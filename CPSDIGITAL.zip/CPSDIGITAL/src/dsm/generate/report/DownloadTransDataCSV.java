package dsm.generate.report;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dsm.model.DB.TransSubData;
import dsm.model.user.User;

/**
 * Servlet implementation class DownloadTransDataCSV
 */
public class DownloadTransDataCSV extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public DownloadTransDataCSV() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		HttpSession httpSession = request.getSession();
		String path	= new File(System.getProperty("SCHEME_STUDIO_FILE_PATH")).getPath();
		User user = (User)httpSession.getAttribute("appUser");
		if(user != null){
			TransSubData transData = new TransSubData();


			transData.setSchemeId(Integer.parseInt(request.getParameter("schemeId")==null?"0":request.getParameter("schemeId")));
			transData.setCompId(Integer.parseInt(request.getParameter("compId")==null?"0":request.getParameter("compId")));
			transData.setConditionId(Integer.parseInt(request.getParameter("conditionId")==null?"0":request.getParameter("conditionId")));
			transData.setPaymentId(Integer.parseInt(request.getParameter("paymentId")==null?"0":request.getParameter("paymentId")));
			transData.setQualifyType(Integer.parseInt(request.getParameter("qualifyType")==null?"0":request.getParameter("qualifyType")));
			transData.setTransSubDataType(request.getParameter("transSubDataType"));
			transData.setUniverseId(Integer.parseInt(request.getParameter("universeId")==null?"0":request.getParameter("universeId")));

			if(user != null)
				transData.setCircleId(user.getCircleId());
			System.out.println("path ::: "+path);

			StringBuffer csvFilePath = new StringBuffer();
			csvFilePath.append(path).append("/").append(transData.getCircleId()).append("/").append(transData.getTransSubDataType()).append("_");//.append(transData.getCircleId()).append("_");
			csvFilePath.append(transData.getSchemeId()).append("_").append(transData.getCompId()).append("_").append(transData.getConditionId()).append("_");
			csvFilePath.append(transData.getQualifyType()).append("_").append(transData.getPaymentId()).append("_").append(transData.getUniverseId()).append(".zip");

			System.out.println("csvFilePath ::: "+csvFilePath);
			//String filePath ="C:\\Users\\IBM_ADMIN\\Desktop\\DesktopIcons\\DSMSamples\\jdk-8u40-docs-all.zip";

			//String filePath ="C:\\Users\\IBM_ADMIN\\Desktop\\DesktopIcons\\DSMSamples\\jdk-8u40-docs-all.zip";
			File downloadFile = new File(csvFilePath.toString());
			
			FileInputStream inStream = new FileInputStream(downloadFile);

			String relativePath = getServletContext().getRealPath("");
			System.out.println("relativePath :: "+relativePath);

			ServletContext context = getServletContext();

			String mimeType = context.getMimeType(csvFilePath.toString());
			if(mimeType == null){
				mimeType = "application/octet-stream";
			}
			System.out.println("MIME type: " + mimeType);

			response.setContentType(mimeType);
			response.setContentLength((int) downloadFile.length());
			if(downloadFile.length() != 0 || downloadFile.length()!= -1){
				String headerKey = "Content-Disposition";
				String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
				response.setHeader(headerKey, headerValue);

				OutputStream outStream = response.getOutputStream();
				byte[] buffer = new byte[4096];
				int bytesRead = -1;
				while ((bytesRead = inStream.read(buffer)) != -1) {
					outStream.write(buffer, 0, bytesRead);
				}

				inStream.close();
				outStream.close();
			}else{
				//code to no file or record
			}
		}
	}

}

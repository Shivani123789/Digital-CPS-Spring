package dsm.generate.report;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import dsm.model.DB.RetailerStmtScmList;
import dsm.model.DB.RetailerStmtVO;

public class RetailerPdfZip extends Thread {

	private List<RetailerStmtVO> retailerList ;
	private String zipFileName;
	private int circleId;
	private String imagePath;
	
	public void run(){
		try{
			if(getRetailerList() != null && getRetailerList().size() != 0){
				String path = new File(System.getProperty("SCHEME_STUDIO_FILE_PATH")).getPath();
				//File Path
				StringBuffer zipFilePath = new StringBuffer();
				zipFilePath.append(path).append("/").append(getCircleId()).append("/").append(getZipFileName()).append(".zip");
				ListIterator<RetailerStmtVO> listIterator = getRetailerList().listIterator();
				
				System.out.println("Retailer Zip File Path :::: "+zipFilePath.toString());
				
				ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipFilePath.toString()));
				
				while(listIterator.hasNext()){
					RetailerStmtVO retvo = (RetailerStmtVO)listIterator.next();
					generateRetailerNewPdf(retvo,zip);
				}
				
				zip.close();
				System.out.println("Zip Completed **********");

			}
		}catch(FileNotFoundException e){
			System.err.println("FileNotFound ::::: "+e.getMessage());//e.printStackTrace();
		}catch(Exception e){

		}
	}
	
	
	/*private void generateRetailerPdf(RetailerStmtVO ret,ZipOutputStream zip){
		try {
			ZipEntry entry = new ZipEntry(ret.getRetailerDsm2Id()+".pdf");
            zip.putNextEntry(entry);
			Document document=null;
			document = new Document();
			document.setPageSize(PageSize.A4);
			PdfWriter writer = PdfWriter.getInstance(document, zip);
            writer.setCloseStream(false);
          
            //Inserting Image and heading in PDF
            
			
			Image image=null;
			try {
				image = Image.getInstance (new URL(getImagePath()));
				//imager.scaleToFit(60f, 30f);//image width,height
				image.scaleAbsolute(50f, 25f);
				image.setAlignment(Element.ALIGN_LEFT);
				image.setBorder(0);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
            
			Image image = Image.getInstance ("src/idealogo.png");
			image.scaleAbsolute(50f, 25f);//image width,height
			image.setAlignment(Element.ALIGN_LEFT);

			//PDF Heading
			Font titlefont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			titlefont.setColor(BaseColor.WHITE);
			titlefont.setSize(9);

			Font curDatefont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			curDatefont.setColor(BaseColor.BLACK);
			curDatefont.setSize(6);

			Font fontCommon = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontCommon.setColor(BaseColor.BLACK);
			fontCommon.setSize(8);	  
			// fontCommon.setStyle(2);

			Font subHeadfont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			subHeadfont.setColor(BaseColor.WHITE);
			subHeadfont.setSize(8);	  

			Font notefont = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
			notefont.setColor(BaseColor.BLACK);
			notefont.setSize(7);

			Font distributorInfofont = FontFactory.getFont(FontFactory.TIMES_ROMAN);
			distributorInfofont.setColor(BaseColor.BLACK);
			distributorInfofont.setSize(8);



			///////////////////////////////

			PdfPTable titleTable = new PdfPTable(2);
			titleTable.setWidthPercentage(100f);
			titleTable.setWidths(new float[] {2.9f,20.0f});


			PdfPCell titleHeadCellR = new PdfPCell ();
			titleHeadCellR.setColspan (0);
			titleHeadCellR.setBackgroundColor(BaseColor.BLACK);
			titleHeadCellR.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell imageHead = new PdfPCell ();
			imageHead.setColspan (1);
			imageHead.setRowspan(2);
			imageHead.setBorder(0);
			imageHead.setHorizontalAlignment (Element.ALIGN_LEFT);
			imageHead.addElement(image);

			titleTable.addCell(imageHead);

			titleHeadCellR.setPhrase(new Phrase("Retailer Statement", titlefont));
			titleHeadCellR.setHorizontalAlignment(Element.ALIGN_CENTER);

			titleTable.addCell(titleHeadCellR);


			PdfPCell currDateHead = new PdfPCell ();
			currDateHead.setColspan (0);
			currDateHead.setBorderWidthTop(6f);
			currDateHead.setBorderWidth(0.5f);
			currDateHead.setBorderColor(BaseColor.BLACK);
			currDateHead.setHorizontalAlignment(Element.ALIGN_CENTER);
			currDateHead.setPhrase(new Phrase("\nStatement PDF Generation Date:"+new Date(), curDatefont));

			titleTable.addCell(currDateHead);


			///////////////////////////////

			*//**
			 * Retailer Info table 
			 *//*

			PdfPTable distributorInfoTable = new PdfPTable(2);
			distributorInfoTable.setWidthPercentage(80f);
			distributorInfoTable.setWidths(new float[] {16.0f,28.0f});
			distributorInfoTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell leftCell = new PdfPCell ();
			leftCell.setColspan (1);
			leftCell.setNoWrap(true);
			leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
			leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell rightCell = new PdfPCell ();
			rightCell.setColspan (1);
			//rightCell.setNoWrap(true);
			rightCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			leftCell.setPhrase(new Phrase("Retailer Mobile", fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerMsisdn(), distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("Retailer Name",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerOwnName(),distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("Firm Name",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerFirmName(),distributorInfofont));
			//rightCell.setPhrase(new Phrase(subString(ret.getRetailerFirmName()),distributorInfofont));
			distributorInfoTable.addCell(rightCell);
			
			leftCell.setPhrase(new Phrase("Address",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerAddress(),distributorInfofont));
			//rightCell.setPhrase(new Phrase(subString(ret.getRetailerAddress()),distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("Distributor",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getDistributorName(),distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("Zone", fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerZone(), distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			*//**
			 * Second Table Generation
			 *//*


			PdfPTable turnOverTable = new PdfPTable(3);
			turnOverTable.setWidthPercentage(80f);
			turnOverTable.setWidths(new float[] {16.0f,8.0f,10.0f});
			turnOverTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);


			PdfPCell totLeftCell = new PdfPCell ();
			totLeftCell.setColspan (1);
			totLeftCell.setNoWrap(true);
			totLeftCell.setBackgroundColor(new BaseColor (193, 193, 193));
			totLeftCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell totSideHeadCell = new PdfPCell ();
			totSideHeadCell.setColspan (1);
			totSideHeadCell.setNoWrap(true);
			totSideHeadCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell totRightCell = new PdfPCell ();
			totRightCell.setColspan (1);
			//totRightCell.setBorder(1);
			totRightCell.setNoWrap(true);
			totRightCell.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell blankCell = new PdfPCell ();
			blankCell.setColspan (1);
			blankCell.addElement(new Paragraph(""));
			
			PdfPCell blankCell3 = new PdfPCell ();
			blankCell3.setColspan (3);
			blankCell3.setBorder(0);
			blankCell3.addElement(new Paragraph(""));
			
			PdfPCell payoutMonthCell = new PdfPCell ();
			payoutMonthCell.setColspan (2);
			payoutMonthCell.setNoWrap(true);
			payoutMonthCell.setBackgroundColor(BaseColor.BLACK);
			payoutMonthCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			//payoutMonthCell.setBorderWidthLeft(1);
			//payoutMonthCell.setBorderColorLeft(BaseColor.WHITE);
			
			PdfPCell payoutMonthCell24 = new PdfPCell ();
			payoutMonthCell24.setColspan (1);
			payoutMonthCell24.setNoWrap(true);
			payoutMonthCell24.setBackgroundColor(BaseColor.BLACK);
			payoutMonthCell24.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			PdfPCell payoutMonthCell2 = new PdfPCell ();
			payoutMonthCell2.setColspan (1);
			payoutMonthCell2.setNoWrap(true);
			payoutMonthCell2.setBackgroundColor(BaseColor.BLACK);
			payoutMonthCell2.setHorizontalAlignment (Element.ALIGN_LEFT);
			payoutMonthCell2.setBorderWidthLeft(1);
			payoutMonthCell2.setBorderColorLeft(BaseColor.WHITE);
			
			PdfPTable turnOverTable1 = new PdfPTable(3);
			turnOverTable1.setWidthPercentage(80f);
			turnOverTable1.setWidths(new float[] {16.0f,8.0f,10.0f});
			turnOverTable1.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
			
			PdfPCell payoutMonthCell1 = new PdfPCell ();
			payoutMonthCell1.setColspan (2);
			payoutMonthCell1.setNoWrap(true);
			payoutMonthCell1.setBackgroundColor(BaseColor.BLACK);
			payoutMonthCell1.setHorizontalAlignment (Element.ALIGN_LEFT);
			//payoutMonthCell1.setBorderWidthLeft(1);
			//payoutMonthCell1.setBorderColorLeft(BaseColor.WHITE);
			
			PdfPCell payoutMonthCell12 = new PdfPCell ();
			payoutMonthCell12.setColspan (1);
			payoutMonthCell12.setNoWrap(true);
			payoutMonthCell12.setBackgroundColor(BaseColor.BLACK);
			payoutMonthCell12.setHorizontalAlignment (Element.ALIGN_LEFT);
			payoutMonthCell12.setBorderWidthLeft(1);
			payoutMonthCell12.setBorderColorLeft(BaseColor.WHITE);
			
			payoutMonthCell1.addElement(new Paragraph("Payout Report for the Month of",subHeadfont));
			turnOverTable1.addCell(payoutMonthCell1);	       
			payoutMonthCell12.addElement(new Paragraph(String.valueOf(ret.getStmtMonth()),subHeadfont));
			turnOverTable1.addCell(payoutMonthCell12);
			
			turnOverTable.addCell(blankCell3);
			
			payoutMonthCell24.setPhrase(new Phrase("Activations",subHeadfont));
			turnOverTable.addCell(payoutMonthCell24);	       
			
			payoutMonthCell2.setPhrase(new Phrase("Gross",subHeadfont));
			turnOverTable.addCell(payoutMonthCell2);	       
			
			payoutMonthCell2.setPhrase(new Phrase("Eligible",subHeadfont));
			turnOverTable.addCell(payoutMonthCell2);	       
			
			
			totLeftCell.setPhrase(new Phrase("Normal",fontCommon));
			turnOverTable.addCell(totLeftCell);
			totRightCell.setPhrase(new Phrase(String.valueOf(ret.getNormalGross()),fontCommon));
			turnOverTable.addCell(totRightCell);
			turnOverTable.addCell(blankCell);
			
			totLeftCell.setPhrase(new Phrase("MNP",fontCommon));
			turnOverTable.addCell(totLeftCell);
			totRightCell.setPhrase(new Phrase(String.valueOf(ret.getMnpGross()),fontCommon));
			turnOverTable.addCell(totRightCell);
			turnOverTable.addCell(blankCell);
			
			totLeftCell.setPhrase(new Phrase("Total",fontCommon));
			turnOverTable.addCell(totLeftCell);
			totRightCell.setPhrase(new Phrase(String.valueOf(ret.getGrossAct()),fontCommon));
			turnOverTable.addCell(totRightCell);
			turnOverTable.addCell(blankCell);

			
			PdfPTable comboInfotable = new PdfPTable(1);
			comboInfotable.setWidthPercentage(100f);
			//comboInfotable.setWidths(new float[] {20.0f,20.0f});
			comboInfotable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell custInfoCell2 = new PdfPCell ();
			custInfoCell2.setColspan (1);
			custInfoCell2.setBorder(0);

			PdfPCell custInfoCell22 = new PdfPCell ();
			custInfoCell22.setColspan (1);
			custInfoCell22.setBorder(0);
			
			custInfoCell2.addElement(turnOverTable1);
			comboInfotable.addCell(custInfoCell2);
			custInfoCell22.addElement(turnOverTable);
			comboInfotable.addCell(custInfoCell22);
			
			
			PdfPTable custInfotable = new PdfPTable(2);
			custInfotable.setWidthPercentage(100f);
			custInfotable.setWidths(new float[] {20.0f,20.0f});
			custInfotable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell custInfoCell = new PdfPCell ();
			custInfoCell.setColspan (1);
			custInfoCell.setBorder(0);

			PdfPCell custInfoCellR = new PdfPCell ();
			custInfoCellR.setColspan (1);
			custInfoCellR.setBorder(0);

			custInfoCell.addElement(distributorInfoTable);
			custInfotable.addCell(custInfoCell);
			custInfoCellR.addElement(comboInfotable);
			custInfotable.addCell(custInfoCellR);
			*//**
			 * Payout Details
			 *//*
			
			
			PdfPTable payoutDetailTable = new PdfPTable(6);
			payoutDetailTable.setWidthPercentage(100f);
			payoutDetailTable.setWidths(new float[] {10.0f,15.0f,8.0f,8.0f,8.0f,8.0f});
			payoutDetailTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPTable payoutDetailTable1 = new PdfPTable(6);
			payoutDetailTable1.setWidthPercentage(100f);
			payoutDetailTable1.setWidths(new float[] {10.0f,15.0f,8.0f,8.0f,8.0f,8.0f});
			payoutDetailTable1.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell tableLeft1_1 = new PdfPCell ();
			tableLeft1_1.setColspan (2);
			tableLeft1_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft1_1.setHorizontalAlignment (Element.ALIGN_CENTER);

			PdfPCell tableLeft1_2 = new PdfPCell ();
			tableLeft1_2.setColspan (1);
			tableLeft1_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft1_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft1_2.setBorderColorLeft(BaseColor.WHITE);
			tableLeft1_2.setBorderWidthLeft(0.4f);


			PdfPCell tableLeft1_3 = new PdfPCell ();
			tableLeft1_3.setColspan (1);
			tableLeft1_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft1_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft1_3.setBorderColorLeft(BaseColor.WHITE);
			tableLeft1_3.setBorderWidthLeft(0.4f);


			PdfPCell tableLeft1_4 = new PdfPCell ();
			tableLeft1_4.setColspan (2);
			tableLeft1_4.setBackgroundColor(BaseColor.BLACK);
			tableLeft1_4.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft1_4.setBorderColorLeft(BaseColor.WHITE);
			tableLeft1_4.setBorderWidthLeft(0.4f);

			tableLeft1_1.setPhrase(new Phrase("Payout Details",subHeadfont));
			payoutDetailTable.addCell(tableLeft1_1);	       
			tableLeft1_2.setPhrase(new Phrase("Activations",subHeadfont));
			payoutDetailTable.addCell(tableLeft1_2);
			tableLeft1_3.setPhrase(new Phrase("Net Amount",subHeadfont));
			payoutDetailTable.addCell(tableLeft1_3);
			tableLeft1_4.setPhrase(new Phrase("Remarks",subHeadfont));
			payoutDetailTable.addCell(tableLeft1_4);
			
			PdfPCell otfHeadCell = new PdfPCell ();
			otfHeadCell.setColspan (1);
			//otfHeadCell.setBorder(1);
			//otfHeadCell.setBorderWidth(1);
			otfHeadCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			
			PdfPCell otfCell1 = new PdfPCell ();
			otfCell1.setColspan (1);
			//otfCell1.setBorder(1);
			otfCell1.setBorderWidthBottom(0.4f);
			otfCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			
			PdfPCell otfCell2 = new PdfPCell ();
			otfCell2.setColspan (1);
			//otfCell2.setBorder(1);
			otfCell2.setBorderWidthBottom(0.4f);
			otfCell2.setHorizontalAlignment(Element.ALIGN_RIGHT);
			
			PdfPCell otfCell3 = new PdfPCell ();
			otfCell3.setColspan (1);
			//otfCell3.setBorder(1);
			otfCell3.setBorderWidthBottom(0.4f);
			otfCell3.setHorizontalAlignment(Element.ALIGN_RIGHT);
			
			PdfPCell otfCell4 = new PdfPCell ();
			otfCell4.setColspan (2);
			//otfCell4.setBorder(1);
			otfCell4.setBorderWidthBottom(0.4f);
			otfCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			
			PdfPCell bottomTab1 = new PdfPCell ();
			bottomTab1.setColspan (1);
			bottomTab1.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab1.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			PdfPCell bottomTab2 = new PdfPCell ();
			bottomTab2.setColspan (1);
			bottomTab2.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab2.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab3 = new PdfPCell ();
			bottomTab3.setColspan (1);
			bottomTab3.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab3.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab4 = new PdfPCell ();
			bottomTab4.setColspan (2);
			bottomTab4.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab4.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			PdfPCell otHeadCell = new PdfPCell ();
			otHeadCell.setColspan (1);
			otHeadCell.setHorizontalAlignment(Element.ALIGN_LEFT);
			
			PdfPCell otCell1 = new PdfPCell ();
			otCell1.setColspan (1);
			otCell1.setHorizontalAlignment(Element.ALIGN_LEFT);
			
			PdfPCell otCell2 = new PdfPCell ();
			otCell2.setColspan (1);
			otCell2.setHorizontalAlignment(Element.ALIGN_RIGHT);
			
			PdfPCell otCell3 = new PdfPCell ();
			otCell3.setColspan (1);
			otCell3.setHorizontalAlignment(Element.ALIGN_RIGHT);
			
			PdfPCell otCell4 = new PdfPCell ();
			otCell4.setColspan (2);
			otCell4.setHorizontalAlignment(Element.ALIGN_LEFT);
			
			PdfPCell bottomTab11 = new PdfPCell ();
			bottomTab11.setColspan (1);
			bottomTab11.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab11.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			PdfPCell bottomTab12 = new PdfPCell ();
			bottomTab12.setColspan (1);
			bottomTab12.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab12.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab13 = new PdfPCell ();
			bottomTab13.setColspan (1);
			bottomTab13.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab13.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab14 = new PdfPCell ();
			bottomTab14.setColspan (2);
			bottomTab14.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab14.setHorizontalAlignment (Element.ALIGN_LEFT);

			//float totalAB = 0f;
			for (Map.Entry<String, List<RetailerStmtScmList>> mapentry : ret.getRetailerSubMap().entrySet()) {
				String key = mapentry.getKey();
				List<RetailerStmtScmList> values = (List<RetailerStmtScmList>)mapentry.getValue();
				
				if("OTF".equalsIgnoreCase(key)){
					otfHeadCell.setRowspan(values.size()+1);
					otfHeadCell.setPhrase(new Phrase("On the Fly \nCommission (A)",fontCommon));
					payoutDetailTable.addCell(otfHeadCell);
					float totala=0f;
					for(RetailerStmtScmList val:values){
						otfCell1.setPhrase(new Phrase(val.getSchemeCompDesc(),fontCommon));
						otfCell2.setPhrase(new Phrase(""));
						otfCell3.setPhrase(new Phrase(String.valueOf(val.getNetComm()),fontCommon));
						otfCell4.setPhrase(new Phrase("",fontCommon));
						//totala=totala+val.getNetComm();
						payoutDetailTable.addCell(otfCell1);
						payoutDetailTable.addCell(otfCell2);
						payoutDetailTable.addCell(otfCell3);
						payoutDetailTable.addCell(otfCell4);
					}
					
					bottomTab1.setPhrase(new Phrase("Total A",fontCommon));	
					bottomTab2.setPhrase(new Phrase("",fontCommon));
					bottomTab3.setPhrase(new Phrase(""+totala,fontCommon));
					bottomTab4.setPhrase(new Phrase("",fontCommon));	
					//totalAB=totala;
					payoutDetailTable.addCell(otfHeadCell);
					if(values.size()!=0){
						payoutDetailTable.addCell(otfCell1);
						payoutDetailTable.addCell(otfCell2);
						payoutDetailTable.addCell(otfCell3);
						payoutDetailTable.addCell(otfCell4);
					}
					payoutDetailTable.addCell(bottomTab1);
					payoutDetailTable.addCell(bottomTab2);
					payoutDetailTable.addCell(bottomTab3);
					payoutDetailTable.addCell(bottomTab4);
					
				}else{

					otHeadCell.setRowspan(values.size()+1);
					otHeadCell.setPhrase(new Phrase("Monthly Schemes (B)",fontCommon));
					payoutDetailTable1.addCell(otHeadCell);
					float totalb=0f;
					for(RetailerStmtScmList val:values){
						otCell1.setPhrase(new Phrase(val.getSchemeCompDesc(),fontCommon));
						otCell2.setPhrase(new Phrase(""));
						otCell3.setPhrase(new Phrase(String.valueOf(val.getNetComm()),fontCommon));
						otCell4.setPhrase(new Phrase("",fontCommon));
						//totalb=totalb+val.getNetComm();
						payoutDetailTable1.addCell(otCell1);
						payoutDetailTable1.addCell(otCell2);
						payoutDetailTable1.addCell(otCell3);
						payoutDetailTable1.addCell(otCell4);
					}

					bottomTab11.setPhrase(new Phrase("Total B",fontCommon));	
					bottomTab12.setPhrase(new Phrase("",fontCommon));
					bottomTab13.setPhrase(new Phrase(""+totalb,fontCommon));
					bottomTab14.setPhrase(new Phrase("",fontCommon));	

					
					if(values.size()!=0){
						payoutDetailTable1.addCell(otCell1);
						payoutDetailTable1.addCell(otCell2);
						payoutDetailTable1.addCell(otCell3);
						payoutDetailTable1.addCell(otCell4);
					}
					payoutDetailTable1.addCell(bottomTab11);
					payoutDetailTable1.addCell(bottomTab12);
					payoutDetailTable1.addCell(bottomTab13);
					payoutDetailTable1.addCell(bottomTab14);

				}
				
			}
				
			PdfPCell bottomTot1 = new PdfPCell ();
			bottomTot1.setColspan (2);
			bottomTot1.setBackgroundColor(BaseColor.GRAY);
			bottomTot1.setHorizontalAlignment (Element.ALIGN_LEFT);
		
			PdfPCell bottomTot2 = new PdfPCell ();
			bottomTot2.setColspan (1);
			bottomTot2.setBackgroundColor(BaseColor.GRAY);
			bottomTot2.setHorizontalAlignment (Element.ALIGN_RIGHT);
		
			PdfPCell bottomTot3 = new PdfPCell ();
			bottomTot3.setColspan (1);
			bottomTot3.setBackgroundColor(BaseColor.GRAY);
			bottomTot3.setHorizontalAlignment (Element.ALIGN_RIGHT);
		
			PdfPCell bottomTot4 = new PdfPCell ();
			bottomTot4.setColspan (2);
			bottomTot4.setBackgroundColor(BaseColor.GRAY);
			bottomTot4.setHorizontalAlignment (Element.ALIGN_LEFT);
		
			bottomTot1.setPhrase(new Phrase("Total Payout (A+B)",fontCommon));
			bottomTot2.setPhrase(new Phrase("",fontCommon));
			bottomTot3.setPhrase(new Phrase(""+ret.getTotalNet(),fontCommon));
			bottomTot4.setPhrase(new Phrase("",fontCommon));
		//	System.out.println("totalAB ********************** "+totalAB);
			payoutDetailTable1.addCell(bottomTot1);
			payoutDetailTable1.addCell(bottomTot2);
			payoutDetailTable1.addCell(bottomTot3);
			payoutDetailTable1.addCell(bottomTot4);
			
			bottomTot1.setPhrase(new Phrase("Clawback",fontCommon));
			bottomTot2.setPhrase(new Phrase("",fontCommon));
			bottomTot3.setPhrase(new Phrase("",fontCommon));
			bottomTot4.setPhrase(new Phrase("",fontCommon));
			
			payoutDetailTable1.addCell(bottomTot1);
			payoutDetailTable1.addCell(bottomTot2);
			payoutDetailTable1.addCell(bottomTot3);
			payoutDetailTable1.addCell(bottomTot4);
			*//**
			 * Third Table Generation
			 *//*



			PdfPTable table2=new PdfPTable(6);
			table2.setWidthPercentage(100f);
			table2.setWidths(new float[] {10.0f,15.0f,8.0f,8.0f,8.0f,8.0f});
			table2.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			
			PdfPCell blankHeadCell = new PdfPCell ();
			blankHeadCell.setColspan (3);
			blankHeadCell.setBorder(0);
			blankHeadCell.addElement(new Paragraph(""));

			
			PdfPCell tableLeft2_1 = new PdfPCell ();
			tableLeft2_1.setColspan (2);
			tableLeft2_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_1.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell tableLeft2_2 = new PdfPCell ();
			tableLeft2_2.setColspan (1);
			tableLeft2_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft2_2.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_2.setBorderWidthLeft(0.4f);


			PdfPCell tableLeft2_3 = new PdfPCell ();
			tableLeft2_3.setColspan (1);
			tableLeft2_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_3.setHorizontalAlignment (Element.ALIGN_RIGHT);
			tableLeft2_3.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_3.setBorderWidthLeft(0.4f);


			PdfPCell tableLeft2_4 = new PdfPCell ();
			tableLeft2_4.setColspan (2);
			tableLeft2_4.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_4.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft2_4.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_4.setBorderWidthLeft(0.4f);


			tableLeft2_1.setPhrase(new Phrase("Net Payout Released",subHeadfont));
			table2.addCell(tableLeft2_1);	       
			tableLeft2_2.setPhrase(new Phrase("",subHeadfont));
			table2.addCell(tableLeft2_2);
			tableLeft2_3.setPhrase(new Phrase(""+ret.getTotalNet(),subHeadfont));
			table2.addCell(tableLeft2_3);
			tableLeft2_4.setPhrase(new Phrase("",subHeadfont));
			table2.addCell(tableLeft2_4);

			
			*//**
			 * Fourth Table Generation
			 *//*


			PdfPTable table3=new PdfPTable(6);
			table3.setWidthPercentage(100f);
			table3.setWidths(new float[]{10.0f,15.0f,8.0f,8.0f,8.0f,8.0f});
			table3.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);


			PdfPCell tableLeft3_1 = new PdfPCell ();
			tableLeft3_1.setColspan (2);
			tableLeft3_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_1.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell tableLeft3_2 = new PdfPCell ();
			tableLeft3_2.setColspan (1);
			tableLeft3_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_2.setBorderWidthLeft(0.4f);
			tableLeft3_2.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_3 = new PdfPCell ();
			tableLeft3_3.setColspan (1);
			tableLeft3_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_3.setBorderWidthLeft(0.4f);
			tableLeft3_3.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_4 = new PdfPCell ();
			tableLeft3_4.setColspan (1);
			tableLeft3_4.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_4.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_4.setBorderWidthLeft(0.4f);
			tableLeft3_4.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_5 = new PdfPCell ();
			tableLeft3_5.setColspan (1);
			tableLeft3_5.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_5.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_5.setBorderWidthLeft(0.4f);
			tableLeft3_5.setBorderColorLeft(BaseColor.WHITE);

			
			tableLeft3_1.setPhrase(new Phrase("Retail Loyalty Points",subHeadfont));
			table3.addCell(tableLeft3_1);	       
			tableLeft3_2.setPhrase(new Phrase("Opening Points",subHeadfont));
			table3.addCell(tableLeft3_2);
			tableLeft3_3.setPhrase(new Phrase("Earned this Month",subHeadfont));
			table3.addCell(tableLeft3_3);
			tableLeft3_4.setPhrase(new Phrase("Total Points",subHeadfont));
			table3.addCell(tableLeft3_4);
			tableLeft3_5.setPhrase(new Phrase("Remarks",subHeadfont));
			table3.addCell(tableLeft3_5);
			
			// Particular
			PdfPCell tableLeft3_11 = new PdfPCell ();
			tableLeft3_11.setColspan (2);
			tableLeft3_11.setHorizontalAlignment (Element.ALIGN_LEFT);
			tableLeft3_11.setNoWrap(true);

			// No's
			PdfPCell tableLeft3_22 = new PdfPCell ();
			tableLeft3_22.setColspan (1);
			tableLeft3_22.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Rate
			PdfPCell tableLeft3_33 = new PdfPCell ();
			tableLeft3_33.setColspan (1);
			tableLeft3_33.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Payout Gross
			PdfPCell tableLeft3_44 = new PdfPCell ();
			tableLeft3_44.setColspan (1);
			tableLeft3_44.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// TDS@10%
			PdfPCell tableLeft3_55 = new PdfPCell ();
			tableLeft3_55.setColspan (1);
			tableLeft3_55.setHorizontalAlignment (Element.ALIGN_RIGHT);

			
			tableLeft3_11.setPhrase(new Phrase("(Yearly)",fontCommon));
			table3.addCell(tableLeft3_11);	       
			tableLeft3_22.setPhrase(new Phrase("" ,fontCommon));
			table3.addCell(tableLeft3_22);
			tableLeft3_33.setPhrase(new Phrase("",fontCommon));
			table3.addCell(tableLeft3_33);
			tableLeft3_44.setPhrase(new Phrase("",fontCommon));
			table3.addCell(tableLeft3_44);
			tableLeft3_55.setPhrase(new Phrase("" ,fontCommon));
			table3.addCell(tableLeft3_55);
			
			
			
			*//**
			 * Fifth Table Generation
			 *//*


			PdfPTable table4=new PdfPTable(6);
			table4.setWidthPercentage(100f);
			table4.setWidths(new float[]{10.0f,15.0f,8.0f,8.0f,8.0f,8.0f});
			table4.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			
			PdfPCell tableLeft4_1 = new PdfPCell ();
			tableLeft4_1.setColspan (2);
			tableLeft4_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_1.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell tableLeft4_2 = new PdfPCell ();
			tableLeft4_2.setColspan (2);
			tableLeft4_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_2.setBorderWidthLeft(0.6f);
			tableLeft4_2.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft4_3 = new PdfPCell ();
			tableLeft4_3.setColspan (2);
			tableLeft4_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_3.setBorderWidthLeft(0.4f);
			tableLeft4_3.setBorderColorLeft(BaseColor.WHITE);

			
			tableLeft4_1.setPhrase(new Phrase("Note:",subHeadfont));
			table4.addCell(tableLeft4_1);	       
			tableLeft4_2.setPhrase(new Phrase("Name",subHeadfont));
			table4.addCell(tableLeft4_2);
			tableLeft4_3.setPhrase(new Phrase("Contact Number",subHeadfont));
			table4.addCell(tableLeft4_3);
			
			// Particular
			PdfPCell tableLeft4_11 = new PdfPCell ();
			tableLeft4_11.setColspan (2);
			tableLeft4_11.setHorizontalAlignment (Element.ALIGN_LEFT);
			tableLeft4_11.setNoWrap(true);
			tableLeft4_11.setBackgroundColor(BaseColor.YELLOW);
			
			// No's
			PdfPCell tableLeft4_22 = new PdfPCell ();
			tableLeft4_22.setColspan (2);
			tableLeft4_22.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_22.setBackgroundColor(BaseColor.YELLOW);
			
			// Rate
			PdfPCell tableLeft4_33 = new PdfPCell ();
			tableLeft4_33.setColspan (2);
			tableLeft4_33.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_33.setBackgroundColor(BaseColor.YELLOW);
			
			PdfPCell tableLeft4_44 = new PdfPCell ();
			tableLeft4_44.setColspan (6);
			tableLeft4_44.setHorizontalAlignment (Element.ALIGN_CENTER);

			
			tableLeft4_11.setPhrase(new Phrase("1. Incase of any query please contact your TSM:",fontCommon));
			table4.addCell(tableLeft4_11);
			
			tableLeft4_22.setPhrase(new Phrase(ret.getTsm() ,fontCommon));
			table4.addCell(tableLeft4_22);
			
			tableLeft4_33.setPhrase(new Phrase(ret.getTsmMsisdn(),fontCommon));
			table4.addCell(tableLeft4_33);
			
			tableLeft4_11.setPhrase(new Phrase("2. ASM Incharge of your business:",fontCommon));
			table4.addCell(tableLeft4_11);
			
			tableLeft4_22.setPhrase(new Phrase(ret.getAsm() ,fontCommon));
			table4.addCell(tableLeft4_22);
			
			tableLeft4_33.setPhrase(new Phrase(ret.getAsmMsisdn(),fontCommon));
			table4.addCell(tableLeft4_33);
			
			tableLeft4_11.setPhrase(new Phrase("3. ZBM Incharge of your business:",fontCommon));
			table4.addCell(tableLeft4_11);
			
			tableLeft4_22.setPhrase(new Phrase(ret.getZbm() ,fontCommon));
			table4.addCell(tableLeft4_22);
			
			tableLeft4_33.setPhrase(new Phrase(ret.getZbmMsisdn(),fontCommon));
			table4.addCell(tableLeft4_33);
			
			tableLeft4_44.setPhrase(new Phrase("This is a system generated report. No signature needed.",fontCommon));
			table4.addCell(tableLeft4_44);
			
			
			
			
			
			
			
			
			
			
			
			
			*//**
			 *  ***********************************************************************************************************			
			 *//*
			//Now Insert Every Thing Into PDF Document
			document.open();//PDF document opened........       
			//document.add(head);
			document.add(titleTable);
			document.add(Chunk.NEWLINE);
			document.add(Chunk.NEWLINE);
			document.add(new Paragraph(" "));
			document.add(custInfotable);
			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph(" "));
			document.add(payoutDetailTable);
			document.add(payoutDetailTable1);
			//document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			//	document.add(new Paragraph(" "));
			//	document.add(table1);
			//document.add(new Paragraph("Dear Channel Partner,", fontCommon));
			//document.add(new Paragraph("Please find mentioned below the details of Hisab-Kitab for the month.", fontCommon));
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			//document.add(subHeaderTable);
			document.add(table2);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			document.add(new Paragraph(""));
			//document.add(headerTable1);
			document.add(table3);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			document.add(new Paragraph(""));
			//document.add(headerTable2);
			document.add(table4);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			document.newPage();
			document.add(titleTable);
			document.add(new Paragraph("Note:")); 
			document.add(new Paragraph("In case of any clarifications you are requested to kindly revert back with details in 7 days. In case of no reply, we will assume this statement to be correct and validated. ",notefont));
			//document.add(Chunk.NEWLINE);
			document.add(new Paragraph("This is a system generated report. No signature needed.",notefont));
			//document.add(Chunk.NEWLINE);
			document.add(new Paragraph("Discharge of applicable withholding tax, if any, towards your retailer payouts should be complied by you.",notefont));

			document.close();
			
			//file.close();
			zip.closeEntry();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}*/


	public List<RetailerStmtVO> getRetailerList() {
		return retailerList;
	}


	public void setRetailerList(List<RetailerStmtVO> retailerList) {
		this.retailerList = retailerList;
	}


	public String getZipFileName() {
		return zipFileName;
	}


	public void setZipFileName(String zipFileName) {
		this.zipFileName = zipFileName;
	}


	public int getCircleId() {
		return circleId;
	}


	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}


	public String getImagePath() {
		return imagePath;
	}


	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

	//15 Oct 2015
	private void generateRetailerNewPdf(RetailerStmtVO ret,ZipOutputStream zip){
		try {
			SimpleDateFormat sd = new SimpleDateFormat("dd-MMMMMM-yyyy  HH:mm:ss ");
			ZipEntry entry = new ZipEntry(ret.getRetailerDsm2Id()+".pdf");
            zip.putNextEntry(entry);
			Document document=null;
			document = new Document();
			document.setPageSize(PageSize.A4);
			PdfWriter writer = PdfWriter.getInstance(document, zip);
            writer.setCloseStream(false);
          
            //Inserting Image and heading in PDF
            
			
			Image image=null;
			try {
				//image = Image.getInstance (new URL(getImagePath()));
				image = Image.getInstance (getImagePath());
				//imager.scaleToFit(60f, 30f);//image width,height
				image.scaleAbsolute(50f, 25f);
				image.setAlignment(Element.ALIGN_LEFT);
				image.setBorder(0);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			//PDF Heading
			Font titlefont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			titlefont.setColor(BaseColor.WHITE);
			titlefont.setSize(9);

			Font curDatefont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			curDatefont.setColor(BaseColor.BLACK);
			curDatefont.setSize(6);

			Font fontCommon = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontCommon.setColor(BaseColor.BLACK);
			fontCommon.setSize(8);	  
			// fontCommon.setStyle(2);

			Font subHeadfont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			subHeadfont.setColor(BaseColor.WHITE);
			subHeadfont.setSize(8);	  

			Font notefont = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
			notefont.setColor(BaseColor.BLACK);
			notefont.setSize(7);

			Font distributorInfofont = FontFactory.getFont(FontFactory.TIMES_ROMAN);
			distributorInfofont.setColor(BaseColor.BLACK);
			distributorInfofont.setSize(8);

			///////////////////////////////

			PdfPTable titleTable = new PdfPTable(1);
			titleTable.setWidthPercentage(100f);
			titleTable.setWidths(new float[] {20.0f});//2.9f,


			PdfPCell titleHeadCellR = new PdfPCell ();
			titleHeadCellR.setColspan (0);
			titleHeadCellR.setBackgroundColor(BaseColor.BLACK);
			titleHeadCellR.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell imageHead = new PdfPCell ();
			imageHead.setColspan (1);
			imageHead.setRowspan(3);
			imageHead.setBorder(0);
			imageHead.setHorizontalAlignment (Element.ALIGN_LEFT);
			imageHead.addElement(image);

			//titleTable.addCell(imageHead);

			titleHeadCellR.setPhrase(new Phrase("Retailer Earning Statement", titlefont));
			titleHeadCellR.setHorizontalAlignment(Element.ALIGN_CENTER);

			titleTable.addCell(titleHeadCellR);


			PdfPCell currDateHead = new PdfPCell ();
			currDateHead.setColspan (0);
			currDateHead.setBorderWidthTop(6f);
			currDateHead.setBorderWidth(0.5f);
			currDateHead.setBorderColor(BaseColor.BLACK);
			currDateHead.setHorizontalAlignment(Element.ALIGN_CENTER);
			currDateHead.setPhrase(new Phrase("\nPDF Generation Date:"+sd.format(new Date()), curDatefont));

			titleTable.addCell(currDateHead);

			PdfPTable turnOverTable1 = new PdfPTable(3);
			turnOverTable1.setWidthPercentage(40f);
			turnOverTable1.setWidths(new float[] {8.0f,4.0f,6.0f});
			turnOverTable1.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
			
			PdfPCell payoutMonthCell1 = new PdfPCell ();
			payoutMonthCell1.setColspan (2);
			payoutMonthCell1.setNoWrap(true);
			payoutMonthCell1.setBackgroundColor(BaseColor.BLACK);
			payoutMonthCell1.setHorizontalAlignment (Element.ALIGN_LEFT);
			//payoutMonthCell1.setBorderWidthLeft(1);
			//payoutMonthCell1.setBorderColorLeft(BaseColor.WHITE);
			
			PdfPCell payoutMonthCell12 = new PdfPCell ();
			payoutMonthCell12.setColspan (1);
			payoutMonthCell12.setNoWrap(true);
			payoutMonthCell12.setBackgroundColor(BaseColor.BLACK);
			payoutMonthCell12.setHorizontalAlignment (Element.ALIGN_LEFT);
			payoutMonthCell12.setBorderWidthLeft(1);
			payoutMonthCell12.setBorderColorLeft(BaseColor.WHITE);
			
			payoutMonthCell1.addElement(new Paragraph("Payout Report for the Month of",subHeadfont));
			turnOverTable1.addCell(payoutMonthCell1);	       
			payoutMonthCell12.addElement(new Paragraph(String.valueOf(ret.getStmtMonth()),subHeadfont));
			turnOverTable1.addCell(payoutMonthCell12);
			
			
			
			PdfPCell reportDateHead = new PdfPCell ();
			reportDateHead.setColspan (0);
			reportDateHead.setBorderWidthTop(0.5f);
			reportDateHead.setBorderWidth(0.5f);
			//reportDateHead.setBorderColor(BaseColor.BLACK);
			reportDateHead.setHorizontalAlignment(Element.ALIGN_CENTER);
			reportDateHead.addElement((turnOverTable1));

			titleTable.addCell(reportDateHead);
			///////////////////////////////

			/**
			 * Retailer Info table 
			 */

			PdfPTable distributorInfoTable = new PdfPTable(2);
			distributorInfoTable.setWidthPercentage(100f);
			distributorInfoTable.setWidths(new float[] {25.0f,80.0f});
			distributorInfoTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell leftCell = new PdfPCell ();
			leftCell.setColspan (1);
			leftCell.setNoWrap(true);
			leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
			leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell rightCell = new PdfPCell ();
			rightCell.setColspan (1);
			//rightCell.setNoWrap(true);
			rightCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			leftCell.setPhrase(new Phrase("Retailer Mobile", fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerMsisdn(), distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			/*leftCell.setPhrase(new Phrase("Retailer Name",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerOwnName(),distributorInfofont));
			distributorInfoTable.addCell(rightCell);
*/
			leftCell.setPhrase(new Phrase("Firm Name",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerFirmName(),distributorInfofont));
			//rightCell.setPhrase(new Phrase(subString(ret.getRetailerFirmName()),distributorInfofont));
			distributorInfoTable.addCell(rightCell);
			
			leftCell.setPhrase(new Phrase("Address",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerAddress(),distributorInfofont));
			//rightCell.setPhrase(new Phrase(subString(ret.getRetailerAddress()),distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("Distributor",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getDistributorName(),distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("Zone", fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(ret.getRetailerZone(), distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			/**
			 * Second Table Generation
			 */

			
			PdfPTable comboInfotable = new PdfPTable(1);
			comboInfotable.setWidthPercentage(100f);
			//comboInfotable.setWidths(new float[] {20.0f,20.0f});
			comboInfotable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell custInfoCell2 = new PdfPCell ();
			custInfoCell2.setColspan (1);
			custInfoCell2.setBorder(0);

			PdfPCell custInfoCell22 = new PdfPCell ();
			custInfoCell22.setColspan (1);
			custInfoCell22.setBorder(0);
			
			PdfPTable custInfotable = new PdfPTable(2);
			custInfotable.setWidthPercentage(100f);
			custInfotable.setWidths(new float[] {20.0f,20.0f});
			custInfotable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell custInfoCell = new PdfPCell ();
			custInfoCell.setColspan (1);
			custInfoCell.setBorder(0);

			PdfPCell custInfoCellR = new PdfPCell ();
			custInfoCellR.setColspan (1);
			custInfoCellR.setBorder(0);

			custInfoCell.addElement(distributorInfoTable);
			custInfotable.addCell(custInfoCell);
			custInfoCellR.addElement(comboInfotable);
			custInfotable.addCell(custInfoCellR);
			/**
			 * Payout Details
			 */
			PdfPCell bottomTab1 = new PdfPCell ();
			bottomTab1.setColspan (1);
			bottomTab1.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab1.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			PdfPCell bottomTab2 = new PdfPCell ();
			bottomTab2.setColspan (1);
			bottomTab2.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab2.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab3 = new PdfPCell ();
			bottomTab3.setColspan (1);
			bottomTab3.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab3.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			PdfPCell bottomTab4 = new PdfPCell ();
			bottomTab4.setColspan (1);
			bottomTab4.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab4.setHorizontalAlignment (Element.ALIGN_RIGHT); 

			PdfPTable table2=new PdfPTable(4);
			table2.setWidthPercentage(69f);
			table2.setWidths(new float[] {28.0f,8.0f,8.0f,8.0f});
			table2.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
			
			PdfPCell targetHeadCell = new PdfPCell ();
			targetHeadCell.setColspan (1);
			targetHeadCell.setBackgroundColor(BaseColor.BLACK);
			targetHeadCell.setBorderColorBottom(BaseColor.WHITE);
			targetHeadCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			targetHeadCell.setBorderWidthBottom(1f);


			PdfPCell blankHeadCell = new PdfPCell ();
			blankHeadCell.setColspan (3);
			blankHeadCell.setBorder(0);
			blankHeadCell.addElement(new Paragraph(""));

			targetHeadCell.setPhrase(new Phrase("Achievement", subHeadfont));

			table2.addCell(targetHeadCell);
			table2.addCell(blankHeadCell);

			PdfPCell tableLeft2_1 = new PdfPCell ();
			tableLeft2_1.setColspan (1);
			tableLeft2_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_1.setHorizontalAlignment (Element.ALIGN_CENTER);

			PdfPCell tableLeft2_2 = new PdfPCell ();
			tableLeft2_2.setColspan (1);
			tableLeft2_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft2_2.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_2.setBorderWidthLeft(0.4f);


			PdfPCell tableLeft2_3 = new PdfPCell ();
			tableLeft2_3.setColspan (1);
			tableLeft2_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft2_3.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_3.setBorderWidthLeft(0.4f);


			PdfPCell tableLeft2_4 = new PdfPCell ();
			tableLeft2_4.setColspan (1);
			tableLeft2_4.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_4.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft2_4.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_4.setBorderWidthLeft(0.4f);


			tableLeft2_1.setPhrase(new Phrase("Particulars ",subHeadfont));
			table2.addCell(tableLeft2_1);	       
			tableLeft2_2.setPhrase(new Phrase("Target",subHeadfont));
			table2.addCell(tableLeft2_2);
			tableLeft2_3.setPhrase(new Phrase("Achievement ",subHeadfont));
			table2.addCell(tableLeft2_3);
			tableLeft2_4.setPhrase(new Phrase("% ACH",subHeadfont));
			table2.addCell(tableLeft2_4);

			// Particular
			PdfPCell tableLeft2_11 = new PdfPCell ();
			tableLeft2_11.setColspan (1);
			tableLeft2_11.setHorizontalAlignment (Element.ALIGN_LEFT);
			tableLeft2_11.setNoWrap(true);

			// Target
			PdfPCell tableLeft2_22 = new PdfPCell ();
			tableLeft2_22.setColspan (1);
			tableLeft2_22.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Achievement
			PdfPCell tableLeft2_33 = new PdfPCell ();
			tableLeft2_33.setColspan (1);
			tableLeft2_33.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// %
			PdfPCell tableLeft2_44 = new PdfPCell ();
			tableLeft2_44.setColspan (1);
			tableLeft2_44.setHorizontalAlignment (Element.ALIGN_RIGHT);

			tableLeft2_11.setPhrase(new Phrase("Gross Adds",fontCommon));
			table2.addCell(tableLeft2_11);	       
			tableLeft2_22.setPhrase(new Phrase( String.valueOf(ret.getTargetGrAddMnp()!=null?ret.getTargetGrAddMnp():0) ,fontCommon));
			table2.addCell(tableLeft2_22);
			tableLeft2_33.setPhrase(new Phrase(String.valueOf(ret.getNormalGross()) ,fontCommon));
			table2.addCell(tableLeft2_33);
			tableLeft2_44.setPhrase(new Phrase(String.valueOf(ret.getAchievementPercMnp()!=null?ret.getAchievementPercMnp():0),fontCommon));
			table2.addCell(tableLeft2_44);

			tableLeft2_11.setPhrase(new Phrase("MNP Gross Adds",fontCommon));
			table2.addCell(tableLeft2_11);	       
			tableLeft2_22.setPhrase(new Phrase( String.valueOf(ret.getTargetGrAddNmnp()!=null?ret.getTargetGrAddNmnp():0),fontCommon));
			table2.addCell(tableLeft2_22);
			tableLeft2_33.setPhrase(new Phrase(String.valueOf(ret.getMnpGross()) ,fontCommon));
			table2.addCell(tableLeft2_33);
			tableLeft2_44.setPhrase(new Phrase(String.valueOf(ret.getAchievementPercNmnp()!=null?ret.getAchievementPercNmnp():0),fontCommon));
			table2.addCell(tableLeft2_44);

			bottomTab1.setPhrase(new Phrase("Total Gross Adds",fontCommon));
			table2.addCell(bottomTab1);	       
			bottomTab2.setPhrase(new Phrase( String.valueOf(ret.getTargetGrAddTotal()!=null?ret.getTargetGrAddTotal():0),fontCommon));
			table2.addCell(bottomTab2);
			bottomTab3.setPhrase(new Phrase(String.valueOf(ret.getGrossAct()) ,fontCommon));
			table2.addCell(bottomTab3);
			bottomTab4.setPhrase(new Phrase(String.valueOf(ret.getAchievementPercTotal()!=null?ret.getAchievementPercTotal():0),fontCommon));
			table2.addCell(bottomTab4);

			
			/**
			 * Retailer Table
			 */
			PdfPCell bottomTab11 = new PdfPCell ();
			bottomTab11.setColspan (1);
			bottomTab11.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab11.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell bottomTab12 = new PdfPCell ();
			bottomTab12.setColspan (1);
			bottomTab12.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab12.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab13 = new PdfPCell ();
			bottomTab13.setColspan (1);
			bottomTab13.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab13.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab14 = new PdfPCell ();
			bottomTab14.setColspan (1);
			bottomTab14.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab14.setHorizontalAlignment (Element.ALIGN_RIGHT); 

			PdfPCell bottomTab15 = new PdfPCell ();
			bottomTab15.setColspan (1);
			bottomTab15.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab15.setHorizontalAlignment (Element.ALIGN_RIGHT);


			PdfPCell bottomTab16 = new PdfPCell ();
			bottomTab16.setColspan (1);
			bottomTab16.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab16.setHorizontalAlignment (Element.ALIGN_RIGHT);


			PdfPCell bottomTab17 = new PdfPCell ();
			bottomTab17.setColspan (1);
			bottomTab17.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab17.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPTable table3=new PdfPTable(5);
			table3.setWidthPercentage(100f);
			//table3.setWidths(new float[]{28.0f,8.0f,8.0f,8.0f,8.0f,8.0f,8.0f});
			table3.setWidths(new float[]{28.0f,8.0f,8.0f,8.0f,8.0f});
			table3.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);


			PdfPCell tableLeft3_1 = new PdfPCell ();
			tableLeft3_1.setColspan (1);
			tableLeft3_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_1.setHorizontalAlignment (Element.ALIGN_CENTER);

			PdfPCell targetPayCell = new PdfPCell ();
			targetPayCell.setColspan (1);
			targetPayCell.setBackgroundColor(BaseColor.BLACK);
			targetPayCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			targetPayCell.setBorderColorBottom(BaseColor.WHITE);
			targetPayCell.setBorderWidthBottom(1f);
			targetPayCell.setPhrase(new Phrase("Payouts to Retailer", subHeadfont));

			PdfPCell blankTargetPayCell = new PdfPCell ();
			blankTargetPayCell.setColspan (6);
			blankTargetPayCell.setBorder(0);
			blankTargetPayCell.addElement(new Paragraph(""));

			table3.addCell(targetPayCell);
			table3.addCell(blankTargetPayCell);


			PdfPCell tableLeft3_2 = new PdfPCell ();
			tableLeft3_2.setColspan (1);
			tableLeft3_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_2.setBorderWidthLeft(0.4f);
			tableLeft3_2.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_3 = new PdfPCell ();
			tableLeft3_3.setColspan (1);
			tableLeft3_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_3.setBorderWidthLeft(0.4f);
			tableLeft3_3.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_4 = new PdfPCell ();
			tableLeft3_4.setColspan (1);
			tableLeft3_4.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_4.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_4.setBorderWidthLeft(0.4f);
			tableLeft3_4.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_5 = new PdfPCell ();
			tableLeft3_5.setColspan (1);
			tableLeft3_5.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_5.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_5.setBorderWidthLeft(0.4f);
			tableLeft3_5.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_6 = new PdfPCell ();
			tableLeft3_6.setColspan (1);
			tableLeft3_6.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_6.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_6.setBorderWidthLeft(0.4f);
			tableLeft3_6.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_7 = new PdfPCell ();
			tableLeft3_7.setColspan (1);
			tableLeft3_7.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_7.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_7.setBorderWidthLeft(0.4f);
			tableLeft3_7.setBorderColorLeft(BaseColor.WHITE);


			tableLeft3_1.setPhrase(new Phrase("Particulars ",subHeadfont));
			table3.addCell(tableLeft3_1);	       
			tableLeft3_2.setPhrase(new Phrase("No's ",subHeadfont));
			table3.addCell(tableLeft3_2);
			tableLeft3_7.setPhrase(new Phrase("Unit",subHeadfont));
			table3.addCell(tableLeft3_7);
			tableLeft3_3.setPhrase(new Phrase("Rate ",subHeadfont));
			table3.addCell(tableLeft3_3);
			tableLeft3_4.setPhrase(new Phrase("Payout",subHeadfont));
			table3.addCell(tableLeft3_4);
			/*tableLeft3_5.setPhrase(new Phrase("TDS",subHeadfont));
			table3.addCell(tableLeft3_5);
			tableLeft3_6.setPhrase(new Phrase("Net ",subHeadfont));
			table3.addCell(tableLeft3_6);
*/
			// Particular
			PdfPCell tableLeft3_11 = new PdfPCell ();
			tableLeft3_11.setColspan (1);
			tableLeft3_11.setHorizontalAlignment (Element.ALIGN_MIDDLE);
			tableLeft3_11.setNoWrap(true);

			// No's
			PdfPCell tableLeft3_22 = new PdfPCell ();
			tableLeft3_22.setColspan (1);
			tableLeft3_22.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Rate
			PdfPCell tableLeft3_33 = new PdfPCell ();
			tableLeft3_33.setColspan (1);
			tableLeft3_33.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Payout Gross
			PdfPCell tableLeft3_44 = new PdfPCell ();
			tableLeft3_44.setColspan (1);
			tableLeft3_44.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// TDS@10%
			PdfPCell tableLeft3_55 = new PdfPCell ();
			tableLeft3_55.setColspan (1);
			tableLeft3_55.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Net
			PdfPCell tableLeft3_66 = new PdfPCell ();
			tableLeft3_66.setColspan (1);
			tableLeft3_66.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Mode of Payment
			PdfPCell tableLeft3_77 = new PdfPCell ();
			tableLeft3_77.setColspan (1);
			tableLeft3_77.setHorizontalAlignment (Element.ALIGN_LEFT);

			for (Map.Entry<String, List<RetailerStmtScmList>> mapentry : ret.getRetailerSubMap().entrySet()) {
				String key = mapentry.getKey();
				List<RetailerStmtScmList> values = (List<RetailerStmtScmList>)mapentry.getValue();
				
				if("OTF".equalsIgnoreCase(key)){
					for(RetailerStmtScmList retStmtPojo : values){
						tableLeft3_11.setPhrase(new Phrase(retStmtPojo.getSchemeCompDesc(),fontCommon));
						table3.addCell(tableLeft3_11);	       
						tableLeft3_22.setPhrase(new Phrase(String.valueOf(retStmtPojo.getPaytotal() != null ? retStmtPojo.getPaytotal() : "") ,fontCommon));
						table3.addCell(tableLeft3_22);
						tableLeft3_77.setPhrase(new Phrase(retStmtPojo.getUnit(),fontCommon));
						table3.addCell(tableLeft3_77);
						tableLeft3_33.setPhrase(new Phrase(String.valueOf(retStmtPojo.getRate()!=null?retStmtPojo.getRate():""),fontCommon));
						table3.addCell(tableLeft3_33);
						tableLeft3_44.setPhrase(new Phrase(String.valueOf(retStmtPojo.getGrossPayAmt()!=null? retStmtPojo.getGrossPayAmt() :""),fontCommon));
						table3.addCell(tableLeft3_44);
						//tableLeft3_55.setPhrase(new Phrase(String.valueOf(retStmtPojo.getTdsAmount() != null ? retStmtPojo.getTdsAmount() : "") ,fontCommon));
						//table3.addCell(tableLeft3_55);
						//tableLeft3_66.setPhrase(new Phrase(String.valueOf(retStmtPojo.getNetComm() != null ?retStmtPojo.getNetComm() :"") ,fontCommon));
						//tableLeft3_66.setPhrase(new Phrase(String.valueOf("") ,fontCommon));
						//table3.addCell(tableLeft3_66);
					}
				}else{
					for(RetailerStmtScmList retStmtPojo : values){
						tableLeft3_11.setPhrase(new Phrase(retStmtPojo.getSchemeCompDesc(),fontCommon));
						table3.addCell(tableLeft3_11);	       
						tableLeft3_22.setPhrase(new Phrase(String.valueOf(retStmtPojo.getPaytotal() != null ? retStmtPojo.getPaytotal() : "") ,fontCommon));
						table3.addCell(tableLeft3_22);
						tableLeft3_77.setPhrase(new Phrase(retStmtPojo.getUnit(),fontCommon));
						table3.addCell(tableLeft3_77);
						tableLeft3_33.setPhrase(new Phrase(String.valueOf(retStmtPojo.getRate()!=null?retStmtPojo.getRate():""),fontCommon));
						table3.addCell(tableLeft3_33);
						tableLeft3_44.setPhrase(new Phrase(String.valueOf(retStmtPojo.getGrossPayAmt()!=null? retStmtPojo.getGrossPayAmt() :""),fontCommon));
						table3.addCell(tableLeft3_44);
						//tableLeft3_55.setPhrase(new Phrase(String.valueOf(retStmtPojo.getTdsAmount() != null ? retStmtPojo.getTdsAmount() : "") ,fontCommon));
						//table3.addCell(tableLeft3_55);
						//tableLeft3_66.setPhrase(new Phrase(String.valueOf(retStmtPojo.getNetComm() != null ?retStmtPojo.getNetComm() :"") ,fontCommon));
						//tableLeft3_66.setPhrase(new Phrase(String.valueOf("") ,fontCommon));
						//table3.addCell(tableLeft3_66);
					}
				}
			}
			bottomTab11.setPhrase(new Phrase("Total Payout",fontCommon));
			table3.addCell(bottomTab11);	       
			bottomTab12.setPhrase(new Phrase("" ,fontCommon));//String.valueOf(ret.getTotalNos() != null ? ret.getTotalNos() : "")
			table3.addCell(bottomTab12);
			bottomTab17.setPhrase(new Phrase("",fontCommon)); 
			table3.addCell(bottomTab17);
			bottomTab13.setPhrase(new Phrase("",fontCommon));//String.valueOf(ret.getTotalRate() != null ? ret.getTotalRate() : "")
			table3.addCell(bottomTab13);
			bottomTab14.setPhrase(new Phrase(String.valueOf(ret.getPayoutGross() != null ? ret.getPayoutGross() : ""),fontCommon));
			table3.addCell(bottomTab14);
			/*bottomTab15.setPhrase(new Phrase(String.valueOf(ret.getTotalTds() != null ? ret.getTotalTds() : "") ,fontCommon));
			table3.addCell(bottomTab15);
			bottomTab16.setPhrase(new Phrase(String.valueOf(ret.getTotalNet()!=null ? ret.getTotalNet() : "") ,fontCommon));
			table3.addCell(bottomTab16);
			*/
			/**
			 * Fifth Table Generation
			 */


			PdfPTable table4=new PdfPTable(6);
			table4.setWidthPercentage(100f);
			table4.setWidths(new float[]{10.0f,15.0f,8.0f,8.0f,8.0f,8.0f});
			table4.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			
			PdfPCell tableLeft4_1 = new PdfPCell ();
			tableLeft4_1.setColspan (2);
			tableLeft4_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_1.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell tableLeft4_2 = new PdfPCell ();
			tableLeft4_2.setColspan (2);
			tableLeft4_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_2.setBorderWidthLeft(0.6f);
			tableLeft4_2.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft4_3 = new PdfPCell ();
			tableLeft4_3.setColspan (2);
			tableLeft4_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_3.setBorderWidthLeft(0.4f);
			tableLeft4_3.setBorderColorLeft(BaseColor.WHITE);

			
			tableLeft4_1.setPhrase(new Phrase("Note:",subHeadfont));
			table4.addCell(tableLeft4_1);	       
			tableLeft4_2.setPhrase(new Phrase("Name",subHeadfont));
			table4.addCell(tableLeft4_2);
			tableLeft4_3.setPhrase(new Phrase("Contact Number",subHeadfont));
			table4.addCell(tableLeft4_3);
			
			// Particular
			PdfPCell tableLeft4_11 = new PdfPCell ();
			tableLeft4_11.setColspan (2);
			tableLeft4_11.setHorizontalAlignment (Element.ALIGN_LEFT);
			tableLeft4_11.setNoWrap(true);
			tableLeft4_11.setBackgroundColor(BaseColor.YELLOW);
			
			// No's
			PdfPCell tableLeft4_22 = new PdfPCell ();
			tableLeft4_22.setColspan (2);
			tableLeft4_22.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_22.setBackgroundColor(BaseColor.YELLOW);
			
			// Rate
			PdfPCell tableLeft4_33 = new PdfPCell ();
			tableLeft4_33.setColspan (2);
			tableLeft4_33.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_33.setBackgroundColor(BaseColor.YELLOW);
			
			PdfPCell tableLeft4_44 = new PdfPCell ();
			tableLeft4_44.setColspan (6);
			tableLeft4_44.setHorizontalAlignment (Element.ALIGN_CENTER);

			
			tableLeft4_11.setPhrase(new Phrase("1. Incase of any query please contact your TSM:",fontCommon));
			table4.addCell(tableLeft4_11);
			
			tableLeft4_22.setPhrase(new Phrase(ret.getTsm() ,fontCommon));
			table4.addCell(tableLeft4_22);
			
			tableLeft4_33.setPhrase(new Phrase(ret.getTsmMsisdn(),fontCommon));
			table4.addCell(tableLeft4_33);
			
			tableLeft4_11.setPhrase(new Phrase("2. ASM Incharge:",fontCommon));
			table4.addCell(tableLeft4_11);
			
			tableLeft4_22.setPhrase(new Phrase(ret.getAsm() ,fontCommon));
			table4.addCell(tableLeft4_22);
			
			tableLeft4_33.setPhrase(new Phrase(ret.getAsmMsisdn(),fontCommon));
			table4.addCell(tableLeft4_33);
			
			tableLeft4_11.setPhrase(new Phrase("3. ZBM Incharge:",fontCommon));
			table4.addCell(tableLeft4_11);
			
			tableLeft4_22.setPhrase(new Phrase(ret.getZbm() ,fontCommon));
			table4.addCell(tableLeft4_22);
			
			tableLeft4_33.setPhrase(new Phrase(ret.getZbmMsisdn(),fontCommon));
			table4.addCell(tableLeft4_33);
			
			tableLeft4_44.setPhrase(new Phrase("This is a system generated earning statement, no signature required. It is not to be used for any financial / legal purposes.",fontCommon));
			table4.addCell(tableLeft4_44);
			
			
			/**
			 *  ***********************************************************************************************************			
			 */
			//Now Insert Every Thing Into PDF Document
			document.open();//PDF document opened........       
			document.add(titleTable);
			document.add(Chunk.NEWLINE);
			document.add(Chunk.NEWLINE);
			document.add(new Paragraph(" "));
			document.add(custInfotable);
			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph(" "));
			document.add(table2);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			document.add(new Paragraph(""));
			//document.add(headerTable1);
			document.add(table3);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			document.add(new Paragraph(""));
			//document.add(headerTable2);
			document.add(table4);
			document.close();
			//file.close();
			zip.closeEntry();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}

}

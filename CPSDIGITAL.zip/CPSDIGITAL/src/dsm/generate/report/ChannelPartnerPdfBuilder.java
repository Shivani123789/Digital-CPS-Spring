package dsm.generate.report;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

import dsm.model.DB.PartnerChannelStatementPojo;
import dsm.model.DB.PartnerChannelStmtScmListPojo;

public class ChannelPartnerPdfBuilder  extends AbstractITextPdfView {

/*	private String cpsName =  null;
	private String stmtNo = null;
	private Image imager = null;
*/
	
	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document,
			PdfWriter writer, HttpServletRequest request, HttpServletResponse response)	throws Exception {
		Image imager = null;
		try {
			PartnerChannelStatementPojo cpvo = (PartnerChannelStatementPojo) model.get("channelPartnerList");
			document.setPageSize(PageSize.A4_LANDSCAPE);

			StringBuffer path = new StringBuffer();
			if(request.isSecure()){
				path.append("https://");
			}else{
				path.append("http://");
			}
			path.append(request.getServerName());
			path.append(":");
			path.append(request.getServerPort());
			path.append(request.getContextPath());
			path.append("/resources/images/ideaLogo.jpg");

			try {
				imager = Image.getInstance (new URL(path.toString()));
				imager.scaleAbsolute(50f, 25f);
				imager.setAlignment(Element.ALIGN_LEFT);
				imager.setBorder(0);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			//PDF Heading
			Font fontTB11 = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontTB11.setColor(BaseColor.BLACK);
			fontTB11.setSize(11);

			Font fontTB9 = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontTB9.setColor(BaseColor.BLACK);
			fontTB9.setSize(9);

			Font fontTB6 = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontTB6.setColor(BaseColor.BLACK);
			fontTB6.setSize(6);

			Font fontTB8 = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontTB8.setColor(BaseColor.BLACK);
			fontTB8.setSize(7);	  

			Font fontTR8 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
			fontTR8.setColor(BaseColor.BLACK);
			fontTR8.setSize(8);

			Font fontTB4 = FontFactory.getFont(FontFactory.defaultEncoding);
			fontTB4.setColor(BaseColor.BLACK);
			fontTB4.setSize(7);
			
			
			//Image and Header 
	        PdfPTable titleTable = new PdfPTable(2);
			titleTable.setWidthPercentage(100f);
			titleTable.setWidths(new float[] {2.9f,20.0f});
			
			PdfPCell imageHead = new PdfPCell ();
			imageHead.setColspan (1);
			imageHead.setRowspan(1);
			imageHead.setBorder(0);
			imageHead.setHorizontalAlignment (Element.ALIGN_LEFT);
			imageHead.addElement(imager);

			titleTable.addCell(imageHead);

			PdfPCell header = new PdfPCell ();
			header.setColspan (1);
			header.setRowspan(1);
			header.disableBorderSide(0);
			header.setBorder(0);
			header.setPaddingRight(2);
			header.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			header.setPhrase(new Phrase("Statement Summary", fontTB11));
			titleTable.addCell(header);

			header.setColspan (2);
			header.setHorizontalAlignment(Element.ALIGN_LEFT);
			header.setPhrase(new Phrase("", fontTR8));
			titleTable.addCell(header);
			
			// address
			
			PdfPTable cpDetailTable = new PdfPTable(2);
			cpDetailTable.setWidthPercentage(100f);
			cpDetailTable.setWidths(new float[]{1.5f,2.5f});
			cpDetailTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell leftCell = new PdfPCell ();
			leftCell.setColspan (1);
			leftCell.setNoWrap(true);
			leftCell.disableBorderSide(0);
			leftCell.setBorder(0);
			//leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
			leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			PdfPCell cpvoCell = new PdfPCell ();
			cpvoCell.setColspan (1);
			cpvoCell.disableBorderSide(0);
			cpvoCell.setBorder(0);
			cpvoCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			leftCell.setPhrase(new Phrase("Name of Partner", fontTB8));
			cpDetailTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getCpName(), fontTB4));
			cpDetailTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("Address", fontTB8));
			cpDetailTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getAddress(), fontTB4));
			cpDetailTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("Country", fontTB8));
			cpDetailTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getCountry(), fontTB4));
			cpDetailTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("PAN", fontTB8));
			cpDetailTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getPanNo(), fontTB4));
			cpDetailTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("STR No./GSTR No.", fontTB8));
			cpDetailTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getStrNo(), fontTB4));
			cpDetailTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("Partner ID", fontTB8));
			cpDetailTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getCpId(), fontTB4));
			cpDetailTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("Partner Type", fontTB8));
			cpDetailTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getPartnerType(), fontTB4));
			cpDetailTable.addCell(cpvoCell);
			
			
			
			PdfPTable cpDetailRightTable = new PdfPTable(2);
			cpDetailRightTable.setWidthPercentage(100f);
			cpDetailRightTable.setWidths(new float[]{1.5f,3.0f});
			cpDetailRightTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
			
			leftCell.setPhrase(new Phrase("Statement No", fontTB8));
			cpDetailRightTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getStmtNo(), fontTB4));
			cpDetailRightTable.addCell(cpvoCell);
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMMMM-yyyy");
			
			leftCell.setPhrase(new Phrase("Date of statement", fontTB8));
			cpDetailRightTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(formatter.format(new Date()), fontTB4));
			cpDetailRightTable.addCell(cpvoCell);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			int year = cal.get(Calendar.YEAR);
			
			leftCell.setPhrase(new Phrase("Traffic Month", fontTB8));
			cpDetailRightTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getStmtDt()!=null ? cpvo.getStmtDt().substring(3):"", fontTB4));
			cpDetailRightTable.addCell(cpvoCell);
			
			String appName = cpvo.getApplicationName();
			String[] result = appName.split("/");
			
			leftCell.setPhrase(new Phrase("App Name", fontTB8));
			cpDetailRightTable.addCell(leftCell);
			if(result.length != 1 && result[0].equalsIgnoreCase(result[1])){
				cpvoCell.setPhrase(new Phrase(result[0], fontTB4));	
			}else{
				cpvoCell.setPhrase(new Phrase(cpvo.getApplicationName(), fontTB4));
			}
			
			cpDetailRightTable.addCell(cpvoCell);
			
			
			// table combo
			PdfPTable infoTable = new PdfPTable(3);
			infoTable.setWidthPercentage(100f);
			infoTable.setWidths(new float[]{20.0f,10.0f,20.0f});
			infoTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
			infoTable.getDefaultCell().setBorder(0);
			
			//leftCell.addElement(cpDetailTable);
			infoTable.addCell(cpDetailTable);
			leftCell.setPhrase(new Phrase(" ", fontTB8));
			infoTable.addCell(leftCell);
			//leftCell.addElement(cpDetailRightTable);
			infoTable.addCell(cpDetailRightTable);
			
			
			PdfPTable cptable1 = new PdfPTable(9);
			cptable1.setWidthPercentage(100f);
			cptable1.setWidths(new float[] {10.0f,30.0f,20.0f,20.0f,20.0f,20.0f,20.0f,20.0f,20.0f});
			
			leftCell.setColspan (1);
			leftCell.setNoWrap(true);
			leftCell.disableBorderSide(0);
			leftCell.setBorder(0);
			leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
			leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			PdfPCell rightCell = new PdfPCell ();
			rightCell.setColspan (1);
			rightCell.setNoWrap(true);
			rightCell.disableBorderSide(0);
			rightCell.setBorder(0);
			rightCell.setBackgroundColor (new BaseColor (193, 193, 193));
			rightCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			
			leftCell.setPhrase(new Phrase("Circle", fontTB8));
			cptable1.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Model Name", fontTB8));
			cptable1.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Service type", fontTB8));
			cptable1.addCell(leftCell);	       
			
			rightCell.setPhrase(new Phrase("Gross Revenue", fontTB8));
			cptable1.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Deductions", fontTB8));
			cptable1.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Net Revenue", fontTB8));
			cptable1.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Usage %", fontTB8));
			cptable1.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Rev Share %", fontTB8));
			cptable1.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Rev Share (Rs.)", fontTB8));
			cptable1.addCell(rightCell);	       
			
			
			
			PdfPTable cptable = new PdfPTable(9);
			cptable.setWidthPercentage(100f);
			cptable.setWidths(new float[] {10.0f,30.0f,20.0f,20.0f,20.0f,20.0f,20.0f,20.0f,20.0f});
			
			
			
//			PdfPCell leftCell = new PdfPCell ();
			leftCell.setColspan (1);
			leftCell.setNoWrap(true);
			leftCell.disableBorderSide(0);
			leftCell.setBorder(0);
			leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
			leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			
	//		PdfPCell cpvoCell = new PdfPCell ();
			cpvoCell.setColspan (1);
			cpvoCell.disableBorderSide(0);
			cpvoCell.setBorder(0);
			cpvoCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell cpvoTotCell = new PdfPCell ();
			cpvoTotCell.setColspan (1);
			cpvoTotCell.disableBorderSide(0);
			cpvoTotCell.setBorder(0);
			cpvoTotCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			PdfPCell circlewiseCell = new PdfPCell ();
			circlewiseCell.setColspan (8);
			circlewiseCell.setNoWrap(true);
			circlewiseCell.disableBorderSide(0);
			circlewiseCell.setBorder(0);
			circlewiseCell.setBackgroundColor (new BaseColor (193, 193, 193));
			circlewiseCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			PdfPCell amtWordsCell = new PdfPCell ();
			amtWordsCell.setColspan (9);
			amtWordsCell.setNoWrap(true);
			amtWordsCell.disableBorderSide(0);
			amtWordsCell.setBorder(0);
			//amtWordsCell.setBackgroundColor (new BaseColor (193, 193, 193));
			amtWordsCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			
			//titleTable
			
			PdfPCell leftCell420 = new PdfPCell ();
			leftCell420.setColspan(9);
			leftCell420.setRowspan(1);
			leftCell420.setNoWrap(true);
			leftCell420.disableBorderSide(0);
			leftCell420.setBorder(0);
			leftCell420.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			
			PdfPCell circleTotalCell = new PdfPCell ();
			circleTotalCell.setColspan (1);
			circleTotalCell.setNoWrap(true);
			circleTotalCell.disableBorderSide(0);
			circleTotalCell.setBorder(0);
			circleTotalCell.setBackgroundColor (new BaseColor (193, 193, 193));
			circleTotalCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			leftCell420.addElement(titleTable);
			cptable.addCell(leftCell420);
			
			leftCell.setPhrase(new Phrase("Circle", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Model Name", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Service type", fontTB8));
			cptable.addCell(leftCell);	       

			rightCell.setPhrase(new Phrase("Gross Revenue", fontTB8));
			cptable.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Deductions", fontTB8));
			cptable.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Net Revenue", fontTB8));
			cptable.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Usage %", fontTB8));
			cptable.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Rev Share %", fontTB8));
			cptable.addCell(rightCell);	       
			
			rightCell.setPhrase(new Phrase("Rev Share (Rs.)", fontTB8));
			cptable.addCell(rightCell);
			
			cptable.setHeaderRows(2);
	      //  cptable.setFooterRows(1);
	        
	        cptable.setSkipFirstHeader(true);
	        //cptable.setSkipLastFooter(true);

			
			boolean multiFlag = false;
			BigDecimal subTotal = null;
			if(cpvo != null && cpvo.getMonthScmList() != null &&  cpvo.getMonthScmList().size() > 0){
				int size = cpvo.getMonthScmList().size();
				int i = 0;
				String circle = null;
				boolean flag = true;
				
				for(PartnerChannelStmtScmListPojo pcstscmlist : cpvo.getMonthScmList()){
					
					if(flag){
						flag = false;
						circle = pcstscmlist.getCircle();
						subTotal = pcstscmlist.getSubTotal();
					}
					
					if(i != size && !circle.equalsIgnoreCase(pcstscmlist.getCircle())){
						circle = pcstscmlist.getCircle();
						multiFlag = true;
						circlewiseCell.setPhrase(new Phrase("Circlewise Sub Total", fontTB8));
						cptable.addCell(circlewiseCell);
						circleTotalCell.setPhrase(new Phrase(String.valueOf(subTotal!=null ? subTotal : 0), fontTR8));
						cptable.addCell(circleTotalCell);
						subTotal = pcstscmlist.getSubTotal();
					}
					cpvoCell.setPhrase(new Phrase(pcstscmlist.getCircle(), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(pcstscmlist.getModelName(), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(pcstscmlist.getServiceType(), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoTotCell.setPhrase(new Phrase(String.valueOf( pcstscmlist.getGrossRevenue()!=null ? pcstscmlist.getGrossRevenue() : 0), fontTR8));
					cptable.addCell(cpvoTotCell);

					cpvoTotCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getTotalDeduction()!=null ? pcstscmlist.getTotalDeduction() : 0), fontTR8));
					cptable.addCell(cpvoTotCell);

					cpvoTotCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getNetRevenue()!=null ? pcstscmlist.getNetRevenue() : 0), fontTR8));
					cptable.addCell(cpvoTotCell);

					cpvoTotCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getUsagesPercent()!=null ? pcstscmlist.getUsagesPercent() : 0), fontTR8));
					cptable.addCell(cpvoTotCell);

					cpvoTotCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getRevenueSharePercent()!=null ? pcstscmlist.getRevenueSharePercent() : 0), fontTR8));
					cptable.addCell(cpvoTotCell);

					cpvoTotCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getRevenueShare()!=null ? pcstscmlist.getRevenueShare() : 0), fontTR8));
					cptable.addCell(cpvoTotCell);

					i++;
					if(i == size && ((!circle.equalsIgnoreCase(pcstscmlist.getCircle()) || multiFlag))){
						circlewiseCell.setPhrase(new Phrase("Circlewise Sub Total", fontTB8));
						cptable.addCell(circlewiseCell);
						circleTotalCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getSubTotal()!=null ? pcstscmlist.getSubTotal() : 0), fontTR8));
						cptable.addCell(circleTotalCell);
						
						circlewiseCell.setPhrase(new Phrase("Total", fontTB8));
						cptable.addCell(circlewiseCell);
						circleTotalCell.setPhrase(new Phrase(String.valueOf(cpvo.getGrandTotal() != null ? cpvo.getGrandTotal() : 0), fontTR8));
						cptable.addCell(circleTotalCell);

					}else if(i == size && circle.equalsIgnoreCase(pcstscmlist.getCircle())){
						circlewiseCell.setPhrase(new Phrase("Total", fontTB8));
						cptable.addCell(circlewiseCell);
						circleTotalCell.setPhrase(new Phrase(String.valueOf(cpvo.getGrandTotal() != null ? cpvo.getGrandTotal() : 0), fontTR8));
						cptable.addCell(circleTotalCell);
					}
				}
			}
			
			amtWordsCell.setPhrase(new Phrase(cpvo.getAmtWords(), fontTB8));
			cptable.addCell(amtWordsCell);

			PdfPTable bankInfoTable = new PdfPTable(2);
			bankInfoTable.setWidthPercentage(100f);
			bankInfoTable.setWidths(new float[]{1.5f,8.0f});
			bankInfoTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
			
			PdfPCell leftCellBkInfo = new PdfPCell ();
			leftCellBkInfo.setColspan (1);
			leftCellBkInfo.setNoWrap(true);
			leftCellBkInfo.disableBorderSide(0);
			leftCellBkInfo.setBorder(0);
			leftCellBkInfo.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			leftCellBkInfo.setPhrase(new Phrase("Bank Name", fontTB8));
			bankInfoTable.addCell(leftCellBkInfo);
			cpvoCell.setPhrase(new Phrase(cpvo.getBankName(), fontTR8));
			bankInfoTable.addCell(cpvoCell);
			
			leftCellBkInfo.setPhrase(new Phrase("Bank Account no.", fontTB8));
			bankInfoTable.addCell(leftCellBkInfo);
			cpvoCell.setPhrase(new Phrase(cpvo.getAccountNo(), fontTR8));
			bankInfoTable.addCell(cpvoCell);
			
			leftCellBkInfo.setPhrase(new Phrase("Bank Branch", fontTB8));
			bankInfoTable.addCell(leftCellBkInfo);
			cpvoCell.setPhrase(new Phrase(cpvo.getBankBranch(), fontTR8));
			bankInfoTable.addCell(cpvoCell);
			
			leftCellBkInfo.setPhrase(new Phrase("IFSC/RTGS Code", fontTB8));
			bankInfoTable.addCell(leftCellBkInfo);
			cpvoCell.setPhrase(new Phrase(cpvo.getIfscCode(), fontTR8));
			bankInfoTable.addCell(cpvoCell);

			
			
			//Now Insert Every Thing Into PDF Document
			document.open();
			document.add(titleTable);
			document.add(Chunk.NEWLINE);
			document.add(infoTable);
			document.add(Chunk.NEWLINE);
			document.add(Chunk.NEWLINE);
			document.add(cptable1);
			document.add(cptable); 
			document.add(Chunk.NEWLINE); 
			document.add(Chunk.NEWLINE); 
			document.add(Chunk.NEWLINE); 
			//document.add(new Paragraph(cpvo.getAmtWords(), fontTB8));
			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph("* Taxes be applied as per statute in force", fontTB8));
			document.add(Chunk.NEWLINE); 
			//document.add(new Paragraph(" Partner Bank details", fontTB8));
			//document.add(Chunk.NEWLINE); 
			//document.add(bankInfoTable);
			document.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		
	}
	
	
	private String month(int month){
		String result = null;
		switch(month){
		case 0: result= "JAN";
		break;
		case 1: result= "FEB";
		break;
		case 2: result= "MAR";
		break;
		case 3: result= "APR";
		break;
		case 4: result= "MAY";
		break;
		case 5: result= "JUN";
		break;
		case 6: result= "JUL";
		break;
		case 7: result= "AUG";
		break;
		case 8: result= "SEP";
		break;
		case 9: result= "OCT";
		break;
		case 10: result= "NOV";
		break;
		case 11: result= "DEC";
		break;
		}
		return result;
	}
		
	//@Override
	/*protected void buildPdfDocument420(Map<String, Object> model, Document document,
			PdfWriter writer, HttpServletRequest request, HttpServletResponse response)	throws Exception {
		try {

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMMMM-yyyy  HH:mm:ss ");
			PartnerChannelStatementPojo cpvo = (PartnerChannelStatementPojo) model.get("channelPartnerList");
			
			document.setPageSize(PageSize.A4_LANDSCAPE);

			StringBuffer path = new StringBuffer();
			if(request.isSecure()){
				path.append("https://");
			}else{
				path.append("http://");
			}
			path.append(request.getServerName());
			path.append(":");
			path.append(request.getServerPort());
			path.append(request.getContextPath());
			path.append("/resources/images/ideaLogo.jpg");

			//Image imager=null;
			try {
				imager = Image.getInstance (new URL(path.toString()));
				imager.scaleAbsolute(50f, 25f);
				imager.setAlignment(Element.ALIGN_LEFT);
				imager.setBorder(0);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			//PDF Heading
			Font fontTB9 = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontTB9.setColor(BaseColor.BLACK);
			fontTB9.setSize(9);

			Font fontTB6 = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontTB6.setColor(BaseColor.BLACK);
			fontTB6.setSize(6);

			Font fontTB8 = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontTB8.setColor(BaseColor.BLACK);
			fontTB8.setSize(8);	  

			Font fontTR8 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
			fontTR8.setColor(BaseColor.BLACK);
			fontTR8.setSize(8);

			//Image and Header 
	        PdfPTable titleTable = new PdfPTable(2);
			titleTable.setWidthPercentage(100f);
			titleTable.setWidths(new float[] {2.9f,20.0f});
			
			PdfPCell imageHead = new PdfPCell ();
			imageHead.setColspan (1);
			imageHead.setRowspan(1);
			imageHead.setBorder(0);
			imageHead.setHorizontalAlignment (Element.ALIGN_LEFT);
			imageHead.addElement(imager);

			titleTable.addCell(imageHead);

			PdfPCell header = new PdfPCell ();
			header.setColspan (1);
			header.setRowspan(1);
			header.disableBorderSide(0);
			header.setBorder(0);
			header.setPaddingRight(2);
			header.setHorizontalAlignment(Element.ALIGN_CENTER);
			
			header.setPhrase(new Phrase("Statement Summary", fontTB9));
			titleTable.addCell(header);

			header.setColspan (2);
			header.setHorizontalAlignment(Element.ALIGN_LEFT);
			header.setPhrase(new Phrase("STATEMENT", fontTB8));
			titleTable.addCell(header);
			
			
			PdfPTable cptable = new PdfPTable(9);
			cptable.setWidthPercentage(100f);
			cptable.setWidths(new float[] {10.0f,30.0f,20.0f,20.0f,20.0f,20.0f,20.0f,20.0f,20.0f});
			
			PdfPCell leftCell = new PdfPCell ();
			leftCell.setColspan (1);
			leftCell.setNoWrap(true);
			leftCell.disableBorderSide(0);
			leftCell.setBorder(0);
			leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
			leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			
			PdfPCell cpvoCell = new PdfPCell ();
			cpvoCell.setColspan (1);
			cpvoCell.disableBorderSide(0);
			cpvoCell.setBorder(0);
			cpvoCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell cpvoTotCell = new PdfPCell ();
			cpvoTotCell.setColspan (1);
			cpvoTotCell.disableBorderSide(0);
			cpvoTotCell.setBorder(0);
			cpvoTotCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			PdfPCell circlewiseCell = new PdfPCell ();
			circlewiseCell.setColspan (8);
			circlewiseCell.setNoWrap(true);
			circlewiseCell.disableBorderSide(0);
			circlewiseCell.setBorder(0);
			circlewiseCell.setBackgroundColor (new BaseColor (193, 193, 193));
			circlewiseCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			PdfPCell amtWordsCell = new PdfPCell ();
			amtWordsCell.setColspan (9);
			amtWordsCell.setNoWrap(true);
			amtWordsCell.disableBorderSide(0);
			amtWordsCell.setBorder(0);
			amtWordsCell.setBackgroundColor (new BaseColor (193, 193, 193));
			amtWordsCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			
			PdfPCell circleTotalCell = new PdfPCell ();
			circleTotalCell.setColspan (1);
			circleTotalCell.setNoWrap(true);
			circleTotalCell.disableBorderSide(0);
			circleTotalCell.setBorder(0);
			circleTotalCell.setBackgroundColor (new BaseColor (193, 193, 193));
			circleTotalCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			
			
			
			leftCell.setPhrase(new Phrase("Circle", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Model Name", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Gross Revenue", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Deductions", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Net Revenue", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Service type", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Usage %", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Rev Share %", fontTB8));
			cptable.addCell(leftCell);	       
			
			leftCell.setPhrase(new Phrase("Rev Share (Rs.)", fontTB8));
			cptable.addCell(leftCell);	       
			
			boolean multiFlag = false;
			BigDecimal subTotal = null;
			if(cpvo != null && cpvo.getMonthScmList() != null &&  cpvo.getMonthScmList().size() > 0){
				int size = cpvo.getMonthScmList().size();
				int i = 0;
				String circle = null;
				boolean flag = true;
				
				for(PartnerChannelStmtScmListPojo pcstscmlist : cpvo.getMonthScmList()){
					
					if(flag){
						flag = false;
						circle = pcstscmlist.getCircle();
						subTotal = pcstscmlist.getSubTotal();
					}
					
					if(i != size && !circle.equalsIgnoreCase(pcstscmlist.getCircle())){
						circle = pcstscmlist.getCircle();
						multiFlag = true;
						circlewiseCell.setPhrase(new Phrase("Circlewise Sub Total", fontTB8));
						cptable.addCell(circlewiseCell);
						circleTotalCell.setPhrase(new Phrase(String.valueOf(subTotal!=null ? subTotal : 0), fontTR8));
						cptable.addCell(circleTotalCell);
						subTotal = pcstscmlist.getSubTotal();
					}
					cpvoCell.setPhrase(new Phrase(pcstscmlist.getCircle(), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(pcstscmlist.getModelName(), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(String.valueOf( pcstscmlist.getGrossRevenue()!=null ? pcstscmlist.getGrossRevenue() : 0), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getTotalDeduction()!=null ? pcstscmlist.getTotalDeduction() : 0), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getNetRevenue()!=null ? pcstscmlist.getNetRevenue() : 0), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(pcstscmlist.getServiceType(), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getUsagesPercent()!=null ? pcstscmlist.getUsagesPercent() : 0), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getRevenueSharePercent()!=null ? pcstscmlist.getRevenueSharePercent() : 0), fontTR8));
					cptable.addCell(cpvoCell);

					cpvoTotCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getRevenueShare()!=null ? pcstscmlist.getRevenueShare() : 0), fontTR8));
					cptable.addCell(cpvoTotCell);

					i++;
					if(i == size && ((!circle.equalsIgnoreCase(pcstscmlist.getCircle()) || multiFlag))){
						circlewiseCell.setPhrase(new Phrase("Circlewise Sub Total", fontTB8));
						cptable.addCell(circlewiseCell);
						circleTotalCell.setPhrase(new Phrase(String.valueOf(pcstscmlist.getSubTotal()!=null ? pcstscmlist.getSubTotal() : 0), fontTR8));
						cptable.addCell(circleTotalCell);
						
						circlewiseCell.setPhrase(new Phrase("Total", fontTB8));
						cptable.addCell(circlewiseCell);
						circleTotalCell.setPhrase(new Phrase(String.valueOf(cpvo.getGrandTotal() != null ? cpvo.getGrandTotal() : 0), fontTR8));
						cptable.addCell(circleTotalCell);

					}else if(i == size && circle.equalsIgnoreCase(pcstscmlist.getCircle())){
						circlewiseCell.setPhrase(new Phrase("Total", fontTB8));
						cptable.addCell(circlewiseCell);
						circleTotalCell.setPhrase(new Phrase(String.valueOf(cpvo.getGrandTotal() != null ? cpvo.getGrandTotal() : 0), fontTR8));
						cptable.addCell(circleTotalCell);
					}
				}
			}
			
			amtWordsCell.setPhrase(new Phrase(cpvo.getAmtWords(), fontTB8));
			cptable.addCell(amtWordsCell);
			
			PdfPTable bankInfoTable = new PdfPTable(2);
			bankInfoTable.setWidthPercentage(100f);
			bankInfoTable.setWidths(new float[]{1.5f,8.0f});
			bankInfoTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
			
			leftCell.setPhrase(new Phrase("Bank Name", fontTB8));
			bankInfoTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getBankName(), fontTR8));
			bankInfoTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("Bank Account no.", fontTB8));
			bankInfoTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getAccountNo(), fontTR8));
			bankInfoTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("Bank Branch", fontTB8));
			bankInfoTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getBankBranch(), fontTR8));
			bankInfoTable.addCell(cpvoCell);
			
			leftCell.setPhrase(new Phrase("IFSC/RTGS Code", fontTB8));
			bankInfoTable.addCell(leftCell);
			cpvoCell.setPhrase(new Phrase(cpvo.getIfscCode(), fontTR8));
			bankInfoTable.addCell(cpvoCell);
			
			//ChannelPartnerPdfBuilder.HeaderTable event = new ChannelPartnerPdfBuilder.HeaderTable();
			
			//writer.setPageEvent(event);
			//Now Insert Every Thing Into PDF Document
			
			PdfPTable titleTable = new PdfPTable(2);
			titleTable.setWidthPercentage(100f);
			titleTable.setWidths(new float[] {2.9f,20.0f});

			PdfPCell imageHead = new PdfPCell ();
			imageHead.setColspan (1);
			imageHead.setRowspan(2);
			imageHead.setBorder(0);
			imageHead.setHorizontalAlignment (Element.ALIGN_LEFT);
			imageHead.addElement(imager);

			titleTable.addCell(imageHead);

			PdfPCell header = new PdfPCell ();
			header.setColspan (1);
			header.setRowspan(2);
			header.disableBorderSide(0);
			header.setBorder(0);
			header.setHorizontalAlignment(Element.ALIGN_LEFT);
			
			header.setPhrase(new Phrase("Statement Summary", fontTB8));
			titleTable.addCell(header);
			
			document.open();
			document.add(titleTable);
			document.add(Chunk.NEWLINE); 
			document.add(cptable); 
			document.add(Chunk.NEWLINE); 
			document.add(Chunk.NEWLINE); 
			document.add(Chunk.NEWLINE); 
			//document.add(new Paragraph(cpvo.getAmtWords(), fontTB8));
			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph("* Taxes be applied as per statute in force", fontTB8));
			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph("Partner Bank details", fontTB8));
			document.add(Chunk.NEWLINE); 
			document.add(bankInfoTable);
			document.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public class HeaderTable extends PdfPageEventHelper {
		protected PdfPTable table;
		protected float tableHeight;

		public HeaderTable() {
			try{
				
				table = new PdfPTable(9);
				table.setWidthPercentage(100f);
				table.setTotalWidth(523);//523
				table.setSkipFirstHeader(true);
				table.setWidths(new float[] {10.0f,30.0f,20.0f,20.0f,20.0f,20.0f,20.0f,20.0f,20.0f});

				Font fontTR8 = FontFactory.getFont(FontFactory.TIMES_ROMAN);
				fontTR8.setColor(BaseColor.BLACK);
				fontTR8.setSize(8);
				
				PdfPCell leftCell = new PdfPCell ();
				leftCell.setColspan (1);
				leftCell.setNoWrap(true);
				leftCell.disableBorderSide(0);
				leftCell.setBorder(0);
				leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
				leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);
				
				PdfPCell imageHead = new PdfPCell ();
				imageHead.setColspan (2);
				imageHead.setRowspan(1);
				imageHead.disableBorderSide(0);
				imageHead.setBorder(0);
				imageHead.setHorizontalAlignment (Element.ALIGN_LEFT);
				imageHead.addElement(imager);
				
				
				
	            leftCell.setColspan (1);
				leftCell.setNoWrap(true);
				leftCell.disableBorderSide(0);
				leftCell.setBorder(0);
				leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
				leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);
				
				Font fontTB8 = FontFactory.getFont(FontFactory.TIMES_BOLD);
				fontTB8.setColor(BaseColor.BLACK);
				fontTB8.setSize(8);
				
				PdfPCell headCell = new PdfPCell ();
				headCell.setColspan (7);
				headCell.disableBorderSide(0);
				headCell.setBorder(0);
				headCell.setHorizontalAlignment (Element.ALIGN_LEFT);

				headCell.setPhrase(new Phrase("Statement Detail", fontTB8));
	            table.addCell(headCell);
	            table.addCell(imageHead);

	            
	            //Statement No
				
				leftCell.setPhrase(new Phrase("Circle", fontTB8));
				table.addCell(leftCell);	       
				
				leftCell.setPhrase(new Phrase("Model Name", fontTB8));
				table.addCell(leftCell);	       
				
				leftCell.setPhrase(new Phrase("Gross Revenue", fontTB8));
				table.addCell(leftCell);	       
				
				leftCell.setPhrase(new Phrase("Deductions", fontTB8));
				table.addCell(leftCell);	       
				
				leftCell.setPhrase(new Phrase("Net Revenue", fontTB8));
				table.addCell(leftCell);	       
				
				leftCell.setPhrase(new Phrase("Service type", fontTB8));
				table.addCell(leftCell);	       
				
				leftCell.setPhrase(new Phrase("Usage %", fontTB8));
				table.addCell(leftCell);	       
				
				leftCell.setPhrase(new Phrase("Rev Share %", fontTB8));
				table.addCell(leftCell);	       
				
				leftCell.setPhrase(new Phrase("Rev Share (Rs.)", fontTB8));
				table.addCell(leftCell);	       

				
				
				tableHeight = table.getTotalHeight();
			}catch(DocumentException de){
				de.printStackTrace();
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		public float getTableHeight() {
			return tableHeight;
		}

		public void onEndPage(PdfWriter writer, Document document) {
			table.writeSelectedRows(0, -1, document.left(),	document.top() + ((document.topMargin() + tableHeight) / 2), writer.getDirectContent());
		}
	}
*/}

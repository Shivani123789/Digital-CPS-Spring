package dsm.generate.report;


import java.util.Locale;
 
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;

public class PdfViewResolver implements ViewResolver{
 
    @Override
    public View resolveViewName(String viewName, Locale locale) throws Exception {
    	
    	if("pdfView".equalsIgnoreCase(viewName)){
    		PDFBuilder view = new PDFBuilder();
    		return view;
    	}else if("distPdfView".equalsIgnoreCase(viewName)){
    		//DistributorPdfBuilder dpb = new DistributorPdfBuilder();
    		ChannelPartnerPdfBuilder dpb = new ChannelPartnerPdfBuilder();
    		return dpb;
    	}
  		return null;
      }
    
}

package dsm.generate.report;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

import dsm.model.DB.ShellScriptPojo;


public class ExecuteShellScript {
	
	private static final String KEY_VALUE_SHELLSCRIPT = "dlp_data_extract.sh";
	
	public  synchronized String callShellScript(ShellScriptPojo shellScript) throws Exception{
		Process p =null;
		try {
			String path	= new File(System.getProperty("SCHEME_STUDIO_SHELLSCRIPT_PATH"),KEY_VALUE_SHELLSCRIPT).getPath();

			System.out.println("Script Path :: "+path+" full type :" +shellScript.getType()+" cid: "+ shellScript.getCircleId()+" schId :"+ shellScript.getSchemeId()+" compId :"+shellScript.getCompId()+" condId :"+shellScript.getConditionId()+" qty :"+shellScript.getQualityType()+" pid :"+shellScript.getPaymentId()+" uid :"+shellScript.getUniverseId()+" stdt :"+shellScript.getStartDt()+" edt :"+ shellScript.getEndDt());
			
			ProcessBuilder pb = new ProcessBuilder();
			
			pb.command(path, shellScript.getType(), shellScript.getCircleId(), shellScript.getSchemeId(), shellScript.getCompId(), shellScript.getConditionId(), shellScript.getQualityType(), shellScript.getPaymentId(), shellScript.getUniverseId(), shellScript.getStartDt(), shellScript.getEndDt());
			
			//ProcessBuilder pb = new ProcessBuilder(path1, "TQ", "3", "1531", "1", "1", "1", "0", "0", "null", "null"); // static test
			
			//System.out.println(" Before Script Call ***************** ");
			 p = pb.start();
			//System.out.println("After start ***************** ");
			
			/*synchronized (p) {
				//Success log
				InputStream is = p.getInputStream();
				int i=0;
				StringBuffer sb = new StringBuffer();
				while((i=is.read())!=-1)
				sb.append((char)i);
				System.out.println("Script log ::: "+sb.toString()+" \t conatins Time taken to zip :: "+"Time taken to zip".contains(sb));
				
				
				//error log
				InputStream ise = p.getErrorStream();
				int j=0;
				StringBuffer sbe = new StringBuffer();
				while((j=ise.read())!=-1)
				sbe.append((char)j);
				System.err.println("Script log Error :::: "+sbe.toString());
					
			}*/
			
				//exit process
				Thread.sleep(10000);
				if(p != null)
					p.destroy();
				p.waitFor();
				int exitVal = p.exitValue();
				
				//System.out.println("exitVal :::: "+exitVal+"   ::  process ::: "+p);
				
				if(exitVal == 0){
					return "Successfully Executed";
				}else{
					return "Successfully Executed";
				}	
			
			
		}catch(IllegalThreadStateException e){
			//e.printStackTrace();
			return "Extract process is running background.";
		}
		catch (IOException e) {
			e.printStackTrace();
			return "Failed Execution Please try After Some Time.";
		}catch (Exception e) {
			e.printStackTrace();
			return "Failed Execution Please try After Some Time.";
		}finally{
			try {
				Thread.sleep(500);
				if(p != null)
					p.destroy();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//return null;
	}
}

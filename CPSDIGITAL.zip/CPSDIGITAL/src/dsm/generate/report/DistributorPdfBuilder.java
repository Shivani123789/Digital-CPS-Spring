package dsm.generate.report;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import dsm.model.DB.DistributorRetSchmPojo;
import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.DistributorStmtSchmPojo;

public class DistributorPdfBuilder  extends AbstractITextPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document document,
			PdfWriter writer, HttpServletRequest request, HttpServletResponse response)
	throws Exception {


		try {
			response.setContentType("application/pdf");
			
			DistributorStatementPojo distVo = (DistributorStatementPojo) model.get("distributorList");
			
			response.setHeader("Content-Disposition","attachment;filename="+distVo.getDistDsm2Id()+"_System_Generated.pdf");
			
			document.setPageSize(PageSize.A4);
			
			/*StringBuffer path = new StringBuffer();
			path.append("https://");
			path.append(request.getServerName());
			path.append(":");
			path.append(request.getServerPort());
			path.append(request.getContextPath());
			path.append("/resources/images/ideaLogo.jpg");
			*/
			StringBuffer path = new StringBuffer(System.getProperty("SCHEME_STUDIO_CONFIG_PATH")+"Images/ideaLogo.jpg");
			Image imager=null;
			try {
				//imager = Image.getInstance (new URL(path.toString()));
				imager = Image.getInstance ((path.toString()));
				//imager.scaleToFit(60f, 30f);//image width,height
				imager.scaleAbsolute(50f, 25f);
				imager.setAlignment(Element.ALIGN_LEFT);
				imager.setBorder(0);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			//PDF Heading
			Font titlefont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			titlefont.setColor(BaseColor.WHITE);
			titlefont.setSize(9);

			Font curDatefont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			curDatefont.setColor(BaseColor.BLACK);
			curDatefont.setSize(6);

			Font fontCommon = FontFactory.getFont(FontFactory.TIMES_BOLD);
			fontCommon.setColor(BaseColor.BLACK);
			fontCommon.setSize(8);	  
			// fontCommon.setStyle(2);

			Font subHeadfont = FontFactory.getFont(FontFactory.TIMES_BOLD);
			subHeadfont.setColor(BaseColor.WHITE);
			subHeadfont.setSize(8);	  

			Font notefont = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
			notefont.setColor(BaseColor.BLACK);
			notefont.setSize(7);

			Font distributorInfofont = FontFactory.getFont(FontFactory.TIMES_ROMAN);
			distributorInfofont.setColor(BaseColor.BLACK);
			distributorInfofont.setSize(8);



			///////////////////////////////

			PdfPTable titleTable = new PdfPTable(2);
			titleTable.setWidthPercentage(100f);
			titleTable.setWidths(new float[] {2.9f,20.0f});


			PdfPCell titleHeadCellR = new PdfPCell ();
			titleHeadCellR.setColspan (0);
			titleHeadCellR.setBackgroundColor(BaseColor.BLACK);
			titleHeadCellR.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell imageHead = new PdfPCell ();
			imageHead.setColspan (1);
			imageHead.setRowspan(2);
			imageHead.setBorder(0);
			imageHead.setHorizontalAlignment (Element.ALIGN_LEFT);
			imageHead.addElement(imager);

			titleTable.addCell(imageHead);

			titleHeadCellR.setPhrase(new Phrase("Distributor Earning Statement", titlefont));
			titleHeadCellR.setHorizontalAlignment(Element.ALIGN_CENTER);

			titleTable.addCell(titleHeadCellR);

			SimpleDateFormat formatter = new SimpleDateFormat("dd-MMMMMM-yyyy  HH:mm:ss ");
			
			PdfPCell currDateHead = new PdfPCell ();
			currDateHead.setColspan (0);
			currDateHead.setBorderWidthTop(6f);
			currDateHead.setBorderWidth(0.5f);
			currDateHead.setBorderColor(BaseColor.BLACK);
			currDateHead.setHorizontalAlignment(Element.ALIGN_CENTER);
			//currDateHead.setPhrase(new Phrase("\nStatement PDF Generation Date:"+formatter.format(new Date()), curDatefont));
			currDateHead.setPhrase(new Phrase("\nPDF Generation Date:"+formatter.format(new Date()), curDatefont));
			titleTable.addCell(currDateHead);


			///////////////////////////////

			/**
			 * Distributor Info table 
			 */

			PdfPTable distributorInfoTable = new PdfPTable(2);
			distributorInfoTable.setWidthPercentage(80f);
			distributorInfoTable.setWidths(new float[] {16.0f,28.0f});
			distributorInfoTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell leftCell = new PdfPCell ();
			leftCell.setColspan (1);
			leftCell.setNoWrap(true);
			leftCell.setBackgroundColor (new BaseColor (193, 193, 193));
			leftCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell rightCell = new PdfPCell ();
			rightCell.setColspan (1);
			//rightCell.setNoWrap(true);
			rightCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			leftCell.setPhrase(new Phrase("Month", fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(distVo.getMonth(), distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("Distributor Name",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(distVo.getDistName(),distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("Email",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(distVo.getDistEmail()!=null?distVo.getDistEmail():"",distributorInfofont));
			distributorInfoTable.addCell(rightCell);
			
			leftCell.setPhrase(new Phrase("AR Code",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(distVo.getArCode()!=null?distVo.getArCode():"",distributorInfofont));
			distributorInfoTable.addCell(rightCell);
			
			leftCell.setPhrase(new Phrase("Zone",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(distVo.getDistZone(),distributorInfofont));
			distributorInfoTable.addCell(rightCell);

/*			leftCell.setPhrase(new Phrase("Statement Date",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(new Paragraph (distVo.getStmtCycleDt()!=null?distVo.getStmtCycleDt():"",distributorInfofont)));
			distributorInfoTable.addCell(rightCell);
*/
			leftCell.setPhrase(new Phrase("Statement Date",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(new Paragraph (distVo.getPaymentDt()!=null?distVo.getPaymentDt():"",distributorInfofont)));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("VTopUp Number",fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(distVo.getDistMobile(),distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			leftCell.setPhrase(new Phrase("PAN Number", fontCommon));
			distributorInfoTable.addCell(leftCell);	       
			rightCell.setPhrase(new Phrase(distVo.getDistPanNo(), distributorInfofont));
			distributorInfoTable.addCell(rightCell);

			/**
			 * Second Table Generation
			 */


			PdfPTable turnOverTable = new PdfPTable(2);
			turnOverTable.setWidthPercentage(70f);
			turnOverTable.setWidths(new float[] {16.0f,8.0f});
			turnOverTable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);


			PdfPCell totLeftCell = new PdfPCell ();
			totLeftCell.setColspan (1);
			totLeftCell.setNoWrap(true);
			totLeftCell.setBackgroundColor(new BaseColor (193, 193, 193));
			totLeftCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell totSideHeadCell = new PdfPCell ();
			totSideHeadCell.setColspan (1);
			totSideHeadCell.setNoWrap(true);
			totSideHeadCell.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell totRightCell = new PdfPCell ();
			totRightCell.setColspan (1);
			totRightCell.setNoWrap(true);
			totRightCell.setHorizontalAlignment (Element.ALIGN_RIGHT);


			totSideHeadCell.setPhrase(new Phrase("Paper Primary Turnover - Rs. ",fontCommon));
			turnOverTable.addCell(totSideHeadCell);	       
			totRightCell.setPhrase(new Phrase(String.valueOf(distVo.getPaper()),fontCommon));
			turnOverTable.addCell(totRightCell);

			totSideHeadCell.setPhrase(new Phrase("Flexi Primary Turnover - Rs. ",fontCommon));
			turnOverTable.addCell(totSideHeadCell);	       
			totRightCell.setPhrase(new Phrase(String.valueOf(distVo.getFlexi()),fontCommon));
			turnOverTable.addCell(totRightCell);

			totLeftCell.setPhrase(new Phrase("Total Primary Turnover - Rs. ",fontCommon));
			turnOverTable.addCell(totLeftCell);
			totLeftCell.setHorizontalAlignment (Element.ALIGN_RIGHT);
			totLeftCell.setPhrase(new Phrase(String.valueOf(distVo.getTotalFexiPaper()),fontCommon));
			turnOverTable.addCell(totLeftCell);


			PdfPTable custInfotable = new PdfPTable(2);
			custInfotable.setWidthPercentage(100f);
			custInfotable.setWidths(new float[] {20.0f,20.0f});
			custInfotable.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell custInfoCell = new PdfPCell ();
			custInfoCell.setColspan (1);
			custInfoCell.setBorder(0);

			PdfPCell custInfoCellR = new PdfPCell ();
			custInfoCellR.setColspan (1);
			custInfoCellR.setBorder(0);

			custInfoCell.addElement(distributorInfoTable);
			custInfotable.addCell(custInfoCell);
			custInfoCellR.addElement(turnOverTable);
			custInfotable.addCell(custInfoCellR);



			/**
			 * Third Table Generation
			 */


			PdfPCell bottomTab1 = new PdfPCell ();
			bottomTab1.setColspan (1);
			bottomTab1.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab1.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell bottomTab2 = new PdfPCell ();
			bottomTab2.setColspan (1);
			bottomTab2.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab2.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab3 = new PdfPCell ();
			bottomTab3.setColspan (1);
			bottomTab3.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab3.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab4 = new PdfPCell ();
			bottomTab4.setColspan (1);
			bottomTab4.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab4.setHorizontalAlignment (Element.ALIGN_RIGHT); 


			PdfPTable table2=new PdfPTable(4);
			table2.setWidthPercentage(69f);
			table2.setWidths(new float[] {28.0f,8.0f,8.0f,8.0f});
			table2.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell targetHeadCell = new PdfPCell ();
			targetHeadCell.setColspan (1);
			targetHeadCell.setBackgroundColor(BaseColor.BLACK);
			targetHeadCell.setBorderColorBottom(BaseColor.WHITE);
			targetHeadCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			targetHeadCell.setBorderWidthBottom(1f);


			PdfPCell blankHeadCell = new PdfPCell ();
			blankHeadCell.setColspan (3);
			blankHeadCell.setBorder(0);
			blankHeadCell.addElement(new Paragraph(""));

			//targetHeadCell.setPhrase(new Phrase("Target Achievement", subHeadfont));
			targetHeadCell.setPhrase(new Phrase("Achievement", subHeadfont));
			
			table2.addCell(targetHeadCell);
			table2.addCell(blankHeadCell);

			PdfPCell tableLeft2_1 = new PdfPCell ();
			tableLeft2_1.setColspan (1);
			tableLeft2_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_1.setHorizontalAlignment (Element.ALIGN_CENTER);

			PdfPCell tableLeft2_2 = new PdfPCell ();
			tableLeft2_2.setColspan (1);
			tableLeft2_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft2_2.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_2.setBorderWidthLeft(0.4f);


			PdfPCell tableLeft2_3 = new PdfPCell ();
			tableLeft2_3.setColspan (1);
			tableLeft2_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft2_3.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_3.setBorderWidthLeft(0.4f);


			PdfPCell tableLeft2_4 = new PdfPCell ();
			tableLeft2_4.setColspan (1);
			tableLeft2_4.setBackgroundColor(BaseColor.BLACK);
			tableLeft2_4.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft2_4.setBorderColorLeft(BaseColor.WHITE);
			tableLeft2_4.setBorderWidthLeft(0.4f);


			tableLeft2_1.setPhrase(new Phrase("Particulars ",subHeadfont));
			table2.addCell(tableLeft2_1);	       
			tableLeft2_2.setPhrase(new Phrase("Target",subHeadfont));
			table2.addCell(tableLeft2_2);
			tableLeft2_3.setPhrase(new Phrase("Achievement ",subHeadfont));
			table2.addCell(tableLeft2_3);
			tableLeft2_4.setPhrase(new Phrase("% ACH",subHeadfont));
			table2.addCell(tableLeft2_4);

			// Particular
			PdfPCell tableLeft2_11 = new PdfPCell ();
			tableLeft2_11.setColspan (1);
			tableLeft2_11.setHorizontalAlignment (Element.ALIGN_LEFT);
			tableLeft2_11.setNoWrap(true);

			// Target
			PdfPCell tableLeft2_22 = new PdfPCell ();
			tableLeft2_22.setColspan (1);
			tableLeft2_22.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Achievement
			PdfPCell tableLeft2_33 = new PdfPCell ();
			tableLeft2_33.setColspan (1);
			tableLeft2_33.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// %
			PdfPCell tableLeft2_44 = new PdfPCell ();
			tableLeft2_44.setColspan (1);
			tableLeft2_44.setHorizontalAlignment (Element.ALIGN_RIGHT);

			tableLeft2_11.setPhrase(new Phrase("Gross Adds",fontCommon));
			table2.addCell(tableLeft2_11);	       
			tableLeft2_22.setPhrase(new Phrase( String.valueOf(distVo.getTargetNmnp()!=null?distVo.getTargetNmnp():0) ,fontCommon));//getTargetNmnp
			table2.addCell(tableLeft2_22);
			tableLeft2_33.setPhrase(new Phrase(String.valueOf(distVo.getNormalGross()!=null?distVo.getNormalGross():0) ,fontCommon));
			table2.addCell(tableLeft2_33);
			tableLeft2_44.setPhrase(new Phrase(String.valueOf(distVo.getAchiveNmnp()!=null?(distVo.getAchiveNmnp().setScale(2, BigDecimal.ROUND_CEILING)):0),fontCommon));//getAchiveNmnp
			table2.addCell(tableLeft2_44);

			tableLeft2_11.setPhrase(new Phrase("MNP Gross Adds",fontCommon));
			table2.addCell(tableLeft2_11);	       
			tableLeft2_22.setPhrase(new Phrase( String.valueOf(distVo.getTargetMnp()!=null?distVo.getTargetMnp():0),fontCommon));//getTargetMnp
			table2.addCell(tableLeft2_22);
			tableLeft2_33.setPhrase(new Phrase(String.valueOf(distVo.getMnpGross()!=null?distVo.getMnpGross():0) ,fontCommon));
			table2.addCell(tableLeft2_33);
			tableLeft2_44.setPhrase(new Phrase(String.valueOf(distVo.getAchiveMnp()!=null?(distVo.getAchiveMnp().setScale(2, BigDecimal.ROUND_CEILING)):0),fontCommon));//getAchiveMnp
			table2.addCell(tableLeft2_44);

			bottomTab1.setPhrase(new Phrase("Total Gross Adds",fontCommon));
			table2.addCell(bottomTab1);	       
			bottomTab2.setPhrase(new Phrase( String.valueOf(distVo.getTargetTotal()!=null?distVo.getTargetTotal():0),fontCommon));
			table2.addCell(bottomTab2);
			bottomTab3.setPhrase(new Phrase(String.valueOf(distVo.getGrossAct()!=null?distVo.getGrossAct():0) ,fontCommon));
			table2.addCell(bottomTab3);
			bottomTab4.setPhrase(new Phrase(String.valueOf(distVo.getAchiveTotal()!=null?(distVo.getAchiveTotal().setScale(2, BigDecimal.ROUND_CEILING)):0),fontCommon));
			table2.addCell(bottomTab4);

			/**
			 * Fourth Table Generation
			 */

			PdfPCell bottomTab11 = new PdfPCell ();
			bottomTab11.setColspan (1);
			bottomTab11.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab11.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPCell bottomTab12 = new PdfPCell ();
			bottomTab12.setColspan (1);
			bottomTab12.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab12.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab13 = new PdfPCell ();
			bottomTab13.setColspan (1);
			bottomTab13.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab13.setHorizontalAlignment (Element.ALIGN_RIGHT);

			PdfPCell bottomTab14 = new PdfPCell ();
			bottomTab14.setColspan (1);
			bottomTab14.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab14.setHorizontalAlignment (Element.ALIGN_RIGHT); 

			PdfPCell bottomTab15 = new PdfPCell ();
			bottomTab15.setColspan (1);
			bottomTab15.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab15.setHorizontalAlignment (Element.ALIGN_RIGHT);


			PdfPCell bottomTab16 = new PdfPCell ();
			bottomTab16.setColspan (1);
			bottomTab16.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab16.setHorizontalAlignment (Element.ALIGN_RIGHT);


			PdfPCell bottomTab17 = new PdfPCell ();
			bottomTab17.setColspan (1);
			bottomTab17.setBackgroundColor(new BaseColor (193, 193, 193));
			bottomTab17.setHorizontalAlignment (Element.ALIGN_LEFT);

			PdfPTable table3=new PdfPTable(7);
			table3.setWidthPercentage(100f);
			table3.setWidths(new float[]{28.0f,8.0f,8.0f,8.0f,8.0f,8.0f,8.0f});
			table3.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);


			PdfPCell tableLeft3_1 = new PdfPCell ();
			tableLeft3_1.setColspan (1);
			tableLeft3_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_1.setHorizontalAlignment (Element.ALIGN_CENTER);

			PdfPCell targetPayCell = new PdfPCell ();
			targetPayCell.setColspan (1);
			targetPayCell.setBackgroundColor(BaseColor.BLACK);
			targetPayCell.setHorizontalAlignment (Element.ALIGN_LEFT);
			targetPayCell.setBorderColorBottom(BaseColor.WHITE);
			targetPayCell.setBorderWidthBottom(1f);
			targetPayCell.setPhrase(new Phrase("Payouts to Distributor", subHeadfont));

			PdfPCell blankTargetPayCell = new PdfPCell ();
			blankTargetPayCell.setColspan (6);
			blankTargetPayCell.setBorder(0);
			blankTargetPayCell.addElement(new Paragraph(""));

			table3.addCell(targetPayCell);
			table3.addCell(blankTargetPayCell);


			PdfPCell tableLeft3_2 = new PdfPCell ();
			tableLeft3_2.setColspan (1);
			tableLeft3_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_2.setBorderWidthLeft(0.4f);
			tableLeft3_2.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_3 = new PdfPCell ();
			tableLeft3_3.setColspan (1);
			tableLeft3_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_3.setBorderWidthLeft(0.4f);
			tableLeft3_3.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_4 = new PdfPCell ();
			tableLeft3_4.setColspan (1);
			tableLeft3_4.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_4.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_4.setBorderWidthLeft(0.4f);
			tableLeft3_4.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_5 = new PdfPCell ();
			tableLeft3_5.setColspan (1);
			tableLeft3_5.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_5.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_5.setBorderWidthLeft(0.4f);
			tableLeft3_5.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_6 = new PdfPCell ();
			tableLeft3_6.setColspan (1);
			tableLeft3_6.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_6.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_6.setBorderWidthLeft(0.4f);
			tableLeft3_6.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft3_7 = new PdfPCell ();
			tableLeft3_7.setColspan (1);
			tableLeft3_7.setBackgroundColor(BaseColor.BLACK);
			tableLeft3_7.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft3_7.setBorderWidthLeft(0.4f);
			tableLeft3_7.setBorderColorLeft(BaseColor.WHITE);


			tableLeft3_1.setPhrase(new Phrase("Particulars ",subHeadfont));
			table3.addCell(tableLeft3_1);	       
			tableLeft3_2.setPhrase(new Phrase("No's ",subHeadfont));
			table3.addCell(tableLeft3_2);
			tableLeft3_7.setPhrase(new Phrase("Unit",subHeadfont));
			table3.addCell(tableLeft3_7);
			tableLeft3_3.setPhrase(new Phrase("Rate ",subHeadfont));
			table3.addCell(tableLeft3_3);
			tableLeft3_4.setPhrase(new Phrase("Payout Gross",subHeadfont));
			table3.addCell(tableLeft3_4);
			tableLeft3_5.setPhrase(new Phrase("TDS",subHeadfont));
			table3.addCell(tableLeft3_5);
			tableLeft3_6.setPhrase(new Phrase("Net = Payout Gross - TDS ",subHeadfont));
			table3.addCell(tableLeft3_6);

			// Particular
			PdfPCell tableLeft3_11 = new PdfPCell ();
			tableLeft3_11.setColspan (1);
			tableLeft3_11.setHorizontalAlignment (Element.ALIGN_MIDDLE);
			tableLeft3_11.setNoWrap(true);

			// No's
			PdfPCell tableLeft3_22 = new PdfPCell ();
			tableLeft3_22.setColspan (1);
			tableLeft3_22.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Rate
			PdfPCell tableLeft3_33 = new PdfPCell ();
			tableLeft3_33.setColspan (1);
			tableLeft3_33.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Payout Gross
			PdfPCell tableLeft3_44 = new PdfPCell ();
			tableLeft3_44.setColspan (1);
			tableLeft3_44.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// TDS@10%
			PdfPCell tableLeft3_55 = new PdfPCell ();
			tableLeft3_55.setColspan (1);
			tableLeft3_55.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Net
			PdfPCell tableLeft3_66 = new PdfPCell ();
			tableLeft3_66.setColspan (1);
			tableLeft3_66.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Mode of Payment
			PdfPCell tableLeft3_77 = new PdfPCell ();
			tableLeft3_77.setColspan (1);
			tableLeft3_77.setHorizontalAlignment (Element.ALIGN_LEFT);

			for(DistributorStmtSchmPojo distStmtPojo : distVo.getDistStmtSchmList()){
				tableLeft3_11.setPhrase(new Phrase(distStmtPojo.getSchemeCompDesc(),fontCommon));
				table3.addCell(tableLeft3_11);	       
				tableLeft3_22.setPhrase(new Phrase(String.valueOf(distStmtPojo.getPayTotal()!=null?distStmtPojo.getPayTotal():"") ,fontCommon));
				table3.addCell(tableLeft3_22);
				tableLeft3_77.setPhrase(new Phrase(distStmtPojo.getUnit(),fontCommon));
				table3.addCell(tableLeft3_77);
				tableLeft3_33.setPhrase(new Phrase(String.valueOf(distStmtPojo.getRate()!=null?distStmtPojo.getRate():""),fontCommon));
				table3.addCell(tableLeft3_33);
				tableLeft3_44.setPhrase(new Phrase(String.valueOf(distStmtPojo.getGrossPayAmt()),fontCommon));
				table3.addCell(tableLeft3_44);
				tableLeft3_55.setPhrase(new Phrase(String.valueOf(distStmtPojo.getTdsAmount()) ,fontCommon));
				table3.addCell(tableLeft3_55);
				tableLeft3_66.setPhrase(new Phrase(String.valueOf(distStmtPojo.getNetComm()) ,fontCommon));
				table3.addCell(tableLeft3_66);
			}
			bottomTab11.setPhrase(new Phrase("Total Payout",fontCommon));
			table3.addCell(bottomTab11);	       
			bottomTab12.setPhrase(new Phrase("" ,fontCommon));
			//bottomTab12.setPhrase(new Phrase(String.valueOf(distVo.getTotalNos()) ,fontCommon));
			table3.addCell(bottomTab12);
			bottomTab17.setPhrase(new Phrase("",fontCommon)); 
			table3.addCell(bottomTab17);
			bottomTab13.setPhrase(new Phrase("",fontCommon));
			//bottomTab13.setPhrase(new Phrase(String.valueOf(distVo.getTotalRate()),fontCommon));
			table3.addCell(bottomTab13);
			bottomTab14.setPhrase(new Phrase(String.valueOf(distVo.getPayoutGross()),fontCommon));
			table3.addCell(bottomTab14);
			bottomTab15.setPhrase(new Phrase(String.valueOf(distVo.getTotalTds()) ,fontCommon));
			table3.addCell(bottomTab15);
			bottomTab16.setPhrase(new Phrase(String.valueOf(distVo.getTotalNet()) ,fontCommon));
			table3.addCell(bottomTab16);

			/**
			 * Fifth Table Generation
			 */


			PdfPTable table4=new PdfPTable(5);//7
			table4.setWidthPercentage(100f);
			//table4.setWidths(new float[]{28.0f,8.0f,8.0f,8.0f,8.0f,8.0f,8.0f});
			table4.setWidths(new float[]{28.0f,8.0f,8.0f,8.0f,8.0f});
			table4.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);

			PdfPCell additionalPayHead = new PdfPCell ();
			additionalPayHead.setColspan (1);
			additionalPayHead.setBackgroundColor(BaseColor.BLACK);
			additionalPayHead.setHorizontalAlignment (Element.ALIGN_CENTER);
			additionalPayHead.setBorderColorBottom(BaseColor.WHITE);
			additionalPayHead.setBorderWidthBottom(1f);
			additionalPayHead.setPhrase(new Phrase("Additional Payout on Distributor's Behalf to Retailer", subHeadfont));

			table4.addCell(additionalPayHead);
			table4.addCell(blankTargetPayCell);


			PdfPCell tableLeft4_1 = new PdfPCell ();
			tableLeft4_1.setColspan (1);
			tableLeft4_1.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_1.setHorizontalAlignment (Element.ALIGN_CENTER);

			PdfPCell tableLeft4_2 = new PdfPCell ();
			tableLeft4_2.setColspan (1);
			tableLeft4_2.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_2.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_2.setBorderWidthLeft(0.6f);
			tableLeft4_2.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft4_3 = new PdfPCell ();
			tableLeft4_3.setColspan (1);
			tableLeft4_3.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_3.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_3.setBorderWidthLeft(0.4f);
			tableLeft4_3.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft4_4 = new PdfPCell ();
			tableLeft4_4.setColspan (1);
			tableLeft4_4.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_4.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_4.setBorderWidthLeft(0.4f);
			tableLeft4_4.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft4_5 = new PdfPCell ();
			tableLeft4_5.setColspan (1);
			tableLeft4_5.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_5.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_5.setBorderWidthLeft(0.4f);
			tableLeft4_5.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft4_6 = new PdfPCell ();
			tableLeft4_6.setColspan (1);
			tableLeft4_6.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_6.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_6.setBorderWidthLeft(0.4f);
			tableLeft4_6.setBorderColorLeft(BaseColor.WHITE);

			PdfPCell tableLeft4_7 = new PdfPCell ();
			tableLeft4_7.setColspan (1);
			tableLeft4_7.setBackgroundColor(BaseColor.BLACK);
			tableLeft4_7.setHorizontalAlignment (Element.ALIGN_CENTER);
			tableLeft4_7.setBorderWidthLeft(0.4f);
			tableLeft4_7.setBorderColorLeft(BaseColor.WHITE);


			tableLeft4_1.setPhrase(new Phrase("Particulars ",subHeadfont));
			table4.addCell(tableLeft4_1);	       
			tableLeft4_2.setPhrase(new Phrase("No's ",subHeadfont));
			table4.addCell(tableLeft4_2);
			tableLeft4_7.setPhrase(new Phrase("Unit",subHeadfont));
			table4.addCell(tableLeft4_7);
			tableLeft4_3.setPhrase(new Phrase("Rate ",subHeadfont));
			table4.addCell(tableLeft4_3);
			//tableLeft4_4.setPhrase(new Phrase("Payout Gross",subHeadfont));
			tableLeft4_4.setPhrase(new Phrase("Payout",subHeadfont));
			table4.addCell(tableLeft4_4);
			/*tableLeft4_5.setPhrase(new Phrase("TDS",subHeadfont));
			table4.addCell(tableLeft4_5);
			tableLeft4_6.setPhrase(new Phrase("Net ",subHeadfont));
			table4.addCell(tableLeft4_6);
*/
			// Particular
			PdfPCell tableLeft4_11 = new PdfPCell ();
			tableLeft4_11.setColspan (1);
			tableLeft4_11.setHorizontalAlignment (Element.ALIGN_MIDDLE);
			tableLeft4_11.setNoWrap(true);

			// No's
			PdfPCell tableLeft4_22 = new PdfPCell ();
			tableLeft4_22.setColspan (1);
			tableLeft4_22.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Rate
			PdfPCell tableLeft4_33 = new PdfPCell ();
			tableLeft4_33.setColspan (1);
			tableLeft4_33.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Payout Gross
			PdfPCell tableLeft4_44 = new PdfPCell ();
			tableLeft4_44.setColspan (1);
			tableLeft4_44.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// TDS@10%
			PdfPCell tableLeft4_55 = new PdfPCell ();
			tableLeft4_55.setColspan (1);
			tableLeft4_55.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Net
			PdfPCell tableLeft4_66 = new PdfPCell ();
			tableLeft4_66.setColspan (1);
			tableLeft4_66.setHorizontalAlignment (Element.ALIGN_RIGHT);

			// Mode of Payment
			PdfPCell tableLeft4_77 = new PdfPCell ();
			tableLeft4_77.setColspan (1);
			tableLeft4_77.setHorizontalAlignment (Element.ALIGN_LEFT);

			for(DistributorRetSchmPojo distRetPojo : distVo.getDistRetSchmList()){
				tableLeft4_11.setPhrase(new Phrase(distRetPojo.getSchemeCompDesc(),fontCommon));
				table4.addCell(tableLeft4_11);	       
				tableLeft4_22.setPhrase(new Phrase(String.valueOf(distRetPojo.getPayTotal()!=null?distRetPojo.getPayTotal():"") ,fontCommon));
				table4.addCell(tableLeft4_22);
				tableLeft4_77.setPhrase(new Phrase(distRetPojo.getUnit(),fontCommon));
				table4.addCell(tableLeft4_77);
				tableLeft4_33.setPhrase(new Phrase(String.valueOf(distRetPojo.getRate()!=null?distRetPojo.getRate():""),fontCommon));
				table4.addCell(tableLeft4_33);
				tableLeft4_44.setPhrase(new Phrase(String.valueOf(distRetPojo.getGrossPayAmt()),fontCommon));
				table4.addCell(tableLeft4_44);
				/*tableLeft4_55.setPhrase(new Phrase(String.valueOf(distRetPojo.getTdsAmount()) ,fontCommon));
				table4.addCell(tableLeft4_55);
				//tableLeft4_66.setPhrase(new Phrase(String.valueOf(distRetPojo.getNetComm()) ,fontCommon));
				tableLeft4_66.setPhrase(new Phrase(String.valueOf("") ,fontCommon));
				table4.addCell(tableLeft4_66);
				*/
			}
			bottomTab11.setPhrase(new Phrase("Total Payout",fontCommon));
			table4.addCell(bottomTab11);	       
			bottomTab12.setPhrase(new Phrase("" ,fontCommon));
			//bottomTab12.setPhrase(new Phrase(String.valueOf(distVo.getTotalRetNos()!=null?distVo.getTotalRetNos():0) ,fontCommon));
			table4.addCell(bottomTab12);
			bottomTab17.setPhrase(new Phrase("",fontCommon)); 
			table4.addCell(bottomTab17);
			bottomTab13.setPhrase(new Phrase("",fontCommon));
			//bottomTab13.setPhrase(new Phrase(String.valueOf(distVo.getTotalRetRate()!=null?distVo.getTotalRetRate():0),fontCommon));
			table4.addCell(bottomTab13);
			bottomTab14.setPhrase(new Phrase(String.valueOf(distVo.getRetPayoutGross()!=null?distVo.getRetPayoutGross():0),fontCommon));
			table4.addCell(bottomTab14);
			/*bottomTab15.setPhrase(new Phrase(String.valueOf(distVo.getRetTotalTds()!=null?distVo.getRetTotalTds():0) ,fontCommon));
			table4.addCell(bottomTab15);
			bottomTab16.setPhrase(new Phrase(String.valueOf(distVo.getRetTotalNet()) ,fontCommon));
			table4.addCell(bottomTab16);
*/
			//double total = distVo.getTotalNet() + distVo.getRetTotalNet();
			double total =  distVo.getRetTotalNet();
			PdfPCell totalPay = new PdfPCell ();
			totalPay.setColspan (7);
			totalPay.setHorizontalAlignment (Element.ALIGN_LEFT);
			//totalPay.setPhrase(new Phrase("To Retailers on your behalf : "+total ,fontCommon));

			totalPay.setPhrase(new Phrase("To Retailers on your behalf : "+ (distVo.getRetPayoutGross()!=null? distVo.getRetPayoutGross() : "") ,fontCommon));
			
			table4.addCell(totalPay);
			/**
			 *  ***********************************************************************************************************			
			 */
			//Now Insert Every Thing Into PDF Document
			document.open();//PDF document opened........       
			//document.add(head);
			document.add(titleTable);
			document.add(Chunk.NEWLINE); 
			document.add(new Paragraph(" "));
			document.add(custInfotable);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			//	document.add(new Paragraph(" "));
			//	document.add(table1);
			document.add(new Paragraph("Dear Channel Partner,", fontCommon));
			//document.add(new Paragraph("Please find mentioned below the details of Hisab-Kitab for the month.", fontCommon));
			document.add(new Paragraph("Please find mentioned below the details of your earning for the month.", fontCommon));
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			//document.add(subHeaderTable);
			document.add(table2);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			document.add(new Paragraph(""));
			//document.add(headerTable1);
			document.add(table3);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			document.add(new Paragraph(""));
			//document.add(headerTable2);
			document.add(table4);
			document.add(Chunk.NEWLINE);   //Something like in HTML :-)
			document.newPage();
			document.add(titleTable);
			document.add(new Paragraph("Note:")); 
			document.add(new Paragraph("In case of any clarifications you are requested to kindly revert back with details in 7 days. In case of no reply, we will assume this statement to be correct and validated. ",notefont));
			//document.add(Chunk.NEWLINE);
			//document.add(new Paragraph("This is a system generated report. No signature needed.",notefont));
			//document.add(new Paragraph("This is a system generated earning statement and it is not to be used for any financial / legal purposes. No signature needed.",notefont));
			document.add(new Paragraph("This is a system generated earning statement, no signature required. It is not to be used for any financial / legal purposes.",notefont));
			//document.add(Chunk.NEWLINE);
			document.add(new Paragraph("Discharge of applicable withholding tax, if any, towards your retailer payouts should be complied by you.",notefont));

			document.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	
	}
}

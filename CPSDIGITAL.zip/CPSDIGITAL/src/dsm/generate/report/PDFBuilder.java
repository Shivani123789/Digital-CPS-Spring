package dsm.generate.report;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

import dsm.model.report.Appendix;
import dsm.model.report.ComponentListReport;
import dsm.model.report.ComponentReport;
import dsm.model.report.ConditionReport;
import dsm.model.report.PayoutReport;
import dsm.model.report.ReportGenerateMaster;
import dsm.model.report.RetailerPerformanceReport;
import dsm.model.report.TransactionDataReport;

/**
 * This view class generates a PDF document 'on the fly' based on the data
 * contained in the model.
 * @author www.codejava.net
 *
 */
public class PDFBuilder extends AbstractITextPdfView {

	@Override
	protected void buildPdfDocument(Map<String, Object> model, Document doc,
			PdfWriter writer, HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		response.setContentType("application/pdf");
		
		//response.setHeader(arg0, arg1);
		// get data model which is passed by the Spring container
		String apprName="";
		String apprDate="";
		ReportGenerateMaster rgm = (ReportGenerateMaster)model.get("reportList");
		response.setHeader("Content-Disposition","attachment;filename="+rgm.getVersionNo()+"_System_NFA.pdf");
		//doc = new Document(PageSize.A4,0,0,0,0);
		//doc.setPageSize(Rectangle.BOX);
		doc.setPageSize(PageSize.A4);
		if("D".equalsIgnoreCase(rgm.getCsvType())){
			writer.setPageEvent(new Watermark("D",153,153,102));
		}else if("A".equalsIgnoreCase(rgm.getCsvType())){
			writer.setPageEvent(new Watermark("A",144,238,144));
			apprName = "Approved By : "+rgm.getApprovedBy();
			apprDate = " on "+rgm.getApprovedDt();
		}else if("R".equalsIgnoreCase(rgm.getCsvType())){
			writer.setPageEvent(new Watermark("R",255, 153, 153));
			apprName = rgm.getRejectedBy();
			apprDate = rgm.getRejectedDt();
			apprName = "Rejected By : "+rgm.getRejectedBy();
			apprDate = " on "+rgm.getRejectedDt();
		}else if("C".equalsIgnoreCase(rgm.getCsvType())){
			writer.setPageEvent(new Watermark("C",153,153,102));
			apprName = "Final Payout Approved By : "+rgm.getPayoutApprovedBy();
			apprDate = " on "+rgm.getPayoutApprovedDt();
		}
		
		doc.addTitle("PDFReport");
		
		SimpleDateFormat sf = new SimpleDateFormat("dd/MMMMM/yyyy  hh:mm:ss aaa");
		Date date = new Date();
		
		Font fontDateText = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontDateText.setColor(BaseColor.BLACK);
		fontDateText.setSize(6f);
		
		Font fontApprRejText = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontApprRejText.setColor(BaseColor.BLACK);
		fontApprRejText.setSize(7f);
		
		Font font = FontFactory.getFont(FontFactory.TIMES_BOLD);
		font.setColor(BaseColor.GRAY);
		
		Chunk chtDate = new Chunk("Date : "+sf.format(date),fontDateText);
		chtDate.setCharacterSpacing(0.75f);
		
		Chunk verNoh = new Chunk("Version No : "+rgm.getVersionNo(),fontDateText);
		verNoh.setCharacterSpacing(0.75f);
		
		Chunk apprRejDate = new Chunk(apprName+apprDate,fontApprRejText);
		apprRejDate.setCharacterSpacing(0.75f);
		
		Chunk userIdDate = new Chunk("Created By : "+rgm.getUserId()+" on "+rgm.getInsertDt(),fontApprRejText);
		apprRejDate.setCharacterSpacing(0.75f);
		
		PdfPTable tableDt = new PdfPTable(2);
		tableDt.setWidthPercentage(100f);
		tableDt.setSpacingAfter(10f);
		
		PdfPCell cellDt = new PdfPCell (new Paragraph(chtDate));
		cellDt.setColspan (1);
		cellDt.setHorizontalAlignment (Element.ALIGN_LEFT);
		cellDt.setBorder(0);
		cellDt.setBottom(20f);
		tableDt.addCell(cellDt);
		
		PdfPCell cellV = new PdfPCell (new Paragraph(verNoh));
		cellV.setColspan (1);
		cellV.setHorizontalAlignment (Element.ALIGN_RIGHT);
		cellV.setBorder(0);
		cellV.setBottom(20f);
		//cellDt.setVerticalAlignment(Element.ALIGN_CENTER);
		//cellV.setPadding (12.0f);
		//cell.setBackgroundColor (new BaseColor (140, 221, 8));	              
		tableDt.addCell(cellV);
		
		PdfPCell userIdDt = new PdfPCell (new Paragraph(userIdDate));
		userIdDt.setColspan (1);
		userIdDt.setHorizontalAlignment (Element.ALIGN_LEFT);
		userIdDt.setBorder(0);
		userIdDt.setBottom(20f);
		tableDt.addCell(userIdDt);
		
		PdfPCell apprRejDt = new PdfPCell (new Paragraph(apprRejDate));
		apprRejDt.setColspan (1);
		apprRejDt.setHorizontalAlignment (Element.ALIGN_RIGHT);
		apprRejDt.setBorder(0);
		apprRejDt.setBottom(20f);
		tableDt.addCell(apprRejDt);
		
		
		
		doc.add(tableDt);
		
		
		doc.add(Chunk.NEWLINE);
		doc.add(Chunk.NEWLINE);
		/*StringBuffer path = new StringBuffer();
		System.out.println("protocol:::::::::: "+request.getProtocol());
		path.append("https://");
		path.append(request.getServerName());
		path.append(":");
		path.append(request.getServerPort());
		path.append(request.getContextPath());
		path.append("/resources/images/ideaLogo.jpg");
		*///System.out.println("Path :: "+path);
					
		StringBuffer path = new StringBuffer(System.getProperty("SCHEME_STUDIO_CONFIG_PATH")+"Images/ideaLogo.jpg");
		//path.append("ideaLogo.jpg");
		
		Font fonth = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
		fonth.setColor(BaseColor.BLACK);
		fonth.setSize(15);
		
		Font fonHeadText = FontFactory.getFont(FontFactory.TIMES);
		fonHeadText.setColor(BaseColor.BLACK);
		fonHeadText.setSize(9f);
		//fon.setStyle(1);
		
		Font fontSubText = FontFactory.getFont(FontFactory.TIMES_BOLD);
		fontSubText.setColor(BaseColor.BLACK);
		fontSubText.setSize(8f);
		
		Font fontSubTextNote = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
		fontSubText.setColor(BaseColor.BLACK);
		fontSubText.setSize(8f);
		
		Font fontAppendexText = FontFactory.getFont(FontFactory.TIMES_ITALIC);
		fontAppendexText.setColor(BaseColor.BLACK);
		fontAppendexText.setSize(8f);
		
		
		Chunk cht = new Chunk("Configured Scheme Details",fonth);
		cht.setCharacterSpacing(0.75f);
		Paragraph head = new Paragraph(cht);
		head.setAlignment(Element.ALIGN_CENTER);
		
		Image imager=null;
		try {
			//imager = Image.getInstance (new URL(path.toString()));
			imager = Image.getInstance (path.toString());
			imager.scaleToFit(60f, 30f);//image width,height
			imager.setAlignment(Element.ALIGN_RIGHT);
			imager.setBorder(0);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		PdfPTable table12=new PdfPTable(3);
		table12.setWidthPercentage(100f);
		table12.setSpacingAfter(2f);
		
		PdfPCell cellh = new PdfPCell (head);
		cellh.setColspan (2);
		cellh.setHorizontalAlignment (Element.ALIGN_RIGHT);
		cellh.setBorder(0);
		cellh.setBottom(0f);
		cellh.setVerticalAlignment(Element.ALIGN_CENTER);
		cellh.setPadding (12.0f);
		//cell.setBackgroundColor (new BaseColor (140, 221, 8));	              
		table12.addCell(cellh);
		
		PdfPCell cell12 = new PdfPCell (imager);
		cell12.setColspan (1);
		cell12.setVerticalAlignment (Element.ALIGN_TOP);
		cell12.setBorder(0);
		cell12.setTop(0f);
		cell12.setHorizontalAlignment (Element.ALIGN_RIGHT);
		//cell.setPadding (10.0f);
		//cell.setBackgroundColor (new BaseColor (140, 221, 8));	              
		table12.addCell(cell12);	 
		
		
		doc.add(table12);
		doc.add(Chunk.NEWLINE);
		doc.add(Chunk.NEWLINE);
		
		try{
			//	System.out.println("PDFBuilder Size :: "+rgm!=null ? rgm.getComponentListReport().size():"null");
			if(rgm.getComponentListReport()!=null && rgm.getComponentListReport().size()!=0)
				for(ComponentListReport comp : rgm.getComponentListReport()){

					

					Font fonts = FontFactory.getFont(FontFactory.TIMES_BOLD);
					fonts.setColor(BaseColor.GRAY);
					fonts.setSize(9f);
					
					PdfPTable schemeTable = new PdfPTable(2);
					schemeTable.setWidthPercentage(100.0f);
					schemeTable.setSpacingBefore(15f);
					schemeTable.setSpacingAfter(15f);
					
					Chunk ch1 = new Chunk("Scheme Name",font);
					Paragraph sch = new Paragraph(ch1);
					PdfPCell schemecell = new PdfPCell(sch);
					schemecell.setBorder(0);


					Chunk ch2 = new Chunk("Component Name",font);
					Paragraph compPara = new Paragraph(ch2);
					PdfPCell compcell = new PdfPCell(compPara);
					compcell.setBorder(0);

					Chunk ch3 = new Chunk(comp.getSchemeName(),fonHeadText);
					Paragraph sch1 = new Paragraph(ch3);
					PdfPCell schemeValcell = new PdfPCell(sch1);
					schemeValcell.setBorder(0);

					Chunk ch4 = new Chunk(comp.getComponentName(),fonHeadText);
					Paragraph comp1 = new Paragraph(ch4);
					PdfPCell compValcell = new PdfPCell(comp1);
					compValcell.setBorder(0);

					schemeTable.addCell(schemecell);
					schemeTable.addCell(compcell);
					schemeTable.addCell(schemeValcell);
					schemeTable.addCell(compValcell);

					
					doc.add(Chunk.NEWLINE);
					doc.add(schemeTable);
					doc.add(Chunk.NEWLINE);



					PdfPTable parantTable = new PdfPTable(1);
					parantTable.setWidthPercentage(100f);
					parantTable.setSpacingAfter(10f);
					
					PdfPTable childTable = new PdfPTable(5);
					childTable.setWidthPercentage(100f);

					System.out.println("************** comp.getComponentReport()size  :::: "+comp.getComponentReport().size());
					//List<ComponentReport> compReport = comp.getComponentReport();
					if(comp.getComponentReport()!=null && comp.getComponentReport().size()!=0)
						for(ComponentReport componentList :  comp.getComponentReport()){
							//System.out.println(" ***************  comp.getComponentReport() getCircleName :::: "+componentList.getCircleName());
							try{
							PdfPCell blankL01 = new PdfPCell(new Paragraph(""));
							blankL01.setColspan(1);
							blankL01.setBorder(0);

							PdfPCell blankL02 = new PdfPCell(new Paragraph(""));
							blankL02.setColspan(2);
							blankL02.setBorder(0);
							//blankL01.setHorizontalAlignment();

							PdfPCell blankL05 = new PdfPCell(new Paragraph(""));
							blankL05.setColspan(5);
							blankL05.setBorder(0);


							Chunk chc1 = new Chunk("Period",fonts);
							Paragraph p1 = new Paragraph(chc1);
							PdfPCell pc1 = new PdfPCell(p1);
							pc1.setBorder(0);
							pc1.setNoWrap(true);

							Chunk chc1a = new Chunk(componentList.getStartDateEndDate(),fontSubText);
							Paragraph p1a = new Paragraph(chc1a);
							PdfPCell  pc1a = new PdfPCell(p1a);
							pc1a.setBorder(0);
							pc1a.setNoWrap(true);
							pc1a.setPaddingBottom(10f);
							
							Chunk chc2 = new Chunk("Payout Frequency",fonts);
							Paragraph p2 = new Paragraph(chc2);
							PdfPCell pc2 = new PdfPCell(p2);
							pc2.setBorder(0);
							pc2.setNoWrap(true);

							Chunk chc2a = new Chunk(componentList.getFrequency(),fontSubText);
							Paragraph p2a = new Paragraph(chc2a);
							PdfPCell  pc2a = new PdfPCell(p2a);
							pc2a.setBorder(0);
							pc2a.setNoWrap(true);
							pc2a.setPaddingBottom(10f);
							
							Chunk chc3 = new Chunk("Payee Entity",fonts);
							Paragraph p3 = new Paragraph(chc3);
							PdfPCell pc3 = new PdfPCell(p3);
							pc3.setBorder(0);
							pc3.setNoWrap(true);

							Chunk chc3a = new Chunk(componentList.getPayTo(),fontSubText);
							Paragraph p3a = new Paragraph(chc3a);
							PdfPCell  pc3a = new PdfPCell(p3a);
							pc3a.setBorder(0);
							pc3a.setNoWrap(true);
							pc3a.setPaddingBottom(10f);
							
							
							//
							Chunk chc21 = new Chunk("Applicable For",fonHeadText);
							Paragraph p21 = new Paragraph(chc21);
							PdfPCell pc21 = new PdfPCell(p21);
							pc21.setBorder(0);
							pc21.setNoWrap(true);
							//pc21.setPadding(8f);
							
							Chunk chc22 = new Chunk("Circle",fonts);
							Paragraph p22 = new Paragraph(chc22);
							PdfPCell pc22 = new PdfPCell(p22);
							pc22.setBorder(0);
							pc22.setPaddingLeft(12f);
							pc22.setNoWrap(true);

							Chunk chc22a = new Chunk(componentList.getCircleName(),fontSubText);
							Paragraph p22a = new Paragraph(chc22a);
							PdfPCell  pc22a = new PdfPCell(p22a);
							pc22a.setBorder(0);
							pc22a.setPaddingLeft(12f);
							pc22a.setNoWrap(true);
							pc22a.setPaddingBottom(10f);
							
							Chunk chc23 = new Chunk("Region",fonts);
							Paragraph p23 = new Paragraph(chc23);
							PdfPCell pc23 = new PdfPCell(p23);
							pc23.setBorder(0);
							pc23.setNoWrap(true);

							Chunk chc23a = new Chunk(componentList.getFileName()==null ? componentList.getRegion():"N/A",fontSubText);
							Paragraph p23a = new Paragraph(chc23a);
							PdfPCell  pc23a = new PdfPCell(p23a);
							pc23a.setBorder(0);
							pc23a.setNoWrap(true);
							pc23a.setPaddingBottom(10f);
							
							
							Chunk chc24 = new Chunk("Zone",fonts);
							Paragraph p24 = new Paragraph(chc24);
							PdfPCell pc24 = new PdfPCell(p24);
							pc24.setBorder(0);
							pc24.setNoWrap(true);

							Chunk chc24a = new Chunk(componentList.getFileName()==null ? componentList.getZone():"N/A",fontSubText);
							Paragraph p24a = new Paragraph(chc24a);
							PdfPCell  pc24a = new PdfPCell(p24a);
							pc24a.setBorder(0);
							pc24a.setNoWrap(true);
							pc24a.setPaddingBottom(10f);
							
							Chunk chc25 = new Chunk("Sales vertical",fonts);
							Paragraph p25 = new Paragraph(chc25);
							PdfPCell pc25 = new PdfPCell(p25);
							pc25.setBorder(0);
							pc25.setNoWrap(true);

							Chunk chc25a = new Chunk(componentList.getFileName()==null ? componentList.getVertical():"N/A",fontSubText);
							Paragraph p25a = new Paragraph(chc25a);
							PdfPCell  pc25a = new PdfPCell(p25a);
							pc25a.setBorder(0);
							pc25a.setNoWrap(true);
							pc25a.setPaddingBottom(10f);
		
							Chunk chc28 = new Chunk("File Upload List",fonts);
							Paragraph p28 = new Paragraph(chc28);
							PdfPCell pc28 = new PdfPCell(p28);
							pc28.setBorder(0);
							pc28.setPaddingLeft(12f);
							pc28.setNoWrap(true);

							System.out.println("componentList.getFileName() :::******* "+componentList.getFileName());
							
							Chunk chc28a = new Chunk(componentList.getFileName()!=null ?"Yes":"No",fontSubText);
							Paragraph p28a = new Paragraph(chc28a);
							PdfPCell  pc28a = new PdfPCell(p28a);
							pc28a.setBorder(0);
							pc28a.setPaddingLeft(12f);
							pc28a.setNoWrap(true);
							pc28a.setPaddingBottom(10f);

							
							Chunk chc29 = new Chunk("File Name",fonts);
							Paragraph p29 = new Paragraph(chc29);
							PdfPCell pc29 = new PdfPCell(p29);
							pc29.setBorder(0);
							pc29.setNoWrap(true);
							pc29.setColspan(3);
							
							Chunk chc29a = new Chunk(componentList.getFileName()!=null ?componentList.getFileName():"",fontSubText);
							Paragraph p29a = new Paragraph(chc29a);
							PdfPCell  pc29a = new PdfPCell(p29a);
							pc29a.setBorder(0);
							pc29a.setNoWrap(true);
							pc29a.setPaddingBottom(10f);
							pc29a.setColspan(3);
							
							Chunk chc26a = new Chunk(componentList.getSalesDesc(),fontSubText);
							Paragraph p26a = new Paragraph(chc26a);
							PdfPCell  pc26a = new PdfPCell(p26a);
							pc26a.setBorder(0);
							pc26a.setNoWrap(true);
							pc26a.setColspan(5);
							pc26a.setHorizontalAlignment(Element.ALIGN_CENTER);
							
							childTable.addCell(pc1);
							childTable.addCell(blankL02);
							childTable.addCell(pc2);
							childTable.addCell(pc3);
							childTable.addCell(pc1a);
							childTable.addCell(blankL02);
							childTable.addCell(pc2a);
							childTable.addCell(pc3a);
							childTable.addCell(blankL05);
							childTable.setHorizontalAlignment(2);
							
							
							childTable.addCell(pc21);
							childTable.addCell(pc22);
							childTable.addCell(pc23);
							childTable.addCell(pc24);
							childTable.addCell(pc25);
							childTable.addCell(blankL01);
							
							childTable.addCell(pc22a);
							childTable.addCell(pc23a);
							childTable.addCell(pc24a);
							childTable.addCell(pc25a);
							childTable.addCell(blankL05);
							childTable.setHorizontalAlignment(2);
							
							childTable.addCell(blankL01);
							childTable.addCell(pc28);
							childTable.addCell(pc29);
							childTable.addCell(blankL01);
							
							//childTable.addCell(blankL02);
							childTable.addCell(pc28a);
							childTable.addCell(pc29a);
							childTable.addCell(blankL05);
							//childTable.setHorizontalAlignment(2);
							
							
							childTable.setHorizontalAlignment(2);
							childTable.addCell(pc26a);
							
							if(comp.getConditionReport()!=null && comp.getConditionReport().size()!=0)
								for(ConditionReport condList : comp.getConditionReport()){
									Chunk chc26 = new Chunk(condList.getCondition(),fontSubText);
									Paragraph p26 = new Paragraph(chc26);
									PdfPCell pc26 = new PdfPCell(p26);
									pc26.setBorder(0);
									pc26.setColspan(5);
									pc26.setNoWrap(true);
									pc26.setHorizontalAlignment(Element.ALIGN_CENTER);
									childTable.addCell(pc26);
								}
						}catch(Exception e){
							System.out.println("Exception in ConditionReport ::::  ::::::"+e.getMessage());
							e.printStackTrace();
						}
						}
					
					BaseColor borderColor = new BaseColor(173,216,230);
					BaseColor backGroundcolor = new BaseColor(135,206,235);
					BaseColor textBackGroundcolor = new BaseColor (240 ,	248, 	255);
					
					
					PdfPCell parentCell = new PdfPCell(childTable);
					parentCell.setBorderWidth(2f);
					//parentCell.setColspan (3);
					//parentCell.setHorizontalAlignment (Element.ALIGN_CENTER);
					parentCell.setPadding (10.0f);
					//cell.setBackgroundColor (new BaseColor (140, 221, 8));	              
					parentCell.setBorderColor(borderColor);
					parantTable.addCell(parentCell);

					
					doc.add(parantTable);
					doc.add(Chunk.NEWLINE);
					
					// Transaction
					doc.add(new Paragraph("Transaction Data to be Considered",font));

					PdfPTable transTable = new PdfPTable(4);
					transTable.setWidthPercentage(100.0f);
					transTable.setWidths(new float[] {0.6f, 3.0f, 3.0f, 5.0f});
					transTable.setSpacingBefore(10);

					PdfPCell cell3 = new PdfPCell();
					cell3.setBackgroundColor(backGroundcolor);
					cell3.setBorderColor(borderColor);
					cell3.setBorderWidth(2f);
					cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
					
					Font font2 = FontFactory.getFont(FontFactory.TIMES_BOLD);
					font2.setColor(BaseColor.BLACK);
					font2.setSize(9f);
					
					
					cell3.setPhrase(new Phrase("SNo.", font2));
					transTable.addCell(cell3);

					cell3.setPhrase(new Phrase("Condition Name", font2));
					transTable.addCell(cell3);

					cell3.setPhrase(new Phrase("Type Of Data", font2));
					transTable.addCell(cell3);

					cell3.setPhrase(new Phrase("Criteria", font2));
					transTable.addCell(cell3);
					
					
					int tqcount=1;
					System.out.println("************** comp.getTransDataReport() :::: "+comp.getTransDataReport());
					//String conditionName="";
					
					PdfPCell cellTq = new PdfPCell();
					cellTq.setBackgroundColor(textBackGroundcolor);
					cellTq.setBorderColor(borderColor);
					cellTq.setBorderWidth(2f);
					cellTq.setPaddingBottom(5f);
					
					if(comp.getTransDataReport()!=null || comp.getTransDataReport().size()!=0)
						for (TransactionDataReport tq : comp.getTransDataReport()) {
							
							cellTq.setPhrase(new Paragraph(String.valueOf(tqcount),fontSubText));
							transTable.addCell(cellTq);
							
							cellTq.setPhrase(new Paragraph(tq.getConditionName(),fontSubText));
							transTable.addCell(cellTq);
							System.out.println(""+tq.getConditionName());
							//conditionName=tq.getConditionName();
							
							cellTq.setPhrase(new Paragraph(tq.getDataSet(),fontSubText));
							transTable.addCell(cellTq);
							
							cellTq.setPhrase(new Paragraph(tq.getCondition(),fontSubText));
							transTable.addCell(cellTq);
							System.out.println("Condition :::: "+tq.getCondition());
							tqcount++;
						}
					
					doc.add(transTable);
					doc.add(Chunk.NEWLINE);
					
					System.out.println("************** comp.getRetailerReport() :::: "+comp.getRetailerReport());

					//Retailer
					doc.add(new Paragraph("Performance Calculation(s)",font));
					//int eaCount=1;
					if(comp.getRetailerReport()!=null || comp.getRetailerReport().size()!=0)
						for(RetailerPerformanceReport ea : comp.getRetailerReport()){
							Paragraph schEA = new Paragraph();
							schEA.setFont(fontSubText);
							schEA.add(ea.getVariableValue());
						//	schEA.add(ea.getVariableName());
							schEA.setSpacingAfter(6);
							Phrase ph = new Phrase();
							ph.setFont(fontSubTextNote);
							if(ea.getNote()!=null){
							ph.add(" ['"+ea.getNote()+"']");
							}else{
								//ph.add("  [From '"+ea.getVariableName()+"']");
								ph.add("");
							}
							//schEA.add(ea.getVariableValue());
							schEA.add(ph);//From condition name
							doc.add(schEA);
						//	eaCount++;
						}

					doc.add(Chunk.NEWLINE);
					doc.add(new Paragraph("Payment Condition",font));
					
					PdfPCell cellPc = new PdfPCell();
					cellPc.setBackgroundColor(textBackGroundcolor);
					cellPc.setBorderColor(borderColor);
					cellPc.setBorderWidth(2f);
					cellPc.setPaddingBottom(5f);
					
					PdfPTable payoutTable = new PdfPTable(8);
					PdfPCell cell2 = new PdfPCell();
					cell2.setBackgroundColor(backGroundcolor);
					cell2.setBorderColor(borderColor);
					cell2.setBorderWidth(2f);
					cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
					
					payoutTable.setWidthPercentage(100.0f);
					payoutTable.setWidths(new float[] {1.2f, 5.0f, 2.0f, 2.0f,4.0f, 2.0f, 3.0f, 3.0f});
					payoutTable.setSpacingBefore(10);

					cell2.setPhrase(new Phrase("SNo.", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Payment Terms", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Amt", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Unit", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Performance", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("G/N", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Over Ach.", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Under Ach.", font2));
					payoutTable.addCell(cell2);

					System.out.println("************** comp.getPayoutReport() :::: "+comp.getPayoutReport());

					int payoutCount=1;
					if(comp.getPayoutReport()!= null || comp.getPayoutReport().size()!=0)
						for (PayoutReport po : comp.getPayoutReport()) {
							
							cellPc.setPhrase(new Phrase(String.valueOf(payoutCount),fontSubText));
							payoutTable.addCell(cellPc);
							
							cellPc.setPhrase(new Phrase(po.getConditionName(),fontSubText));
							payoutTable.addCell(cellPc);
							
							cellPc.setPhrase(new Phrase(String.valueOf(po.getAmount()),fontSubText));
							payoutTable.addCell(cellPc);
							
							cellPc.setPhrase(new Phrase(po.getUnit(),fontSubText));
							payoutTable.addCell(cellPc);
							
							cellPc.setPhrase(new Phrase(po.getVariable(),fontSubText));
							payoutTable.addCell(cellPc);
							
							cellPc.setPhrase(new Phrase(po.getGrossNet(),fontSubText));
							payoutTable.addCell(cellPc);
							
							cellPc.setPhrase(new Phrase(String.valueOf(po.getOverAchive()),fontSubText));
							payoutTable.addCell(cellPc);
							
							cellPc.setPhrase(new Phrase(String.valueOf(po.getUnderAchive()),fontSubText));
							payoutTable.addCell(cellPc);
							
							/*//payoutTable.addCell(String.valueOf(payoutCount));
							payoutTable.addCell(po.getConditionName());
							payoutTable.addCell(String.valueOf(po.getAmount()));
							payoutTable.addCell(po.getUnit());
							payoutTable.addCell(po.getVariable());
							payoutTable.addCell(po.getGrossNet());
							payoutTable.addCell(String.valueOf(po.getOverAchive()));
							payoutTable.addCell(String.valueOf(po.getUnderAchive()));*/
							payoutCount++;
						}

					doc.add(payoutTable);


					
					if("C".equalsIgnoreCase(rgm.getCsvType())){
						
						doc.add(Chunk.NEWLINE);
						doc.add(new Paragraph("Payout Information",font));
						
						PdfPCell cellPId = new PdfPCell();
						cellPId.setBackgroundColor(textBackGroundcolor);
						cellPId.setBorderColor(borderColor);
						cellPId.setBorderWidth(2f);
						cellPId.setPaddingBottom(5f);
						
						PdfPTable payoutInfoTable = new PdfPTable(4);
						PdfPCell cellPich = new PdfPCell();
						cellPich.setBackgroundColor(backGroundcolor);
						cellPich.setBorderColor(borderColor);
						cellPich.setBorderWidth(2f);
						cellPich.setHorizontalAlignment(Element.ALIGN_CENTER);
						
						payoutInfoTable.setWidthPercentage(100.0f);
						payoutInfoTable.setWidths(new float[] {1.2f, 5.0f, 5.0f, 5.0f});
						payoutInfoTable.setSpacingBefore(10);
						
						cellPich.setPhrase(new Phrase("SNo.", font2));
						payoutInfoTable.addCell(cellPich);

						cellPich.setPhrase(new Phrase("Total Net Amount", font2));
						payoutInfoTable.addCell(cellPich);

						cellPich.setPhrase(new Phrase("Total Gross Amount", font2));
						payoutInfoTable.addCell(cellPich);
						
						cellPich.setPhrase(new Phrase("Head Count", font2));
						payoutInfoTable.addCell(cellPich);
						
						cellPId.setPhrase(new Phrase(String.valueOf("1"),fontSubText));
						payoutInfoTable.addCell(cellPId);
						
						cellPId.setPhrase(new Phrase(String.valueOf(rgm.getTotalNetAmount()),fontSubText));
						payoutInfoTable.addCell(cellPId);
						
						cellPId.setPhrase(new Phrase(String.valueOf(rgm.getTotalGrossAmount()),fontSubText));
						payoutInfoTable.addCell(cellPId);
						
						cellPId.setPhrase(new Phrase(String.valueOf(rgm.getHeadCount()),fontSubText));
						payoutInfoTable.addCell(cellPId);
						
						doc.add(payoutInfoTable);
						
					}
			/*PdfContentByte over = writer.getDirectContentUnder();
			over.saveState();
			float sinus = (float)Math.sin(Math.PI / 90);
			float cosinus = (float)Math.cos(Math.PI / 90);
			BaseFont bf = BaseFont.createFont();
			over.beginText();
			over.setTextRenderingMode(
			//PdfContentByte.TEXT_RENDER_MODE_FILL);
					PdfContentByte.TEXT_RENDER_MODE_FILL_STROKE_CLIP);
			over.setLineWidth(1.5f);
			over.setFontAndSize(bf, 100);
			over.setTextMatrix(cosinus, sinus, -sinus, cosinus, 100, 324);
			if("D".equalsIgnoreCase(rgm.getCsvType())){
			over.setRGBColorStroke(153,153,102);
			over.setRGBColorFill(255,255,255);
			//over.showText("D R A F T");
			over.showTextAligned(Element.YMARK, "D R A F T", 180f, 240f, 50f);
			}else if("A".equalsIgnoreCase(rgm.getCsvType())){
				over.setFontAndSize(bf, 80);
				over.setRGBColorStroke(144,238,144);
				over.setRGBColorFill(255,255,255);
				over.showTextAligned(Element.YMARK, "A P P R O V E D", 100f, 200f, 50f);
			}else if("R".equalsIgnoreCase(rgm.getCsvType())){
				over.setFontAndSize(bf, 80);
				over.setRGBColorStroke(255, 153, 153);
				over.setRGBColorFill(255, 153, 153);
				over.showTextAligned(Element.YMARK, "R E J E C T E D", 100f, 200f, 50f);
			}
			over.endText();
			over.restoreState();
*/



					doc.newPage();
				}
		}catch(Exception e){
			e.getMessage();	
		}
		Font font1 = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
		font1.setColor(BaseColor.RED);
		doc.add(new Paragraph("Appendix",font1));

		PdfPTable table = new PdfPTable(4);
		table.setWidthPercentage(100.0f);
		table.setWidths(new float[] {3.3f, 3.0f, 6.3f, 3.3f});
		table.setSpacingBefore(10);

		// define font for table header row
		Font fontw = FontFactory.getFont(FontFactory.TIMES);
		fontw.setSize(9f);
		fontw.setColor(BaseColor.WHITE);

		// define table header cell
		PdfPCell cell = new PdfPCell();
		cell.setBackgroundColor(new BaseColor(102, 153, 255));
		cell.setHorizontalAlignment(Element.ALIGN_CENTER);
		cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
		//cell.setPadding(4);

		// write table header 
		cell.setPhrase(new Phrase("Performance Type", fontw));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Parameter Name", fontw));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Parameter Meaning", fontw));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Valid Value (If Any)", fontw));
		table.addCell(cell);

		PdfPCell cellAppendex = new PdfPCell();
		//cellAppendex.setBorderWidth(1f);
		
		//System.out.println("PDFBuilder getAppendix Size :: "+rgm!=null ? rgm.getAppendix().size():"null");
		if(rgm!=null && rgm.getAppendix()!=null && rgm.getAppendix().size()!=0)
			for (Appendix app : rgm.getAppendix()) {
				cellAppendex.setPhrase(new Phrase(app.getPerformanceType(),fontAppendexText));
				table.addCell(cellAppendex);
				cellAppendex.setPhrase(new Phrase(app.getParameterName(),fontAppendexText));
				table.addCell(cellAppendex);
				cellAppendex.setPhrase(new Phrase(app.getParameterMeaning(),fontAppendexText));
				table.addCell(cellAppendex);
				cellAppendex.setPhrase(new Phrase(app.getValidValue(),fontAppendexText));
				table.addCell(cellAppendex);
				
				/*table.addCell(app.getPerformanceType());
				table.addCell(app.getParameterName());
				table.addCell(app.getParameterMeaning());
				table.addCell(app.getValidValue());*/
			}
		doc.add(table);
	}

	
	
	
	/*@Override
	protected void buildPdfDocument(Map<String, Object> model, Document doc,PdfWriter writer, HttpServletRequest request, HttpServletResponse response)
	throws Exception {
		
		ReportGenerateMaster rgm = (ReportGenerateMaster)model.get("reportList");
		doc.addTitle("PDFReport");
		
		Font fonth = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
		fonth.setColor(BaseColor.BLACK);
		fonth.setSize(14);


		Chunk cht = new Chunk("Configured Scheme Details",fonth);
		Paragraph head = new Paragraph(cht);
		head.setAlignment(Element.ALIGN_CENTER);
		
		Image imagel = Image.getInstance ("src/Aditiya_Birla.jpg");//"http://"+request.getServerName()+":"+request.getServerPort()+request.getContextPath()+"/resources/images/ideaLogo.jpg"
		imagel.scaleToFit(80f, 50f);//image width,height
		imagel.setAlignment(Element.ALIGN_LEFT);
		imagel.setBorder(0);
		
		System.out.println("Image Path ::: "+request.getLocalAddr()+request.getRemoteAddr()+request.getRemotePort()+request.getRemoteHost()+request.getContextPath()+"/resources/images/ideaLogo.jpg");
		StringBuffer path = new StringBuffer();
		path.append("http://");
		path.append(request.getServerName());
		path.append(":");
		path.append(request.getServerPort());
		path.append(request.getContextPath());
		path.append("/resources/images/ideaLogo.jpg");
		System.out.println("Path :: "+path);
		
		Image imager = Image.getInstance (new URL(path.toString()));
		imager.scaleToFit(60f, 30f);//image width,height
		imager.setAlignment(Element.ALIGN_RIGHT);
		imager.setBorder(0);

		PdfPTable table=new PdfPTable(3);
		table.setWidthPercentage(100f);
		table.setSpacingAfter(0f);
		
		PdfPCell cellh = new PdfPCell (head);
		cellh.setColspan (2);
		cellh.setHorizontalAlignment (Element.ALIGN_RIGHT);
		cellh.setBorder(0);
		cellh.setBottom(0f);
		cellh.setVerticalAlignment(Element.ALIGN_CENTER);
		cellh.setPadding (12.0f);
		//cell.setBackgroundColor (new BaseColor (140, 221, 8));	              
		table.addCell(cellh);
		
		PdfPCell cell = new PdfPCell (imager);
		cell.setColspan (1);
		cell.setVerticalAlignment (Element.ALIGN_TOP);
		cell.setBorder(0);
		cell.setTop(0f);
		cell.setHorizontalAlignment (Element.ALIGN_RIGHT);
		//cell.setPadding (10.0f);
		//cell.setBackgroundColor (new BaseColor (140, 221, 8));	              
		table.addCell(cell);	  
		
			
					
		PdfPCell cellr = new PdfPCell (imager);
		cellr.setColspan (1);
		cellr.setHorizontalAlignment (Element.ALIGN_RIGHT);
		cellr.setBorder(0);
		//cell.setPadding (10.0f);
		//cell.setBackgroundColor (new BaseColor (140, 221, 8));	              
		table.addCell(cellr);	
		
		
		doc.open();
		doc.add(table);
		
		
		PdfContentByte over = writer.getDirectContentUnder();
		over.saveState();
		float sinus = (float)Math.sin(Math.PI / 90);
		float cosinus = (float)Math.cos(Math.PI / 90);
		BaseFont bf = BaseFont.createFont();
		
		over.beginText();
		over.setTextRenderingMode(
		PdfContentByte.TEXT_RENDER_MODE_STROKE_CLIP);
		over.setLineWidth(2.5f);
		//over.setRGBColorStroke(0xFF, 0x00, 0x00);
		//over.setRGBColorFill(0xFF, 0xFF, 0xFF);
		over.setFontAndSize(bf, 90);
		over.setTextMatrix(
		cosinus, sinus, -sinus, cosinus, 100, 324);
		over.showText("D R A F T");
		over.showTextAligned(Element.YMARK, "REJECT", 10f, 20f, 450f);
		over.endText();
		over.restoreState();
		PdfContentByte under = writer.getDirectContentUnder();
		under.saveState();
		under.setRGBColorFill(0xFF, 0xD7, 0x00);
		under.rectangle(5, 5, PageSize.POSTCARD.getWidth() - 10,
		PageSize.POSTCARD.getHeight() - 10);
		under.fill();
		under.restoreState();
		
		doc.close();
	}
	*/
	
	
	
	
	
	
	
	
	
	public class Watermark extends PdfPageEventHelper {
		public String waterMark;
		public int r;
		public int g;
		public int b;
		
		public Watermark(String marker,int r, int g, int b){
			waterMark = marker;
			this.r=r;
			this.g=g;
			this.b=b;
		}
		
		//protected Phrase watermark = new Phrase(waterMark, new Font(FontFamily.HELVETICA, 60, Font.NORMAL, BaseColor.LIGHT_GRAY));
        
       /* @Override
        public void onEndPage(PdfWriter writer, Document document) {
        	//writer.setRgbTransparencyBlending(true);
        	Phrase watermark = new Phrase(waterMark, new Font(FontFamily.HELVETICA, 60, Font.NORMAL, new BaseColor(r,g,b)));
        	PdfContentByte canvas = writer.getDirectContentUnder();//getDirectContent();
            ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, watermark, 298, 421, 45);
           // canvas.saveState();297, 500, 0
            PdfGState gs1 = new PdfGState();298, 421, 45
            gs1.setFillOpacity(0.5f);
            canvas.setGState(gs1);
            ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, watermark, 297, 450, 0);
            canvas.restoreState();
        }*/
		
		
		 @Override
		 public void onEndPage(PdfWriter writer, Document document) {
			 try{
				 PdfContentByte over = writer.getDirectContentUnder();
				 over.saveState();
				 float sinus = (float)Math.sin(Math.PI / 90);
				 float cosinus = (float)Math.cos(Math.PI / 90);
				 BaseFont bf = BaseFont.createFont();
				 over.beginText();
				 over.setTextRenderingMode(PdfContentByte.TEXT_RENDER_MODE_FILL_STROKE_CLIP);
				 over.setLineWidth(1.5f);
				 over.setFontAndSize(bf, 100);
				 over.setTextMatrix(cosinus, sinus, -sinus, cosinus, 100, 324);
				 if("D".equalsIgnoreCase(waterMark)){
					 over.setRGBColorStroke(153,153,102);
					 over.setRGBColorFill(255,255,255);
					 over.showTextAligned(Element.YMARK, "D R A F T", 180f, 240f, 50f);
				 }else if("A".equalsIgnoreCase(waterMark)){
					 over.setFontAndSize(bf, 80);
					 over.setRGBColorStroke(144,238,144);
					 over.setRGBColorFill(255,255,255);
					 over.showTextAligned(Element.YMARK, "A P P R O V E D", 100f, 200f, 50f);
				 }else if("R".equalsIgnoreCase(waterMark)){
					 over.setFontAndSize(bf, 80);
					 over.setRGBColorStroke(255, 153, 153);
					 over.setRGBColorFill(255,255,255);
					 over.showTextAligned(Element.YMARK, "R E J E C T E D", 100f, 200f, 50f);
				 }else  if("C".equalsIgnoreCase(waterMark)){
					 over.setRGBColorStroke(51,51,255);
					 over.setRGBColorFill(255,255,255);
					 over.showTextAligned(Element.YMARK, "C L O S E D", 180f, 240f, 50f);
				 }
				 over.endText();
				 over.restoreState();

			 }catch(Exception e){
				 e.getMessage();
			 }
		 }
    }

	
	
	
	
	
	
	
	
	
	
	
}
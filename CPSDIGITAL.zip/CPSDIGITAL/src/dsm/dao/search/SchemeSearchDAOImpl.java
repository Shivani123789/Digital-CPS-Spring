package dsm.dao.search;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import dsm.dataBase.query.SchemeConfigQueries;
import dsm.model.DB.BulkRejectionDataPojo;
import dsm.model.DB.CompMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ScmPayoutVO;
import dsm.model.DB.UpdateCalander;
import dsm.model.form.BulkLoadErrorFileStatus;
import dsm.model.form.HoldReleaseAmount;
import dsm.model.form.SchemeCompNFAList;
import dsm.model.search.SearchScheme;
import dsm.model.submit.SubmitScheme;
import dsm.model.user.User;

public class SchemeSearchDAOImpl implements SchemeSearchDAO {

private JdbcTemplate jdbcTemplate;
private static Logger logger = Logger.getLogger (SchemeSearchDAOImpl.class);	

@Autowired
HttpSession httpSession;
	public SchemeSearchDAOImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

	
	
/*	@Override
	public List<SchemeMaster> loadSchemeForEdit(String Scheme) {
		//logger.debug("Begin SchemeSearchDAOImpl loadSchemeForEdit ");
		try{
			int circleId =0;
			// TODO Auto-generated method stub
			if(httpSession.getAttribute("circleId")!=null){
				circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
			User user = (User)httpSession.getAttribute("appUser");
			String query = "select distinct stg.scheme_id,stg.scheme_name from DLP_SCHEME_MASTER_STAGE stg where  circle_id="+circleId+" AND upper(user_id)=upper('"+user.getUserName()+"') AND validity_flag IN ('Y','I','W','F') union  select distinct s.scheme_id,s.scheme_name from DLP_SCHEME_MASTER s ,dlp_scheme_comp_mapping c where circle_id="+circleId+" AND s.scheme_id = c.scheme_id AND upper(s.user_id)=upper('"+user.getUserName()+"')  and c.scm_status='D' and s.validity_flag = c.validity_flag and c.validity_flag='Y' order by scheme_id desc";
			//logger.debug("get scheme for edit  "+query);
			List<SchemeMaster> covList = jdbcTemplate.query(query, new RowMapper<SchemeMaster>() {
				@Override
				public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
					SchemeMaster schemeMaster = new SchemeMaster();
					schemeMaster.setSchemeINputId(rs.getInt("scheme_id"));
					schemeMaster.setSchemeName(rs.getString("scheme_name"));
					return schemeMaster;
				}
			});
			//logger.debug("End SchemeSearchDAOImpl loadSchemeForEdit ");
			return covList;
			}
		}catch(Exception e){
			logger.error("Exception :: ",e);
			e.printStackTrace();
		}
		//logger.debug("End SchemeSearchDAOImpl loadSchemeForEdit ");
		return null;
	}
*/
	@Override
	public List<SchemeMaster> loadSchemeForEdit(SearchScheme searchScheme) {
		/*//logger.debug*/////System.out.println("Begin SchemeSearchDAOImpl loadSchemeForEdit || stDate:"+searchScheme.getStartDate());
		try{
			int circleId =0;
			// TODO Auto-generated method stub
			List<SchemeMaster> covList = new ArrayList<SchemeMaster>();
			if(httpSession.getAttribute("circleId")!=null){
				circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
			User user = (User)httpSession.getAttribute("appUser");
			String query = "select distinct stg.scheme_id,stg.scheme_name from DLP_SCHEME_MASTER_STAGE stg, Dlp_Scheme_Comp_Mapping_Stage stgc where  circle_id="+circleId+
					" AND upper(stg.user_id)=upper('"+user.getUserName()+"') AND stgc.scm_status IN ('I','W','F') And Stg.Scheme_Id= Stgc.Scheme_Id And  stg.Validity_Flag = stgc.Validity_Flag And stgc.Validity_Flag ='Y' AND TRUNC(stgc.START_DATE) >= to_date('"+searchScheme.getStartDate()+"','DD-MON-YYYY')   AND TRUNC(stgc.END_DATE) <= to_date('"+searchScheme.getEndDate()+"','DD-MON-YYYY')  "+(searchScheme.getPayTo()==11?" ":" AND stgc.PAY_TO="+searchScheme.getPayTo())+
							"union  select distinct s.scheme_id,s.scheme_name from DLP_SCHEME_MASTER s ,dlp_scheme_comp_mapping c where circle_id="+circleId+
							" AND s.scheme_id = c.scheme_id AND upper(s.user_id)=upper('"+user.getUserName()+"')  and c.scm_status='D'" +
									" AND TRUNC(C.START_DATE) >=  to_date('"+searchScheme.getStartDate()+"','DD-MON-YYYY')  AND TRUNC(C.END_DATE) <= to_date('"+searchScheme.getEndDate()+"','DD-MON-YYYY')  AND "+(searchScheme.getPayTo()==11?" ":" C.PAY_TO="+searchScheme.getPayTo()+" AND ")+
									" s.validity_flag = c.validity_flag and c.validity_flag='Y' order by scheme_id desc";
			
			/*//logger.debug*/////System.out.println("get scheme for edit  "+query);
			
			SchemeMaster schemeMaster = new SchemeMaster();
			schemeMaster.setSchemeINputId(0);
			schemeMaster.setSchemeName("&nbsp;");
			covList.add(schemeMaster);
			
			covList = jdbcTemplate.query(query, new RowMapper<SchemeMaster>() {
				@Override
				public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
					SchemeMaster schemeMaster = new SchemeMaster();
					schemeMaster.setSchemeINputId(rs.getInt("scheme_id"));
					schemeMaster.setSchemeName(rs.getString("scheme_name"));
					return schemeMaster;
				}
			});
			/*//logger.debug*/////System.out.println("End SchemeSearchDAOImpl loadSchemeForEdit ");
			
			return covList;
			}
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeSearchDAOImpl || loadSchemeForEdit || Exception  ");
		}
		catch(Exception e){
			////System.out.println(" SchemeSearchDAOImpl || loadSchemeForEdit || Exception  "+e);
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		//logger.debug("End SchemeSearchDAOImpl loadSchemeForEdit ");
		return null;
	}

	
	
	@Override
	public List<SchemeMaster> loadScheme(String Scheme) {
		//logger.debug("Begin SchemeSearchDAOImpl loadScheme ");
		try {
		if(httpSession.getAttribute("circleId")!=null){
			int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
					//String query = "select * from DLP_SCHEME_MASTER where upper(scheme_name) like upper('%"+Scheme+"%') AND circle_id="+circleId+" AND validity_flag='Y' order by update_date_time desc";
			List<SchemeMaster> covList = jdbcTemplate.query(SchemeConfigQueries.LOAD_SCHEME_MASTER, new Object[]{circleId}, new RowMapper<SchemeMaster>() {
			//	List<SchemeMaster> covList = jdbcTemplate.query(query, new RowMapper<SchemeMaster>() {
					
				@Override
				public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
					SchemeMaster schemeMaster = new SchemeMaster();
					schemeMaster.setSchemeINputId(rs.getInt("SCHEME_ID"));
					schemeMaster.setSchemeName(rs.getString("SCHEME_NAME"));
					return schemeMaster;
				}
			});
			return covList;
		}
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeSearchDAOImpl || loadScheme ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		//logger.debug("End SchemeSearchDAOImpl loadScheme ");
		return null;
	}

		
		
	@Override
	public List<SchemeMaster> searchSchemeView(SearchScheme searchView) {
		//logger.debug("Begin SchemeSearchDAOImpl searchSchemeView ");	
		List<SchemeMaster> covList =null;
		try 
		{	
		String scmId = "%"+(searchView.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(searchView.getSchemeComp())?"":searchView.getSchemeId())+"%";
		String scmName = "%"+(searchView.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(searchView.getSchemeComp())?"":searchView.getSchemeComp())+"%";
		String compName = "%"+("ABCDEF".equalsIgnoreCase(searchView.getComponentName())?"":searchView.getComponentName())+"%";
		String payTo = "%"+(searchView.getPayTo()==-1?"":searchView.getPayTo())+"%";
		String fileName = "%"+("ABCDEF".equalsIgnoreCase(searchView.getFileName())?"":searchView.getFileName())+"%";
		
		
			String query = "SELECT comp.scheme_id," +
					"  scm.scheme_name,  scm.insert_date_time,  scm.validity_flag,  comp.component_id,  comp.componenet_name,  TO_CHAR(comp.START_DATE,'DD-MON-YYYY') AS START_DATE ," +
					"  TO_CHAR(comp.END_DATE,'DD-MON-YYYY')   AS END_DATE ,  PAYTO.DISPLAY_VALUE,  COMP.FILE_NAME,  comp.SCM_STATUS,  comp.reason,  comp.vtopup_file_flag" +
					"  FROM dlp_scheme_comp_mapping_stage comp,  dlp_scheme_master_stage scm,  DLP_ENTITY_TYPE_MASTER PAYTO " +
					" where (SCM.SCHEME_ID like ? " +
					" or SCM.SCHEME_NAME like ? )" +
					" and (upper(COMP.COMPONENET_NAME) like upper(?))" +
					" AND COMP.PAY_TO like ? " +
					" and SCM.CIRCLE_ID           = ? "+
					" AND (upper(COMP.FILE_NAME) like upper(?) " +
							" "+searchView.getChangeDesc()+")" +
					" AND TRUNC(comp.start_date) >= to_date(?,'DD-MON-YYYY') " +
					" AND TRUNC(comp.end_date)   <= to_date(?,'DD-MON-YYYY') " +
					" AND comp.SCM_STATUS         = ? " +
					" AND comp.validity_flag      = 'Y' " +
					" and SCM.VALIDITY_FLAG       = 'Y' " +
					" AND scm.validity_flag = comp.validity_flag " +
					" and COMP.SCHEME_ID          = SCM.SCHEME_ID " +
					" AND payto.entity_type_id  = comp.pay_to " +
					" UNION ALL" +
					" SELECT comp.scheme_id," +
					"  scm.scheme_name,  scm.insert_date_time,  scm.validity_flag,  comp.component_id,  comp.componenet_name,  TO_CHAR(comp.START_DATE,'DD-MON-YYYY') AS START_DATE ," +
					"  TO_CHAR(comp.END_DATE,'DD-MON-YYYY')   AS END_DATE ,  PAYTO.DISPLAY_VALUE,  COMP.FILE_NAME,  comp.SCM_STATUS,  comp.reason,  comp.vtopup_file_flag" +
					"  FROM dlp_scheme_comp_mapping comp,  dlp_scheme_master scm,  DLP_ENTITY_TYPE_MASTER PAYTO" +
					" where (SCM.SCHEME_ID like ? " +
							" or SCM.SCHEME_NAME like ? )" +
							" and (upper(COMP.COMPONENET_NAME) like upper(?)) " +
					" and SCM.CIRCLE_ID     = ? " +
					" AND COMP.PAY_TO like ? " +
					" AND (upper(COMP.FILE_NAME) like upper(?) " +
							" "+searchView.getChangeDesc()+")" +
					" AND TRUNC(comp.start_date) BETWEEN to_date(?,'DD-MON-YYYY')  AND  to_date(?,'DD-MON-YYYY') " +
					" and TRUNC(COMP.END_DATE) between to_date(?,'DD-MON-YYYY') and to_date(?,'DD-MON-YYYY')  " +
					" and COMP.SCM_STATUS   = ? " +
					" and COMP.VALIDITY_FLAG = 'Y' " +
					" and SCM.VALIDITY_FLAG = 'Y' " +
					" AND scm.validity_flag = comp.validity_flag " +
					" and COMP.SCHEME_ID    = SCM.SCHEME_ID " +
					" and PAYTO.ENTITY_TYPE_ID = COMP.PAY_TO ";

			 	covList = jdbcTemplate.query(query, new Object[]{scmId, scmName, compName, payTo, searchView.getCircleId(), fileName, searchView.getStartDate(), searchView.getEndDate(), searchView.getCondParam(),
					scmId, scmName, compName, searchView.getCircleId(), payTo, fileName, searchView.getStartDate(), searchView.getEndDate(), searchView.getStartDate(), searchView.getEndDate(), searchView.getCondParam()}, new RowMapper<SchemeMaster>() {
				@Override
				public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
					SchemeMaster schemeMaster = new SchemeMaster();
					schemeMaster.setSchemeINputId(rs.getInt("scheme_id"));
					schemeMaster.setSchemeName(rs.getString("scheme_name"));
					schemeMaster.setInsertTime(rs.getDate("insert_date_time"));
					schemeMaster.setStartDate(rs.getString("start_date"));
					schemeMaster.setEndDate(rs.getString("end_date"));
					schemeMaster.setPayTo(rs.getString("scheme_name"));
					schemeMaster.setFileName(rs.getString("FILE_NAME"));
					if(rs.getString("SCM_STATUS")!=null)
					{
						if(rs.getString("SCM_STATUS").equals("I"))
							schemeMaster.setSchemeStatus("Intial");
						if(rs.getString("SCM_STATUS").equals("W"))
							schemeMaster.setSchemeStatus("Waiting for Submit");
						if(rs.getString("SCM_STATUS").equals("D"))
							schemeMaster.setSchemeStatus("Draft");
						if(rs.getString("SCM_STATUS").equals("R"))
							schemeMaster.setSchemeStatus("Rejected");
						if(rs.getString("SCM_STATUS").equals("A"))
							schemeMaster.setSchemeStatus("Approved");
						if(rs.getString("SCM_STATUS").equals("C"))
							schemeMaster.setSchemeStatus("Closed");
					}
					if(rs.getString("reason")!=null)
						schemeMaster.setRemarks(rs.getString("reason"));
					schemeMaster.setPayTo(rs.getString("display_value"));
					schemeMaster.setCompName(rs.getString("componenet_name"));
					schemeMaster.setCompId(rs.getInt("component_id"));
					return schemeMaster;
				}

			});
			
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || loadScheme ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}	
			//logger.debug("End SchemeSearchDAOImpl searchSchemeView ");
		return covList;

	}


	
	@Override
	public void loadScheme(SchemeMaster sm) {
		//logger.debug("Begin SchemeSearchDAOImpl loadScheme ");
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("scheme_update");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("pCIRCLEID", sm.getCircleId());
		inParamMap.put("pSCHNAME", sm.getSchemeName());
		inParamMap.put("pCOMPNAME", sm.getCompName());
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		//logger.debug("End SchemeSearchDAOImpl loadScheme "+simpleJdbcCallResult);
	}

	@Override
	public void submitScheme(SubmitScheme scheme) {
		try {
		//logger.debug("Begin SchemeSearchDAOImpl submitScheme ");
		String sql = "INSERT INTO DSM2_SCHEME_SUBMISSION_AUDIT(" +
				" SCHEME_ID, "+
				"CIRCLE_ID, "+
				"SCHEME_NAME, "+
				"DESCRIPTION, "+
				"START_DATE, "+
				"END_DATE, "+
				"VALIDITY_FLAG, "+
				"USER_ID, "+
				"SUBMIT_DATE_TIME"+
						")"+
				"VALUES(?,?,?,?,?,?,?,?,?)";
		////logger.debug("submitScheme query ::"+sql);
		jdbcTemplate.update(sql,scheme.getSchemeINputId(),
				scheme.getCircleId(),
				scheme.getSchemeName(),
				scheme.getDesc(),
				scheme.getStartDate(),
				scheme.getEndDate(),
				scheme.getValidityFlag(),
				scheme.getUserId(),
				scheme.getSubmitDate()
				);
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || submitScheme ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}	
		//logger.debug("End SchemeSearchDAOImpl submitScheme ");
	}

	@Override
	public String validateScheme(SubmitScheme scheme) throws Exception {
		//logger.debug("Begin SchemeSearchDAOImpl validateScheme ");
		
		String dupReq = duplicateRequest(scheme.getSchemeINputId(),scheme.getCompId());
		if(dupReq == null){
			return "Component is already submitted.";
		}
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DLP_SCM_TRANSFER_GUI_STAGE");

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("pUSERCODE", scheme.getUserName());
		inParamMap.put("Pcircle", scheme.getCircleCode());
		inParamMap.put("Pscm_Id", scheme.getSchemeINputId());
		inParamMap.put("pCOMP_ID", scheme.getCompId());		
		
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);

		//logger.debug("pret_val:: "+simpleJdbcCallResult.get("PRET_VAL"));
		try{
			String val = (String) simpleJdbcCallResult.get("PRET_VAL");
			if("F".equalsIgnoreCase(val)){
			String sql = "update DLP_SCHEME_COMP_MAPPING_STAGE " +
					"set SCM_STATUS=?"+
					"where " +
					"scheme_id=? AND COMPONENT_ID=?";
			jdbcTemplate.update(sql,simpleJdbcCallResult.get("PRET_VAL"),scheme.getSchemeINputId(),scheme.getCompId());
			}
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || validateScheme ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}	
		//logger.debug("End SchemeSearchDAOImpl validateScheme ");
		return simpleJdbcCallResult.toString();
	}
	
	private String duplicateRequest(int schemeId, int compId) 
	{
		//logger.debug("Begin SchemeSearchDAOImpl duplicateRequest ");
		try{
			String sql = "select SCM_STATUS from DLP_SCHEME_COMP_MAPPING_STAGE where SCHEME_ID=? and COMPONENT_ID=? and VALIDITY_FLAG='Y'";
			//logger.debug(" duplicateRequest query :: "+sql);
			String status = jdbcTemplate.queryForObject(sql, new Object[]{schemeId,compId}, String.class);
			//logger.debug("End SchemeSearchDAOImpl duplicateRequest ");
			return status;
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || duplicateRequest ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}	
		return null;
	}
	@Override
	public String showError(SubmitScheme scheme) throws Exception {
		//logger.debug("Begin SchemeSearchDAOImpl showError ");
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
		.withProcedureName("DLP_SCH_RETURN_ERRMSG");
		Map<String, Object> inParamMap = new HashMap<String, Object>();
		//logger.debug("Circle Id "+scheme.getCircleId() +" :: Scheme Id "+scheme.getSchemeINputId() +" :: Comp Id "+scheme.getCompId() );
		inParamMap.put("pCIRCLEID", scheme.getCircleId());
		inParamMap.put("pSCMID", scheme.getSchemeINputId());
		inParamMap.put("pCOMPID", scheme.getCompId());
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		//return simpleJdbcCallResult.toString();
		//logger.debug("End SchemeSearchDAOImpl showError ");
		return simpleJdbcCallResult.get("POUTVAL").toString();
	}



	
	
	@Override
	public List<SchemeMaster> searchSchemeSubmit(SearchScheme schemeSearch) {
		List<SchemeMaster> covList = new ArrayList<SchemeMaster>();
		try {
		
		String scmId = "%"+(schemeSearch.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(schemeSearch.getSchemeComp())?"":schemeSearch.getSchemeId())+"%";
		String scmName = "%"+(schemeSearch.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(schemeSearch.getSchemeComp())?"":schemeSearch.getSchemeComp())+"%";
		String compName = "%"+("ABCDEF".equalsIgnoreCase(schemeSearch.getComponentName())?"":schemeSearch.getComponentName())+"%";
		String payTo = "%"+(schemeSearch.getPayTo()==-1?"":schemeSearch.getPayTo())+"%";
		
		String query = "SELECT c.*," +
				"  (SELECT COUNT(1)  FROM" +
				"  (SELECT COMP.SCHEME_ID, SCM.SCHEME_NAME, SCM.INSERT_DATE_TIME, SCM.VALIDITY_FLAG, COMP.COMPONENT_ID, COMP.COMPONENET_NAME, TO_CHAR(COMP.START_DATE,'DD-MON-YYYY') AS START_DATE ," +
				"   TO_CHAR(COMP.END_DATE,'DD-MON-YYYY')   AS END_DATE , PAYTO.DISPLAY_VALUE, COMP.SCM_STATUS, COMP.REASON, COMP.VTOPUP_FILE_FLAG FROM DLP_SCHEME_COMP_MAPPING_STAGE COMP," +
				"    DLP_SCHEME_MASTER_STAGE SCM,  DLP_ENTITY_TYPE_MASTER PAYTO  where (SCM.SCHEME_ID like ? " +
				"  or SCM.SCHEME_NAME like ?)" +
				"  AND upper(COMP.COMPONENET_NAME) like upper(?)"+
				"    and TRUNC(COMP.START_DATE) >= to_date(?,'DD-MON-YYYY')   AND TRUNC(COMP.END_DATE)   <= to_date(?,'DD-MON-YYYY')   and COMP.SCM_STATUS  = ?" +
				"    and SCM.VALIDITY_FLAG       ='Y'  AND scm.circle_id  = ? AND COMP.PAY_TO like ?  AND PAYTO.ENTITY_TYPE_ID  = COMP.PAY_TO  AND scm.validity_flag = comp.validity_flag" +
				"    AND comp.scheme_id          = scm.scheme_id    ORDER BY scm.insert_date_time DESC    )" +
				"  )     NO_OF_RECORDS  FROM ( SELECT a.*,rownum ROW_NUM FROM " +
				" ( SELECT b.* FROM  " +
				" ( SELECT comp.scheme_id,  scm.scheme_name,  scm.insert_date_time,  scm.validity_flag,  comp.component_id,  comp.componenet_name,  TO_CHAR(comp.START_DATE,'DD-MON-YYYY') AS START_DATE ," +
				"  TO_CHAR(comp.END_DATE,'DD-MON-YYYY')   AS END_DATE ,  payto.display_value,  comp.SCM_STATUS,  comp.reason,  comp.vtopup_file_flag FROM dlp_scheme_comp_mapping_stage comp," +
				"  dlp_scheme_master_stage scm,  DLP_ENTITY_TYPE_MASTER PAYTO where (SCM.SCHEME_ID like ? " +
				"  or SCM.SCHEME_NAME like ?)" +
				"  AND upper(COMP.COMPONENET_NAME) like upper(?)"+
				"  AND TRUNC(COMP.START_DATE) >= to_date(?,'DD-MON-YYYY')  AND  TRUNC(comp.end_date)   <= to_date(?,'DD-MON-YYYY') and COMP.SCM_STATUS  = ? " +
				"  and SCM.VALIDITY_FLAG       ='Y' and SCM.CIRCLE_ID           = ? AND COMP.PAY_TO like ? and PAYTO.ENTITY_TYPE_ID  = COMP.PAY_TO and SCM.VALIDITY_FLAG = COMP.VALIDITY_FLAG" +
				"  and COMP.SCHEME_ID = SCM.SCHEME_ID order by SCM.INSERT_DATE_TIME desc) B ) a) C " +
				"  WHERE ROW_NUM BETWEEN  "+(schemeSearch.getStart()+1)+" AND "+(schemeSearch.getStart()+schemeSearch.getLimit());
		
		
		 covList = jdbcTemplate.query(query, new Object[]{scmId, scmName, compName, schemeSearch.getStartDate(), schemeSearch.getEndDate(), schemeSearch.getCondParam(), schemeSearch.getCircleId(), payTo, scmId, scmName, compName, schemeSearch.getStartDate(), schemeSearch.getEndDate(), schemeSearch.getCondParam(), schemeSearch.getCircleId(), payTo}, new RowMapper<SchemeMaster>() {

			@Override
			public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeMaster schemeMaster = new SchemeMaster();
				schemeMaster.setTotalRow(rs.getInt("NO_OF_RECORDS"));
				schemeMaster.setSchemeINputId(rs.getInt("scheme_id"));
				schemeMaster.setSchemeName(rs.getString("scheme_name"));
				schemeMaster.setInsertTime(rs.getDate("insert_date_time"));
				schemeMaster.setStartDate(rs.getString("start_date"));
				schemeMaster.setEndDate(rs.getString("end_date"));
				schemeMaster.setPayTo(rs.getString("scheme_name"));
		if(rs.getString("SCM_STATUS")!=null)
		{
				if(rs.getString("SCM_STATUS").equals("I"))
				schemeMaster.setSchemeStatus("Intial");
				if(rs.getString("SCM_STATUS").equals("W"))
				schemeMaster.setSchemeStatus("Waiting for Submit");
				if(rs.getString("SCM_STATUS").equals("D"))
				schemeMaster.setSchemeStatus("Draft");
				if(rs.getString("SCM_STATUS").equals("R"))
				schemeMaster.setSchemeStatus("Rejected");
				if(rs.getString("SCM_STATUS").equals("A"))
				schemeMaster.setSchemeStatus("Approved");
				if(rs.getString("SCM_STATUS").equals("C"))
				schemeMaster.setSchemeStatus("Closed");
				if(rs.getString("SCM_STATUS").equals("F"))
					schemeMaster.setSchemeStatus("Failed");
		}
		
		if(rs.getString("reason")!=null)
				schemeMaster.setRemarks(rs.getString("reason"));
		else
		{
			if(rs.getString("SCM_STATUS").equals("F"))
				schemeMaster.setRemarks("Failed");
		}
				schemeMaster.setPayTo(rs.getString("display_value"));
				schemeMaster.setCompName(rs.getString("componenet_name"));
				//component_id
				schemeMaster.setCompId(rs.getInt("component_id"));
				return schemeMaster;
		}
			
		});
		
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || searchSchemeSubmit ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}	
		//logger.debug("End SchemeSearchDAOImpl searchSchemeSubmit ");
		return covList;

	}


	
	@Override
	public List<SchemeMaster> searchSchemeApprove(SearchScheme schemeName) {
		//logger.debug("Begin SchemeSearchDAOImpl searchSchemeApprove ");
		
		List<SchemeMaster> covList  = new ArrayList<SchemeMaster>();
		try 
		{
		String scmId = "%"+(schemeName.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(schemeName.getSchemeComp())?"":schemeName.getSchemeId())+"%";
		String scmName = "%"+(schemeName.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(schemeName.getSchemeComp())?"":schemeName.getSchemeComp())+"%";
		String compName = "%"+("ABCDEF".equalsIgnoreCase(schemeName.getComponentName())?"":schemeName.getComponentName())+"%";
		String payTo = "%"+(schemeName.getPayTo()==-1?"":schemeName.getPayTo())+"%";
		
		String query = "SELECT SM.SCHEME_ID,  SM.SCHEME_NAME,  SM.INSERT_DATE_TIME,  CM.COMPONENT_ID,  CM.COMPONENET_NAME,  CM.REASON,  DECODE(CM.VTOPUP_FILE_FLAG,NULL,'','Y','Yes','N','No') AS VTOPUP_FILE_FLAG," +
				"  TO_CHAR(CM.START_DATE,'DD-MON-YYYY') AS START_DATE ,  TO_CHAR(CM.END_DATE,'DD-MON-YYYY') AS END_DATE ,  CM.PAY_TO,  DECODE(CM.SCM_STATUS,'A','Approve') AS SCM_STATUS," +
				"  EM.DISPLAY_VALUE,  EXEC.FREQUENCY,  EXEC.SCM_EXEC_START_DATE,  EXEC.SCM_EXEC_END_DATE,  EXEC.STMT_DATE,  EXEC.PAYOUT_APPROVAL_DATE,  MAX(DSP1.INSERT_DATE_TIME) EXECUTION_DATE," +
				"   SUM(DSP1.NET_VALUE) AMOUNT,  MIN(DSP1.NET_VALUE) MIN_AMOUNT,  MAX(DSP1.NET_VALUE) MAX_AMOUNT FROM DLP_SCHEME_MASTER SM,  DLP_SCM_EXECUTION_CALENDER EXEC,  DLP_SCHEME_COMP_MAPPING CM  ," +
				"  DLP_ENTITY_TYPE_MASTER EM,  DLP_SCM_PAYOUT_"+schemeName.getCircleCode()+" DSP1 where " +
				" (SM.SCHEME_ID like ? or " +
				" upper(SM.SCHEME_NAME) like upper(?))" +
				" AND upper(CM.COMPONENET_NAME) like upper(?)"+
				" AND DSP1.VALIDITY_FLAG   = 'Y' AND CM.VALIDITY_FLAG     ='Y' and EXEC.VALIDITY_FLAG   ='Y' and CM.SCM_STATUS        ='A' " +
				" and TRUNC(CM.START_DATE) >= to_date(?,'DD-MON-YYYY')  AND TRUNC(CM.END_DATE)  <= to_date(?,'DD-MON-YYYY') and SM.CIRCLE_ID         = ? "+
				" and DSP1.SCM_ID = EXEC.SCM_ID and EXEC.SCM_ID = SM.SCHEME_ID AND SM.SCHEME_ID = CM.SCHEME_ID and DSP1.COMP_ID = EXEC.COMP_ID and EXEC.COMP_ID = CM.COMPONENT_ID" +
				" AND EXEC.CIRCLE_ID = ? AND SM.VALIDITY_FLAG  = CM.VALIDITY_FLAG AND CM.PAY_TO like ? AND CM.PAY_TO = EM.ENTITY_TYPE_ID " +
				" GROUP BY SM.SCHEME_ID,  SM.SCHEME_NAME,  SM.INSERT_DATE_TIME,  CM.COMPONENT_ID,  CM.COMPONENET_NAME,  CM.REASON,  VTOPUP_FILE_FLAG,  CM.START_DATE," +
				" CM.END_DATE,  CM.PAY_TO,  SCM_STATUS,  EM.DISPLAY_VALUE,  EXEC.FREQUENCY,  EXEC.SCM_EXEC_START_DATE,  EXEC.SCM_EXEC_END_DATE,  EXEC.STMT_DATE," +
				" EXEC.PAYOUT_APPROVAL_DATE  ";//ORDER BY SM.INSERT_DATE_TIME DESC

		//////System.out.println("searchSchemeApprove Query:  "+query);
		////logger.debug("searchSchemeApprove query :: "+query+" scmId::"+scmId+" scmName::"+scmName+" compName::"+compName+" stDt::"+schemeName.getStartDate()+" endDt::"+schemeName.getEndDate()+" circleId::"+schemeName.getCircleId()+" payTo::"+payTo);
		
		 covList = jdbcTemplate.query(query, new Object[]{scmId, scmName, compName, schemeName.getStartDate(), schemeName.getEndDate(), schemeName.getCircleId(), schemeName.getCircleId(), payTo}, new RowMapper<SchemeMaster>() {
			@Override
			public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeMaster schemeMaster = new SchemeMaster();
				schemeMaster.setSchemeINputId(rs.getInt("SCHEME_ID"));
				schemeMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				schemeMaster.setCompId(rs.getInt("COMPONENT_ID"));
				schemeMaster.setCompName(rs.getString("COMPONENET_NAME"));
				schemeMaster.setInsertTime(rs.getDate("INSERT_DATE_TIME"));
				schemeMaster.setPayTo(rs.getString("DISPLAY_VALUE"));
				schemeMaster.setStartDate(rs.getString("START_DATE"));
				schemeMaster.setEndDate(rs.getString("END_DATE"));
				schemeMaster.setSchemeStatus(rs.getString("SCM_STATUS"));
				schemeMaster.setVtopUpFlag(rs.getString("VTOPUP_FILE_FLAG"));
				schemeMaster.setRemarks(rs.getString("REASON"));
				schemeMaster.setExecDate(rs.getDate("EXECUTION_DATE"));
				
				//schemeMaster.setRegion(rs.getString("REGION_NAME"));
				//schemeMaster.setZone(rs.getString("ZONE_NAME"));
				
				
				//////System.out.println("rs.getInt(MIN_AMOUNT) :::: "+rs.getString("MIN_AMOUNT"));
				//if(rs.getInt("AMOUNT")>0)
					schemeMaster.setPayAmtStr(rs.getString("AMOUNT"));
				//if(rs.getInt("MIN_AMOUNT")>0)
					schemeMaster.setMaxPayStr(rs.getString("MAX_AMOUNT"));
				//if(rs.getInt("MAX_AMOUNT")>0)
					schemeMaster.setMinPayStr(rs.getString("MIN_AMOUNT"));
				return schemeMaster;
			}
		});
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || searchSchemeApprove ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}	
		//logger.debug("End SchemeSearchDAOImpl searchSchemeApprove ");
		return covList;
	}


	@Override
	public List<SchemeCompNFAList> searchSchemeNFA(SearchScheme schemeName) {
		// TODO Auto-generated method stub
		//logger.debug("Begin SchemeSearchDAOImpl searchSchemeNFA ");
		List<SchemeCompNFAList> covList = new ArrayList<SchemeCompNFAList>();
		try {
		String scmId = "%" +(schemeName.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(schemeName.getSchemeComp())?"":schemeName.getSchemeId())+"%";
		String scmName = "%" +(schemeName.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(schemeName.getSchemeComp())?"":schemeName.getSchemeComp())+"%";
		String compName = "%"+("ABCDEF".equalsIgnoreCase(schemeName.getComponentName())?"":schemeName.getComponentName())+"%";
		String payTo = "%"+(schemeName.getPayTo()==-1?"":schemeName.getPayTo())+"%";
		
		String query = null;
		 if(schemeName != null){
			 query = " select c.*,(select count(1) from ( select SM.SCHEME_ID,SM.SCHEME_NAME, SM.INSERT_DATE_TIME,CM.COMPONENT_ID, CM.COMPONENET_NAME," +
			 		" TO_CHAR(CM.START_DATE,'DD-MON-YYYY') as STARTDATE, TO_CHAR(CM.END_DATE,'DD-MON-YYYY') as ENDDATE, CM.PAY_TO," +
			 		" DECODE(CM.SCM_STATUS,'D','Draft','A','Approve','R','Reject') as SCM_STATUS, CM.REASON, CM.CATEGORY_ID, EM.DISPLAY_VALUE  ," +
			 		" CM.last_execution_date as EXECUTION_DATE from DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM , DLP_ENTITY_TYPE_MASTER EM where " +
			 		" SM.SCHEME_ID = CM.SCHEME_ID and ( SM.SCHEME_ID like  ?  " +
			 		" or SM.SCHEME_NAME like ? ) " +
			 		" AND upper(CM.COMPONENET_NAME) like upper( ? ) "+
			 		" and CM.SCM_STATUS = ? and TRUNC(CM.START_DATE) >= to_date(?,'DD-MON-YYYY') " +
			 		" and TRUNC(CM.END_DATE) <= to_date(?,'DD-MON-YYYY')  and SM.CIRCLE_ID = ? and SM.VALIDITY_FLAG=CM.VALIDITY_FLAG " +
			 		" AND CM.PAY_TO like  ?  and CM.PAY_TO = EM.ENTITY_TYPE_ID and CM.VALIDITY_FLAG='Y')) NO_OF_RECORDS " +
			 		" from ( select  a.*,rownum ROW_NUM from ( " +
			 		" select  b.* from  ( select SM.SCHEME_ID,SM.SCHEME_NAME, SM.INSERT_DATE_TIME,CM.COMPONENT_ID, CM.COMPONENET_NAME," +
			 		" TO_CHAR(CM.START_DATE,'DD-MON-YYYY') as STARTDATE, TO_CHAR(CM.END_DATE,'DD-MON-YYYY') as ENDDATE, " +
			 		" CM.PAY_TO,DECODE(CM.SCM_STATUS,'D','Draft','A','Approve','R','Reject') as SCM_STATUS, CM.REASON, CM.CATEGORY_ID, EM.DISPLAY_VALUE  ," +
			 		" CM.last_execution_date as EXECUTION_DATE from DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM , DLP_ENTITY_TYPE_MASTER EM where " +
			 		" SM.SCHEME_ID = CM.SCHEME_ID and ( SM.SCHEME_ID like  ? " +
			 		" or SM.SCHEME_NAME like ? )  " +
			 		" AND upper(CM.COMPONENET_NAME) like upper(?)"+
			 		" AND CM.SCM_STATUS = ? and TRUNC(CM.START_DATE) >= to_date(?,'DD-MON-YYYY') " +
			 		" AND TRUNC(CM.END_DATE) <= to_date(?,'DD-MON-YYYY')  and SM.CIRCLE_ID = ? and SM.VALIDITY_FLAG=CM.VALIDITY_FLAG " +
			 		" AND CM.PAY_TO like ? and CM.PAY_TO = EM.ENTITY_TYPE_ID and CM.VALIDITY_FLAG='Y'  order by SM.INSERT_DATE_TIME, cm.component_id desc ) b ) a) c where ROW_NUM between "+(schemeName.getStart()+1)+" AND "+(schemeName.getStart()+schemeName.getLimit());
		}
		
		 ////logger.debug("Scheme Search Query NFA:  "+query+" \t scmId:: "+scmId +" \t scmName:: "+scmName+" \t compName:: "+compName+" \t scmStatus:: "+schemeName.getCondParam()+" \t scmStartDt:: "+schemeName.getStartDate()+" \t scmEndDt:: "+schemeName.getEndDate()+" \t circleId:: "+schemeName.getCircleId()+" \t payTo:: "+payTo);
		
		 covList = jdbcTemplate.query(query, new Object[]{scmId, scmName, compName, schemeName.getCondParam(), schemeName.getStartDate(), schemeName.getEndDate(), schemeName.getCircleId(), payTo, scmId, scmName, compName, schemeName.getCondParam(), schemeName.getStartDate(), schemeName.getEndDate(), schemeName.getCircleId(), payTo}, new RowMapper<SchemeCompNFAList>() {
			@Override
			public SchemeCompNFAList mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeCompNFAList schemeMaster = new SchemeCompNFAList();
				schemeMaster.setSchemeINputId(rs.getInt("SCHEME_ID"));
				schemeMaster.setCompId(rs.getInt("COMPONENT_ID"));
				schemeMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				schemeMaster.setCompName(rs.getString("COMPONENET_NAME"));
				schemeMaster.setStartDate(rs.getString("STARTDATE"));
				schemeMaster.setEndDate(rs.getString("ENDDATE"));
				schemeMaster.setPayout(rs.getString("DISPLAY_VALUE"));
				schemeMaster.setInsertTime(rs.getDate("INSERT_DATE_TIME"));
				schemeMaster.setValidityFlag(rs.getString("SCM_STATUS"));
				schemeMaster.setExecutionDate(rs.getDate("EXECUTION_DATE"));
				schemeMaster.setTotalCount(rs.getInt("NO_OF_RECORDS"));
				schemeMaster.setRemarks(rs.getString("REASON"));
				schemeMaster.setCategoryId(rs.getInt("CATEGORY_ID"));
				return schemeMaster;
			}
		});
		//logger.debug("End SchemeSearchDAOImpl searchSchemeNFA ");
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || searchSchemeNFA ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}	
		return covList;
	}
	

	@Override
	public List<SchemeMaster> searchSchemeExecCal(SearchScheme schemeName) {
		String query =null;	
		final int filterType = schemeName.getFilterBy();
		Object[] object = null;
		//logger.debug("Entered into DAO searchSchemeExecCal ");
		List<SchemeMaster> covList = new ArrayList<SchemeMaster>();
		try {
		if(schemeName.getFilterBy()==0){
			
			query = "SELECT SM.SCHEME_ID, SM.SCHEME_NAME,SM.INSERT_DATE_TIME,CM.COMPONENT_ID,CM.COMPONENET_NAME,CM.REASON,DECODE(CM.VTOPUP_FILE_FLAG,NULL,'','Y','Yes','N','No') AS VTOPUP_FILE_FLAG," +
					" TO_CHAR(CM.START_DATE,'DD-MON-YYYY') AS START_DATE , TO_CHAR(CM.END_DATE,'DD-MON-YYYY') AS END_DATE ,CM.PAY_TO," +
					" DECODE(CM.SCM_STATUS,'A','Approve') AS SCM_STATUS, EM.DISPLAY_VALUE,EXEC.FREQUENCY,EXEC.SCM_EXEC_START_DATE,EXEC.SCM_EXEC_END_DATE," +
					" EXEC.STMT_DATE,EXEC.PAYOUT_APPROVAL_DATE FROM DLP_SCHEME_MASTER SM,DLP_SCM_EXECUTION_CALENDER EXEC,DLP_SCHEME_COMP_MAPPING CM" +
					",DLP_ENTITY_TYPE_MASTER EM,DLP_SCM_PAYOUT_"+schemeName.getCircleCode()+" DSP1 WHERE DSP1.SCM_ID(+)=EXEC.SCM_ID AND DSP1.COMP_ID(+)=EXEC.COMP_ID AND EXEC.CIRCLE_ID = ? " +
					" AND DSP1.VALIDITY_FLAG(+)='Y' AND SM.SCHEME_ID = CM.SCHEME_ID AND CM.SCM_STATUS='A' AND TRUNC(CM.START_DATE) = ? AND TRUNC(CM.END_DATE) <= ? " +
					" AND SM.CIRCLE_ID = ?  AND EXEC.SCM_ID=SM.SCHEME_ID  AND EXEC.COMP_ID= CM.COMPONENT_ID AND SM.VALIDITY_FLAG=CM.VALIDITY_FLAG AND CM.PAY_TO = EM.ENTITY_TYPE_ID" +
					" AND CM.VALIDITY_FLAG='Y' AND EXEC.VALIDITY_FLAG='Y' GROUP BY SM.SCHEME_ID, SM.SCHEME_NAME,SM.INSERT_DATE_TIME,CM.COMPONENT_ID,CM.COMPONENET_NAME,CM.REASON,DECODE(CM.VTOPUP_FILE_FLAG,NULL,'','Y','Yes','N','No')," +
					" TO_CHAR(CM.START_DATE,'DD-MON-YYYY'),TO_CHAR(CM.END_DATE,'DD-MON-YYYY'),CM.PAY_TO,DECODE(CM.SCM_STATUS,'A','Approve'),EM.DISPLAY_VALUE,EXEC.FREQUENCY," +
					" EXEC.SCM_EXEC_START_DATE,EXEC.SCM_EXEC_END_DATE,EXEC.STMT_DATE,EXEC.PAYOUT_APPROVAL_DATE ORDER BY SM.INSERT_DATE_TIME DESC";
			object = new Object[]{schemeName.getCircleId(), schemeName.getStartDate(), schemeName.getEndDate(), schemeName.getCircleId()};
		}else 
		{
			query ="select  SM.SCHEME_ID, SM.SCHEME_NAME,  SM.INSERT_DATE_TIME, CM.COMPONENT_ID, CM.COMPONENET_NAME," +
					"  TO_CHAR(CM.START_DATE,'DD-MON-YYYY') as START_DATE, TO_CHAR(CM.END_DATE,'DD-MON-YYYY') as END_DATE, DECODE(CM.SCM_STATUS,'C','Closed') as SCM_STATUS,  EM.DISPLAY_VALUE" +
					" from DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM,DLP_ENTITY_TYPE_MASTER EM  where  SM.SCHEME_ID = CM.SCHEME_ID and CM.PAY_TO= 10" +
					" and CM.SCM_STATUS in ('C') and CM.PAYMENT_STATUS in ('U')  and CM.PAYOUT_STATUS in ('A') and TRUNC(CM.START_DATE) >= ?  " +
					" and TRUNC(CM.END_DATE) <= ?  and SM.CIRCLE_ID = ?  and SM.VALIDITY_FLAG=CM.VALIDITY_FLAG  and CM.PAY_TO = EM.ENTITY_TYPE_ID " +
					" and CM.VALIDITY_FLAG='Y' order by SM.INSERT_DATE_TIME desc";
			object = new Object[]{schemeName.getStartDate(), schemeName.getEndDate(), schemeName.getCircleId() };
		}		 		

		////logger.debug("filterType :: "+filterType+" Query:  "+query);
		
		 covList = jdbcTemplate.query(query, object, new RowMapper<SchemeMaster>() {
			@Override
			public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeMaster schemeMaster = new SchemeMaster();
				schemeMaster.setSchemeINputId(rs.getInt("scheme_id"));
				schemeMaster.setSchemeName(rs.getString("scheme_name"));
				schemeMaster.setCompName(rs.getString("componenet_name"));
				schemeMaster.setCompId(rs.getInt("COMPONENT_ID"));
				schemeMaster.setInsertTime(rs.getDate("insert_date_time"));
				schemeMaster.setStartDate(rs.getString("start_date"));
				schemeMaster.setEndDate(rs.getString("end_date"));
				schemeMaster.setPayTo(rs.getString("DISPLAY_VALUE"));
				schemeMaster.setSchemeStatus(rs.getString("SCM_STATUS"));
		
		if(rs.getString("reason")!=null)
				schemeMaster.setRemarks(rs.getString("reason"));
				if(filterType == 0){
				//schemeMaster.setPayTo(rs.getString("display_value"));
				if(rs.getString("frequency")!=null)		
				schemeMaster.setExecFreq(rs.getString("frequency"));
				if(rs.getDate("scm_exec_start_date")!=null)
				schemeMaster.setExecStartDate(rs.getDate("scm_exec_start_date"));
				if(rs.getDate("scm_exec_end_date")!=null)
				schemeMaster.setExecEndDate(rs.getDate("scm_exec_end_date"));
				if(rs.getDate("payout_approval_date")!=null)
				schemeMaster.setPayoutAppDate(rs.getDate("payout_approval_date"));
				if(rs.getDate("stmt_date")!=null)
				schemeMaster.setStmGenDate(rs.getDate("stmt_date"));
				}
				return schemeMaster;
			}
		});
		
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || searchSchemeExecCal ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}	
		logger.info("End  SchemeSearchDAOImpl searchSchemeExecCal ");
		return covList;
	}


	@Override
	public void updateCalander(UpdateCalander cal) {
		//logger.debug("Begin SchemeSearchDAOImpl updateCalander ");
		String sql = "update dlp_scm_execution_calender " +
				" set SCM_EXEC_START_DATE=?," +
				" SCM_EXEC_END_DATE=?," +
				" PAYOUT_APPROVAL_DATE=?," +
				" STMT_DATE=?" +
				" where scm_id=? and comp_id=? and CIRCLE_ID=?";
		try
		{
			int r = 	jdbcTemplate.update(sql
					,cal.getExecStartDate(),cal.getExecEndDate(),cal.getPayoutAppDate(),cal.getStmGenDate(),cal.getSchemeINputId(),cal.getCompId(),cal.getCircleId());
			////logger.debug("update query : "+r);
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || updateCalander ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}
		//logger.debug("End SchemeSearchDAOImpl updateCalander ");
	}

	
	public void updateVTopUpFileFlag(String vTopUpFlag,int schemeId,int compId) {
		//logger.debug("Begin SchemeSearchDAOImpl updateVTopUpFileFlag ");
		String sql = "UPDATE  DLP_SCHEME_COMP_MAPPING SET VTOPUP_FILE_FLAG = 'Y' WHERE SCHEME_ID=? AND COMPONENT_ID = ?";
		////logger.debug("updateVTopUpFileFlag query:: "+sql);
		try
		{
			jdbcTemplate.update(sql,vTopUpFlag,schemeId,compId);
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || updateVTopUpFileFlag ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}
		//logger.debug("End SchemeSearchDAOImpl updateVTopUpFileFlag ");
	}


	


	@Override
	public List<SchemeMaster> searchSchemeStmGen(SearchScheme schemeName) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String submitSchemePayment(SearchScheme schemeName) {
		//logger.debug("Begin SchemeSearchDAOImpl submitSchemePayment :: DLP_APPROVE_PAYMENT_M ");
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)

		.withProcedureName("DLP_APPROVE_PAYMENT_M");

			Map<String, Object> inParamMap = new HashMap<String, Object>();
			
			inParamMap.put("pCIRCLE_ID", schemeName.getCircleId());
			
			inParamMap.put("pSCM_COMPONENT", schemeName.getSchemeComp());
			inParamMap.put("pUSER_CODE", schemeName.getUserId());
			inParamMap.put("pPAYMENTTYPE", schemeName.getPaymentType());
			inParamMap.put("pPAYMENTREMARKS", schemeName.getPaymentRemarks());
			inParamMap.put("pPAYTO", schemeName.getPayTo());
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);

			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);

			//logger.debug("Payment submit "+simpleJdbcCallResult);
		
			//logger.debug("End SchemeSearchDAOImpl submitSchemePayment ");
			return simpleJdbcCallResult.toString();//+"detail "+schemeName.getSchemeComp()+" payTo :"+schemeName.getPayTo()+schemeName.getUserId();

	}
	
	public List<SchemeMaster> searchSchemePayment(SearchScheme schemeName) {
		//logger.debug("Begin SchemeSearchDAOImpl searchSchemePayment ");
		List<SchemeMaster> covList = new ArrayList<SchemeMaster>();
		try {
		String query =null;	
					query ="select  SM.SCHEME_ID, SM.SCHEME_NAME,  SM.INSERT_DATE_TIME, CM.COMPONENT_ID, CM.COMPONENET_NAME," +
					"  TO_CHAR(CM.START_DATE,'DD-MON-YYYY') as START_DATE, TO_CHAR(CM.END_DATE,'DD-MON-YYYY') as END_DATE, DECODE(CM.SCM_STATUS,'C','Closed') as SCM_STATUS,  EM.DISPLAY_VALUE" +
					" from DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM,DLP_ENTITY_TYPE_MASTER EM  where  SM.SCHEME_ID = CM.SCHEME_ID and CM.PAY_TO = ? " +
					" and CM.SCM_STATUS in ('C') and CM.PAYMENT_STATUS in ('U')  and CM.PAYOUT_STATUS in ('A') and TRUNC(CM.START_DATE) >= ?  " +
					" and TRUNC(CM.END_DATE) <= ? and SM.CIRCLE_ID = ?  and SM.VALIDITY_FLAG=CM.VALIDITY_FLAG  and CM.PAY_TO = EM.ENTITY_TYPE_ID " +
					" and CM.VALIDITY_FLAG='Y' order by SM.INSERT_DATE_TIME desc";
		 		
				//	//logger.debug("searchSchemePayment Query:  "+query);
		
		 covList = jdbcTemplate.query(query, new Object[]{schemeName.getPayTo(), schemeName.getStartDate(), schemeName.getEndDate(), schemeName.getCircleId()}, new RowMapper<SchemeMaster>() {

			@Override
			public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeMaster schemeMaster = new SchemeMaster();
				schemeMaster.setSchemeINputId(rs.getInt("scheme_id"));
				schemeMaster.setSchemeName(rs.getString("scheme_name"));
				schemeMaster.setCompName(rs.getString("componenet_name"));
				schemeMaster.setCompId(rs.getInt("COMPONENT_ID"));
				schemeMaster.setInsertTime(rs.getDate("insert_date_time"));
				schemeMaster.setStartDate(rs.getString("start_date"));
				schemeMaster.setEndDate(rs.getString("end_date"));
				schemeMaster.setPayTo(rs.getString("DISPLAY_VALUE"));
				schemeMaster.setSchemeStatus(rs.getString("SCM_STATUS"));
		
				return schemeMaster;
			}
		});
		
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || searchSchemePayment ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}
		//logger.debug("End SchemeSearchDAOImpl searchSchemePayment ");
		return covList;
	}


	@Override
	public String submitSchemeChange(SearchScheme schemeName) {
		//logger.debug("Begin SchemeSearchDAOImpl submitSchemeChange :: DLP_SCM_REVISION");
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)

		.withProcedureName("DLP_SCM_REVISION");

			Map<String, Object> inParamMap = new HashMap<String, Object>();
			
			inParamMap.put("pCIRCLE_ID", schemeName.getCircleId());
			
			inParamMap.put("pSCHEME_ID", schemeName.getSchemeId());
			inParamMap.put("pCOMP_ID", schemeName.getCompId());
			inParamMap.put("pUSER_CODE", schemeName.getUserId());
			inParamMap.put("pCOMMENTS", schemeName.getChangeDesc());
			
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);

			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);

			//logger.debug("Change Request "+simpleJdbcCallResult);
		
			//logger.debug("End SchemeSearchDAOImpl submitSchemeChange ");
			return simpleJdbcCallResult.toString();//+"detail "+schemeName.getSchemeComp()+" payTo :"+schemeName.getPayTo()+schemeName.getUserId();
	}


	public List<CompMaster> searchTransactionData(String filtertype, String startDate, String endDate, int circleId,SearchScheme schemeName){
		//logger.debug("Begin SchemeSearchDAOImpl searchTransactionData ");
		List<CompMaster> compList = new ArrayList<CompMaster>();
		try {
		String query =null;	
		String scmId = "%"+(schemeName.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(schemeName.getSchemeComp())?"":schemeName.getSchemeId())+"%";
		String scmName = "%"+(schemeName.getSchemeId()==-1 && "ABCDEF".equalsIgnoreCase(schemeName.getSchemeComp())?"":schemeName.getSchemeComp())+"%";
		String compName = "%"+("ABCDEF".equalsIgnoreCase(schemeName.getComponentName())?"":schemeName.getComponentName())+"%";
		String payTo = "%"+(schemeName.getPayTo()==-1?"":schemeName.getPayTo())+"%";
		
		query = " select CM.SCHEME_ID,SM.SCHEME_NAME,CM.COMPONENT_ID,CM.COMPONENET_NAME,TO_CHAR( TO_CHAR(CM.START_DATE,'DD-MON-YYYY') || ' - ' || TO_CHAR(CM.END_DATE,'DD-MON-YYYY')) as START_END_DT,"+
				" TO_CHAR(CM.START_DATE,'DD-MON-YYYY') as STARTDATE, TO_CHAR(CM.END_DATE,'DD-MON-YYYY') as ENDDATE, " +
				" DECODE(CM.SCM_STATUS,'R','Rejected','A','Approved','D','Draft','O','Open for edit','C','Closed','F','Fail') SCM_STATUS, EM.DISPLAY_VALUE," +
				" CM.PAYOUT_STATUS,CM.PAYMENT_STATUS,SM.CIRCLE_ID from DLP_SCHEME_COMP_MAPPING CM, DLP_SCHEME_MASTER SM, DLP_ENTITY_TYPE_MASTER EM" +
				" WHERE (SM.SCHEME_ID like  ?  or " +
				" upper(SM.SCHEME_NAME) like upper(?))" +
				" AND upper(CM.COMPONENET_NAME) like upper(?)" +
				" AND CM.PAY_TO like ? " +
				" AND TRUNC(CM.START_DATE)>= ? " +
				" AND TRUNC(CM.END_DATE)  <= ? " +
				" AND SM.CIRCLE_ID         =  ? " +
				" AND CM.PAY_TO            = EM.ENTITY_TYPE_ID" +
				" AND SM.SCHEME_ID       = CM.SCHEME_ID" +
				" AND SM.VALIDITY_FLAG     =CM.VALIDITY_FLAG" +
				" AND CM.VALIDITY_FLAG     ='Y'" +
				" ORDER BY CM.INSERT_DATE_TIME DESC ";
		
		////logger.debug("TransactionData Query:  "+query);
		 compList = jdbcTemplate.query(query, new Object[]{scmId, scmName, compName, payTo, startDate, endDate, circleId}, new RowMapper<CompMaster>() {
			@Override
			public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompMaster compMaster = new CompMaster();
				compMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				compMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				compMaster.setCompName(rs.getString("COMPONENET_NAME"));
				compMaster.setCompId(rs.getInt("COMPONENT_ID"));
				compMaster.setStartDtStr(rs.getString("STARTDATE"));
				compMaster.setEndDtStr(rs.getString("ENDDATE"));
				compMaster.setScmStatus(rs.getString("SCM_STATUS"));
				compMaster.setPayoutStatus(rs.getString("PAYOUT_STATUS"));
				compMaster.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
				compMaster.setPayToName(rs.getString("DISPLAY_VALUE"));
				return compMaster;
			}
		});
		
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || searchTransactionData ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}
		//logger.debug("End SchemeSearchDAOImpl searchTransactionData ");
		return compList;
	}
	
	
	public List<SchemeTqMaster> getTransactionSubData(final String filtertype,int schemeId,int compId,int circleId,String circleCode){
		//logger.debug("Begin SchemeSearchDAOImpl getTransactionSubData ");
		String query =null;	
		Object[] object = null;
		List<SchemeTqMaster> tqList = new ArrayList<SchemeTqMaster>();
		try {
		/*query = " select SM.SCHEME_ID,SM.SCHEME_NAME,TQ.COMPONENT_ID,CM.COMPONENET_NAME,TQ.CONDITION_NAME from DLP_SCM_TQ_COND_CONFIG TQ, DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM" +
				" where  SM.SCHEME_ID=CM.SCHEME_ID and SM.SCHEME_ID=TQ.SCHEME_ID and CM.COMPONENT_ID=TQ.COMPONENT_ID and SM.VALIDITY_FLAG=TQ.VALIDITY_FLAG and" +
				" CM.VALIDITY_FLAG=TQ.VALIDITY_FLAG and TQ.SCHEME_ID = "+schemeId+" and TQ.COMPONENT_ID="+compId+" and TQ.VALIDITY_FLAG='Y'";*/
	//	////System.out.println("filtertype :: "+filtertype);
		if("EA".equalsIgnoreCase(filtertype)){
			 query = " SELECT SCHEME_ID,COMPONENT_ID,VARIABLE_ID AS CONDITION_ID,VARIABLE_NAME AS CONDITION_NAME,VARIABLE_NAME||'('||ENTITY_TYPE||') = '||FUNCTION||'('||PARAMETER||') '||OPR||' '||VALUE||DECODE(START_DATE,NULL,'',' between '||START_DATE||' and '||END_DATE) AS CONDITION," +
						" DECODE(DATA_SET,1,'Note: '||PARAMETER||' belongs to defined condition '||DATA_SOURCE,'') AS NOTE  from( SELECT EA.SCHEME_ID,EA.COMPONENT_ID,EA.VARIABLE_ID,EA.VARIABLE_NAME," +
						//" (SELECT ET.DISPLAY_VALUE FROM DLP_ENTITY_TYPE_MASTER ET WHERE ET.VALIDITY_FLAG='Y' AND ET.ENTITY_TYPE_ID=EA.ENTITY_TYPE) AS ENTITY_TYPE," +
						" (LTRIM((" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%11%') THEN 'Date (Universe Key)' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%10%') THEN 'Network_Type' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%9%') THEN ',Delivery_Bearer' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%8%') THEN ',Keyword' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%7%') THEN ',Service_Type' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%6%') THEN ',CP' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%5%') THEN ',Platform' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%4%') THEN ',CP+Platform' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%3%') THEN ',Circle Head' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%2%') THEN ',Operation Head' END||" +
						"  CASE WHEN EA.ENTITY_TYPE LIKE ('%1%') THEN ',MD' END" +
						"  ),',')) AS ENTITY_TYPE," +
						" (SELECT FM.DISPLAY_VALUE FROM DLP_TBL_FUNCTION_MASTER FM WHERE FM.VALIDITY_FLAG='Y' AND FM.ENTITY_AGG_FLAG='Y' AND FM.FUNCTION_ID=EA.FUNCTION) AS FUNCTION," +
						" DECODE(EA.DATA_SET,1,(SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID = ? AND UF.UNI_FLD_SEQ_NO=EA.PARAMETER),EA.PARAMETER) AS PARAMETER," +
						" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.EA_VAR_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R','A') AND OM.OPERATOR_ID=EA.OPR) AS OPR," +
						" EA.VALUE,TO_CHAR(EA.START_DATE,'DD-Mon-YYYY') AS START_DATE,TO_CHAR(EA.END_DATE,'DD-Mon-YYYY') AS END_DATE," +
						" DECODE(EA.DATA_SET,1,(SELECT TQ.CONDITION_NAME FROM DLP_SCM_TQ_COND_CONFIG TQ WHERE TQ.VALIDITY_FLAG='Y' AND TQ.SCHEME_ID=EA.SCHEME_ID AND TQ.COMPONENT_ID=EA.COMPONENT_ID AND TQ.CONDITION_ID=EA.COND_ID AND ROWNUM=1),EA.DATA_SOURCE) AS DATA_SOURCE," +
						" EA.DATA_SET FROM DLP_SCM_EA_COND_CONFIG EA WHERE EA.VALIDITY_FLAG='Y' AND EA.SCHEME_ID = ?  AND EA.COMPONENT_ID = ? ) ORDER BY VARIABLE_ID ASC";
			 
			 object = new Object[]{circleId, schemeId, compId};
			 
	}else if("PO".equalsIgnoreCase(filtertype)){
			 query = " SELECT SCHEME_ID,COMPONENT_ID,CONDITION_ID,INPUT_PARAM||' '||OPR||' '||VALUE||DECODE(START_DATE,'','',' between '||START_DATE||' and '||END_DATE)||DECODE(LOPR,'Add New Condition','','Close Condition','',' '||LOPR) AS CONDITION," +
			 		" DECODE(LOPR,'Add New Condition','1','Close Condition','1','0') AS NEXT_COND," +
			 		" GROSS_NET, AMOUNT, VARIABLE AS CONDITION_NAME, OVER_ACHIEVEMENT, UNDER_ACHIEVEMENT,UNIT" +
			 		" from(" +
			 		" SELECT PO.SCHEME_ID,PO.COMPONENT_ID,PO.CONDITION_ID,PO.CONDITION_ROW_ID," +
			 		" DECODE(PO.INPUT_TYPE,6,PO.INPUT_PARAMETER,(SELECT EA.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING EA WHERE EA.VALIDITY_FLAG='Y' AND EA.PAY_COND_FLAG='Y' AND EA.ATTR_SEQ_NO=PO.INPUT_PARAMETER)) AS INPUT_PARAM," +
			 		" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.PO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=PO.OPR) AS OPR," +
			 		" PO.VALUE,TO_CHAR(PO.START_DATE,'DD-Mon-YYYY') AS START_DATE,TO_CHAR(PO.END_DATE,'DD-Mon-YYYY') AS END_DATE," +
			 		" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.PO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L','M') AND OM.OPERATOR_ID=PO.LOPR) AS LOPR," +
			 		" PM.GROSS_NET, PM.AMOUNT, PM.VARIABLE, PM.OVER_ACHIEVEMENT, PM.UNDER_ACHIEVEMENT," +
			 		" (SELECT UM.DISPLAY_VALUE FROM DLP_UNIT_MASTER UM WHERE UM.VALIDITY_FLAG='Y' AND UM.UNIT_ID=PM.UNIT) AS UNIT" +
			 		" from DLP_SCM_PO_COND_CONFIG PO,DLP_SCM_PO_AMT_CONFIG PM" +
			 		" WHERE PO.VALIDITY_FLAG='Y' AND PO.SCHEME_ID= ?  AND PO.COMPONENT_ID = ? " +
			 		" AND PM.VALIDITY_FLAG='Y' AND PM.SCHEME_ID=PO.SCHEME_ID AND PM.COMPONENT_ID=PO.COMPONENT_ID AND PM.CONDITION_ID=PO.CONDITION_ID)" +
			 		" ORDER BY CONDITION_ID,CONDITION_ROW_ID ASC ";
		
			 object = new Object[]{schemeId, compId};
			 
		}else if("PD".equalsIgnoreCase(filtertype)){
			 query = " SELECT COUNT(1) AS HEADCOUNT, ROUND(SUM(case  when GROSS_NET= 'Gross' then GROSS_VALUE else NET_VALUE end),2) as TOTAL_AMOUNT," +
			 		" ROUND(AVG(case  when GROSS_NET= 'Gross' then GROSS_VALUE  else NET_VALUE end),2) as AVERAGE_AMOUNT," +
			 		" ROUND(max(case  when GROSS_NET= 'Gross' then GROSS_VALUE else NET_VALUE end),2) as MAX_AMOUNT," +
			 		" ROUND(min(case  when GROSS_NET= 'Gross' then GROSS_VALUE else NET_VALUE end),2) as MIN_AMOUNT " +
			 		" FROM DLP_SCM_PAYOUT_"+circleCode+"  where SCM_ID = ? and COMP_ID = ? and VALIDITY_FLAG='Y' and " +
			 		" RE_CONFIG_ID = ( select max(RE_CONFIG_ID) from DLP_SCM_PAYOUT_"+circleCode+" where SCM_ID = ? "+
			 		" AND COMP_ID  = ? AND VALIDITY_FLAG='Y' )";// and CIRCLE_CODE='"+circleCode+"'";
			 object = new Object[]{schemeId, compId, schemeId, compId};
		}
		
		else if("COV".equalsIgnoreCase(filtertype)){
			
			List<SchemeTqMaster> tqList1=getTransactionSubCOVData( filtertype, schemeId, compId, circleId);
			if(tqList1 != null && tqList1.size()!=0){
				return tqList1;
			}
			query = " SELECT SCHEME_ID,COMPONENT_ID,CONDITION_ID,CONDITION_ROW_ID,ENTITY_TYPE||'''s '||ATTRIBUTE_NAME||' '||DECODE(OPR,'Date Range','is between '||START_DATE||' and '||END_DATE,OPR||' '||VALUE)||' '||LOPR||' '||" +
					" DECODE(L_ENTITY_TYPE,'','',L_ATTRIBUTE_NAME||' '||DECODE(L_OPR,'Date Range','is between '||L_START_DATE||' and '||L_END_DATE,L_OPR||' '||L_VALUE))||DECODE(ROPR,'Add New Condition','','Close Configration','',' '||ROPR) AS CONDITION" +
					" from( SELECT CC.SCHEME_ID,CC.COMPONENT_ID,CC.CONDITION_ID,CC.CONDITION_ROW_ID,(SELECT ET.DISPLAY_VALUE FROM DLP_ENTITY_TYPE_MASTER ET WHERE ET.VALIDITY_FLAG='Y' AND ET.ENTITY_TYPE_ID=CC.ENTITY_TYPE) AS ENTITY_TYPE," +
					" (SELECT EA.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING EA WHERE EA.VALIDITY_FLAG='Y' AND EA.ATTR_SEQ_NO=CC.ATTRIBUTE_NAME) AS ATTRIBUTE_NAME," +
					" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.CO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=CC.OPR) AS OPR," +
					"  CC.VALUE, TO_CHAR(CC.START_DATE,'DD-Mon-YYYY') AS START_DATE, TO_CHAR(CC.END_DATE,'DD-Mon-YYYY') AS END_DATE," +
					" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.CO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L') AND OM.OPERATOR_ID=CC.LOPR) AS LOPR," +
					" (SELECT ET.DISPLAY_VALUE FROM DLP_ENTITY_TYPE_MASTER ET WHERE ET.VALIDITY_FLAG='Y' AND ET.ENTITY_TYPE_ID=CC.L_ENTITY_TYPE) AS L_ENTITY_TYPE," +
					" (SELECT EA.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING EA WHERE EA.VALIDITY_FLAG='Y' AND EA.ATTR_SEQ_NO=CC.L_ATTRIBUTE_NAME) AS L_ATTRIBUTE_NAME," +
					" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.CO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=CC.L_OPR) AS L_OPR," +
					"  CC.L_VALUE, TO_CHAR(CC.L_START_DATE,'DD-Mon-YYYY') AS L_START_DATE, TO_CHAR(CC.L_END_DATE,'DD-Mon-YYYY') AS L_END_DATE," +
					" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.CO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L') AND OM.OPERATOR_ID=CC.R_OPR) AS ROPR" +
					" from DLP_SCM_CO_COND_CONFIG CC  where CC.VALIDITY_FLAG='Y' AND CC.SCHEME_ID= ?  AND CC.COMPONENT_ID= ? "+
					" AND CC.ENTITY_TYPE IS NOT NULL) ORDER BY SCHEME_ID DESC";
			
			object = new Object[]{schemeId, compId};
		}
		else{
			/*query = "select SCHEME_ID,COMPONENT_ID,CONDITION_ID,GROUP_ID,CONDITION_ROW_ID,CONDITION_NAME,DATA_SET, " +
					" DECODE(PERF_PARAMETER,'','',(PERF_PARAMETER||' '||DECODE(OPR,'Date Range','is between '||START_DATE||' and '||END_DATE,OPR||' '||value)||' '||LOPR||' '|| " +
					" DECODE(L_PERF_PARAMETER,'','',L_PERF_PARAMETER||' '||DECODE(L_OPR,'Date Range','is between '||L_START_DATE||' and '||L_END_DATE,L_OPR||' '||L_VALUE))||DECODE(ROPR,'Add New Condition','','Close Configration','',' '||ROPR))) as CONDITION," +
					" DECODE(ROPR,'Add New Condition','1','Close Configration','1',0) AS NEXTCOND" +
					" from( SELECT TQ.SCHEME_ID,TQ.COMPONENT_ID, TQ.GROUP_ID,TQ.CONDITION_ID,TQ.CONDITION_ROW_ID,TQ.CONDITION_NAME," +
					" (SELECT DECODE(IP.DISPLAY_VALUE,'Act  Recharge','Activation and Recharge Performance','Retailer','Retailer Performance','Distributor','Distributor Performance',IP.DISPLAY_VALUE) FROM DLP_TBL_INPUT_TYPE_MASTER IP WHERE IP.VALIDITY_FLAG='Y' AND IP.TQ_FLAG='Y' AND IP.INPUT_TYPE_ID=TQ.DATA_SET) AS DATA_SET," +
					" (select UF.UNI_FIELD_DISPLAY_VALUE from DLP_TBL_UNIVERSE_FIELD_MAP UF" +
					" WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID= "+circleId+"  AND UF.UNI_FLD_SEQ_NO=TQ.PERF_PARAMETER) AS PERF_PARAMETER," +
					" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=TQ.OPR) AS OPR," +
					" TQ.VALUE, TO_CHAR(TQ.START_DATE,'DD-MON-YYYY') AS START_DATE, TO_CHAR(TQ.END_DATE,'DD-MON-YYYY') AS END_DATE, (select OM.DISPLAY_VALUE from DLP_OPERATOR_MASTER OM where OM.VALIDITY_FLAG='Y' and OM.TQ_FLAG='Y' and OM.OPERATOR_TYPE in ('L') and OM.OPERATOR_ID=TQ.LOPR) as LOPR," +
					" (SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID= "+circleId+"  AND UF.UNI_FLD_SEQ_NO=TQ.L_PERF_PARAMETER) AS L_PERF_PARAMETER," +
					" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=TQ.L_OPR) AS L_OPR," +
					" TQ.L_VALUE, TO_CHAR(TQ.L_START_DATE,'DD-MON-YYYY') AS L_START_DATE, TO_CHAR(TQ.L_END_DATE,'DD-MON-YYYY') AS L_END_DATE," +
					" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L','M') AND OM.OPERATOR_ID=TQ.ROPR) AS ROPR" +
					" from DLP_SCM_TQ_COND_CONFIG TQ  WHERE TQ.VALIDITY_FLAG='Y' AND TQ.SCHEME_ID = "+schemeId+"   AND TQ.COMPONENT_ID = "+compId+" ) ORDER BY GROUP_ID,CONDITION_ID,CONDITION_ROW_ID ASC";
			*/
			query = "select SCHEME_ID,COMPONENT_ID,CONDITION_ID,GROUP_ID, CONDITION_NAME,DATA_SET,LISTAGG (CONDITION, ' ')" +
					" WITHIN GROUP (ORDER BY condition) AS CONDITION from ( select SCHEME_ID,COMPONENT_ID,CONDITION_ID,GROUP_ID,CONDITION_ROW_ID,CONDITION_NAME,DATA_SET," +
					" DECODE(PERF_PARAMETER,'','',(PERF_PARAMETER||' '||DECODE(OPR,'Date Range','is between '||START_DATE||' and '||END_DATE,OPR||' '||value)||' '||LOPR||' '||" +
					" DECODE(L_PERF_PARAMETER,'','',L_PERF_PARAMETER||' '||DECODE(L_OPR,'Date Range','is between '||L_START_DATE||' and '||L_END_DATE,L_OPR||' '||L_VALUE))||DECODE(ROPR,'Add New Condition','','Close Configration','',' '||ROPR))) as CONDITION," +
					" DECODE(ROPR,'Add New Condition','1','Close Configration','1',0) AS NEXTCOND" +
					" from( SELECT TQ.SCHEME_ID,TQ.COMPONENT_ID, TQ.GROUP_ID,TQ.CONDITION_ID,TQ.CONDITION_ROW_ID,TQ.CONDITION_NAME," +
					" (SELECT DECODE(IP.DISPLAY_VALUE,'Act  Recharge','Activation and Recharge Performance','Retailer','Retailer Performance','Distributor','Distributor Performance',IP.DISPLAY_VALUE) FROM DLP_TBL_INPUT_TYPE_MASTER IP WHERE IP.VALIDITY_FLAG='Y' AND IP.TQ_FLAG='Y' AND IP.INPUT_TYPE_ID=TQ.DATA_SET) AS DATA_SET," +
					" (select UF.UNI_FIELD_DISPLAY_VALUE from DLP_TBL_UNIVERSE_FIELD_MAP UF" +
					"  WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID = ?  AND UF.UNI_FLD_SEQ_NO=TQ.PERF_PARAMETER) AS PERF_PARAMETER," +
					"  (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=TQ.OPR) AS OPR," +
					"  TQ.VALUE, TO_CHAR(TQ.START_DATE,'DD-MON-YYYY') AS START_DATE, TO_CHAR(TQ.END_DATE,'DD-MON-YYYY') AS END_DATE, (select OM.DISPLAY_VALUE from DLP_OPERATOR_MASTER OM where OM.VALIDITY_FLAG='Y' and OM.TQ_FLAG='Y' and OM.OPERATOR_TYPE in ('L') and OM.OPERATOR_ID=TQ.LOPR) as LOPR," +
					"  (SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID = ?  AND UF.UNI_FLD_SEQ_NO=TQ.L_PERF_PARAMETER) AS L_PERF_PARAMETER," +
					"  (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=TQ.L_OPR) AS L_OPR," +
					"  TQ.L_VALUE, TO_CHAR(TQ.L_START_DATE,'DD-MON-YYYY') AS L_START_DATE, TO_CHAR(TQ.L_END_DATE,'DD-MON-YYYY') AS L_END_DATE," +
					"  (select OM.DISPLAY_VALUE from DLP_OPERATOR_MASTER OM where OM.VALIDITY_FLAG='Y' and OM.TQ_FLAG='Y' and OM.OPERATOR_TYPE in ('L','M') and OM.OPERATOR_ID=TQ.ROPR) as ROPR" +
					"  from DLP_SCM_TQ_COND_CONFIG TQ  WHERE TQ.VALIDITY_FLAG='Y' AND TQ.SCHEME_ID = ?   AND TQ.COMPONENT_ID = ? ) ORDER BY GROUP_ID,CONDITION_ID,CONDITION_ROW_ID ASC)" +
					" group by SCHEME_ID,COMPONENT_ID,CONDITION_ID,GROUP_ID, CONDITION_NAME,data_set";
			
			object = new Object[]{circleId, circleId, schemeId, compId};
					
		}
		//////System.out.println("filtertype ::: "+filtertype+"  getTransactionSubData Query:  "+query);
		////logger.debug("SchemeSearchDAOImpl getTransactionSubData filtertype ::: "+filtertype+":: Query:  "+query);
		 tqList = jdbcTemplate.query(query, object, new RowMapper<SchemeTqMaster>() {
			@Override
			public SchemeTqMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeTqMaster tqMaster = new SchemeTqMaster();
				if("PD".equalsIgnoreCase(filtertype))
				{
					tqMaster.setHeadCount(rs.getLong("HEADCOUNT"));
					tqMaster.setGrossnet(rs.getFloat("TOTAL_AMOUNT"));
					tqMaster.setAvgAmt(rs.getFloat("AVERAGE_AMOUNT"));
					tqMaster.setMaxAmt(rs.getFloat("MAX_AMOUNT"));
					tqMaster.setMinAmt(rs.getFloat("MIN_AMOUNT"));
				}else{
					tqMaster.setSchemeId(rs.getInt("SCHEME_ID"));
					tqMaster.setCondId(rs.getInt("CONDITION_ID"));
					tqMaster.setCompId(rs.getInt("COMPONENT_ID"));
					if(!("COV".equalsIgnoreCase(filtertype)))
						tqMaster.setCondName(rs.getString("CONDITION_NAME"));
					tqMaster.setCondition(rs.getString("CONDITION"));
				}
				return tqMaster;
			}
		});
		
		
		 if("COV".equalsIgnoreCase(filtertype) && (tqList==null || tqList.size()==0)){
			 SchemeTqMaster tqMaster = new SchemeTqMaster();
			 tqMaster.setSchemeId(schemeId);
			 tqMaster.setCompId(compId);
			 tqMaster.setCondName("N/A");
			 tqMaster.setCondition("ALL");
			 tqList.add(tqMaster);
		 }
		 
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || getTransactionSubData ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}
		 //logger.debug("End SchemeSearchDAOImpl getTransactionSubData ");
		return tqList;
	}
	
	private List<SchemeTqMaster> getTransactionSubCOVData(String filtertype,int schemeId,int compId,int circleId){
		//logger.debug("Begin SchemeSearchDAOImpl getTransactionSubCOVData ");
		List<SchemeTqMaster> tqList = new ArrayList<SchemeTqMaster>();
		try {
		String query = " SELECT CO.SCHEME_ID, CO.COMPONENT_ID,CASE WHEN CM.FILE_NAME IS NOT NULL THEN TO_CHAR(1)  WHEN CM.FILE_NAME IS  NULL THEN TO_CHAR(CO.CONDITION_ID) end AS CONDITION_ID," +
		 		" CASE WHEN CM.FILE_NAME IS NOT NULL THEN 'LIST' WHEN CM.FILE_NAME IS  NULL THEN TO_CHAR(CO.CONDITION_ROW_ID) end AS CONDITION_NAME," +
		 		" CASE WHEN CM.FILE_NAME IS NOT NULL THEN CM.FILE_NAME end AS CONDITION from DLP_SCM_CO_COND_CONFIG CO,DLP_SCHEME_COMP_MAPPING CM" +
		 		" where CO.SCHEME_ID    = CM.SCHEME_ID AND   CO.COMPONENT_ID = CM.COMPONENT_ID AND CO.VALIDITY_FLAG = CM.VALIDITY_FLAG" +
		 		" AND CM.FILE_NAME IS NOT NULL AND CO.SCHEME_ID = ? AND CO.COMPONENT_ID = ? AND CO.VALIDITY_FLAG='Y'";
		
		////logger.debug(" TransSubCOVData Query:  "+query);
		
		 tqList = jdbcTemplate.query(query, new Object[]{schemeId, compId}, new RowMapper<SchemeTqMaster>() {
			@Override
			public SchemeTqMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeTqMaster tqMaster = new SchemeTqMaster();
				tqMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				//tqMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				tqMaster.setCondId(rs.getInt("CONDITION_ID"));
				tqMaster.setCompId(rs.getInt("COMPONENT_ID"));
				tqMaster.setCondName(rs.getString("CONDITION_NAME"));
				tqMaster.setCondition(rs.getString("CONDITION"));
				
				return tqMaster;
			}
		});
		
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || getTransactionSubCOVData ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}
		//logger.debug("End SchemeSearchDAOImpl getTransactionSubCOVData ");
		return tqList;
	}



	@Override
	public List<CompMaster> loadCompForEdit(SearchScheme searchScheme) {
		List<CompMaster> compMasterList = new ArrayList<CompMaster>();
		//logger.debug("Begin SchemeSearchDAOImpl loadCompForEdit ");
		//String query = "select scheme_id,component_id,componenet_name from dlp_scheme_comp_mapping_stage where validity_flag='Y' AND scm_status in ('W','I','F') union  select scheme_id,component_id,componenet_name from dlp_scheme_comp_mapping where validity_flag='Y' AND scm_status in ('D')";
	try {
		String query = "select scheme_id,component_id,componenet_name from dlp_scheme_comp_mapping_stage where validity_flag='Y' AND scm_status in ('W','I','F')  AND scheme_id= ? union  select scheme_id,component_id,componenet_name from dlp_scheme_comp_mapping where validity_flag='Y' AND scm_status in ('D') AND scheme_id = ?";
		////logger.debug("loadCompForEdit query :: "+query);
		 compMasterList = jdbcTemplate.query(query, new Object[]{searchScheme.getSchemeId(),searchScheme.getSchemeId()}, new RowMapper<CompMaster>() {
			@Override
			public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompMaster compMaster = new CompMaster();
				compMaster.setSchemeId(rs.getInt("scheme_id"));
				compMaster.setCompId(rs.getInt("component_id"));
				compMaster.setCompName(rs.getString("componenet_name"));
				return compMaster;
			}
		});
		
	}catch(NullPointerException e) {
		System.err.println("NullPointerException caught in SchemeSearchDAOImpl || loadCompForEdit ");
	}
	catch(Exception e){
		if(logger.isDebugEnabled()) {
		e.printStackTrace();
		}
	}
		//logger.debug("End SchemeSearchDAOImpl loadCompForEdit ");
	return compMasterList;
	}



	@Override
	public List<SchemeTqMaster> getTransactionSubDataTarget(String filtertype,int schemeId, int compId, int circleId, String circleCode) throws SQLException {
		//logger.debug("Begin SchemeSearchDAOImpl getTransactionSubDataTarget ");
		Connection connection=null;
		PreparedStatement ps = null;
		ResultSet result=null;
		PreparedStatement ps1 = null;
		ResultSet rs =null;
		
		List<SchemeTqMaster> tqList = null;
		int i = 1;
		String query = "SELECT NVL(rtrim(xmlagg(xmlelement(e, DISPLAY_VALUE || ', ')).extract('//text()'), ', '), '') as display_name  FROM(" +
				" SELECT DISTINCT TRIM(RTRIM(LTRIM(TRIM(CASE WHEN T.DATA_SET=3 THEN (SELECT E.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING E" +
				" WHERE E.VALIDITY_FLAG='Y' AND E.ATTR_CATG=8 AND E.CIRCLE_ID = ? AND E.SRC_TBL_FIELD=T.PARAMETER) ELSE '' END ||','||" +
				" CASE WHEN T.VALUE_TYPE=8 THEN (SELECT E.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING E" +
				" WHERE E.VALIDITY_FLAG='Y' AND E.ATTR_CATG=8 AND E.CIRCLE_ID = ? AND E.ATTR_SEQ_NO=TO_NUMBER(T.VALUE)) ELSE '' END),','),',')) AS DISPLAY_VALUE" +
				" FROM DLP_SCM_EA_COND_CONFIG T where T.VALIDITY_FLAG='Y' and T.SCHEME_ID = ? and T.COMPONENT_ID = ? "+
				" AND (T.DATA_SET=3 OR T.VALUE_TYPE=8))";
		try{
			
			////logger.debug("SchemeSearchDAOImpl getTransactionSubDataTarget EA query ::"+query);
			connection = jdbcTemplate.getDataSource().getConnection();
			ps = connection.prepareStatement(query);
			ps.setInt(1, circleId);
			ps.setInt(2, circleId);
			ps.setInt(3, schemeId);
			ps.setInt(4, compId);
			result = ps.executeQuery();
			tqList = new ArrayList<SchemeTqMaster>();
			String str = null;
			while(result.next()){
				if(result.getString("display_name")!=null)
					str=result.getString("display_name")+", ";
			}
			
			query="SELECT NVL(rtrim(xmlagg(xmlelement(e, DISPLAY_VALUE || ', ')).extract('//text()'), ', '), '') as display_name  FROM(" +
					" SELECT DISTINCT TRIM(RTRIM(LTRIM(TRIM(CASE WHEN T.INPUT_TYPE=8 THEN (SELECT E.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING E" +
					"  WHERE E.VALIDITY_FLAG='Y' AND E.ATTR_CATG=8 AND E.CIRCLE_ID = ? AND E.ATTR_SEQ_NO=TO_NUMBER(T.INPUT_PARAMETER)) ELSE '' END ||','||" +
					" CASE WHEN T.VALUE_TYPE=8 THEN (SELECT E.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING E" +
					"  WHERE E.VALIDITY_FLAG='Y' AND E.ATTR_CATG=8 AND E.CIRCLE_ID = ? AND E.ATTR_SEQ_NO=TO_NUMBER(T.VALUE)) ELSE '' END),','),',')) AS DISPLAY_VALUE" +
					" FROM DLP_SCM_PO_COND_CONFIG T" +
					" where T.VALIDITY_FLAG='Y' and T.SCHEME_ID = ? and T.COMPONENT_ID = ? "+
					" AND (T.INPUT_TYPE=8 OR T.VALUE_TYPE=8))";
			
			ps1 = connection.prepareStatement(query);
			ps1.setInt(1, circleId);
			ps1.setInt(2, circleId);
			ps1.setInt(3, schemeId);
			ps1.setInt(4, compId);
			rs = ps1.executeQuery();

			//logger.debug("SchemeSearchDAOImpl getTransactionSubDataTarget PO query2 ::"+query);
			while(rs.next()){
				if(rs.getString("display_name")!=null){
					if(str!=null){
						str = str.concat(rs.getString("display_name"));
					}else{
						str = rs.getString("display_name");
					}
				}
					
			}
			
			
			SchemeTqMaster tqMaster = new SchemeTqMaster();
			tqMaster.setCondId(i);
			tqMaster.setCondName("N/A");
			tqMaster.setCondition(str);
			if(str!=null)
			tqList.add(tqMaster);
			//logger.debug("End SchemeSearchDAOImpl getTransactionSubDataTarget ");
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || getTransactionSubDataTarget ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		
		}finally{
			if(ps!=null)
				ps.close();
			if(ps1!=null)
				ps1.close();
			if(result!=null)
				rs.close();
			if(result!=null)
				rs.close();
			if(connection!=null)
				connection.close();
		}
		return tqList;
	}



	@Override
	public List<ScmPayoutVO> loadHoldDataSearch(SearchScheme holdData,int circleId,String circleCode) throws Exception {
		//logger.debug("Begin SchemeSearchDAOImpl loadHoldDataSearch ");
		String columnName="";
		List<ScmPayoutVO> holdDataList = new ArrayList<ScmPayoutVO>();
		if(holdData.getPayTo() == 1){
			columnName = " PD.PRODUCER_ID = ? and" ;
		}else if(holdData.getPayTo() == 2){
			columnName = " PD.FTA_NUMBER = ? and" ;
		}else if(holdData.getPayTo() == 3){
			columnName = " PD.VTOPUP_NUMBER = ? and" ;
		}
		try {
		String query ="select PD.FTA_NUMBER,DP.PAYMENT_REMARKS,PD.VTOPUP_NUMBER,PD.PAYMENT_ID,PD.PRODUCER_ID,PD.SCHEME_ID,SM.SCHEME_NAME,PD.COMPONENT_ID,CM.COMPONENET_NAME," +
				" TO_CHAR(CM.START_DATE,'DD-MON-YYYY') START_DATE, TO_CHAR(CM.END_DATE,'DD-MON-YYYY') END_DATE,CM.PAYMENT_STATUS,CM.PAYOUT_STATUS," +
				" PD.PAYMENT_AMOUNT,PD.PAY_TO,EM.DISPLAY_VALUE,PD.TOTAL_ENTITY,decode(PD.PAYMENT_TYPE,'V','VTOPUP Payment','T','OTF Payment', 'O','OFFLINE Payment', 'I','IDEA-MONEY Payment') PAYMENT_TYPE, " +
				" TO_CHAR(DP.PAYMENT_DATE,'DD-MON-YYYY') PAYMENT_DATE from" +
				" DLP_PAYMENT_"+circleCode+" DP, DLP_PAYMENT_DETAILS_"+circleCode+" PD, DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM,DLP_ENTITY_TYPE_MASTER EM where " +columnName+
				" PD.PAYMENT_ID=DP.PAYMENT_ID and PD.VALIDITY_FLAG='Y' and PD.Taken_For_Vtopup !='Y' and PD.PAYMENT_TYPE = ? and CM.PAYMENT_STATUS='P' and CM.PAYOUT_STATUS='A' and" +
				" TRUNC(DP.PAYMENT_DATE) between ? and ? and SM.SCHEME_ID=CM.SCHEME_ID and" +
				" CM.SCHEME_ID=PD.SCHEME_ID and CM.COMPONENT_ID=PD.COMPONENT_ID and PD.PAY_TO=EM.ENTITY_TYPE_ID and" +
				" SM.VALIDITY_FLAG=CM.VALIDITY_FLAG and PD.PAYMENT_ID=CM.PAYMENT_ID and PD.VALIDITY_FLAG=CM.VALIDITY_FLAG"; 

		////logger.debug("loadCompForEdit query :: "+query);
		 holdDataList = jdbcTemplate.query(query,new Object[]{holdData.getCondParam(),holdData.getPaymentType(),holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<ScmPayoutVO>() {
			@Override
			public ScmPayoutVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				ScmPayoutVO scmPay = new ScmPayoutVO();
				scmPay.setScmId(rs.getInt("SCHEME_ID"));
				scmPay.setScmName(rs.getString("SCHEME_NAME"));
				scmPay.setCompId(rs.getInt("COMPONENT_ID"));
				scmPay.setCompName(rs.getString("COMPONENET_NAME"));
				scmPay.setStartDt(rs.getString("START_DATE"));
				scmPay.setEndDt(rs.getString("END_DATE"));
				scmPay.setPayoutStatus(rs.getString("PAYOUT_STATUS"));
				scmPay.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
				scmPay.setAmount(rs.getBigDecimal("PAYMENT_AMOUNT"));
				scmPay.setPayTo(rs.getString("DISPLAY_VALUE"));
				scmPay.setProducerId(rs.getString("PRODUCER_ID"));
				scmPay.setVtopupNumber(rs.getString("VTOPUP_NUMBER"));
				scmPay.setFtaNumber(rs.getString("FTA_NUMBER"));
				scmPay.setPaymentDt(rs.getString("PAYMENT_DATE"));
				scmPay.setPaymentType(rs.getString("PAYMENT_TYPE"));
				scmPay.setTotalEntity(rs.getString("TOTAL_ENTITY"));
				scmPay.setRemarks(rs.getString("PAYMENT_REMARKS"));
				scmPay.setPayToId(rs.getInt("PAY_TO"));
				
				return scmPay;
			}
		});
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || loadCompForEdit ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		
		}
		//logger.debug("End SchemeSearchDAOImpl loadCompForEdit ");
	return holdDataList;
	}



	@Override
	public ScmPayoutVO getTotalHoldAmount(final SearchScheme holdData, int circleId, final String circleCode) throws Exception {

		//logger.debug("Begin SchemeSearchDAOImpl loadHoldDataSearch ");
		String columnName="";
		if(holdData.getPayTo() == 1){
			columnName = " PD.PRODUCER_ID = ? and" ;
		}else if(holdData.getPayTo() == 2){
			columnName = " PD.FTA_NUMBER = ? and" ;
		}else if(holdData.getPayTo() == 3){
			columnName = " PD.VTOPUP_NUMBER = ? and" ;
		}
		final String columnName1 = columnName;
		final String val = holdData.getCondParam();
		
		String query ="select " +
				" sum(PD.PAYMENT_AMOUNT) PAYMENT_AMOUNT, PD.PRODUCER_ID,PD.FTA_NUMBER,PD.VTOPUP_NUMBER,PD.PAY_TO from" +
				" DLP_PAYMENT_"+circleCode+" DP, DLP_PAYMENT_DETAILS_"+circleCode+" PD, DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM,DLP_ENTITY_TYPE_MASTER EM where " +columnName+
				" PD.PAYMENT_ID=DP.PAYMENT_ID and PD.VALIDITY_FLAG='Y'  and PD.Taken_For_Vtopup !='Y' and PD.PAYMENT_TYPE = ?  and CM.PAYMENT_STATUS='P' and CM.PAYOUT_STATUS='A'  and" +
				" TRUNC(DP.PAYMENT_DATE) between ? and ? and SM.SCHEME_ID=CM.SCHEME_ID and" +
				" CM.SCHEME_ID=PD.SCHEME_ID and CM.COMPONENT_ID=PD.COMPONENT_ID and PD.PAY_TO=EM.ENTITY_TYPE_ID and" +
				" SM.VALIDITY_FLAG=CM.VALIDITY_FLAG and PD.PAYMENT_ID=CM.PAYMENT_ID and PD.VALIDITY_FLAG=CM.VALIDITY_FLAG " +
				" group by PD.PRODUCER_ID,PD.FTA_NUMBER,PD.VTOPUP_NUMBER,PD.PAY_TO"; 

		////logger.debug("loadCompForEdit query :: "+query);
		ScmPayoutVO holdDataList = jdbcTemplate.queryForObject(query,new Object[]{holdData.getCondParam(),holdData.getPaymentType(),holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<ScmPayoutVO>() {
			@Override
			public ScmPayoutVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				ScmPayoutVO scmPay = new ScmPayoutVO();
				scmPay.setTotalAmt(rs.getBigDecimal("PAYMENT_AMOUNT"));
				scmPay.setProducerId(rs.getString("PRODUCER_ID"));
				scmPay.setFtaNumber(rs.getString("FTA_NUMBER"));
				scmPay.setVtopupNumber(rs.getString("VTOPUP_NUMBER"));
				scmPay.setPayToId(rs.getInt("PAY_TO"));
				scmPay.setHoldAmt(getHoldAmt(circleCode,columnName1,val));
				scmPay.setNetHoldAmt(getRecTotalHoldAmount(holdData,circleCode));
				return scmPay;
			}
		});
		
		
		//logger.debug("End SchemeSearchDAOImpl loadCompForEdit ");
	return holdDataList;

	}

	private BigDecimal getHoldAmt(String circleCode, String columnName,String val){
		try {
			String query = "select sum(PD.HOLD_AMOUNT) HOLD_AMOUNT from  DLP_HOLD_AMT_DETAILS_"+circleCode+" PD where  "+columnName+" HOLD_RELEASE_STATUS not in( 'S','I') and PD.HOLD_RELEASE_REQUEST= 'N'  group by PD.PRODUCER_ID,PD.FTA_NUMBER,PD.VTOPUP_NUMBER";
			String result = jdbcTemplate.queryForObject(query,new Object[]{val},String.class);
			return new BigDecimal(result);
		} catch (Exception e) {
			if(logger.isDebugEnabled()){
			e.printStackTrace();
			}
		}
		return new BigDecimal(0);
	}

	private BigDecimal getRecTotalHoldAmount(SearchScheme holdData, String circleCode) {
		//String result="0";
		try{
		////System.out.println("Begin SchemeSearchDAOImpl loadHoldDataSearch holdData.getCondParam():"+holdData.getCondParam());
		String columnName="";
		if(holdData.getPayTo() == 1){
			columnName = " PD.PRODUCER_ID = ? and" ;
		}else if(holdData.getPayTo() == 2){
			columnName = " PD.FTA_NUMBER = ? and" ;
		}else if(holdData.getPayTo() == 3){
			columnName = " PD.VTOPUP_NUMBER = ? and" ;
		}
		String query="SELECT SUM(PD.HOLD_AMOUNT) HOLD_AMOUNT FROM DLP_HOLD_AMT_DETAILS_"+circleCode+" PD where " +columnName+
				" HOLD_RELEASE_STATUS NOT IN( 'S','I')  AND PD.HOLD_STATUS in ('N','F') GROUP BY PD.PRODUCER_ID," +
				" PD.FTA_NUMBER,PD.VTOPUP_NUMBER";
		String result = jdbcTemplate.queryForObject(query,new Object[]{holdData.getCondParam()},String.class);
		////System.out.println("End SchemeSearchDAOImpl loadCompForEdit "+result);
		return new BigDecimal(result);
		}catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}
		return new BigDecimal(0);

	}
	
	@Override
	public String saveHoldAmountData(HoldReleaseAmount holdData)	throws Exception {
		try {
		String query = "insert into DLP_HOLD_AMT_DETAILS_"+holdData.getCircleCode()+" (" +
				" TRANSACTION_DATE, PAYMENT_TYPE, PRODUCER_ID, VTOPUP_NUMBER, FTA_NUMBER, HOLD_AMOUNT, HOLD_RELEASE_REQUEST," +
				" HOLD_STATUS, HOLD_RELEASE_STATUS, USER_ID, VALIDITY_FLAG, INSERT_DATE_TIME,UPDATE_DATE_TIME,SETTLEMENT_FLAG,PAY_TO) values" +
				" (sysdate,?,?,?,?,?,'N','N','N',?,'Y',sysdate,sysdate,'N',?)";
		
		int result = jdbcTemplate.update(query, new Object[]{holdData.getPaymentType(),holdData.getProducerId(),holdData.getVtopupNumber(),holdData.getFtaNumber(),holdData.getHoldAmt(),holdData.getUserId(),holdData.getPayToId()});
		  if(result==1){
			  return "Request to hold the amount for selected payee is successfully placed.";
		  }
		} catch (Exception e) {
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		}
		return "Fail to hold amount.";
	}



	@Override
	public List<HoldReleaseAmount> holdDataProducers(SearchScheme holdData,int circleId,String circleCode) throws Exception {
		//logger.debug("Begin SchemeSearchDAOImpl loadHoldDataSearch ");
		String columnName="";
		List<HoldReleaseAmount> holdDataList = new ArrayList<HoldReleaseAmount>();
		if(holdData.getPayTo() == 1){
			columnName = " PD.PRODUCER_ID like '"+holdData.getCondParam()+"%' and" ;
		}else if(holdData.getPayTo() == 2){
			columnName = " PD.FTA_NUMBER = ? and" ;
		}else if(holdData.getPayTo() == 3){
			columnName = " PD.VTOPUP_NUMBER = ? and" ;
		}
		try {
		String query ="select distinct PD.PRODUCER_ID from" +
				" DLP_PAYMENT_"+circleCode+" DP, DLP_PAYMENT_DETAILS_"+circleCode+" PD, DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM,DLP_ENTITY_TYPE_MASTER EM where " +columnName+
				" PD.PAYMENT_ID=DP.PAYMENT_ID and PD.VALIDITY_FLAG='Y' and PD.PAYMENT_TYPE = ? and CM.PAYMENT_STATUS='P' and CM.PAYOUT_STATUS='A' and" +
				" TRUNC(DP.PAYMENT_DATE) between ? and ? and SM.SCHEME_ID=CM.SCHEME_ID and" +
				" CM.SCHEME_ID=PD.SCHEME_ID and CM.COMPONENT_ID=PD.COMPONENT_ID and PD.PAY_TO=EM.ENTITY_TYPE_ID and" +
				" SM.VALIDITY_FLAG=CM.VALIDITY_FLAG and PD.PAYMENT_ID=CM.PAYMENT_ID and PD.VALIDITY_FLAG=CM.VALIDITY_FLAG"; 
////System.out.println("loadCompForEdit query :: "+query);
		////logger.debug("loadCompForEdit query :: "+query);
		 holdDataList = jdbcTemplate.query(query,new Object[]{holdData.getPaymentType(),holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<HoldReleaseAmount>() {
			@Override
			public HoldReleaseAmount mapRow(ResultSet rs, int rowNum) throws SQLException {
				HoldReleaseAmount scmPay = new HoldReleaseAmount();
				scmPay.setProducerId(rs.getString("PRODUCER_ID"));
				return scmPay;
			}
		});
		
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || loadCompForEdit ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
		
		}
		//logger.debug("End SchemeSearchDAOImpl loadCompForEdit ");
	return holdDataList;
	}

	@Override
	public List<HoldReleaseAmount> getTotalReleaseAmount(SearchScheme holdData, int circleId, final String circleCode) throws Exception {
		try
		{
			//logger.debug("SchemeSearchDAOImpl || getTotalReleaseAmount || BEG|| payTO:"+holdData.getPayTo()+" condParam:"+holdData.getChangeDesc());
			String relReqHis=holdData.getReleaseType();	
			String query;
			String columnName="";
			List<HoldReleaseAmount> holdDataList=null;
			if("1".equals(relReqHis))
			{
				////System.out.println("SchemeSearchDAOImpl || getTotalReleaseAmount || Request Block");
				if(holdData.getPayTo()==1)
					columnName="";
				else if(holdData.getPayTo() == 2){
					columnName = " PRODUCER_ID = ? and " ;
				}else if(holdData.getPayTo() == 3){
					columnName = " FTA_NUMBER = ? and" ;
				}else if(holdData.getPayTo() == 4){
					columnName = " VTOPUP_NUMBER = ? and" ;
				}
				query="select Transaction_Date Transaction_Date,Producer_Id,Hold_Amount,Release_Request_Dt,Release_Date," +
						" (select sum(hold_amount)  from  Dlp_Hold_Amt_Details_"+circleCode +
						" Where Settlement_Flag = 'N' And HOLD_RELEASE_REQUEST = 'N' And "+columnName+"  TRUNC(Transaction_Date) BETWEEN ? AND ?) sumAmount,update_remarks," +
						" Hold_Release_Status, HOLD_RELEASE_REQUEST,HOLD_STATUS from DLP_HOLD_AMT_DETAILS_"+circleCode+" where Settlement_Flag = 'N' " +
						" and HOLD_RELEASE_REQUEST = 'N' AND "+columnName+"   TRUNC(Transaction_Date) BETWEEN ? AND ?"; 

			//	//logger.debug("getTotalReleaseAmount query :: "+query);
				holdDataList = jdbcTemplate.query(query,new Object[]{holdData.getChangeDesc(),holdData.getStartDate(),holdData.getEndDate(),holdData.getChangeDesc(),holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<HoldReleaseAmount>() {
					@Override
					public HoldReleaseAmount mapRow(ResultSet rs, int rowNum) throws SQLException {
						HoldReleaseAmount relPayment = new HoldReleaseAmount();
						relPayment.setTransactionDate(rs.getString(1));
						relPayment.setProducerId(rs.getString(2));
						relPayment.setHoldAmt(rs.getBigDecimal("Hold_Amount"));
						relPayment.setReleaseReqDate(rs.getString(4));
						relPayment.setReleaseDate(rs.getString(5));
						relPayment.setTotalAmt(rs.getBigDecimal(6));
						relPayment.setRemarks(rs.getString(7));
						relPayment.setReleaseStatus(rs.getString(8));
						relPayment.setHoldReleaseRequest(rs.getString("HOLD_RELEASE_REQUEST"));
						relPayment.setHoldStatus(rs.getString("HOLD_STATUS"));
						return relPayment;
					}
				});
			}
			else
			{
				////System.out.println("SchemeSearchDAOImpl || getTotalReleaseAmount || History Block");
				boolean flag = false;
				/*if(holdData.getCompId() == 1){
					columnName="";
					flag = true;
				}else if(holdData.getCompId() == 2){
					columnName = " PRODUCER_ID = ? and " ;
				}else if(holdData.getCompId() == 3){
					columnName = " FTA_NUMBER = ? and" ;
				}else if(holdData.getCompId() == 4){
					columnName = " VTOPUP_NUMBER = ? and" ;
				}*/
				if(holdData.getPayTo()==1){
					columnName="";
					flag = true;
				}else if(holdData.getPayTo() == 2){
					columnName = " PRODUCER_ID = ? and " ;
				}else if(holdData.getPayTo() == 3){
					columnName = " FTA_NUMBER = ? and" ;
				}else if(holdData.getPayTo() == 4){
					columnName = " VTOPUP_NUMBER = ? and" ;
				}
				if(flag){
				query="select Transaction_Date, Producer_Id, Hold_Amount, Release_Request_Dt, Release_Date, update_remarks, Hold_Release_Status,HOLD_RELEASE_REQUEST,HOLD_STATUS from Dlp_Hold_Amt_Details_"+circleCode+" where  VALIDITY_FLAG='Y' and TRUNC(Transaction_Date) BETWEEN ? AND ?";
				////System.out.println("if query ::: "+query);
				holdDataList = jdbcTemplate.query(query,new Object[]{holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<HoldReleaseAmount>() {
					@Override
					public HoldReleaseAmount mapRow(ResultSet rs, int rowNum) throws SQLException {
						HoldReleaseAmount relPayment = new HoldReleaseAmount();
						relPayment.setTransactionDate(rs.getString("Transaction_Date"));
						relPayment.setProducerId(rs.getString("Producer_Id"));
						relPayment.setHoldAmt(rs.getBigDecimal("Hold_Amount"));
						relPayment.setReleaseReqDate(rs.getString("Release_Request_Dt"));
						relPayment.setReleaseDate(rs.getString("Release_Date"));
						relPayment.setRemarks(rs.getString("update_remarks"));
						relPayment.setReleaseStatus(rs.getString("Hold_Release_Status"));
						relPayment.setHoldReleaseRequest(rs.getString("HOLD_RELEASE_REQUEST"));
						relPayment.setHoldStatus(rs.getString("HOLD_STATUS"));
						return relPayment;
					}
				});
			}else{
				query="select Transaction_Date, Producer_Id, Hold_Amount, Release_Request_Dt, Release_Date, update_remarks, Hold_Release_Status, HOLD_RELEASE_REQUEST, HOLD_STATUS from Dlp_Hold_Amt_Details_"+circleCode+" where "+columnName+"  VALIDITY_FLAG='Y'  and  TRUNC(Transaction_Date) BETWEEN ? AND ?";
				////System.out.println("else query :: "+query);
				holdDataList = jdbcTemplate.query(query,new Object[]{holdData.getChangeDesc(), holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<HoldReleaseAmount>() {
					@Override
					public HoldReleaseAmount mapRow(ResultSet rs, int rowNum) throws SQLException {
						HoldReleaseAmount relPayment = new HoldReleaseAmount();
						relPayment.setTransactionDate(rs.getString("Transaction_Date"));
						relPayment.setProducerId(rs.getString("Producer_Id"));
						relPayment.setHoldAmt(rs.getBigDecimal("Hold_Amount"));
						relPayment.setReleaseReqDate(rs.getString("Release_Request_Dt"));
						relPayment.setReleaseDate(rs.getString("Release_Date"));
						relPayment.setRemarks(rs.getString("update_remarks"));
						relPayment.setReleaseStatus(rs.getString("Hold_Release_Status"));
						relPayment.setHoldReleaseRequest(rs.getString("HOLD_RELEASE_REQUEST"));
						relPayment.setHoldStatus(rs.getString("HOLD_STATUS"));
						return relPayment;
					}
				});
			}
			}
			//logger.debug("End SchemeSearchDAOImpl getTotalReleaseAmount ");
			return holdDataList;
		}
		catch(Exception e)
		{
			if(logger.isDebugEnabled()) {
			logger.error("SchemeSearchDAOImpl || getTotalReleaseAmount || Exception is:"+e);
			e.printStackTrace();
			}
			return null;
		}
	}
	
	public String updateRelReq(String relReqData,String remarksVal, int circleId, String circleCode) throws Exception
	{
		//logger.debug("SchemeSearchDAOImpl || updateRelReq || BEG");
		String retVal="";
		try {
		String[] data = relReqData.split(",");
		int count1=0;
		//logger.debug("count =====>"+data.length);
		for(String varD:data)
		{
			String dmVal="(select  to_date('"+varD.substring(0,19)+"','yyyy-mm-dd hh24:mi:ss') from dual)";
			String query="update Dlp_Hold_Amt_Details_"+circleCode+" set Hold_Release_Request = 'Y', Release_Request_Dt = sysdate, Update_Remarks = ? where  Transaction_Date = ?";
			////logger.debug(" updateRelReq dmVal ======================> "+query);
			int count=jdbcTemplate.update(query, remarksVal, dmVal);
			if(count!=0)
				count1+=count;
		}
		if(count1!=0)
			retVal = "Request to release the amount for selected transaction(s) is successfully placed.";
		else
			retVal= "Failed to release amount.";
		//logger.debug("SchemeSearchDAOImpl || updateRelReq || count :");
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || loadCompForEdit ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
			
		}
		
		return retVal;
	}



	@Override
	public List<HoldReleaseAmount> getReleaseDataCSV(SearchScheme holdData,	int circleId, String circleCode) throws Exception {
		try
		{
			//logger.debug("Begin SchemeSearchDAOImpl getReleaseDataCSV ");
			String query;
			//logger.debug("SchemeSearchDAOImpl || getReleaseDataCSV || BEG|| payTO:"+holdData.getPayTo()+" condParam:"+holdData.getCondParam()+" sertype::"+holdData.getFilterBy());
			String columnName="";
			List<HoldReleaseAmount> holdDataList=null;
			if(holdData.getPayTo()==1)
			{
				if(holdData.getCompId()==1)
					columnName="";
				else if(holdData.getCompId() == 2){
					columnName = " PRODUCER_ID = ? and " ;
				}else if(holdData.getCompId() == 3){
					columnName = " FTA_NUMBER = ? and" ;
				}else if(holdData.getCompId() == 4){
					columnName = " VTOPUP_NUMBER = ? and" ;
				}
				query=" select TRANSACTION_DATE, PAYMENT_TYPE, PRODUCER_ID, VTOPUP_NUMBER, FTA_NUMBER, HOLD_AMOUNT," +
						" HOLD_RELEASE_REQUEST, RELEASE_REQUEST_DT, HOLD_RELEASE_STATUS, HOLD_STATUS, RELEASE_DATE, USER_ID, UPDATE_REMARKS from DLP_HOLD_AMT_DETAILS_"+circleCode +
						" where "+columnName+"  SETTLEMENT_FLAG='N' and HOLD_RELEASE_STATUS in('N','Y')" +
						" and TRUNC(TRANSACTION_DATE) between ? and ? "; 

				holdDataList = jdbcTemplate.query(query,new Object[]{holdData.getCondParam(),holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<HoldReleaseAmount>() {
					@Override
					public HoldReleaseAmount mapRow(ResultSet rs, int rowNum) throws SQLException {
						HoldReleaseAmount relPayment = new HoldReleaseAmount();
						relPayment.setTransactionDate(rs.getString("TRANSACTION_DATE"));
						relPayment.setPaymentType(rs.getString("PAYMENT_TYPE"));
						relPayment.setProducerId(rs.getString("PRODUCER_ID"));
						relPayment.setVtopupNumber(rs.getString("VTOPUP_NUMBER"));
						relPayment.setFtaNumber(rs.getString("FTA_NUMBER"));
						relPayment.setHoldAmt(rs.getBigDecimal("Hold_Amount"));
						relPayment.setHoldReleaseRequest(rs.getString("HOLD_RELEASE_REQUEST"));
						relPayment.setReleaseReqDate(rs.getString("RELEASE_REQUEST_DT"));
						relPayment.setHoldReleaseStatus(rs.getString("HOLD_RELEASE_STATUS"));
						relPayment.setHoldStatus(rs.getString("HOLD_STATUS"));
						relPayment.setReleaseDate(rs.getString("RELEASE_DATE"));
						relPayment.setUserId(rs.getString("USER_ID"));
						relPayment.setRemarks(rs.getString("UPDATE_REMARKS"));
						return relPayment;
					}
				});
			} else {
				boolean flag = true;
				if(holdData.getCompId() == 1){
					columnName="";
					flag = false;
				}else if(holdData.getCompId() == 2){
					columnName = " PRODUCER_ID = ? and " ;
				}else if(holdData.getCompId() == 3){
					columnName = " FTA_NUMBER = ? and" ;
				}else if(holdData.getCompId() == 4){
					columnName = " VTOPUP_NUMBER = ? and" ;
				}
				
				//logger.debug("SchemeSearchDAOImpl || getTotalReleaseAmount || History Block");
				query=" select TRANSACTION_DATE, PAYMENT_TYPE, PRODUCER_ID, VTOPUP_NUMBER, FTA_NUMBER, HOLD_AMOUNT," +
						" HOLD_RELEASE_REQUEST, RELEASE_REQUEST_DT, HOLD_RELEASE_STATUS, HOLD_STATUS, RELEASE_DATE, USER_ID, UPDATE_REMARKS from DLP_HOLD_AMT_DETAILS_"+circleCode +
						" where "+columnName+"  SETTLEMENT_FLAG='Y' and Hold_Release_Status='S' " +
						" and TRUNC(TRANSACTION_DATE) between ? and ? "; 
				if(flag){
				holdDataList = jdbcTemplate.query(query,new Object[]{holdData.getCondParam(),holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<HoldReleaseAmount>() {
					@Override
					public HoldReleaseAmount mapRow(ResultSet rs, int rowNum) throws SQLException {
						HoldReleaseAmount relPayment = new HoldReleaseAmount();
						relPayment.setTransactionDate(rs.getString("TRANSACTION_DATE"));
						relPayment.setPaymentType(rs.getString("PAYMENT_TYPE"));
						relPayment.setProducerId(rs.getString("PRODUCER_ID"));
						relPayment.setVtopupNumber(rs.getString("VTOPUP_NUMBER"));
						relPayment.setFtaNumber(rs.getString("FTA_NUMBER"));
						relPayment.setHoldAmt(rs.getBigDecimal("Hold_Amount"));
						relPayment.setHoldReleaseRequest(rs.getString("HOLD_RELEASE_REQUEST"));
						relPayment.setReleaseReqDate(rs.getString("RELEASE_REQUEST_DT"));
						relPayment.setHoldReleaseStatus(rs.getString("HOLD_RELEASE_STATUS"));
						relPayment.setHoldStatus(rs.getString("HOLD_STATUS"));
						relPayment.setReleaseDate(rs.getString("RELEASE_DATE"));
						relPayment.setUserId(rs.getString("USER_ID"));
						relPayment.setRemarks(rs.getString("UPDATE_REMARKS"));
						return relPayment;
					}
				});
				}else{
					holdDataList = jdbcTemplate.query(query,new Object[]{holdData.getStartDate(),holdData.getEndDate()}, new RowMapper<HoldReleaseAmount>() {
						@Override
						public HoldReleaseAmount mapRow(ResultSet rs, int rowNum) throws SQLException {
							HoldReleaseAmount relPayment = new HoldReleaseAmount();
							relPayment.setTransactionDate(rs.getString("TRANSACTION_DATE"));
							relPayment.setPaymentType(rs.getString("PAYMENT_TYPE"));
							relPayment.setProducerId(rs.getString("PRODUCER_ID"));
							relPayment.setVtopupNumber(rs.getString("VTOPUP_NUMBER"));
							relPayment.setFtaNumber(rs.getString("FTA_NUMBER"));
							relPayment.setHoldAmt(rs.getBigDecimal("Hold_Amount"));
							relPayment.setHoldReleaseRequest(rs.getString("HOLD_RELEASE_REQUEST"));
							relPayment.setReleaseReqDate(rs.getString("RELEASE_REQUEST_DT"));
							relPayment.setHoldReleaseStatus(rs.getString("HOLD_RELEASE_STATUS"));
							relPayment.setHoldStatus(rs.getString("HOLD_STATUS"));
							relPayment.setReleaseDate(rs.getString("RELEASE_DATE"));
							relPayment.setUserId(rs.getString("USER_ID"));
							relPayment.setRemarks(rs.getString("UPDATE_REMARKS"));
							return relPayment;
						}
					});
			}
			}
			//logger.debug("getReleaseDataCSV query :: "+query);
			//logger.debug("End SchemeSearchDAOImpl getReleaseDataCSV ");
			return holdDataList;
		}
		catch(Exception e)
		{
			if(logger.isDebugEnabled()) {
			logger.error("SchemeSearchDAOImpl || getReleaseDataCSV || Exception is:"+e);
			}
			return null;
		}
	
	}
	
	@Override
	public List<SchemeMaster> loadSchemeCreate(SearchScheme scheme) {
		
		List<SchemeMaster> covList = new ArrayList<SchemeMaster>();
		try {
		if(httpSession.getAttribute("circleId")!=null){
			int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
			////System.out.println("circle id-------------->"+circleId);
					//String query = "select * from DLP_SCHEME_MASTER where upper(scheme_name) like upper('%"+Scheme+"%') AND circle_id="+circleId+" AND validity_flag='Y' order by update_date_time desc";
			SchemeMaster schemeMaster = new SchemeMaster();
			schemeMaster.setSchemeINputId(0);
			schemeMaster.setSchemeName("&nbsp;");
			covList.add(schemeMaster);
			
				////System.out.println("Begin SchemeSearchDAOImpl loadScheme  || entity ALL");
			 covList = jdbcTemplate.query(SchemeConfigQueries.LOAD_SCHEME_MASTER_CREATE, new Object[]{circleId,scheme.getStartDate(),scheme.getEndDate(),(scheme.getPayTo()==11)?"%%":scheme.getPayTo()}, new RowMapper<SchemeMaster>() {
			//	List<SchemeMaster> covList = jdbcTemplate.query(query, new RowMapper<SchemeMaster>() {
				
				@Override
				public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
					SchemeMaster schemeMaster = new SchemeMaster();
					
					schemeMaster.setSchemeINputId(rs.getInt("SCHEME_ID"));
					schemeMaster.setSchemeName(rs.getString("SCHEME_NAME"));
					schemeMaster.setAggrementEndDate(rs.getDate("Aggrement_End_Date"));
					schemeMaster.setAutoApprovalFlag(rs.getString("Auto_Approval_Flag"));
					schemeMaster.setAutoCopyFlag(rs.getString("Auto_Copy_Flag"));
					return schemeMaster;
				}
			});
			return covList;
			
		
		}
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || loadSchemeCreate ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
			
		}
		//logger.debug("End SchemeSearchDAOImpl loadScheme ");
		return null;
	}



	@Override
	public List<BulkLoadErrorFileStatus> getBulkUploadErrorFile(SearchScheme holdData, String circleCode) {
		
		
		
		return null;
	}
	
	@Override
	public List<BulkRejectionDataPojo> loadBulkRejFileList(String fileName, String uniqueFileName, String  whereColumnFields, final String confNameType,String selectColumnFields,String circle)
	{
		List<BulkRejectionDataPojo> rejFileList=null;
		try {
		////System.out.println("SchemeSearchDAOImpl || loadBulkRejFileList || BEG | fileName:"+fileName+" : whereColumnFields:"+whereColumnFields+" :selectColumnFields:"+selectColumnFields);
		
		String queryForTable = "select  Destination_Table_Name from Scheme_Bulk_Load_Conf_Temp where Conf_Name=? ";
		
		String tableName = jdbcTemplate.queryForObject(queryForTable, new Object[]{confNameType},String.class);
		
		String queryForData = "select "+selectColumnFields+" from "+tableName+" where "+whereColumnFields;
		
		//final String confNameTypeLocal=confNameType;
		rejFileList = jdbcTemplate.query(queryForData,new Object[]{uniqueFileName, circle},new RowMapper<BulkRejectionDataPojo>()
		{
			@Override
			public BulkRejectionDataPojo mapRow(ResultSet rs, int count) throws SQLException {
				BulkRejectionDataPojo br=new 	BulkRejectionDataPojo();			
				
				if(confNameType.equals("ADD_ATTR"))
				{
					br.setDsm2RefCode(rs.getString("Dsm2_Ref_Code"));
					br.setEntityType(rs.getString("Entity_Type"));
				}
				else if(confNameType.equals("ADD_ACT_UNI"))
				{
					br.setMsisdn(rs.getString("Msisdn"));
					br.setEventDate(rs.getDate("Event_Date"));
				}
				else if(confNameType.equals("ADD_DIST_UNI"))
				{
					br.setDistId(rs.getString("Dist_Id"));
					br.setEventDate(rs.getDate("Event_Date"));
				}
				else if(confNameType.equals("ADD_DSE_UNI"))
				{
					br.setDseId(rs.getString("Dse_Id"));
					br.setEventDate(rs.getDate("Event_Date"));
				}else if(confNameType.equals("ADD_RET_UNI"))
				{
				    br.setRetId(rs.getString("Ret_Id"));
				    br.setEventDate(rs.getDate("Event_Date"));
				}
				else if(confNameType.equals("ENTITY-LIST"))
				{
					br.setProducerId(rs.getString("Producer_Id"));
					br.setEntityType(rs.getString("Entity_Type"));
				}
				else if(confNameType.equals("MANUAL-PAYOUT"))
				{
					br.setDsmRefCode(rs.getString("Dsm_Ref_Code"));
					br.setEntityType(rs.getString("Entity_Type"));
				}
				br.setCircle(rs.getString("Circle"));
				br.setFileName(rs.getString("File_Name"));
				br.setRejectionReason(rs.getString("Rejection_Reason"));
				
				return br;
			} 
		});
		
		}catch(NullPointerException e) {
			System.err.println("NullPointerException caught in SchemeSearchDAOImpl || loadSchemeCreate ");
		}
		catch(Exception e){
			if(logger.isDebugEnabled()) {
			e.printStackTrace();
			}
			
		}
		return rejFileList;
	}


	
}
package dsm.dao.search;

import java.sql.SQLException;
import java.util.List;

import dsm.model.DB.BulkRejectionDataPojo;
import dsm.model.DB.CompMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ScmPayoutVO;
import dsm.model.DB.UpdateCalander;
import dsm.model.form.BulkLoadErrorFileStatus;
import dsm.model.form.HoldReleaseAmount;
import dsm.model.form.SchemeCompNFAList;
import dsm.model.search.SearchScheme;
import dsm.model.submit.SubmitScheme;

public interface SchemeSearchDAO {
	
	public void submitScheme(SubmitScheme scheme) throws Exception;
	
	public String validateScheme(SubmitScheme scheme) throws Exception;

	public List<SchemeMaster> loadScheme(String Scheme);
	
	public List<SchemeMaster> searchSchemeView(SearchScheme schemeName);
	
	public List<SchemeMaster> searchSchemeExecCal(SearchScheme schemeName);

	public List<SchemeMaster> searchSchemeSubmit(SearchScheme schemeSearch);
	
	public void updateCalander(UpdateCalander cal);
	
	public List<SchemeCompNFAList> searchSchemeNFA(SearchScheme schemeName);

	public List<SchemeMaster> searchSchemeApprove(SearchScheme schemeName);
	
	public String submitSchemePayment(SearchScheme schemeName);
	
	public String submitSchemeChange(SearchScheme schemeName);
	
	public List<SchemeMaster> searchSchemeStmGen(SearchScheme schemeName);
	
	public void updateVTopUpFileFlag(String vTopUpFlag,int schemeId,int compId);
	
	public List<SchemeMaster> searchSchemePayment(SearchScheme schemeName);
	
	public List<CompMaster> searchTransactionData(String filtertype,String startDate,String endDate,int circleId,SearchScheme schemeName);
	
	public List<SchemeTqMaster> getTransactionSubData(final String filtertype,int schemeId, int compId,int circleId, String circleCode);

	//public List<SchemeMaster> loadSchemeForEdit(String Scheme);

	public List<CompMaster> loadCompForEdit(SearchScheme searchScheme);
	
	public String showError(SubmitScheme scheme) throws Exception;

	public void loadScheme(SchemeMaster sm);
	
	public List<SchemeTqMaster> getTransactionSubDataTarget(final String filtertype,int schemeId, int compId,int circleId, String circleCode) throws SQLException ;
	
	public List<ScmPayoutVO> loadHoldDataSearch(SearchScheme holdData, int circleId, String circleCode) throws Exception;
	
	public ScmPayoutVO getTotalHoldAmount(SearchScheme holdData, int circleId, String circleCode) throws Exception;
	
	public String saveHoldAmountData(HoldReleaseAmount holdData) throws Exception;
	
	public List<HoldReleaseAmount> holdDataProducers(SearchScheme holdData,int circleId,String circleCode) throws Exception;
	
	public List<HoldReleaseAmount> getTotalReleaseAmount(SearchScheme holdData, int circleId, String circleCode) throws Exception;
	//public String executeQueueProcess(SubmitScheme scheme);
	
	public String updateRelReq(String relReqData,String remarksVal, int circleId, String circleCode) throws Exception;
	
	public List<HoldReleaseAmount> getReleaseDataCSV(SearchScheme holdData, int circleId, String circleCode) throws Exception;
	
	public List<SchemeMaster> loadSchemeCreate(SearchScheme Scheme);
	
	public List<SchemeMaster> loadSchemeForEdit(SearchScheme searchScheme);
	
	public List<BulkLoadErrorFileStatus> getBulkUploadErrorFile(SearchScheme holdData, String circleCode);
	
	public List<BulkRejectionDataPojo> loadBulkRejFileList(String fileName, String uniqueFileName, String  whereColumnFields,String confNameType,String selectColumnFields,String circle);
}

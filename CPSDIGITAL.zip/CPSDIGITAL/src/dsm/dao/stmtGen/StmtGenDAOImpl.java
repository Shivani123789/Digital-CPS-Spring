package dsm.dao.stmtGen;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import dsm.dataBase.query.StmtGenQueries;
import dsm.model.DB.DistributorRetSchmPojo;
import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.DistributorStmtSchmPojo;
import dsm.model.DB.PartnerChannelStatementPojo;
import dsm.model.DB.PartnerChannelStmtScmListPojo;
import dsm.model.DB.PaymentDetailVO;
import dsm.model.DB.RetailerStmtScmList;
import dsm.model.DB.RetailerStmtVO;
import dsm.model.DB.ServiceType;
import dsm.model.DB.StmtGenCycleMaster;
import dsm.model.DB.StmtReqMapping;
import dsm.model.StmGen.StmtCpBean;

public class StmtGenDAOImpl implements StmtGenDAO{

	private JdbcTemplate jdbcTemplate;
	
	
	public StmtGenDAOImpl(){
		
	}
	
	public StmtGenDAOImpl(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<StmtGenCycleMaster> searchScheme(String circleCode, String serviceType)  throws Exception{
		String query = "select STATEMENT_CYCLE_ID, CIRCLE, TO_CHAR(CYCLE_START_DT,'DD-MON-YYYY') || ' TO ' || TO_CHAR(CYCLE_END_DT,'DD-MON-YYYY') START_END_DT, " +
				//" NO_OF_STATEMENTS, " +
				"CYCLE_STATUS, STATEMENT_MONTH, TO_CHAR(STATEMENT_DT,'DD-MON-YYYY') STATEMENT_DT, STATEMENT_GEN_STATUS from DLP_STATEMENT_CYCLE_MASTER where UPPER(CIRCLE) = UPPER(?) and UPPER(CYCLE_STATUS)= UPPER('closed') and UPPER(SERVICE_TYPE) = UPPER(?) ";
		
		List<StmtGenCycleMaster> reportList = jdbcTemplate.query(query, new Object[]{circleCode, serviceType},new RowMapper<StmtGenCycleMaster>() {
			@Override
			public StmtGenCycleMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				StmtGenCycleMaster stmtGenCycleMaster = new StmtGenCycleMaster();
				stmtGenCycleMaster.setStmtCycleId(rs.getInt("STATEMENT_CYCLE_ID"));
				stmtGenCycleMaster.setCycle(rs.getString("CIRCLE"));
				stmtGenCycleMaster.setStartEndDt(rs.getString("START_END_DT"));
			//	stmtGenCycleMaster.setNoOfStmt(rs.getInt("NO_OF_STATEMENTS"));
				stmtGenCycleMaster.setCycleStatus(rs.getString("CYCLE_STATUS"));
				stmtGenCycleMaster.setStmtMonth(rs.getString("STATEMENT_MONTH"));
				stmtGenCycleMaster.setStmtDt(rs.getString("STATEMENT_DT"));
				stmtGenCycleMaster.setStmtGenStatus(rs.getString("STATEMENT_GEN_STATUS"));
				return stmtGenCycleMaster;
			}
		});
		return reportList;
	}
	
	public List<PaymentDetailVO> searchStatementGenerate(String startDt,String endDt,int circleId, String circleCode, int stmtCycleId) throws Exception{
		String query = "select PD.SCHEME_ID,SM.SCHEME_NAME,PD.COMPONENT_ID,CM.COMPONENET_NAME,TO_CHAR(CM.START_DATE,'DD-MON-YYYY') START_DATE ," +
				" TO_CHAR(CM.END_DATE,'DD-MON-YYYY') END_DATE, CM.PAYMENT_STATUS, CM.PAYMENT_ID, sum(round(PD.PAYMENT_AMOUNT,2)) PAYMENT_AMOUNT, " +
				" count(PD.TOTAL_ENTITY) TOTAL_ENTITY, max(round(PD.PAYMENT_AMOUNT,2)) MAX_PAYMENT, min(round(PD.PAYMENT_AMOUNT,2)) MIN_PAYMENT, TO_CHAR(PD.INSERT_DATE_TIME,'DD-MON-YYYY') INSERT_DATE_TIME from " +
				" DLP_SCHEME_COMP_MAPPING CM, DLP_SCHEME_MASTER SM, DLP_PAYMENT_DETAILS_"+circleCode+" PD where SM.SCHEME_ID=CM.SCHEME_ID and " +
				" SM.VALIDITY_FLAG=CM.VALIDITY_FLAG and CM.VALIDITY_FLAG = PD.VALIDITY_FLAG and SM.CIRCLE_ID = ? and CM.PAYMENT_ID=PD.PAYMENT_ID AND " +
				" CM.VALIDITY_FLAG='Y' and  CM.STATEMENT_CYCLE_ID = ?  and CM.SCM_STATUS ='C' AND CM.PAYMENT_STATUS ='P'" +
				" AND PD.SCHEME_ID=CM.SCHEME_ID  AND PD.COMPONENT_ID=CM.COMPONENT_ID"+
				" group by PD.SCHEME_ID, PD.COMPONENT_ID, SM.SCHEME_NAME,CM.COMPONENET_NAME,PD.INSERT_DATE_TIME," +
				" CM.PAYMENT_STATUS, CM.PAYMENT_ID,CM.START_DATE,CM.END_DATE";//CM.START_DATE='"+startDt+"' and CM.END_DATE='"+endDt+"'
		try{
		List<PaymentDetailVO> searchList = jdbcTemplate.query(query, new Object[]{circleId,stmtCycleId}, new RowMapper<PaymentDetailVO>() {
			@Override
			public PaymentDetailVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				PaymentDetailVO payDetails = new PaymentDetailVO();
				payDetails.setSchemeId(rs.getInt("SCHEME_ID"));
				payDetails.setSchemeName(rs.getString("SCHEME_NAME"));
				payDetails.setCompId(rs.getInt("COMPONENT_ID"));
				payDetails.setCompName(rs.getString("COMPONENET_NAME"));
				payDetails.setStartDt(rs.getString("START_DATE"));
				payDetails.setEndDt(rs.getString("END_DATE"));
				payDetails.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
				payDetails.setPaymentAmt(rs.getFloat("PAYMENT_AMOUNT"));
				payDetails.setPaymentId(rs.getInt("PAYMENT_ID"));
				payDetails.setTotalEntity(rs.getFloat("TOTAL_ENTITY"));
				payDetails.setMaxPayment(rs.getFloat("MAX_PAYMENT"));
				payDetails.setMinPayment(rs.getFloat("MIN_PAYMENT"));
				payDetails.setInsertDt(rs.getString("INSERT_DATE_TIME"));
				payDetails.setPaymentMode("CASH");
				return payDetails;
			}
		});
		return searchList;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public List<DistributorStatementPojo> searchViewStmtSearch(String endDt, String circleCode, String msisdn, String distId, int start, int limit)  throws Exception{
	/*	String query = "select C.* , (select COUNT(1) from (select DISTRIBUTOR_DSM2_ID,DISTRIBUTOR_MOBILE_NUM,DISTRIBUOTR_EMAIL,DISTRIBUTOR_NAME, TOTAL_TDS, PAYOUT_GROSS, TOTAL_NET,ROUND(RET_PAYOUT_GROSS,2) RET_PAYOUT_GROSS," +
				" RET_TOTAL_NET from DLP_DIST_STATEMENT where STATEMENT_DATE='"+endDt+"' and UPPER(CIRCLE) = UPPER('"+circleCode+"') and DISTRIBUTOR_MOBILE_NUM like '"+msisdn+"%' )) NO_OF_RECORDS from ( select  a.*,rownum ROW_NUM from ( select  B.* from" +
				" (select DISTRIBUTOR_DSM2_ID,DISTRIBUTOR_MOBILE_NUM,DISTRIBUOTR_EMAIL,DISTRIBUTOR_NAME, TOTAL_TDS, PAYOUT_GROSS, TOTAL_NET,ROUND(RET_PAYOUT_GROSS,2) RET_PAYOUT_GROSS," +
				" RET_TOTAL_NET from DLP_DIST_STATEMENT_"+circleCode+" where STATEMENT_DATE= '"+endDt+"' and UPPER(CIRCLE) = UPPER('"+circleCode+"') and DISTRIBUTOR_MOBILE_NUM like '"+msisdn+"%' )b)a) c where ROW_NUM between "+(start+1)+" AND "+(start+limit);
	*/
		
		String query = "select C.* , (select COUNT(1) from (select DISTRIBUTOR_DSM2_ID,DISTRIBUTOR_MOBILE_NUM,DISTRIBUOTR_EMAIL,DISTRIBUTOR_NAME, TOTAL_TDS, PAYOUT_GROSS, TOTAL_NET,ROUND(RET_PAYOUT_GROSS,2) RET_PAYOUT_GROSS," +
				" RET_TOTAL_NET,DISTRIBUTOR_FIRST_NAME,DISTRIBUTOR_LAST_NAME from DLP_DIST_STATEMENT_"+circleCode+" where CYCLE_END_DT = ? and DISTRIBUTOR_MOBILE_NUM like  ?  AND upper(DISTRIBUTOR_DSM2_ID) like upper(?) )) NO_OF_RECORDS from ( select  a.*,rownum ROW_NUM from ( select  B.* from" +
				" (select DISTRIBUTOR_DSM2_ID,DISTRIBUTOR_MOBILE_NUM,DISTRIBUOTR_EMAIL,DISTRIBUTOR_NAME, TOTAL_TDS, PAYOUT_GROSS, TOTAL_NET,ROUND(RET_PAYOUT_GROSS,2) RET_PAYOUT_GROSS," +
				" RET_TOTAL_NET,DISTRIBUTOR_FIRST_NAME,DISTRIBUTOR_LAST_NAME from DLP_DIST_STATEMENT_"+circleCode+" where CYCLE_END_DT = ? and DISTRIBUTOR_MOBILE_NUM like  ?  AND upper(DISTRIBUTOR_DSM2_ID) like upper(?) )b)a) c where ROW_NUM between "+(start+1)+" AND "+(start+limit);
	
		
		////System.outprintln("Dist stmts query ::: "+query);
		List<DistributorStatementPojo> distList = jdbcTemplate.query(query, new Object[]{endDt, msisdn+"%", "%"+distId+"%", endDt, msisdn+"%", "%"+distId+"%" }, new RowMapper<DistributorStatementPojo>() {
			@Override
			public DistributorStatementPojo mapRow(ResultSet rs, int rowNum) throws SQLException {
				DistributorStatementPojo viewStmt = new DistributorStatementPojo();
				viewStmt.setDistDsm2Id(rs.getString("DISTRIBUTOR_DSM2_ID"));
				viewStmt.setDistMobile(rs.getString("DISTRIBUTOR_MOBILE_NUM"));
				viewStmt.setDistName(rs.getString("DISTRIBUTOR_NAME"));
				viewStmt.setPayoutGross(rs.getString("PAYOUT_GROSS"));
				viewStmt.setTotalTds(rs.getBigDecimal("TOTAL_TDS"));
				viewStmt.setTotalNet(rs.getBigDecimal("TOTAL_NET"));
				viewStmt.setDistEmail(rs.getString("DISTRIBUOTR_EMAIL"));
				viewStmt.setRetPayoutGross(rs.getBigDecimal("RET_PAYOUT_GROSS"));
				viewStmt.setRetTotalNet(rs.getDouble("RET_TOTAL_NET"));
				viewStmt.setFirstName(rs.getString("DISTRIBUTOR_FIRST_NAME"));
				viewStmt.setLastName(rs.getString("DISTRIBUTOR_LAST_NAME"));
				viewStmt.setTotalCount(rs.getInt("NO_OF_RECORDS"));
				return viewStmt;
			}
		});
		return distList;
	}
	
	
	@Override
	public List<DistributorStatementPojo> fetchDistributorStmt(String distributorID, String stmtDt, String circle, String stmtCycleDt) throws Exception{
		Connection connection=null;
		PreparedStatement ps = null;
		ResultSet result=null;
		DistributorStatementPojo distStmtPojo;
		List<DistributorStatementPojo> distStmtPojoList = null;
		try{
			String query = "SELECT STATEMENT_CYCLE_ID,DISTRIBUTOR_STATEMENT_ID,STATEMENT_MONTH,STATEMENT_DATE," +
					" DISTRIBUTOR_DSM2_ID,DISTRIBUTOR_NAME,DISTRIBUTOR_MOBILE_NUM,DISTRIBUTOR_PAN_NO,DISTRIBUOTR_EMAIL,DISTRIBUTOR_ZONE," +
					" SCM_LIST_ID,NORMAL_GROSS,MNP_GROSS,FLEXI,PAPER,TARGET_GR_ADD_MNP,TARGET_GR_ADD_NMNP,TARGET_GR_ADD_TOTAL," +
					" TOTAL_FLEXI_PAPER,ACHIEVEMENT_PERC_MNP,ACHIEVEMENT_PERC_NMNP,ACHIEVEMENT_PERC_TOTAL, INSERT_DATE_TIME," +
					" PAYOUT_GROSS,TOTAL_TDS,TOTAL_NET,TRIM(TO_CHAR(RET_PAYOUT_GROSS,'9999999999999999999999999999999999999.99')) RET_PAYOUT_GROSS,RET_TOTAL_TDS,RET_TOTAL_NET," +
					" GROSS_ACT,    TO_CHAR(STATEMENT_DATE, 'DD-MM-YYYY') PAYMENT_DATE,DIST_AR_CODE FROM DLP_DIST_STATEMENT_"+circle+" WHERE DISTRIBUTOR_DSM2_ID=? AND CYCLE_END_DT=? ";
			
			connection = jdbcTemplate.getDataSource().getConnection();
	/*	ps = connection.prepareStatement("SELECT STATEMENT_CYCLE_ID,DISTRIBUTOR_STATEMENT_ID,STATEMENT_MONTH,STATEMENT_DATE," +
				"DISTRIBUTOR_DSM2_ID,DISTRIBUTOR_NAME,DISTRIBUTOR_MOBILE_NUM,DISTRIBUTOR_PAN_NO,DISTRIBUOTR_EMAIL,DISTRIBUTOR_ZONE," +
				"CIRCLE,SCM_LIST_ID,NORMAL_GROSS,MNP_GROSS,FLEXI,PAPER,TARGET_GR_ADD_MNP,TARGET_GR_ADD_NMNP,TARGET_GR_ADD_TOTAL," +
				"TOTAL_FLEXI_PAPER,ACHIEVEMENT_PERC_MNP,ACHIEVEMENT_PERC_NMNP,ACHIEVEMENT_PERC_TOTAL,DIST_INVOICE_LINK,INSERT_DATE_TIME," +
				"PAYOUT_GROSS,TOTAL_TDS,TOTAL_NET,TRIM(TO_CHAR(RET_PAYOUT_GROSS,'9999999999999999999999999999999999999.99')) RET_PAYOUT_GROSS,RET_TOTAL_TDS,RET_TOTAL_NET," +
				"GROSS_ACT, TOTAL_NOS, TOTAL_RATE, RET_TOTAL_NOS, RET_TOTAL_RATE, TO_CHAR(PAYMENT_DATE, 'DD-MM-YYYY') PAYMENT_DATE FROM DLP_DIST_STATEMENT WHERE DISTRIBUTOR_DSM2_ID=? AND STATEMENT_DATE=? ");//AND UPPER(CIRCLE) = UPPER(?)
	*/
			ps = connection.prepareStatement(query);//AND UPPER(CIRCLE) = UPPER(?)
			ps.setString(1, distributorID);
			ps.setString(2, stmtDt);
		//ps.setString(3, circle);
		
		result = ps.executeQuery();
		distStmtPojoList = new ArrayList<DistributorStatementPojo>();
		while(result.next()){
			distStmtPojo = new DistributorStatementPojo();
			distStmtPojo.setStmtCycleId(result.getInt("STATEMENT_CYCLE_ID"));
			distStmtPojo.setDistStmtId(result.getInt("DISTRIBUTOR_STATEMENT_ID"));
			distStmtPojo.setMonth(result.getString("STATEMENT_MONTH"));
			distStmtPojo.setDate(result.getString("STATEMENT_DATE"));
			distStmtPojo.setDistDsm2Id(result.getString("DISTRIBUTOR_DSM2_ID"));
			distStmtPojo.setDistName(result.getString("DISTRIBUTOR_NAME"));
			distStmtPojo.setDistMobile(result.getString("DISTRIBUTOR_MOBILE_NUM"));
			distStmtPojo.setDistPanNo(result.getString("DISTRIBUTOR_PAN_NO"));
			distStmtPojo.setDistEmail(result.getString("DISTRIBUOTR_EMAIL"));
			distStmtPojo.setDistZone(result.getString("DISTRIBUTOR_ZONE"));
			//distStmtPojo.setCircle(result.getString("CIRCLE"));circle
			distStmtPojo.setCircle(circle);
			distStmtPojo.setScmListId(result.getInt("SCM_LIST_ID"));
			distStmtPojo.setNormalGross(result.getBigDecimal("NORMAL_GROSS"));
			distStmtPojo.setMnpGross(result.getBigDecimal("MNP_GROSS"));
			distStmtPojo.setFlexi(result.getBigDecimal("FLEXI"));
			distStmtPojo.setPaper(result.getBigDecimal("PAPER"));
			distStmtPojo.setTargetMnp(result.getBigDecimal("TARGET_GR_ADD_MNP"));
			distStmtPojo.setTargetNmnp(result.getBigDecimal("TARGET_GR_ADD_NMNP"));
			distStmtPojo.setTargetTotal(result.getBigDecimal("TARGET_GR_ADD_TOTAL"));
			distStmtPojo.setTotalFexiPaper(result.getBigDecimal("TOTAL_FLEXI_PAPER"));
			distStmtPojo.setAchiveMnp(result.getBigDecimal("ACHIEVEMENT_PERC_MNP"));
			distStmtPojo.setAchiveNmnp(result.getBigDecimal("ACHIEVEMENT_PERC_NMNP"));
			distStmtPojo.setAchiveTotal(result.getBigDecimal("ACHIEVEMENT_PERC_TOTAL"));
			//distStmtPojo.setDistInvoiceLink(result.getString("DIST_INVOICE_LINK"));
			distStmtPojo.setInsertDateTime(result.getString("INSERT_DATE_TIME"));
			distStmtPojo.setPayoutGross(result.getString("PAYOUT_GROSS")!=null?result.getString("PAYOUT_GROSS"):"");
			distStmtPojo.setTotalTds(result.getBigDecimal("TOTAL_TDS"));
			distStmtPojo.setTotalNet(result.getBigDecimal("TOTAL_NET"));
			distStmtPojo.setRetPayoutGross(result.getBigDecimal("RET_PAYOUT_GROSS"));
			distStmtPojo.setRetTotalTds(result.getBigDecimal("RET_TOTAL_TDS"));
			distStmtPojo.setRetTotalNet(result.getDouble("RET_TOTAL_NET"));
			distStmtPojo.setGrossAct(result.getBigDecimal("GROSS_ACT"));
			//distStmtPojo.setTotalNos(result.getBigDecimal("TOTAL_NOS"));
			//distStmtPojo.setTotalRate(result.getBigDecimal("TOTAL_RATE"));
			//distStmtPojo.setTotalRetNos(result.getBigDecimal("RET_TOTAL_NOS"));
			//distStmtPojo.setTotalRetRate(result.getBigDecimal("RET_TOTAL_RATE"));
			distStmtPojo.setStmtCycleDt(stmtCycleDt);
			distStmtPojo.setPaymentDt(result.getString("PAYMENT_DATE"));
			distStmtPojo.setArCode(result.getString("DIST_AR_CODE"));
			distStmtPojo.setDistStmtSchmList(fetchDistStmtScheme(connection, distStmtPojo.getScmListId(),circle));
			distStmtPojo.setDistRetSchmList(fetchDistRetScheme(connection, distStmtPojo.getScmListId(),circle));
			distStmtPojoList.add(distStmtPojo);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(ps!=null)
				ps.close();
			if(connection!=null)
				connection.close();
		}
		//System.outprintln(distStmtPojoList.size());
		return distStmtPojoList;
	}
	
	private List<DistributorStmtSchmPojo> fetchDistStmtScheme(Connection connection, int scmListId, String circle) throws Exception{
		PreparedStatement ps = null;
		ResultSet result = null;
		DistributorStmtSchmPojo distStmtScmPojo= null;
		List<DistributorStmtSchmPojo> distStmtScmPojoList = new ArrayList<DistributorStmtSchmPojo>();
		
		try {
			
			String query = "select STMT_SCM_ID,SCM_LIST_ID,PAY_TOTAL,GROSS_PAY_AMT,NET_COMM,TDS_AMOUNT," +
			" SCHEME_ID,COMPONENT_ID,SCHEME_COMPONENT_DESC, UNIT, RATE FROM DLP_DIST_STMT_SCM_LIST_" +circle+
			" WHERE SCM_LIST_ID = ?";
			
			ps = connection.prepareStatement(query);
			ps.setInt(1, scmListId);
			result = ps.executeQuery();
			while(result.next()){
				distStmtScmPojo = new DistributorStmtSchmPojo();
				
				distStmtScmPojo.setStatScmId(result.getInt("STMT_SCM_ID"));
				distStmtScmPojo.setSchListId(result.getInt("SCM_LIST_ID"));
				distStmtScmPojo.setPayTotal(result.getBigDecimal("PAY_TOTAL"));
				//distStmtScmPojo.setRefTotal(result.getBigDecimal("PERF_TOTAL"));
				distStmtScmPojo.setGrossPayAmt(result.getBigDecimal("GROSS_PAY_AMT"));
				distStmtScmPojo.setNetComm(result.getBigDecimal("NET_COMM"));
				distStmtScmPojo.setTdsAmount(result.getBigDecimal("TDS_AMOUNT"));
				distStmtScmPojo.setSchemeId(result.getInt("SCHEME_ID")); 
				distStmtScmPojo.setCompoentId(result.getInt("COMPONENT_ID"));
				//distStmtScmPojo.setTarget(result.getString("TARGET"));
			//	distStmtScmPojo.setAchivedPerc(result.getString("ACHIEVED_PERC"));
				distStmtScmPojo.setSchemeCompDesc(result.getString("SCHEME_COMPONENT_DESC"));
				//distStmtScmPojo.setPaymentMode(result.getString("PAYMENT_MODE"));PAYMENT_MODE
				distStmtScmPojo.setUnit(result.getString("UNIT"));
				distStmtScmPojo.setRate(result.getBigDecimal("RATE"));
				distStmtScmPojoList.add(distStmtScmPojo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(ps!=null)
				ps.close();
		}
		return distStmtScmPojoList;
		
	}
	
	private List<DistributorRetSchmPojo> fetchDistRetScheme(Connection connection, int scmListId,String circle) throws Exception{
		PreparedStatement ps = null;
		ResultSet result = null;
		DistributorRetSchmPojo distRetPojo = null;
		List<DistributorRetSchmPojo> distRetPojoList = new ArrayList<DistributorRetSchmPojo>();
		
		try {
			
			String query = "SELECT SCM_LIST_ID,PAY_TOTAL,GROSS_PAY_AMT,NET_COMM,TDS_AMOUNT,SCHEME_ID," +
			" COMPONENT_ID,SCHEME_COMPONENT_DESC,UNIT,RATE FROM DLP_DIST_RET_SCM_LIST_"+circle+
			" WHERE SCM_LIST_ID = ?";
			
			ps = connection.prepareStatement(query);
			ps.setInt(1, scmListId);
			result = ps.executeQuery();
			while(result.next()){
				distRetPojo = new DistributorRetSchmPojo();
				distRetPojo.setSchemeListId(result.getInt("SCM_LIST_ID"));
				distRetPojo.setPayTotal(result.getBigDecimal("PAY_TOTAL"));
				//distRetPojo.setRefTotal(result.getFloat("PERF_TOTAL"));PERF_TOTAL
				distRetPojo.setGrossPayAmt(result.getBigDecimal("GROSS_PAY_AMT"));
				distRetPojo.setNetComm(result.getFloat("NET_COMM"));
				distRetPojo.setTdsAmount(result.getBigDecimal("TDS_AMOUNT"));
				distRetPojo.setSheetId(result.getInt("SCHEME_ID"));
				distRetPojo.setComponentId(result.getInt("COMPONENT_ID"));
				//distRetPojo.setTarget(result.getString("TARGET"));TARGET,
				//distRetPojo.setAchivedPerc(result.getString("ACHIEVED_PERC"));ACHIEVED_PERC,
				distRetPojo.setSchemeCompDesc(result.getString("SCHEME_COMPONENT_DESC"));
				distRetPojo.setUnit(result.getString("UNIT"));
				distRetPojo.setRate(result.getBigDecimal("RATE"));
				distRetPojoList.add(distRetPojo);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(ps!=null)
				ps.close();
		}
		return distRetPojoList;
	}
	
	
	public List<RetailerStmtVO> fetchRetailerStmt(String distDsmId, String stmtDt, String circle) throws Exception{

		PreparedStatement ps = null;
		ResultSet result=null;
		Connection connection=null;
		List<RetailerStmtVO> retailerStmtList = null;
		try{
			String query = "select STATEMENT_CYCLE_ID, RETAILER_STATEMENT_ID, STATEMENT_MONTH, STATEMENT_DATE, RETAILER_DSM2_ID, RETAILER_FIRM_NAME, " +
					" RETAILER_MOBILE_NUM, RETAILER_ADDRESS, RETAILER_ZONE, DISTRIBUTOR_NAME, DISTRIBUTOR_DSM2_ID, TSM, ASM, ZBM, TSM_ID, ASM_ID, ZBM_ID, " +
					" TSM_MOBILE_NUM, ASM_MOBILE_NUM, ZBM_MOBILE_NUM,  SCM_LIST_ID, NORMAL_GROSS, MNP_GROSS, TOTAL_NET, " +
					"  GROSS_ACT, PAYOUT_GROSS,  TOTAL_TDS,  TARGET_GR_ADD_MNP, TARGET_GR_ADD_NMNP, TARGET_GR_ADD_TOTAL," +
					" ACHIEVEMENT_PERC_MNP, ACHIEVEMENT_PERC_NMNP, ACHIEVEMENT_PERC_TOTAL, TO_CHAR(STATEMENT_DATE, 'DD-MM-YYYY') PAYMENT_DATE  from DLP_RET_STATEMENT_"+circle+" where DISTRIBUTOR_DSM2_ID = ? and CYCLE_END_DT = ?";// and UPPER(CIRCLE) = UPPER(?) 
			connection = jdbcTemplate.getDataSource().getConnection();
			
			/*ps = connection.prepareStatement("select STATEMENT_CYCLE_ID, RETAILER_STATEMENT_ID, STATEMENT_MONTH, STATEMENT_DATE, RETAILER_DSM2_ID, RETAILER_FIRM_NAME, " +
				" RETAILER_MOBILE_NUM, RETAILER_ADDRESS, RETAILER_ZONE, DISTRIBUTOR_NAME, DISTRIBUTOR_DSM2_ID, TSM, ASM, ZBM, TSM_ID, ASM_ID, ZBM_ID, " +
				" TSM_MOBILE_NUM, ASM_MOBILE_NUM, ZBM_MOBILE_NUM, CIRCLE, SCM_LIST_ID, NORMAL_GROSS, MNP_GROSS, TOTAL_NET, RETAILER_INVOICE_LINK," +
				" RETAILER_OWN_NAME, GROSS_ACT, PAYOUT_GROSS, TOTAL_NOS, TOTAL_TDS, TOTAL_RATE, TARGET_GR_ADD_MNP, TARGET_GR_ADD_NMNP, TARGET_GR_ADD_TOTAL," +
				" ACHIEVEMENT_PERC_MNP, ACHIEVEMENT_PERC_NMNP, ACHIEVEMENT_PERC_TOTAL, TO_CHAR(PAYMENT_DATE, 'DD-MM-YYYY') PAYMENT_DATE  from DLP_RET_STATEMENT where DISTRIBUTOR_DSM2_ID = ? and STATEMENT_DATE = ? and UPPER(CIRCLE) = UPPER(?) ");
	*/	
			ps = connection.prepareStatement(query);
			
		ps.setString(1, distDsmId);
		ps.setString(2, stmtDt);
		//ps.setString(3, circle);
		
		result = ps.executeQuery();
		retailerStmtList = new ArrayList<RetailerStmtVO>();
		while(result.next()){
			RetailerStmtVO retailerStmtPojo = new RetailerStmtVO();
			retailerStmtPojo.setStmtCycleId(result.getInt("STATEMENT_CYCLE_ID"));
			retailerStmtPojo.setRetailerStmtId(result.getInt("RETAILER_STATEMENT_ID"));
			retailerStmtPojo.setStmtMonth(result.getString("STATEMENT_MONTH"));
			retailerStmtPojo.setStmtDt(result.getDate("STATEMENT_DATE"));
			retailerStmtPojo.setRetailerDsm2Id(result.getString("RETAILER_DSM2_ID"));
			retailerStmtPojo.setRetailerFirmName(result.getString("RETAILER_FIRM_NAME"));
			retailerStmtPojo.setRetailerMsisdn(result.getString("RETAILER_MOBILE_NUM"));
			retailerStmtPojo.setRetailerAddress(result.getString("RETAILER_ADDRESS"));
			retailerStmtPojo.setRetailerZone(result.getString("RETAILER_ZONE"));
			retailerStmtPojo.setDistributorName(result.getString("DISTRIBUTOR_NAME"));
			retailerStmtPojo.setDistributorDsm2Id(result.getString("DISTRIBUTOR_DSM2_ID"));
			retailerStmtPojo.setTsm(result.getString("TSM"));
			retailerStmtPojo.setAsm(result.getString("ASM"));
			retailerStmtPojo.setZbm(result.getString("ZBM"));
			retailerStmtPojo.setTsmId(result.getString("TSM_ID"));
			retailerStmtPojo.setAsmId(result.getString("ASM_ID"));
			retailerStmtPojo.setZbmId(result.getString("ZBM_ID"));
			retailerStmtPojo.setTsmMsisdn(result.getString("TSM_MOBILE_NUM"));
			retailerStmtPojo.setAsmMsisdn(result.getString("ASM_MOBILE_NUM"));
			retailerStmtPojo.setZbmMsisdn(result.getString("ZBM_MOBILE_NUM"));
			//retailerStmtPojo.setCircleCode(result.getString("CIRCLE"));
			retailerStmtPojo.setCircleCode(circle);
			retailerStmtPojo.setScmListId(result.getInt("SCM_LIST_ID"));
			retailerStmtPojo.setNormalGross(result.getInt("NORMAL_GROSS"));
			retailerStmtPojo.setMnpGross(result.getInt("MNP_GROSS"));
			retailerStmtPojo.setTotalNet(result.getBigDecimal("TOTAL_NET"));
			//retailerStmtPojo.setRetailerInvoiceLink(result.getString("RETAILER_INVOICE_LINK"));
			//retailerStmtPojo.setRetailerOwnName(result.getString("RETAILER_OWN_NAME"));
			retailerStmtPojo.setGrossAct(result.getInt("GROSS_ACT"));
			
			retailerStmtPojo.setPayoutGross(result.getBigDecimal("PAYOUT_GROSS"));
			//retailerStmtPojo.setTotalNos(result.getBigDecimal("TOTAL_NOS"));
			retailerStmtPojo.setTotalTds(result.getBigDecimal("TOTAL_TDS"));
			//retailerStmtPojo.setTotalRate(result.getBigDecimal("TOTAL_RATE"));
			retailerStmtPojo.setTargetGrAddMnp(result.getBigDecimal("TARGET_GR_ADD_MNP"));
			retailerStmtPojo.setTargetGrAddNmnp(result.getBigDecimal("TARGET_GR_ADD_NMNP"));
			retailerStmtPojo.setTargetGrAddTotal(result.getBigDecimal("TARGET_GR_ADD_TOTAL"));
			retailerStmtPojo.setAchievementPercMnp(result.getBigDecimal("ACHIEVEMENT_PERC_MNP"));
			retailerStmtPojo.setAchievementPercNmnp(result.getBigDecimal("ACHIEVEMENT_PERC_NMNP"));
			retailerStmtPojo.setAchievementPercTotal(result.getBigDecimal("ACHIEVEMENT_PERC_TOTAL"));
			
			retailerStmtPojo.setPaymentDt(result.getString("PAYMENT_DATE"));
			//retailerStmtPojo.setRetailerSubList(fetchRetailerStmtScmList(connection, retailerStmtPojo.getScmListId()));PAYMENT_DATE
			
			retailerStmtPojo.setRetailerSubMap(fetchRetailerStmtScmMap(connection, retailerStmtPojo.getScmListId(),circle));
			
			retailerStmtList.add(retailerStmtPojo);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(ps!=null)
				ps.close();
			if(result!=null)
				result.close();
			if(connection!=null)
				connection.close();
		}
		////System.outprintln(retailerStmtList.size());
		return retailerStmtList;
	}
	
	private Map<String,List<RetailerStmtScmList>> fetchRetailerStmtScmMap(Connection connection, int scmListId, String circle) throws Exception{
		PreparedStatement ps = null;
		ResultSet result = null;
		Map<String,List<RetailerStmtScmList>> retailerStmtScmList = new HashMap<String,List<RetailerStmtScmList>>();
		
		List<RetailerStmtScmList> retailerStmtScmListOTF = new ArrayList<RetailerStmtScmList>();
		List<RetailerStmtScmList> retailerStmtScmListOthers = new ArrayList<RetailerStmtScmList>();
		
		try {

			String query = "select STMT_SCM_ID, SCM_LIST_ID, PAY_TOTAL,  GROSS_PAY_AMT, NET_COMM, TDS_AMOUNT, SCHEME_ID, COMPONENT_ID, " +
					" SCHEME_COMPONENT_DESC, SCHEME_TYPE,  UNIT, RATE from DLP_RET_STMT_SCM_LIST_"+circle+" where SCM_LIST_ID = ? order by SCHEME_TYPE asc";

			ps = connection.prepareStatement(query);
			ps.setInt(1, scmListId);
			result = ps.executeQuery();
			while(result.next()){
				RetailerStmtScmList retPojo = new RetailerStmtScmList();
				retPojo.setStmtScmId(result.getInt("STMT_SCM_ID"));
				retPojo.setScmListId(result.getInt("SCM_LIST_ID"));
				retPojo.setPaytotal(result.getBigDecimal("PAY_TOTAL"));
				//retPojo.setPerftotal(result.getFloat("PERF_TOTAL"));PAYMENT_MODE,
				retPojo.setGrossPayAmt(result.getBigDecimal("GROSS_PAY_AMT"));
				retPojo.setNetComm(result.getBigDecimal("NET_COMM"));
				retPojo.setTdsAmount(result.getBigDecimal("TDS_AMOUNT"));
				retPojo.setSchemeId(result.getInt("SCHEME_ID"));
				retPojo.setCompId(result.getInt("COMPONENT_ID"));
				retPojo.setSchemeCompDesc(result.getString("SCHEME_COMPONENT_DESC"));
				retPojo.setSchemeType(result.getString("SCHEME_TYPE"));
				retPojo.setUnit(result.getString("UNIT"));
				retPojo.setRate(result.getBigDecimal("RATE"));
				if("OTF".equalsIgnoreCase(result.getString("SCHEME_TYPE"))){
					retailerStmtScmListOTF.add(retPojo);
				}else if(!"OTF".equalsIgnoreCase(result.getString("SCHEME_TYPE"))){
					retailerStmtScmListOthers.add(retPojo);
				}
				
			}
			
			retailerStmtScmList.put("OTF",retailerStmtScmListOTF);
			retailerStmtScmList.put("Other",retailerStmtScmListOthers);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(ps!=null){
				ps.close();
			}if(result!=null){
				result.close();
			}
		}
		return retailerStmtScmList;
	}

	@Override
	public String selectedStmtGenEmailConfig(String distDsmId, String circle) throws Exception {
		try{
			String[] data =  distDsmId.split(":");
			List<Object[]> paramObj = null;
			if(data != null){
				paramObj = new ArrayList<Object[]>();
				for(String value : data){
					String[] dataValue = value.split(",");
					String[] str = dataValue[1].split("TO");
					Object[] object = new Object[]{dataValue[0],circle,str[1]};
					paramObj.add(object);
				}
				int[] count = jdbcTemplate.batchUpdate(StmtGenQueries.CPS_EMAIL_CONFIG2, paramObj);
				//System.outprintln(count[0]+" paramObj:::: "+paramObj);
				if(count.length != 0)
					return "Successfully Email Configured To Scheduled.";
			}
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}catch(DataAccessException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return "Failed To Email Scheduled.";
	}
	@SuppressWarnings("unused")
	@Override
	public String stmtGenEmailConfig(String distDsmId, String startEndDtParam, String circle) throws Exception {
		try{
				String[] str = startEndDtParam.split("TO");
				SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DLP_EMAIL_SCHEDULER_CONFIG");
				Map<String, Object> inParamMap = new HashMap<String, Object>();
				inParamMap.put("pCIRCLE", circle);
				inParamMap.put("pStmtCycleId", distDsmId);
				inParamMap.put("pSTARTDT", str[0]);
				inParamMap.put("pENDDT", str[1]);
				
				SqlParameterSource in = new MapSqlParameterSource(inParamMap);
				Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
				String val= (String) simpleJdbcCallResult.get("pOUT_VAL");
				////System.outprintln("  value :::::::::::::::::::::::::;;;; "+val+"  ::::: "+simpleJdbcCallResult);
				//if(simpleJdbcCallResult.get("pOUT_VAL")!=null)
			return simpleJdbcCallResult.toString();
		}catch(Exception e){
			e.printStackTrace();
		}
		return "Failed To Email Scheduled.";
	}
	@Override
	public List<StmtReqMapping> searchReqStmtSearch(String endDt, String circleCode, int circleId, String stmtCycleId) throws Exception {
		/*String query = "select SM.SCHEME_ID,SM.SCHEME_NAME, CM.COMPONENT_ID,CM.COMPONENET_NAME, cm.pay_to, em.display_value," +
				"  Cm.Payout_Approval_Dt,cm.PAYOUT_STATUS,cm.PAYMENT_STATUS, CM.PAYMENT_ID,TO_CHAR(cm.START_DATE, 'DD-MON-YYYY') START_DATE,TO_CHAR(cm.END_DATE, 'DD-MON-YYYY') END_DATE, " +
				" TO_CHAR(DP.PAYMENT_DATE, 'DD-MON-YYYY') PAYMENT_DATE from DLP_SCHEME_STATEMENT_MAP_"+circleCode+" ss," +
				" DLP_SCHEME_COMP_MAPPING CM ,  DLP_SCHEME_MASTER SM, dlp_entity_type_master em, DLP_PAYMENT_"+circleCode+" DP" +
				" where TRUNC(SS.END_DATE)    <= ? AND SM.CIRCLE_ID = ?" +
				" AND CM.VALIDITY_FLAG  ='Y' AND CM.SCM_STATUS ='C' AND CM.PAYOUT_STATUS ='A'" +
				" AND CM.PAYMENT_STATUS = 'P' AND CM.STATEMENT_STATUS <> 'S' AND CM.STATEMENT_CYCLE_ID IS NULL" +
				" AND SS.work_status='W' AND CM.VALIDITY_FLAG = SM.VALIDITY_FLAG AND DP.PAYMENT_ID = CM.PAYMENT_ID AND SS.SCM_ID = SM.SCHEME_ID " +
				" AND CM.SCHEME_ID = SM.SCHEME_ID AND CM.COMPONENT_ID = SS.Comp_Id AND cm.pay_to = em.entity_type_id";
	*/
		String query = "select SM.SCHEME_ID,SM.SCHEME_NAME, CM.COMPONENT_ID,CM.COMPONENET_NAME, cm.pay_to, em.display_value," +
				"  Cm.Payout_Approval_Dt,cm.PAYOUT_STATUS,cm.PAYMENT_STATUS, CM.PAYMENT_ID,TO_CHAR(cm.START_DATE, 'DD-MON-YYYY') START_DATE,TO_CHAR(cm.END_DATE, 'DD-MON-YYYY') END_DATE " +
				"  from DLP_SCHEME_STATEMENT_MAP_"+circleCode+" ss," +
				" DLP_SCHEME_COMP_MAPPING CM ,  DLP_SCHEME_MASTER SM, dlp_entity_type_master em " +
				" where TRUNC(SS.END_DATE)    <= ? AND SM.CIRCLE_ID = ?" +
				" AND CM.VALIDITY_FLAG  ='Y' AND CM.SCM_STATUS ='C' AND CM.PAYOUT_STATUS ='A'" +
				" AND CM.PAYMENT_STATUS = 'U' AND CM.STATEMENT_STATUS <> 'S' AND CM.STATEMENT_CYCLE_ID IS NULL" +
				" AND SS.work_status='W' AND CM.VALIDITY_FLAG = SM.VALIDITY_FLAG  AND SS.SCM_ID = SM.SCHEME_ID " +
				" AND CM.SCHEME_ID = SM.SCHEME_ID AND CM.COMPONENT_ID = SS.Comp_Id AND cm.pay_to = em.entity_type_id and ss.STATEMENT_CYCLE_ID=?  order by  SCHEME_ID, COMPONENT_ID";
	
		
		
		////System.outprintln("StmtGenDAOImpl || searchReqStmtSearch  || END date :"+endDt+" circleId:"+circleCode);
	List<StmtReqMapping> entAttrList = jdbcTemplate.query(query,new Object[]{endDt,circleId,stmtCycleId}, new RowMapper<StmtReqMapping>() {
		@Override
		public StmtReqMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
			StmtReqMapping obj = new StmtReqMapping();
			obj.setScmId(rs.getInt("SCHEME_ID"));
			obj.setScmName((rs.getString("SCHEME_NAME")));
			obj.setCompId(rs.getInt("COMPONENT_ID"));
			obj.setCompName(rs.getString("COMPONENET_NAME"));
			obj.setPayoutStatus(rs.getString("PAYOUT_STATUS"));
			obj.setPayTo(rs.getString("display_value"));
			obj.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
			obj.setPayoutApprovalDt(rs.getString("Payout_Approval_Dt"));
			obj.setPaymentId(rs.getInt("PAYMENT_ID"));
			obj.setStartDt(rs.getString("START_DATE"));
			obj.setEndDt(rs.getString("END_DATE"));
			//obj.setPaymentDt(rs.getString("PAYMENT_DATE"));
			obj.setPaymentDt(null);
			return obj;
		}
	});
	return entAttrList;
}

	@Override
	public int deleteSchemeStatementMap(String scmcompId, String circleCode)	throws Exception {
		try{
			String query ="delete from DLP_SCHEME_STATEMENT_MAP_"+circleCode+" where SCM_ID = ? and COMP_ID = ?";
			String[] data =  scmcompId.split(":");
			List<Object[]> paramObj = null;
			if(data != null){
				paramObj = new ArrayList<Object[]>();
				for(String value : data){
					String[] dataValue = value.split(",");
					Object[] object = new Object[]{dataValue[0],dataValue[1]};
					paramObj.add(object);
				}
				int[] count = jdbcTemplate.batchUpdate(query, paramObj);
				////System.outprintln("deleted : "+scmcompId+" success 1 : fail 0 ::::"+count[0]);
				return count[0];
			}
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}catch(DataAccessException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;
	}

	@Override
	public String saveSchemeStatementMap(String scmcompId, String circleCode, String userId,int stmtCycleId) throws Exception {
		try{
			String query ="update DLP_SCHEME_STATEMENT_MAP_"+circleCode+" set STATEMENT_CYCLE_ID=?, USER_ID='"+userId+"', PAYMENT_DATE = sysdate where SCM_ID=? and COMP_ID = ?";
			stmtCycleId=1;
			String[] data =  scmcompId.split(":");
			List<Object[]> paramObj = null;
			if(data != null){
				paramObj = new ArrayList<Object[]>();
				for(String value : data){
					String[] dataValue = value.split(",");
					Object[] object = new Object[]{stmtCycleId,dataValue[0], dataValue[1]};
					paramObj.add(object);
				}
				int[] count = jdbcTemplate.batchUpdate(query, paramObj);
				//System.outprintln(count[0]);
				if(count.length != 0)
					return "Successfully saved the schemes for statement generation.";
			}
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}catch(DataAccessException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return "Failed to save the schemes for statement generation .";
	}

	@Override
	public int insertSchemeStatementMap(String scmcompId, String circleCode, String userId) throws Exception {
		try{
			String query ="insert into DLP_SCHEME_STATEMENT_MAP_"+circleCode+" (SCM_ID, COMP_ID, START_DATE, END_DATE, WORK_STATUS, USER_ID, VALIDITY_FLAG, INSERT_DATE_TIME, STATEMENT_CYCLE_ID,CIRCLE  ) values" +
					"(?,?,?,?,'W','"+userId+"','Y',sysdate,?,'"+circleCode+"')";
			String[] data =  scmcompId.split(":");
			List<Object[]> paramObj = null;
			if(data != null){
				paramObj = new ArrayList<Object[]>();
				for(String value : data){
					String[] dataValue = value.split(",");
					Object[] object = new Object[]{dataValue[0],dataValue[1],dataValue[2],dataValue[3],dataValue[4]};
					paramObj.add(object);
				}
				int[] count = jdbcTemplate.batchUpdate(query, paramObj);
				//System.outprintln("insert : "+scmcompId+" success 1 : fail 0 ::::"+count[0]);
				return count[0];
			}
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}catch(DataAccessException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return 0;	
	}
	
	@Override
	public List<StmtGenCycleMaster> searchStmtPeriod(String circleCode, String serviceType) throws Exception {
		String query = "select rownum, a.* from" +
				" (select STATEMENT_CYCLE_ID, CIRCLE, TO_CHAR(CYCLE_START_DT,'DD-MON-YYYY') || ' TO ' || TO_CHAR(CYCLE_END_DT,'DD-MON-YYYY') START_END_DT," +
				//" NO_OF_STATEMENTS, " +
				"CYCLE_STATUS, STATEMENT_MONTH, TO_CHAR(STATEMENT_DT,'DD-MON-YYYY') STATEMENT_DT, STATEMENT_GEN_STATUS, TO_CHAR(CYCLE_END_DT,'DD-MON-YYYY') CYCLE_END_DT" +
				" from DLP_STATEMENT_CYCLE_MASTER where" +
				" UPPER(CIRCLE)=UPPER(?) and UPPER(CYCLE_STATUS)= UPPER('open') and upper(SERVICE_TYPE) = upper(?)  order by CYCLE_START_DT asc) a";
		
		List<StmtGenCycleMaster> reportList = jdbcTemplate.query(query, new Object[]{circleCode, serviceType}, new RowMapper<StmtGenCycleMaster>() {
			@Override
			public StmtGenCycleMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				StmtGenCycleMaster stmtGenCycleMaster = new StmtGenCycleMaster();
				stmtGenCycleMaster.setStmtCycleId(rs.getInt("STATEMENT_CYCLE_ID"));
				stmtGenCycleMaster.setCycle(rs.getString("CIRCLE"));
				stmtGenCycleMaster.setStartEndDt(rs.getString("START_END_DT"));
				//stmtGenCycleMaster.setNoOfStmt(rs.getInt("NO_OF_STATEMENTS"));
				stmtGenCycleMaster.setCycleStatus(rs.getString("CYCLE_STATUS"));
				stmtGenCycleMaster.setStmtMonth(rs.getString("STATEMENT_MONTH"));
				stmtGenCycleMaster.setStmtDt(rs.getString("STATEMENT_DT"));
				stmtGenCycleMaster.setStmtGenStatus(rs.getString("STATEMENT_GEN_STATUS"));
				stmtGenCycleMaster.setCountId(rs.getInt("rownum"));
				stmtGenCycleMaster.setCycleEndDt(rs.getString("CYCLE_END_DT"));
				return stmtGenCycleMaster;
			}
		});
		return reportList;
	}

	/*@Override
	public String reqForStmtGenerate(int stmtCycleId, String circleCode) {

		try{
			String query ="update DLP_STATEMENT_CYCLE_MASTER set statement_dt = sysdate+1 where upper(CIRCLE) = upper(?) and upper(CYCLE_STATUS) = upper('OPEN') and statement_cycle_id = ?";
				int count = jdbcTemplate.update(query, new Object[]{circleCode,stmtCycleId});
				//System.outprintln(count);
				if(count != 0)
					return "Successfully saved the schemes for statement generation.";
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}catch(DataAccessException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return "Failed to save the schemes for statement generation .";
	
	}
	*/
	
	@Override
	public String reqForStmtGenerate(int stmtCycleId, String circleCode)  throws Exception{

		try{
			//System.outprintln("reqForStmtGenerate ::: stmtCycleId :: "+stmtCycleId+"   circleCode :: "+circleCode);
			 int recCount=validateStmtGen(stmtCycleId,circleCode);
			
			 if(recCount!=0)
			 {
			String query ="update DLP_STATEMENT_CYCLE_MASTER set statement_dt = sysdate+1 where upper(CIRCLE) = upper(?) and upper(CYCLE_STATUS) = upper('OPEN') and statement_cycle_id = ?";
				int count = jdbcTemplate.update(query, new Object[]{circleCode,stmtCycleId});
				//System.outprintln("reqForStmtGenerate ::: count :: "+count);
				if(count != 0)
					return "1";
			 }
			 else
				 return "2";
		}catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}catch(DataAccessException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return "3";
	
	}
	
	
	@SuppressWarnings("deprecation")
	private int validateStmtGen(int stmtCycleId,String circleCode) throws Exception
	{
		//System.outprintln("StmtGenDAOImpl || validateStmtGen || BEG");
		String query="Select COUNT(*) From Dlp_Scheme_Statement_Map_"+circleCode+" Where Statement_Cycle_Id=?";
		//System.outprintln("StmtGenDAOImpl || validateStmtGen || query:"+query);
		int count=jdbcTemplate.queryForInt(query, new Object[]{stmtCycleId});
		//System.outprintln("StmtGenDAOImpl || validateStmtGen ||  count:"+count);
		
		return count;
	}
	
	
	@Override
	public List<PartnerChannelStatementPojo> searchViewPartnerChannelStmtSearch(String endDt, String circleCode, String msisdn, String distId, int start, int limit, String stmtCycleId) {
		
		String query = "SELECT C.* ,  (SELECT COUNT(1)  FROM    (SELECT STATEMENT_NO, CP_ID, CP_NAME, PARTNER_TYPE, CP_EMAIL, CONTRACT_END_DT, GRAND_TOTAL, BENEFICIARY, TOT_GROSS_AMT,"+
				" TOT_NET_AMT, APPLICATION_NAME, SCM_LIST_ID  FROM DLP_STMT_SUMMARY_"+circleCode+"    WHERE CYCLE_END_DT = '"+endDt+"'    AND  STATEMENT_CYCLE_ID = '"+stmtCycleId+"'  AND CP_MOBILE_NO LIKE '"+msisdn+"%'    AND upper(CP_NAME) LIKE upper('%"+distId+"%'))) NO_OF_RECORDS "+
				" FROM  (SELECT a.*,    rownum ROW_NUM  FROM  (SELECT B.*    FROM (SELECT STATEMENT_NO, CP_ID, CP_NAME, PARTNER_TYPE, CP_EMAIL, CONTRACT_END_DT, GRAND_TOTAL, BENEFICIARY, TOT_GROSS_AMT,"+
				" TOT_NET_AMT, APPLICATION_NAME, SCM_LIST_ID  FROM DLP_STMT_SUMMARY_"+circleCode+"  WHERE CYCLE_END_DT= '"+endDt+"'  AND  STATEMENT_CYCLE_ID = '"+stmtCycleId+"'  AND (CP_MOBILE_NO LIKE '"+msisdn+"%' OR CP_MOBILE_NO is null) AND upper(CP_NAME) LIKE upper('%"+distId+"%'))b)a)c WHERE ROW_NUM BETWEEN "+(start+1)+" AND "+(start+limit);
			
		
			//System.out.println("Partner Channel stmts query ::: "+query);
			List<PartnerChannelStatementPojo> distList = jdbcTemplate.query(query, new RowMapper<PartnerChannelStatementPojo>() {
				@Override
				public PartnerChannelStatementPojo mapRow(ResultSet rs, int rowNum) throws SQLException {
					PartnerChannelStatementPojo viewStmt = new PartnerChannelStatementPojo();
					viewStmt.setStmtNo(rs.getString("STATEMENT_NO"));
					viewStmt.setCpId(rs.getString("CP_ID"));
					viewStmt.setCpName(rs.getString("CP_NAME"));
					viewStmt.setPartnerType(rs.getString("PARTNER_TYPE"));
					viewStmt.setEmail(rs.getString("CP_EMAIL"));
					viewStmt.setContractEndDt(rs.getString("CONTRACT_END_DT"));
					viewStmt.setGrandTotal(rs.getBigDecimal("GRAND_TOTAL"));
					viewStmt.setBeneficiary(rs.getString("BENEFICIARY"));
					viewStmt.setTotNetAmt(rs.getBigDecimal("TOT_NET_AMT"));
					viewStmt.setApplicationName(rs.getString("APPLICATION_NAME"));
					viewStmt.setTotGrossAmt(rs.getBigDecimal("TOT_GROSS_AMT"));
					viewStmt.setTotalCount(rs.getInt("NO_OF_RECORDS"));
					viewStmt.setScmListId(rs.getInt("SCM_LIST_ID"));
					return viewStmt;
				}
			});
			return distList;
	}

	@Override
	public List<PartnerChannelStatementPojo> fetchChannelPartnerStmt(String distributorID, String stmtDt, String circle, String stmtCycleDt) throws Exception {

		Connection connection=null;
		PreparedStatement ps = null;
		ResultSet result=null;
		PartnerChannelStatementPojo distStmtPojo;
		List<PartnerChannelStatementPojo> distStmtPojoList = null;
		try{
			String query = "SELECT CIRCLE,STATEMENT_CYCLE_ID,STATEMENT_NO,STATEMENT_DATE,CYCLE_END_DT,CP_ID,CP_NAME,PARTNER_TYPE,CP_MOBILE_NO,CP_PAN_NO,CP_EMAIL,"+
					"CP_ADDRESS,CP_COUNTRY,CONTRACT_END_DT,SCM_LIST_ID,GRAND_TOTAL,AMT_IN_WORDS,BENEFICIARY,BANK_ACCOUNT_NO,BANK_NAME,IFSC_CODE,BANK_BRANCH,"+
					"INSERT_DATE_TIME,TOT_GROSS_AMT,TOT_NET_AMT,STR_NO,APPLICATION_NAME FROM DLP_STMT_SUMMARY_"+circle+" WHERE SCM_LIST_ID = ? AND CYCLE_END_DT = ?  order by CIRCLE";
			
			connection = jdbcTemplate.getDataSource().getConnection();
			ps = connection.prepareStatement(query);
			ps.setString(1, distributorID);
			ps.setString(2, stmtDt);
		//System.outprintln("stmtDt ::::: "+stmtDt);
		result = ps.executeQuery();
		distStmtPojoList = new ArrayList<PartnerChannelStatementPojo>();
		while(result.next()){
			distStmtPojo = new PartnerChannelStatementPojo();
			distStmtPojo.setCircle(result.getString("CIRCLE"));
			distStmtPojo.setStmtCycleId(result.getInt("STATEMENT_CYCLE_ID"));
			distStmtPojo.setStmtNo(result.getString("STATEMENT_NO"));
			//distStmtPojo.setStmtDt(result.getString("STATEMENT_DATE"));//stmtCycleDt
			distStmtPojo.setStmtDt(stmtDt);
			distStmtPojo.setCycleDt(result.getString("CYCLE_END_DT"));
			distStmtPojo.setCpId(result.getString("CP_ID"));
			distStmtPojo.setCpName(result.getString("CP_NAME"));
			distStmtPojo.setPartnerType(result.getString("PARTNER_TYPE"));
			distStmtPojo.setMobileNo(result.getString("CP_MOBILE_NO"));
			distStmtPojo.setPanNo(result.getString("CP_PAN_NO"));
			distStmtPojo.setEmail(result.getString("CP_EMAIL"));
			distStmtPojo.setAddress(result.getString("CP_ADDRESS"));
			distStmtPojo.setCountry(result.getString("CP_COUNTRY"));
			distStmtPojo.setContractEndDt(result.getString("CONTRACT_END_DT"));
			distStmtPojo.setScmListId(result.getInt("SCM_LIST_ID"));
			distStmtPojo.setGrandTotal(result.getBigDecimal("GRAND_TOTAL"));
			distStmtPojo.setAmtWords(result.getString("AMT_IN_WORDS"));
			distStmtPojo.setBeneficiary(result.getString("BENEFICIARY"));
			distStmtPojo.setAccountNo(result.getString("BANK_ACCOUNT_NO"));
			distStmtPojo.setBankName(result.getString("BANK_NAME"));
			distStmtPojo.setIfscCode(result.getString("IFSC_CODE"));
			distStmtPojo.setBankBranch(result.getString("BANK_BRANCH"));
			distStmtPojo.setTotGrossAmt(result.getBigDecimal("TOT_GROSS_AMT"));
			distStmtPojo.setTotNetAmt(result.getBigDecimal("TOT_NET_AMT"));
			distStmtPojo.setStrNo(result.getString("STR_NO"));
			distStmtPojo.setApplicationName(result.getString("APPLICATION_NAME"));
			
			distStmtPojo.setMonthScmList(fetchCPStmtScheme(connection, distStmtPojo.getScmListId(),circle,distStmtPojo.getPartnerType()));
			distStmtPojoList.add(distStmtPojo);
		}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(ps!=null)
				ps.close();
			if(connection!=null)
				connection.close();
		}
		//System.outprintln(distStmtPojoList.size());
		return distStmtPojoList;
	
	}
	
	private List<PartnerChannelStmtScmListPojo> fetchCPStmtScheme(Connection connection, int scmListId, String circle, String partnerType) throws Exception{
		PreparedStatement ps = null;
		ResultSet result = null;
		PreparedStatement ps1 = null;
		ResultSet result1 = null;
		PartnerChannelStmtScmListPojo distStmtScmPojo= null;
		List<PartnerChannelStmtScmListPojo> distStmtScmPojoList = new ArrayList<PartnerChannelStmtScmListPojo>();
		
		try {
			
			String query = "select MSS.SCM_LIST_ID,MSS.SCM_ID,MSS.COMP_ID,MSS.MODEL_NAME,MSS.SERVICE_TYPE,MSS.CP_ID,MSS.GROSS_REVENUE,MSS.TOTAL_DEDUCTION,MSS.NET_REVENUE,"+
					" MSS.USAGES_PERCENTAGE,MSS.REVENUE_SHARE,MSS.REVENUE_SHARE_PERCENTAGE,MSS.SUB_TOTAL,MSS.CIRCLE,sm.scheme_name,cm.componenet_name,"+
					" mss.INSERT_DATE_TIME, case when MSS.sub_total >0 then  spell_indian_money(MSS.sub_total)" +
					"     when MSS.sub_total <0 then  'Minus '|| spell_indian_money(abs(MSS.sub_total))" +
					" end amount_in_words" +
					" from DLP_MONTHWISE_STMT_SCM_LIST_CU  MSS, dlp_scheme_master sm, dlp_scheme_comp_mapping cm WHERE SCM_LIST_ID = ? and mss.scm_id=sm.scheme_id"+
					" and mss.comp_id = cm.component_id and sm.scheme_id = cm.scheme_id and sm.validity_flag = 'Y' and cm.validity_flag = 'Y' and  MSS.CIRCLE <> 'CU' order by MSS.CIRCLE";
			
			
			String query1 = "select MSS.SCM_LIST_ID,MSS.SCM_ID,MSS.COMP_ID,MSS.MODEL_NAME,MSS.SERVICE_TYPE,MSS.CP_ID,MSS.GROSS_REVENUE,MSS.TOTAL_DEDUCTION,MSS.NET_REVENUE,"+
					" MSS.USAGES_PERCENTAGE,MSS.REVENUE_SHARE,MSS.REVENUE_SHARE_PERCENTAGE,MSS.SUB_TOTAL,MSS.CIRCLE,sm.scheme_name,cm.componenet_name,"+
					" mss.INSERT_DATE_TIME, case when MSS.sub_total >0 then  spell_indian_money(MSS.sub_total)" +
					"     when MSS.sub_total <0 then  'Minus '|| spell_indian_money(abs(MSS.sub_total))" +
					" end amount_in_words" +
					" from DLP_MONTHWISE_STMT_SCM_LIST_CU  MSS, dlp_scheme_master sm, dlp_scheme_comp_mapping cm WHERE SCM_LIST_ID = ? and mss.scm_id=sm.scheme_id"+
					" and mss.comp_id = cm.component_id and sm.scheme_id = cm.scheme_id and sm.validity_flag = 'Y' and cm.validity_flag = 'Y' and MSS.CIRCLE = 'CU' order by MSS.CIRCLE";
			
			
			ps1 = connection.prepareStatement(query1);
			ps1.setInt(1, scmListId);
			result1 = ps1.executeQuery();
			while(result1.next()){
				distStmtScmPojo = new PartnerChannelStmtScmListPojo();
				distStmtScmPojo.setScmListId(result1.getInt("SCM_LIST_ID"));
				distStmtScmPojo.setScmId(result1.getInt("SCM_ID"));
				distStmtScmPojo.setCompId(result1.getInt("COMP_ID"));
				distStmtScmPojo.setModelName(result1.getString("MODEL_NAME"));
				distStmtScmPojo.setServiceType(result1.getString("SERVICE_TYPE"));
				distStmtScmPojo.setCpId(result1.getString("CP_ID"));
				distStmtScmPojo.setGrossRevenue(result1.getBigDecimal("GROSS_REVENUE"));
				distStmtScmPojo.setTotalDeduction(result1.getBigDecimal("TOTAL_DEDUCTION")); 
				distStmtScmPojo.setNetRevenue(result1.getBigDecimal("NET_REVENUE"));
				distStmtScmPojo.setUsagesPercent(result1.getBigDecimal("USAGES_PERCENTAGE"));
				distStmtScmPojo.setRevenueShare(result1.getBigDecimal("REVENUE_SHARE"));
				distStmtScmPojo.setRevenueSharePercent(result1.getBigDecimal("REVENUE_SHARE_PERCENTAGE"));
				distStmtScmPojo.setSubTotal(result1.getBigDecimal("SUB_TOTAL"));
				distStmtScmPojo.setCircle(result1.getString("CIRCLE"));
				distStmtScmPojo.setSchemeName(result1.getString("scheme_name"));
				distStmtScmPojo.setCompName(result1.getString("componenet_name"));
				distStmtScmPojo.setAmtInWords(result1.getString("amount_in_words"));
				
				distStmtScmPojoList.add(distStmtScmPojo);
			}
			
			ps = connection.prepareStatement(query);
			ps.setInt(1, scmListId);
			result = ps.executeQuery();
			while(result.next()){
				distStmtScmPojo = new PartnerChannelStmtScmListPojo();
				distStmtScmPojo.setScmListId(result.getInt("SCM_LIST_ID"));
				distStmtScmPojo.setScmId(result.getInt("SCM_ID"));
				distStmtScmPojo.setCompId(result.getInt("COMP_ID"));
				distStmtScmPojo.setModelName(result.getString("MODEL_NAME"));
				distStmtScmPojo.setServiceType(result.getString("SERVICE_TYPE"));
				distStmtScmPojo.setCpId(result.getString("CP_ID"));
				distStmtScmPojo.setGrossRevenue(result.getBigDecimal("GROSS_REVENUE"));
				distStmtScmPojo.setTotalDeduction(result.getBigDecimal("TOTAL_DEDUCTION")); 
				distStmtScmPojo.setNetRevenue(result.getBigDecimal("NET_REVENUE"));
				distStmtScmPojo.setUsagesPercent(result.getBigDecimal("USAGES_PERCENTAGE"));
				distStmtScmPojo.setRevenueShare(result.getBigDecimal("REVENUE_SHARE"));
				distStmtScmPojo.setRevenueSharePercent(result.getBigDecimal("REVENUE_SHARE_PERCENTAGE"));
				distStmtScmPojo.setSubTotal(result.getBigDecimal("SUB_TOTAL"));
				distStmtScmPojo.setCircle(result.getString("CIRCLE"));
				distStmtScmPojo.setSchemeName(result.getString("scheme_name"));
				distStmtScmPojo.setCompName(result.getString("componenet_name"));
				distStmtScmPojo.setAmtInWords(result.getString("amount_in_words"));
				
				distStmtScmPojoList.add(distStmtScmPojo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			if(ps!=null)
				ps.close();
			if(ps1!=null)
				ps1.close();
			
		}
		return distStmtScmPojoList;
		
	}

	@Override
	public List<String> fetchChannelPartnerCircleList(String distributorID, String circle) {


		Connection connection=null;
		PreparedStatement ps = null;
		ResultSet result = null;
		List<String> list = null;
		try{
			String query = "select distinct circle from dlp_monthwise_stmt_scm_list_"+circle+" where scm_list_id = ? order by circle";
			connection = jdbcTemplate.getDataSource().getConnection();
			ps = connection.prepareStatement(query);
			ps.setString(1, distributorID);
			result = ps.executeQuery();
			boolean flag = true;
			while(result.next()){
				if(flag){
					list = new ArrayList<String>();
					flag=false;
				}
			list.add(result.getString("circle"));
			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(ps!=null)
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if(connection!=null)
				try {
					connection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
		}
		return list;
	}

	
	@Override
	public List<StmtCpBean> fetchCpStmt(String cpName, String stmtDt) throws Exception {

		List<StmtCpBean> listContact = null;
		try{
			//System.outprintln("STMTDT:: "+stmtDt+" ::: CPNAME:: "+ cpName);
			String query = "SELECT CP_ID,SCM_MONTH,USAGE_TYPE,SUM(PARTNER_SUBSCRIBER_COUNT) PARTNER_SUBSCRIBER_COUNT ,sum(TOTAL_SUBSCRIBER_CNT) TOTAL_SUBSCRIBER_CNT," +
					" SUM(TOTAL_REVENUE) TOTAL_REVENUE ,SUM(NET_REVENUE) NET_REVENUE,POOL_PER," +
					" SUM(POOL_AMOUNT) POOL_AMOUNT ,MAX(TOTAL_STREAMS) TOTAL_STREAMS,SUM(PARTNER_STREAMS) PARTNER_STREAMS ,SUM(MKT_SHARE_PER) MKT_SHARE_PER ,SUM(PARTNER_PAYOUT)" +
					" PARTNER_PAYOUT from (select cp_id,SCM_MONTH,USAGE_TYPE,PARTNER_SUBSCRIBER_COUNT,TOTAL_SUBSCRIBER_CNT,TOTAL_REVENUE," +
					" case when usage_type='BUNDLE' then null else NET_REVENUE end net_revenue," +
					" POOL_PER,POOL_AMOUNT,TOTAL_STREAMS,PARTNER_STREAMS,MKT_SHARE_PER,PARTNER_PAYOUT" +
					" FROM cpsdata.DLP_MUSIC_CIRWISE_SUMMARY WHERE SCM_MONTH = ? AND CP_NAME LIKE ?)" +
					" GROUP BY USAGE_TYPE,CP_ID,SCM_MONTH,POOL_PER ORDER BY 1 DESC";

			listContact = jdbcTemplate.query(query, new Object[]{stmtDt, cpName}, new RowMapper<StmtCpBean>() {
				@Override
				public StmtCpBean mapRow(ResultSet rs, int rowNum) throws SQLException {
					StmtCpBean bean=new StmtCpBean();
					bean.setCpId(rs.getString("CP_ID"));
					bean.setScmMonth(rs.getString("SCM_MONTH"));
					bean.setUsageType(rs.getString("USAGE_TYPE"));
					bean.setSubscriberCount((rs.getString("PARTNER_SUBSCRIBER_COUNT") != null ) ? rs.getString("PARTNER_SUBSCRIBER_COUNT") : "");
					bean.setTotalRevenue(( rs.getString("TOTAL_REVENUE") != null) ? rs.getString("TOTAL_REVENUE") : "");
					bean.setNetRevenue(( rs.getString("NET_REVENUE") != null) ? rs.getString("NET_REVENUE") : "");
					bean.setPoolPer((rs.getString("POOL_PER") != null) ? rs.getString("POOL_PER") : "");
					bean.setPoolAmount((rs.getString("Pool_Amount") != null) ? rs.getString("Pool_Amount") : "");
					bean.setTotalStreams((rs.getString("Total_Streams") != null) ? rs.getString("Total_Streams") : "");
					bean.setPartnerStreams((rs.getString("Partner_Streams") != null) ? rs.getString("Partner_Streams") : "");
					bean.setMktSharePer((rs.getString("Mkt_Share_Per") != null) ? rs.getString("Mkt_Share_Per") : "");
					bean.setPartnerPayout((rs.getString("Partner_Payout") != null) ? rs.getString("Partner_Payout") : "");
					bean.setTotalSubscriberCount((rs.getString("TOTAL_SUBSCRIBER_CNT") != null) ? rs.getString("TOTAL_SUBSCRIBER_CNT") : "");
					return bean;
				}});
		}catch(Exception e){
			e.printStackTrace();
		}
		return listContact;
	}
	
	
	
	@Override
	public List<ServiceType> getStmtServiceType() throws Exception {
		String query = "SELECT SRVC_ID, SERVICE_TYPE, SERVICE_DESC FROM DLP_STMT_SERVICE_MASTER WHERE VALIDITY_FLAG='Y'";
		List<ServiceType> reportList = jdbcTemplate.query(query, new RowMapper<ServiceType>() {
			@Override
			public ServiceType mapRow(ResultSet rs, int rowNum) throws SQLException {
				ServiceType stmtGenCycleMaster = new ServiceType();
				stmtGenCycleMaster.setServiceId(rs.getInt("SRVC_ID"));
				stmtGenCycleMaster.setServiceType(rs.getString("SERVICE_TYPE"));
				stmtGenCycleMaster.setServiceDesc(rs.getString("SERVICE_DESC"));
				return stmtGenCycleMaster;
			}
		});
		return reportList;
	}

}

package dsm.dao.admin;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;  
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import dsm.dataBase.query.AdminQueries;
//import dsm.dataBase.query.MasterQueries;
import dsm.model.DB.AttrMappingFiledSet;
import dsm.model.DB.CheckBaselineVO;
import dsm.model.DB.EntAttrMapping;
import dsm.model.DB.HierarchyMismatchVO;
import dsm.model.DB.HierarchySuspense;
import dsm.model.DB.StmtReqMapping;
import dsm.model.DB.UniverseMaster;
import dsm.model.form.CircleMaster;
import dsm.model.form.CircleSchedular;

public class AdminDAOImpl implements AdminDAO{

	
	private NamedParameterJdbcTemplate namedParamJdbcTemplate;
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplate;
	private static Logger logger = Logger.getLogger (AdminDAOImpl.class);
	
	public AdminDAOImpl(){
		
	}
	
	public AdminDAOImpl(DataSource dataSource){
		namedParamJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
		jdbcTemplate = new JdbcTemplate(dataSource);
		this.dataSource=dataSource;
	}
	
	@Override
	public List<HierarchySuspense> getHierarchySuspense(String startDt, String endDt, String circleCode) throws Exception{
		List<UniverseMaster> universeList = namedParamJdbcTemplate.query(AdminQueries.UNIVERSE, new RowMapper<UniverseMaster>(){
			@Override
			public UniverseMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				UniverseMaster universeMaster = new UniverseMaster();
				universeMaster.setUniverseId(rs.getInt("UNIVERSE_ID"));
				universeMaster.setUniverseName(rs.getString("UNIVERSE_NAME"));
				universeMaster.setUniverseTablePrefix(rs.getString("UNIVERSE_TBL_PREFIX"));
				universeMaster.setValidityFlag(rs.getString("VALIDITY_FLAG"));
				return universeMaster;
			}
		});
		List<HierarchySuspense> hsList = new ArrayList<HierarchySuspense>();
		if(universeList != null && universeList.size() != 0){
			for(UniverseMaster um : universeList){
				hsList.add(getHierarchySuspenseData(startDt,endDt,um.getUniverseTablePrefix().concat("_").concat(circleCode),um.getUniverseName(),um.getUniverseId()));
			}
		}
		return hsList;
	}
	
	private HierarchySuspense getHierarchySuspenseData(String startDt, String endDt, String tableName, final String scm, final int unid) throws Exception {
		SqlParameterSource parameters = new MapSqlParameterSource().addValue("startDate", startDt).addValue("endDate", endDt);
		String query = AdminQueries.HIERARCHY_SUSPENSE;
		query = query.replace(":tableName", tableName);
		final boolean flag = tableName.contains("DLP_TBL_UNI_DISTRIBUTOR");
		HierarchySuspense hierarchySuspense = (HierarchySuspense) namedParamJdbcTemplate.queryForObject(query, parameters, new RowMapper<HierarchySuspense>() {
			@Override
			public HierarchySuspense mapRow(ResultSet rs, int rowNum) throws SQLException {
				HierarchySuspense hs = new HierarchySuspense();
				hs.setUnid(unid);
				hs.setScm(scm);
				if(flag){
					hs.setRetailer(0);
					hs.setDse(0);
				}
				else{
					hs.setRetailer(rs.getInt("RET"));
					hs.setDse(rs.getInt("DSE"));
				}
				hs.setDist(rs.getInt("DIST"));
				hs.setInternalSales(rs.getInt("INTERNAL_SALES"));
				return hs;
			}
		});
		return hierarchySuspense;
	}
	
	
	@Override
	public String getExecuteHierarchyStamp(String startDt, String endDt, String qualify, String circle, int circleId, int unid){
		try{
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(dataSource).withProcedureName(AdminQueries.DL_PROC_RESTAMP_HIER_UNI);
			@SuppressWarnings("deprecation")
			SqlParameterSource parameters = new MapSqlParameterSource().addValue("pTYPE",qualify).addValue("pCIRCLE",circle)
			.addValue("pCIRCLEID",circleId).addValue("pUNIVID",unid).addValue("pFROM_DATE",new Date(startDt)).addValue("pTO_DATE",new Date(endDt));
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(parameters);
			return simpleJdbcCallResult.toString();
		}catch(Exception e){
			logger.error("AdminDAOImpl getExecuteHierarchyStamp Exception ::: ",e);
			e.printStackTrace();
		}
		return "Unsuccess";
	}
	
	
	@Override
	public String updateCircleSchedular(CircleSchedular circleSchedular){
		try {
			int count = jdbcTemplate.update(AdminQueries.UPDATE_DL_CIRCLE_CONFIG, circleSchedular.getDelayTime(),circleSchedular.getTax(),circleSchedular.getStartDay(),circleSchedular.getEndDay(),circleSchedular.getDistMagin(),circleSchedular.getSchemeSchedular(),circleSchedular.getStatementDay(),circleSchedular.getCircleId());
			if(count>0){
				return "Successfully Update Circle Schedular.";
			}
		} catch (Exception e) {
			logger.error("AdminDAOImpl updateCircleSchedular Exception :: ",e);
			e.printStackTrace();
			return "Problem in Database.";
		}
		return "Not update Circle Schedular. ";
	}
	
	@Override
	public CircleSchedular getFrcDenoCircleSchedular(CircleSchedular circleSchedular){
		try {
			CircleSchedular circleSch = jdbcTemplate.query(AdminQueries.GET_FRC_DENO_SET, new Object[]{circleSchedular.getCircleId(), circleSchedular.getDenoMonth()}, new ResultSetExtractor<CircleSchedular>(){
				@Override
				public CircleSchedular extractData(ResultSet rs) throws SQLException {
					CircleSchedular cir = null;
					if(rs.next()){
						cir = new CircleSchedular();
						cir.setNegativeDay(rs.getInt("NEGATIVE_DAYS"));
						cir.setDenoSet(rs.getString("DENO_SET"));
						cir.setExeTillDate(rs.getDate("EXE_TILL_DATE"));
					}
					return cir;
				}
			});
			return circleSch;
		} catch (Exception e) {
			logger.error("AdminDAOImpl getFrcDenoCircleSchedular Exception :: ",e);
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public String updateDenoSetCircleSchedular(CircleSchedular circleSchedular){
		try {
			int count = jdbcTemplate.update(AdminQueries.UPDATE_DENO_SET, circleSchedular.getCircleId(),circleSchedular.getDenoMonth());
			if(count>0){
				return insertDenoSetCircleSchedular(circleSchedular);
			}
		} catch (Exception e) {
			logger.error(" AdminDAOImpl -- updateDenoSetCircleSchedular  Exception ",e);
			e.printStackTrace();
			return "Problem in Database.";
		}
		return "Not update Deno Set. ";
	}
	
	private String insertDenoSetCircleSchedular(CircleSchedular circleSchedular){
		try {
			int count = jdbcTemplate.update(AdminQueries.INSERT_DENO_SET, circleSchedular.getCircleId(),circleSchedular.getDenoMonth(),circleSchedular.getDenoSet(),circleSchedular.getStartDtStr(),circleSchedular.getNegativeDay(),circleSchedular.getEndDtStr(),circleSchedular.getExeTillDate());
			if(count>0){
				return "Successfully Inserted Deno Set.";
			}
		} catch (Exception e) {
			logger.error(" AdminDAOImpl -- insertDenoSetCircleSchedular  Exception ",e);
			e.printStackTrace();
			return "Problem in Database.";
		}
		return "Not inserted Deno Set. ";
	}
	
	@Override
	public List<HierarchyMismatchVO> getHierarchyMismatch(String circleCode, String startDt, String endDt, String type) throws Exception{
		try{
			List<HierarchyMismatchVO> hierarchyMismatchList = jdbcTemplate.query(AdminQueries.HIERARCHY_MISMATCH, new Object[]{circleCode,type,startDt,endDt}, new RowMapper<HierarchyMismatchVO>(){
				@Override
				public HierarchyMismatchVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					HierarchyMismatchVO mismatch = new HierarchyMismatchVO();
					mismatch.setSystemsInvolved(rs.getString("SYSTEMS_INVOLVED"));
					mismatch.setHierarchyDate(rs.getString("HIERARCHY_DATE"));
					mismatch.setRetMissingFirstSys(rs.getInt("RET_MIS_IN_FIRST_SYSTEM"));
					mismatch.setRetMissingSecondSys(rs.getInt("RET_MIS_IN_SECOND_SYSTEM"));
					mismatch.setDseMissingFirstSys(rs.getInt("DSE_MIS_IN_FIRST_SYSTEM"));
					mismatch.setDseMissingSecondSys(rs.getInt("DSE_MIS_IN_SECOND_SYSTEM"));
					mismatch.setDistMissingFirstSys(rs.getInt("DIST_MIS_IN_FIRST_SYSTEM"));
					mismatch.setDistMissingSecondSys(rs.getInt("DIST_MIS_IN_SECOND_SYSTEM"));
					mismatch.setTsmMissingFirstSys(rs.getInt("TSM_MIS_IN_FIRST_SYSTEM"));
					mismatch.setTsmMissingSecondSys(rs.getInt("TSM_MIS_IN_SECOND_SYSTEM"));
					mismatch.setAsmMissingFirstSys(rs.getInt("ASM_MIS_IN_FIRST_SYSTEM"));
					mismatch.setAsmMissingSecondSys(rs.getInt("ASM_MIS_IN_SECOND_SYSTEM"));
					mismatch.setZbmMissingFirstSys(rs.getInt("ZBM_MIS_IN_FIRST_SYSTEM"));
					mismatch.setZbmMissingSecondSys(rs.getInt("ZBM_MIS_IN_SECOND_SYSTEM"));
					mismatch.setShMissingFirstSys(rs.getInt("SH_MIS_IN_FIRST_SYSTEM"));
					mismatch.setShMissingSecondSys(rs.getInt("SH_MIS_IN_SECOND_SYSTEM"));
					mismatch.setChMissingFirstSys(rs.getInt("CH_MIS_IN_FIRST_SYSTEM"));
					mismatch.setChMissingSecondSys(rs.getInt("CH_MIS_IN_SECOND_SYSTEM"));
					mismatch.setRetMgrMismatch(rs.getInt("RET_MGR_MISMATCH"));
					mismatch.setDseMgrMismatch(rs.getInt("DSE_MGR_MISMATCH"));
					mismatch.setDistMgrMismatch(rs.getInt("DIST_MGR_MISMATCH"));
					mismatch.setTsmMgrMismatch(rs.getInt("TSM_MGR_MISMATCH"));
					mismatch.setAsmMgrMismatch(rs.getInt("ASM_MGR_MISMATCH"));
					mismatch.setZbmMgrMismatch(rs.getInt("ZBM_MGR_MISMATCH"));
					mismatch.setShMgrMismatch(rs.getInt("SH_MGR_MISMATCH"));
					mismatch.setTotalMissing(rs.getInt("TOTAL_MISSING"));
					mismatch.setTotalMismatch(rs.getInt("TOTAL_MISMATCH"));
					return mismatch;
				}
			});
			return hierarchyMismatchList;
		}
		catch(Exception e){
			logger.error("-- AdminDAOImpl getHierarchyMismatch Exception :: ",e);
			e.printStackTrace();
		}
	return null;
	}
	
	
	@Override
	public List<CheckBaselineVO> getScmDataAnalysis(int circleId, String startDt, String endDt, int schemeId, int compId, String type) throws Exception{
		try{
			CircleMaster circle = getCircleMasterList(circleId);
			String query = AdminQueries.SCM_DATA_ANLYSIS;
			if(schemeId==-1 && compId==-1){
				query = AdminQueries.SCM_DATA_ANLYSIS_ALL_SCHEME;
			}else if(schemeId!=-1 && compId==-1){
				query = AdminQueries.SCM_DATA_ANLYSIS_ALL_COMPONENT;
			}
			
			query = query.replace(":tableName", "DLP_PRE_CHECK_BASELINE_"+circle.getCircleCode());

			if(schemeId==-1 && compId==-1){
				List<CheckBaselineVO> checkBaseLineList = jdbcTemplate.query(query, new Object[]{circleId,startDt,endDt,type}, new RowMapper<CheckBaselineVO>(){
					@Override
					public CheckBaselineVO mapRow(ResultSet rs, int rowNum) throws SQLException {
						CheckBaselineVO checkBase = new CheckBaselineVO();
						checkBase.setSchemeId(rs.getInt("SCM_ID"));
						checkBase.setSchemeName(rs.getString("SCHEME_NAME"));
						checkBase.setCompId(rs.getInt("COMP_ID"));
						checkBase.setCompName(rs.getString("COMPONENET_NAME"));
						checkBase.setStartDt(rs.getString("START_DATE"));
						checkBase.setEndDt(rs.getString("END_DATE"));
						checkBase.setParamCat(rs.getString("PARAM_CAT"));
						checkBase.setParamName(rs.getString("PARAM_NAME"));
						checkBase.setRowCount(rs.getInt("ROW_COUNT"));
						checkBase.setValueCount(rs.getInt("VALUE_CNT"));
						checkBase.setMissingValueCount(rs.getInt("MISSING_VALUE_CNT"));
						checkBase.setRemarks(rs.getString("REMARK"));
						checkBase.setFullHierStampCount(rs.getString("FULL_HIER_STAMP_CNT"));
						checkBase.setPartialHierStampCount(rs.getString("PARTIAL_HIER_STAMP_CNT"));
						checkBase.setMissingHierStampCount(rs.getString("MISSING_HIER_STAMP_CNT"));
						return checkBase;
					}
				});
				return checkBaseLineList;
			}else if(schemeId!=-1 && compId==-1){
				List<CheckBaselineVO> checkBaseLineList = jdbcTemplate.query(query, new Object[]{circleId,startDt,endDt,schemeId,type}, new RowMapper<CheckBaselineVO>(){
					@Override
					public CheckBaselineVO mapRow(ResultSet rs, int rowNum) throws SQLException {
						CheckBaselineVO checkBase = new CheckBaselineVO();
						checkBase.setSchemeId(rs.getInt("SCM_ID"));
						checkBase.setSchemeName(rs.getString("SCHEME_NAME"));
						checkBase.setCompId(rs.getInt("COMP_ID"));
						checkBase.setCompName(rs.getString("COMPONENET_NAME"));
						checkBase.setStartDt(rs.getString("START_DATE"));
						checkBase.setEndDt(rs.getString("END_DATE"));
						checkBase.setParamCat(rs.getString("PARAM_CAT"));
						checkBase.setParamName(rs.getString("PARAM_NAME"));
						checkBase.setRowCount(rs.getInt("ROW_COUNT"));
						checkBase.setValueCount(rs.getInt("VALUE_CNT"));
						checkBase.setMissingValueCount(rs.getInt("MISSING_VALUE_CNT"));
						checkBase.setRemarks(rs.getString("REMARK"));
						checkBase.setFullHierStampCount(rs.getString("FULL_HIER_STAMP_CNT"));
						checkBase.setPartialHierStampCount(rs.getString("PARTIAL_HIER_STAMP_CNT"));
						checkBase.setMissingHierStampCount(rs.getString("MISSING_HIER_STAMP_CNT"));
						return checkBase;
					}
				});
				return checkBaseLineList;
			}else{
				List<CheckBaselineVO> checkBaseLineList = jdbcTemplate.query(query, new Object[]{circleId,startDt,endDt,schemeId,compId,type}, new RowMapper<CheckBaselineVO>(){
					@Override
					public CheckBaselineVO mapRow(ResultSet rs, int rowNum) throws SQLException {
						CheckBaselineVO checkBase = new CheckBaselineVO();
						checkBase.setSchemeId(rs.getInt("SCM_ID"));
						checkBase.setSchemeName(rs.getString("SCHEME_NAME"));
						checkBase.setCompId(rs.getInt("COMP_ID"));
						checkBase.setCompName(rs.getString("COMPONENET_NAME"));
						checkBase.setStartDt(rs.getString("START_DATE"));
						checkBase.setEndDt(rs.getString("END_DATE"));
						checkBase.setParamCat(rs.getString("PARAM_CAT"));
						checkBase.setParamName(rs.getString("PARAM_NAME"));
						checkBase.setRowCount(rs.getInt("ROW_COUNT"));
						checkBase.setValueCount(rs.getInt("VALUE_CNT"));
						checkBase.setMissingValueCount(rs.getInt("MISSING_VALUE_CNT"));
						checkBase.setRemarks(rs.getString("REMARK"));
						checkBase.setFullHierStampCount(rs.getString("FULL_HIER_STAMP_CNT"));
						checkBase.setPartialHierStampCount(rs.getString("PARTIAL_HIER_STAMP_CNT"));
						checkBase.setMissingHierStampCount(rs.getString("MISSING_HIER_STAMP_CNT"));
						return checkBase;
					}
				});
				return checkBaseLineList;
			}
		}
		catch(Exception e){
			logger.error("AdminDAOImpl getScmDataAnalysis Exception :: ",e);
			e.printStackTrace();
		}
		return null;
	}
	
	
	private CircleMaster getCircleMasterList(int circleId) throws Exception{
		List<CircleMaster> circleMasterList = jdbcTemplate.query(AdminQueries.CIRCLE_CODE, new Object[]{circleId}, new RowMapper<CircleMaster>() {
			@Override
			public CircleMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CircleMaster circleMaster = new CircleMaster();
				circleMaster.setCircleId(rs.getInt("CIRCLE_NUMBER"));
				circleMaster.setCircleCode(rs.getString("CIRCLE_CODE"));
				circleMaster.setCircleName(rs.getString("CIRCLE_NAME"));
				return circleMaster;
			}
		});
		return circleMasterList.get(0);
	}
	
	
	@Override
	public List<EntAttrMapping> getAttrMapping(int circleId) throws Exception {
		List<EntAttrMapping> entAttrList = jdbcTemplate.query(AdminQueries.GET_ADDITIONAL_ATTRIBUTE,new Object[]{circleId}, new RowMapper<EntAttrMapping>() {
			@Override
			public EntAttrMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
				EntAttrMapping obj = new EntAttrMapping();
				obj.setId(rs.getInt("ATTR_SEQ_NO"));
				obj.setAttrType(rs.getString("aatr_type"));
				if(rs.getString("aatr_catg").equals("Additional"))
					obj.setSrcTblName("DLP_TBL_ENTITY_ADD_ATT_PRESTAG");
				if(rs.getString("aatr_catg").equals("Core"))
					obj.setSrcTblName("DL_ENTITY_HIERARCHY_STAG");
				obj.setSrcTblField(rs.getString("SRC_TBL_FIELD"));
				obj.setDisplayName(rs.getString("DISPLAY_NAME"));
				obj.setCovFlag(rs.getString("COVERAGE_FLAG"));
				obj.setTqFlag(rs.getString("TQ_FLAG"));
				obj.setEntAggFlag(rs.getString("ENTITY_AGG_FLAG"));
				obj.setPayCondFlag(rs.getString("PAY_COND_FLAG"));
				obj.setAttrCatg(rs.getString("aatr_catg"));
				if(rs.getString("FREE_TEXT_TYPE_CHK").equals("N"))
					obj.setFreeTxtType("Number");
				if(rs.getString("FREE_TEXT_TYPE_CHK").equals("S"))
					obj.setFreeTxtType("String");
				if(rs.getString("FREE_TEXT_TYPE_CHK").equals("D"))
					obj.setFreeTxtType("Date");
				return obj;
			}
		});
		return entAttrList;
	}

	@Override
	public List<AttrMappingFiledSet> getAttrMappingFieldSet(int circleId, String attriType) throws Exception {
		List<AttrMappingFiledSet> entAttrList = jdbcTemplate.query(AdminQueries.ADDITIONAL_ATTR_COLUMNS, new Object[]{circleId}, new RowMapper<AttrMappingFiledSet>() {
			@Override
			public AttrMappingFiledSet mapRow(ResultSet rs, int rowNum) throws SQLException {
				AttrMappingFiledSet obj = new AttrMappingFiledSet();
				obj.setFieldId(rs.getInt("column_id"));
				obj.setFieldName(rs.getString("column_name"));
				obj.setFieldType("A");
				return obj;
			}
		});
		return entAttrList;
	}
	
	@Override
	public List<AttrMappingFiledSet> getAttrMappingCoreFieldSet() throws Exception {
		String query = "SELECT column_id,column_name FROM USER_TAB_COLUMNS WHERE TABLE_NAME='DL_ENTITY_HIERARCHY_STAG' AND column_name not in (SELECT src_tbl_field FROM DLP_TBL_ENTITY_ATTR_MAPPING where attr_catg = 7) ORDER BY column_id";
		List<AttrMappingFiledSet> entAttrList = jdbcTemplate.query(query, new RowMapper<AttrMappingFiledSet>() {
			@Override
			public AttrMappingFiledSet mapRow(ResultSet rs, int rowNum) throws SQLException {
				AttrMappingFiledSet obj = new AttrMappingFiledSet();
					obj.setFieldId(rs.getInt("column_id"));
					obj.setFieldName(rs.getString("column_name"));
					obj.setFieldType("C");
				return obj;
			}
		});
		return entAttrList;
	}


	@Override
	public String saveAttrMapping(EntAttrMapping obj) throws Exception {
		try{
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(dataSource).withProcedureName(AdminQueries.DLP_ADD_ATTR_FIELD_CONFIG);
			SqlParameterSource parameters = new MapSqlParameterSource().addValue("pCIRCLE_ID",obj.getCircleId()).addValue("pATTRID",obj.getId())
					.addValue("pATTRCATG",obj.getAttrCatg()).addValue("pATTRTYPE",obj.getAttrType()).addValue("pFIELDNAME",obj.getSrcTblField())
					.addValue("pDISPNAME",obj.getDisplayName()).addValue("pDATATYPE",obj.getFreeTxtType()).addValue("pCOFLAG",obj.getCovFlag())
					.addValue("pTQFLAG",obj.getTqFlag()).addValue("pEAFLAG",obj.getEntAggFlag()).addValue("pPOFLAG",obj.getPayCondFlag());
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(parameters);
			return simpleJdbcCallResult.toString();
		}catch(Exception e){
			logger.error("AdminDAOImpl saveAttrMapping Exception :: ",e);
			e.printStackTrace();
		}
		return "Attribute is Not Added..";
	}

	@Override
	public String updateAttrMapping(EntAttrMapping obj) throws Exception {
		try{
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(dataSource).withProcedureName(AdminQueries.DLP_ADD_ATTR_FIELD_CONFIG);
			SqlParameterSource parameters = new MapSqlParameterSource().addValue("pCIRCLE_ID",obj.getCircleId()).addValue("pATTRID",obj.getId())
					.addValue("pATTRCATG",obj.getAttrCatg()).addValue("pATTRTYPE",obj.getAttrType()).addValue("pFIELDNAME",obj.getSrcTblField())
					.addValue("pDISPNAME",obj.getDisplayName()).addValue("pDATATYPE",obj.getFreeTxtType()).addValue("pCOFLAG",obj.getCovFlag())
					.addValue("pTQFLAG",obj.getTqFlag()).addValue("pEAFLAG",obj.getEntAggFlag()).addValue("pPOFLAG",obj.getPayCondFlag());
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(parameters);
			return simpleJdbcCallResult.toString();
		}catch(Exception e){
			logger.error("AdminDAOImpl updateAttrMapping Exception ::",e);
			e.printStackTrace();
		}
		return "Attribute is Not Updated..";
}

	@Override
	public boolean deleteAttrMapping(EntAttrMapping obj) throws Exception {
		String query = "update DLP_TBL_ENTITY_ATTR_MAPPING SET VALIDITY_FLAG=?,UPDATE_DATE_TIME=?, INSERT_DATE_TIME=? where ATTR_SEQ_NO=?";
		jdbcTemplate.update(query,	obj.getValFlag(),	obj.getUpdateTime(),	obj.getInsertTime(),  obj.getId());	
				return true;
	}

	@Override
	public List<StmtReqMapping> getStmtReq(int circleId, String circleCode, String endDt, String serviceType) throws Exception {
		/*String query = "SELECT SM.SCHEME_ID,SM.SCHEME_NAME, CM.COMPONENT_ID,CM.COMPONENET_NAME, cm.pay_to, em.display_value," +
				"  Cm.Payout_Approval_Dt,cm.PAYOUT_STATUS,cm.PAYMENT_STATUS, CM.PAYMENT_ID,TO_CHAR(cm.START_DATE, 'DD-MON-YYYY') START_DATE," +
				" TO_CHAR(cm.END_DATE, 'DD-MON-YYYY') END_DATE, TO_CHAR(DP.PAYMENT_DATE, 'DD-MON-YYYY') PAYMENT_DATE" +
				" FROM DLP_SCHEME_COMP_MAPPING CM ,  DLP_SCHEME_MASTER SM, dlp_entity_type_master em, DLP_PAYMENT_"+circleCode+" DP" +
				" where TRUNC(CM.END_DATE) <= ? " +
				" AND SM.CIRCLE_ID  = ? AND CM.VALIDITY_FLAG   ='Y' AND CM.SCM_STATUS ='C'" +
				" AND CM.PAYOUT_STATUS  ='A' AND CM.PAYMENT_STATUS   ='P' AND CM.STATEMENT_STATUS   <> 'S'" +
				" AND CM.STATEMENT_CYCLE_ID IS NULL AND CM.VALIDITY_FLAG = SM.VALIDITY_FLAG AND DP.PAYMENT_ID = CM.PAYMENT_ID AND CM.SCHEME_ID = SM.SCHEME_ID " +
				" AND cm.pay_to = em.entity_type_id AND cm.pay_to IN (10,9,8) ";
		*/

		/*String query = "SELECT SM.SCHEME_ID,SM.SCHEME_NAME, CM.COMPONENT_ID,CM.COMPONENET_NAME, cm.pay_to, em.display_value," +
				"  Cm.Payout_Approval_Dt,cm.PAYOUT_STATUS,cm.PAYMENT_STATUS, CM.PAYMENT_ID,TO_CHAR(cm.START_DATE, 'DD-MON-YYYY') START_DATE," +
				" TO_CHAR(cm.END_DATE, 'DD-MON-YYYY') END_DATE " +
				" FROM DLP_SCHEME_COMP_MAPPING CM ,  DLP_SCHEME_MASTER SM, dlp_entity_type_master em" +
				" where TRUNC(CM.END_DATE) <= ? " +
				" AND SM.CIRCLE_ID  = ? AND CM.VALIDITY_FLAG   ='Y' AND CM.SCM_STATUS ='C' " +
				" AND CM.PAYOUT_STATUS  ='A' AND CM.PAYMENT_STATUS   ='U' AND CM.STATEMENT_STATUS   <> 'S'" +
				" AND CM.STATEMENT_CYCLE_ID IS NULL AND CM.VALIDITY_FLAG = SM.VALIDITY_FLAG  AND CM.SCHEME_ID = SM.SCHEME_ID " +
				" AND cm.pay_to = em.entity_type_id AND cm.pay_to IN (6,5) ";
		*/
		
		String query = "SELECT srd.service_type,SM.SCHEME_ID,SM.SCHEME_NAME, CM.COMPONENT_ID,CM.COMPONENET_NAME, cm.pay_to, em.display_value," +
				"  Cm.Payout_Approval_Dt,cm.PAYOUT_STATUS,cm.PAYMENT_STATUS, CM.PAYMENT_ID,TO_CHAR(cm.START_DATE, 'DD-MON-YYYY') START_DATE," +
				"  TO_CHAR(CM.END_DATE, 'DD-MON-YYYY') END_DATE" +
				"  FROM DLP_SCHEME_COMP_MAPPING CM ,  DLP_SCHEME_MASTER SM, DLP_ENTITY_TYPE_MASTER EM" +
				"  ,(select distinct service_type ,cm.scheme_id,CM.COMPONENT_ID" +
				"  from dlp_scm_report_data srd ,DLP_SCHEME_COMP_MAPPING CM" +
				"  where CM.SCHEME_ID = Srd.SCm_ID and cm.component_id=srd.comp_id and srd.validity_flag='Y'" +
				"  group by service_type ,cm.scheme_id,CM.COMPONENT_ID  ) srd" +
				"  WHERE  TRUNC(CM.END_DATE) <= ? " +
				"  and srd.scheme_id=cm.scheme_id and srd.component_id=cm.component_id" +
				"  AND SM.CIRCLE_ID  = ? AND CM.VALIDITY_FLAG   ='Y' AND CM.SCM_STATUS ='C'" +
				"  AND CM.PAYOUT_STATUS  ='A' AND CM.PAYMENT_STATUS   ='U' AND CM.STATEMENT_STATUS   <> 'S'" +
				"  AND CM.STATEMENT_CYCLE_ID IS NULL AND CM.VALIDITY_FLAG = SM.VALIDITY_FLAG  AND CM.SCHEME_ID = SM.SCHEME_ID" +
				"  AND CM.PAY_TO = EM.ENTITY_TYPE_ID AND CM.PAY_TO IN (6,5)" +
				"  AND SRD.SERVICE_TYPE = ?";
		
		List<StmtReqMapping> entAttrList = jdbcTemplate.query(query, new Object[]{endDt,circleId,serviceType}, new RowMapper<StmtReqMapping>() {
			@Override
			public StmtReqMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
				StmtReqMapping obj = new StmtReqMapping();
				obj.setCompId(rs.getInt("COMPONENT_ID"));
				obj.setScmId(rs.getInt("SCHEME_ID"));
				obj.setCompName(rs.getString("COMPONENET_NAME"));
				obj.setScmName(rs.getString("SCHEME_NAME"));
				obj.setPayTo(rs.getString("display_value"));
				obj.setPayoutApprovalDt(rs.getString("Payout_Approval_Dt"));
				obj.setPayoutStatus(rs.getString("PAYOUT_STATUS"));
				obj.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
				obj.setPaymentId(rs.getInt("PAYMENT_ID"));
				obj.setStartDt(rs.getString("START_DATE"));
				obj.setEndDt(rs.getString("END_DATE"));
				obj.setPaymentDt(null);
				return obj;
			}
		});
		return entAttrList;
	}

	@Override
	public List<StmtReqMapping> removeScmStmtReq(String circleCode,	String endDt, String stmtCycleId) throws Exception {

		String query = "select SCM_ID,COMP_ID,STATEMENT_CYCLE_ID,VALIDITY_FLAG,PAYMENT_DATE,START_DATE,END_DATE,WORK_STATUS from DLP_SCHEME_STATEMENT_MAP_"+circleCode +
				" where TRUNC(END_DATE) <= ? and WORK_STATUS='W' and STATEMENT_CYCLE_ID = ? ";
		List<StmtReqMapping> entAttrList = jdbcTemplate.query(query, new Object[]{endDt,stmtCycleId}, new RowMapper<StmtReqMapping>() {
			@Override
			public StmtReqMapping mapRow(ResultSet rs, int rowNum) throws SQLException {
				StmtReqMapping obj = new StmtReqMapping();
				obj.setCompId(rs.getInt("COMP_ID"));
				obj.setScmId(rs.getInt("SCM_ID"));
				return obj;
			}
		});
		return entAttrList;
	}
}

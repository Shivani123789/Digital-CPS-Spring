package dsm.dao.save;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import dsm.dao.search.SchemeSearchDAOImpl;
import dsm.dataBase.query.SchemeConfigQueries;
import dsm.model.DB.CompMaster;
import dsm.model.DB.RegZoneMaster;
import dsm.model.DB.RoprMaster;
import dsm.model.DB.SchemeAcMaster;
import dsm.model.DB.SchemeEaFilterCondMaster;
import dsm.model.DB.SchemeEaMaster;
import dsm.model.DB.SchemeInputAll;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemePoAmtMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.po.SchemePoMaster;
import dsm.model.user.User;

public class SchemeInputAllDAOImpl implements SchemeInputAllDAO {

	private JdbcTemplate jdbcTemplate;
	private static Logger logger = Logger.getLogger (SchemeInputAllDAOImpl.class);	
	
	@Autowired
	 HttpSession httpSession;
	
	public SchemeInputAllDAOImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }
	
	//save SchemeMaster
	private void saveSchemeMaster(SchemeMaster schemeInput)
	{
		String sql=null;
		try {
		if(schemeInput.getAutoCopyFlag()!=null && !"".equals(schemeInput.getAutoCopyFlag()) && "Y".equals(schemeInput.getAutoCopyFlag())) 
		{
		
			sql="INSERT INTO DLP_SCHEME_MASTER_STAGE(" +
					"SCHEME_ID, "+
					"SCHEME_VER, "+
					"CIRCLE_ID, "+
					"SCHEME_NAME, "+
					"VALIDITY_FLAG, "+
					"USER_ID, "+
					"UPDATE_DATE_TIME, "+
					"INSERT_DATE_TIME,"+
					"AUTO_COPY_FLAG,"+
					"Aggrement_End_Date,"+
					"AUTO_APPROVAL_FLAG"+
					")"+
					"VALUES(SEQ_SCM_NO.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";
		
		jdbcTemplate.update(sql,
							0
				,schemeInput.getCircleId()
				,schemeInput.getSchemeName()
				,schemeInput.getValidityFlag()
				,schemeInput.getUserId()
				,schemeInput.getUpdateTime()
				,schemeInput.getInsertTime()
				,schemeInput.getAutoCopyFlag()
				,schemeInput.getAggrementEndDate()
				,schemeInput.getAutoApprovalFlag());
		}
		
		else
		{
			sql = "INSERT INTO DLP_SCHEME_MASTER_STAGE(" +
					"SCHEME_ID, "+
					"SCHEME_VER, "+
					"CIRCLE_ID, "+
					"SCHEME_NAME, "+
					"VALIDITY_FLAG, "+
					"USER_ID, "+
					"UPDATE_DATE_TIME, "+
					"INSERT_DATE_TIME"+
					")"+
					"VALUES(SEQ_SCM_NO.NEXTVAL,?,?,?,?,?,?,?)";
				jdbcTemplate.update(sql,
						0
			,schemeInput.getCircleId()
			,schemeInput.getSchemeName()
			,schemeInput.getValidityFlag()
			,schemeInput.getUserId()
			,schemeInput.getUpdateTime()
			,schemeInput.getInsertTime()
			);

		}
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveSchemeMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}
		
	private void deleteSchemeMaster(SchemeMaster schemeInput)
	{
		try {
		String sql = "DELETE FROM DLP_SCHEME_MASTER_STAGE where SCHEME_ID=?";
		
		jdbcTemplate.update(sql,schemeInput.getSchemeINputId());
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || deleteSchemeMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		
	}
	
	//save Componenet Mapping
	private void saveCompMaster(SchemeInputAll schemeInput)
	{
		try {
		
		String sql = "INSERT INTO DLP_SCHEME_COMP_MAPPING_STAGE(" +
				"SCHEME_ID, "+
				"COMPONENT_ID, "+
				"COMPONENT_VER, "+
				"COMPONENET_NAME, "+
				"START_DATE, "+
				"END_DATE, "+
				"FREEQUENCY_ID, "+
				"VERTICAL_ID, "+
				"PAY_TO, "+
				"COVERAGE_FLAG, "+
				"FILE_NAME, "+
				"VALIDITY_FLAG, "+
				"USER_ID, "+
				"UPDATE_DATE_TIME, "+
				"INSERT_DATE_TIME,"+
				"SCM_STATUS,"+
				"CATEGORY_ID"+
				")"+
				"VALUES((select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		jdbcTemplate.update(sql
				,schemeInput.getSchemeInputComp().getSchemeName()
				,schemeInput.getSchemeInputComp().getCircleId()
				,schemeInput.getSchemeInputComp().getCompId()
				,schemeInput.getSchemeInputComp().getCompVer()
				,schemeInput.getSchemeInputComp().getCompName()
				,schemeInput.getSchemeInputComp().getStartDate()
				,schemeInput.getSchemeInputComp().getEndDate()
				,schemeInput.getSchemeInputComp().getFreqId()
				,schemeInput.getSchemeInputComp().getVerticalId()
				,schemeInput.getSchemeInputComp().getPayTo()
				,schemeInput.getSchemeInputComp().getCoverageFlag()
				,schemeInput.getSchemeInputComp().getFileName()
				,"Y"
				,schemeInput.getSchemeInputComp().getUserName()
				,schemeInput.getSchemeInputComp().getUpdateTime()
				,schemeInput.getSchemeInputComp().getInsertTime()
				,schemeInput.getSchemeInputComp().getScmStatus()
				,schemeInput.getSchemeInputComp().getCategory()
				);	
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveCompMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}
	
	//Save CoverageConditions
	private void saveAddCoverageMaster(SchemeInputAll schemeInput)
	{
	try {	 
		String sql = "INSERT INTO DLP_SCM_CO_COND_CONFIG_STAGE(" +
				"PROCESS_TYPE, "+
				"SCHEME_ID, "+
				"COMPONENT_ID, "+
				"RE_CONFIG_ID, "+
				"CONDITION_ID, "+
				"CONDITION_ROW_ID, "+
				"ENTITY_TYPE, "+
				"ATTRIBUTE_TYPE, "+
				"FUNCTION, "+
				"ATTRIBUTE_NAME, "+
				"OPR, "+
				"VALUE_TYPE, "+
				"V_FUNCTION, "+
				"VALUE, "+
				"START_DATE, "+
				"END_DATE, "+
				"LOPR, "+
				"L_ENTITY_TYPE, "+
				"L_ATTRIBUTE_TYPE, "+
				"L_FUNCTION, "+
				"L_ATTRIBUTE_NAME, "+
				"L_OPR, "+
				"L_VALUE_TYPE, "+
				"L_V_FUNCTION, "+
				"L_VALUE, "+
				"L_START_DATE, "+
				"L_END_DATE, "+
				"R_OPR, "+
				"VALIDITY_FLAG, "+
				"UPDATE_DATE_TIME, "+
				"INSERT_DATE_TIME"+
				")"+
				"VALUES(?," +
				"(select max(SCHEME_ID) from DLP_SCHEME_MASTER_STAGE where scheme_name=? and circle_id=?)," +
				"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		
		jdbcTemplate.update(sql,schemeInput.getSchemeInputAc().getProcessType(),
				schemeInput.getSchemeInputAc().getSchemeName(),
				schemeInput.getSchemeInputAc().getCircleId(),
				schemeInput.getSchemeInputAc().getCompId()
				,schemeInput.getSchemeInputAc().getReConfigId()
				,schemeInput.getSchemeInputAc().getCondId()
				,schemeInput.getSchemeInputAc().getCondRowId()
				,schemeInput.getSchemeInputAc().getEntityId()
				,schemeInput.getSchemeInputAc().getAttrType()
				,schemeInput.getSchemeInputAc().getFunction()
				,schemeInput.getSchemeInputAc().getAttrName()
				,schemeInput.getSchemeInputAc().getOpr()
				,schemeInput.getSchemeInputAc().getCo_ValueType()
				,schemeInput.getSchemeInputAc().getCo_vFunction()
				,schemeInput.getSchemeInputAc().getValue()
				,schemeInput.getSchemeInputAc().getStartDate()
				,schemeInput.getSchemeInputAc().getEndDate()
				,schemeInput.getSchemeInputAc().getLopr()
				,schemeInput.getSchemeInputAc().getlEntityType()
				,schemeInput.getSchemeInputAc().getlAttrType()
				,schemeInput.getSchemeInputAc().getlFunction()
				,schemeInput.getSchemeInputAc().getlAttName()
				,schemeInput.getSchemeInputAc().getlOpr()
				,schemeInput.getSchemeInputAc().getlValueType()
				,schemeInput.getSchemeInputAc().getlVfunction()
				,schemeInput.getSchemeInputAc().getlValue()
				,schemeInput.getSchemeInputAc().getlStartDate()
				,schemeInput.getSchemeInputAc().getlEndDate()
				,schemeInput.getSchemeInputAc().getrOpr()
				,schemeInput.getSchemeInputAc().getValFlag()
				,schemeInput.getSchemeInputAc().getUpdateDate()
				,schemeInput.getSchemeInputAc().getInsertDate()
				);	
	}catch(NullPointerException e) {
		System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveAddCoverageMaster || Exception  ");
	}
	catch(Exception e){
		
		if(logger.isDebugEnabled()) {
		logger.error("Exception :: ",e);
		e.printStackTrace();
		}
	}
	}
	
	
	//Save Transaction Qualifier Conditions
private void saveTransactionMaster(SchemeInputAll schemeInput)
		{
			try 
			{
			String sql = "INSERT INTO DLP_SCM_TQ_COND_CONFIG_STAGE(" +
					"PROCESS_TYPE, "+
					"SCHEME_ID, "+
					"COMPONENT_ID, "+
					"RE_CONFIG_ID, "+
					"GROUP_ID, "+
					"CONDITION_ID, "+
					"CONDITION_NAME, "+
					"CONDITION_ROW_ID, "+
					"DATA_SET, "+
					"PERF_PARAMETER, "+
					"OPR, "+
					"VALUE_TYPE, "+
					"VALUE, "+
					"START_DATE, "+
					"END_DATE, "+
					"LOPR, "+
					"L_PERF_PARAMETER, "+
					"L_OPR, "+
					"L_VALUE_TYPE, "+
					"L_VALUE, "+
					"L_START_DATE, "+
					"L_END_DATE, "+
					"ROPR, "+
					"VALIDITY_FLAG, "+
					"UPDATE_DATE_TIME, "+
					"INSERT_DATE_TIME"+
					")"+
					"VALUES(?," +
					"(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?)," +
					"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			jdbcTemplate.update(sql,schemeInput.getSchemeInputTq().getProcessType(),
					schemeInput.getSchemeInputTq().getSchemeName(),
					schemeInput.getSchemeInputTq().getCircleId(),
					schemeInput.getSchemeInputTq().getCompId()
					,schemeInput.getSchemeInputTq().getReConfigId()
					,schemeInput.getSchemeInputTq().getGroupId()
					,schemeInput.getSchemeInputTq().getCondId()
					,schemeInput.getSchemeInputTq().getCondName()
					,schemeInput.getSchemeInputTq().getCondRowId()
					,schemeInput.getSchemeInputTq().getDataSet()
					,schemeInput.getSchemeInputTq().getPerfParmeter()
					,schemeInput.getSchemeInputTq().getOpr()
					,schemeInput.getSchemeInputTq().getValueType()
					,schemeInput.getSchemeInputTq().getValue()
					,schemeInput.getSchemeInputTq().getStartDate()
					,schemeInput.getSchemeInputTq().getEndDate()
					,schemeInput.getSchemeInputTq().getLopr()
					,schemeInput.getSchemeInputTq().getlPrefparameter()
					,schemeInput.getSchemeInputTq().getlOpr()
					,schemeInput.getSchemeInputTq().getlValueType()
					,schemeInput.getSchemeInputTq().getlValue()
					,schemeInput.getSchemeInputTq().getlStartDate()
					,schemeInput.getSchemeInputTq().getlEndDate()
					,schemeInput.getSchemeInputTq().getlRopr()
					,schemeInput.getSchemeInputTq().getValFlag()
					,schemeInput.getSchemeInputTq().getUpdateDate()
					,schemeInput.getSchemeInputTq().getInsertDate()
					);
			
			}catch(NullPointerException e) {
				System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveTransactionMaster || Exception  ");
			}
			catch(Exception e){
				
				if(logger.isDebugEnabled()) {
				logger.error("Exception :: ",e);
				e.printStackTrace();
				}
			}
			
		}
		
		//Save Entity Aggregations Conditions
private void saveEntityMaster(SchemeInputAll schemeInput) throws SQLException
	{
	//System.out.println("schemeInput.getSchemeInputEa().getEntityType() :::::: "+schemeInput.getSchemeInputEa().getEntityType());
	try{
						String sql = "INSERT INTO DLP_SCM_EA_COND_CONFIG_STAGE(" +
								"PROCESS_TYPE, "+
								"SCHEME_ID, "+
								"COMPONENT_ID, "+
								"RE_CONFIG_ID, "+
								"VARIABLE_ID, "+
								"VARIABLE_NAME, "+
								"DATA_SET, "+
								"ENTITY_TYPE, "+
								"DATA_SOURCE, "+
								"FUNCTION, "+
								"PARAMETER, "+
								"OPR, "+
								"VALUE_TYPE, "+
								"VALUE, "+
								"START_DATE, "+
								"END_DATE, "+
								"FILTER, "+
								"VALIDITY_FLAG, "+
								"UPDATE_DATE_TIME, "+
								"INSERT_DATE_TIME, "+
								"COL_NAME, "+
								"COND_ID, "+
								"VAR_ROW_ID,"+
								"DAY_AGGREGATION"+
								")"+
								"VALUES(?," +
								"(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?)" +
								",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					
					jdbcTemplate.update(sql,
							schemeInput.getSchemeInputEa().getProcessType(),
							schemeInput.getSchemeInputEa().getSchemeName(),
							schemeInput.getSchemeInputEa().getCircleId(),
							schemeInput.getSchemeInputEa().getCompId()
							,schemeInput.getSchemeInputEa().getReConfigId()
							,schemeInput.getSchemeInputEa().getVariableId()
							,schemeInput.getSchemeInputEa().getVariableName()
							,schemeInput.getSchemeInputEa().getDataSet()
							,schemeInput.getSchemeInputEa().getEntityType()
							,schemeInput.getSchemeInputEa().getDataSourceName()
							,schemeInput.getSchemeInputEa().getFunction()
							,schemeInput.getSchemeInputEa().getParameter()
							,schemeInput.getSchemeInputEa().getOpr()
							,schemeInput.getSchemeInputEa().getValueType()
							,schemeInput.getSchemeInputEa().getValue()
							,schemeInput.getSchemeInputEa().getStartDate()
							,schemeInput.getSchemeInputEa().getEndDate()
							,schemeInput.getSchemeInputEa().getFilter()
							,schemeInput.getSchemeInputEa().getValFlag()
							,schemeInput.getSchemeInputEa().getUpdateDate()
							,schemeInput.getSchemeInputEa().getInsertDate()
							,schemeInput.getSchemeInputEa().getColName()
							,schemeInput.getSchemeInputEa().getCondId()
							,schemeInput.getSchemeInputEa().getVarRowId()
							,schemeInput.getSchemeInputEa().getDaylvlAggrId()
						);
	}catch(NullPointerException e) {
		System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveTransactionMaster || Exception  ");
	}
	catch(Exception e){
		
		if(logger.isDebugEnabled()) {
		logger.error("Exception :: ",e);
		e.printStackTrace();
		}
	}
}	
		


	

//save payout Conditions
private void savePayoutCondMaster(SchemeInputAll schemeInput)
{
	try {
					String sql = "INSERT INTO DLP_SCM_PO_COND_CONFIG_STAGE(" +
							" PROCESS_TYPE, "+
							"SCHEME_ID, "+
							"COMPONENT_ID, "+
							"RE_CONFIG_ID, "+
							"CONDITION_ID, "+
							"CONDITION_ROW_ID, "+
							"INPUT_TYPE, "+
							"INPUT_PARAMETER, "+
							"OPR, "+
							"VALUE_TYPE, "+
							"VALUE, "+
							"START_DATE, "+
							"END_DATE, "+
							"LOPR, "+
							"VALIDITY_FLAG, "+
							"UPDATE_DATE_TIME, "+
							"INSERT_DATE_TIME"+
							")"+
							"VALUES(?," +
							"(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?)," +
							"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					
					jdbcTemplate.update(sql,schemeInput.getSchemeInputPo().getProcessType(),
							schemeInput.getSchemeInputPo().getSchemeName(),
							schemeInput.getSchemeInputPo().getCircleId(),
							schemeInput.getSchemeInputPo().getCompId()
							,schemeInput.getSchemeInputPo().getReConfigId()
							,schemeInput.getSchemeInputPo().getCondId()
							,schemeInput.getSchemeInputPo().getCondRowId()
							,schemeInput.getSchemeInputPo().getInputType()
							,schemeInput.getSchemeInputPo().getInputParameter()
							,schemeInput.getSchemeInputPo().getOpr()
							,schemeInput.getSchemeInputPo().getValueType()
							,schemeInput.getSchemeInputPo().getValue()
							,schemeInput.getSchemeInputPo().getStartDate()
							,schemeInput.getSchemeInputPo().getEndDate()
							,schemeInput.getSchemeInputPo().getLopr()
							,schemeInput.getSchemeInputPo().getValFlag()
							,schemeInput.getSchemeInputPo().getUpdateDate()
							,schemeInput.getSchemeInputPo().getInsertDate()
							);	
	}catch(NullPointerException e) {
		System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || savePayoutCondMaster || Exception  ");
	}
	catch(Exception e){
		
		if(logger.isDebugEnabled()) {
		logger.error("Exception :: ",e);
		e.printStackTrace();
		}
	}

}

@Override
 public void savePayoutCondMasterRight(SchemeInputAll schemeInput)
{
	try {
					String sql = "INSERT INTO DLP_SCM_PO_COND_CONFIG_STAGE(" +
							" PROCESS_TYPE, "+
							"SCHEME_ID, "+
							"COMPONENT_ID, "+
							"RE_CONFIG_ID, "+
							"CONDITION_ID, "+
							"CONDITION_ROW_ID, "+
							"INPUT_TYPE, "+
							"INPUT_PARAMETER, "+
							"OPR, "+
							"VALUE_TYPE, "+
							"VALUE, "+
							"START_DATE, "+
							"END_DATE, "+
							"LOPR, "+
							"VALIDITY_FLAG, "+
							"UPDATE_DATE_TIME, "+
							"INSERT_DATE_TIME"+
							")"+
							"VALUES(?," +
							"(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?)," +
							"?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
					
					jdbcTemplate.update(sql,schemeInput.getSchemeInputPo().getProcessType(),
							schemeInput.getSchemeInputPo().getSchemeName(),
							schemeInput.getSchemeInputPo().getCircleId(),
							schemeInput.getSchemeInputPo().getCompId()
							,schemeInput.getSchemeInputPo().getReConfigId()
							,schemeInput.getSchemeInputPo().getCondId()
							,schemeInput.getSchemeInputPo().getCondRowId()
							,schemeInput.getSchemeInputPo().getRinputType()
							,schemeInput.getSchemeInputPo().getRinputParameter()
							,schemeInput.getSchemeInputPo().getRopr()
							,schemeInput.getSchemeInputPo().getRvalueType()
							,schemeInput.getSchemeInputPo().getRvalue()
							,schemeInput.getSchemeInputPo().getRstartDate()
							,schemeInput.getSchemeInputPo().getRendDate()
							,schemeInput.getSchemeInputPo().getRlopr()
							,schemeInput.getSchemeInputPo().getValFlag()
							,schemeInput.getSchemeInputPo().getUpdateDate()
							,schemeInput.getSchemeInputPo().getInsertDate()
							);	
	}catch(NullPointerException e) {
		System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || savePayoutCondMasterRight || Exception  ");
	}
	catch(Exception e){
		
		if(logger.isDebugEnabled()) {
		logger.error("Exception :: ",e);
		e.printStackTrace();
		}
	}

}




//save payout Condition AMt

	private void saveRegZoneMaster(SchemeInputAll schemeInput) throws Exception
	{
		try {
		String sql = "INSERT INTO DLP_COV_REG_ZONE_MAPPING_STG(" +
				"COV_REG_ZONE_ID, "+
				"COV_REG_ZONE_SERIAL_ID, "+
				"SCHEME_ID, "+
				"COMPONENET_ID, "+
				"CIRCLE_ID, "+
				"REGION_ID, "+
				"ZONE_ID, "+
				"VALIDITY_FLAG, "+
				"USER_ID, "+
				"UPDATE_DATE_TIME, "+
				"INSERT_DATE_TIME"+
				")"+
				"VALUES(SEQ_SCM_REG_ZONE.NEXTVAL,?," +
				"(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?)," +
				"?,?,?,?,?,?,?,?)";
		
		jdbcTemplate.update(sql,
				schemeInput.getSchemeInputRegZone().getCovRegZoneSerialId()
				,schemeInput.getSchemeInputRegZone().getSchemeName()
				,schemeInput.getSchemeInputRegZone().getCircleId()
				,schemeInput.getSchemeInputRegZone().getCompId()
				,schemeInput.getSchemeInputRegZone().getCircleId()
				,schemeInput.getSchemeInputRegZone().getRegionId()
				,schemeInput.getSchemeInputRegZone().getZoneId()
				,schemeInput.getSchemeInputRegZone().getValFlag()
				,schemeInput.getSchemeInputRegZone().getUserId()
				,schemeInput.getSchemeInputRegZone().getUpdateTime()
				,schemeInput.getSchemeInputRegZone().getInsertTime()
				);	
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || savePayoutCondMasterRight || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}
	@Override
	public void SaveOrUpdate(SchemeInputAll schemeInput) {
		// TODO Auto-generated method stub
		
		//saveSchemeMaster(schemeInput);
	}
	
	@Override
	public void saveScheme(SchemeMaster schemeInput) {
		saveSchemeMaster(schemeInput);
		updateCurWorkingScheme(schemeInput);
	}


	private void updateCurWorkingScheme(SchemeMaster schemeInput)
	{
		try {
		String query = "update  dsm2_users set last_working_scheme = ? where username = ?";
		User user = (User)httpSession.getAttribute("appUser");
		jdbcTemplate.update(query,schemeInput.getSchemeName(),user.getUserName().toLowerCase());
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updateCurWorkingScheme || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}
	


	@Override
	public String saveComponenent(CompMaster compInput) throws Exception{
		// TODO Auto-generated method stub
		SchemeInputAll schemeInput = new SchemeInputAll();
		schemeInput.setSchemeInputComp(compInput);
		try {
		List<String> duplicate = validateComponentDulicate(compInput.getSchemeId(), compInput.getCompName());
		if(duplicate != null && duplicate.size()>0){
			return "Component name already exist.";
		}
		saveCompMaster(schemeInput);
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveComponenent || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return null;
	}


	private List<String> validateComponentDulicate(int schemeId, String compName){
		try{
			List<String> dulicate = jdbcTemplate.query(SchemeConfigQueries.COMPONENT_DUPLICATE, new Object[]{schemeId, compName, schemeId, compName}, new RowMapper<String>(){
				@Override
				public String mapRow(ResultSet result, int arg1) throws SQLException {
					String val = result.getString("COMPONENET_NAME");
					return val;
				}
			});
			return dulicate;
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || validateComponentDulicate || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return null;
	}

	
	
	@Override
	public void saveRegion(RegZoneMaster regInput) throws Exception {
		// TODO Auto-generated method stub
		SchemeInputAll schemeInput = new SchemeInputAll();
		schemeInput.setSchemeInputRegZone(regInput);
		//schemeInput.setSchemeInputComp(compInput);
		saveRegZoneMaster(schemeInput);
	}




	@Override
	public void saveAddCov(SchemeAcMaster addCov) {
		// TODO Auto-generated method stub
		SchemeInputAll schemeInput = new SchemeInputAll();
		schemeInput.setSchemeInputAc(addCov);
		saveAddCoverageMaster(schemeInput);
	}




	@Override
	public void saveTq(SchemeTqMaster tq) {
		// TODO Auto-generated method stub
		SchemeInputAll schemeInput = new SchemeInputAll();
		schemeInput.setSchemeInputTq(tq);
		
		saveTransactionMaster(schemeInput);
	}


	@Override
	public List<SchemeTqMaster> getTq(String schemeName) {
		// TODO Auto-generated method stub
		List<SchemeTqMaster> covList = new ArrayList<SchemeTqMaster>();
		try {
		String query="select tq.scheme_id," +
				"tq.component_id," +
				"tq.condition_id,tq.condition_row_id,tq.data_set dataSetId," +
				"tq.condition_name," +
				"tq.value," +
				"tq.start_date," +
				"tq.end_date," +
				"tq.l_start_date," +
				"tq.l_end_date," +
				"tq.l_value," +
				"input.display_value data_set," +
				"param.uni_field_display_value param," +
				"lparam.uni_field_display_value l_param," +
				"opr.display_value opr," +
				"l_lopr.display_value l_lopr," +
				"lopr.display_value lopr," +
				"ropr.display_value ropr," +
				"vt.display_value value_type," +
				"lvt.display_value l_value_type " +
				"from DLP_SCM_TQ_COND_CONFIG_STAGE tq " +
				"left outer join dlp_tbl_input_type_master input " +
				"on tq.data_set =input.input_type_id  " +
				"left outer join dlp_tbl_universe_field_map param " +
				"on tq.perf_parameter =param.uni_fld_seq_no " +
				"left outer join dlp_operator_master opr " +
				"on tq.opr =opr.operator_id  " +
				"left outer join dlp_tbl_value_type_master vt " +
				"on tq.value_type =vt.value_type_id " +
				"left outer join dlp_operator_master lopr " +
				"on tq.lopr =lopr.operator_id " +
				"left outer join dlp_tbl_universe_field_map " +
				"lparam on tq.l_perf_parameter =lparam.uni_fld_seq_no  " +
				"left outer join dlp_operator_master l_lopr " +
				"on tq.l_opr =l_lopr.operator_id " +
				"left outer join dlp_operator_master ropr " +
				"on tq.ropr =ropr.operator_id " +
				"left outer join dlp_tbl_value_type_master lvt " +
				"on tq.l_value_type =lvt.value_type_id " +
				"where scheme_id in(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ? and circle_id = ?) order by tq.insert_date_time asc";

		//System.out.println("TQ QUERY:  "+query);

		 covList = jdbcTemplate.query(query, new Object[]{schemeName, Integer.valueOf(httpSession.getAttribute("circleId").toString())}, new RowMapper<SchemeTqMaster>() {

			@Override
			public SchemeTqMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeTqMaster covMaster = new SchemeTqMaster();
				covMaster.setCondRowId(rs.getInt("condition_row_id"));
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setDataSet(rs.getInt("dataSetId"));
				//covMaster.setCompName(rs.getString("componenet_name"));
				covMaster.setCondId(rs.getInt("condition_id"));
				covMaster.setCondName(rs.getString("condition_name"));
				covMaster.setDataSetName(rs.getString("data_set"));
				covMaster.setPerfParamName(rs.getString("param"));
				covMaster.setOprName(rs.getString("opr"));
				covMaster.setValueTypeName(rs.getString("value_type"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setStartDate(rs.getDate("start_date"));
				covMaster.setEndDate(rs.getDate("end_date"));
				covMaster.setLoprName(rs.getString("lopr"));
				covMaster.setLperfParamName(rs.getString("l_param"));
				covMaster.setL_loprName(rs.getString("l_lopr"));
				covMaster.setLvalueTypeName(rs.getString("l_value_type"));
				covMaster.setlValue(rs.getString("l_value"));
				covMaster.setlStartDate(rs.getDate("l_start_date"));
				covMaster.setlEndDate(rs.getDate("l_end_date"));
				covMaster.setRoprName(rs.getString("ropr"));
				
				
				return covMaster;
			}
			
		});
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || getTq || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return covList;
	}




	@Override
	public void saveEa(SchemeEaMaster ea) throws SQLException {
		// TODO Auto-generated method stub
		SchemeInputAll schemeInput = new SchemeInputAll();
		schemeInput.setSchemeInputEa(ea);
		saveEntityMaster(schemeInput);
	}




	@Override
	public void savePo(SchemePoMaster po) throws SQLException {
		// TODO Auto-generated method stub
		SchemeInputAll schemeInput = new SchemeInputAll();
		po.setGrossNet("NULL");

		schemeInput.setSchemeInputPo(po);

		savePayoutCondMaster(schemeInput);

		if((po.getLopr()!=1) && (po.getLopr()!=2))
		{

			int row = getPoAmtCount(po.getCompId(), po.getCondId());
			if(row==0)
				savePayoutCondAmtMaster(schemeInput);
		}	
		/*if(po.getLopr()==26)
			updateSchemeFlag(po.getSchemeName(),po.getCircleId(),po.getCompId());*/
	}




	@Override
	public void deleteScheme(SchemeMaster schemeInput) {
		// TODO Auto-generated method stub
		
		deleteSchemeMaster(schemeInput);
	}




	@Override
	public int getCompCount(String schemeName, int circleId) {
		String query=	"select max(COMPONENT_ID) from DLP_SCHEME_COMP_MAPPING_STAGE where " +
						"SCHEME_ID = (select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ?  AND CIRCLE_ID=?)";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeName,circleId});
		return row;
	}
	
	
	@Override
	public int getPoFiltersCount(String schemeName,int compId) {
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				String query=	"select max(condition_id) from DLP_SCM_PO_COND_CONFIG_STAGE where " +
								"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? AND circle_id = ?)  and LOPR IN(26,23) and component_id = ?";
				@SuppressWarnings("deprecation")
				 int row = jdbcTemplate.queryForInt(query,new Object[]{schemeName, circleId, compId});
				return row;
	}
	
	
	@Override
	public int getPoAmtCount(int compId,int condId) {
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
				String query="select max(condition_id) from dlp_scm_po_amt_config_stage where scheme_id = ? AND component_id = ? AND condition_id = ?";
				@SuppressWarnings("deprecation")
				 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeId, compId, condId});
				return row;
	}

	
	@Override
	public int getPoCondCount(String schemeName,int compId) {
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				String query="select max(condition_id) from DLP_SCM_PO_COND_CONFIG_STAGE where " +
						"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? AND circle_id = ? )  and LOPR IN(26,23) and COMPONENT_ID = ?";
				@SuppressWarnings("deprecation")
				 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeName, circleId, compId});
				return row;
	}


	
/*	private int getPoCondCountForDelete(String schemeName,int compId) {
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());

		// TODO Auto-generated method stub
				String query="select max(condition_id) from DLP_SCM_PO_COND_CONFIG_STAGE where " +
						"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME="+"'"+schemeName+"' AND circle_id="+circleId+")   and COMPONENT_ID="+compId;
				@SuppressWarnings("deprecation")
				 int row = jdbcTemplate.queryForInt(query);
				
				return row;
	}
*/
	
	
	
	@Override
	public int getPoFiltersRowCount(String schemeName,int condId,int compId) {
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				String query="select max(condition_row_id) from DLP_SCM_PO_COND_CONFIG_STAGE where " +
						"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? AND circle_id = ? ) and condition_id = ? AND COMPONENT_ID = ?";
				@SuppressWarnings("deprecation")
				 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeName, circleId, condId, compId});
				return row;
	}



	@Override
	public List<RegZoneMaster> getRegZone(String schemeName) {
		// TODO Auto-generated method stub
		List<RegZoneMaster> regList = new ArrayList<RegZoneMaster>();
		try {
		String query="select  map.cov_reg_zone_id,scm.component_id, scm.componenet_name, rm.region_description,zm.zone_description " +
				"from DLP_COV_REG_ZONE_MAPPING_STG map," +
				"DLP_SCHEME_MASTER_STAGE sm," +
				"dlp_zone_master zm," +
				"dlp_region_master rm," +
				"DLP_SCHEME_COMP_MAPPING_STAGE scm " +
				"where sm.scheme_id = map.scheme_id " +
				"and map.zone_id = zm.zone_id " +
				"and zm.region_id = rm.region_id " +
				"and scm.scheme_id = map.scheme_id " +
				"and map.componenet_id = scm.component_id " +
				"and map.scheme_id in (select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ? )";

		 	regList = jdbcTemplate.query(query, new Object[]{schemeName}, new RowMapper<RegZoneMaster>() {

			@Override
			public RegZoneMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				RegZoneMaster regMaster = new RegZoneMaster();
				regMaster.setCovRegZoneId(rs.getInt("cov_reg_zone_id"));
				regMaster.setCompId(rs.getInt("component_id"));
				regMaster.setCompName(rs.getString("componenet_name"));
				//regMaster.setRegionId(rs.getInt("region_id"));
				regMaster.setRegionDesc(rs.getString("region_description"));
				regMaster.setZoneDesc(rs.getString("zone_description"));
				
				return regMaster;
			}
			
		});
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || getRegZone || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return regList;
	}

	@Override
	public void deleteRegZone(int regZoneId) {
		// TODO Auto-generated method stub
		String sql = "DELETE FROM DLP_COV_REG_ZONE_MAPPING_STG where cov_reg_zone_id=?";
		
		jdbcTemplate.update(sql,regZoneId);	

	}

	@Override
	public void updateRegZone(RegZoneMaster rzMaster) {
		// TODO Auto-generated method stub
		String sql = "update DLP_COV_REG_ZONE_MAPPING_STG set componenet_id=?,region_id=?,zone_id=?,validity_flag=?,update_date_time=? where cov_reg_zone_id=?";
		
/*//System.out.println(sql+" "+rzMaster.getCompId()+" "
				+rzMaster.getRegionId()+" "
				+rzMaster.getZoneId()+" "
				+rzMaster.getValFlag()+" "
				+rzMaster.getUpdateTime()+" "
				+rzMaster.getCovRegZoneId());	*/	

		jdbcTemplate.update(sql,rzMaster.getCompId()
				,rzMaster.getRegionId(),
				rzMaster.getZoneId()
				,rzMaster.getValFlag()
				,rzMaster.getUpdateTime()
				,rzMaster.getCovRegZoneId());
	}


	@Override
	public void saveEaFilter(SchemeEaFilterCondMaster ea) {
		// TODO Auto-generated method stub
		SchemeInputAll schemeInput = new SchemeInputAll();
		schemeInput.setSchemeInputEaFilter(ea);
		saveEaFilterCondMaster(schemeInput);
	}




	




	@Override
	public List<SchemeAcMaster> getCoverage(String schemeName) throws SQLException {
		// TODO Auto-generated method stub
		List<SchemeAcMaster> covList = new ArrayList<SchemeAcMaster>();
		try {
		String query="select ent.display_value as entity_type" +
				",con.component_id as comp_id," +
				"con.value,con.start_date," +
				"con.end_date,con.condition_id as condition_id,con.condition_row_id," +
				"a.display_value as attribute_type," +
				"f.display_value as function," +
				"entattr.display_name as attribute_name," +
				"opr.display_value as opr," +
				"vt.display_value as value_type," +
				"vf.display_value as v_function," +
				"lopr.display_value as lopr," +
				"lent.display_value as l_entity_type," +
				"lat.display_value as l_attribute_type," +
				"lf.display_value as l_function," +
				"lentattr.display_name as l_attribute_name," +
				"l_lopr.display_value as l_opr," +
				"lvt.display_value as l_value_type," +
				"lvf.display_value as l_v_function," +
				"con.l_value," +
				"con.l_start_date as l_start_date," +
				"con.l_end_date as l_end_date," +
				"rop.display_value as r_opr " +
				"from DLP_SCM_CO_COND_CONFIG_STAGE con " +
				"left outer join dlp_entity_type_master ent " +
				"on con.entity_type =ent.entity_type_id " +
				"left outer join dlp_tbl_input_type_master a " +
				"on con.attribute_type =a.input_type_id " +
				"left outer join dlp_tbl_function_master f " +
				"on con.function =f.function_id " +
				"left outer join dlp_operator_master lopr " +
				"on con.lopr =lopr.operator_id " +
				"left outer join dlp_operator_master opr " +
				"on con.opr =opr.operator_id " +
				"left outer join dlp_tbl_entity_attr_mapping entattr " +
				"on con.attribute_name =entattr.attr_seq_no " +
				"left outer join dlp_tbl_function_master vf " +
				"on con.v_function =vf.function_id " +
				"left outer join dlp_tbl_value_type_master vt " +
				"on con.value_type =vt.value_type_id " +
				"left outer join dlp_entity_type_master lent " +
				"on con.l_entity_type =lent.entity_type_id " +
				"left outer join dlp_tbl_input_type_master lat " +
				"on con.l_attribute_type =lat.input_type_id " +
				"left outer join dlp_tbl_entity_attr_mapping lentattr " +
				"on con.l_attribute_name =lentattr.attr_seq_no " +
				"left outer join dlp_operator_master l_lopr " +
				"on con.l_opr =l_lopr.operator_id " +
				"left outer join dlp_tbl_function_master lf " +
				"on con.l_function =lf.function_id " +
				"left outer join dlp_tbl_function_master lvf " +
				"on con.l_v_function =lvf.function_id " +
				"left outer join dlp_tbl_value_type_master lvt " +
				"on con.l_value_type =lvt.value_type_id " +
				"left outer join dlp_operator_master rop " +
				"on con.r_opr =rop.operator_id where scheme_id in(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ? and circle_id = ? ) order by con.insert_date_time asc";

		//System.out.println("Cov Query  "+query);
		 	covList = jdbcTemplate.query(query, new Object[]{schemeName, Integer.valueOf(httpSession.getAttribute("circleId").toString())}, new RowMapper<SchemeAcMaster>() {

			@Override
			public SchemeAcMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeAcMaster covMaster = new SchemeAcMaster();
				
				
				covMaster.setCondId(rs.getInt("condition_id"));
				covMaster.setCondRowId(rs.getInt("condition_row_id"));
				covMaster.setCompId(rs.getInt("comp_id")); 
			//	covMaster.setCompName(rs.getString("componenet_name"));
				covMaster.setEntityName(rs.getString("entity_type"));
				covMaster.setAttrTypeName(rs.getString("attribute_type"));
				covMaster.setFunctionName(rs.getString("function"));
				covMaster.setAttrMappingName(rs.getString("attribute_name"));
				covMaster.setOprName(rs.getString("opr"));
				covMaster.setCo_functionName(rs.getString("v_function"));
				covMaster.setStartDate(rs.getDate("start_date"));
				covMaster.setEndDate(rs.getDate("end_date"));
				covMaster.setCo_ValueTypeName(rs.getString("value_type"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setLoprName(rs.getString("lopr"));
				covMaster.setLentityTypeName(rs.getString("l_entity_type"));
				covMaster.setLattrTypeName(rs.getString("l_attribute_type"));
				covMaster.setLfunctionName(rs.getString("l_function"));
				covMaster.setLattNameString(rs.getString("l_attribute_name"));
				covMaster.setLloprName(rs.getString("l_opr"));
				covMaster.setLvalueTypeName(rs.getString("l_value_type"));
				covMaster.setLvalueName(rs.getString("l_value"));
				covMaster.setLvfunctionName(rs.getString("l_v_function"));
				covMaster.setlStartDate(rs.getDate("l_start_date"));
				covMaster.setlEndDate(rs.getDate("l_end_date"));
				covMaster.setRoprName(rs.getString("r_opr"));
				
				return covMaster;
			}
			
		});
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || getCoverage || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return covList;
	}

	@Override
	public void updateCov(String schemeName, int compId, int condId, int condRowId,
			SchemeAcMaster addCov) throws Exception {
		// TODO Auto-generated method stub
		try {
		//System.out.println("SchemeInputAllDAOImpl || updateCov");
		String sql = "update DLP_SCM_CO_COND_CONFIG_STAGE set entity_type=?," +
				"attribute_type=?," +
				"function=?," +
				"attribute_name=?," +
				"v_function=?,opr=?,value_type=?,value=?,start_date=?,end_date=?,lopr=?,l_entity_type=?,l_attribute_type=?,l_function=?,l_attribute_name=?,l_opr=?,l_value_type=?,l_start_date=?,l_end_date=?,r_opr=?,validity_flag=?,l_v_function=?,l_value=?,update_date_time=? where scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name='"+schemeName+"' and CIRCLE_ID="+addCov.getCircleId()+") AND component_id=? AND condition_id=? AND condition_row_id=?";
	
		
		jdbcTemplate.update(sql
				,addCov.getEntityId()
				,addCov.getAttrType()
				,addCov.getFunction()
				,addCov.getAttrName()
				,addCov.getCo_vFunction()
				,addCov.getOpr()
				,addCov.getCo_ValueType()
				,addCov.getValue()
				,addCov.getStartDate()
				,addCov.getEndDate()
				,addCov.getLopr()
				,addCov.getlEntityType()
				,addCov.getlAttrType()
				,addCov.getlFunction()
				,addCov.getlAttName()
				,addCov.getlOpr()
				,addCov.getlValueType()
				,addCov.getlStartDate()
				,addCov.getlEndDate()
				,addCov.getrOpr()
				,addCov.getValFlag()
				,addCov.getlVfunction()
				,addCov.getlValue()
				,addCov.getUpdateDate()
				,compId
				,condId
				,condRowId);
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updateCov || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		
	}
	

	@Override
	public int deleteCov(String schemeName,String coValueTypeName) throws Exception {

		// TODO Auto-generated method stub
		
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		
		String covArray[]=coValueTypeName.split(",");
		
		int successFlag=0;
		
		boolean isValid=false;
		
		Set<Integer> s=new HashSet<Integer>();
		List<Integer> n=null;
		try {
		if(covArray.length>1)
		{
			for(String tempVar:covArray)
				{
					String tempArray[]=tempVar.split(":");
					s.add(Integer.parseInt(tempArray[2]));
					n=new ArrayList<Integer>(s);
				}
			
			
				for(int j=0;j<n.size()-1;j++)
				{
					int x=Integer.parseInt(n.get(j).toString());
					int y=Integer.parseInt(n.get(j+1).toString());
					
					int z=y-x;
					
					if(z!=1)
					{
					
						//System.out.println("SchemeInputALLDAOImpl || deleteCov || mismatch");
						return 0;
					
						
					}
					else
					{
						//System.out.println("SchemeInputALLDAOImpl || deleteCov || correct data");

					} 
					
					//System.out.println("Outside For");
					
				}
				//System.out.println("SchemeInputALLDAOImpl || deleteCov || min val:");
					int maxVal=n.get(n.size()-1);
				
					//System.out.println("SchemeInputALLDAOImpl || deleteCov || max val:"+maxVal);
					
					int r =   getcovCondRowCount(schemeName, 1,1);
					
					//System.out.println("SchemeInputALLDAOImpl || deleteCov || o/p:"+r);
					
					if(maxVal==r)
						isValid=true;
				
		}
		
	
		if(covArray.length==1 || isValid)
		{
		for(String tempVar:covArray)
		//for(int i=covArray.length;)
		{
		//System.out.println("SchemeInputALLDAOImpl || deleteCov || tempVar"+tempVar);
		String eachCov[]=tempVar.split(":");
		int condRowId=Integer.parseInt(eachCov[2]);
		int r =   getcovCondRowCount(schemeName, Integer.parseInt(eachCov[1]), Integer.parseInt(eachCov[0]));
		
		String sql = "DELETE FROM DLP_SCM_CO_COND_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=?  and condition_row_id=?";
		
		//System.out.println("SchemeInputALLDAOImpl || deleteCov || r: "+r+" || condRowId:"+condRowId);
		if(covArray.length==1 && r==condRowId)
		{
			//System.out.println("SchemeInputALLDAOImpl || deleteCov || if block || condRowId:"+condRowId+" || successFlag 1");
			jdbcTemplate.update(sql,schemeId,eachCov[0],condRowId);	
			successFlag=1;
		}
		else if(isValid)
		{
			//System.out.println("SchemeInputALLDAOImpl || deleteCov || if block || condRowId:"+condRowId+" || eachCov[0]:"+eachCov[0]);
			
			jdbcTemplate.update(sql,schemeId,eachCov[0],condRowId);	
			successFlag=1;	
		}
	
		
		}
		}
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || deleteCov || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return successFlag;
		
	}
	private void saveEaFilterCondMaster(SchemeInputAll schemeInput)
	{
		try {
								String sql = "INSERT INTO DLP_SCM_EA_FLTR_COND_CNFG_STG(" +
										" PROCESS_TYPE,"+
										"SCHEME_ID, "+
										"COMPONENT_ID, "+
										"RE_CONFIG_ID, "+
										"VARIABLE_ID, "+
										"VARIABLE_ROW_ID, "+
										"DATA_SET, "+
										"PARAMETER, "+
										"OPR, "+
										"VALUE_TYPE, "+
										"VALUE, "+
										"START_DATE, "+
										"END_DATE, "+
										"ROPR, "+
										"VALIDITY_FLAG, "+
										"UPDATE_DATE_TIME, "+
										"INSERT_DATE_TIME"+
										")"+
										"VALUES(?" +
										",(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?)" +
										",?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
						
						jdbcTemplate.update(sql,schemeInput.getSchemeInputEaFilter().getProcessType(),
								schemeInput.getSchemeInputEaFilter().getSchemeName(),
								schemeInput.getSchemeInputEaFilter().getCircleId()
								,schemeInput.getSchemeInputEaFilter().getCompId()
								,schemeInput.getSchemeInputEaFilter().getReConfigId()
								,schemeInput.getSchemeInputEaFilter().getVariableId()
								,schemeInput.getSchemeInputEaFilter().getVariableRowId()
								,schemeInput.getSchemeInputEaFilter().getDataSet()
								,schemeInput.getSchemeInputEaFilter().getParameter()
								,schemeInput.getSchemeInputEaFilter().getOpr()
								,schemeInput.getSchemeInputEaFilter().getValueType()
								,schemeInput.getSchemeInputEaFilter().getValue()
								,schemeInput.getSchemeInputEaFilter().getStartDate()
								,schemeInput.getSchemeInputEaFilter().getEndDate()
								,schemeInput.getSchemeInputEaFilter().getrOpr()
								,schemeInput.getSchemeInputEaFilter().getValFlag()
								,schemeInput.getSchemeInputEaFilter().getUpdateDate()
								,schemeInput.getSchemeInputEaFilter().getInsertDate()
								);	
						
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveEaFilterCondMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}	

	@Override
	public List<SchemeEaMaster> getEa(String schemeName) {
		
		
		// TODO Auto-generated method stub
		//User user = (User)httpSession.getAttribute("appUser");
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
		List<SchemeEaMaster> covList = new ArrayList<SchemeEaMaster>();
		/*String query="select ea.component_id," +
				"ea.variable_id," +
				"ea.variable_name," +
				"dst.agg_type_desc data_set," +
				"ent.display_value entity_name," +
				"ea.data_source," +
				"fun.display_value function_name," +
				"ea.parameter parameter_name," +
				"opr.display_value opr," +
				"ea.value_type,ea.value," +
				"ea.start_date,ea.end_date," +
				"ea.update_date_time," +
				"ea.insert_date_time " +
				"from DLP_SCM_EA_COND_CONFIG_STAGE ea " +
				"left outer join dlp_aggregate_type_master dst " +
				"on ea.data_set =dst.agg_type_id  " +
				"left outer join dlp_entity_type_master ent " +
				//"on ea.entity_type =ent.entity_type_id " +
				"on ent.entity_type_id in (SELECT TRIM(REGEXP_SUBSTR(ea.entity_type,'[^,]+',1,LEVEL)) FROM DUAL CONNECT BY LEVEL <= REGEXP_COUNT(ea.entity_type, ',') + 1) " +
				
				"left outer join dlp_tbl_function_master fun " +
				"on ea.function =fun.function_id " +
				"left outer join dlp_operator_master opr " +
				"on ea.opr =opr.operator_id  where " +
				"ea.scheme_id in(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name='"+schemeName+"' AND circle_id="+circleId+") order by ea.variable_id desc";
*/
		try {
		String query = "select COMPONENT_ID, VARIABLE_ID, VARIABLE_NAME, DATA_SET," +
				"  rtrim" +
				"  ( XMLAGG (xmlelement (C, ENTITY_TYPE_ID || ',') order by ENTITY_TYPE_ID).extract ('//text()')" +
				"   , ',' ) as ENTITY_TYPE_ID, " +
				"    rtrim" +
				"    ( XMLAGG (xmlelement (C, ENTITY_NAME || ',') order by ENTITY_TYPE_ID).extract ('//text()')" +
				"   , ',' ) as  ENTITY_NAME," +
				" DATA_SOURCE," +
				" FUNCTION_NAME," +
				" PARAMETER_NAME," +
				" OPR," +
				" VALUE_TYPE," +
				" VALUE," +
				" START_DATE," +
				" END_DATE," +
				" UPDATE_DATE_TIME," +
				" INSERT_DATE_TIME,DAY_AGGREGATION,  DAY_LEVEL_AGG_FIELD_DSP_NAME" +
				" FROM (" +
				" select ea.component_id," +
				" ea.variable_id," +
				" ea.variable_name," +
				" DST.AGG_TYPE_DESC DATA_SET," +
				" ent.entity_type_id,ent.display_value entity_name," +
				" ea.data_source," +
				" fun.display_value function_name," +
				" ea.parameter parameter_name," +
				" opr.display_value opr, ea.value_type,ea.value, ea.start_date,ea.end_date,	ea.update_date_time, ea.insert_date_time,EA.DAY_AGGREGATION,  AGG.DAY_LEVEL_AGG_FIELD_DSP_NAME" +
				" from DLP_SCM_EA_COND_CONFIG_STAGE ea" +
				" left outer join DLP_EA_CONFIG_DAY_LEVEL_AGG AGG" +
				" ON (EA.DAY_AGGREGATION = AGG.DAY_LEVEL_AGG_ID)"+
				" left outer join dlp_aggregate_type_master dst" +
				" on ea.data_set =dst.agg_type_id" +
				" left outer join dlp_entity_type_master ent" +
				" on ent.entity_type_id in (SELECT TRIM(REGEXP_SUBSTR(ea.entity_type,'[^,]+',1,LEVEL)) FROM DUAL CONNECT BY LEVEL <= REGEXP_COUNT(ea.entity_type, ',') + 1)" +
				" left outer join dlp_tbl_function_master fun" +
				" on ea.function =fun.function_id" +
				" left outer join dlp_operator_master opr" +
				" on EA.OPR =OPR.OPERATOR_ID  where" +
				" EA.SCHEME_ID in(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? and CIRCLE_ID = ? ) order by EA.VARIABLE_ID desc" +
				") group by COMPONENT_ID,VARIABLE_ID,VARIABLE_NAME,DATA_SET,DATA_SOURCE,FUNCTION_NAME,PARAMETER_NAME,OPR,VALUE_TYPE,value,START_DATE," +
				" END_DATE,UPDATE_DATE_TIME,INSERT_DATE_TIME,DAY_AGGREGATION,  DAY_LEVEL_AGG_FIELD_DSP_NAME";
		
		//System.out.println("EA QUERY"+query);

		 covList = jdbcTemplate.query(query, new Object[]{schemeName,circleId}, new RowMapper<SchemeEaMaster>() {

			@Override
			public SchemeEaMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeEaMaster covMaster = new SchemeEaMaster();
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setCondId(rs.getInt("variable_id"));
				covMaster.setVariableId(rs.getInt("variable_id"));
				covMaster.setVariableName(rs.getString("variable_name"));
				covMaster.setDataSetName(rs.getString("data_set"));
				covMaster.setEntityTypeName(rs.getString("entity_name"));
				covMaster.setDataSourceName(rs.getString("data_source"));
				covMaster.setFunctionName(rs.getString("function_name"));
				covMaster.setParameter(rs.getString("parameter_name"));
				covMaster.setOprName(rs.getString("opr"));
				covMaster.setValueType(rs.getString("value_type"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setStartDate(rs.getDate("start_date"));
				covMaster.setEndDate(rs.getDate("end_date"));
				covMaster.setUpdateDate(rs.getDate("update_date_time"));
				covMaster.setInsertDate(rs.getDate("insert_date_time"));
				covMaster.setEntityTypeId(rs.getString("entity_type_id"));
				
				covMaster.setDaylvlAggrId(rs.getInt("DAY_AGGREGATION"));
				covMaster.setDaylvlAggr(rs.getString("DAY_LEVEL_AGG_FIELD_DSP_NAME"));
				
				return covMaster;
			}
			
		});
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveEaFilterCondMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return covList;
	}




	@Override
	public List<SchemeEaFilterCondMaster> getEaFilter(String schemeName) {
		// TODO Auto-generated method stub
		List<SchemeEaFilterCondMaster> covList = new ArrayList<SchemeEaFilterCondMaster>();
		try {
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		
		
		String query="select eaf.component_id," +
				"eaf.variable_id," +
				"ea.variable_name ," +
				"eaf.variable_row_id var_row_id," +
				"dst.display_value data_set," +
				"eaf.parameter,op" +
				"r.display_value opr," +
				"eaf.value_type," +
				"eaf.value," +
				"eaf.start_date," +
				"eaf.end_date," +
				"eaf.update_date_time," +
				"eaf.insert_date_time " +
				"from DLP_SCM_EA_FLTR_COND_CNFG_STG eaf " +
				"left outer join DLP_SCM_EA_COND_CONFIG_STAGE ea " +
				"on ea.variable_id = eaf.variable_id  " +
				"left outer join dlp_tbl_input_type_master dst " +
				"on dst.input_type_id = eaf.data_set " +
				"left outer join dlp_operator_master opr " +
				"on opr.operator_id = eaf.opr  " +
				"left outer join dlp_tbl_function_master fun " +
				"on ea.function =fun.function_id " +
				"left outer join dlp_operator_master opr " +
				"on ea.opr =opr.operator_id " +
				"where ea.scheme_id = eaf.scheme_id  and ea.component_id = eaf.component_id and ea.variable_id = eaf.variable_id and eaf.scheme_id = ?";
	//	//System.out.println("EA FILTER: "+query);

		 covList = jdbcTemplate.query(query, new Object[]{schemeId}, new RowMapper<SchemeEaFilterCondMaster>() {

			@Override
			public SchemeEaFilterCondMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeEaFilterCondMaster covMaster = new SchemeEaFilterCondMaster();
				
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setVariableId(rs.getInt("VARIABLE_ID"));
				//covMaster.setCompName(rs.getString("componenet_name"));
				covMaster.setVariableName(rs.getString("variable_name"));
				covMaster.setVariableRowId(rs.getInt("var_row_id"));
				covMaster.setDataSetName(rs.getString("data_set"));
				covMaster.setParameter(rs.getString("parameter"));
				covMaster.setOprName(rs.getString("opr"));
				covMaster.setValueType(rs.getString("value_type"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setStartDate(rs.getDate("start_date"));
				covMaster.setEndDate(rs.getDate("end_date"));
				
				return covMaster;
			}
			
		});
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || saveEaFilterCondMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return covList;
	}


		
	/*@Override
	public int deletePoCond(String schemeName, int compId, int condId, int condRowId) {
		// TODO Auto-generated method stub

		int isMax = 0;
		
		isMax = getPoCondCountForDelete(schemeName, compId);
		
		if(isMax==condId)
		{	
		String query = "select lopr from DLP_SCM_PO_COND_CONFIG_STAGE where scheme_id = "+Integer.valueOf(httpSession.getAttribute("schemeId").toString())+" and component_id = "+compId+" and condition_id="+condId+" and condition_row_id="+condRowId;
		
		
		@SuppressWarnings("deprecation")
		 int lopr = jdbcTemplate.queryForInt(query);
		
		if((lopr==26) ||(lopr==23) ||(lopr==0) || condRowId ==1 )
		{
		String sql2 = "DELETE FROM DLP_SCM_PO_AMT_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND condition_id=?";

		jdbcTemplate.update(sql2,
				Integer.valueOf(httpSession.getAttribute("schemeId").toString()),
				compId,condId);
		}

		
		
		String sql = "DELETE FROM DLP_SCM_PO_COND_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND  condition_id = ? AND condition_row_id=?";
		
		jdbcTemplate.update(sql,
				Integer.valueOf(httpSession.getAttribute("schemeId").toString()),
				compId,condId,condRowId);
		
		return 1;
		}
		else
		return 0;	
		
	}*/
	@Override
	public int deletePoCond(String schemeName, String paramName) {
		//System.out.println("SchemeInputAllDAOImpl || deleteTq || paramName:"+paramName);
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		String rows[]=paramName.split(":");
		int updatedRowsCount=0;
		//int maxCondId = getTqCondMaxCount(compId);
		//int maxrowId = getTqCondRowCount(schemeName, condId, compId);
		try {
		for(String eachRow:rows)
		{
			String eachVal[]=eachRow.split(",");	

			int compId=Integer.parseInt(eachVal[0]);
			int condId=Integer.parseInt(eachVal[1]);
			int condRowId=Integer.parseInt(eachVal[2]);
			String query = "select lopr from DLP_SCM_PO_COND_CONFIG_STAGE where scheme_id = ? and component_id = ? and condition_id = ? and condition_row_id = ?";
			@SuppressWarnings("deprecation")
			int lopr = jdbcTemplate.queryForInt(query, new Object[]{Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId, condId, condRowId});
			if((lopr==26) ||(lopr==23) ||(lopr==0) || condRowId ==1 )
			{

				String sql2 = "DELETE FROM DLP_SCM_PO_AMT_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND condition_id=?";
				jdbcTemplate.update(sql2, Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId,condId);
			}

			String sql = "DELETE FROM DLP_SCM_PO_COND_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND  condition_id = ? AND condition_row_id=?";
			updatedRowsCount=jdbcTemplate.update(sql,
					Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId,condId,condRowId);
		}
		
		
		for(String eachRow:rows)
		{
			String eachVal[]=eachRow.split(",");	

			int compId=Integer.parseInt(eachVal[0]);
			int condId=Integer.parseInt(eachVal[1]);
			//int condRowId=Integer.parseInt(eachVal[2]);
			
			String queryStrRowId = "select ltrim(rtrim(xmlagg(xmlelement(e, CONDITION_ROW_ID || ',')).extract('//text()'),','),',') AS CONDITION_ROW_ID " +
					" from DLP_SCM_PO_COND_CONFIG_STAGE where SCHEME_ID = ?   AND COMPONENT_ID = ?  and condition_id = ?  and validity_flag = 'Y' order by CONDITION_ROW_ID ";
			
			String queryCount = " select count(*) from DLP_SCM_PO_COND_CONFIG_STAGE where SCHEME_ID = ?  AND COMPONENT_ID = ?  and condition_id = ? and validity_flag = 'Y' ";
			
		
			String condiRowIdStr = null;
			try{
				condiRowIdStr = jdbcTemplate.queryForObject(queryStrRowId,  new Object[]{Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId, condId}, String.class);
				
			}catch(Exception e){
				e.printStackTrace();
			}
			
			
			int count = 0;
			//System.out.println("condiRowIdStr ::::::::::: ===== >>>> "+condiRowIdStr);
			try {
				
				String count1 = jdbcTemplate.queryForObject(queryCount, new Object[]{Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId, condId}, String.class);
				count = Integer.parseInt(count1);
					
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			//System.out.println("count ::::::::::: ===== >>>> "+count);
			if(condiRowIdStr!=null){
				String[] rowId =  condiRowIdStr.split(",");

				for(int i=1; i <= count; i++ ){

					int j = Integer.parseInt(rowId[i-1]);

					if( j != i){
						String sql = " update DLP_SCM_PO_COND_CONFIG_STAGE set condition_row_id = ? where SCHEME_ID = ? AND COMPONENT_ID=? AND  condition_id = ? AND condition_row_id = ? ";
						updatedRowsCount = jdbcTemplate.update(sql,new Object[]{i, Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId, condId, j });
					}
				}
			}
		}

		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || deletePoCond || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		if(updatedRowsCount!=0)
			return 1;
		else
			return 0;
	}
	
	
	
	@Override
	public void updatePo(String schemeName, int compId, int condId,int condRowId, SchemePoMaster po) throws SQLException {
		// TODO Auto-generated method stub
		
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());

		try {
		String sql = "update DLP_SCM_PO_COND_CONFIG_STAGE set " +
				"INPUT_TYPE=?," +
				"input_parameter=?," +
				"opr=?," +
				"value_type=?," +
				"value=?," +
				"start_date=?," +
				"end_date=?," +
				"LOPR=?," +
				"validity_flag=?," +
				"update_date_time=? " +
				"where scheme_id=? and component_id=? AND condition_id=? AND condition_row_id=?";
	
		jdbcTemplate.update(sql
				,po.getInputType()
				,po.getInputParameter()
				,po.getOpr()
				,po.getValueType()
				,po.getValue()
				,po.getStartDate()
				,po.getEndDate()
				,po.getLopr()
				,po.getValFlag()
				,po.getUpdateDate()
				,schemeId
				,compId
				,condId
				,condRowId);
			
	
		
		
		
		if(po.getLopr()==26 ||po.getLopr()==23)
		{
			po.setProcessType("G");
			SchemeInputAll schemeInput = new SchemeInputAll();
			schemeInput.setSchemeInputPo(po);
			int row = getPoAmtCount(po.getCompId(), po.getCondId());
			if(row==0)
			savePayoutCondAmtMaster(schemeInput);

			
		updatePoFilter(schemeId,po.getCompId(),po.getCondId(),po);
	
		}
		if(po.getLopr()==26)
			updateSchemeFlag(po.getSchemeName(),po.getCircleId(),po.getCompId());
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updatePo || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}


	@Override
	public void updatePoFilter(int schemeId, int compId, int condId,
			SchemePoMaster poFilter) {
		// TODO Auto-generated method stub
		
		//System.out.println("varaiable "+poFilter.getPaymentVariable());
		try {
		String sql = "update DLP_SCM_PO_AMT_CONFIG_STAGE " +
				"set gross_net=?," +
				"unit=?," +
				"amount=?," +
				"variable=?," +
				"over_achievement=?," +
				"under_achievement=?," +
				"update_date_time=? where scheme_id=? and component_id=? and condition_id=?";
		jdbcTemplate.update(sql
				,poFilter.getGrossNet()
				,poFilter.getUnit()
				,poFilter.getAmount()
				,poFilter.getPaymentVariable()
				,poFilter.getOverAch()
				,poFilter.getUnderAch()
				,poFilter.getUpdateDate()
				
				,schemeId
				,compId
				,condId);
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updatePoFilter || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}
	
	@Override
	public List<SchemePoMaster> getPo(String schemeName) {
		// TODO Auto-generated method stub
		List<SchemePoMaster> covList = new ArrayList<SchemePoMaster>();
	try {	
		String query = "SELECT "+ 
						"PO.SCHEME_ID "+
						",PO.COMPONENT_ID "+
						",PO.CONDITION_ID "+
						",PO.CONDITION_ROW_ID "+
						", (SELECT inp.display_value FROM dlp_tbl_input_type_master inp WHERE inp.input_type_id=po.input_type) INPUT_TYPE "+
						",PO.INPUT_PARAMETER "+
						",(SELECT OPR.display_value FROM DLP_OPERATOR_MASTER OPR "+ 
						"WHERE OPR.OPERATOR_ID=PO.OPR AND OPR.VALIDITY_FLAG='Y'  AND OPR.PO_FLAG='Y') OPR "+
						", (SELECT vt.display_value FROM dlp_tbl_value_type_master vt WHERE vt.value_type_id=PO.VALUE_TYPE) VALUE_TYPE "+
						",PO.VALUE "+
						",PO.START_DATE "+
						",PO.END_DATE "+
						",(SELECT OPR.display_value FROM DLP_OPERATOR_MASTER OPR "+ 
						"WHERE OPR.OPERATOR_ID=PO.LOPR AND OPR.VALIDITY_FLAG='Y'  AND OPR.PO_FLAG='Y') LOPR "+
						",POF.GROSS_NET "+
						",(SELECT UNIT.DISPLAY_VALUE FROM DLP_UNIT_MASTER UNIT "+ 
						"WHERE UNIT.UNIT_ID = POF.UNIT) UNIT "+
						",POF.AMOUNT "+
						",POF.VARIABLE VARIABLE "+
						",POF.OVER_ACHIEVEMENT "+
						",POF.UNDER_ACHIEVEMENT "+
						",PO.INSERT_DATE_TIME "+
						",PO.UPDATE_DATE_TIME "+   
						"FROM "+
						"DLP_SCM_PO_COND_CONFIG_STAGE PO  " +
						"left outer join DLP_SCM_PO_AMT_CONFIG_STAGE POF "+
						" on PO.SCHEME_ID =POF.SCHEME_ID AND PO.COMPONENT_ID=POF.COMPONENT_ID AND PO.CONDITION_ID=POF.CONDITION_ID"+
						
						" WHERE "+
						""+
						""+
						" PO.SCHEME_ID in (select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ? and circle_id = ? ) order by po.condition_id desc,po.condition_row_id desc";		
		//System.out.println("GET PO "+query);

		 covList = jdbcTemplate.query(query, new Object[]{schemeName, Integer.valueOf(httpSession.getAttribute("circleId").toString())}, new RowMapper<SchemePoMaster>() {

			@Override
			public SchemePoMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemePoMaster covMaster = new SchemePoMaster();
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setCondRowId(rs.getInt("condition_row_id"));
				covMaster.setCondId(rs.getInt("condition_id"));
				covMaster.setInputType(rs.getString("input_type"));
				covMaster.setInputParameter(rs.getString("input_parameter"));
				covMaster.setOprName(rs.getString("opr"));
				covMaster.setValueType(rs.getString("value_type"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setStartDate(rs.getDate("start_date"));
				covMaster.setEndDate(rs.getDate("end_date"));
				covMaster.setLoprName(rs.getString("lopr"));
				
				if("Close Condition".equals(covMaster.getLoprName()) || "Add New Condition".equals(covMaster.getLoprName()))
				{
				covMaster.setGrossNet(rs.getString("gross_net"));
				covMaster.setUnitName(rs.getString("unit"));
				covMaster.setAmount(rs.getBigDecimal("amount"));
				//covMaster.setAmount(amount);
				covMaster.setPaymentVariable(rs.getString("variable"));
				covMaster.setOverAch(rs.getInt("over_achievement"));
				covMaster.setUnderAch(rs.getInt("under_achievement"));
				}
				covMaster.setUpdateDate(rs.getDate("update_date_time"));
				covMaster.setInsertDate(rs.getDate("insert_date_time"));
				
				
				return covMaster;
			}
			
		});
		
	}catch(NullPointerException e) {
		System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updatePoFilter || Exception  ");
	}
	catch(Exception e){
		
		if(logger.isDebugEnabled()) {
		logger.error("Exception :: ",e);
		e.printStackTrace();
		}
	}
		return covList;
	}

@Override
	public void savePayoutCondAmtMaster(SchemeInputAll schemeInput) throws SQLException
	{
		try {
		
						String sql = "INSERT INTO DLP_SCM_PO_AMT_CONFIG_STAGE(" +
								" PROCESS_TYPE, "+
								"SCHEME_ID, "+
								"COMPONENT_ID, "+
								"RE_CONFIG_ID, "+
								"CONDITION_ID, "+
								"GROSS_NET, "+
								"UNIT, "+
								"AMOUNT, "+
								"VARIABLE, "+
								"OVER_ACHIEVEMENT, "+
								"UNDER_ACHIEVEMENT, "+
								"VALIDITY_FLAG, "+
								"UPDATE_DATE_TIME, "+
								"INSERT_DATE_TIME"+
								")"+
								"VALUES(?" +
								",(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?)" +
								",?,?," +
								"?," +
								"?,?,?,?,?,?,?,?,?)";
						
						jdbcTemplate.update(sql,schemeInput.getSchemeInputPo().getProcessType(),
								schemeInput.getSchemeInputPo().getSchemeName(),
								schemeInput.getSchemeInputPo().getCircleId(),
								schemeInput.getSchemeInputPo().getCompId()
								,schemeInput.getSchemeInputPo().getReConfigId()
								,schemeInput.getSchemeInputPo().getCondId()
								,schemeInput.getSchemeInputPo().getGrossNet()
								,schemeInput.getSchemeInputPo().getUnit()
								,schemeInput.getSchemeInputPo().getAmount()
								,schemeInput.getSchemeInputPo().getVariable()
								,schemeInput.getSchemeInputPo().getOverAch()
								,schemeInput.getSchemeInputPo().getUnderAch()
								,schemeInput.getSchemeInputPo().getValFlag()
								,schemeInput.getSchemeInputPo().getUpdateDate()
								,schemeInput.getSchemeInputPo().getInsertDate()
								);	
	
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || savePayoutCondAmtMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		
		}


	
	@Override
	public void savePoFilter(SchemePoAmtMaster po) throws SQLException {
		// TODO Auto-generated method stub
		SchemeInputAll schemeInput = new SchemeInputAll();
		schemeInput.setSchemeInputPoAmt(po);
		savePayoutCondAmtMaster(schemeInput);
	}
	
	@Override
	public List<SchemePoAmtMaster> getPoFilter(String schemeName) {
		// TODO Auto-generated method stub
		List<SchemePoAmtMaster> covList = new ArrayList<SchemePoAmtMaster>();
		try {
		String query="select pof.component_id," +
				"pof.condition_id," +
				"po.value," +
				"pof.gross_net," +
				"unit.display_value unit," +
				"pof.amount," +
				"var.display_value variable," +
				"pof.over_achievement," +
				"pof.under_achievement," +
				"pof.update_date_time," +
				"pof.insert_date_time " +
				"from DLP_SCM_PO_AMT_CONFIG_STAGE pof " +
				"left outer join DLP_SCM_PO_COND_CONFIG_STAGE po " +
				"on po.condition_id = pof.condition_id " +
				"left outer join DLP_Entity_Type_Master var " +
				"on var.entity_type_id = pof.variable " +
				"left outer join dlp_unit_master unit " +
				"on unit.unit_id = pof.unit " +
				"where po.scheme_id = pof.scheme_id and pof.scheme_id = ?";
				//"where po.scheme_id = pof.scheme_id and pof.scheme_id in (select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ?)";
				
		 covList = jdbcTemplate.query(query, new Object[]{Integer.valueOf(httpSession.getAttribute("schemeId").toString())}, new RowMapper<SchemePoAmtMaster>() {
			@Override
			public SchemePoAmtMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemePoAmtMaster covMaster = new SchemePoAmtMaster();
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setCondId(rs.getInt("condition_id"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setGrossNet(rs.getString("gross_net"));
				covMaster.setUnitName(rs.getString("unit"));
				covMaster.setAmount(rs.getBigDecimal("amount"));
				covMaster.setVariableName(rs.getString("variable"));
				covMaster.setOverAch(rs.getInt("over_achievement"));
				covMaster.setUnderAch(rs.getInt("under_achievement"));
				covMaster.setUpdateDate(rs.getDate("update_date_time"));
				covMaster.setInsertDate(rs.getDate("insert_date_time"));
				return covMaster;
			}
		});
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || savePayoutCondAmtMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		
		return covList;
	}

	@Override
	public List<RoprMaster> getRopr() {
		List<RoprMaster> covList = new ArrayList<RoprMaster>();
		try {
		String query="select operator_id, display_value, co_flag, tq_flag, po_flag from dlp_operator_master where validity_flag='Y' AND operator_type IN ('M','L')";
		 covList = jdbcTemplate.query(query, new RowMapper<RoprMaster>() {
			@Override
			public RoprMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				RoprMaster covMaster = new RoprMaster();
				covMaster.setOprId(rs.getInt("operator_id"));
				covMaster.setOprName(rs.getString("display_value"));
				covMaster.setCoFlag(rs.getString("co_flag"));
				covMaster.setTqFlag(rs.getString("tq_flag"));
				covMaster.setPoFlag(rs.getString("po_flag"));
				//covMaster.setCompName(rs.getString("componenet_name"));
				//regMaster.setRegionId(rs.getInt("region_id"));
				//covMaster.setRegionDesc(rs.getString("region_description"));
				//covMaster.setZoneDesc(rs.getString("zone_description"));
				return covMaster;
			}
		});
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || savePayoutCondAmtMaster || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return covList;
	}




	@Override
	public int getcovCondCount(String schemeName,int compId) {
		// TODO Auto-generated method stub
		String query="select max(condition_id) from DLP_SCM_CO_COND_CONFIG_STAGE where " +
				"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? and circle_id = ? ) and component_id = ?";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeName, Integer.valueOf(httpSession.getAttribute("circleId").toString()), compId});
		return row;
	}
	
	@Override
	public int getcovCondRowCount(String schemeName,int condId,int compId) {
		// TODO Auto-generated method stub
		String query="select max(condition_row_id) from DLP_SCM_CO_COND_CONFIG_STAGE where " +
				"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? and circle_id = ? ) and condition_id = ? and component_id = ?";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeName, Integer.valueOf(httpSession.getAttribute("circleId").toString()), condId, compId});
		return row;
	}

	@Override
	public int getTqCondCount(String condName,int compId) {
		// TODO Auto-generated method stub
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		String query="select  max(condition_id) from DLP_SCM_TQ_COND_CONFIG_STAGE where  SCHEME_ID = ? and component_id = ? AND condition_name = ?";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeId, compId, condName});
		return row;
	}
	
	
	@Override
	public int getTqCondMaxCount(int compId) {
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		String query="select  max(condition_id) from DLP_SCM_TQ_COND_CONFIG_STAGE where  SCHEME_ID = ? and component_id = ?";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeId, compId});
		return row;
	}

	
	

	@Override
	public int getTqCondRowCount(String schemeName,int condId,int compId) {
		String query="select  max(condition_row_id) from DLP_SCM_TQ_COND_CONFIG_STAGE where " +
				"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? and circle_id = ?) and condition_id = ? AND component_id = ? ";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeName,Integer.valueOf(httpSession.getAttribute("circleId").toString()),condId,compId});
		return row;
	}

	
	@Override
	public int getEaCondCount(String schemeName,int compId) {
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		String query="select max(variable_id) from DLP_SCM_EA_COND_CONFIG_STAGE where  SCHEME_ID = ? and  component_id= ?";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeId, compId});
		return row;
	}
	
	
	
	@Override
	public int getEaFilterCondCount(String schemeName, int varId , int compId) {
		// TODO Auto-generated method stub
		String query="select max(variable_row_id) from DLP_SCM_EA_FLTR_COND_CNFG_STG where " +
				"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? ) AND variable_id = ? and component_id = ?";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query,new Object[]{schemeName,varId,compId});
		return row;
	}
	
	@Override
	public List<SchemeEaMaster> getEaVaraibles(String schemeName) {
		// TODO Auto-generated method stub
		String query="select component_id,variable_id,variable_name,data_set from DLP_SCM_EA_COND_CONFIG_STAGE where scheme_id in(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ?)";
		//System.out.println("SchemeInputAllDAOImpl getEaVaraibles :::: "+query);
		List<SchemeEaMaster> covList = jdbcTemplate.query(query, new Object[]{schemeName}, new RowMapper<SchemeEaMaster>() {
			@Override
			public SchemeEaMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeEaMaster covMaster = new SchemeEaMaster();
				covMaster.setVariableId(rs.getInt("variable_id"));
				covMaster.setVariableName(rs.getString("variable_name"));
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setDataSet(rs.getInt("data_set"));
				return covMaster;
			}
		});
		return covList;
	}


	@Override
	public List<SchemePoMaster> getPoValues(String schemeName) {
		// TODO Auto-generated method stub
		String query="select po.condition_id,po.value from DLP_SCM_PO_COND_CONFIG_STAGE po where po.scheme_id in (select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ?)";
		List<SchemePoMaster> covList = jdbcTemplate.query(query, new Object[]{schemeName}, new RowMapper<SchemePoMaster>() {
			@Override
			public SchemePoMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemePoMaster covMaster = new SchemePoMaster();
				covMaster.setCondId(rs.getInt("condition_id"));
				covMaster.setValue(rs.getString("value"));
				return covMaster;
			}
		});
		return covList;
	}

	@Override
	public boolean schemeNameVal(String schemeName, int circleId) {
		// TODO Auto-generated method stub
		String query="select count(scheme_id) from DLP_SCHEME_MASTER_STAGE where " +
				"SCHEME_NAME = ? AND CIRCLE_ID = ?";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query,schemeName,circleId);
		if(row==0)
		return true;
		else
		return false;
	}

	@Override
	public boolean compNameVal(String compName) {
		// TODO Auto-generated method stub
		
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
		String schemeName = (String)httpSession.getAttribute("schemeName");
		String query="select count(comp.scheme_id) from DLP_SCHEME_COMP_MAPPING_STAGE comp where " +
				"comp.COMPONENET_NAME = ? AND comp.SCHEME_ID=(select scm.scheme_id from DLP_SCHEME_MASTER_STAGE scm where scm.scheme_name = ? AND scm.circle_id = ?)";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query,compName,schemeName,circleId);
		if(row==0)
		return true;
		else
		return false;
	}

	@Override
	public int deleteComp(int schemeId, int compId) {
		// TODO Auto-generated method stub
		//System.out.println();
		
		String sql = "DELETE FROM DLP_SCHEME_COMP_MAPPING_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND scm_status !='D'";
		
		 int  r = jdbcTemplate.update(sql,schemeId,compId);
	
		 return r;
	
	}

	
	@Override
	public void updateComp(int schemeId, int compId, CompMaster compInput) {
		try {
		
			String sql = "update DLP_SCHEME_COMP_MAPPING_STAGE set " +
					"COMPONENET_NAME=?,"+
					"component_ver=?," +
					"start_date=?," +
					"end_date=?," +
					"freequency_id=?," +
					"coverage_flag=?," +
					"vertical_id=?," +
					"pay_to=?," +
					"file_name=?," +
					"validity_flag=?," +
					"update_date_time=?," +
					"CATEGORY_ID=?"+
					" where scheme_id=? and component_id=?";
			
		//	//System.out.println(sql);
			 jdbcTemplate.update(sql,
					 compInput.getCompName(),
					compInput.getCompVer()
					,compInput.getStartDate()
					,compInput.getEndDate()
					,compInput.getFreqId()
					,compInput.getCoverageFlag()
					,compInput.getVerticalId()
					,compInput.getPayTo()
					,compInput.getFileName()
					,compInput.getValFlag()
					,compInput.getUpdateTime()
					,compInput.getCategory()
					,schemeId,compId);
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updateComp || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}

	/*private CompMaster getCompName(int schemeId, int compId){
		String query="select SCHEME_ID, COMPONENT_ID, COMPONENT_VER, COMPONENET_NAME, START_DATE, END_DATE, FREEQUENCY_ID, VERTICAL_ID, PAY_TO, COVERAGE_FLAG," +
				" FILE_NAME, VALIDITY_FLAG, USER_ID, UPDATE_DATE_TIME, INSERT_DATE_TIME, REASON, VTOPUP_FILE_FLAG, PAYOUT_STATUS, SCM_STATUS, SCM_APPROVAL_DT," +
				" SCM_APPROVED_BY, PAYOUT_APPROVAL_DT, PAYOUT_APPROVED_BY, PAYMENT_STATUS, PAYMENT_ID, STATEMENT_STATUS, STATEMENT_CYCLE_ID, SCM_REJECTED_BY," +
				" SCM_REJECTION_DT, SCM_COMMENT, VTOPUP_FILE_NAME, LAST_EXECUTION_DATE, MANUAL_PAYOUT_FLAG   from DLP_SCHEME_COMP_MAPPING_STAGE where SCHEME_ID = ? and COMPONENT_ID = ? and VALIDITY_FLAG='Y'";
	
		CompMaster cm = jdbcTemplate.queryForObject(query, new Object[]{schemeId,compId}, new RowMapper<CompMaster>(){
			@Override
			public CompMaster mapRow(ResultSet rs, int arg1)	throws SQLException {
				CompMaster cm = new CompMaster();
				cm.setSchemeId(rs.getInt("SCHEME_ID"));
				cm.setCompId(rs.getInt("COMPONENT_ID"));
				cm.setCompVer(rs.getInt("COMPONENT_VER"));
				cm.setCompName(rs.getString("COMPONENET_NAME"));
				return cm;
			}
		});
		return cm;
	}*/
	
	
/*	private boolean updateOldComp(){
		
	}*/
	/*@Override
	public int deleteTq(String schemeName, int compId, int condId,int condRowId) {
		// TODO Auto-generated method stub
		
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());

		
		int maxCondId = getTqCondMaxCount(compId);
		int maxrowId = getTqCondRowCount(schemeName, condId, compId);
		
		
		String sql = "DELETE FROM DLP_SCM_TQ_COND_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND condition_id=? AND condition_row_id=?";
		
		if(condId== maxCondId && condRowId ==maxrowId)
		{
		jdbcTemplate.update(sql,schemeId,compId,condId,condRowId);
		
		return 1;
		}
		else
		return 0;
		
		}*/
	@Override
	public int deleteTq(String schemeName,String paramName) {
		// TODO Auto-generated method stub
		
		//System.out.println("SchemeInputAllDAOImpl || deleteTq || paramName:"+paramName);
		
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());

		String rows[]=paramName.split(":");
		int updatedRowsCount=0;
		
		//int maxCondId = getTqCondMaxCount(compId);
		//int maxrowId = getTqCondRowCount(schemeName, condId, compId);
		
		for(String eachRow:rows)
		{
		
		String eachVal[]=eachRow.split(",");	
		String sql = "DELETE FROM DLP_SCM_TQ_COND_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND condition_id=? AND condition_row_id=?";
		
		 updatedRowsCount=jdbcTemplate.update(sql,schemeId,eachVal[0],eachVal[1],eachVal[2]);
		
		//System.out.println("SchemeInputAllDAOImpl || deleteTq || updatedRowsCount:"+updatedRowsCount);
		
		}
		
		if(updatedRowsCount!=0)
			return 1;
		else
		    return 0;
		}
	
	
	@Override
	public void updateTq(String schemeName, int compId, int condId,int condRowId, SchemeTqMaster tq) {
		// TODO Auto-generated method stub
		
		try {
		String sql = "update DLP_SCM_TQ_COND_CONFIG_STAGE set " +
				"condition_name=?," +
				"value=?," +
				"value_type=?," +
				"data_set=?," +
				"perf_parameter=?," +
				"opr=?," +
				"start_date=?," +
				"end_date=?," +
				"lopr=?," +
				"l_perf_parameter=?," +
				"l_opr=?," +
				"l_value_type=?," +
				"l_value=?," +
				"l_start_date=?," +
				"l_end_date=?,ropr=?,validity_flag=?,update_date_time=? where scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?) and component_id=? AND condition_id=? AND condition_row_id=?";
		jdbcTemplate.update(sql
				,tq.getCondName()
				,tq.getValue()
				,tq.getValueType()
				,tq.getDataSet()
				,tq.getPerfParmeter()
				,tq.getOpr()
				,tq.getStartDate()
				,tq.getEndDate()
				,tq.getLopr()
				,tq.getlPrefparameter()
				,tq.getlOpr()
				,tq.getlValueType()
				,tq.getlValue()
				,tq.getlStartDate()
				,tq.getlEndDate()
				,tq.getlRopr()
				,tq.getValFlag()
				,tq.getUpdateDate()
				,schemeName
				,tq.getCircleId()
				,compId
				,condId
				,condRowId);
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updateTq || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}


/*	@Override
	public void deleteEa(String schemeName, int compId, int condId , int condRow) {
		// TODO Auto-generated method stub
		
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());

		
		String sql = "DELETE FROM DLP_SCM_EA_COND_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND variable_id=?";
		
		jdbcTemplate.update(sql,schemeId,compId,condId);	
	}*/

	@Override
	public void deleteEa(String schemeName, String parameter) {
		// TODO Auto-generated method stub
	//System.out.println("SchemeInputAllDAOImpl || deleteTq || paramName:"+parameter);
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		String rows[]=parameter.split(":");
		String sql = "DELETE FROM DLP_SCM_EA_COND_CONFIG_STAGE where SCHEME_ID=? AND COMPONENT_ID=? AND variable_id=?";
		for(String eachRow:rows)
		{
			String eachVal[]=eachRow.split(",");
			jdbcTemplate.update(sql,schemeId,eachVal[0],eachVal[1]);
		}
	}

	
	@Override
	public void updateEa(String schemeName, int compId, int condId,int condRowId, SchemeEaMaster ea) {
		// TODO Auto-generated method stub
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		//System.out.println("ea.getEntityType() :::: "+ea.getEntityType()+"  EA DayID :: "+ea.getDaylvlAggrId());
		String[] enty = ea.getEntityType().split(",");
		String flag = "ENTITY_TYPE=?,";
		//String value = ea.getEntityType();
		try{
			int entityType = Integer.parseInt(enty[0]);
			}catch(Exception e){
				flag = "";
			}
		try {
		String sql = "update DLP_SCM_EA_COND_CONFIG_STAGE " +
				"set VARIABLE_NAME=?," +
				"DATA_SET=?," +
				flag+
				"DATA_SOURCE=?," +
				"FUNCTION=?," +
				"PARAMETER=?," +
				"OPR=?," +
				"VALUE_TYPE=?," +
				"VALUE=?," +
				"START_DATE=?," +
				"END_DATE=?," +
				"FILTER=?," +
				"VALIDITY_FLAG=?," +
				"UPDATE_DATE_TIME=?," +
				"VAR_ROW_ID=?," +
				"DAY_AGGREGATION=? where scheme_id=? and COMPONENT_ID=? AND VARIABLE_ID=?";
		
		if(flag.equalsIgnoreCase("")){ jdbcTemplate.update(sql
				,ea.getVariableName()
				,ea.getDataSet()
				,ea.getDataSourceName()
				,ea.getFunction()
				,ea.getParameter()
				,ea.getOpr()
				,ea.getValueType()
				,ea.getValue()
				,ea.getStartDate()
				,ea.getEndDate()
				,ea.getFilter()
				,ea.getValFlag()
				,ea.getUpdateDate()
				,ea.getVarRowId()
				,ea.getDaylvlAggrId()
				,schemeId
				,compId
				,condId
				
				);
		}else{
			jdbcTemplate.update(sql
					,ea.getVariableName()
					,ea.getDataSet()
					,ea.getEntityType()
					,ea.getDataSourceName()
					,ea.getFunction()
					,ea.getParameter()
					,ea.getOpr()
					,ea.getValueType()
					,ea.getValue()
					,ea.getStartDate()
					,ea.getEndDate()
					,ea.getFilter()
					,ea.getValFlag()
					,ea.getUpdateDate()
					,ea.getVarRowId()
					,ea.getDaylvlAggrId()
					,schemeId
					,compId
					,condId
					
					);
		
		}
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updateEa || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}
	
	
	
	@Override
	public void deleteEaFilter(String schemeName, int compId, int condId, int filtId) {
		// TODO Auto-generated method stub
		String sql = "DELETE FROM DLP_SCM_EA_FLTR_COND_CNFG_STG where SCHEME_ID=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=?) AND COMPONENT_ID=? AND VARIABLE_ID=? AND VARIABLE_ROW_ID=?";
			
		jdbcTemplate.update(sql,schemeName,compId,condId,filtId);	
	}

	
	

	@Override
	public void updateEaFilter(String schemeName, int compId, int condId,
			int filtId, SchemeEaFilterCondMaster eaFilter) {
		// TODO Auto-generated method stub
		try {
		String sql = "update DLP_SCM_EA_FLTR_COND_CNFG_STG " +
				"set data_set=?," +
				"parameter=?," +
				"opr=?," +
				"value_type=?," +
				"value=?," +
				"start_date=?," +
				"end_date=?," +
				"ropr=?," +
				"update_date_time=? " +
				"where " +
				"scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=?) and component_id=? and variable_id=? and variable_row_id=?";
		jdbcTemplate.update(sql
				,eaFilter.getDataSet()
				,eaFilter.getParameter()
				,eaFilter.getOpr()
				,eaFilter.getValueType()
				,eaFilter.getValue()
				,eaFilter.getStartDate()
				,eaFilter.getEndDate()
				,eaFilter.getrOpr()
				,eaFilter.getUpdateDate()
				,schemeName
				,compId
				,condId
				,filtId);
		
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updateEaFilter || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}

	@Override
	public void updateCompVflag(int schemeId, int compId, CompMaster compInput) {
		// TODO Auto-generated method stub
		String sql = "update DLP_SCHEME_COMP_MAPPING_STAGE set validity_flag = ?" +
				" where scheme_id = ? and component_id = ?";
		 jdbcTemplate.update(sql, compInput.getValFlag(), compInput.getSchemeId(), compInput.getCompId());		
	}

	@Override
	public void updateRegZoneVflag(RegZoneMaster rzMaster) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateTqVflag(String schemeName, int compId, int condId,
			SchemeTqMaster tq) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateEaVflag(String schemeName, int compId, int condId, SchemeEaMaster ea) {
		String sql = "update DLP_SCM_EA_COND_CONFIG_STAGE set validity_flag=? where scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=?) and component_id=? AND COND_ID=?";
		jdbcTemplate.update(sql, ea.getValFlag(), schemeName, compId, condId);
	}

	@Override
	public void updatePoVflag(String schemeName, int compId, int condId, SchemePoMaster po) {
		String sql = "update DLP_SCM_PO_COND_CONFIG_STAGE set validity_flag=? where scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=?) and component_id=? AND condition_id=?";
		jdbcTemplate.update(sql, po.getValFlag(), schemeName, compId, condId);
		}

	@Override
	public void updateEaFilterVflag(String schemeName, int compId, int condId, int filtId, SchemeEaFilterCondMaster ea) {
		// TODO Auto-generated method stub
		String sql = "update DLP_SCM_EA_FLTR_COND_CNFG_STG set validity_flag = ? where " +
				"scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=?) and component_id=? and variable_id=? and variable_row_id=?";
		jdbcTemplate.update(sql, ea.getValFlag(), schemeName, compId, condId, filtId);
	}

	@Override
	public void updatePoFilterVflag(String schemeName, int compId, int condId,
			SchemePoAmtMaster po) {
		String sql = "update DLP_SCM_PO_AMT_CONFIG_STAGE set validity_flag = ? " +
				" where scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=?) and component_id=? and condition_id=?";
		jdbcTemplate.update(sql, po.getValFlag(), schemeName, compId, condId);
	}

	@Override
	public List<SchemeMaster> searchScheme(String Scheme) {
		// TODO Auto-generated method stub
		List<SchemeMaster> covList = new ArrayList<SchemeMaster>();
		try {
		String query = "select scheme_id,scheme_name from DLP_SCHEME_MASTER_STAGE where upper(scheme_name) like upper(?) order by update_date_time desc";
		 covList = jdbcTemplate.query(query, new Object[]{"%"+Scheme+"%"}, new RowMapper<SchemeMaster>() {
			@Override
			public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeMaster schemeMaster = new SchemeMaster();
				schemeMaster.setSchemeINputId(rs.getInt("scheme_id"));
				schemeMaster.setSchemeName(rs.getString("scheme_name"));
				return schemeMaster;
			}
		});
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || searchScheme || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return covList;
	}

	@Override
	public String getCircle(String schemeName) {
		// TODO Auto-generated method stub
		String query = "select Circle_name from DL_Circle_Config where circle_number=(select circle_id from DLP_SCHEME_MASTER where scheme_name = ? and validity_flag='Y')";
		   Object circle = jdbcTemplate.queryForObject(query, new Object[]{schemeName}, Object.class);	
		   return (String)circle;
	}

	@Override
	public boolean isFileUpload(String schemeName, int compId) {
		
		String query = "select coverage_flag from DLP_SCHEME_COMP_MAPPING comp where component_id = ? " +
				" AND scheme_id=(select scheme_id from DLP_SCHEME_MASTER where scheme_name = ? )";
		   Object coverage = jdbcTemplate.queryForObject(query, new Object[]{compId,schemeName},Object.class);	
	//	   return (String)circle;
	if(coverage!=null)
		return true;
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User getUserCircle(String userName) {
		// TODO Auto-generated method stub
		//	return null;
		//System.out.println("getUserCircle userName ::: "+userName);
		List<User> covList = new ArrayList<User>();
		if(userName!=null){
			//String query = "select cm.circle_number,cm.circle_code,cm.circle_name from dl_circle_config cm , dsm2_users du  where cm.circle_number = du.circle_id AND du.username='"+userName+"'";
			try {
				covList = jdbcTemplate.query(SchemeConfigQueries.USER_CIRCLE, new Object[]{userName}, new RowMapper<User>() {
				@Override
				public User mapRow(ResultSet rs, int rowNum) throws SQLException {
					User user = new User();
					user.setCircleId(rs.getInt("CIRCLE_NUMBER"));
					user.setUserCircleCode(rs.getString("CIRCLE_CODE"));
					user.setCircleName(rs.getString("CIRCLE_NAME"));
					//System.out.println("------"+rs.getString("CIRCLE_NAME"));
					return user;
				}

			});
			}catch(NullPointerException e) {
				System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || getUserCircle || Exception  ");
			}
			catch(Exception e){
				
				if(logger.isDebugEnabled()) {
				logger.error("Exception :: ",e);
				e.printStackTrace();
				}
			}
			//System.out.println("covList ::::size :  "+covList.size()+"\t covList"+covList);
			return covList.size()!=0 ? covList.get(0) : null;
		}
		return null;
	}

//	@Override
	private void updateSchemeFlag(String schemeName ,int circleId, int compId) {
		// TODO Auto-generated method stub
		try {
		String sql = "update dlp_scheme_comp_mapping_stage " +
				" set SCM_STATUS='W' "+
				" where " +
				" scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=? AND CIRCLE_ID=?) and "+
				" COMPONENT_ID =?";
		jdbcTemplate.update(sql,schemeName,circleId,compId);
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || updateSchemeFlag || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	}

	
	public String schemeUpdateOldToNew(SchemeMaster schemeMaster,String monthName){

		try{
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("SCHEME_UPDATE_OLD_TO_NEW");

			Map<String, Object> inParamMap = new HashMap<String, Object>();

			inParamMap.put("p_SCHEME_NAME_OLD", schemeMaster.getSchemeNameOld());

			inParamMap.put("p_SCHEME_NAME_NEW", schemeMaster.getSchemeName());

			inParamMap.put("P_CIRCLE_ID", schemeMaster.getCircleId());
			
			inParamMap.put("p_USERNAME", schemeMaster.getUserId());
			
			inParamMap.put("P_SCMMONTH", monthName);
			
			if(schemeMaster.getAutoCopyFlag()==null || "".equals(schemeMaster.getAutoCopyFlag()))
				schemeMaster.setAutoCopyFlag("N");
			if(schemeMaster.getAutoApprovalFlag()==null || "".equals(schemeMaster.getAutoApprovalFlag()))
				schemeMaster.setAutoApprovalFlag("N");
			
			inParamMap.put("p_COPYFLAG", schemeMaster.getAutoCopyFlag());
			
			inParamMap.put("p_AGREEMENTDATE", schemeMaster.getAggrementEndDate());
			
			inParamMap.put("p_APPROVALFLAG",schemeMaster.getAutoApprovalFlag());

			SqlParameterSource in = new MapSqlParameterSource(inParamMap);

			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);

			//System.out.println("size :: "+simpleJdbcCallResult.size()+"  empty :::: "+simpleJdbcCallResult.isEmpty()+"  *:::"+simpleJdbcCallResult);

			return simpleJdbcCallResult.toString();

		}catch(Exception e){
			e.printStackTrace();
		}
		return "Problem in Procedure.";
	}



	@Override
	public boolean eaVarNameVal(String eaVarName) {
		// TODO Auto-generated method stub
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
		String query="select count(ea.scheme_id) from DLP_SCM_EA_COND_CONFIG_stage ea where " +
				"ea.VARIABLE_NAME = ? AND ea.SCHEME_ID = (select scm.scheme_id from DLP_SCHEME_MASTER_STAGE scm where scm.scheme_name = ? AND scm.circle_id = ? )";
		@SuppressWarnings("deprecation")
		int row = jdbcTemplate.queryForInt(query, new Object[]{eaVarName, httpSession.getAttribute("schemeName").toString(), circleId});
		if(row == 0)
			return true;
		else
			return false;
	}



	@Override
	public void deleteExtraCov(int schemeId, int compId) {
		// TODO Auto-generated method stub
		String query = "delete from dlp_scm_co_cond_config_stage where  condition_row_id between (select min(condition_row_id)+1 from dlp_scm_co_cond_config_stage where scheme_id = ? and r_opr=26 and component_id = ?) and (select max(condition_row_id) from dlp_scm_co_cond_config_stage where scheme_id = ? and component_id = ?)";
		jdbcTemplate.update(query, schemeId,compId,schemeId,compId);
		//System.out.println("delte extra Cov  "+query);
	 //jdbcTemplate.execute(query);
	
	}



	@Override
	public String getCurrentScheme() {
		try{
			User user = (User)httpSession.getAttribute("appUser");
			//String query = "select last_working_scheme from dsm2_users where upper(username)='"+user.getUserName().toUpperCase()+"'";
			if(user!=null && user.getUserName()!=null)
				return jdbcTemplate.queryForObject(SchemeConfigQueries.USER_LAST_SCHEME,new Object[]{user.getUserName().toUpperCase()}, String.class);
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || getCurrentScheme || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return null;
	}

	
	@Override
	public int getSchemeId(String schemeName) {
		// TODO Auto-generated method stub
		
		int scmId = 0;
		try{
		if(schemeName!=null && "".equalsIgnoreCase(schemeName)){
		User user = (User)httpSession.getAttribute("appUser");
		//String query = "select  * from (select scheme_id from dlp_scheme_master_stage where scheme_name='"+schemeName+"' and circle_id="+user.getCircleId()+" and validity_flag ='Y' union all select scheme_id from dlp_scheme_master where scheme_name='"+schemeName+"' and validity_flag ='Y') where rownum=1";
		 scmId = jdbcTemplate.queryForObject(SchemeConfigQueries.SCHEME_ID,new Object[]{schemeName,user.getCircleId(),schemeName}, Integer.class);
		}
//	String query = "select last_working_scheme from dsm2_users where username='"+user.getUserName()+"'";
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || getSchemeId || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
	
	return scmId;
	}

	
	
	
	@Override
	public List<EntityAttributeMaster> getEaValueList() {
		// TODO Auto-generated method stub
		User user = (User)httpSession.getAttribute("appUser");
		//System.out.println("getEaValueList :: "+user.getCircleId());
		List<EntityAttributeMaster> enetityAttributeList = new ArrayList<EntityAttributeMaster>();
		try {
		String query="select ATTR_SEQ_NO,DISPLAY_NAME,attr_catg,attr_type,free_text_type_chk,operator_flag from dlp_tbl_entity_attr_mapping where validity_flag='Y' and entity_agg_flag='Y' and (CIRCLE_ID = ? or CIRCLE_ID is null)";
		 enetityAttributeList = jdbcTemplate.query(query,new Object[]{user.getCircleId()},new RowMapper<EntityAttributeMaster>() {
			@Override
			public EntityAttributeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				EntityAttributeMaster enetityAttributeMaster = new EntityAttributeMaster();
				enetityAttributeMaster.setEntityAttributeId(rs.getInt("ATTR_SEQ_NO"));
				enetityAttributeMaster.setEntityAttributeName(rs.getString("DISPLAY_NAME"));
				enetityAttributeMaster.setAttrCatg(rs.getInt("attr_catg"));
				enetityAttributeMaster.setAttrType(rs.getInt("attr_type"));
				enetityAttributeMaster.setFreeTextType(rs.getString("free_text_type_chk"));
				enetityAttributeMaster.setOperatorFlag(rs.getString("operator_flag"));
				return enetityAttributeMaster;
			}
		});
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || getSchemeId || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return enetityAttributeList;
	}

	@Override
	public int getCompCountFromMaster(String schemeName, int circleId) {
		// TODO Auto-generated method stub
		String query="select max(COMPONENT_ID) from DLP_SCHEME_COMP_MAPPING where " +
				"SCHEME_ID=(select SCHEME_ID from DLP_SCHEME_MASTER_STAGE where SCHEME_NAME = ? " +
						"AND CIRCLE_ID=?)";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query,new Object[]{schemeName,circleId});
		
		return row;
		
	}



	@Override
	public String copyPo(SchemePoMaster po) throws SQLException {
		// TODO Auto-generated method stub
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
		.withProcedureName("PAYOUT_COPY_PO");
			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put("pschemeId", po.getSchemeId());
			inParamMap.put("pcompId", po.getCompId());
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
			return simpleJdbcCallResult.get("P_OUT_MSG").toString();
			
	}



	@Override
	public void updateCovVflag(String schemeName, int compId, int condId, SchemeAcMaster addCov) {
		String sql = "update DLP_SCM_CO_COND_CONFIG_STAGE set validity_flag=? where scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name=?) AND component_id=? AND condition_id=?";
		try
		{
		jdbcTemplate.update(sql
				,addCov.getValFlag()
				,schemeName
				,compId
				,condId);
		}catch(Exception e)
		{
		}
	}

	public int getSchemeId(String schemeName, int circleId){
		//String query = "SELECT SCHEME_ID FROM DLP_SCHEME_MASTER_STAGE WHERE SCHEME_NAME = '"+schemeName+"' AND VALIDITY_FLAG='Y' AND CIRCLE_ID="+circleId;
		try{
			Integer schemeId = jdbcTemplate.queryForObject(SchemeConfigQueries.GET_SCHEME_ID, new Object[]{schemeName, circleId},  new RowMapper<Integer>() {
				@Override
				public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {
					return rs.getInt("SCHEME_ID");
				}
			});
			return schemeId;
		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || getSchemeId || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return 0;
	}

	@Override
	public String insertNewRowPo(SchemePoMaster po, String paramName) throws Exception {

		String rows[]=paramName.split(",");
		int updatedRowsCount=0;
		try {

				int compId = Integer.parseInt(rows[0]);
				int condId = Integer.parseInt(rows[1]);
				int condRowId = Integer.parseInt(rows[2]);

				String queryStrRowId = "select ltrim(rtrim(xmlagg(xmlelement(e, CONDITION_ROW_ID || ',')).extract('//text()'),','),',') AS CONDITION_ROW_ID " +
						" from DLP_SCM_PO_COND_CONFIG_STAGE where SCHEME_ID = ?   AND COMPONENT_ID = ?  and condition_id = ?  and validity_flag = 'Y' order by CONDITION_ROW_ID ";

				String queryCount = " select count(*) from DLP_SCM_PO_COND_CONFIG_STAGE where SCHEME_ID = ?  AND COMPONENT_ID = ?  and condition_id = ? and validity_flag = 'Y' ";

				String condiRowIdStr = null;
				try{
					condiRowIdStr = jdbcTemplate.queryForObject(queryStrRowId,  new Object[]{Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId, condId}, String.class);
				}catch(Exception e){
					e.printStackTrace();
				}
				int count = 0;
				try {
					String count1 = jdbcTemplate.queryForObject(queryCount, new Object[]{Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId, condId}, String.class);
					count = Integer.parseInt(count1);
				}catch(NullPointerException e) {
					System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || insertNewRowPo || Exception  ");
				}
				catch(Exception e){
					
					if(logger.isDebugEnabled()) {
					logger.error("Exception :: ",e);
					e.printStackTrace();
					}
				}

				if(po.getInsertEmptyRowType() == 2)
					condRowId = condRowId - 1;
				//System.out.println("condRowId ;;;;;; ::::: =====>>>> "+condRowId);
				if(condiRowIdStr!=null){
					String sql = " update DLP_SCM_PO_COND_CONFIG_STAGE set condition_row_id = ? where SCHEME_ID = ? AND COMPONENT_ID=? AND  condition_id = ? AND condition_row_id = ? ";
					for(int i = count; i > condRowId; i-- ){
						int z = i + 1;
						updatedRowsCount = jdbcTemplate.update(sql,new Object[]{z, Integer.valueOf(httpSession.getAttribute("schemeId").toString()), compId, condId, i });
					}
				}
				//System.out.println("updatedRowsCount ;;;;;; ::::: =====>>>> "+updatedRowsCount);
				if(updatedRowsCount==0){
					return "Not Updated";
				}

		}catch(NullPointerException e) {
			System.out.println("NullPointerException caught in SchemeInputAllDAOImpl || insertNewRowPo || Exception  ");
		}
		catch(Exception e){
			
			if(logger.isDebugEnabled()) {
			logger.error("Exception :: ",e);
			e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public void insertNewRowPo(SchemePoMaster po) throws Exception {
		SchemeInputAll schemeInput = new SchemeInputAll();
		po.setGrossNet("NULL");

		schemeInput.setSchemeInputPo(po);

		savePayoutCondMaster(schemeInput);
		
	}

	
	@Override
	public int insertMultiRowPo(String valueListName) throws Exception {
		//System.out.println("SchemeInputAllDAOImpl || insertMultiRowPo || paramName : "+valueListName);
		int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
		String rows[] = valueListName.split(":");

		int updatedRowsCount=0;
		boolean flag = true;
		int componentId = 0;
		int maxCondId = 0;
		int condiRowCount = 0;
		int conditionRowId = 0;
		int duplicate = 0;
		for(String eachRow:rows)
		{
			String eachVal[] = eachRow.split(",");
			int compoId = Integer.parseInt(eachVal[0]);
			int compId = Integer.parseInt(eachVal[1]);
			int condId = Integer.parseInt(eachVal[2]);
			int condRowId = Integer.parseInt(eachVal[3]);
			
			if(flag){
				componentId = compoId;
				maxCondId = getPOMaxConditionId(schemeId, compId);
				condiRowCount = getPOCondRowCount(schemeId, compId, maxCondId);
				if(condiRowCount == 0){
					conditionRowId = getPOCondRowId(schemeId, compId, maxCondId);
				}else{
					maxCondId = maxCondId + 1;
				}
				flag = false;
			}
			
			conditionRowId++;
			
			String insertQuery = "INSERT INTO DLP_SCM_PO_COND_CONFIG_STAGE (PROCESS_TYPE,SCHEME_ID,COMPONENT_ID,RE_CONFIG_ID,CONDITION_ID,CONDITION_ROW_ID,INPUT_TYPE,INPUT_PARAMETER," +
					"  OPR,VALUE_TYPE,VALUE,START_DATE,END_DATE,LOPR,VALIDITY_FLAG,UPDATE_DATE_TIME,INSERT_DATE_TIME)" +
					"  SELECT 'G','"+schemeId+"', '"+componentId+"','1','"+maxCondId+"','"+(conditionRowId)+"'," +
					"  INPUT_TYPE,INPUT_PARAMETER,OPR,VALUE_TYPE,VALUE,START_DATE,END_DATE,LOPR,'Y',SYSDATE,SYSDATE FROM DLP_SCM_PO_COND_CONFIG_STAGE" +
					"  WHERE SCHEME_ID = ?  AND  COMPONENT_ID = ?  AND  CONDITION_ID = ?  AND  CONDITION_ROW_ID = ?  AND  VALIDITY_FLAG = 'Y' ";
			
			
			String query = "select lopr from DLP_SCM_PO_COND_CONFIG_STAGE where scheme_id = ? and component_id = ? and condition_id = ? and condition_row_id = ?";
			@SuppressWarnings("deprecation")
			int lopr = jdbcTemplate.queryForInt(query, new Object[]{schemeId, compId, condId, condRowId});
			if((lopr == 26) || (lopr == 23) && duplicate==0)
			{
				String sql2 = "INSERT INTO DLP_SCM_PO_AMT_CONFIG_STAGE (PROCESS_TYPE,SCHEME_ID,COMPONENT_ID,RE_CONFIG_ID,CONDITION_ID,GROSS_NET,UNIT,AMOUNT,VARIABLE," +
						" OVER_ACHIEVEMENT,UNDER_ACHIEVEMENT,VALIDITY_FLAG,UPDATE_DATE_TIME,INSERT_DATE_TIME )" +
						" SELECT 'G','"+schemeId+"', '"+componentId+"','1','"+maxCondId+"',GROSS_NET,UNIT,AMOUNT,VARIABLE," +
						" OVER_ACHIEVEMENT,UNDER_ACHIEVEMENT,VALIDITY_FLAG,UPDATE_DATE_TIME,INSERT_DATE_TIME  FROM DLP_SCM_PO_AMT_CONFIG_STAGE  WHERE  SCHEME_ID =  ?  AND  COMPONENT_ID = ?  AND CONDITION_ID = ?  AND  VALIDITY_FLAG = 'Y' ";
				jdbcTemplate.update(sql2, new Object[]{schemeId, compId,condId});
				duplicate++;
			}
			updatedRowsCount = jdbcTemplate.update(insertQuery,	new Object[]{schemeId, compId, condId, condRowId});
		}
		if(updatedRowsCount!=0)
			return 1;
		else
			return 0;
	}

	
	private int getPOMaxConditionId(int schemeId, int compId) {
		String query="SELECT MAX(CONDITION_ID) FROM DLP_SCM_PO_COND_CONFIG_STAGE WHERE SCHEME_ID = ? AND COMPONENT_ID = ? AND VALIDITY_FLAG = 'Y' ";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeId, compId});
		return row;
	}
	
	private int getPOCondRowCount(int schemeId, int compId, int condid) {
		String query="SELECT COUNT(*) FROM DLP_SCM_PO_COND_CONFIG_STAGE  WHERE  SCHEME_ID = ?  AND  COMPONENT_ID = ?  AND  CONDITION_ID = ?  AND VALIDITY_FLAG = 'Y' AND  LOPR IN (23,26)";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeId, compId, condid});
		return row;
	}

	private int getPOCondRowId(int schemeId, int compId, int condid) {
		String query="SELECT MAX(CONDITION_ROW_ID) FROM DLP_SCM_PO_COND_CONFIG_STAGE WHERE SCHEME_ID = ?  AND  COMPONENT_ID = ?  AND  CONDITION_ID = ? AND VALIDITY_FLAG = 'Y'";
		@SuppressWarnings("deprecation")
		 int row = jdbcTemplate.queryForInt(query, new Object[]{schemeId, compId, condid});
		return row;
	}
	
}

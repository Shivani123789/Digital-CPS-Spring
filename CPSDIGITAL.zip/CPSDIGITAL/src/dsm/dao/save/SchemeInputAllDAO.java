package dsm.dao.save;

import java.sql.SQLException;
import java.util.List;

import dsm.model.DB.CompMaster;
import dsm.model.DB.RegZoneMaster;
import dsm.model.DB.RoprMaster;
import dsm.model.DB.SchemeAcMaster;
import dsm.model.DB.SchemeEaFilterCondMaster;
import dsm.model.DB.SchemeEaMaster;
import dsm.model.DB.SchemeInputAll;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemePoAmtMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.po.SchemePoMaster;
import dsm.model.user.User;

public interface SchemeInputAllDAO {

	public void SaveOrUpdate(SchemeInputAll schemeInput);
	
	public void deleteExtraCov(int schemeId,int compId);
	
	public User getUserCircle(String userName);

	public void savePayoutCondMasterRight(SchemeInputAll schemeInput);
	
	public void saveScheme(SchemeMaster schemeInput);
	
	public void deleteScheme(SchemeMaster schemeInput);
	
	public boolean isFileUpload(String schemeName,int compId);
	
	public int deleteComp(int schemeId,int compId);
	
	public void updateComp(int schemeId,int compId,CompMaster compInput);
	
	public void deleteRegZone(int regZoneId);
	
	public void updateRegZone(RegZoneMaster rzMaster);
	
	//public int deleteCov(String schemeName,int compId,int condId,int condRowId) throws Exception;
	
	public void updateCov(String schemeName,int compId,int condId,int condRowId,SchemeAcMaster addCov) throws Exception;

	//public int deleteTq(String schemeName,int compId,int condId,int condRowId);
	public int deleteTq(String schemeName,String paramName);
	public void updateTq(String schemeName,int compId,int condId,int condRowId,SchemeTqMaster tq);

	//public void deleteEa(String schemeName,int compId,int condId,int conRowId);
	public void deleteEa(String schemeName,String parameter);
	
	public void updateEa(String schemeName,int compId,int condId,int condRowId,SchemeEaMaster ea);
	
	public void updatePo(String schemeName,int compId,int condId,int condRowId,SchemePoMaster po) throws SQLException;
	
	public void deleteEaFilter(String schemeName,int compId,int condId,int filtId);
	
	public void updateEaFilter(String schemeName,int compId,int condId,int filtId,SchemeEaFilterCondMaster ea);
	
	public void updatePoFilterVflag(String schemeName,int compId,int condId,SchemePoAmtMaster po);
	
	public void updatePoVflag(String schemeName,int compId,int condId,SchemePoMaster po);
	
	public void updateEaVflag(String schemeName,int compId,int condId,SchemeEaMaster ea);
	
	public void updateEaFilterVflag(String schemeName,int compId,int condId,int filtId,SchemeEaFilterCondMaster ea);
	
	public void updateCovVflag(String schemeName,int compId,int condId,SchemeAcMaster addCov);
	
	public void updateRegZoneVflag(RegZoneMaster rzMaster);
	
	public void updateCompVflag(int schemeId,int compId,CompMaster compInput);
	
	public void updateTqVflag(String schemeName,int compId,int condId,SchemeTqMaster tq);
	
	public String saveComponenent(CompMaster compInput) throws Exception;
	
	public void saveRegion(RegZoneMaster regInput) throws Exception;
	
	public void saveAddCov(SchemeAcMaster addCov);
	
	public void saveTq(SchemeTqMaster tq);
	
	public String getCircle(String schemeName);
	
	public String getCurrentScheme();
	
	public void saveEa(SchemeEaMaster ea) throws SQLException;
	
	public void saveEaFilter(SchemeEaFilterCondMaster ea);
	
	public void savePo(SchemePoMaster po) throws SQLException;
	
	public String copyPo(SchemePoMaster po) throws SQLException;
	
	public void savePoFilter(SchemePoAmtMaster po) throws SQLException;
	
	public int getCompCount(String schemeName, int circleId);
	
	public int getCompCountFromMaster(String schemeName, int circleId);
	
	public int getTqCondCount(String schemeName ,int compId);
	
	public int getPoFiltersCount(String schemeName,int compId);
	
	public int getEaCondCount(String schemeName,int compId);
	
	public int getEaFilterCondCount(String schemeName,int varId,int compId);
	
	public List<SchemeMaster> searchScheme(String Scheme);
	
	public List<RegZoneMaster> getRegZone(String schemeName);
	
	public List<SchemeAcMaster> getCoverage(String schemeName) throws SQLException;
	
	public List<SchemeTqMaster> getTq(String schemeName);
	
	public List<SchemeEaMaster> getEa(String schemeName);
	
	public List<SchemeEaMaster> getEaVaraibles(String schemeName);
	
	public List<SchemePoMaster> getPoValues(String schemeName);
	
	public List<SchemeEaFilterCondMaster> getEaFilter(String schemeName);
	
	public List<SchemePoMaster> getPo(String schemeName);
	
	public 	List<SchemePoAmtMaster> getPoFilter(String schemeName);
	
	public List<RoprMaster> getRopr();
	
	public boolean schemeNameVal(String schemeName,int circleId);
	
	public boolean compNameVal(String compName);
	
	public boolean eaVarNameVal(String eaVarName);
	
	public String schemeUpdateOldToNew(SchemeMaster schemeMaster,String monthName);

	public int getTqCondRowCount(String schemeName, int condId,int compId);

	public int getPoFiltersRowCount(String schemeName, int condId,int compId);

	public List<EntityAttributeMaster> getEaValueList();

	public void savePayoutCondAmtMaster(SchemeInputAll schemeInput)	throws SQLException;

	public int getPoCondCount(String schemeName,int compId);

//	public int deletePoCond(String schemeName, int compId, int condId, int condRowId);
	public int deletePoCond(String schemeName, String valueListName);
	
	public int getcovCondCount(String schemeName, int compId);

	public int getcovCondRowCount(String schemeName, int condId, int compId);

	public int getSchemeId(String schemeName);

	public int getTqCondMaxCount(int compId);

	public void updatePoFilter(int schemeId, int compId, int condId, SchemePoMaster poFilter);

	public int getPoAmtCount(int compId, int condId);

	public int getSchemeId(String schemeName, int circleId);
	
	public int deleteCov(String schemeName,String coValueTypeName) throws Exception ;
	
	public String insertNewRowPo(SchemePoMaster po, String param) throws Exception;
	
	public void insertNewRowPo(SchemePoMaster po) throws Exception;
	
	public int insertMultiRowPo(String valueListName) throws Exception;
	
}

package dsm.dao.csv;

import java.util.List;

import dsm.model.DB.CPSPaymentVO;
import dsm.model.DB.CSVModelInput;
import dsm.model.DB.DistributorVO;
import dsm.model.DB.ExecPayoutStatusVO;
import dsm.model.DB.HierarchyMismatchCsvVO;
import dsm.model.DB.PayoutVO;
import dsm.model.DB.RetailerVO;
import dsm.model.report.ReportCsvDownload;

public interface CSVDAO {

	public List<RetailerVO> retailerCsv(CSVModelInput csvdata) throws Exception;
	
	public List<PayoutVO> payoutCsv(CSVModelInput csvdata) throws Exception;
	
	public List<DistributorVO> distributorCsv(CSVModelInput csvdata) throws Exception;
	
	public List<PayoutVO> testValidPayoutCsv(CSVModelInput csvdata) throws Exception;
	
	public List<RetailerVO> payoutRetailerCsv(CSVModelInput csvdata) throws Exception;
	
	public List<DistributorVO> payoutDistributorCsv(CSVModelInput csvdata) throws Exception;
	
	public List<ExecPayoutStatusVO> execPayoutStatusCsv(CSVModelInput csvdata) throws Exception;
	
	public List<HierarchyMismatchCsvVO> hierarchyMismatchCsv(CSVModelInput csvdata) throws Exception;
	
	public List<ReportCsvDownload> reportValidPayoutCsv(String csvdata) throws Exception;
	
	public List<CPSPaymentVO> payoutCPSCsv(CSVModelInput csvdata) throws Exception;
}

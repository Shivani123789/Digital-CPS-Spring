package dsm.dao.csv;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import dsm.dataBase.query.CSVQueries;
import dsm.model.DB.CPSPaymentVO;
import dsm.model.DB.CSVModelInput;
import dsm.model.DB.CpsMapMaster;
import dsm.model.DB.DistributorVO;
import dsm.model.DB.ExecPayoutStatusVO;
import dsm.model.DB.HierarchyMismatchCsvVO;
import dsm.model.DB.PayoutVO;
import dsm.model.DB.RetailerVO;
import dsm.model.report.ReportCsvDownload;


public class CSVDAOImpl implements CSVDAO{

	private JdbcTemplate jdbcTemplate;
	private NamedParameterJdbcTemplate namedParamJdbcTemplate;
	public CSVDAOImpl(){
	}

	public CSVDAOImpl(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
		namedParamJdbcTemplate = new NamedParameterJdbcTemplate(dataSource);
	}

	@Override
	public List<RetailerVO> retailerCsv(CSVModelInput csvdata) throws Exception{

		/*String RetailerQuery = "SELECT (SELECT A.PRIMARY_VTOPUP_NUM FROM DL_ENTITY_HIERARCHY_STAG A  "+
				" WHERE A.ENTITY_TYPE='Retailer' AND PRODUCER_ID=P.PRODUCER_ID AND ROWNUM=1) AS Retailer_MSISDN, "+
				" P.VTOPUP_AMOUNT AS Amount, "+
				" TO_CHAR(S.END_DATE,'MONYY')||'_'||'"+csvdata.getCircleCode()+"'||'_RET_SCH' AS Remarks "+
				" FROM DLP_SCHEME_COMP_MAPPING S,DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+" P "+
				" WHERE S.VALIDITY_FLAG = 'Y' AND S.START_DATE> = '"+csvdata.getFromDate()+"' AND S.END_DATE<= '"+csvdata.getToDate()+"'"+
				" AND S.SCHEME_ID=P.SCM_ID AND S.COMPONENT_ID=P.COMP_ID AND S.COMPONENT_VER=P.RE_CONFIG_ID "+
				" AND P.VALIDITY_FLAG = 'Y' AND S.VTOPUP_FILE_FLAG='Y' AND P.PAY_TO='Retailer' "+
				" AND S.SCHEME_ID = "+ csvdata.getSchemeId()+
				" ORDER BY P.SCM_ID,P.COMP_ID,P.RE_CONFIG_ID,P.PRODUCER_ID";*/
		String RetailerQuery = "SELECT (SELECT A.PRIMARY_VTOPUP_NUM FROM DL_ENTITY_HIERARCHY_STAG A  "+
				" WHERE A.ENTITY_TYPE='Retailer' AND PRODUCER_ID=P.PRODUCER_ID AND ROWNUM=1) AS Retailer_MSISDN, "+
				" P.VTOPUP_AMOUNT AS Amount, "+
				" TO_CHAR(S.END_DATE,'MONYY')||'_'||'"+csvdata.getCircleCode()+"'||'_RET_SCH' AS Remarks "+
				" FROM DLP_SCHEME_COMP_MAPPING S,DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+" P "+
				" WHERE S.VALIDITY_FLAG = 'Y' AND S.START_DATE> = ? AND S.END_DATE<= ? "+
				" AND S.SCHEME_ID=P.SCM_ID AND S.COMPONENT_ID=P.COMP_ID AND S.COMPONENT_VER=P.RE_CONFIG_ID "+
				" AND P.VALIDITY_FLAG = 'Y' AND S.VTOPUP_FILE_FLAG='Y' AND P.PAY_TO='Retailer' "+
				" AND S.SCHEME_ID = ? "+
				" ORDER BY P.SCM_ID,P.COMP_ID,P.RE_CONFIG_ID,P.PRODUCER_ID";
		List<RetailerVO> csvList = jdbcTemplate.query(RetailerQuery, new Object[]{csvdata.getFromDate(),csvdata.getToDate(),csvdata.getSchemeId()}, new RowMapper<RetailerVO>() {
			@Override
			public RetailerVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				RetailerVO retailer = new RetailerVO();
				retailer.setRetailerMsisd(rs.getString("Retailer_MSISDN"));
				retailer.setRemarks(rs.getString("Remarks"));
				retailer.setAmount(rs.getFloat("Amount"));
				return retailer;
			}
		});
		return csvList;
	}

	@Override
	public List<PayoutVO> payoutCsv(CSVModelInput csvdata) throws Exception
	{
		//System.out.println("download Payout");
		//System.out.println("Scheme_ID"+csvdata.getSchemeId());
		//System.out.println("Scheme_ID"+csvdata.getFromDate());
		//System.out.println("Scheme_ID"+csvdata.getToDate());
		/*String payoutQuery = "SELECT SP.SCM_NAME,SP.COMP_NAME,SP.PAY_TO,SP.PRODUCER_ID AS ENTITY_ID,SP.VARIABLE_VALUE AS PAY_NOS, "+
				" SP.GROSS_NET,SP.UNIT,ROUND(SP.GROSS_VALUE,2) AS GROSS_VALUE,ROUND(SP.NET_VALUE,2) AS NET_VALUE, "+
				" ROUND((SP.GROSS_VALUE-SP.NET_VALUE),2) AS TAX "+
				" FROM DLP_SCHEME_MASTER SM,DLP_SCHEME_COMP_MAPPING SC,DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+" SP "+
				" WHERE SM.VALIDITY_FLAG='Y' AND SM.SCHEME_ID=SC.SCHEME_ID AND SC.VALIDITY_FLAG='Y' "+
				" AND SC.START_DATE>= '"+csvdata.getFromDate()+"'  AND SM.CIRCLE_ID="+csvdata.getCircleId()+" AND SM.SCHEME_ID=SP.SCM_ID "+
				" AND SC.COMPONENT_ID=SP.COMP_ID AND SC.COMPONENT_VER=SP.RE_CONFIG_ID "+
				" AND SP.VALIDITY_FLAG='Y' AND TRUNC(SP.INSERT_DATE_TIME)= '"+csvdata.getToDate()+"'"+
				" AND SM.SCHEME_ID = "+ csvdata.getSchemeId()+
				" ORDER BY SP.SCM_ID,SP.COMP_ID,SP.RE_CONFIG_ID,SP.PAYOUT_COND_ID";*/

		String payoutQuery = "SELECT SP.SCM_NAME,SP.COMP_NAME,SP.PAY_TO,SP.PRODUCER_ID AS ENTITY_ID,SP.VARIABLE_VALUE AS PAY_NOS, "+
				" SP.GROSS_NET,SP.UNIT,ROUND(SP.GROSS_VALUE,2) AS GROSS_VALUE,ROUND(SP.NET_VALUE,2) AS NET_VALUE, "+
				" ROUND((SP.GROSS_VALUE-SP.NET_VALUE),2) AS TAX "+
				" FROM DLP_SCHEME_MASTER SM,DLP_SCHEME_COMP_MAPPING SC,DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+" SP "+
				" WHERE SM.VALIDITY_FLAG='Y' AND SM.SCHEME_ID=SC.SCHEME_ID AND SC.VALIDITY_FLAG='Y' "+
				" AND SC.START_DATE>= ?  AND SM.CIRCLE_ID= ? AND SM.SCHEME_ID=SP.SCM_ID "+
				" AND SC.COMPONENT_ID=SP.COMP_ID AND SC.COMPONENT_VER=SP.RE_CONFIG_ID "+
				" AND SP.VALIDITY_FLAG='Y' AND TRUNC(SP.INSERT_DATE_TIME)= ? "+
				" AND SM.SCHEME_ID = ? "+
				" ORDER BY SP.SCM_ID,SP.COMP_ID,SP.RE_CONFIG_ID,SP.PAYOUT_COND_ID";


		final String circleCode = csvdata.getCircleCode();

		//System.out.println(payoutQuery);
		List<PayoutVO> csvList = jdbcTemplate.query(payoutQuery, new Object[]{csvdata.getFromDate(),csvdata.getCircleId(),csvdata.getToDate(),csvdata.getSchemeId()}, new RowMapper<PayoutVO>() {
			@Override
			public PayoutVO mapRow(ResultSet rs,  int rowNum) throws SQLException {
				PayoutVO payout = new PayoutVO();
				payout.setCircleCode(circleCode);
				payout.setSchemeName(rs.getString("SCM_NAME"));
				payout.setComponentName(rs.getString("COMP_NAME"));
				payout.setPayTo(rs.getString("PAY_TO"));
				payout.setEntityId(rs.getString("ENTITY_ID"));
				payout.setPayNos(rs.getString("PAY_NOS"));
				payout.setGrossNet(rs.getString("GROSS_NET"));
				payout.setUnit(rs.getString("UNIT"));
				payout.setGrossValue(rs.getInt("GROSS_VALUE"));
				payout.setNetValue(rs.getFloat("NET_VALUE"));
				payout.setTax(rs.getFloat("TAX"));
				return payout;
			}
		});
		return csvList;
	}

	@Override
	public List<DistributorVO> distributorCsv(CSVModelInput csvdata) throws Exception{
		String distributorQuery = "SELECT (SELECT A.PRIMARY_VTOPUP_NUM FROM DL_ENTITY_HIERARCHY_STAG A "+
				" WHERE A.ENTITY_TYPE='Distributor' AND PRODUCER_ID=P.PRODUCER_ID AND ROWNUM=1) AS Distributor_MSISDN, "+
				" P.VTOPUP_AMOUNT AS Amount,  "+
				" TO_CHAR(S.END_DATE,'MONYY')||'_'||'"+csvdata.getCircleCode()+"'||'_DIST_SCH' AS Remarks "+
				" FROM DLP_SCHEME_COMP_MAPPING S,DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+"  P "+
				" WHERE S.VALIDITY_FLAG='Y' AND S.START_DATE >= ? AND S.END_DATE <= ? "+
				" AND S.SCHEME_ID=P.SCM_ID AND S.COMPONENT_ID=P.COMP_ID AND S.COMPONENT_VER=P.RE_CONFIG_ID "+
				" AND P.VALIDITY_FLAG='Y' AND S.VTOPUP_FILE_FLAG='Y' AND P.PAY_TO='Distributor' "+
				" AND S.SCHEME_ID= ? "+
				" ORDER BY P.SCM_ID,P.COMP_ID,P.RE_CONFIG_ID,P.PRODUCER_ID";

		List<DistributorVO> csvList = jdbcTemplate.query(distributorQuery, new Object[]{ csvdata.getFromDate(), csvdata.getToDate(),csvdata.getSchemeId()}, new RowMapper<DistributorVO>() {
			@Override
			public DistributorVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				DistributorVO distributor = new DistributorVO();
				distributor.setDistributorMsisd(rs.getString("Distributor_MSISDN"));
				distributor.setRemarks(rs.getString("Remarks"));
				distributor.setAmount(rs.getFloat("Amount"));
				return distributor;
			}
		});
		return csvList;
	}


	@Override
	public List<PayoutVO> testValidPayoutCsv(CSVModelInput csvdata) throws Exception
	{
		String payoutQuery;
		/*String payoutQuery = " SELECT SP.SCM_NAME,SP.COMP_NAME,SP.PAY_TO,SP.PRODUCER_ID AS ENTITY_ID,SP.VARIABLE_VALUE AS PAY_NOS,"+ 
				" SP.GROSS_NET,SP.UNIT,ROUND(SP.GROSS_VALUE,2) AS GROSS_VALUE,ROUND(SP.NET_VALUE,2) AS NET_VALUE, REGION_NAME, ZONE_NAME, "+
				" ROUND((SP.GROSS_VALUE-SP.NET_VALUE),2) AS TAX, SP.VTOPUP_NUMBER, SP.FTA_NUMBER, SP.ENTITY_NAME, SP.OVER_ACHIEVEMENT, SP.UNDER_ACHIEVEMENT "+
				" FROM DLP_SCHEME_MASTER SM,DLP_SCHEME_COMP_MAPPING SC,DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+" SP"+ 
				" where SM.VALIDITY_FLAG='Y' and SM.SCHEME_ID=SC.SCHEME_ID and SC.VALIDITY_FLAG='Y'"+ 
				" and SC.START_DATE >= '"+csvdata.getFromDate()+"'  "+
				" AND SC.END_DATE <= '"+csvdata.getToDate()+"'"+
				//" AND SM.CIRCLE_ID=SP.CIRCLE_ID " +
				" AND SM.SCHEME_ID=SP.SCM_ID"+ 
				" AND SC.COMPONENT_ID=SP.COMP_ID AND SC.COMPONENT_VER=SP.RE_CONFIG_ID"+ 
				" and SP.VALIDITY_FLAG='Y'  "+
				" and SM.CIRCLE_ID ="+csvdata.getCircleId()+
				" AND SM.SCHEME_ID = "+csvdata.getSchemeId()+
				" and SP.COMP_ID = "+csvdata.getCompId()+
				" and SC.SCM_STATUS='"+csvdata.getCompStatus()+"' AND SC.PAYOUT_STATUS='N'"+
				" ORDER BY SP.SCM_ID,SP.COMP_ID,SP.RE_CONFIG_ID,SP.PAYOUT_COND_ID";*/
		////System.out.println("CSVDAOImpl || testValidPayoutCsv || BEG "+csvdata.getCircleCode());
		if(!csvdata.getCircleCode().trim().equalsIgnoreCase("CU"))
		 payoutQuery = " SELECT SP.SCM_NAME,SP.COMP_NAME,SP.PAY_TO,SP.PRODUCER_ID AS ENTITY_ID,SP.VARIABLE_VALUE AS PAY_NOS,"+ 
				" SP.GROSS_NET,SP.UNIT,ROUND(SP.GROSS_VALUE,2) AS GROSS_VALUE,ROUND(SP.NET_VALUE,2) AS NET_VALUE, REGION_NAME, ZONE_NAME, "+
				" ROUND((SP.GROSS_VALUE-SP.NET_VALUE),2) AS TAX, SP.VTOPUP_NUMBER, SP.FTA_NUMBER, SP.ENTITY_NAME, SP.OVER_ACHIEVEMENT, SP.UNDER_ACHIEVEMENT "+
				" FROM DLP_SCHEME_MASTER SM,DLP_SCHEME_COMP_MAPPING SC,DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+" SP"+ 
				" where SM.VALIDITY_FLAG='Y' and SM.SCHEME_ID=SC.SCHEME_ID and SC.VALIDITY_FLAG='Y'"+ 
				" and SC.START_DATE >= ?  "+
				" AND SC.END_DATE <= ? "+
				//" AND SM.CIRCLE_ID=SP.CIRCLE_ID " +
				" AND SM.SCHEME_ID=SP.SCM_ID"+ 
				" AND SC.COMPONENT_ID=SP.COMP_ID AND SC.COMPONENT_VER=SP.RE_CONFIG_ID"+ 
				" and SP.VALIDITY_FLAG='Y'  "+
				" and SM.CIRCLE_ID = ? "+
				" AND SM.SCHEME_ID = ? "+
				" and SP.COMP_ID = ? "+
				" and SC.SCM_STATUS = ? AND SC.PAYOUT_STATUS='N'"+
				" ORDER BY SP.SCM_ID,SP.COMP_ID,SP.RE_CONFIG_ID,SP.PAYOUT_COND_ID";
		else
			 payoutQuery = " SELECT (SELECT CC.CIRCLE_CODE FROM DL_CIRCLE_CONFIG CC WHERE CC.CIRCLE_NUMBER=SP.CIRCLE_ID) CIRCLE_CODE,SP.SCM_NAME,SP.COMP_NAME,SP.PAY_TO,SP.PRODUCER_ID AS ENTITY_ID,SP.VARIABLE_VALUE AS PAY_NOS,"+ 
						" SP.GROSS_NET,SP.UNIT,ROUND(SP.GROSS_VALUE,2) AS GROSS_VALUE,ROUND(SP.NET_VALUE,2) AS NET_VALUE, REGION_NAME, ZONE_NAME, "+
						" ROUND((SP.GROSS_VALUE-SP.NET_VALUE),2) AS TAX, SP.VTOPUP_NUMBER, SP.FTA_NUMBER, SP.ENTITY_NAME, SP.OVER_ACHIEVEMENT, SP.UNDER_ACHIEVEMENT "+
						" FROM DLP_SCHEME_MASTER SM,DLP_SCHEME_COMP_MAPPING SC,DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+" SP"+ 
						" where SM.VALIDITY_FLAG='Y' and SM.SCHEME_ID=SC.SCHEME_ID and SC.VALIDITY_FLAG='Y'"+ 
						" and SC.START_DATE >= ?  "+
						" AND SC.END_DATE <= ? "+
						//" AND SM.CIRCLE_ID=SP.CIRCLE_ID " +
						" AND SM.SCHEME_ID=SP.SCM_ID"+ 
						" AND SC.COMPONENT_ID=SP.COMP_ID AND SC.COMPONENT_VER=SP.RE_CONFIG_ID"+ 
						" and SP.VALIDITY_FLAG='Y'  "+
						" and SM.CIRCLE_ID = ? "+
						" AND SM.SCHEME_ID = ? "+
						" and SP.COMP_ID = ? "+
						" and SC.SCM_STATUS = ? AND SC.PAYOUT_STATUS='N'"+
						" ORDER BY SP.SCM_ID,SP.COMP_ID,SP.RE_CONFIG_ID,SP.PAYOUT_COND_ID";
		
		final String circleCode = csvdata.getCircleCode();
		//System.out.println(payoutQuery);
		List<PayoutVO> csvList = jdbcTemplate.query(payoutQuery, new Object[]{csvdata.getFromDate(),csvdata.getToDate(),csvdata.getCircleId(),csvdata.getSchemeId(),csvdata.getCompId(),csvdata.getCompStatus()}, new RowMapper<PayoutVO>() {
			@Override
			public PayoutVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				PayoutVO payout = new PayoutVO();
				if(circleCode.equalsIgnoreCase("CU"))
					payout.setCircleCode(rs.getString("CIRCLE_CODE"));
				else
				payout.setCircleCode(circleCode);
				payout.setSchemeName(rs.getString("SCM_NAME"));
				payout.setComponentName(rs.getString("COMP_NAME"));
				payout.setPayTo(rs.getString("PAY_TO"));
				payout.setEntityId(rs.getString("ENTITY_ID"));
				payout.setPayNos(rs.getString("PAY_NOS"));
				payout.setGrossNet(rs.getString("GROSS_NET"));
				payout.setUnit(rs.getString("UNIT"));
				payout.setGrossValue(rs.getInt("GROSS_VALUE"));
				payout.setNetValue(rs.getFloat("NET_VALUE"));
				payout.setTax(rs.getFloat("TAX"));
				payout.setVtopUpNumber(rs.getString("VTOPUP_NUMBER"));
				payout.setFtaNumber(rs.getString("FTA_NUMBER"));
				payout.setEntityName(rs.getString("ENTITY_NAME"));
				payout.setUnderAchieveStr(rs.getString("UNDER_ACHIEVEMENT"));
				payout.setOverAchieveStr(rs.getString("OVER_ACHIEVEMENT"));
				payout.setRegion(rs.getString("REGION_NAME"));
				payout.setZone(rs.getString("ZONE_NAME"));
				
				return payout;
			}
		});
		return csvList;
	}


	@Override
	public List<RetailerVO> payoutRetailerCsv(CSVModelInput csvdata) throws Exception{

		String partition = getPartition(Integer.parseInt(csvdata.getSchemeId()), csvdata.getCompId());

		/*String query =	"SELECT B.PRIMARY_VTOPUPNO AS Retailer_MSISDN,"+
				" T.VTOPUP_AMOUNT AS Amount,"+
				" TO_CHAR(TO_DATE(T.SCM_END_DATE, 'DD-MON-YYYY'), 'MONYY') || '_' ||"+
				" '"+csvdata.getCircleCode()+"' || '_RET_SCH' AS Remarks, T.REGION_NAME, T.ZONE_NAME"+
				" FROM DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+"           T,"+
				" DLP_PAYOUT_HIER_DSM1_TEMP PARTITION("+partition+") B"+
				" WHERE B.CIRCLE = '"+csvdata.getCircleCode()+"'"+
				" AND T.PAY_TO = B.ENTITY_TYPE"+
				" AND T.PRODUCER_ID = B.PRODUCER_ID"+
				" AND B.IPS_MOVEMENT_FLAG = 'Y'"+
				" AND T.VALIDITY_FLAG = 'Y'"+
				//" AND T.CIRCLE_CODE = '"+csvdata.getCircleCode()+"'"+
				" AND T.SCM_ID ="+csvdata.getSchemeId()+
				" AND T.COMP_ID ="+csvdata.getCompId();*/

		String query =	"SELECT B.PRIMARY_VTOPUPNO AS Retailer_MSISDN,"+
				" T.VTOPUP_AMOUNT AS Amount,"+
				" TO_CHAR(TO_DATE(T.SCM_END_DATE, 'DD-MON-YYYY'), 'MONYY') || '_' ||"+
				" '"+csvdata.getCircleCode()+"' || '_RET_SCH' AS Remarks, T.REGION_NAME, T.ZONE_NAME"+
				" FROM DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+"           T,"+
				" DLP_PAYOUT_HIER_DSM1_TEMP PARTITION("+partition+") B"+
				" WHERE B.CIRCLE = ? "+
				" AND T.PAY_TO = B.ENTITY_TYPE"+
				" AND T.PRODUCER_ID = B.PRODUCER_ID"+
				" AND B.IPS_MOVEMENT_FLAG = 'Y'"+
				" AND T.VALIDITY_FLAG = 'Y'"+
				//" AND T.CIRCLE_CODE = '"+csvdata.getCircleCode()+"'"+
				" AND T.SCM_ID = ? "+
				" AND T.COMP_ID = ?";
		
		List<RetailerVO> csvList = jdbcTemplate.query(query, new Object[]{csvdata.getCircleCode(),csvdata.getSchemeId(),csvdata.getCompId()}, new RowMapper<RetailerVO>() {
			@Override
			public RetailerVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				RetailerVO retailer = new RetailerVO();
				retailer.setRetailerMsisd(rs.getString("Retailer_MSISDN"));
				retailer.setRemarks(rs.getString("Remarks"));
				retailer.setAmount(rs.getFloat("Amount"));
				retailer.setRegion(rs.getString("REGION_NAME"));
				retailer.setZone(rs.getString("ZONE_NAME"));
				
				return retailer;
			}
		});
		return csvList;
	}


	@Override
	public List<DistributorVO> payoutDistributorCsv(CSVModelInput csvdata) throws Exception{
		String partition = getPartition(Integer.parseInt(csvdata.getSchemeId()), csvdata.getCompId());
/*		String query =	"SELECT B.PRIMARY_VTOPUPNO AS Distributor_MSISDN,"+
				" T.VTOPUP_AMOUNT AS Amount,"+
				" TO_CHAR(TO_DATE(T.SCM_END_DATE, 'DD-MON-YYYY'), 'MONYY') || '_' ||"+
				" '"+csvdata.getCircleCode()+"' || '_DIST_SCH' AS Remarks, T.REGION_NAME, T.ZONE_NAME"+
				" FROM DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+"           T,"+
				" DLP_PAYOUT_HIER_DSM1_TEMP PARTITION("+partition+") B"+
				//" WHERE T.CIRCLE_CODE = B.CIRCLE"+
				" WHERE B.CIRCLE = "+csvdata.getCircleCode()+
				" AND T.PAY_TO = B.ENTITY_TYPE"+
				" AND T.PRODUCER_ID = B.PRODUCER_ID"+
				" AND B.IPS_MOVEMENT_FLAG = 'Y'"+
				" AND T.VALIDITY_FLAG = 'Y'"+
			//	" AND T.CIRCLE_CODE = '"+csvdata.getCircleCode()+"'"+
				" AND T.SCM_ID ="+csvdata.getSchemeId()+
				" AND T.COMP_ID ="+csvdata.getCompId();
*/
		String query =	"SELECT B.PRIMARY_VTOPUPNO AS Distributor_MSISDN,"+
				" T.VTOPUP_AMOUNT AS Amount,"+
				" TO_CHAR(TO_DATE(T.SCM_END_DATE, 'DD-MON-YYYY'), 'MONYY') || '_' ||"+
				" '"+csvdata.getCircleCode()+"' || '_DIST_SCH' AS Remarks, T.REGION_NAME, T.ZONE_NAME"+
				" FROM DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+"           T,"+
				" DLP_PAYOUT_HIER_DSM1_TEMP PARTITION("+partition+") B"+
				//" WHERE T.CIRCLE_CODE = B.CIRCLE"+
				" WHERE B.CIRCLE = ? "+
				" AND T.PAY_TO = B.ENTITY_TYPE"+
				" AND T.PRODUCER_ID = B.PRODUCER_ID"+
				" AND B.IPS_MOVEMENT_FLAG = 'Y'"+
				" AND T.VALIDITY_FLAG = 'Y'"+
			//	" AND T.CIRCLE_CODE = '"+csvdata.getCircleCode()+"'"+
				" AND T.SCM_ID = ? "+
				" AND T.COMP_ID = ?";

		List<DistributorVO> csvList = jdbcTemplate.query(query, new Object[]{csvdata.getCircleCode(),csvdata.getSchemeId(),csvdata.getCompId()}, new RowMapper<DistributorVO>() {
			@Override
			public DistributorVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				DistributorVO distributor = new DistributorVO();
				distributor.setDistributorMsisd(rs.getString("Distributor_MSISDN"));
				distributor.setRemarks(rs.getString("Remarks"));
				distributor.setAmount(rs.getFloat("Amount"));
				distributor.setRegion(rs.getString("REGION_NAME"));
				distributor.setZone(rs.getString("ZONE_NAME"));
				
				return distributor;
			}
		});
		return csvList;
	}


	private String getPartition(int schemeId,int compId) throws Exception{
		String sql= "SELECT 'PAR_' || TO_CHAR(END_DATE, 'MON_YYYY_DD')" +
				" FROM DLP_SCHEME_COMP_MAPPING T WHERE T.VALIDITY_FLAG = 'Y'" +
				" AND T.SCHEME_ID = ? AND T.COMPONENT_ID = ?";
		String partition = jdbcTemplate.queryForObject(sql, new Object[]{schemeId,compId},String.class);
		//System.out.println("getPartition :: "+partition);
		return partition;
	}


	
	
	@Override
	public List<ExecPayoutStatusVO> execPayoutStatusCsv(CSVModelInput csvdata) throws Exception{

		SqlParameterSource parameters = new MapSqlParameterSource().addValue("circleId", csvdata.getCircleId()).addValue("startDate", csvdata.getFromDate()).addValue("endDate", csvdata.getToDate());
		List<ExecPayoutStatusVO> csvList = namedParamJdbcTemplate.query(CSVQueries.DL_PAYOUT_STATUS_CSV, parameters, new RowMapper<ExecPayoutStatusVO>() {
			@Override
			public ExecPayoutStatusVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				ExecPayoutStatusVO payout = new ExecPayoutStatusVO();
				payout.setCircleName(rs.getString("CIRCLE_NAME"));
				payout.setSchemeId(rs.getInt("SCM_ID"));
				payout.setCompId(rs.getInt("COMP_ID"));
				payout.setSchemeName(rs.getString("SCHEME_NAME"));
				payout.setCompName(rs.getString("COMPONENET_NAME"));
				payout.setConfigId(rs.getInt("CONFIG_ID"));
				payout.setConVarId(rs.getInt("CON_VAR_ID"));
				payout.setConfigTypeId(rs.getInt("CONFIG_TYPE_ID"));
				payout.setTableId(rs.getInt("TABLE_ID"));
				payout.setTableName(rs.getString("TABLE_NAME"));
				payout.setStartDT(rs.getString("START_TIME"));
				payout.setEndDT(rs.getString("END_TIME"));
				return payout;
			}
		});
		return csvList;
	}

	@Override
	public List<HierarchyMismatchCsvVO> hierarchyMismatchCsv(CSVModelInput csvdata) throws Exception{
		try{
			List<HierarchyMismatchCsvVO> csvList = jdbcTemplate.query(CSVQueries.HIERARCHY_MISMATCH, new Object[]{csvdata.getCircleCode(),csvdata.getToDate(),csvdata.getCsvType()}, new RowMapper<HierarchyMismatchCsvVO>() {
				@Override
				public HierarchyMismatchCsvVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					HierarchyMismatchCsvVO mismatch = new HierarchyMismatchCsvVO();
					mismatch.setCircle(rs.getString("CIRCLE"));
					mismatch.setHierDt(rs.getString("HIERARCHY_DATE"));
					mismatch.setSystemInvolved(rs.getString("SystemS_INVOLVED"));
					mismatch.setEntityType(rs.getString("ENTITY_TYPE"));
					mismatch.setMobileNo(rs.getString("MOBILE_NUMBER"));
					mismatch.setFirstSysMgr(rs.getString("FIRST_SYS_MGR"));
					mismatch.setSecondSysMgr(rs.getString("SECOND_SYS_MGR"));
					mismatch.setRemarks(rs.getString("REMARKS"));
					return mismatch;
				}
			});
			return csvList;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	public List<ReportCsvDownload> reportValidPayoutCsv(String csvdata) throws Exception
	{
		//System.out.println("CSVDAOImpl || reportValidPayoutCsv || BEG:"+csvdata);
		List<ReportCsvDownload> csvList=jdbcTemplate.query(csvdata, new RowMapper<ReportCsvDownload>(){
			@Override
			public ReportCsvDownload mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReportCsvDownload records = new ReportCsvDownload();
				records.setVal1(rs.getString(1));
				records.setVal2(rs.getString(2));
				records.setVal3(rs.getString(3));
				records.setVal4(rs.getString(4));
				records.setVal5(rs.getString(5));
				return records;
			}	
		});
		return csvList;
	}
	
	
	
	@Override
	public List<CPSPaymentVO> payoutCPSCsv(CSVModelInput csvdata) throws Exception{
		String partition = getPartition(Integer.parseInt(csvdata.getSchemeId()), csvdata.getCompId());
		CpsMapMaster mapMaster = payoutCPSMapMaster("CORE");
		String query =	"SELECT T.PRODUCER_ID, T.ENTITY_NAME,  T.VTOPUP_AMOUNT AS Amount,"+
				" TO_CHAR(TO_DATE(T.SCM_END_DATE, 'DD-MON-YYYY'), 'MONYY') || '_' ||"+
				" '"+csvdata.getCircleCode()+"' || '_"+csvdata.getCsvType()+"_SCH' AS Remarks,  B.CONTACT_NUMBER, T.REGION_NAME, T.ZONE_NAME"+
				" FROM DLP_SCM_PAYOUT_"+csvdata.getCircleCode()+"           T,  "+
					mapMaster.getMapTableName()+"   B"+ //PARTITION("+partition+")
				" WHERE B.CIRCLE = ? "+
				" AND T.PAY_TO = B.ENTITY_TYPE"+
				" AND T.PRODUCER_ID = B.PRODUCER_ID"+
				" AND B.IPS_MOVEMENT_FLAG = 'Y'"+
				" AND T.VALIDITY_FLAG = 'Y'"+
				" AND T.SCM_ID = ? "+
				" AND T.COMP_ID = ?";
		
		List<CPSPaymentVO> csvList = jdbcTemplate.query(query, new Object[]{csvdata.getCircleCode(),csvdata.getSchemeId(),csvdata.getCompId()}, new RowMapper<CPSPaymentVO>() {
			@Override
			public CPSPaymentVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				CPSPaymentVO cps = new CPSPaymentVO();
				cps.setProducerId(rs.getString("PRODUCER_ID"));
				cps.setEntityName(rs.getString("ENTITY_NAME"));
				cps.setRemarks(rs.getString("Remarks"));
				cps.setAmount(rs.getFloat("Amount"));
				cps.setContactNumber(rs.getString("CONTACT_NUMBER"));
				cps.setRegion(rs.getString("REGION_NAME"));
				cps.setZone(rs.getString("ZONE_NAME"));
				return cps;
			}
		});
		return csvList;
	}
	
	
	private CpsMapMaster payoutCPSMapMaster(String categoryType) {
		String query =	"select MAP_ID, MAP_DESCRIPTION, CATEGORY, MAP_TABLE_NAME, System_ID from DLP_MAP_MASTER where category = ?";
		CpsMapMaster holdDataList = jdbcTemplate.queryForObject(query,new Object[]{categoryType}, new RowMapper<CpsMapMaster>() {
			@Override
			public CpsMapMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CpsMapMaster scmPay = new CpsMapMaster();
				scmPay.setMapId(rs.getInt("MAP_ID"));
				scmPay.setMapDescription(rs.getString("MAP_DESCRIPTION"));
				scmPay.setCategory(rs.getString("CATEGORY"));
				scmPay.setMapTableName(rs.getString("MAP_TABLE_NAME"));
				scmPay.setSystemId(rs.getInt("System_ID"));
				return scmPay;
			}
		});
		return holdDataList;
	}
	
}

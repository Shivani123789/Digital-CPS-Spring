package dsm.dao.bulk;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFFormulaEvaluator;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import dsm.dataBase.query.BulkQueries;
import dsm.model.DB.ExceptionVo;
import dsm.model.DB.MappingTableFields;
import dsm.model.DB.SchemeBulkColumnVo;
import dsm.model.DB.SchemeBulkLoadConfVo;
import dsm.model.form.BulkComponentMasterStore;
import dsm.model.form.BulkLoadFileStatus;
import dsm.model.form.BulkSchemeMasterStore;
import dsm.model.form.DocTypeList;
import dsm.model.form.DocUploadFile;
import dsm.model.form.UploadMailStatusData;
import dsm.module.constant.BulkConstants;

public class BulkUploadDAOImpl implements BulkUploadDAO{

	private JdbcTemplate jdbcTemplate;
	
	/*@Autowired
	private HttpSession httpSession;
*/

	private static Logger logger = Logger.getLogger (BulkUploadDAOImpl.class);

	public BulkUploadDAOImpl(){

	}

	public BulkUploadDAOImpl(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}


	@Override
	public List<BulkSchemeMasterStore> getBulkSchemeMasterStore(String fileName, int circleId)  throws Exception{
		// TODO Auto-generated method stub
		//String query="select SCHEME_ID,SCHEME_NAME from DLP_SCHEME_MASTER where VALIDITY_FLAG='Y' AND CIRCLE_ID = "+circleId+"ORDER BY INSERT_DATE_TIME DESC";
		String query = "select CM.SCHEME_ID,SM.SCHEME_NAME, CM.COMPONENT_ID,CM.COMPONENET_NAME,CM.FILE_NAME,CM.PAY_TO from DLP_SCHEME_COMP_MAPPING CM, DLP_SCHEME_MASTER SM" +
				" where CM.FILE_NAME like '%"+fileName+"'" +
				" and SM.CIRCLE_ID = "+circleId+
				" and CM.PAY_TO like '%%'" +
				" and CM.SCHEME_ID = SM.SCHEME_ID and CM.VALIDITY_FLAG = SM.VALIDITY_FLAG AND cm.VALIDITY_FLAG='Y' ORDER BY cm.INSERT_DATE_TIME DESC";
		//logger.debug("BulkSchemeMasterStore query :::: "+query);
		List<BulkSchemeMasterStore> schemeList = jdbcTemplate.query(query, new RowMapper<BulkSchemeMasterStore>() {
			@Override
			public BulkSchemeMasterStore mapRow(ResultSet rs, int rowNum) throws SQLException {
				BulkSchemeMasterStore schemeMaster = new BulkSchemeMasterStore();
				schemeMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				schemeMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				return schemeMaster;
			}
		});
		return schemeList;
	}

	@Override
	public List<BulkComponentMasterStore> getBulkComponentMasterStore(String fileName, int circleId) throws Exception {
		// TODO Auto-generated method stub
		//String query="SELECT cm.SCHEME_ID,cm.COMPONENT_ID,cm.COMPONENET_NAME FROM DLP_SCHEME_COMP_MAPPING cm, DLP_SCHEME_MASTER sm WHERE cm.SCHEME_ID=sm.SCHEME_ID AND cm.VALIDITY_FLAG=sm.VALIDITY_FLAG AND cm.VALIDITY_FLAG='Y' ORDER BY cm.INSERT_DATE_TIME DESC";
		String query = "select CM.SCHEME_ID,SM.SCHEME_NAME, CM.COMPONENT_ID,CM.COMPONENET_NAME,CM.FILE_NAME,CM.PAY_TO from DLP_SCHEME_COMP_MAPPING CM, DLP_SCHEME_MASTER SM" +
				" where CM.FILE_NAME like '%"+fileName+"'" +
				" and SM.CIRCLE_ID = "+circleId+
				" and CM.PAY_TO like '%%'" +
				" and CM.SCHEME_ID = SM.SCHEME_ID and CM.VALIDITY_FLAG = SM.VALIDITY_FLAG AND cm.VALIDITY_FLAG='Y' ORDER BY cm.INSERT_DATE_TIME DESC";
		
		//logger.debug("BulkComponentMasterStore query :::: "+query);
		List<BulkComponentMasterStore> schemeList = jdbcTemplate.query(query, new RowMapper<BulkComponentMasterStore>() {
			@Override
			public BulkComponentMasterStore mapRow(ResultSet rs, int rowNum) throws SQLException {
				BulkComponentMasterStore schemeMaster = new BulkComponentMasterStore();
				schemeMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				schemeMaster.setComponentId(rs.getInt("COMPONENT_ID"));
				schemeMaster.setComponentName(rs.getString("COMPONENET_NAME"));
				return schemeMaster;
			}

		});
		return schemeList;
	}



	
	
	///New Rebuilt BulkUpload Code 
	@Override
	public List<SchemeBulkLoadConfVo> getSchemBulkConfDataNew(int file_id)  throws Exception{

		logger.debug("Entered into getSchemBulkConfData() method");
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet result = null;
		List<SchemeBulkLoadConfVo> schemBulkLoadConfList = null;
		try {
			connection = jdbcTemplate.getDataSource().getConnection();
			ps = connection.prepareStatement(BulkQueries.SCHEME_BULK_LOAD_CONF_TEMP);
			ps.setInt(1, file_id);
			result = ps.executeQuery();
			schemBulkLoadConfList = new ArrayList<SchemeBulkLoadConfVo>();
			
			while (result.next()) {
				SchemeBulkLoadConfVo schemeBulkLoad = new SchemeBulkLoadConfVo();
				
				schemeBulkLoad.setConfName(result.getString("CONF_NAME"));
				schemeBulkLoad.setSheetName(result.getString("SHEET_NAME"));
				schemeBulkLoad.setSheetNum(result.getInt("SHEET_NUM"));
				schemeBulkLoad.setProcedureName(result.getString("PROCEDURE_NAME"));
				schemeBulkLoad.setColReadCount(result.getInt("COL_READ_COUNT"));
				schemeBulkLoad.setFileId(result.getInt("FILE_ID"));
				schemeBulkLoad.setHeaderRows(result.getInt("HEADER_ROWS"));
				schemeBulkLoad.setLoadingMethod(result.getString("LOADING_METHOD"));
				schemeBulkLoad.setMappingTable(result.getString("MAPPING_TABLE"));
				schemeBulkLoad.setMappingTableConnectionPool(result.getString("MAPPING_TABLE_CONNECTION_POOL"));
				schemeBulkLoad.setMappingFieldHeaderName(result.getString("MAPPING_FIELD_HEADER_NAME"));
				schemeBulkLoad.setMappingFieldName(result.getString("MAPPING_FIELD_NAME"));
				schemeBulkLoad.setDestinationTable(result.getString("DESTINATION_TABLE_NAME"));
				schemeBulkLoad.setType(result.getString("TYPE"));
				schemeBulkLoad.setFeedNumber(result.getString("FEED_NUMBER"));
				schemeBulkLoad.setFeedMapping(result.getString("FEED_MAPPING"));
				
				schemeBulkLoad.setCellValue(getBulkLoadColumnListNew(connection,(result.getInt("FILE_ID")==1?result.getInt("SHEET_NUM"):999999),(result.getInt("FILE_ID")==1?result.getInt("FILE_ID"):0)));
				
				schemBulkLoadConfList.add(schemeBulkLoad);
			}logger.debug("End getSchemBulkConfData() method");
			
		}catch(SQLException e) {
			SchemeBulkLoadConfVo error = new SchemeBulkLoadConfVo();
			error.setErrorFlag(true);
			if(e.getMessage().toLowerCase().contains("Closed Connection".toLowerCase())){
				error.setErrorCode("Closed Connection");
				error.setErrorDescription("Please try after sometime Database is down or Contact Database admin.");
				logger.debug("Closed Connection");
				schemBulkLoadConfList.add(error);
			}else
				error.setErrorDescription("Internal Problem. Please try after sometime.");
			logger.error("SQLException :: ", e);
		}catch(NullPointerException e){
			SchemeBulkLoadConfVo error = new SchemeBulkLoadConfVo();
			error.setErrorFlag(true);
			error.setErrorDescription("Internal Problem. Please try after sometime.");
			logger.error("NullException :: ", e);
		}catch(Exception e){
			SchemeBulkLoadConfVo error = new SchemeBulkLoadConfVo();
			error.setErrorFlag(true);
			error.setErrorDescription("Internal Problem. Please try after sometime.");
			logger.error("Exception :: ", e);
		}finally{
			try {
				if(result!=null)
					result.close();
				if(ps!=null)
					ps.close();
				if(connection!=null)
					connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return schemBulkLoadConfList;
	}

	private List<SchemeBulkColumnVo> getBulkLoadColumnListNew(Connection connection, int sheetNum, int fileId) throws SQLException,Exception {
		logger.debug("Entered into getBulkLoadColumnList() method");
		
		PreparedStatement ps = null;
		ResultSet result = null;
		List<SchemeBulkColumnVo> bulkColumnList = null;
		try {
			ps = connection.prepareStatement(BulkQueries.SCHEME_BULK_COLUMN_TEMP);
			ps.setInt(1, sheetNum);
			ps.setInt(2, fileId);
			result = ps.executeQuery();
			bulkColumnList = new ArrayList<SchemeBulkColumnVo>();
			while (result.next()) {
				SchemeBulkColumnVo bulkColumnVo = new SchemeBulkColumnVo();
				bulkColumnVo.setSheetNum(result.getInt("SHEET_NUM"));
				bulkColumnVo.setCellName(result.getString("CELL_NAME"));
				bulkColumnVo.setCellNum(result.getInt("CELL_NUM"));
				bulkColumnVo.setCellType(result.getString("CELL_TYPE"));
				bulkColumnVo.setDbDataType(result.getString("DB_DATA_TYPE"));
				bulkColumnVo.setFileId(result.getInt("FILE_ID"));
				bulkColumnVo.setDbColumnName(result.getString("DB_COLUMN_NAME"));
				bulkColumnList.add(bulkColumnVo);
			}logger.debug("End getBulkLoadColumnList() method");
			
		} catch (SQLException e) {
			throw e;
		}catch (Exception e) {
			throw e;
		}
		finally{
			try {
				if(result!=null)
					result.close();
				if(ps!=null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return bulkColumnList;
	}

	
/*	private List<MappingTableFields> getDestTableColumnValueNew(String fileHeaderName,String type) throws Exception{
		logger.debug("Enter into getDestTableColumnValue() method");
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet result =null;
		List<MappingTableFields> mtf =null;
		String[] str = fileHeaderName.split(Constant.COMMA);
		StringBuffer questionMarks=new StringBuffer();
		for(int i=0;i<str.length;i++){
			if(i!=0 && i!=str.length)
				questionMarks.append(",");
			questionMarks.append("?");
		}
		logger.debug(questionMarks);
		try{
			connection = ConnectionUtility.getInstance().getLocalConnection();
			String query = "SELECT A.FIELD_NAME FIELD_NAME,A.DISPLAY_NAME DISPLAY_NAME,A.TYPE, A.TABLE_NAME, A.COLUMN_NAME, COUNT(*) OVER(PARTITION BY 1) CNT FROM DLP_TBL_ADD_FIELDS_CONFIG A WHERE DISPLAY_NAME IN("+questionMarks+") AND TYPE=?";
			ps = connection.prepareStatement(query);
			for(int i=0;i<str.length;i++){
			ps.setString(i, str[i].trim());
			}
			ps.setString(str.length+1, type);
			result = ps.executeQuery();
			mtf = new ArrayList<MappingTableFields>();
			while(result.next()){
				MappingTableFields mappingFields = new MappingTableFields();
				mappingFields.setFieldName(result.getString("FIELD_NAME"));
				mappingFields.setDisplayName(result.getString("DISPLAY_NAME"));
				mappingFields.setType(result.getString("TYPE"));
				mappingFields.setTableName(result.getString("TABLE_NAME"));
				mappingFields.setColumnName(result.getString("COLUMN_NAME"));
				mappingFields.setFieldCount(result.getInt("CNT"));
				mtf.add(mappingFields);
			}logger.debug("End getDestTableColumnValue() method");
			return mtf;
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(result != null)
				result.close();
			if(ps!=null)
				ps.close();
			connection.close();
		}
		return null;
	}
	*/
	@Override
	public MappingTableFields getDestTabColValueNew(String fileHeaderName, String type, int circleId) throws Exception{
		logger.debug("Enter into getDestTabColValue() method");
		Connection connection = null;
		PreparedStatement ps = null;
		PreparedStatement mandatoryPs = null;
		ResultSet result = null;
		MappingTableFields mtf = null;
		Map<String,String> map = null;
		boolean flag = true;
		String[] str = fileHeaderName.split(BulkConstants.COMMA);
		StringBuffer mandatoryColumns = null;
		int mandatoryCount = 0;
		Map<String,String> mandmap = new HashMap<String, String>();
		String mandatoryQuery = ("1".equalsIgnoreCase(type) || "2".equalsIgnoreCase(type) || "5".equalsIgnoreCase(type) || "6".equalsIgnoreCase(type) || "7".equalsIgnoreCase(type)) ? BulkQueries.ADDI_MANDATORY_DLP_TBL_ADD_FIELDS_CONFIG : BulkQueries.MANDATORY_DLP_TBL_ADD_FIELDS_CONFIG;

		logger.debug("Num of fileHeaderName :: "+str.length);
		if(fileHeaderName == null || fileHeaderName.length() == 0 || str.length == 0){
			logger.debug("str :: "+fileHeaderName.length());
			mtf = new MappingTableFields();
			mtf.setErrorFlag(true);
			mtf.setErrorCode(BulkConstants.NO_HEADER_ERROR);
			return mtf;
		}
		StringBuffer questionMarks = new StringBuffer();
		for(int i=0; i<str.length; i++){
			if(i != 0 && i != str.length)
				questionMarks.append(",");
			questionMarks.append("?");
		}
		logger.debug(questionMarks);
		try{
			connection = jdbcTemplate.getDataSource().getConnection();
			mandatoryPs = connection.prepareStatement(mandatoryQuery);
			mandatoryPs.setString(1, type);
			if("1".equalsIgnoreCase(type) || "2".equalsIgnoreCase(type) || "5".equalsIgnoreCase(type) || "6".equalsIgnoreCase(type) || "7".equalsIgnoreCase(type))
				mandatoryPs.setInt(2, circleId);
			result = mandatoryPs.executeQuery();
			while(result.next()){
				if(flag){
					mandatoryCount = result.getInt("CNT");
					flag=false;
				}
				mandmap.put(result.getString("FIELD_NAME"), result.getString("DISPLAY_NAME") );
			}
			//String query = "SELECT A.FIELD_NAME FIELD_NAME, A.DISPLAY_NAME DISPLAY_NAME, A.MANDATORY_TYPE, COUNT(*) OVER(PARTITION BY 1) CNT FROM DLP_TBL_ADD_FIELDS_CONFIG A WHERE A.DISPLAY_NAME IN("+questionMarks+") AND A.TYPE = ? AND A.CIRCLE_ID = ?";
			String addiQuery = "SELECT A.FIELD_NAME FIELD_NAME, A.DISPLAY_NAME DISPLAY_NAME, A.MANDATORY_TYPE, COUNT(*) OVER(PARTITION BY 1) CNT FROM DLP_TBL_ADD_FIELDS_CONFIG A WHERE A.DISPLAY_NAME IN("+questionMarks+") AND A.TYPE = ? AND A.CIRCLE_ID=?";
			String query = "SELECT A.FIELD_NAME FIELD_NAME, A.DISPLAY_NAME DISPLAY_NAME, A.MANDATORY_TYPE, COUNT(*) OVER(PARTITION BY 1) CNT FROM DLP_TBL_ADD_FIELDS_CONFIG A WHERE A.DISPLAY_NAME IN("+questionMarks+") AND A.TYPE = ? ";
			String queryOpt = ("1".equalsIgnoreCase(type) || "2".equalsIgnoreCase(type) || "5".equalsIgnoreCase(type) || "6".equalsIgnoreCase(type) || "7".equalsIgnoreCase(type))  ? addiQuery : query;

			result=null;
			flag=true;
			ps = connection.prepareStatement(queryOpt);
			for(int i=1;i<str.length+1;i++){
				ps.setString(i, str[i-1].trim());
				logger.debug(""+i+" :: "+str[i-1].trim());
			}
			ps.setString(str.length+1, type);
			if("1".equalsIgnoreCase(type) || "2".equalsIgnoreCase(type) || "5".equalsIgnoreCase(type) || "6".equalsIgnoreCase(type) || "7".equalsIgnoreCase(type))
				ps.setInt(str.length+2, circleId);

			result = ps.executeQuery();
			while(result.next()){
				if(flag){
					mtf= new MappingTableFields();
					map = new HashMap<String, String>();
					mtf.setFieldCount(result.getInt("CNT"));
					mtf.setFileHeaderCount(str.length);
					mandatoryColumns = new StringBuffer();
					flag=false;
				}
				map.put(result.getString("DISPLAY_NAME"), result.getString("FIELD_NAME") );
				if("Y".equalsIgnoreCase(result.getString("MANDATORY_TYPE")))
					mandatoryColumns.append(result.getString("FIELD_NAME")).append(BulkConstants.COMMA);
				logger.debug("in DB ::"+result.getString("DISPLAY_NAME")+"  :: cnt:: "+result.getInt("CNT"));
			}
			if(mtf!=null){
				mtf.setFieldNames(map);
				if(mandatoryColumns != null)
					mtf.setMandatoryColumns(mandatoryColumns.toString());
				mtf.setMandatoryFieldNames(mandmap);
				mtf.setMandatoryFieldCount(mandatoryCount);
			}

			logger.debug("End getDestTabColValue() method");
			return mtf;
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally{
			if(result != null)
				result.close();
			if(ps!=null)
				ps.close();
			connection.close();
		}
	}
	

	
	private String[] generateInsertQueryNew(SchemeBulkLoadConfVo schemeBulkLoadVo) throws SQLException{
		logger.debug("Entered into generateInsertQuery() method");
		logger.debug(" generateInsertQuery :: schemeBulkLoadVo.getFileHeaderNames() ::: \n "+schemeBulkLoadVo.getFileHeaderNames());
		StringBuffer columns = new StringBuffer();
		StringBuffer questionMarks = new StringBuffer();
		boolean flag = true;
		StringBuffer mandatoryColumnsMissing = null;
		String query2 = "SELECT * FROM "+schemeBulkLoadVo.getDestinationTable();
		Connection connection = null;
		PreparedStatement ps = null;
		ResultSet rs =null;
		ResultSetMetaData rsmd = null;
		List<String> list = new ArrayList<String>();
		StringBuffer sb = null;
		boolean sbFlag = true;
		
		/**
		 * query[0] = column names of destination table
		 * query[1] = parameters 
		 * query[2] = insert query
		 * query[3] = validate mandatory columns
		 * query[4] = validate destination table columns
		 * 
		
		*/
		String[] query = new String[5] ; 
		String[] headerFields =  schemeBulkLoadVo.getFileHeaderNames().split(BulkConstants.COMMA);
		for(String val : headerFields){
			if(schemeBulkLoadVo.getFieldNames().containsKey(val)){
				columns.append(schemeBulkLoadVo.getFieldNames().get(val)).append(BulkConstants.COMMA);
				questionMarks.append(BulkConstants.QUESTION_MARK_COMMA);
			}
		}
		query[0] = columns.toString();
		query[1] = questionMarks.toString();
		
		int size = schemeBulkLoadVo.getCellValue().size();
		int i=0;
		for(SchemeBulkColumnVo col : schemeBulkLoadVo.getCellValue()){
			if(++i % size == 0)
				columns.append(col.getDbColumnName());
			else
				columns.append(col.getDbColumnName()).append(BulkConstants.COMMA);
		}
		questionMarks.append(BulkConstants.SINGLE_QUOTE + schemeBulkLoadVo.getFeedNumber()+ BulkConstants.SINGLE_QUOTE_COMMA);
		questionMarks.append(BulkConstants.SINGLE_QUOTE + schemeBulkLoadVo.getFileNameDate() + BulkConstants.SINGLE_QUOTE_COMMA);
		if(schemeBulkLoadVo.getFileId()==4)
			questionMarks.append(BulkConstants.SINGLE_QUOTE + schemeBulkLoadVo.getFileFullName() + BulkConstants.SINGLE_QUOTE_COMMA);
		else
			questionMarks.append(BulkConstants.SINGLE_QUOTE + schemeBulkLoadVo.getFileUniqueName() + BulkConstants.SINGLE_QUOTE_COMMA);
		questionMarks.append("'0',");
		questionMarks.append(BulkConstants.SINGLE_QUOTE + new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format( new Date().getTime()) + BulkConstants.SINGLE_QUOTE_COMMA);
		questionMarks.append("SEQ_DL_PROC_TRANS.NEXTVAL,");
		questionMarks.append("'Y',");
		questionMarks.append("'N',");
		questionMarks.append("'NO_REASON',");
		questionMarks.append(BulkConstants.SINGLE_QUOTE + schemeBulkLoadVo.getFileCircleCode() + BulkConstants.SINGLE_QUOTE);
		String query1 = "insert into "+schemeBulkLoadVo.getDestinationTable()+" ("+columns+") values ("+ questionMarks + BulkConstants.RIGHT_BRACKET;
		query[2] = query1;
		query[3] = null;
		
		//validate mandatory columns
		for(Map.Entry<String,String> m : schemeBulkLoadVo.getMandatoryFieldNames().entrySet()){  
		    if(!schemeBulkLoadVo.getMandatoryColumnNames().contains(m.getKey().toString())){
				if(flag){
					mandatoryColumnsMissing = new StringBuffer();
					flag=false;
				}
				mandatoryColumnsMissing.append(m.getValue()).append(",");
		    }
		  } 
		if(mandatoryColumnsMissing!=null){
			query[3] = mandatoryColumnsMissing.toString();
		}
		
		//validate destination table columns
		try{
			connection = jdbcTemplate.getDataSource().getConnection();
			ps = connection.prepareStatement(query2);
			rs = ps.executeQuery();
			rsmd = rs.getMetaData();
			String[] columnContains = columns.toString().split(",");
			for(int j = 1; j <= rsmd.getColumnCount(); j++){
				for(int z=0; z < columnContains.length; z++){
					if(columnContains[z].equalsIgnoreCase(rsmd.getColumnName(j))){
						logger.debug("TBL Column :: "+rsmd.getColumnName(j));
						list.add(rsmd.getColumnName(j));
					}
				}
			}
			String comp = columns.toString();
			String[] sp = columns.toString().split(BulkConstants.COMMA);
			for(String c : sp){
				for(String s : list){
					if(c.equals(s)){
						comp = comp.replace(s,BulkConstants.BLANK);
						continue;
					}
				}
			}
			
			sp = comp.split(BulkConstants.COMMA);
			for(String s:sp){
				if("".equals(s)){
					continue;
				}else{
					for(Map.Entry<String, String> map : schemeBulkLoadVo.getFieldNames().entrySet()){
						if(map.getValue().equalsIgnoreCase(s)){
							if(sbFlag){
								sb = new StringBuffer();
								sbFlag=false;
							}
							sb.append(map.getKey()).append(BulkConstants.COMMA);		
						}
					}
					
				}
			}
			query[4] = null;
			if(sb != null){
				query[4] = sb.toString();
				//System.out.println("query[4] ::: sb.toString() :::: "+sb.toString());
			}
				
		}catch(Exception e){
			
		}finally{
			if(rs != null)
				rs.close();
			if(ps != null)
				ps.close();
			if(connection != null)
				connection.close();
		}
		//logger.debug("final query ::"+query1);
		logger.debug("End generateInsertQuery() method");
		return query;
	}
	
	@Override
	public String insertDestinationTableNew(File file,SchemeBulkLoadConfVo schemeBulkLoadVo) throws Exception{
		logger.debug("Entered into  insertDestinationTable() method");
		long startTime = new Date().getTime();
		logger.debug("startTime ::: "+startTime);
		Connection connection = null;
		PreparedStatement ps = null;
		BufferedReader br = null;
		String errorMsg = null;
		int count = 0;
		//int opt = 0;
		String line = null;
		//String optional = "DSM2_REF_CODE,VTOPUP_NUMBER,FTA_NUMBER";
		//String optional = "DSM2_REF_CODE";
		
		try{
			connection = jdbcTemplate.getDataSource().getConnection();
			String[] query = generateInsertQueryNew(schemeBulkLoadVo);
			
			if(query[3]!=null){
				return BulkConstants.MANDATORY_COLUMN_REQUIRED + query[3];
			}
			if(query[4] != null){
				return BulkConstants.DESTINATION_COLUMN_ERROR + query[4];
			}
			connection.setAutoCommit(false);
			ps = connection.prepareStatement(query[2]);
			final int batchSize = 6000;
			br = new BufferedReader(new FileReader(file));
			String[] columnNames = query[0].split(BulkConstants.COMMA);
			while ((line = br.readLine()) != null) {
				//opt = 0;
				if(count==0){
					count++;
					continue;
				}logger.debug(count+". line :::: "+line);
				String[] columnData = line.split(BulkConstants.COMMA);
				
				if(schemeBulkLoadVo.getFieldCount()==columnData.length){
				
					for(int i=1;i<columnData.length+1;i++){
					
						if(schemeBulkLoadVo.getMandatoryColumnNames().contains(columnNames[i-1])){
							
							if(schemeBulkLoadVo.getFileId() == 2){
								
								if(columnNames[i-1].contains(BulkConstants.DATE)){
									
									if( "".equalsIgnoreCase(columnData[i-1])){
									
										if(br!=null)
											br.close();
										
										return BulkConstants.MANDATORY_DATA_REQUIRED +  count;
									}
									SimpleDateFormat format1 = null;
									if(columnData[i-1].trim().length()==22 || columnData[i-1].trim().length()==23){
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_AM_PM);
									}else if(columnData[i-1].trim().length()==20 || columnData[i-1].trim().length()==21){
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_24);
									}else //if(columnData[i-1].trim().length()==11)
									{
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY);
									}
								//	System.out.println("columnData[i-1] ::: "+columnData[i-1]);
									Date utilDate = format1.parse(columnData[i-1]);
									java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
									//System.out.println("sqlDate ::: "+sqlDate);
									ps.setDate(i, sqlDate);
								}else{
									if( "".equalsIgnoreCase(columnData[i-1])){
										
										if(br!=null)
											br.close();
										
										return BulkConstants.MANDATORY_DATA_REQUIRED +  count;
									}
									
									/*if( "".equalsIgnoreCase(columnData[i-1])){
										if(!optional.contains(columnNames[i-1])){
											if(br!=null)
												br.close();
											return BulkConstants.MANDATORY_DATA_REQUIRED + count;
										}else {
											++opt;
											if(opt==3){
												if(br!=null)
													br.close();
												return BulkConstants.ATLEAT_ONE_MANDATORY_DATA  + count ;
											}
										}
									}*/
									ps.setString(i, columnData[i-1]);
								}
								
							}else{
								if(columnNames[i-1].contains(BulkConstants.DATE)){
									if( "".equalsIgnoreCase(columnData[i-1])){
										if(br!=null)
											br.close();
										
										return BulkConstants.MANDATORY_DATA_REQUIRED + count ;
									}
									SimpleDateFormat format1 = null;
									if(columnData[i-1].trim().length()==22 || columnData[i-1].trim().length()==23){
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_AM_PM);
									}else if(columnData[i-1].trim().length()==20 || columnData[i-1].trim().length()==21){
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_24);
									}else //if(columnData[i-1].trim().length()==11)
									{
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY);
									}
									//SimpleDateFormat format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY);
									//System.out.println("columnData[i-1] ::: "+columnData[i-1]);
									Date utilDate = format1.parse(columnData[i-1]);
									java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
									//System.out.println("sqlDate ::: "+sqlDate);
									ps.setDate(i, sqlDate);
								}else{
									if( "".equalsIgnoreCase(columnData[i-1])){
										if(br!=null)
											br.close();
										
										return BulkConstants.MANDATORY_DATA_REQUIRED + count;
									}
									ps.setString(i, columnData[i-1]);
								}
							}
							
						}else{
							if(columnNames[i-1].contains(BulkConstants.DATE)){
								//SimpleDateFormat format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY);
								SimpleDateFormat format1 = null;
								if(columnData[i-1].trim().length()==22 || columnData[i-1].trim().length()==23){
									format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_AM_PM);
								}else if(columnData[i-1].trim().length()==20 || columnData[i-1].trim().length()==21){
									format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_24);
								}else // if(columnData[i-1].trim().length()==11)
								{
									format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY);
								}
								Date utilDate = format1.parse(columnData[i-1]);
								java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
								ps.setDate(i, sqlDate);
							}else{
								ps.setString(i, columnData[i-1]);
							}
						}
						
					//	logger.debug(""+i+" ::: "+columnData[i-1]);
					}
				}else{
					if(br!=null)
						br.close();
					connection.rollback();
					if((count==1 ) && "".equalsIgnoreCase(line.trim())){
						return BulkConstants.NO_DATA_FIRST_ROW;
					}else if((count!=1 ) && "".equalsIgnoreCase(line.trim())){
						return BulkConstants.NO_DATA_FOUND_MIDDLE + count;
					}
					return BulkConstants.DATA_HEADER_MISMATCH_ERROR + count;
				}
				ps.addBatch();
				if(++count % batchSize == 0) {
					ps.executeBatch();
					ps.clearBatch(); 
				}
			}
			
			if(count==0){
				if(br!=null)
					br.close();
				return BulkConstants.NO_DATA_FOUND;
			}
			if(count==1){
				if(br!=null)
					br.close();
				return BulkConstants.NO_DATA_HEADER_ERROR;
			}
			if(++count % batchSize != 0) {
				logger.debug(count+". In execute batch >>>");
				ps.executeBatch();// insert remaining records ParseException 
				ps.clearBatch(); 
			}
			connection.commit();
			logger.debug("End insertDestinationTable() method");
			//System.out.println("start Time :: "+startTime+" - end time ::"+new Date().getTime()+"  \t diff Time ::: "+(new Date().getTime()-startTime));
			logger.debug("start Time :: "+startTime+" - end time ::"+new Date().getTime()+"  \t diff Time ::: "+(new Date().getTime()-startTime));
			return errorMsg;
		}catch (ParseException e1) {
			logger.error("in ParseException");
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
			}catch (IOException e) {
				logger.error("in ParseException",e);
				e.printStackTrace();
			} catch (SQLException e) {
				logger.error("in ParseSQLException",e);
				e.printStackTrace();
			}
			logger.error("ParseException :: ",e1);
			e1.printStackTrace();
			return BulkConstants.DATA_DATE_ERROR + count;
		}catch (IOException e1) {
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
				logger.error("IOException :: ",e1);
				return BulkConstants.FILE_READER_ERROR ;
			}catch (IOException e) {
				logger.error("IOException :: ",e);
				e.printStackTrace();
			} catch (SQLException e) {
				logger.error("SQLException :: ",e);
				e.printStackTrace();
			}
			logger.error("IOException :: ",e1);
			e1.printStackTrace();
		}catch (SQLException e1) {
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
				logger.error("SQLException :: ",e1);
				if(e1.getMessage().contains("partition key")){
					return BulkConstants.PARTITION_ERROR;
				}else
				return BulkConstants.DESTINATION_TABLE_ERROR ;
			}catch (IOException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}e1.printStackTrace();
		}catch (NullPointerException e1) {
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
				logger.error("NullPointerException :: ",e1);
				return   BulkConstants.NULL_ERROR  + count;
			}catch (IOException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}e1.printStackTrace();
		}catch(Exception e){
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close(); 
				logger.error("Exception :: ",e);
				return  BulkConstants.DATA_ERROR ;
			}catch (IOException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}finally{
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.close();
				if(br!=null)
					br.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return errorMsg;
	}

	@Override
	public String callProcEntityAddAttrStampNew(SchemeBulkLoadConfVo schemeBulkLoadVo) throws Exception{
		logger.debug("Entered into callProcEntityAddAttrStamp() method");
		String procOutput = null;
		Connection conn=null;
		try {
			if(schemeBulkLoadVo.getProcedureName()!=null){
			logger.debug("FEED NUMBER :: "+schemeBulkLoadVo.getFeedNumber()+"\t fileDate::: "+schemeBulkLoadVo.getFileNameDate()+"\t fileName:: "+schemeBulkLoadVo.getFileUniqueName()+"\t cir:: "+schemeBulkLoadVo.getFileCircleCode()+"\t proc:: "+schemeBulkLoadVo.getProcedureName());
				conn = jdbcTemplate.getDataSource().getConnection();
				CallableStatement call = conn.prepareCall("{call "+schemeBulkLoadVo.getProcedureName()+"(?,?,?,?,?)}");
				call.setInt(1, Integer.parseInt(schemeBulkLoadVo.getFeedNumber()));
				logger.debug(" getSqlDate(fileDate) :::: "+ getSqlDateNew(schemeBulkLoadVo.getFileNameDate()));
				call.setDate(2, getSqlDateNew(schemeBulkLoadVo.getFileNameDate()));
				if(schemeBulkLoadVo.getFileId()==4)
					call.setString(3, schemeBulkLoadVo.getFileFullName());
				else
					call.setString(3, schemeBulkLoadVo.getFileUniqueName());
				call.setString(4, schemeBulkLoadVo.getFileCircleCode());
				call.registerOutParameter(5 , OracleTypes.VARCHAR);
				call.execute();
				procOutput = call.getString(5);
				logger.debug("procOutput :::: "+procOutput);
				logger.debug("End callProcEntityAddAttrStamp() method");
			}else{
				procOutput="No procedure name";	
			}
		} catch (Exception e) {
			e.printStackTrace();
			return procOutput;
		}finally{
			conn.close();
		}
		return procOutput;	
	}
	
	private java.sql.Date getSqlDateNew(String date) throws ParseException{
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		//System.out.println("getSqlDateNew ::: "+date);
		Date parsed = format.parse(date);
		return  new java.sql.Date(parsed.getTime());
	}

	
	private java.sql.Date getSqlDateFromDate(Date date) throws ParseException{
		//SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		//System.out.println("getSqlDateNew ::: "+date);
		//Date parsed = format.parse(date);
		return  new java.sql.Date(date.getTime());
	}

	
	@Override
	public String persistFileDetailNew(String userName, String fileName, String fileStatus, String uniqueFileName, String circleCode)  throws Exception{
		logger.debug("Entered into persistFileDetail() method");
		Connection con = null;
		PreparedStatement ps = null;
		PreparedStatement checkFilePs=null;
		int rowCount = 0;
		String recordStatus = "FAIL";
		ResultSet result = null;
		int reloadStatus = 0;
		try {
			con = jdbcTemplate.getDataSource().getConnection();
			checkFilePs = con.prepareStatement(BulkQueries.SELECT_SCHEME_BULK_LOAD_FILE_STATUS);
			checkFilePs.setString(1, fileName);
			result = checkFilePs.executeQuery();
			if(result.next()){
				reloadStatus = result.getInt("RELOAD_ATTEMPTS");
				reloadStatus = reloadStatus+1;
				//logger.debug("Reload attampts :: "+reloadStatus);
			}
				ps = con.prepareStatement(BulkQueries.INSERT_SCHEME_BULK_LOAD_FILE_STATUS);
				ps.setString(1, userName);
				ps.setString(2, fileName);
				ps.setString(3, "FILE LOADED");
				ps.setString(4, fileStatus);
				ps.setInt(5, reloadStatus);
				ps.setString(6, uniqueFileName);
				ps.setString(7, circleCode);
				rowCount = ps.executeUpdate();
				//logger.debug(rowCount +" Inserted successfully ");
		//	}
		//System.out.println("reloadStatus ::: "+reloadStatus);
			/*else{
				ps = con.prepareStatement(BulkQueries.UPDATE_SCHEME_BULK_LOAD_FILE_STATUS);
				ps.setString(1, userName);
				ps.setString(2, fileStatus);
				ps.setInt(3, reloadStatus);
				ps.setString(4, fileName);
				rowCount = ps.executeUpdate();
				//logger.debug(rowCount +" Updated successfully ");
			}*/
			if (rowCount > 0) {
				recordStatus = "SUCCESS";
				//logger.debug("FILE INFORMATION UPDATED SUCCESSFULLY");
			}logger.debug("End persistFileDetail() method");
			
		} catch (Exception e) {
			recordStatus = "FAIL";
			//logger.debug("FAIL TO UPDATE FILE INFORMATION");
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return recordStatus;
	}

	@Override
	public boolean matchSchemeCompMappingFileNew(int schemeId, int compId, String fileName) throws Exception{
		Connection con=null;
		PreparedStatement ps =null;
		boolean resultStatus=false;
		ResultSet rs=null;
		logger.debug("FILE FULL NAME >> "+fileName+"\t scid:: "+schemeId+"\t compId::"+ compId);
		try {
			con = jdbcTemplate.getDataSource().getConnection();
			ps = con.prepareStatement(BulkQueries.DLP_SCHEME_COMP_MAPPING);
			ps.setString(1, fileName);
			ps.setInt(2, schemeId);
			ps.setInt(3, compId);
			rs = ps.executeQuery();
			if(rs.next()){
				resultStatus = true;
				logger.debug("resultCount :::: "+rs+"\t resultStatus:: "+resultStatus+"\t "+rs.getString("FILE_NAME"));
			}

		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(ps!=null)
					ps.close();
				if(rs!=null)
					rs.close();

				if(con!=null)
					con.close();

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.debug("resultStatus :::: "+resultStatus);
		return resultStatus;
	}
	
	@Override
	public void updateDestinationTableNew(String circleCode, String fileName, String distinationTableName) throws Exception{
		Connection con=null;
		PreparedStatement ps = null;
		int rowCount = 0;
		try {
			con=jdbcTemplate.getDataSource().getConnection();
			String query;
			query = "UPDATE "+distinationTableName+" SET IPS_MOVEMENT_FLAG = 'R' WHERE CIRCLE = ? AND FILE_NAME = ? AND IPS_MOVEMENT_FLAG = 'Y' ";
			ps = con.prepareStatement(query);
			ps.setString(1, circleCode);
			ps.setString(2, fileName);
			rowCount = ps.executeUpdate();
			//logger.debug(rowCount +" Updated successfully ");
			if (rowCount > 0) {
				logger.debug("FILE INFORMATION UPDATED SUCCESSFULLY");
			}
		} catch(SQLException e1) {
			throw e1;
		}catch(Exception e) {
			throw e;
		}finally{

			try {
				if(ps!=null)
					ps.close();
				if(con!=null)
					con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public String callProcDlpPerformConfigNew(SchemeBulkLoadConfVo schemeBulk, String userName) throws Exception{
		Connection conn = null;
		String procOutput = null;
		PreparedStatement ps = null;
		ResultSet result = null;
		int reloadAttamp = 0;
		logger.debug("procName :: "+schemeBulk.getProcedureName());
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			if(conn !=null){
				ps = conn.prepareStatement(BulkQueries.SELECT_SCHEME_BULK_LOAD_FILE_STATUS);
				if(schemeBulk.getFileId()==5){
					ps.setString(1, schemeBulk.getFileUniqueName());
				}else{
					ps.setString(1, schemeBulk.getFileFullName());	
				}
				
				result = ps.executeQuery();
				if(result.next()){
					reloadAttamp = result.getInt("RELOAD_ATTEMPTS");
				}

				CallableStatement call = conn.prepareCall("{call "+schemeBulk.getProcedureName()+"(?,?,?,?,?,?,?)}");
				call.setInt(1, Integer.parseInt(schemeBulk.getFeedNumber()));
				call.setDate(2, getSqlDateNew(schemeBulk.getFileNameDate()));
				if(schemeBulk.getFileId()==5){
					call.setString(3, schemeBulk.getFileUniqueName());
				}else{
					call.setString(3, schemeBulk.getFileFullName());
				}
				call.setInt(4, reloadAttamp);
				call.setString(5, schemeBulk.getFileCircleCode());
				call.setString(6, userName);
				call.registerOutParameter(7 , OracleTypes.VARCHAR);
				call.execute();
				procOutput = call.getString(7);
				//System.out.println("callProcDlpPerformConfigNew :::: "+procOutput);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return procOutput;
		}finally{

			try {
				if(result!=null)
					result.close();

				if(ps!=null)
					ps.close();
				if(conn!=null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.debug("procOutput ::::::::::: "+procOutput);
		return procOutput;
	}

	public String callProcDlpCirclePerformParamConfigNew(SchemeBulkLoadConfVo schemeBulk, String userName) throws Exception{

		Connection conn = null;
		String procOutput = null;
		ResultSet result = null;
		logger.debug("procName :: "+schemeBulk.getProcedureName());
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			//System.out.println("BulkUploadDAOImpl || callProcDlpCirclePerformParamConfigNew || BEG:"+schemeBulk.getFileId() +"\t ::: stdt ::: "+schemeBulk.getStartDate()+" \t enddt:::::: "+schemeBulk.getEndDate());
			if(conn !=null){
				
				    //String query="Insert Into Scheme_Bulk_Load_File_Det (Circle,Upload_Type,Upload_Universe,Upload_File_Name,Insert_Date_Time,File_Status) values(?,?,?,?,?)";
					CallableStatement call = conn.prepareCall("{call "+schemeBulk.getProcedureName()+"(?,?,?,?,?,?,?)}");
					call.setInt(1, Integer.parseInt(schemeBulk.getFeedNumber()));
					call.setDate(2, getSqlDateNew(schemeBulk.getFileNameDate()));
					call.setString(3, schemeBulk.getFileUniqueName());
					call.setString(4, schemeBulk.getFileCircleCode());
					
					if(schemeBulk.getFileId() == 3){
						call.setDate(5,getSqlDateFromDate(schemeBulk.getStartDate()));
						call.setDate(6,getSqlDateFromDate(schemeBulk.getEndDate()));
					}else{
						call.setString(5, null);
						call.setString(6, null);
					}
					call.registerOutParameter(7, OracleTypes.VARCHAR);
					
					/*call.setDate(5,getSqlDateNew((schemeBulk.getStartDate()!=null)?schemeBulk.getStartDate().toString():""));
					call.setDate(6,getSqlDateNew((schemeBulk.getEndDate()!=null)?schemeBulk.getEndDate().toString():""));
					call.registerOutParameter(7, OracleTypes.VARCHAR);
					*/call.execute();
					procOutput = call.getString(7);
					//System.out.println("callProcDlpPerformConfigNew :::: "+procOutput);
					
					
					//int insertedStatus=jdbcTemplate.update(BulkQueries.query, new Object[]{schemeBulk.getFileCircleCode(),schemeBulk.getType(),"ACT","abc.txt",new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format( new Date().getTime()),'N'});
					
					////System.out.println("inserted Rec Status"+insertedStatus);
					
					//conn.prepareCall(query);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
			return procOutput;
		}finally{
			try {
				if(result!=null)
					result.close();
				if(conn!=null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.debug("procOutput ::::::::::: "+procOutput);
		return procOutput;
	}
	
	//New BulkUpLoad Code 11

	public int headerAdd =0;
	String columnArr[] = null;
	String columnName;
	//String fileDate;
	String feedNum;
	int fileid;
	String circleCode;
	String sourceDate;
	String fileFullName;
	String fileStatus = null;
	String schemeFileName=null;
	String errorCode;
	String procedureName;
	String fileNameDate;
	int sheetNum;
	long interFileSeq;


	@SuppressWarnings("rawtypes")
	public String fetchFileData(String userName, int file_id, File file, String circle, int schemeId, int compId)  throws Exception{
		int fileRowId=1;
		String fileDate;
		boolean procSchmIsSuccess = false;
		String dlpProcSchmConf = null;
		String fileStageStatus = null;
		boolean errorFlag = false;
		List<SchemeBulkLoadConfVo> schmeBulkConfData;
		//FileLoadStatus fileLoadStatus = new FileLoadStatus();
		Connection connection = null;
		//String direct = null;
		BufferedReader br =null;
		//String[] status=null;
		try {
			//User user = (User)httpSession.getAttribute("appUser");
			connection = jdbcTemplate.getDataSource().getConnection();// ConnectionUtility.getInstance().getLocalConnection();
			connection.setAutoCommit(false);
			/**
			 * Generate sequence for INTERNAL_FILE_SEQ
			 */
			int reloadAtmp = 0;
			if(file_id==1){

				reloadAtmp = fileReloaded(file, connection);
				String sqlIdentifier = "SELECT COV_PRESTAG_INTERNAL_FILE_SEQ.NEXTVAL FROM DUAL";
				PreparedStatement pst = connection.prepareStatement(sqlIdentifier);
				ResultSet rs = pst.executeQuery();
				if(rs.next()){
					interFileSeq = rs.getLong(1);
				}
				rs.close();
				pst.close();
			}
			schemeFileName = file.getName();
			String fileName[] = file.getName().split("\\.");
			Long uniqueFile = new Date().getTime();
			fileFullName = fileName[0]+"_"+(Long.toString(uniqueFile))+"."+fileName[1];
			//fileFullName = file.getName();
			fileDate = fileName[0]; 
			logger.debug("fileFullName : "+fileName[1]);
			//feedNum = feedNumber;
			circleCode = circle;

			if(file_id==4){
				boolean flag = matchSchemeCompMappingFile(connection, schemeId, compId, schemeFileName);
				if(!flag){
					if(schemeId==0)
						return "GIVEN SCHEME ID IS ZERO.";
					if(compId==0)
						return "GIVEN COMPONENT ID IS ZERO.";
					return "FILE NAME IS NOT MATCHED WITH GIVEN SCHEME AND COMPONENT";
				}
			}
			/**
			 * Below calling method, Providing configured data from DB
			 */
			
			schmeBulkConfData = getSchemBulkConfData(connection, file_id);


			Iterator<Row> rowIterator = null;
			StringBuffer dataTypes = new StringBuffer();
			int checkHeader=1;
			String line = "";
			if("csv".equalsIgnoreCase(fileName[1])){
				br = new BufferedReader(new FileReader(file));
			}

			for (SchemeBulkLoadConfVo schemeBulkLoadVo : schmeBulkConfData) {
				FileInputStream fStream = new FileInputStream(file);
				feedNum= schemeBulkLoadVo.getFeedNumber();
				fileid = schemeBulkLoadVo.getFileId();
				procedureName = schemeBulkLoadVo.getProcedureName();
				logger.debug("SCHEET NUMBER : "+schemeBulkLoadVo.getSheetNum());
				DataFormatter objDefaultFormat = null;
				FormulaEvaluator objFormulaEvaluator = null;
				XSSFFormulaEvaluator objDFormulaEvalutor = null;
				dlpProcSchmConf = schemeBulkLoadVo.getMappingTable();
				fileStageStatus = schemeBulkLoadVo.getProcedureName();
				logger.debug("PPPPPPPPPP :::::::"+dlpProcSchmConf);
				logger.debug("CONF NAME : "+schemeBulkLoadVo.getConfName()); 
				logger.debug("DESTINATION TABLE NAME : "+schemeBulkLoadVo.getDestinationTable());
				
				if(schemeBulkLoadVo.getFileId() == 4){
					updateDestinationTable(circle, schemeFileName, schemeBulkLoadVo.getDestinationTable(), connection);
				}
				/**
				 * Below code is to read .xls file
				 */
				if ("xls".equalsIgnoreCase(fileName[1])) {
					logger.debug("Start Time : "+new Date());
					logger.debug("XLS File Loaded and started Reading.......");
					Workbook workbook = WorkbookFactory.create(fStream);
					objDefaultFormat = new DataFormatter();
					objFormulaEvaluator = new HSSFFormulaEvaluator((HSSFWorkbook) workbook);
					sheetNum = schemeBulkLoadVo.getSheetNum();
					Sheet sheet = workbook.getSheetAt(sheetNum);
					rowIterator = sheet.iterator();
					logger.debug("End Time : "+new Date());
				}
				/**
				 * Below code is to read .xlsx file
				 */
				if ("xlsx".equalsIgnoreCase(fileName[1])) {
					logger.debug("Start Time"+new Date().getTime());
					logger.debug("XLSX File Loaded and started Reading.......");
					XSSFWorkbook xlsxWorkbook = new XSSFWorkbook(fStream);
					objDefaultFormat = new DataFormatter();
					objDFormulaEvalutor = new XSSFFormulaEvaluator(xlsxWorkbook);
					sheetNum = schemeBulkLoadVo.getSheetNum();
					XSSFSheet xlsxSheet = xlsxWorkbook.getSheetAt(sheetNum);
					rowIterator = xlsxSheet.iterator();
					logger.debug(new Date().getTime());
				}

				ArrayList recordList = null;

				if ("csv".equalsIgnoreCase(fileName[1]) && "D".equalsIgnoreCase(schemeBulkLoadVo.getLoadingMethod())) {
					logger.debug("CSV File loaded for : "+fileFullName);

					while ((line = br.readLine()) != null) {
						int blankCounter = 0;
						recordList = new ArrayList();
						String lineArr[] = line.split(",");
						for(String csvValue : lineArr){

							if(checkHeader==1){
								//System.out.print(cellValueStr+", ");
								//System.out.print(" >> "+csvValue);
								schemeBulkLoadVo = getDestTabColValue(csvValue, connection, schemeBulkLoadVo);

								if("FAIL".equals(schemeBulkLoadVo.getExceptionVo().getMsgCode())){
									if(errorFlag==false){
										errorFlag=true;
									}
									errorCode = schemeBulkLoadVo.getExceptionVo().getMsgCode();
									fileStatus = errorCode+": "+schemeBulkLoadVo.getExceptionVo().getMsgDescription();
									logger.debug("Error Description from colum value fetch >> "+schemeBulkLoadVo.getExceptionVo().getMsgDescription());
								}else{
									dataTypes.append(schemeBulkLoadVo.getColumnNames()+",");
									fileStatus=schemeBulkLoadVo.getExceptionVo().getMsgDescription();
								}
							}else{
								recordList.add(csvValue);
							}

							if ("".equals(csvValue))
								blankCounter++;

						} // End of reading record values

						if (!recordList.isEmpty()&& blankCounter != recordList.size()) {
							schemeBulkLoadVo = addEntityAttribute(connection, dataTypes, recordList, schemeBulkLoadVo,fileDate);
							errorCode = schemeBulkLoadVo.getExceptionVo().getMsgCode();
							logger.debug("ERROR CODE : "+errorCode);
							if("FAIL".equals(schemeBulkLoadVo.getExceptionVo().getMsgCode())){
								if(errorFlag==false){
									errorFlag=true;
								}
								errorCode = schemeBulkLoadVo.getExceptionVo().getMsgCode();
								fileStatus= errorCode+": "+schemeBulkLoadVo.getExceptionVo().getMsgDescription();
								logger.debug("Erro occured during Attribute insertion :: "+schemeBulkLoadVo.getExceptionVo().getMsgDescription());
							}else{
								fileStatus=schemeBulkLoadVo.getExceptionVo().getMsgDescription();
							}
						}
						checkHeader++;
						schemeBulkLoadVo.setColumnNames(null);
						recordList = null;
					}
					connection.commit();
				}


				if("P".equalsIgnoreCase(schemeBulkLoadVo.getLoadingMethod())  && !"csv".equalsIgnoreCase(fileName[1])){

					while (rowIterator.hasNext()) {
						int tildeOperator = 0;
						int procedureCount =1;
						recordList = new ArrayList();
						Row row = rowIterator.next();
						// For each row, iterate through all the columns

						if (row.getRowNum() > (schemeBulkLoadVo.getHeaderRows()-1)) {
							Iterator<Cell> cellIterator = row.cellIterator();
							int blankCounter = 0;
							while (cellIterator.hasNext()) {
								Cell cell = cellIterator.next();
								String cellValueStr = null;
								if (objDFormulaEvalutor != null) {
									objDFormulaEvalutor.evaluate(cell);
									cellValueStr = objDefaultFormat.formatCellValue(cell,objDFormulaEvalutor);
								} else {
									objFormulaEvaluator.evaluate(cell);
									cellValueStr = objDefaultFormat.formatCellValue(cell,objFormulaEvaluator);
									//System.out.print("<<<< BEFORE :"+cellValueStr+" >>>>>");
								}
								if(cellValueStr.contains(":"))
									cellValueStr = cellValueStr.replace(":", ",");

								recordList.add(cellValueStr);
								if(cellValueStr.contains("~") && tildeOperator==0 && sheetNum > 0){
									String[] schemeComp= cellValueStr.split("~");
									for(String schmeCompValue : schemeComp){
										recordList.add(schmeCompValue);
									}
									tildeOperator++;
								}// End of if 								    

								if ("".equals(cellValueStr))
									blankCounter++;
							}
							if (!recordList.isEmpty() && blankCounter != recordList.size()) {
								logger.debug(procedureCount++);
								//logger.debug("RECORD LIST :: "+recordList);
								//SchemeConf schemeConf = new SchemeConf();
								/**
								 * Calling persistData() method to store Scheme's
								 */
								//logger.debug("ON READING ::"+recordList);
								schemeBulkLoadVo = persitData(recordList, schemeBulkLoadVo, connection, sheetNum, file, file_id, circle, interFileSeq, fileRowId, reloadAtmp);	
								errorCode=schemeBulkLoadVo.getExceptionVo().getMsgCode();

								if("FAIL".equals(schemeBulkLoadVo.getExceptionVo().getMsgCode())){
									if(errorFlag==false){
										errorFlag=true;
									}
									errorCode=schemeBulkLoadVo.getExceptionVo().getMsgCode();
									logger.debug("Error from PROC :: "+schemeBulkLoadVo.getExceptionVo().getMsgDescription());
									fileStatus = schemeBulkLoadVo.getExceptionVo().getMsgCode()+":"+schemeBulkLoadVo.getExceptionVo().getMsgDescription();
								} else{
									fileStatus = schemeBulkLoadVo.getExceptionVo().getMsgDescription();
									if(procSchmIsSuccess==false){
										logger.debug("procSchmIsSuccess::: "+procSchmIsSuccess);
										procSchmIsSuccess=true;
									}
								}	
							}
							recordList = null;
						}
						fileRowId++;
						if(errorFlag==true){
							break;
						}
						//System.out.println();
						logger.debug("");
					}
				}
				fStream.close();
				if(br!=null){
					br.close();
				}

			} // First for loop ended

			logger.debug("ENTITY CONFIGURATION PROCESS CALLED >> "+procedureName);
			if("DLP_ENTITY_ADD_ATTR_STAMP".equalsIgnoreCase(procedureName) && errorFlag==false){
				logger.debug("CALLING PROCEDURE >> PROC_ENTITY_ADD_ATTR_STAMP");
				fileStatus = callProcEntityAddAttrStamp(connection, feedNum, fileNameDate,fileFullName, circle, procedureName );

			}

			if("DLP_PP_CONFIGURATION".equalsIgnoreCase(procedureName) && errorFlag==false){
				logger.debug("CALLING PROCEDURE >> DLP_PP_CONFIGURATION");
				fileStatus =  callProcDlpPerformConfig(connection, feedNum,  fileNameDate,  fileFullName,  circle,  procedureName,userName);
			}

			if("DLP_SCHEME_COMP_MAPPING".equalsIgnoreCase(procedureName) && errorFlag==false){
				logger.debug("Updating table >> DLP_SCHEME_COMP_MAPPING");
				//fileStatus =  callProcDlpPerformConfig(connection, feedNum,  fileNameDate,  fileFullName,  circle,  procedureName);schemeFileName
				
				//updateSchemMapping(connection, schemeId, compId, schemeFileName, procedureName);
			}

			if("DLP_MANUAL_PAYOUT".equalsIgnoreCase(procedureName) && errorFlag==false){
				logger.debug("CALLING PROCEDURE >> DLP_MANUAL_PAYOUT"+"\t"+ fileNameDate + "\t"+ fileFullName+"\t"+  circle+"\t" + procedureName+"\t"+userName);
				fileStatus =  callProcDlpPerformConfig(connection, feedNum,  fileNameDate,  fileFullName,  circle,  procedureName,userName);
			}

			/**
			 * Here we will call DLP_PROC_SCHEME_CONFIG Procedure
			 * after Successfully insertion of all Schemes.  
			 */
			if(errorFlag==false && procSchmIsSuccess==true){
				/**
				 * Persisting data into DLP_TBL_CONF_FILE_STAG_STATUS table
				 * if code will fail to insert data into this table then 
				 * rollback is required for all the persisted data related to
				 * scheme configuration. 
				 */
				logger.debug("fileStageStatus:::::: "+fileStageStatus);
				String fileDateArr[] = fileDate.split("_");
				SimpleDateFormat format = new SimpleDateFormat("ddMMyyyy");
				Date parsed = format.parse(fileDateArr[fileDateArr.length-1]);
				String sqlDate = new SimpleDateFormat("dd-MMM-yyyy").format(parsed);
				CallableStatement call =null;	
				//persistFileStageStatus();
				call = connection.prepareCall("{call "+fileStageStatus+"(?,?,?,?,?)}");

				call.setString(1, file.getName());
				call.setLong(2, interFileSeq);
				call.setString(3, circle);
				call.setString(4, sqlDate);
				call.setInt(5, reloadAtmp);
				call.execute();
				logger.debug("DATA LOADED SUCCESSFULLY IN 'DLP_PROC_FILE_STAGE_STATUS' PROC");
				call.close();

				logger.debug("PROC NAME >> ::::::::::"+dlpProcSchmConf);
				CallableStatement call1 = connection.prepareCall("{call "+dlpProcSchmConf+"(?,?,?)}");
				call1.setString(1, userName);
				call1.setString(2, circle);
				call1.setInt(3, 1);
				call1.execute();
				call1.close();
				logger.debug("After successfully loading Scheme's procedure call");
			}

			logger.debug("ERROR FLAG >>>::::>>>> "+errorFlag);
			if(errorFlag==true){
				//System.err.println("FAIL : Transaction has been rolled back successfully");
				//logger.debug("NOT ROLLED BACK FOR SOME TIME");
				connection.rollback();
				//return "Transaction has been rolled back";
			}	

		} catch (FileNotFoundException errorMessage) {
			//System.err.println("Wrong file uploaded or Please check file extension it must be xls/xlsx or csv");
			errorMessage.printStackTrace();
		} catch (Exception e) {
			if(connection!=null){
				try {
					//System.err.print("Transaction is being rolled back");
					connection.rollback();
				//	return "Transaction is being rolled back.";
				} catch(SQLException excep) {
					excep.printStackTrace();
				}
			}
			e.printStackTrace();
		}finally{
			logger.debug("FILE STATUS :: "+fileStatus);
			if(!"".equalsIgnoreCase(fileStatus) && fileStatus !=null){
				try {
					connection.setAutoCommit(true);
					persistFileDetail(userName, file.getName(), fileStatus, connection);
				} catch (SQLException e) {
					e.printStackTrace();
				} catch (Exception e) {
					e.printStackTrace();
				}	
			}

			if(connection!=null){
				try {					
					connection.close();
					logger.debug("connection closed successfully");
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			headerAdd =0;
			columnArr = null;
			columnName= null;
			//fileDate= null;
			feedNum= null;
			fileid=0;
			circleCode= null;
			sourceDate= null;
			fileFullName= null;
			schemeFileName=null;
			procedureName= null;
			fileNameDate= null;
			sheetNum=0;
		}	
		  
		//interFileSeq;
		logger.debug(" fileStatus :: "+fileStatus);
		return fileStatus;
	} // End of fetchFileData() method


	private SchemeBulkLoadConfVo addEntityAttribute(Connection connection, StringBuffer dataTypes, List recordList, SchemeBulkLoadConfVo schemeBulkLoadVo,String fileDate)throws Exception{

		PreparedStatement ps = null;
		String questinMark;
		int count=1;
		int insertedRecord;
		String errorColumn = null;
		String errorValue = null;
		try {
			if(headerAdd==0){
				logger.debug("Type :: "+schemeBulkLoadVo.getType());
				columnName = dataTypes.append(getHeaderColValue(connection)).toString();
				logger.debug("StrinbBuffer :: "+dataTypes);
				//columnName = dataTypes.substring(0, dataTypes.length()-1);
				columnArr = columnName.split(",");
				headerAdd++;
			}
			StringBuffer procParmList = new StringBuffer();
			for (int i = 0; i < columnArr.length; i++) {
				procParmList.append("?,");
			}

			logger.debug("COLUMN NAME :: "+columnName);
			getColumnConstValue(recordList,schemeBulkLoadVo.getFileId(),fileDate, connection);
			logger.debug("RECORD LIST :: "+recordList);

			questinMark = procParmList.toString();
			questinMark = questinMark.substring(0, questinMark.length()-1);
			String query = "INSERT INTO "+schemeBulkLoadVo.getDestinationTable()+"("+columnName+") VALUES ("+questinMark+")";
			ps = connection.prepareStatement(query);
			for(int inValue=0; inValue<columnArr.length; inValue++){
				errorColumn = columnArr[inValue];
				errorValue = recordList.get(inValue).toString();
				if(columnArr[inValue].contains("DATE")){
					String dateValue= recordList.get(inValue).toString();
					//logger.debug("DATE LENGTH :: "+recordList.get(inValue).toString());
					SimpleDateFormat format1 = new SimpleDateFormat("dd-MMM-yyyy");
					Date utilDate = format1.parse(recordList.get(inValue).toString());
					java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
					ps.setDate(count, sqlDate);
				}else{
					ps.setString(count, recordList.get(inValue).toString());
				}
				count++;
			}
			insertedRecord = ps.executeUpdate();
			if(insertedRecord>0){
				ExceptionVo exceptionVo = new ExceptionVo();
				exceptionVo.setMsgCode("SUCCESS");
				exceptionVo.setMsgDescription("RECORD INSERTED SUCCESSFULLY");
				schemeBulkLoadVo.setExceptionVo(exceptionVo);
				connection.commit();
			}
			logger.debug("Records Inserted Successfully ");
			//getColumnConstValue();
		} catch (Exception e){
			ExceptionVo exceptionVo = new ExceptionVo();
			exceptionVo.setMsgCode("FAIL");
			exceptionVo.setMsgDescription("ERROR > "+e.getMessage());
			schemeBulkLoadVo.setExceptionVo(exceptionVo);
			e.printStackTrace();
		}finally{
			try {
				if(ps!=null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return schemeBulkLoadVo;
	}

	private String getHeaderColValue(Connection connection)throws Exception{
		PreparedStatement ps = null;
		ResultSet result = null;
		StringBuffer sb =null;
		try {
			ps= connection.prepareStatement("SELECT CELL_TYPE FROM SCHEME_BULK_COLUMN_TEMP WHERE SHEET_NUM=?");
			ps.setInt(1, 999999);
			result = ps.executeQuery();
			sb = new StringBuffer();
			while(result.next()){
				sb.append(result.getString("CELL_TYPE")+",");
			}

		} catch (Exception e) {
			throw e;
		}finally{
			if(ps!=null){
				result.close();
				ps.close();
			}
		}
		return sb.toString().substring(0, sb.toString().length()-1);
	}

	private void getColumnConstValue(List recordList, int fileId, String fileDate,Connection con) throws ParseException, SQLException, Exception{
		String fileDateArr[] = fileDate.split("_");
		SimpleDateFormat format = new SimpleDateFormat("ddMMyyyy");
		Date parsed = format.parse(fileDateArr[fileDateArr.length-1]);
		sourceDate = new SimpleDateFormat("dd-MMM-yyyy").format(parsed);
		fileNameDate = sourceDate;
		long sqlDlProcTransSeq = 0;
		String sqlIdentifier = "SELECT SEQ_DL_PROC_TRANS.NEXTVAL FROM DUAL";
		PreparedStatement pst = con.prepareStatement(sqlIdentifier);
		ResultSet rs = pst.executeQuery();

		if(rs.next()){
			sqlDlProcTransSeq = rs.getLong(1);
		}
		rs.close();
		pst.close();
		recordList.add(feedNum);
		recordList.add(sourceDate);
		if(fileId==4){
		recordList.add(schemeFileName);
		}else{
			recordList.add(fileFullName);
		}
		recordList.add("0");
		recordList.add(circleCode);
		recordList.add(sqlDlProcTransSeq);
		recordList.add("Y");
		recordList.add("N");
		sourceDate = new SimpleDateFormat("dd-MMM-yyyy").format( new Date().getTime()) ;
		recordList.add("NO_REASON");
		recordList.add(sourceDate);
		
		if(rs!=null){
			rs.close();
		}
		if(pst!=null){
			pst.close();
		}

	}

	/*	public String getFileDate(String fullFileName){

	}*/

	private SchemeBulkLoadConfVo getDestTabColValue(String fileHeaderName, Connection connection, SchemeBulkLoadConfVo schemeBulkconfVo) throws Exception{
		//logger.debug("Fetching value from Mapping table");
		String fieldName = schemeBulkconfVo.getMappingFieldName();
		String displayName = schemeBulkconfVo.getMappingFieldHeaderName();
		String mapTableName= schemeBulkconfVo.getMappingTable();
		ExceptionVo exceptionVo;
		PreparedStatement ps = null;
		ResultSet result =null;
		try{
			logger.debug("SELECT "+fieldName+" FROM "+mapTableName+" WHERE "+displayName+"="+fileHeaderName+ "AND TYPE=");
			String query = "SELECT "+fieldName+" FROM "+mapTableName+" WHERE "+displayName+"=? AND TYPE=?";
			ps = connection.prepareStatement(query);
			ps.setString(1, fileHeaderName);
			ps.setString(2, schemeBulkconfVo.getType());
			result = ps.executeQuery();
			if(result.next()){
				schemeBulkconfVo.setColumnNames(result.getString(fieldName));	
			}
			exceptionVo = new ExceptionVo();
			exceptionVo.setMsgCode("SUCCESS");
			schemeBulkconfVo.setExceptionVo(exceptionVo);
		}catch(Exception e){
			exceptionVo = new ExceptionVo();
			exceptionVo.setMsgCode("FAIL");
			exceptionVo.setMsgDescription("Exception occured in fetching column values from Mapping table");
			schemeBulkconfVo.setExceptionVo(exceptionVo);
			throw e;
		}finally{
			if(result!=null){
				try {
					result.close();
					ps.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return schemeBulkconfVo;
	}


	private List<SchemeBulkLoadConfVo> getSchemBulkConfData(Connection connection, int file_id) throws Exception {
		logger.debug("Entered into getSchemBulkConfData() method");
		PreparedStatement ps = null;
		ResultSet result = null;
		List<SchemeBulkLoadConfVo> schemBulkLoadConfList = null;
		try {
			String query = "SELECT * FROM SCHEME_BULK_LOAD_CONF_TEMP WHERE FILE_ID=? ORDER BY FILE_ID ASC";
			//String query = "SELECT * FROM SCHEME_BULK_UPLOAD_CONFIG WHERE FILE_ID=? ORDER BY FILE_ID ASC";
			ps = connection.prepareStatement(query);
			ps.setInt(1, file_id);
			result = ps.executeQuery();
			schemBulkLoadConfList = new ArrayList<SchemeBulkLoadConfVo>();
			SchemeBulkLoadConfVo schemeBulkLoad = null;
			while (result.next()) {

				schemeBulkLoad = new SchemeBulkLoadConfVo();

				String loadingMethod = result.getString("LOADING_METHOD");

				schemeBulkLoad.setConfName(result.getString("CONF_NAME"));
				schemeBulkLoad.setSheetName(result.getString("SHEET_NAME"));
				int sheetNum = result.getInt("SHEET_NUM");
				schemeBulkLoad.setParamNum(result.getInt("COL_READ_COUNT"));
				schemeBulkLoad.setFileId(result.getInt("FILE_ID"));
				schemeBulkLoad.setSheetNum(sheetNum);
				schemeBulkLoad.setHeaderRows(result.getInt("HEADER_ROWS"));
				schemeBulkLoad.setLoadingMethod(loadingMethod);
				schemeBulkLoad.setProcedureName(result.getString("PROCEDURE_NAME"));

				if("D".equalsIgnoreCase(loadingMethod)){
					schemeBulkLoad.setMappingTable(result.getString("MAPPING_TABLE"));
					schemeBulkLoad.setMappingTableJndi(result.getString("MAPPING_TABLE_CONNECTION_POOL"));
					schemeBulkLoad.setMappingFieldHeaderName(result.getString("MAPPING_FIELD_HEADER_NAME"));
					schemeBulkLoad.setMappingFieldName(result.getString("MAPPING_FIELD_NAME"));
					schemeBulkLoad.setDestinationTable(result.getString("DESTINATION_TABLE_NAME"));
					schemeBulkLoad.setType(result.getString("TYPE"));
					schemeBulkLoad.setFeedNumber(result.getString("FEED_NUMBER"));
				}else{
					schemeBulkLoad.setMappingTable(result.getString("MAPPING_TABLE"));
					schemeBulkLoad.setFeedNumber(result.getString("FEED_NUMBER"));
					schemeBulkLoad.setDestinationTable(result.getString("DESTINATION_TABLE_NAME"));
					schemeBulkLoad.setFeedMapping(result.getString("FEED_MAPPING"));
					schemeBulkLoad.setCellValue(getBulkLoadColumnList(connection,schemeBulkLoad));
				}
				schemBulkLoadConfList.add(schemeBulkLoad);
			}
			result.close();
			ps.close();

		} catch (SQLException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		}
		return schemBulkLoadConfList;
	}


	private List<SchemeBulkColumnVo> getBulkLoadColumnList(Connection connection, SchemeBulkLoadConfVo schemeBulkLoad) throws Exception {
		PreparedStatement ps = null;
		ResultSet result = null;
		List<SchemeBulkColumnVo> bulkColumnList = null;
		try {
			String sql = "SELECT CELL_NAME, CELL_NUM, CELL_TYPE, DB_DATA_TYPE FROM SCHEME_BULK_COLUMN_TEMP WHERE SHEET_NUM = ? AND FILE_ID = ? ORDER BY  CELL_NUM ASC";
			ps = connection.prepareStatement(sql);
			ps.setInt(1, schemeBulkLoad.getSheetNum());
			ps.setInt(2, schemeBulkLoad.getFileId());
			result = ps.executeQuery();
			SchemeBulkColumnVo bulkColumnVo = null;
			bulkColumnList = new ArrayList<SchemeBulkColumnVo>();
			StringBuffer stringBuffer = new StringBuffer();

			while (result.next()) {
				bulkColumnVo = new SchemeBulkColumnVo();
				bulkColumnVo.setCellName(result.getString("CELL_NAME"));
				bulkColumnVo.setCellNum(result.getInt("CELL_NUM"));
				bulkColumnVo.setCellType(result.getString("CELL_TYPE"));
				bulkColumnVo.setDbDataType(result.getString("DB_DATA_TYPE"));

				bulkColumnList.add(bulkColumnVo);
				stringBuffer.append(result.getString("DB_DATA_TYPE") + ",");
			}
			schemeBulkLoad.setDbType(stringBuffer.toString().split(","));

		} catch (SQLException e) {
			throw e;
		}catch (Exception e) {
			throw e;
		}
		finally{
			if(result!=null){
				try {
					result.close();
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return bulkColumnList;
	}


	private String callProcEntityAddAttrStamp(Connection conn, String feedNum, String fileDate, String fileName, String circle, String procName ) throws Exception{
		String procOutput = null;
		try {
			logger.debug("FEED NUMBER :: "+feedNum+"\t fileDate::: "+fileDate+"\t fileName:: "+fileName+"\t cir:: "+circle+"\t proc:: "+procName);


			if(conn !=null){
				CallableStatement call = conn.prepareCall("{call "+procName+"(?,?,?,?,?)}");
				call.setInt(1, Integer.parseInt(feedNum));
				logger.debug(" getSqlDate(fileDate) :::: "+ getSqlDate(fileDate));
				call.setDate(2, getSqlDate(fileDate));
				call.setString(3, fileName);
				call.setString(4, circle);
				call.registerOutParameter(5 , OracleTypes.VARCHAR);
				call.execute();
				procOutput = call.getString(5);
				logger.debug("procOutput :::: "+procOutput);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return procOutput;
		}
		return procOutput;	
	}

	private String callProcDlpPerformConfig(Connection conn, String feedNum, String fileDate, String fileName, String circle, String procName, String userName) throws Exception{

		String procOutput = null;
		PreparedStatement ps = null;
		ResultSet result = null;
		int reloadAttamp = 0;
		logger.debug("procName :: "+procName);
		try {
			if(conn !=null){
				ps = conn.prepareStatement("SELECT RELOAD_ATTEMPTS FROM SCHEME_BULK_LOAD_FILE_STATUS WHERE FILE_NAME =?");
				ps.setString(1, fileName);
				result = ps.executeQuery();
				if(result.next()){
					reloadAttamp = result.getInt("RELOAD_ATTEMPTS");
				}

				CallableStatement call = conn.prepareCall("{call "+procName+"(?,?,?,?,?,?,?)}");
				call.setInt(1, Integer.parseInt(feedNum));
				call.setDate(2, getSqlDate(fileDate));
				call.setString(3, fileName);
				call.setInt(4, reloadAttamp);
				call.setString(5, circle);
				call.setString(6, userName);
				call.registerOutParameter(7 , OracleTypes.VARCHAR);
				call.execute();
				procOutput = call.getString(7);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return procOutput;
		}finally{

			try {
				if(result!=null)
					result.close();

				if(ps!=null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.debug("procOutput ::::::::::: "+procOutput);
		return procOutput;
	}

	/*private String updateSchemMapping(Connection con, int schemeId, int compId, String fileName, String tableName){
		PreparedStatement ps =null;
		int resultCount;
		String resultStatus="FAIL From DLP_SCHEME_COMP_MAPPING";
		logger.debug("FILE FULL NAME >> "+fileName);
		try {
			ps = con.prepareStatement("UPDATE DLP_SCHEME_COMP_MAPPING SET COVERAGE_FLAG=?, FILE_NAME=? WHERE SCHEME_ID=? AND COMPONENT_ID=?");
			ps.setString(1, "E");
			ps.setString(2, fileName);
			ps.setInt(3, schemeId);
			ps.setInt(4, compId);
			resultCount = ps.executeUpdate();
			if(resultCount>0)
				resultStatus = "SUCCESS";

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return resultStatus;
	}*/
	
	private boolean matchSchemeCompMappingFile(Connection con, int schemeId, int compId, String fileName) throws SQLException{
		PreparedStatement ps =null;
		int resultCount;
		boolean resultStatus=false;
		ResultSet rs=null;
		//String resultStatus="FAIL From DLP_SCHEME_COMP_MAPPING";
		logger.debug("FILE FULL NAME >> "+fileName+"\t scid:: "+schemeId+"\t compId::"+ compId+"\t connection:: "+con.isClosed());
		try {
			ps = con.prepareStatement("SELECT FILE_NAME FROM DLP_SCHEME_COMP_MAPPING WHERE  FILE_NAME=? AND SCHEME_ID=? AND COMPONENT_ID=? AND VALIDITY_FLAG='Y'");
			ps.setString(1, fileName);
			ps.setInt(2, schemeId);
			ps.setInt(3, compId);
			//ps.setString(4, "Y");
			
			rs = ps.executeQuery();
			
			if(rs.next()){
				resultStatus = true;
				logger.debug("resultCount :::: "+rs+"\t resultStatus:: "+resultStatus+"\t "+rs.getString("FILE_NAME"));
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(ps!=null){
				ps.close();
			}
			if(rs!=null){
				rs.close();
			}
		}
		logger.debug("resultStatus :::: "+resultStatus);
		return resultStatus;
	}

	private java.sql.Date getSqlDate(String date) throws ParseException{
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		Date parsed = format.parse(date);
		return  new java.sql.Date(parsed.getTime());
	}






	/*	
public String fileReloaded(File file, Connection conn) throws SQLException{

		PreparedStatement ps = null;
		ResultSet result = null;
		int reloadCount=0;
		int noCount = 0;
		StringBuffer sb = new StringBuffer();
		ps = conn.prepareStatement("SELECT RELOAD_ATTEMPTS, ERROR_DESC FROM SCHEME_BULK_LOAD_FILE_STATUS WHERE FILE_NAME=? AND TRUNC(LOAD_DATE_TIME)= TRUNC(SYSDATE)");
		ps.setString(1, file.getName());
		result = ps.executeQuery();
		if(result.next()){
			reloadCount = result.getInt("RELOAD_ATTEMPTS");	
			String status = result.getString("ERROR_DESC");
			if("SUCCESS".equalsIgnoreCase(status)){
				sb.append("Y,");
				sb.append(reloadCount);
			}else{
				sb.append("N,");
				sb.append(reloadCount);
			}
		}else{
			sb.append("N,");
			sb.append(reloadCount);
			noCount++;
		} 
		if(reloadCount>=0 && noCount==0){
			reloadCount++;
		}
		result.close();
		ps.close();
		return sb.toString();
	}
	 */

	private int fileReloaded(File file, Connection conn) throws SQLException{

		PreparedStatement ps = null;
		ResultSet result = null;
		int reloadCount=0;
		StringBuffer sb = new StringBuffer();
		ps = conn.prepareStatement("SELECT RELOAD_ATTEMPTS, ERROR_DESC FROM SCHEME_BULK_LOAD_FILE_STATUS WHERE FILE_NAME=? AND TRUNC(LOAD_DATE_TIME)= TRUNC(SYSDATE)");
		ps.setString(1, file.getName());
		result = ps.executeQuery();
		if(result.next()){
			reloadCount++;
		} 
		result.close();
		ps.close();
		return reloadCount;
	}

	public SchemeBulkLoadConfVo persitData(ArrayList fileRecordList, SchemeBulkLoadConfVo schemBulkLoadVo,Connection connection, int sheetNum, File file, int fileId, String circle, long interFileSeq, int fileRowId, int fileReload) throws Exception{

		PreparedStatement ps = null;
		int rowInsert;
		String dbTypes[] = schemBulkLoadVo.getDbType();
		String questionMark;
		StringBuffer procParmList = null;
		ExceptionVo exceptionVo;
		String value = null;
		try {
			addExtraColumn(connection, fileRecordList, schemBulkLoadVo, file, fileId, circle, interFileSeq, fileRowId, sheetNum, fileReload);

			procParmList = new StringBuffer(); 
			int dbTypeSize = dbTypes.length;
			for (int i = 0; i < dbTypeSize; i++) {
				procParmList.append("?,");
			}

			questionMark = procParmList.toString();
			questionMark = questionMark.substring(0, questionMark.length()-1);
			logger.debug("COUNT :: "+dbTypeSize);
			logger.debug("questionMark "+questionMark);
			logger.debug(fileRecordList);
			//logger.debug("schemBulkLoadVo DB TYPE >> "+schemBulkLoadVo.get);

			String query = "INSERT INTO "+schemBulkLoadVo.getDestinationTable()+" VALUES("+questionMark+")";
			//logger.debug("QUERY >> "+query);
			ps = connection.prepareStatement(query);
			int indexValue = 1;
			for (int recordValue = 0; recordValue < dbTypes.length; recordValue++) {
				//value = fileRecordList.get(recordValue).toString();
				//System.out.print(fileRecordList);
				if("VARCHAR".equalsIgnoreCase(dbTypes[recordValue])){

					if(fileRecordList.get(recordValue) != null){
						String listVal = fileRecordList.get(recordValue).toString();
						ps.setString(indexValue, listVal);
						value = listVal;
					}else{
						ps.setString(indexValue, null);
					}
				}

				if("NUMBER".equalsIgnoreCase(dbTypes[recordValue])){
					//String listVal = fileRecordList.get(recordValue).toString();
					long listVal = Long.parseLong(fileRecordList.get(recordValue).toString());
					ps.setLong(indexValue, listVal);
					value = Long.toString(listVal);				

				}

				if("DATE".equalsIgnoreCase(dbTypes[recordValue])){
					if(fileRecordList.get(recordValue) != null){
						String listVal = fileRecordList.get(recordValue).toString();
						ps.setString(indexValue, listVal);
						value = listVal;
					}
				} 
				//logger.debug("RECORDVALUE :: "+indexValue +" > "+listVal);
				indexValue++;
			}
			boolean rsFlag = ps.execute();
			//logger.debug("RS FLAG >> "+rsFlag);

			exceptionVo = new ExceptionVo();
			exceptionVo.setMsgCode("SUCCESS");
			exceptionVo.setMsgDescription("SUCCESS");
			schemBulkLoadVo.setExceptionVo(exceptionVo);
		} catch (Exception e) {
			exceptionVo = new ExceptionVo();
			exceptionVo.setMsgCode("FAIL");
			exceptionVo.setMsgDescription("FAIL TO LOAD SHEET NUMBER "+sheetNum+" FOR "+value);
			schemBulkLoadVo.setExceptionVo(exceptionVo);
			e.printStackTrace();

		}
		finally{
			if(ps!=null)
				ps.close();
		}

		return schemBulkLoadVo;
	}


	private void addExtraColumn(Connection con, ArrayList recordList, SchemeBulkLoadConfVo schemeBulkLoadVo, File file, int fileId, String circle, long interFileSeq, int fileRowId, int sheetNum, int fileReload) throws ParseException, SQLException
	{
		int paramNum = schemeBulkLoadVo.getParamNum();

		int extraSize =0;

		switch(sheetNum){
		case 0:
			if(recordList.size()>paramNum){
				extraSize = recordList.size()-paramNum;	
			}
			break;  
		case 1:
			if(recordList.size()>paramNum){
				extraSize = recordList.size()-paramNum;	
			}
			break;
		case 2:
			if(recordList.size()>paramNum){
				extraSize = recordList.size()-paramNum;	
			}
			break;
		case 3:
			if(recordList.size()>paramNum){
				extraSize = recordList.size()-paramNum;	
			}
			break;
		default:
			logger.debug("No sheet needs to be read. . . . .");
		}

		for(int i=1; i<=extraSize; i++){
			recordList.remove(recordList.size()-1);
		}
		String[] fileNameArr = file.getName().split("\\.");
		String fileFirstName = fileNameArr[0];
		String fileDateArr[] = fileFirstName.split("_");
		SimpleDateFormat format = new SimpleDateFormat("ddMMyyyy");
		Date parsed = format.parse(fileDateArr[fileDateArr.length-1]);
		String sourceDate = new SimpleDateFormat("dd-MMM-yyyy").format(parsed);

		/**
		 * Generate sequence for insert each data
		 */
		long sqlDlProcTransSeq = 0;
		String sqlIdentifier = "SELECT SEQ_DL_PROC_TRANS.NEXTVAL FROM DUAL";
		PreparedStatement pst = con.prepareStatement(sqlIdentifier);
		ResultSet rs = pst.executeQuery();

		if(rs.next()){
			sqlDlProcTransSeq = rs.getLong(1);
		}
		if(sheetNum==0){
			recordList.add(file.getName());			
			recordList.add(interFileSeq);
			recordList.add(fileRowId);
			recordList.add(1);
			recordList.add(0);
			recordList.add(schemeBulkLoadVo.getFeedNumber());
			recordList.add(sourceDate);
			recordList.add(generateFileName(file.getName(), schemeBulkLoadVo.getFeedMapping()));
			recordList.add(fileReload);
			recordList.add(circle);
			recordList.add(sqlDlProcTransSeq);
			recordList.add("Y");
			recordList.add("N");
			recordList.add(null);
			recordList.add(new SimpleDateFormat("dd-MMM-yyyy").format( new Date().getTime()));
			recordList.add(null);
			recordList.add(null);
			recordList.add(null);
			recordList.add(null);
			recordList.add(null);
		}
		if(sheetNum==1){
			recordList.add(file.getName());			
			recordList.add(interFileSeq);
			recordList.add(fileRowId);
			recordList.add(0);
			recordList.add(schemeBulkLoadVo.getFeedNumber());
			recordList.add(sourceDate);
			recordList.add(generateFileName(file.getName(), schemeBulkLoadVo.getFeedMapping()));
			recordList.add(fileReload);
			recordList.add(circle);
			recordList.add(sqlDlProcTransSeq);
			recordList.add("Y");
			recordList.add("N");
			recordList.add(null);
			recordList.add(new SimpleDateFormat("dd-MMM-yyyy").format( new Date().getTime()));
		}
		if(sheetNum==2){
			recordList.add(5,0);
			recordList.add(file.getName());
			recordList.add(interFileSeq);
			recordList.add(fileRowId);
			recordList.add(0);
			recordList.add(schemeBulkLoadVo.getFeedNumber());
			recordList.add(sourceDate);
			recordList.add(generateFileName(file.getName(), schemeBulkLoadVo.getFeedMapping()));
			recordList.add(fileReload);
			recordList.add(circle);
			recordList.add(sqlDlProcTransSeq);
			recordList.add("Y");
			recordList.add("N");
			recordList.add(null);
			recordList.add(new SimpleDateFormat("dd-MMM-yyyy").format( new Date().getTime()));
			recordList.add(null);
			recordList.add(null);
			recordList.add(null);
			recordList.add(null);
			recordList.add(null);
		}
		if(sheetNum==3){
			recordList.add(file.getName());
			recordList.add(interFileSeq);
			recordList.add(fileRowId);
			recordList.add(0);
			recordList.add(schemeBulkLoadVo.getFeedNumber());
			recordList.add(sourceDate);
			recordList.add(generateFileName(file.getName(), schemeBulkLoadVo.getFeedMapping()));
			recordList.add(fileReload);
			recordList.add(circle);
			recordList.add(sqlDlProcTransSeq);
			recordList.add("Y");
			recordList.add("N");
			recordList.add(null);
			recordList.add(new SimpleDateFormat("dd-MMM-yyyy").format( new Date().getTime()));
		}
		
		if(rs!=null){
			rs.close();
		}
		if(pst!=null){
			pst.close();
		}
	}

	public String generateFileName(String fileName, String values){
		String[] fileBreak = fileName.split("_");
		StringBuffer sfileName = new StringBuffer();
		int count=1;
		for(String fileS : fileBreak){
			if(count==3){
				sfileName.append(fileS+"_"+values+"_");
			}else{
				sfileName.append(fileS+"_");
			}
			count++;
		}
		return sfileName.substring(0, sfileName.length()-1).toString();
	}


	private String persistFileDetail(String userName, String fileName, String fileStatus, Connection con) throws Exception{

		PreparedStatement ps = null;
		PreparedStatement checkFilePs=null;
		int rowCount = 0;
		String recordStatus = "FAIL";
		ResultSet result;
		int reloadStatus=0;
		try {
			String query;
			query = "SELECT RELOAD_ATTEMPTS FROM SCHEME_BULK_LOAD_FILE_STATUS WHERE FILE_NAME=?";
			checkFilePs = con.prepareStatement(query);
			checkFilePs.setString(1, fileName);
			result = checkFilePs.executeQuery();
			if(result.next()){
				reloadStatus = result.getInt("RELOAD_ATTEMPTS");
				reloadStatus = reloadStatus+1;
				logger.debug("Reload attampts :: "+reloadStatus);
			}

			if(reloadStatus==0){
				query = "INSERT INTO SCHEME_BULK_LOAD_FILE_STATUS VALUES (?,?,SYSDATE,?,?,?)";
				ps = con.prepareStatement(query);
				ps.setString(1, userName);
				ps.setString(2, fileName);
				ps.setString(3, "FILE LOADED");
				ps.setString(4, fileStatus);
				ps.setInt(5, 0);
				rowCount = ps.executeUpdate();
				logger.debug(rowCount +" Inserted successfully ");
			}else{
				query = "UPDATE SCHEME_BULK_LOAD_FILE_STATUS SET LOAD_DATE_TIME= SYSDATE, ERROR_DESC=?, RELOAD_ATTEMPTS=?  WHERE FILE_NAME=?";
				ps = con.prepareStatement(query);
				ps.setString(1, fileStatus);
				ps.setInt(2, reloadStatus);
				ps.setString(3, fileName);
				rowCount = ps.executeUpdate();
				logger.debug(rowCount +" Updated successfully ");
			}
			if (rowCount > 0) {
				recordStatus = "SUCCESS";
				logger.debug("FILE INFORMATION UPDATED SUCCESSFULLY");
			}
			con.commit();
		} catch (Exception e) {
			recordStatus = "FAIL";
			logger.debug("FAIL TO UPDATE FILE INFORMATION");
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			throw e;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
				if (con != null) {
					con.close();
				}
				if(checkFilePs != null){
					checkFilePs.close();
				}

			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return recordStatus;
	}




	private void updateDestinationTable(String circleCode, String fileName, String distinationTableName, Connection con) throws Exception{
		PreparedStatement ps = null;
		int rowCount = 0;
		try {
			String query;
			query = "UPDATE "+distinationTableName+" SET IPS_MOVEMENT_FLAG = 'R' WHERE CIRCLE = ? AND FILE_NAME = ? AND IPS_MOVEMENT_FLAG = 'Y' ";
			ps = con.prepareStatement(query);
			ps.setString(1, circleCode);
			ps.setString(2, fileName);
			rowCount = ps.executeUpdate();
			logger.debug(rowCount +" Updated successfully ");
			if (rowCount > 0) {
				logger.debug("FILE INFORMATION UPDATED SUCCESSFULLY");
			}
		} catch (SQLException e1) {
			throw e1;
		}catch (Exception e) {
			throw e;
		}finally{

			try {
				if(ps!=null)
					ps.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	
	
	
	
	
	
	
	//============ Bulk Upload Doc File  ========================//
	
	@Override
	public DocUploadFile validateDocFileType(String fileExt) throws Exception
	{
		try
		{
			List<DocUploadFile> doc = jdbcTemplate.query(BulkQueries.DOC_FILE, new Object[]{fileExt}, new RowMapper<DocUploadFile>(){
				@Override
				public DocUploadFile mapRow(ResultSet rs, int arg1) throws SQLException {
					DocUploadFile duf = new DocUploadFile();
					duf.setFileExt(rs.getString("FILE_EXTENSION"));
					duf.setFileNameSize(rs.getInt("FILE_NAME_SIZE"));
					duf.setFileSize(rs.getInt("FILE_SIZE"));
					return duf;
				}
			});
			if(doc != null && !doc.isEmpty())
				return doc.get(0);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	@Override
	public int insertDocTypeValues(DocTypeList docTypeList)
	{
		//System.out.println("BulkUploadDAOImpl || insertDocTypeValues || file name:"+docTypeList.getUploadDocFile().getOriginalFilename());
		int val = 0;
		try
		{
			val =	jdbcTemplate.update(BulkQueries.DOC_FILE_INSERT, new Object[]{docTypeList.getUploadDocFile().getOriginalFilename(), docTypeList.getFilePath(),
					docTypeList.getUserName(), docTypeList.getCircleCode()});
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return val;
	}
	
		
	@Override
	public List<DocTypeList> getDocListType() throws Exception
	{
		List<DocTypeList> getList=null;
		try
		{
			getList=jdbcTemplate.query(BulkQueries.DOC_FILE_DROPDOWN, new RowMapper<DocTypeList>(){
				@Override
				public DocTypeList mapRow(ResultSet rs,int rowNum) throws SQLException
				{
					DocTypeList docType=new DocTypeList();
					docType.setDocFileType(rs.getString("LISTTYPE"));
					docType.setTypeId(rs.getInt("TYPE_ID"));
					return docType;
				}
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		//System.out.println("lis type ::::::>>>>>>>>>>>s"+getList.get(1).getDocFileType());
		//System.out.println("lis type id  ::::::>>>>>>>>>>>s"+getList.get(1).getTypeId());
		return getList;
	}
	
	
	
	
	
	
	/*@Override
	public String insertDocTypeValues(DocTypeList docTypeList)
	{
	//	User appUser = (User)httpSession.getAttribute("appUser");
		System.out.println("BulkUploadDAOImpl || insertDocTypeValues || file name:"+docTypeList.getUploadDocFile().getOriginalFilename());
		String query="insert into Dlp_Doc_Upload_File_Det (file_name,path,user_id,circle) values(?,?,?,?)";
		Connection con=null;
		PreparedStatement ps=null;
		int val=0;
		try
		{
			con=jdbcTemplate.getDataSource().getConnection();
			//boolean checkValidity=validateDocFileType(con,ps,docTypeList);
			ps=con.prepareStatement(query);
			ps.setString(1,docTypeList.getUploadDocFile().getOriginalFilename());
			ps.setString(2, System.getProperty("DLP_FILE_REPOSITORY"));
			//ps.setString(3,appUser.getUserName());
			//ps.setString(4, appUser.getUserCircleCode());
			val=ps.executeUpdate();
			
		}
		catch(Exception e)
		{
			System.out.println("Exception raised  . Exception is:"+e);
		}
		finally{
			if(ps!=null){
				try {
					ps.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return val+"";
	}
	*/
	
	@Override
	public int insertMailTypeValues(DocTypeList docTypeList,String line) throws Exception
	{
	//	User appUser = (User)httpSession.getAttribute("appUser");
		System.out.println("BulkUploadDAOImpl || insertDocTypeValues || file name:"+docTypeList.getUploadDocFile().getOriginalFilename());
		String query="insert into Dlp_Doc_File_Mail_List (file_name,Dsm2_Ref_Code,updated_date) values(?,?,?)";
		Connection con=null;
		PreparedStatement ps=null;
		int val=0;
		try
		{  
			con=jdbcTemplate.getDataSource().getConnection();
			//boolean checkValidity=validateDocFileType(con,ps,docTypeList);
			ps=con.prepareStatement(query);
			ps.setString(1,line.split("\\,")[0]);
			ps.setString(2,line.split("\\,")[1]);
			ps.setDate(3, new java.sql.Date(new java.util.Date().getTime()));
			val=ps.executeUpdate();
			
		}
		catch(Exception e)
		{
			System.out.println("Exception raised  . Exception is:"+e);
		}
		
		
		return val;
	}
	
	
	/*public boolean validateDocFileType(DocTypeList docTypeList)
	{
		boolean isValidFile=false;
		int dbFileNameSize=0;
		long dbFileSize=0;
		Connection con=null;
		PreparedStatement ps=null;
		try
		{
		con=jdbcTemplate.getDataSource().getConnection();
		int fileNameSize=docTypeList.getUploadDocFile().getOriginalFilename().split("\\.")[0].length();
		long fileSize=docTypeList.getUploadDocFile().getSize();
		ps=con.prepareStatement("select * from Dlp_Doc_upload_file_val_master where File_Extension=?");
		ps.setString(1,docTypeList.getUploadDocFile().getOriginalFilename().split("\\.")[1]);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			dbFileNameSize=rs.getInt("File_Name_Size");
			dbFileSize=rs.getLong("file_size");
			if(dbFileNameSize!=0 && dbFileSize!=0 && fileNameSize<=dbFileNameSize && fileSize<=(dbFileSize*1024))
			{
				isValidFile=true;
			}
			
		}
		}
		catch(Exception e)
		{
			System.out.println("Exception raised. Exception is:"+e);
			
		}
		return isValidFile;
	}*/
	@Override
	public List<UploadMailStatusData> getUploadData(UploadMailStatusData uploadMailStatusData) throws Exception
	{
		Connection con=null;
		List<UploadMailStatusData> uploadMailStatus=null;
		
		try
		{
			
			//System.out.println("File validation check || start date:"+uploadMailStatusData.getStartDateStatus());
			con=jdbcTemplate.getDataSource().getConnection();
			String dataFileName=("".equals(uploadMailStatusData.getDataFileName()) ||uploadMailStatusData.getDataFileName()==null)?"'%%'":"upper('%"+uploadMailStatusData.getDataFileName()+"%')";
			String query="select file_name,date_time,user_id,seq_no from Dlp_Doc_Upload_File_Det where circle=? and trunc(date_time) between ? and ? and upper(file_name) like "+dataFileName+" order by seq_no";
			uploadMailStatus=jdbcTemplate.query(query,new Object[]{uploadMailStatusData.getCircleCode(),uploadMailStatusData.getStartDateStatus(),uploadMailStatusData.getEndDateStatus()} ,new RowMapper<UploadMailStatusData>()
					{
				@Override 
				public UploadMailStatusData mapRow(ResultSet rs,int count) throws SQLException
				{
					UploadMailStatusData uploadMailStatus=new UploadMailStatusData();
					uploadMailStatus.setDataFileName(rs.getString("file_name"));
					uploadMailStatus.setInsertedDate(rs.getDate("date_time"));
					uploadMailStatus.setUserId(rs.getString("user_id"));
					uploadMailStatus.setSeqNo(rs.getInt("seq_no"));
					return uploadMailStatus;
				}
 				
					});
			
		}
		catch(Exception e)
		{
			//System.out.println("BulkUploadDAoImpl || getUploadData || Exception raised: Exception is:"+e);
		}
		return uploadMailStatus;
		
		
	}
	
	@Override
	public List<UploadMailStatusData> getMailData(UploadMailStatusData uploadMailStatusData) throws Exception
	{
		Connection con=null;
		List<UploadMailStatusData> uploadMailStatus=null;
		try
		{
			//System.out.println("getMailData StartDate StartDate:"+uploadMailStatusData.getStartDateStatus()+" || end date:"+uploadMailStatusData.getEndDateStatus()+" || dsm_code:"+uploadMailStatusData.getDsm2RefCode()+"|| "+uploadMailStatusData.getMailStatus()+" || "+uploadMailStatusData.getMailSendStatus());
			con=jdbcTemplate.getDataSource().getConnection();
			String dataFile=("".equals(uploadMailStatusData.getDataFileName()) ||uploadMailStatusData.getDataFileName()==null)?"'%%'":"upper('%"+uploadMailStatusData.getDataFileName()+"%')";
			String dsmRefCode=("".equals(uploadMailStatusData.getDsm2RefCode()) ||uploadMailStatusData.getDsm2RefCode()==null)?"'%%'":"upper('%"+uploadMailStatusData.getDsm2RefCode()+"%')";
			String sendStatus=("".equals(uploadMailStatusData.getMailSendStatus()) ||uploadMailStatusData.getMailSendStatus()==null)?"'%%'":"upper('%"+uploadMailStatusData.getMailSendStatus()+"%')";
			String mailStatus=("".equals(uploadMailStatusData.getMailStatus()) ||uploadMailStatusData.getMailStatus()==null)?"'%%'":"upper('%"+uploadMailStatusData.getMailStatus()+"%')";
			//System.out.println("dataFile:"+dataFile+"| dsmRefCode:"+dsmRefCode+" | sendStatus:"+sendStatus+":"+mailStatus);
			String query="select mail_file_name,Dsm2_Ref_Code,insert_date_time,email,Error_Msg,Send_Status,Mail_Status,send_date from Dlp_Doc_File_Mail_List where circle=? and trunc(insert_date_time) between ? and ? and upper(mail_file_name) like "+dataFile+" and upper(DSM2_REF_CODE) like "+dsmRefCode+" and upper(send_Status) like "+sendStatus+" and nvl(upper(Mail_Status),0) like "+mailStatus;
			uploadMailStatus=jdbcTemplate.query(query,new Object[]{uploadMailStatusData.getCircleCode(),uploadMailStatusData.getStartDateStatus(),uploadMailStatusData.getEndDateStatus()},/*
					("".equals(uploadMailStatusData.getDataFileName()) ||uploadMailStatusData.getDataFileName()==null)?"%%":"upper(%"+uploadMailStatusData.getDataFileName()+"%)",
					("".equals(uploadMailStatusData.getDsm2RefCode()) ||uploadMailStatusData.getDsm2RefCode()==null)?"%%":"upper(%"+uploadMailStatusData.getDsm2RefCode()+"%)",
				    ("".equals(uploadMailStatusData.getMailSendStatus()) ||uploadMailStatusData.getMailSendStatus()==null)?"%%":"upper(%"+uploadMailStatusData.getMailSendStatus()+"%)",
				    ("".equals(uploadMailStatusData.getMailStatus()) ||uploadMailStatusData.getMailStatus()==null)?"%0%":"upper(%"+uploadMailStatusData.getMailStatus()+"%)"} ,*/new RowMapper<UploadMailStatusData>()
					{
				@Override 
				public UploadMailStatusData mapRow(ResultSet rs,int count) throws SQLException
				{
					UploadMailStatusData uploadMailStatus=new UploadMailStatusData();
					uploadMailStatus.setDataFileName(rs.getString("mail_file_name"));
					uploadMailStatus.setDsm2RefCode(rs.getString("Dsm2_Ref_Code"));
					uploadMailStatus.setMailInsertDate(rs.getDate("insert_date_time"));
					uploadMailStatus.setEmail(rs.getString("email"));
					uploadMailStatus.setErrorMsg(rs.getString("Error_Msg"));
					uploadMailStatus.setMailSendStatus(rs.getString("Send_Status"));
					uploadMailStatus.setMailStatus(rs.getString("Mail_Status"));
					uploadMailStatus.setSendDate(rs.getDate("send_date"));
					return uploadMailStatus;
				}
					});
			
		}
		catch(Exception e)
		{
			//System.out.println("BulkUploadDAOImpl || getMailData || Exception raised Exception is:"+e);
		}
		return uploadMailStatus;
	}
	
	
	@Override
	public String insertMailDestinationTableNew(File file,SchemeBulkLoadConfVo schemeBulkLoadVo) throws Exception{
		logger.debug("Entered into  insertDestinationTable() method");
		long startTime = new Date().getTime();
		logger.debug("startTime ::: "+startTime);
		Connection connection = null;
		PreparedStatement ps = null;
		BufferedReader br = null;
		String errorMsg = null;
		int count = 0;
		String line = null;
		String subPartition  = null;
		
		try{
			connection = jdbcTemplate.getDataSource().getConnection();
			if(schemeBulkLoadVo.getFileId() == 9){
				try{
					String subPartitionQuery = "select 'PAR_'|| TO_CHAR(sysdate-1,'MON_YYYY_DD')||'_"+schemeBulkLoadVo.getFileCircleCode()+"' as PAR from dual";
					PreparedStatement pst = connection.prepareStatement(subPartitionQuery);	
					ResultSet rs = pst.executeQuery();
					while(rs.next()){
						subPartition=rs.getString("PAR");
					}
					pst.close();
					rs.close();
				}catch(SQLException e){
					e.printStackTrace();
				}
			}
			//String email = "select email from DLP_PAYOUT_HIER_DSM1_TEMP subpartition(PAR_MAR_2016_31_MU) where PRODUCER_ID = ':DSMREFCODE'  and  circle_code =  '"+schemeBulkLoadVo.getFileCircleCode()+"' ";
			
			String email = "select email from DLP_PAYOUT_HIER_DSM1_TEMP subpartition("+subPartition+") where PRODUCER_ID = ':DSMREFCODE'  and  circle_code =  '"+schemeBulkLoadVo.getFileCircleCode()+"' ";
			
			String[] query = generateInsertQueryNew(schemeBulkLoadVo);
			
			if(query[3]!=null){
				return BulkConstants.MANDATORY_COLUMN_REQUIRED + query[3];
			}
			if(query[4] != null){
				return BulkConstants.DESTINATION_COLUMN_ERROR + query[4];
			}
			connection.setAutoCommit(false);
			ps = connection.prepareStatement(query[2]);
			final int batchSize = 6000;
			br = new BufferedReader(new FileReader(file));
			String[] columnNames = query[0].split(BulkConstants.COMMA);
			while ((line = br.readLine()) != null) {
				if(count==0){
					count++;
					continue;
				}logger.debug(count+". line :::: "+line);
				String[] columnData = line.split(BulkConstants.COMMA);
				
				if(schemeBulkLoadVo.getFieldCount()==columnData.length){
				
					for(int i=1;i<columnData.length+1;i++){
					
						if(schemeBulkLoadVo.getMandatoryColumnNames().contains(columnNames[i-1])){

							if(columnNames[i-1].contains(BulkConstants.DATE)){
									if( "".equalsIgnoreCase(columnData[i-1])){
										if(br!=null)
											br.close();
										
										return BulkConstants.MANDATORY_DATA_REQUIRED + count ;
									}
									SimpleDateFormat format1 = null;
									if(columnData[i-1].trim().length()==22 || columnData[i-1].trim().length()==23){
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_AM_PM);
									}else if(columnData[i-1].trim().length()==20 || columnData[i-1].trim().length()==21){
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_24);
									}else 
									{
										format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY);
									}
									Date utilDate = format1.parse(columnData[i-1]);
									java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
									//System.out.println("sqlDate ::: "+sqlDate);
									ps.setDate(i, sqlDate);
								}
							if(columnNames[i-1].contains(BulkConstants.EMAIL)){
								if( "".equalsIgnoreCase(columnData[i-1])){
									if(br!=null)
										br.close();
									return BulkConstants.MANDATORY_DATA_REQUIRED + count ;
								}
								String email420 = (columnData[i-1]==null || "".equalsIgnoreCase(columnData[i-1]) ) ? email.replace(":DSMREFCODE", columnData[i-2]) : columnData[i-1];
								String emailQuery = null;
								String emailId = null;
								boolean flag = false;
								if(columnData[i-1]==null || "".equalsIgnoreCase(columnData[i-1]) ){
									emailQuery = email420;
								}else{
									emailId = columnData[i-1];
									flag = true;
									emailQuery = email.replace(":DSMREFCODE", columnData[i-2]);
								}
								
								if(emailQuery!=null){
									//System.out.println("BulkUploadDAOImpl || BEG || emailQuery:"+emailQuery);
									PreparedStatement st2 = null;
									try{
										st2 = connection.prepareStatement(emailQuery);
										ResultSet rs2 = st2.executeQuery();
										
											while(rs2.next()){
												if(!flag){
													emailId = rs2.getString("email");
												}else{
													int noRows = rs2.getRow();
													if(noRows==0){
													return BulkConstants.MANDATORY_DSM2_REF_CODE_REQUIRED + count;
													}
												}
												logger.debug("email::: "+emailId);
											}
										rs2.close();
									}catch(Exception e){
										//System.out.println("Exception Raised. Exception is :"+e);
										e.printStackTrace();
										return BulkConstants.MANDATORY_DSM2_REF_CODE_REQUIRED + count;
									}finally{
										st2.close();
									}		
								}
								ps.setString(i, emailId);
							}
							if(columnNames[i-1].contains(BulkConstants.EMAIL_FILE_NAME)){
								if( "".equalsIgnoreCase(columnData[i-1])){
									if(br!=null)
										br.close();
									return BulkConstants.MANDATORY_DATA_REQUIRED + count ;
								}
								File fileName = new File(System.getProperty("SCHEME_STUDIO_FILE_REPOSITORY")+(columnData[i-1]).trim());
								String fileNa=null;
								if(fileName.isFile()){
									String queryFile420 = "select FILE_NAME, max(SEQ_NO) seq  from DLP_DOC_UPLOAD_FILE_DET where CIRCLE='"+schemeBulkLoadVo.getFileCircleCode()+"' and FILE_NAME='"+(columnData[i-1]).trim()+"' group by FILE_NAME";
									
									PreparedStatement st3 = null;
									try{
										st3 = connection.prepareStatement(queryFile420);
										ResultSet rs3 = st3.executeQuery();
										if(!rs3.next()){
											//System.out.println("BulkUploadDaoImpl ||  insertMailDestinationTableNew || records not found in file:"+queryFile420);
											return BulkConstants.MANDATORY_FILE_REQUIRED + count ;
										}
										rs3.close();
									}catch(Exception e){
										e.printStackTrace();
									}finally{
										st3.close();
									}	
									ps.setString(i, (columnData[i-1]).trim());
								}else{
									//System.out.println("BulkUploadDaoImpl ||  insertMailDestinationTableNew || records not found in table");
									return BulkConstants.MANDATORY_FILE_REQUIRED + count ;
								}
							}
							else{
									if( "".equalsIgnoreCase(columnData[i-1])){
										if(br!=null)
											br.close();
										return BulkConstants.MANDATORY_DATA_REQUIRED + count;
									}
									ps.setString(i, columnData[i-1]);
								}
						}else{
							if(columnNames[i-1].contains(BulkConstants.DATE)){
								//SimpleDateFormat format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY);
								SimpleDateFormat format1 = null;
								if(columnData[i-1].trim().length()==22 || columnData[i-1].trim().length()==23){
									format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_AM_PM);
								}else if(columnData[i-1].trim().length()==20 || columnData[i-1].trim().length()==21){
									format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY_24);
								}else // if(columnData[i-1].trim().length()==11)
								{
									format1 = new SimpleDateFormat(BulkConstants.DD_MMM_YYYY);
								}
								Date utilDate = format1.parse(columnData[i-1]);
								java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
								ps.setDate(i, sqlDate);
							}if(columnNames[i-1].contains(BulkConstants.EMAIL)){
								String email420 = (columnData[i-1]==null || "".equalsIgnoreCase(columnData[i-1]) ) ? email.replace(":DSMREFCODE", columnData[i-2]) : columnData[i-1];
								String emailQuery = null;
								String emailId = null;
								boolean flag = false;
								if(columnData[i-1]==null || "".equalsIgnoreCase(columnData[i-1]) ){
									emailQuery = email420;
								}else{
									emailId = columnData[i-1];
									flag = true;
									emailQuery = email.replace(":DSMREFCODE", columnData[i-2]);
								}
								
								if(emailQuery!=null){
									PreparedStatement st2 = null;
									try{
										st2 = connection.prepareStatement(emailQuery);
										ResultSet rs2 = st2.executeQuery();
										
											if(rs2.next()){
												if(!flag){
													emailId = rs2.getString("email");
												}else{
													int noRows = rs2.getRow();
													if(noRows==0){
													return BulkConstants.MANDATORY_DSM2_REF_CODE_REQUIRED + count;
													}
												}
												logger.debug("email::: "+emailId);
											}else{
												logger.debug("MANDATORY_DSM2_REF_CODE_REQUIRED ::: email::: "+emailId);
												return BulkConstants.MANDATORY_DSM2_REF_CODE_REQUIRED + count;
											}
										rs2.close();
									}catch(Exception e){
										e.printStackTrace();
										//System.out.println("3");
										return BulkConstants.MANDATORY_DSM2_REF_CODE_REQUIRED + count;
									}finally{
										st2.close();
									}		
								}
								ps.setString(i, emailId);
							}else{
								ps.setString(i, columnData[i-1]);
							}
						}
						
					//	logger.debug(""+i+" ::: "+columnData[i-1]);
					}
				}else{
					if(br!=null)
						br.close();
					connection.rollback();
					if((count==1 ) && "".equalsIgnoreCase(line.trim())){
						return BulkConstants.NO_DATA_FIRST_ROW;
					}else if((count!=1 ) && "".equalsIgnoreCase(line.trim())){
						return BulkConstants.NO_DATA_FOUND_MIDDLE + count;
					}
					return BulkConstants.DATA_HEADER_MISMATCH_ERROR + count;
				}
				ps.addBatch();
				if(++count % batchSize == 0) {
					ps.executeBatch();
					ps.clearBatch(); 
				}
			}
			
			if(count==0){
				if(br!=null)
					br.close();
				return BulkConstants.NO_DATA_FOUND;
			}
			if(count==1){
				if(br!=null)
					br.close();
				return BulkConstants.NO_DATA_HEADER_ERROR;
			}
			if(++count % batchSize != 0) {
				logger.debug(count+". In execute batch >>>");
				ps.executeBatch();// insert remaining records ParseException 
				ps.clearBatch(); 
			}
			connection.commit();
			logger.debug("End insertDestinationTable() method");
			//System.out.println("start Time :: "+startTime+" - end time ::"+new Date().getTime()+"  \t diff Time ::: "+(new Date().getTime()-startTime));
			logger.debug("start Time :: "+startTime+" - end time ::"+new Date().getTime()+"  \t diff Time ::: "+(new Date().getTime()-startTime));
			return errorMsg;
		}catch (ParseException e1) {
			logger.error("in ParseException");
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
			}catch (IOException e) {
				logger.error("in ParseException",e);
				e.printStackTrace();
			} catch (SQLException e) {
				logger.error("in ParseSQLException",e);
				e.printStackTrace();
			}
			logger.error("ParseException :: ",e1);
			e1.printStackTrace();
			return BulkConstants.DATA_DATE_ERROR + count;
		}catch (IOException e1) {
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
				logger.error("IOException :: ",e1);
				return BulkConstants.FILE_READER_ERROR ;
			}catch (IOException e) {
				logger.error("IOException :: ",e);
				e.printStackTrace();
			} catch (SQLException e) {
				logger.error("SQLException :: ",e);
				e.printStackTrace();
			}
			logger.error("IOException :: ",e1);
			e1.printStackTrace();
		}catch (SQLException e1) {
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
				logger.error("SQLException :: ",e1);
				if(e1.getMessage().contains("partition key")){
					return BulkConstants.PARTITION_ERROR;
				}else
				return BulkConstants.DESTINATION_TABLE_ERROR ;
			}catch (IOException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}e1.printStackTrace();
		}catch (NullPointerException e1) {
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
				logger.error("NullPointerException :: ",e1);
				return   BulkConstants.NULL_ERROR  + count;
			}catch (IOException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}e1.printStackTrace();
		}catch(Exception e){
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.rollback();
				if(br!=null)
					br.close();
				logger.error("Exception :: ",e);
				return  BulkConstants.DATA_ERROR ;
			}catch (IOException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}finally{
			try {
				if(ps!=null){
					ps.clearBatch();
					ps.close();
				}
				if(connection!=null)
					connection.close();
				if(br!=null)
					br.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return errorMsg;
	}
	
/*	public int insertIntoBulkLoadFileDet(String fileName,String circle,int file_id)
	{

		Connection conn = null;
		String procOutput = null;
		ResultSet result = null;
		int insertedStatus=0;
		System.out.println("BulkUploadDAOImpl || insertIntoBulkLoadFileDet || BEG || file_id:"+file_id);
		try {
			conn = jdbcTemplate.getDataSource().getConnection();
			String uploadType="";
			String uploadUniverse="";
			String query="Insert Into Scheme_Bulk_Load_File_Det (Circle,Upload_Type,Upload_Universe,Upload_File_Name,File_Status) values(?,?,?,?)";
			switch (file_id) {
			case 2:
				uploadType="ADD_ATTR";
				uploadUniverse="";
			break;
			case 3:
				uploadType="ACTIVATION";
				uploadUniverse="PERF_PARAM";
			break;
			case 4:
				uploadType="COVERAGE_LIST";
				uploadUniverse="";
			break;
			case 5:
				uploadType="MANUAL_PAYOUT";
				uploadUniverse="";
			break;
			case 6:
				uploadType="DISTRIBUTOR";
				uploadUniverse="PERF_PARAM";
			break;
			case 7:
				uploadType="RETAILER";
				uploadUniverse="PERF_PARAM";
			break;
			case 8:
				uploadType="DSE";
				uploadUniverse="PERF_PARAM";
			break;

			}
			
			if(conn !=null){
                insertedStatus=jdbcTemplate.update(query, new Object[]{circle,uploadType,uploadUniverse,fileName,"N"});
			   System.out.println("inserted Rec Status"+insertedStatus);
					
					//conn.prepareCall(query);
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				if(result!=null)
					result.close();
				if(conn!=null)
					conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		logger.debug("procOutput ::::::::::: "+procOutput);
		return insertedStatus;
	
	}
*/
	@Override
	public List<BulkLoadFileStatus> getRejectedFileList(Date stDt, Date enddt, String type, String circleCode) throws Exception {
		List<BulkLoadFileStatus> doc = null;
		NamedParameterJdbcTemplate npjt = null;
		try
		{
			SqlParameterSource parameters = new MapSqlParameterSource().addValue("startDate", getSqlDateFromDate(stDt)).addValue("endDate", getSqlDateFromDate(enddt)).addValue("circleCode", circleCode);
			
			/*String type2=null;
			String type3=null;
			String type4=null;
			String query = null;
			Object[] object = null;
			if(type.equalsIgnoreCase("1")){
				type = "%_ADD_ACT_UNI_%";
				type2 = "%_ADD_DIST_UNI_%";
				type3 = "%_ADD_RET_UNI_%";
				type4 = "%_ADD_DSE_UNI_%";
				object = new Object[]{new java.sql.Date(stDt.getTime()),new java.sql.Date(enddt.getTime()),type,type2,type3,type4,circleCode};
				query = BulkQueries.SCHEME_BULK_LOAD_FILE_STATUS_PERF;
			}else if(type.equalsIgnoreCase("2")){
				type = "%_ADD_ATTR_%";
				query = BulkQueries.SCHEME_BULK_LOAD_FILE_STATUS;
				object = new Object[]{new java.sql.Date(stDt.getTime()),new java.sql.Date(enddt.getTime()),type,circleCode};
			}else if(type.equalsIgnoreCase("3")){
				type = "%_ENTITY-LIST_%";
				object = new Object[]{new java.sql.Date(stDt.getTime()),new java.sql.Date(enddt.getTime()),type,circleCode};
				query = BulkQueries.SCHEME_BULK_LOAD_FILE_STATUS;
			}else if(type.equalsIgnoreCase("4")){
				type = "%_MANUAL-PAYOUT_%";
				object = new Object[]{new java.sql.Date(stDt.getTime()),new java.sql.Date(enddt.getTime()),type,circleCode};
				query = BulkQueries.SCHEME_BULK_LOAD_FILE_STATUS;
			}
			*/
			npjt = new NamedParameterJdbcTemplate (jdbcTemplate.getDataSource());
			
			doc = npjt.query(BulkQueries.SCHEME_BULK_LOAD_FILE_STATUS_PERF, parameters, new RowMapper<BulkLoadFileStatus>(){
				@Override
				public BulkLoadFileStatus mapRow(ResultSet rs, int arg1) throws SQLException {
					BulkLoadFileStatus duf = new BulkLoadFileStatus();
					duf.setCircleCode(rs.getString("CIRCLE_CODE"));
					duf.setErrorDesc(rs.getString("ERROR_DESC"));
					duf.setFileName(rs.getString("FILE_NAME"));
					duf.setFileStatus(rs.getString("FILE_STATUS"));
					duf.setLoadDateTime(rs.getString("LOAD_DATE_TIME"));
					duf.setReloadattempts(rs.getInt("RELOAD_ATTEMPTS"));
					duf.setUnquieFileName(rs.getString("UNIQUE_FILE_NAME"));
					duf.setUserName(rs.getString("USER_NAME"));
					return duf;
				}
			});
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally{
			npjt=null;
			}
		return doc;
	}

}


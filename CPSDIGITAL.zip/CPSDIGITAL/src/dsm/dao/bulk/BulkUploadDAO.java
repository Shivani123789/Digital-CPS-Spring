package dsm.dao.bulk;

import java.io.File;
import java.util.Date;
import java.util.List;

import dsm.model.DB.MappingTableFields;
import dsm.model.DB.SchemeBulkLoadConfVo;
import dsm.model.form.BulkComponentMasterStore;
import dsm.model.form.BulkLoadFileStatus;
import dsm.model.form.BulkSchemeMasterStore;
import dsm.model.form.DocTypeList;
import dsm.model.form.DocUploadFile;
import dsm.model.form.UploadMailStatusData;

public interface BulkUploadDAO {

	//New Rebuilt Bulkupload code
	public List<SchemeBulkLoadConfVo> getSchemBulkConfDataNew(int file_id) throws Exception;

	public boolean matchSchemeCompMappingFileNew(int schemeId, int compId, String fileName) throws Exception;

	public void updateDestinationTableNew(String circleCode, String fileName, String distinationTableName) throws Exception;
	
	public MappingTableFields getDestTabColValueNew(String fileHeaderName,String type, int circleId) throws Exception;
	
	public String insertDestinationTableNew(File file,SchemeBulkLoadConfVo schemeBulkLoadVo) throws Exception;
	
	public String callProcDlpPerformConfigNew(SchemeBulkLoadConfVo schemeBulk, String userName) throws Exception;
	
	public String callProcEntityAddAttrStampNew(SchemeBulkLoadConfVo schemeBulkLoadVo) throws Exception;
	
	public String persistFileDetailNew(String userName, String fileName, String fileStatus, String uniqueFileName, String circleCode)  throws Exception;
	//public String fetchFileData(String userName, String confName, File file, String feedNumber, String circle);
	public String fetchFileData(String userName, int file_id, File file, String circle, int schemeId, int compId) throws Exception; 
	
	public List<BulkSchemeMasterStore> getBulkSchemeMasterStore(String fileName, int circleId) throws Exception;
	
	public List<BulkComponentMasterStore> getBulkComponentMasterStore(String fileName, int circleId) throws Exception;
	
	public String callProcDlpCirclePerformParamConfigNew(SchemeBulkLoadConfVo schemeBulk, String userName) throws Exception;
	
	
	//=================== Bulk Upload Doc File ================//
	public DocUploadFile validateDocFileType(String fileExt) throws Exception;
	
	public int insertDocTypeValues(DocTypeList docTypeList) throws Exception;
	
	public List<DocTypeList> getDocListType() throws Exception;
	
	public String insertMailDestinationTableNew(File file,SchemeBulkLoadConfVo schemeBulkLoadVo) throws Exception;
	
	//public boolean validateDocFileType(DocTypeList docTypeList);
	
	public List<UploadMailStatusData> getUploadData(UploadMailStatusData uploadMailStatusData) throws Exception;
	
	public List<UploadMailStatusData> getMailData(UploadMailStatusData uploadMailStatusData) throws Exception;
	
	public int insertMailTypeValues(DocTypeList docTypeList,String line) throws Exception;
	
	//public int insertIntoBulkLoadFileDet(String file,String circle,int file_id);
	
	public List<BulkLoadFileStatus> getRejectedFileList(Date stDt, Date enddt, String type, String circleCode) throws Exception;
	
	
}  

package dsm.dao.postapp;

import java.util.List;

import dsm.model.DB.SchemeMaster;
import dsm.model.postapp.PostApprovedScheme;

public interface PostExecDAO {

	//List<SchemeMaster> searchScheme(Date startDate,Date endDate);
	
	public List<PostApprovedScheme>listScheme(String execDate,String approvedBy,String approvedStatus,String approvedDate) throws Exception;
	
	public void updateSchemeStatus(int scheme_id,String approvedBy) throws Exception;
	
	public String payoutScheme(PostApprovedScheme schemeMaster) throws Exception;
	
	public String testValidApproveScheme(SchemeMaster schemeMaster) throws Exception;
}

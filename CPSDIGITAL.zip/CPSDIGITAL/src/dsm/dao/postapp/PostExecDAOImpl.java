package dsm.dao.postapp;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import dsm.model.DB.SchemeMaster;
import dsm.model.postapp.PostApprovedScheme;

public class PostExecDAOImpl implements PostExecDAO {

	private JdbcTemplate jdbcTemplate;

	public PostExecDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<PostApprovedScheme> listScheme(String execDate,	String approvedBy, String approvedStatus, String approvedDate)  throws Exception{
		// TODO Auto-generated method stub
		//String query = "SELECT scheme_id,scheme_name,APPROVED_STATUS FROM POST_EXECUTION_SCHEME_TBL where (APPROVED_STATUS != 'Yes' OR APPROVED_STATUS IS NULL)  ORDER BY execution_date DESC";
		String query = "select sm.scheme_id,sm.scheme_name,cm.SCM_STATUS from dlp_scheme_master sm, dlp_scheme_comp_mapping cm where sm.scheme_id=cm.scheme_id and cm.SCM_STATUS='A' and cm.validity_flag=sm.validity_flag and cm.validity_flag='Y' order by sm.insert_date_time desc";	
		//System.out.println("listScheme :::: "+query);		
		List<PostApprovedScheme> schemeList = jdbcTemplate.query(query, new RowMapper<PostApprovedScheme>() {
			@Override
			public PostApprovedScheme mapRow(ResultSet rs, int rowNum) throws SQLException {
				PostApprovedScheme schemeMaster = new PostApprovedScheme();
				schemeMaster.setSchemeId(rs.getInt("scheme_id"));
				schemeMaster.setSchemeName(rs.getString("scheme_name"));
				return schemeMaster;
			}
		});
		return schemeList;
	}

	@Override
	public void updateSchemeStatus(int scheme_id,String approvedBy)  throws Exception{
		// TODO Auto-generated method stub
		String sql = "update POST_EXECUTION_SCHEME_TBL set  APPROVED_BY = ?, APPROVED_STATUS = ?,  APPROVED_DATE = ?  where  scheme_id = ?";
		jdbcTemplate.update(sql, approvedBy, "Yes", new Date(), scheme_id );
	}


	public String payoutScheme(PostApprovedScheme schemeMaster) throws Exception{
		try{
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DLP_APPROVE_PAYOUT");
			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put("pCIRCLE_ID", schemeMaster.getCircleId());
			inParamMap.put("pSCHEME_ID", schemeMaster.getSchemeId());
			inParamMap.put("pCOMP_ID",schemeMaster.getCompId() );
			//pUSER_CODE
			inParamMap.put("pUSER_CODE",schemeMaster.getUserCode() );
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
			return simpleJdbcCallResult.toString();
		}catch(Exception e){
			e.printStackTrace();
			return "Error "+e.getMessage();
		}
	}



	public synchronized String testValidApproveScheme(SchemeMaster schemeMaster) throws Exception{
		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DLP_SCM_EXECUTE_BASELINE");
		Map<String, Object> simpleJdbcCallResult=null;// = simpleJdbcCall.execute(in);
		try{
			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put("pCIR_NUM", schemeMaster.getCircleId());
			inParamMap.put("pSCHEME_ID", schemeMaster.getSchemeINputId());
			inParamMap.put("pCOMP_ID", schemeMaster.getCompID());
			inParamMap.put("pMODE", "O");
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			simpleJdbcCallResult = simpleJdbcCall.execute(in);
			//System.out.println("Test Run pay "+simpleJdbcCallResult);
			return simpleJdbcCallResult.toString();
		}catch(Exception e){
			e.printStackTrace();
			return "Error "+e.getMessage();
		}
	}

}

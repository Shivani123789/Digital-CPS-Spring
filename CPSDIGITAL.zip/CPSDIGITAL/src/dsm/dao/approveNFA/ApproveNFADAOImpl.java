package dsm.dao.approveNFA;

//import java.sql.CallableStatement;
//import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

//import oracle.jdbc.OracleTypes;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import dsm.dataBase.query.NFAQueries;
//import dsm.model.DB.ExceptionVo;
import dsm.model.DB.PayoutEmailConfigVO;
import dsm.model.DB.PayoutSmsConfigVO;
import dsm.model.DB.RejectSchemeVO;
import dsm.model.DB.SchemeMaster;
//import dsm.model.DB.UniverseMasterVO;

public class ApproveNFADAOImpl implements ApproveNFADAO{

	private JdbcTemplate jdbcTemplate;

	private static Logger logger = Logger.getLogger (ApproveNFADAOImpl.class);

	public ApproveNFADAOImpl(){

	}

	public ApproveNFADAOImpl(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}


	public String  approveScheme(SchemeMaster schemeMaster)  throws Exception{
		Map<String, Object> simpleJdbcCallResult = null;
		try{
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DLP_APPROVAL_SCHEME");
			////logger.debug("ApproveNFADAOImpl - approveScheme - cirlce Id : "+schemeMaster.getCircleId()+"  SchemeId ::"+schemeMaster.getSchemeINputId()+" CompId :: "+schemeMaster.getCompId());
			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put("pCIRCLE_ID", schemeMaster.getCircleId());
			inParamMap.put("pSCHEME_ID", schemeMaster.getSchemeINputId());
			inParamMap.put("pUSER_CODE", schemeMaster.getUserName());
			inParamMap.put("pCOMP_ID",schemeMaster.getCompId() );
		//	inParamMap.put("pCOMP_ID",schemeMaster.getCompId() );
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			simpleJdbcCallResult = simpleJdbcCall.execute(in);
			////logger.debug("ApproveNFADAOImpl - approveScheme - DLP_APPROVAL_SCHEME result:: ----"+simpleJdbcCallResult);
			return simpleJdbcCallResult.toString();
		}catch(Exception e){
			logger.error("ApproveNFADAOImpl - approveScheme - Exception :: ", e);
			return " Error " + e.getMessage();
		}
	
	}

	public String rejectScheme(SchemeMaster schemeMaster)  throws Exception{
		Map<String, Object> simpleJdbcCallResult = null;
		try{
			////logger.debug("ApproveNFADAOImpl - rejectScheme - DLP_REJECT_SCHEME - cirlce Id : "+schemeMaster.getCircleId()+"  SchemeId ::"+schemeMaster.getSchemeINputId()+" CompId :: "+schemeMaster.getCompId()+" userId :: "+schemeMaster.getUserId());
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
			.withProcedureName("DLP_REJECT_SCHEME");
			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put("pCIRCLE_ID", schemeMaster.getCircleId());
			inParamMap.put("pSCHEME_ID", schemeMaster.getSchemeINputId());
			inParamMap.put("pCOMP_ID",schemeMaster.getCompId() );
			inParamMap.put("pUSER_CODE",schemeMaster.getUserId());
			//
			inParamMap.put("pCOMMENTS", schemeMaster.getRejectComment());
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			simpleJdbcCallResult = simpleJdbcCall.execute(in);
			////logger.debug("ApproveNFADAOImpl - rejectScheme - DLP_REJECT_SCHEME result::  "+simpleJdbcCallResult);
			return simpleJdbcCallResult.toString();
		}catch(Exception e){
			logger.error(" rejectScheme . Exception ::", e);
			return "Error " + e.getMessage();
		}
		
	}

	
	public synchronized String testValidScheme(SchemeMaster schemeMaster) throws Exception{
		Map<String, Object> simpleJdbcCallResult =null;
		try{
			////logger.debug("ApproveNFADAOImpl - testValidScheme - DLP_SCM_EXECUTE_BASELINE - cirlce Id : "+schemeMaster.getCircleId()+"  SchemeId ::"+schemeMaster.getSchemeINputId()+" CompId :: "+schemeMaster.getCompID()+" status :: "+schemeMaster.getStatus());
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
			.withProcedureName("DLP_SCM_EXECUTE_BASELINE");
			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put("pCIR_NUM", schemeMaster.getCircleId());
			inParamMap.put("pSCHEME_ID", schemeMaster.getSchemeINputId());
			inParamMap.put("pCOMP_ID", schemeMaster.getCompID());
			inParamMap.put("pMODE", schemeMaster.getStatus());
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			simpleJdbcCallResult = simpleJdbcCall.execute(in);
			//System.out.println( "Procedure SchemeId :" +schemeMaster.getSchemeINputId()+" CompId :"+ schemeMaster.getCompID()+" Status : "+schemeMaster.getStatus());
			
			if(simpleJdbcCallResult!=null)
			{
				////logger.debug( "ApproveNFADAOImpl - testValidScheme - DLP_SCM_EXECUTE_BASELINE Procedure error SchemeId :" +schemeMaster.getSchemeINputId()+" CompId :"+ schemeMaster.getCompID()+" Status : "+schemeMaster.getStatus());
				////logger.debug("ApproveNFADAOImpl - testValidScheme - DLP_SCM_EXECUTE_BASELINE Test Run "+simpleJdbcCallResult);
			return simpleJdbcCallResult.toString();
			}
			else
				return "Procedure error SchemeId :" +schemeMaster.getSchemeINputId()+" CompId :"+ schemeMaster.getCompID()+" Status : "+schemeMaster.getStatus();
		}catch(Exception e){
			logger.error("ApproveNFADAOImpl - testValidScheme - DLP_SCM_EXECUTE_BASELINE", e);
			return "Error "+e.getMessage();
		}
	}

	
	@Override
	public String rejectScheme(RejectSchemeVO reject)  throws Exception{

		if(reject.getRejectType()==1)
		{
			////logger.debug("ApproveNFADAOImpl rejectScheme scmId :: "+reject.getSchemeId()+" compId :: "+reject.getCompId()+" circleId :: "+reject.getCircleId() +" userId :: "+reject.getUserId() +" rejectRemarks :: "+reject.getRejectReason());
			SchemeMaster sm = new SchemeMaster();
			sm.setSchemeINputId(reject.getSchemeId());
			sm.setCompId(reject.getCompId());
			sm.setCircleId(reject.getCircleId());
			sm.setUserId(reject.getUserId());
			sm.setRejectComment(reject.getRejectReason());
			String result =	rejectScheme(sm);
		//	String query = "update dlp_scheme_comp_mapping set SCM_STATUS ='R',reason=? where scheme_id=? and component_id=?";	
		//	int r = 	jdbcTemplate.update(query,reject.getRejectReason(),reject.getSchemeId(),reject.getCompId());
		//	//logger.debug("reject Update"+r);
			////logger.debug("End -- ApproveNFADAOImpl rejectScheme result :: "+result);
			return result;
		}
		else
		{
			String query = "update dlp_scheme_comp_mapping set SCM_STATUS ='D',reason=? where scheme_id=? and component_id=?";	
			////logger.debug("ApproveNFADAOImpl rejectScheme query "+query+"  scmId :: "+reject.getSchemeId()+" compId :: "+reject.getCompId()+" circleId :: "+reject.getCircleId() +" rejectRemarks :: "+reject.getRejectReason());
			int r = 	jdbcTemplate.update(query,reject.getRejectReason(),reject.getSchemeId(),reject.getCompId());
			////logger.debug("End -- ApproveNFADAOImpl rejectScheme return "+r);
			return "Updated successfully.";
		}
	}
	
	@Override
	public PayoutSmsConfigVO smsConfigTemplate(int schemeId, int compId, int circleId)  throws Exception{
		try{
			////logger.debug("Begin -- ApproveNFADAOImpl smsConfigTemplate query :: "+NFAQueries.SMS_TRANSACTION+" ::: circleId :: "+circleId+" schemeId :: "+ schemeId+" compId :: "+ compId);
			List<PayoutSmsConfigVO> sms = jdbcTemplate.query(NFAQueries.SMS_TRANSACTION,new Object[]{circleId, schemeId, compId, circleId}, new RowMapper<PayoutSmsConfigVO>(){
				@Override
				public PayoutSmsConfigVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					PayoutSmsConfigVO smsVo = new PayoutSmsConfigVO();
					smsVo.setCircle(rs.getInt("CIRCLE"));
					smsVo.setEventName(rs.getString("EVENT_NAME"));
					smsVo.setSmsContent(rs.getString("SMS_CONTENT"));
					smsVo.setFromNumber(rs.getString("FROM_NUMBER"));
					smsVo.setToNumber("91"+rs.getString("TO_NUMBER"));
					smsVo.setSendStatus(rs.getString("SEND_STATUS"));
					smsVo.setValidityFlag(rs.getString("VALIDITY_FLAG"));
					return smsVo; 
				}
			});
			////logger.debug("End -- ApproveNFADAOImpl smsConfigTemplate :::sms::::::: "+sms);
			//System.out.println("smsConfigTemplate :::sms::::::: "+sms);
			if(sms!=null && sms.size()!=0)
				return sms.get(0);
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public boolean updateSmsTransaction(PayoutSmsConfigVO config)  throws Exception{
		int i = jdbcTemplate.update(NFAQueries.UPDATE_SMS_TRANSACTION, new Object[]{new Date(),new Date(),config.getEventName(),config.getSmsContent(),config.getCircle()});
		//System.out.println("SMS Transaction updated :::::------>>>>>> "+i);
		////logger.debug("End -- ApproveNFADAOImpl updateSmsTransaction ::::::: "+i);
		if(i==1){
			return true;
		}else{
			return false;
		}
	}
	
	@Override
	public PayoutEmailConfigVO emailConfigTemplate(String componentName, int circleId)  throws Exception{
		try{
			////logger.debug("Begin -- ApproveNFADAOImpl emailConfigTemplate ::::::: componentName :: "+componentName+ " circleId :: "+circleId);
			List<PayoutEmailConfigVO> email = jdbcTemplate.query(NFAQueries.EMAIL_TRANSACTION,new Object[]{circleId, "%"+componentName+"%"}, new RowMapper<PayoutEmailConfigVO>(){
				@Override
				public PayoutEmailConfigVO mapRow(ResultSet rs, int rowNum) throws SQLException {
					PayoutEmailConfigVO emailVo = new PayoutEmailConfigVO();
					emailVo.setCircleId(rs.getInt("CIRCLE"));
					emailVo.setEventName(rs.getString("EVENT_NAME"));
					emailVo.setSender(rs.getString("SENDER"));
					emailVo.setRecipients(rs.getString("RECIPIENTS"));
					emailVo.setCcRecipients(rs.getString("CC_RECIPIENTS"));
					emailVo.setEmailSubject(rs.getString("EMAIL_SUBJECT"));
					emailVo.setClobEmailContent(rs.getClob("EMAIL_CONTENT"));
					emailVo.setAttachmentFlag(rs.getString("ATTACHMENT_FLAG"));
					emailVo.setAttachmentPath(rs.getString("ATTACHMENT_PATH"));
					emailVo.setSendStatus(rs.getString("SEND_STATUS"));
					emailVo.setValidityFlag(rs.getString("VALIDITY_FLAG"));
					//emailVo.set(rs.getString("SEND_DATE_TIME"));
					//emailVo.set(rs.getString("UPDATE_DATE_TIME"));
					//emailVo.set(rs.getString("INSERT_DATE_TIME"));
					return emailVo; 
				}
			});
			////logger.debug("End -- ApproveNFADAOImpl emailConfigTemplate :::email::::::: "+email);
			if(email!=null && email.size()!=0)
				return email.get(0);
		}catch(Exception e){
			logger.error("ApproveNFADAOImpl emailConfigTemplate Exception :: ",e);
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public boolean updateEmailTransaction(PayoutEmailConfigVO config)  throws Exception{
		int i = jdbcTemplate.update(NFAQueries.UPDATE_EMAIL_TRANSACTION, new Object[]{config.getCircleId(), config.getEventName(), config.getEmailContent()});
		if(i==1){
			return true;
		}else{
			return false;
		}
	}
}

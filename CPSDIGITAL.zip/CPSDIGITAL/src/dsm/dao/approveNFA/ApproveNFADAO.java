package dsm.dao.approveNFA;

import dsm.model.DB.PayoutEmailConfigVO;
import dsm.model.DB.PayoutSmsConfigVO;
import dsm.model.DB.RejectSchemeVO;
import dsm.model.DB.SchemeMaster;

public interface ApproveNFADAO {
	
	public String approveScheme(SchemeMaster schemeMaster)  throws Exception;
	
	public String rejectScheme(SchemeMaster schemeMaster)  throws Exception;
	
	public String testValidScheme(SchemeMaster schemeMaster) throws Exception;
	
	public String rejectScheme(RejectSchemeVO reject)  throws Exception;
	
	public PayoutSmsConfigVO smsConfigTemplate(int schemeId, int compId, int circleId)  throws Exception; 
	
	public boolean updateSmsTransaction(PayoutSmsConfigVO config)  throws Exception;
	
	public PayoutEmailConfigVO emailConfigTemplate(String componentName, int circleId)  throws Exception;
	
	public boolean updateEmailTransaction(PayoutEmailConfigVO config)  throws Exception;
}

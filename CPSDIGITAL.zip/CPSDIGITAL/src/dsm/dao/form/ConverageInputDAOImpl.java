package dsm.dao.form;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import dsm.dataBase.query.SchemeConfigQueries;
import dsm.model.DB.CompCategoryPojo;
import dsm.model.DB.CompMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.form.AttributeTypeMaster;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.form.EntityMaster;
import dsm.model.form.FunctionMaster;
import dsm.model.form.OprMaster;
import dsm.model.form.PayToMaster;
import dsm.model.form.PayoutFrequency;
import dsm.model.form.RegionMaster;
import dsm.model.form.SchemaMaster;
import dsm.model.form.UnitMaster;
import dsm.model.form.UploadMaster;
import dsm.model.form.ValueTypeMaster;
import dsm.model.form.VerticalMaster;
import dsm.model.form.ZoneMaster;
import dsm.model.po.PayoutCondition;


public class ConverageInputDAOImpl implements ConverageInputDAO{
	
private JdbcTemplate jdbcTemplate;



@Autowired
HttpSession httpSession;
     public ConverageInputDAOImpl(){}
	
	public ConverageInputDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<CompMaster> getCompMasterList(String schemeName) throws Exception{
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
		String query="select comp.scheme_id,scheme.scheme_name," +
				"comp.component_id,comp.pay_to,comp.componenet_name," +
				"comp.start_date,comp.end_date," +
				"freq.description," +
				"vert.vertical_name," +
				"payto.display_value," +
				"comp.file_name, " +
				"comp.COVERAGE_FLAG, "+
				"cat.display_value cat_display_value, "+
				"cat.cat_id cat_id "+
				"from DLP_SCHEME_MASTER_STAGE scheme," +
				"DLP_SCHEME_COMP_MAPPING_STAGE comp," +
				"DLP_Payout_Freequency freq," +
				"DLP_Vertical_Master vert," +
				"DLP_Entity_Type_Master payto, " +
				"Dlp_Scheme_Category cat "+
				"where freq.freequency_id = comp.freequency_id " +
				"AND vert.vertical_id = comp.vertical_id " +
                "and Comp.Category_Id=cat.cat_id(+) " +
				"AND payto.entity_type_id = comp.pay_to " +
				"AND comp.scheme_id=scheme.scheme_id " +
				"AND scheme.scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ? AND circle_id = ?)";

		/*int sysId2 = 2;
		String systemDesc2 = "CPS";
		Map<String,Object> map = getSystemTypeValue();
			for(Map.Entry<String,Object> newMap : map.entrySet()){
				//System.out.println("newMap.getKey() ::: "+ newMap.getKey() +" \t value :::: "+newMap.getValue().toString());
				sysId2 = Integer.parseInt(newMap.getKey());
				systemDesc2 = newMap.getValue().toString();
			}
			final int sysId = sysId2;
			final String systemDesc = systemDesc2;
			*/
		//System.out.println(query);
		List<CompMaster> listContact = jdbcTemplate.query(query, new Object[]{schemeName, circleId}, new RowMapper<CompMaster>() {

			@Override
			public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompMaster compMaster = new CompMaster();
				
				compMaster.setSchemeId(rs.getInt("scheme_id"));
				compMaster.setPayTo(rs.getInt("pay_to"));
				compMaster.setSchemeName(rs.getString("scheme_name"));
				compMaster.setCompId(rs.getInt("component_id"));
				compMaster.setCompName(rs.getString("componenet_name"));
				compMaster.setStartDate(rs.getDate("start_date"));
				compMaster.setEndDate(rs.getDate("end_date"));
				compMaster.setFreqName(rs.getString("description"));
				compMaster.setVerticalName(rs.getString("vertical_name"));
				compMaster.setPayToName(rs.getString("display_value"));
				compMaster.setFileName(rs.getString("file_name"));
				compMaster.setCoverageFlag(rs.getString("COVERAGE_FLAG"));
				compMaster.setCategory(rs.getString("cat_display_value"));
				compMaster.setCategoryId(rs.getInt("cat_id"));
			//	compMaster.setSystemId(sysId);
			//	compMaster.setSystemType(systemDesc);
				return compMaster;
			}
			
		});
		return listContact;
	}
	
	@Override
	public List<CompMaster> getCompMasterListReg(String schemeName) {
		
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
		String query="select comp.scheme_id,scheme.scheme_name," +
				"comp.component_id,comp.pay_to,comp.componenet_name," +
				"comp.start_date,comp.end_date," +
				"freq.description," +
				"vert.vertical_name," +
				"payto.display_value," +
				"comp.file_name, " +
				"comp.COVERAGE_FLAG "+
				"from DLP_SCHEME_MASTER_STAGE scheme," +
				"DLP_SCHEME_COMP_MAPPING_STAGE comp," +
				"DLP_Payout_Freequency freq," +
				"DLP_Vertical_Master vert," +
				"DLP_Entity_Type_Master payto " +
				"where freq.freequency_id = comp.freequency_id " +
				"AND vert.vertical_id = comp.vertical_id " +
				"AND payto.entity_type_id = comp.pay_to " +
				"AND comp.scheme_id=scheme.scheme_id " +
				"AND scheme.scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ? AND circle_id = ? ) and comp.file_name is null";

		//System.out.println(query);
		List<CompMaster> listContact = jdbcTemplate.query(query, new Object[]{schemeName, circleId}, new RowMapper<CompMaster>() {

			@Override
			public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompMaster compMaster = new CompMaster();
				
				compMaster.setSchemeId(rs.getInt("scheme_id"));
				compMaster.setPayTo(rs.getInt("pay_to"));
				compMaster.setSchemeName(rs.getString("scheme_name"));
				compMaster.setCompId(rs.getInt("component_id"));
				compMaster.setCompName(rs.getString("componenet_name"));
				compMaster.setStartDate(rs.getDate("start_date"));
				compMaster.setEndDate(rs.getDate("end_date"));
				compMaster.setFreqName(rs.getString("description"));
				compMaster.setVerticalName(rs.getString("vertical_name"));
				compMaster.setPayToName(rs.getString("display_value"));
				compMaster.setFileName(rs.getString("file_name"));
				compMaster.setCoverageFlag(rs.getString("COVERAGE_FLAG"));
				return compMaster;
			}
			
		});
		return listContact;
	}
	
	
	@Override
	public List<CompMaster> getCompListForCoverage() {
		try{
			if(httpSession.getAttribute("schemeId")!=null){
				int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());

				String query = "select component_id, componenet_name, START_DATE , END_DATE from dlp_scheme_comp_mapping_stage where scheme_id = ? and  component_id not in (select  component_id from dlp_scm_co_cond_config_stage where scheme_id = ? and r_opr =26)";

				List<CompMaster> listContact = jdbcTemplate.query(query, new Object[]{schemeId, schemeId}, new RowMapper<CompMaster>() {

					@Override
					public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
						CompMaster compMaster = new CompMaster();

						compMaster.setCompId(rs.getInt("component_id"));
						compMaster.setCompName(rs.getString("componenet_name"));
						compMaster.setStartDtStr(rs.getString("START_DATE"));
						compMaster.setEndDtStr(rs.getString("END_DATE"));
						return compMaster;
					}

				});
				return listContact;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	@Override
	public List<PayoutFrequency> getPayoutFrequency() {
		String query="select FREEQUENCY_ID,display_value from DLP_Payout_Freequency  where validity_flag='Y'";
		List<PayoutFrequency> listContact = jdbcTemplate.query(query, new RowMapper<PayoutFrequency>() {

			@Override
			public PayoutFrequency mapRow(ResultSet rs, int rowNum) throws SQLException {
				PayoutFrequency payoutFreq = new PayoutFrequency();
				
				payoutFreq.setFreqId(rs.getInt("FREEQUENCY_ID"));
				payoutFreq.setDescription(rs.getString("display_value"));
				return payoutFreq;
			}
			
		});
		
		
		return listContact;
		
	}

	@Override
	public List<RegionMaster> getRegionList() {
		int circle=0;
		if(httpSession.getAttribute("circleId")!=null)
			circle = Integer.valueOf(httpSession.getAttribute("circleId").toString());
		String query="select REGION_ID,REGION_DESCRIPTION,CIRCLE_ID from DLP_Region_Master where circle_id = ?";
		List<RegionMaster> listRegion = jdbcTemplate.query(query, new Object[]{circle}, new RowMapper<RegionMaster>() {

			@Override
			public RegionMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				RegionMaster regionMaster = new RegionMaster();
				
				//payoutFreq.setDescription("description");
				regionMaster.setRegionId(rs.getInt("REGION_ID"));
			//	regionMaster.setRegionId(rs.getInt("REGION_ID"));
				regionMaster.setRegionDesc(rs.getString("REGION_DESCRIPTION"));
				regionMaster.setCircleId(rs.getInt("CIRCLE_ID"));
				return regionMaster;
			}
			
		});
		return listRegion;
	}

	@Override
	public List<SchemaMaster> getSchemaList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ZoneMaster> getZoneList() {
		String query="select ZONE_ID,REGION_ID,ZONE_DESCRIPTION from DLP_Zone_Master";
		List<ZoneMaster> listContact = jdbcTemplate.query(query, new RowMapper<ZoneMaster>() {

			@Override
			public ZoneMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				ZoneMaster zoneMaster = new ZoneMaster();
				//payoutFreq.setDescription("description");
				zoneMaster.setZoneId(rs.getInt("ZONE_ID"));
				zoneMaster.setZoneDesc(rs.getString("ZONE_DESCRIPTION"));
				zoneMaster.setRegionId(rs.getInt("REGION_ID"));
				return zoneMaster;
			}
			
		});
		return listContact;
	}

	@Override
	public List<VerticalMaster> getVerticalList() {
		String query="select VERTICAL_ID,display_value from DLP_Vertical_Master where validity_flag = 'Y'";
		List<VerticalMaster> listContact = jdbcTemplate.query(query, new RowMapper<VerticalMaster>() {
			@Override
			public VerticalMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				VerticalMaster verticalMaster = new VerticalMaster();
				//payoutFreq.setDescription("description");
				verticalMaster.setVerticalName(rs.getString("display_value"));
				verticalMaster.setVerticalId(rs.getInt("VERTICAL_ID"));
				return verticalMaster;
			}
		});
		return listContact;
	}

	
	@Override
	public List<UploadMaster> getUploadList() {
		String query="select LIST_ID,display_value from DLP_Upload_List_Master where validity_flag='Y'";
		List<UploadMaster> listContact = jdbcTemplate.query(query, new RowMapper<UploadMaster>() {
			@Override
			public UploadMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				UploadMaster uploadMaster = new UploadMaster();
				//payoutFreq.setDescription("description");
				uploadMaster.setCovFlag(rs.getString("display_value"));
				uploadMaster.setListId(rs.getInt("LIST_ID"));
				return uploadMaster;
			}
		});
		return listContact;
	}

	
	@Override
	public List<PayToMaster> getPayToList() {
		String query="select ENTITY_TYPE_ID,DESCRIPTION,DISPLAY_VALUE from DLP_Entity_Type_Master where PAYTO_FLAG='Y' and  validity_flag='Y' order by ENTITY_TYPE_ID desc";
		List<PayToMaster> listContact = jdbcTemplate.query(query, new RowMapper<PayToMaster>() {
			@Override
			public PayToMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				PayToMaster payToMaster = new PayToMaster();
				//payoutFreq.setDescription("description");
				payToMaster.setEntityTypeId(rs.getInt("ENTITY_TYPE_ID"));
				payToMaster.setDescription(rs.getString("DESCRIPTION"));
				payToMaster.setDisplayValue(rs.getString("DISPLAY_VALUE"));
				return payToMaster;
			}
		});
		return listContact;
	}

	
	/*@Override
	public List<CircleMaster> getCircleList() {
		String query="select CIRCLE_ID,CIRCLE_CODE from circle_master";
		List<CircleMaster> listContact = jdbcTemplate.query(query, new RowMapper<CircleMaster>() {
			@Override
			public CircleMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CircleMaster circleMaster = new CircleMaster();
				//payoutFreq.setDescription("description");
				circleMaster.setCircleName(rs.getString("CIRCLE_CODE"));
				circleMaster.setCircleId(rs.getInt("CIRCLE_ID"));
				return circleMaster;
			}
		});
		return listContact;
	}*/

	@Override
	public List<PayoutCondition> getPayoutCondtion() {
		// TODO Auto-generated method stub
		String query="select e.INPUT_TYPE_ID," +
				"e.INPUT_TYPE_DESC," +
				"o.display_value," +
				"o.operator_id,"+
				"v.value_type_id,"+
				"v.display_value," +
				"u.unit_id," +
				"u.display_value " +
				"from DLP_tbl_Input_Type_Master e,"+
				"dlp_operator_master o,"+ 
				"dlp_tbl_value_type_master v,"+
				 "dlp_unit_master u"+
                   " where e.PO_FLAG='Y'"+
                   	"AND v.po_flag='Y'"+
                   	"AND u.validity_flag='Y'"+
                    "AND o.po_flag='Y'";
		List<PayoutCondition> payoutCondition = jdbcTemplate.query(query, new RowMapper<PayoutCondition>() {
			@Override
			public PayoutCondition mapRow(ResultSet rs, int rowNum) throws SQLException {
				PayoutCondition payoutCondition = new PayoutCondition();
				payoutCondition.setInputTypeId(rs.getInt("INPUT_TYPE_ID"));
				payoutCondition.setInputType(rs.getString("INPUT_TYPE_DESC"));
				payoutCondition.setOprId(rs.getInt("operator_id"));
				payoutCondition.setOpr(rs.getString("display_value"));
				payoutCondition.setValueId(rs.getInt("value_type_id"));
				payoutCondition.setValueType(rs.getString(6));
				payoutCondition.setUnitId(rs.getInt("unit_id"));
				payoutCondition.setUnitName(rs.getString(8));
				return payoutCondition;
			}
		});
		return payoutCondition;
	}

	@Override
	public List<EntityMaster> getEntityList() {
		String query="select ENTITY_TYPE_ID,display_value from dlp_entity_type_master where validity_flag='Y' order by ENTITY_TYPE_ID desc";
		List<EntityMaster> entityList = jdbcTemplate.query(query, new RowMapper<EntityMaster>() {
			@Override
			public EntityMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				EntityMaster entityMaster = new EntityMaster();
				//payoutFreq.setDescription("description");
				entityMaster.setEntityId(rs.getInt("ENTITY_TYPE_ID"));
				entityMaster.setEntityName(rs.getString("display_value"));
				return entityMaster;
			}
		});
		return entityList;
	}

	
	@Override
	public List<AttributeTypeMaster> getAttributeTypeList() {
		String query="select INPUT_TYPE_ID,DISPLAY_VALUE from dlp_tbl_input_type_master where validity_flag='Y' AND co_flag='Y'";
		List<AttributeTypeMaster> attribteList = jdbcTemplate.query(query, new RowMapper<AttributeTypeMaster>() {
			@Override
			public AttributeTypeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				AttributeTypeMaster attributeMaster = new AttributeTypeMaster();
				attributeMaster.setAttributeTypeId(rs.getInt("INPUT_TYPE_ID"));
				attributeMaster.setAttributeTypeName(rs.getString("DISPLAY_VALUE"));
				return attributeMaster;
			}
		});
		return attribteList;
	}

	
	@Override
	public List<FunctionMaster> getFunctionList() {
		String query="select FUNCTION_ID, DESCRIPTION from dlp_tbl_function_master where coverage_flag='Y'";
		List<FunctionMaster> functionList = jdbcTemplate.query(query, new RowMapper<FunctionMaster>() {
			@Override
			public FunctionMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				FunctionMaster functionMaster = new FunctionMaster();
				functionMaster.setFunctioId(rs.getInt("FUNCTION_ID"));
				functionMaster.setFunctionName(rs.getString("DESCRIPTION"));
				return functionMaster;
			}
		});
		return functionList;
	}

	
	@Override
	public List<EntityAttributeMaster> getEntityAttributeList() {
		int circle=0;
		if(httpSession.getAttribute("circleId")!=null)
			circle = Integer.valueOf(httpSession.getAttribute("circleId").toString());
	//	String query="select ATTR_SEQ_NO,DISPLAY_NAME,attr_catg,attr_type,free_text_type_chk,operator_flag from dlp_tbl_entity_attr_mapping where validity_flag='Y' AND coverage_flag='Y' and (CIRCLE_ID = 1 OR CIRCLE_ID is null)";
		List<EntityAttributeMaster> enetityAttributeList = jdbcTemplate.query(SchemeConfigQueries.ENTITY_ATTRIBUTE_LIST, new Object[]{circle}, new RowMapper<EntityAttributeMaster>() {
			@Override
			public EntityAttributeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				EntityAttributeMaster enetityAttributeMaster = new EntityAttributeMaster();
				enetityAttributeMaster.setEntityAttributeId(rs.getInt("ATTR_SEQ_NO"));
				enetityAttributeMaster.setEntityAttributeName(rs.getString("DISPLAY_NAME"));
				enetityAttributeMaster.setAttrCatg(rs.getInt("attr_catg"));
				enetityAttributeMaster.setAttrType(rs.getInt("attr_type"));
				enetityAttributeMaster.setFreeTextType(rs.getString("free_text_type_chk"));
				enetityAttributeMaster.setOperatorFlag(rs.getString("free_text_type_chk"));
				return enetityAttributeMaster;
			}
		});
		return enetityAttributeList;
	}

	@Override
	public List<OprMaster> getOprList() {
		// TODO Auto-generated method stub
		String query="select OPERATOR_ID, display_value, operator_type, number_flag, date_flag, string_flag from dlp_operator_master where  validity_flag='Y' and co_flag='Y'";
		List<OprMaster> oprList = jdbcTemplate.query(query, new RowMapper<OprMaster>() {
			@Override
			public OprMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				OprMaster opreMaster = new OprMaster();
				opreMaster.setOprId(rs.getInt("OPERATOR_ID"));
				opreMaster.setOprName(rs.getString("display_value"));
				opreMaster.setOprType(rs.getString("operator_type"));
				opreMaster.setDateFlag(rs.getString("date_flag"));
				opreMaster.setNumberFlag(rs.getString("number_flag"));
				opreMaster.setStringFlag(rs.getString("string_flag"));
				return opreMaster;
			}
		});
		return oprList;
	}

	
	@Override
	public List<OprMaster> getTqOprList() {
		// TODO Auto-generated method stub
		String query="select OPERATOR_ID, DESCRIPTION from dlp_operator_master where operator_type='L' OR operator_type='M'";
		List<OprMaster> oprList = jdbcTemplate.query(query, new RowMapper<OprMaster>() {
			@Override
			public OprMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				OprMaster opreMaster = new OprMaster();
				opreMaster.setOprId(rs.getInt("OPERATOR_ID"));
				opreMaster.setOprName(rs.getString("DESCRIPTION"));
				return opreMaster;
			}
		});
		return oprList;
	}

	
	
	@Override
	public List<ValueTypeMaster> getValueTypeList() {
		// TODO Auto-generated method stub
		String query="select VALUE_TYPE_ID,display_value from dlp_tbl_value_type_master where validity_flag = 'Y' AND co_flag = 'Y'";
		List<ValueTypeMaster> valueTypeList = jdbcTemplate.query(query, new RowMapper<ValueTypeMaster>() {
			@Override
			public ValueTypeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				ValueTypeMaster valueTypeMaster = new ValueTypeMaster();
				valueTypeMaster.setValueTypeId(rs.getInt("VALUE_TYPE_ID"));
				valueTypeMaster.setValueTypeName(rs.getString("display_value"));
				return valueTypeMaster;
			}
		});
		return valueTypeList;
	}

	
	
	@Override
	public List<SchemeMaster> getSchemeList() {
		// TODO Auto-generated method stub
		String query="select SCHEME_ID, SCHEME_NAME from DLP_SCHEME_MASTER_STAGE where VALIDITY_FLAG='Y' ORDER BY INSERT_DATE_TIME DESC";
		List<SchemeMaster> schemeList = jdbcTemplate.query(query, new RowMapper<SchemeMaster>() {
			@Override
			public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeMaster schemeMaster = new SchemeMaster();
				schemeMaster.setSchemeINputId(rs.getInt("SCHEME_ID"));
				schemeMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				return schemeMaster;
			}
		});
		return schemeList;
	}

	
	
	@Override
	public List<UnitMaster> getUnitMasterList() {
		// TODO Auto-generated method stub
		String query="select UNIT_ID,DISPLAY_VALUE from dlp_unit_master where VALIDITY_FLAG='Y'";
		List<UnitMaster> schemeList = jdbcTemplate.query(query, new RowMapper<UnitMaster>() {
			@Override
			public UnitMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				UnitMaster schemeMaster = new UnitMaster();
				schemeMaster.setUnitId(rs.getInt("UNIT_ID"));
				schemeMaster.setUnitName(rs.getString("DISPLAY_VALUE"));
				return schemeMaster;
			}
		});
		return schemeList;
	}

	
	
	@Override
	public List<CompCategoryPojo> getCategoryList() {
		// TODO Auto-generated method stub
		String query="select CAT_ID, DISPLAY_VALUE, CAT_DESCRIPTION from DLP_SCHEME_CATEGORY where VALIDITY_FLAG = 'Y'  order by DISPLAY_VALUE asc ";
		List<CompCategoryPojo> categMaster = jdbcTemplate.query(query, new RowMapper<CompCategoryPojo>() {
			@Override
			public CompCategoryPojo mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompCategoryPojo categMaster = new CompCategoryPojo();
				categMaster.setCategoryId(rs.getInt("CAT_ID"));
				categMaster.setCategory(rs.getString("DISPLAY_VALUE"));
				return categMaster;
			}
		});
		return categMaster;
	}
	
	
	private Map<String,Object> getSystemTypeValue() throws Exception {
		try{
			String query = "select SYSTEM_ID, SYSTEM_DESC from DLP_SYSTEM_DETAILS where VALIDITY_FLAG='Y'";
			Map<String,Object>  map = jdbcTemplate.queryForMap(query);
			return map;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
}

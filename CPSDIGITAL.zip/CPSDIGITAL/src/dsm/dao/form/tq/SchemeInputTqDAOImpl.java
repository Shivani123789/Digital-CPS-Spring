package dsm.dao.form.tq;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import dsm.model.DB.CompMaster;
import dsm.model.DB.TqValueMaster;
import dsm.model.DB.TransDataCSV;
import dsm.model.DB.TransSubData;
import dsm.model.po.SchemePoMaster;
import dsm.model.tq.DataSetTQModel;
import dsm.model.tq.OprTQModel;
import dsm.model.tq.P_ParamTQModel;
import dsm.model.tq.SchemeComponenetTQModel;
import dsm.model.tq.ValueTypeTQModel;

public class SchemeInputTqDAOImpl implements SchemeInputTqDAO {

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	HttpSession httpSession;
	
public SchemeInputTqDAOImpl(){}
	
	public SchemeInputTqDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	
	
	
	@Override
	public List<CompMaster> getCompListForTq() {
		try{
			if(httpSession.getAttribute("schemeId")!=null){
				int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
				String query = "select component_id,componenet_name from dlp_scheme_comp_mapping_stage where scheme_id = ?"; 
				List<CompMaster> listContact = jdbcTemplate.query(query, new Object[]{schemeId}, new RowMapper<CompMaster>() {
					@Override
					public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
						CompMaster compMaster = new CompMaster();
						compMaster.setCompId(rs.getInt("component_id"));
						compMaster.setCompName(rs.getString("componenet_name"));
						return compMaster;
					}
				});
				return listContact;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}


	
	
	
	@Override
	public List<SchemeComponenetTQModel> getComponenetList() {
		String query="select SCM_NO,SCHEME_NAME,COMP_NO,COMP_NAME from dlp_tbl_excel_co_prestag";
		List<SchemeComponenetTQModel> scmList = jdbcTemplate.query(query, new RowMapper<SchemeComponenetTQModel>() {
			@Override
			public SchemeComponenetTQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeComponenetTQModel scmCmp = new SchemeComponenetTQModel();
				scmCmp.setSchemeCmpId(rs.getInt("SCM_NO"));
				scmCmp.setSchemeCmpName(rs.getString("SCHEME_NAME"));
				return scmCmp;
			}
		});
		return scmList;
	}

	@Override
	public List<DataSetTQModel> getDataSetList() {
		// TODO Auto-generated method stub
		String query=" select input_type_id,display_value from dlp_tbl_input_type_master where tq_flag='Y' and validity_flag='Y'";
		List<DataSetTQModel> dataSetList = jdbcTemplate.query(query, new RowMapper<DataSetTQModel>() {
			@Override
			public DataSetTQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				DataSetTQModel dataSet = new DataSetTQModel();
				dataSet.setDataSetId(rs.getInt("input_type_id"));
				dataSet.setDataSetName(rs.getString("display_value"));
				return dataSet;
			}
		});
		return dataSetList;
	}

	@Override
	public List<P_ParamTQModel> getParamList() {
		// TODO Auto-generated method stub
		String query="select uni_fld_seq_no,uni_field_display_value,universe_id,dta_type from dlp_tbl_universe_field_map where uni_field_cat_flag='Y' and validity_flag='Y' and uni_field_display_value!='null' and circle_id = ? order by UNI_FIELD_DISPLAY_VALUE asc";//uni_fld_seq_no
		List<P_ParamTQModel> paramList = jdbcTemplate.query(query, new Object[]{Integer.valueOf(httpSession.getAttribute("circleId").toString())},new RowMapper<P_ParamTQModel>() {
			@Override
			public P_ParamTQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				P_ParamTQModel param = new P_ParamTQModel();
				param.setParamId(rs.getInt("uni_fld_seq_no"));
				param.setUnivId(rs.getInt("universe_id"));
				param.setParamName(rs.getString("uni_field_display_value"));
				param.setDtaType(rs.getString("dta_type"));
				return param;
			}
		});
		return paramList;
	}

	@Override
	public List<OprTQModel> getOprList() {
		// TODO Auto-generated method stub
		String query="select operator_id,display_value,operator_type,number_flag,date_flag,string_flag from dlp_operator_master where tq_flag='Y' and validity_flag='Y'";
		List<OprTQModel> oprList = jdbcTemplate.query(query, new RowMapper<OprTQModel>() {
			@Override
			public OprTQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				OprTQModel opr = new OprTQModel();
				opr.setOprId(rs.getInt("operator_id"));
				opr.setOprName(rs.getString("display_value"));
				opr.setDateFlag(rs.getString("date_flag"));
				opr.setNumberFlag(rs.getString("number_flag"));
				opr.setStringFlag(rs.getString("string_flag"));
				return opr;
			}
		});
		return oprList;
	}

	
	@Override
	public List<ValueTypeTQModel> getValueTypeList() {
		String query="select value_type_id,display_value from dlp_tbl_value_type_master where tq_flag='Y' and validity_flag='Y'";
		List<ValueTypeTQModel> valueTypeList = jdbcTemplate.query(query, new RowMapper<ValueTypeTQModel>() {
			@Override
			public ValueTypeTQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				ValueTypeTQModel valueType = new ValueTypeTQModel();
				valueType.setValueTypeId(rs.getInt("value_type_id"));
				valueType.setValueTypeName(rs.getString("display_value"));
				return valueType;
			}
		});
		return valueTypeList;
	}

	
	@Override
	public List<TqValueMaster> valueList() {
		// TODO Auto-generated method stub
		String query="select uni_fld_seq_no,uni_field_display_value,universe_id,dta_type from dlp_tbl_universe_field_map where uni_field_cat_flag='Y' and validity_flag='Y' and uni_field_display_value!='null' and circle_id = ?";
		List<TqValueMaster> valueList = jdbcTemplate.query(query, new Object[]{Integer.valueOf(httpSession.getAttribute("circleId").toString())}, new RowMapper<TqValueMaster>() {
			@Override
			public TqValueMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				TqValueMaster value = new TqValueMaster();
				value.setUnivId(rs.getInt("universe_id"));
				value.setUnivName(rs.getString("uni_field_display_value"));
				value.setDataType(rs.getString("dta_type"));
				return value;
			}
		});
		return valueList;
	}

	
	@Override
	public TransDataCSV transDataNotQualify(TransSubData transdata) {
		Connection connection=null;
		TransDataCSV trans = new TransDataCSV();
		try{
			/*SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DLP_GET_RPT_VALUE").declareParameters(new SqlOutParameter("pOUTVAL", Types.));

			Map<String, Object> inParamMap = new HashMap<String, Object>();

			inParamMap.put("pTYPE", transdata.getTransSubDataType());
			inParamMap.put("pCIRCLE_ID", transdata.getCircleId());
			inParamMap.put("pSCM_ID", transdata.getSchemeId());
			inParamMap.put("pCOMP_ID", transdata.getCompId());
			inParamMap.put("pCONVARID", transdata.getConditionId());
			inParamMap.put("pQTYPE", transdata.getQualifyType());
			
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);

			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);

			//System.out.println("Change Request "+simpleJdbcCallResult);
			return simpleJdbcCallResult.toString();*/
			
			 connection = jdbcTemplate.getDataSource().getConnection();
			String dlpGetRptValue = "{call DLP_GET_RPT_VALUE(?,?,?,?,?,?,?,?) }";
			//String dlpGetRptValue = "{call DLP_GET_RPT_VALUE( pTYPE, pCIRCLE_ID,pSCM_ID,pCOMP_ID,pCONVARID,pQTYPE,pOUTVAL,pOUT_CURSOR) }";
			
			CallableStatement callableStmt = connection.prepareCall(dlpGetRptValue);
			/*callableStmt.setString("pTYPE", transdata.getTransSubDataType());
			callableStmt.setInt("pCIRCLE_ID", transdata.getCircleId());
			callableStmt.setInt("pSCM_ID", transdata.getSchemeId());
			callableStmt.setInt("pCOMP_ID", transdata.getCompId());
			callableStmt.setInt("pCONVARID", transdata.getConditionId());
			callableStmt.setInt("pQTYPE", transdata.getQualifyType());
			callableStmt.registerOutParameter("pOUTVAL", java.sql.Types.VARCHAR);
			callableStmt.registerOutParameter("pOUT_CURSOR", OracleTypes.CURSOR);
			*/
			callableStmt.setString(1, transdata.getTransSubDataType());
			callableStmt.setInt(2, transdata.getCircleId());
			callableStmt.setInt(3, transdata.getSchemeId());
			callableStmt.setInt(4, transdata.getCompId());
			callableStmt.setInt(5, transdata.getConditionId());
			callableStmt.setInt(6, transdata.getQualifyType());
			callableStmt.registerOutParameter(7, java.sql.Types.VARCHAR);
			callableStmt.registerOutParameter(8, OracleTypes.CURSOR);
			
			callableStmt.execute();
			
			String flag = (String)callableStmt.getString(7);
			
			trans.setStatus(flag);
			StringBuffer buffer=new StringBuffer();
			//System.out.println("flag ::::  "+flag);
			if("Success".equalsIgnoreCase(flag)){
				ResultSet rs = (ResultSet)callableStmt.getObject(8);
				//rs.setFetchSize(50000);
				
				
				
				ResultSetMetaData rsm = rs.getMetaData();
				int columnCount = rsm.getColumnCount();
				
				//setting Column Name
				
				//List<String> listColumnName = new ArrayList<String>(); 
				for(int i=0; i < columnCount; i++){
				//testing for buf
				//	listColumnName.add(rsm.getColumnName(i+1));
					//setting for csv
					buffer.append(rsm.getColumnName(i+1));
					buffer.append(", ");
				}
				
				buffer.append("Error_Message");
				buffer.append("\n");
				
				//testing for buf
				//trans.setColumnName(listColumnName);
				rs.setFetchDirection(ResultSet.FETCH_FORWARD);
				rs.setFetchSize(10000);
				//System.out.println("rs size : "+rs.getFetchSize());
				
				//set values
				//int key = 0;
				//Map<Integer, List> keyValues = new HashMap<Integer,List>(); 
				while(rs.next()){
					//++key;
					//List values = new ArrayList();
					for (int j=0;j< columnCount;j++){
						//Testing for buff
						//values.add(rs.getObject(j+1));
						buffer.append(rs.getObject(j+1)); 
						buffer.append(", "); 
						//System.out.println("J :: "+j+" ColumnName :: "+rsm.getColumnName(j+1));//+" "+rs.getObject(j+1)
					}
					buffer.append("");
					buffer.append("\n");
					//test for buff
					//keyValues.put(key, values);
				}
				
				//trans.setValues(keyValues);
				////System.out.println(""+new Date());
			}else{
				   buffer.append("NO RECORDS AVAILABLE.");
				   buffer.append("\n"); 
			   }
			trans.setGenerateCsv(buffer);
			return trans;
			
		}catch(Exception e){
			System.err.println(e);
			trans.setError(true);
			trans.setStatus("Problem in DB try again.");
			return trans;
		}finally{
			if(connection!=null)
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}

	

	@Override
	public String copyCondition(SchemePoMaster po) throws Exception {
		try{
			SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("DLP_SCHEME_COPY_CONDITION");
			Map<String, Object> inParamMap = new HashMap<String, Object>();
			inParamMap.put("pschemeId", po.getSchemeId());
			inParamMap.put("pcompId", po.getCompId());
			inParamMap.put("pcondId", po.getCondId());
			inParamMap.put("puser_code", po.getProcessType());
			SqlParameterSource in = new MapSqlParameterSource(inParamMap);
			Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
			return simpleJdbcCallResult.get("P_OUT_MSG").toString();
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}


}

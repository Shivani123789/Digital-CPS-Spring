package dsm.dao.form.tq;

import java.util.List;

import dsm.model.DB.TqValueMaster;
import dsm.model.tq.DataSetTQModel;
import dsm.model.tq.OprTQModel;
import dsm.model.tq.P_ParamTQModel;
import dsm.model.tq.SchemeComponenetTQModel;
import dsm.model.tq.ValueTypeTQModel;



public class SchemeInputTq {
	
	public List<SchemeComponenetTQModel> schemeList;
	public List<DataSetTQModel> dataSetList;
	public List<P_ParamTQModel> paramList;
	public List<OprTQModel> oprList;
	public List<TqValueMaster> getValueList() {
		return valueList;
	}
	public void setValueList(List<TqValueMaster> valueList) {
		this.valueList = valueList;
	}
	public List<ValueTypeTQModel> valueTypeList;
	public List<TqValueMaster> valueList;
	public List<SchemeComponenetTQModel> getSchemeList() {
		return schemeList;
	}
	public void setSchemeList(List<SchemeComponenetTQModel> schemeList) {
		this.schemeList = schemeList;
	}
	public List<DataSetTQModel> getDataSetList() {
		return dataSetList;
	}
	public void setDataSetList(List<DataSetTQModel> dataSetList) {
		this.dataSetList = dataSetList;
	}
	public List<P_ParamTQModel> getParamList() {
		return paramList;
	}
	public void setParamList(List<P_ParamTQModel> paramList) {
		this.paramList = paramList;
	}
	public List<OprTQModel> getOprList() {
		return oprList;
	}
	public void setOprList(List<OprTQModel> oprList) {
		this.oprList = oprList;
	}
	public List<ValueTypeTQModel> getValueTypeList() {
		return valueTypeList;
	}
	public void setValueTypeList(List<ValueTypeTQModel> valueTypeList) {
		this.valueTypeList = valueTypeList;
	}
	
	

}

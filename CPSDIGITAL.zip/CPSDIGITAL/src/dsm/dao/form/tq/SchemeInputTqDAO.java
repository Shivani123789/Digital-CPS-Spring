package dsm.dao.form.tq;

import java.util.List;

import dsm.model.DB.CompMaster;
import dsm.model.DB.TqValueMaster;
import dsm.model.DB.TransDataCSV;
import dsm.model.DB.TransSubData;
import dsm.model.po.SchemePoMaster;
import dsm.model.tq.DataSetTQModel;
import dsm.model.tq.OprTQModel;
import dsm.model.tq.P_ParamTQModel;
import dsm.model.tq.SchemeComponenetTQModel;
import dsm.model.tq.ValueTypeTQModel;

public interface SchemeInputTqDAO {
	public List<SchemeComponenetTQModel> getComponenetList();
	public List<DataSetTQModel> getDataSetList();
	public List<P_ParamTQModel> getParamList();
	public List<OprTQModel> getOprList();
	public List<ValueTypeTQModel> getValueTypeList();
	public List<TqValueMaster> valueList();
	public TransDataCSV transDataNotQualify(TransSubData transdata) ;
	public List<CompMaster> getCompListForTq();
	public String copyCondition(SchemePoMaster po) throws Exception;
}

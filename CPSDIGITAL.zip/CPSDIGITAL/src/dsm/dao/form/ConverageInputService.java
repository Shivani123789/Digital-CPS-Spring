package dsm.dao.form;

public interface ConverageInputService {
	
	public CoverageOutput getConverageDetails();
	public CoverageOutput getCompList(String schemeName) throws Exception;
	public CoverageOutput getCompListReg(String schemeName);

}

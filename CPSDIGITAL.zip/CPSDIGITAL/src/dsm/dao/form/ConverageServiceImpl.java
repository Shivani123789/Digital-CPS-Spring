package dsm.dao.form;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ConverageServiceImpl implements ConverageInputService {
	//private JdbcTemplate jdbcTemplate;
	
	@Autowired
	ConverageInputDAO converagedao=null;
	
	public ConverageServiceImpl(){}
		
	CoverageOutput coverageOutput=new CoverageOutput();
	
	//ConverageInputDAO converagedao=new ConverageInputDAOImpl();
	/*public ConverageService(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	*/
	 
	@Transactional
	public CoverageOutput getConverageDetails(){
		if(converagedao!=null){
			
		}else{
			
		}
		
		//System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>called getConverageDetails");
		//System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>"+converagedao.getPayoutList().size());
	     

		coverageOutput.setPayoutList(converagedao.getPayoutFrequency());
		//System.out.println(">>>>>>>>>>>>size"+converagedao.getPayoutList().size());
		coverageOutput.setRegionList(converagedao.getRegionList());
		coverageOutput.setPayToList(converagedao.getPayToList());
		coverageOutput.setUploadList(converagedao.getUploadList());
		coverageOutput.setVerticalList(converagedao.getVerticalList());
		coverageOutput.setZoneList(converagedao.getZoneList());
		//coverageOutput.setCircleList(converagedao.getCircleList());
		coverageOutput.setPayoutConditionList(converagedao.getPayoutCondtion());
		coverageOutput.setEntityList(converagedao.getEntityList());
		coverageOutput.setAttributeTypeList(converagedao.getAttributeTypeList());
		coverageOutput.setFunctionList(converagedao.getFunctionList());
		coverageOutput.setEntityAttributeList(converagedao.getEntityAttributeList());
		coverageOutput.setOprList(converagedao.getOprList());
		coverageOutput.setValueTypeList(converagedao.getValueTypeList());
		coverageOutput.setSchemeList(converagedao.getSchemeList());
		coverageOutput.setUnitList(converagedao.getUnitMasterList());
		coverageOutput.setTqOprList(converagedao.getTqOprList());
		coverageOutput.setCategoryDet(converagedao.getCategoryList());
		//coverageOutput.setCompMasterList(converagedao.getCompMasterList());
		
		
		return coverageOutput;
		
	}

	@Override
	public CoverageOutput getCompList(String schemeName) throws Exception{
		// TODO Auto-generated method stub
		coverageOutput.setCompMasterList(converagedao.getCompMasterList(schemeName));
		return coverageOutput;
	}
	
	@Override
	public CoverageOutput getCompListReg(String schemeName) {
		// TODO Auto-generated method stub
		coverageOutput.setCompMasterListReg(converagedao.getCompMasterListReg(schemeName));
		return coverageOutput;
	}
}
	



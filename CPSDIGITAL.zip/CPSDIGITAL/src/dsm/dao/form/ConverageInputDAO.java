package dsm.dao.form;

import java.util.List;

import dsm.model.DB.CompCategoryPojo;
import dsm.model.DB.CompMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.form.AttributeTypeMaster;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.form.EntityMaster;
import dsm.model.form.FunctionMaster;
import dsm.model.form.OprMaster;
import dsm.model.form.PayToMaster;
import dsm.model.form.PayoutFrequency;
import dsm.model.form.RegionMaster;
import dsm.model.form.SchemaMaster;
import dsm.model.form.UnitMaster;
import dsm.model.form.UploadMaster;
import dsm.model.form.ValueTypeMaster;
import dsm.model.form.VerticalMaster;
import dsm.model.form.ZoneMaster;
import dsm.model.po.PayoutCondition;





public interface ConverageInputDAO {
	
public List<PayoutFrequency> getPayoutFrequency();
public List<VerticalMaster> getVerticalList();
public List<RegionMaster> getRegionList();
public List<SchemaMaster> getSchemaList();
public List<ZoneMaster> getZoneList();
public List<UploadMaster> getUploadList();
public List<PayToMaster> getPayToList();
//public List<CircleMaster> getCircleList();
public List<PayoutCondition> getPayoutCondtion();

public List<EntityMaster> getEntityList();
public List<AttributeTypeMaster> getAttributeTypeList();
public List<FunctionMaster> getFunctionList();
public List<EntityAttributeMaster> getEntityAttributeList();
public List<OprMaster> getOprList();
public List<ValueTypeMaster> getValueTypeList();
public List<SchemeMaster> getSchemeList();

public List<CompMaster> getCompMasterList(String schemeName) throws Exception;
public List<UnitMaster> getUnitMasterList();
public List<OprMaster> getTqOprList();
public List<CompMaster> getCompListForCoverage();

public List<CompMaster> getCompMasterListReg(String schemeName);

public List<CompCategoryPojo> getCategoryList();














}

package dsm.dao.master;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import dsm.dataBase.query.MasterQueries;
import dsm.model.form.CircleMaster;
import dsm.model.form.ComponentMasterCombo;
import dsm.model.form.ParamCategory;
import dsm.model.form.PayToMaster;
import dsm.model.form.SchemaMaster;

public class MasterDAOImpl implements MasterDAO{

	private JdbcTemplate jdbcTemplate;
	
	public MasterDAOImpl(){
		
	}
	
	public MasterDAOImpl(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public List<CircleMaster> getCircleMasterList() throws Exception{
		List<CircleMaster> circleMasterList = jdbcTemplate.query(MasterQueries.CIRCLE_MASTER, new RowMapper<CircleMaster>() {
			@Override
			public CircleMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CircleMaster circleMaster = new CircleMaster();
				circleMaster.setCircleId(rs.getInt("CIRCLE_NUMBER"));
				circleMaster.setCircleCode(rs.getString("CIRCLE_CODE"));
				circleMaster.setCircleName(rs.getString("CIRCLE_NAME"));
				return circleMaster;
			}
		});
		return circleMasterList;
	}

	@Override
	public List<SchemaMaster> getSchemeMasterList(int circleId,String startDt, String endDt) throws Exception{
		List<SchemaMaster> schemeMasterList = jdbcTemplate.query(MasterQueries.SCHEME_MASTER, new Object[]{circleId,startDt, endDt}, new RowMapper<SchemaMaster>() {
			@Override
			public SchemaMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemaMaster schemeMaster = new SchemaMaster();
				schemeMaster.setSchemaId(rs.getInt("SCHEME_ID"));
				schemeMaster.setSchemaName(rs.getString("SCHEME_NAME"));
				schemeMaster.setCircleId(rs.getInt("CIRCLE_ID"));
				return schemeMaster;
			}
		});
		return schemeMasterList;
	}
	
	@Override
	public List<ComponentMasterCombo> getComponentMasterList(int schemeId) throws Exception{
		List<ComponentMasterCombo> compMasterList = jdbcTemplate.query(MasterQueries.COMPONENT_MASTER, new Object[]{schemeId}, new RowMapper<ComponentMasterCombo>() {
			@Override
			public ComponentMasterCombo mapRow(ResultSet rs, int rowNum) throws SQLException {
				ComponentMasterCombo compMaster = new ComponentMasterCombo();
				compMaster.setCompId(rs.getInt("COMPONENT_ID"));
				compMaster.setCompName(rs.getString("COMPONENET_NAME"));
				compMaster.setSchemaId(rs.getInt("SCHEME_ID"));
				return compMaster;
			}
		});
		return compMasterList;
	}

	@Override
	public List<ParamCategory> getParamCatMasterList(int circleId) throws Exception{
		List<ParamCategory> paramCatMasterList = jdbcTemplate.query(MasterQueries.PARAM_CATEGORY_MASTER, new Object[]{circleId},  new RowMapper<ParamCategory>() {
			@Override
			public ParamCategory mapRow(ResultSet rs, int rowNum) throws SQLException {
				ParamCategory paramMaster = new ParamCategory();
				paramMaster.setCategoryId(rs.getInt("CATEGORY_ID"));
				paramMaster.setCircleId(rs.getInt("CIRCLE_ID"));
				paramMaster.setCategoryName(rs.getString("CATEGORY_NAME"));
				paramMaster.setDescription(rs.getString("DESCRIPTION"));
				return paramMaster;
			}
		});
		return paramCatMasterList;
	}
	

	@Override
	public List<PayToMaster> getPayToDetails() throws Exception
	{
	   String query="select ENTITY_TYPE_ID,DESCRIPTION,DISPLAY_VALUE from DLP_Entity_Type_Master   union select 11,'ALL','ALL' from dual order by ENTITY_TYPE_ID desc";
	   List<PayToMaster> payToList=	jdbcTemplate.query(query, new RowMapper<PayToMaster>() {
			@Override
			public PayToMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				PayToMaster payToMaster = new PayToMaster();
				payToMaster.setEntityTypeId(rs.getInt(1));
				payToMaster.setDescription(rs.getString(2));
				payToMaster.setDisplayValue(rs.getString(3));
				return payToMaster;
			}
	   });
	   return payToList;
	}
	
}

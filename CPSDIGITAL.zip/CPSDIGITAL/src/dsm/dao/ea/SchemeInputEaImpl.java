package dsm.dao.ea;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import dsm.model.ea.DataSetEQModel;
import dsm.model.ea.DataSourceEQModel;
import dsm.model.ea.DayLvlAggr;
import dsm.model.ea.FunctionEaModel;
import dsm.model.ea.OprEaModel;
import dsm.model.ea.ParameterEQModel;
import dsm.model.ea.SchemeComponentEQModel;
import dsm.model.ea.ValueTypeEQModel;
import dsm.model.form.AttributeTypeMaster;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.user.User;
//import dsm.model.form.FunctionMaster;
//import dsm.model.tq.DataSetTQModel;
//import dsm.model.tq.OprTQModel;
//import dsm.model.tq.ValueTypeTQModel;


public class SchemeInputEaImpl implements SchemeInputEaDAO {

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	HttpSession httpSession;
	
	public SchemeInputEaImpl(){}
		
		public SchemeInputEaImpl(DataSource dataSource) {
			jdbcTemplate = new JdbcTemplate(dataSource);
		}
	
	@Override
	public List<SchemeComponentEQModel> getSchemeList() {
		String query="select SCM_NO,SCHEME_NAME,COMP_NO,COMP_NAME from dlp_tbl_excel_tq_prestag";
		List<SchemeComponentEQModel> scmList = jdbcTemplate.query(query, new RowMapper<SchemeComponentEQModel>() {
			@Override
			public SchemeComponentEQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeComponentEQModel scmCmp = new SchemeComponentEQModel();
				scmCmp.setScmCompId(rs.getInt("SCM_NO"));
				scmCmp.setScmCompName(rs.getString("SCHEME_NAME"));
				return scmCmp;
			}
		});
		return scmList;
	}

	
	
	@Override
	public List<DataSetEQModel> getDataSetList() {
		// TODO Auto-generated method stub
		String query="select AGG_TYPE_ID,display_value from dlp_aggregate_type_master where validity_flag='Y'";
		List<DataSetEQModel> dataSetList = jdbcTemplate.query(query, new RowMapper<DataSetEQModel>() {
			@Override
			public DataSetEQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				DataSetEQModel dataSet = new DataSetEQModel();
				dataSet.setDataSetId(rs.getInt("AGG_TYPE_ID"));
				dataSet.setDataSetName(rs.getString("display_value"));
				return dataSet;
			}
		});
		return dataSetList;
	}

	
	
	@Override
	public List<DataSourceEQModel> getDataSourceList(String schemeName) {
		// TODO Auto-generated method stub
		int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString()); 
		String query="select component_id,condition_id dsId,condition_name dsName from DLP_SCM_TQ_COND_CONFIG_STAGE where scheme_id=(select scheme_id from DLP_SCHEME_MASTER_STAGE where scheme_name = ? AND circle_id = ? ) and ropr IN (25,23)";
		List<DataSourceEQModel> dataSourceList = jdbcTemplate.query(query, new Object[]{schemeName,circleId},  new RowMapper<DataSourceEQModel>() {
			@Override
			public DataSourceEQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				DataSourceEQModel dataSource = new DataSourceEQModel();
				dataSource.setDataSourceId(rs.getInt("dsId"));
				dataSource.setDataSourceName(rs.getString("dsName"));
				dataSource.setCompId(rs.getInt("component_id"));
				dataSource.setValFlag("C");
				return dataSource;
			}
		});
		return dataSourceList;
	}
	
	
	@Override
	public List<AttributeTypeMaster> getEaFilterDataSet() {
		String query="select INPUT_TYPE_ID,DISPLAY_VALUE,ea_con_flag,ea_var_flag from dlp_tbl_input_type_master where validity_flag='Y'";
		List<AttributeTypeMaster> attribteList = jdbcTemplate.query(query, new RowMapper<AttributeTypeMaster>() {
			@Override
			public AttributeTypeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				AttributeTypeMaster attributeMaster = new AttributeTypeMaster();
				attributeMaster.setAttributeTypeId(rs.getInt("INPUT_TYPE_ID"));
				attributeMaster.setAttributeTypeName(rs.getString("DISPLAY_VALUE"));
				attributeMaster.setEaFilterConFlag(rs.getString("ea_con_flag"));
				attributeMaster.setEaFilterVarFlag(rs.getString("ea_var_flag"));
				return attributeMaster;
			}
		});
		return attribteList;
	}


	@Override
	public List<FunctionEaModel> getFunctionList() {
		String query="select function_id,display_value,function_type from dlp_tbl_function_master where entity_agg_flag='Y' and validity_flag='Y'";
		List<FunctionEaModel> functionList = jdbcTemplate.query(query, new RowMapper<FunctionEaModel>() {
			@Override
			public FunctionEaModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				FunctionEaModel functionMaster = new FunctionEaModel();
				functionMaster.setFunctionId(rs.getInt("function_id"));
				functionMaster.setFunctionName(rs.getString("display_value"));
				functionMaster.setFunctionType(rs.getString("function_type"));
				return functionMaster;
			}
		});
		return functionList;
	}
	

	@Override
	public List<ParameterEQModel> getParameterList() {
		// TODO Auto-generated method stub
		//int dataSetId =  Integer.valueOf(httpSession.getAttribute("dataSetId").toString());
		//int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
		/*String query="select uni_fld_seq_no,uni_field_display_value from dlp_tbl_universe_field_map where " +
				"universe_id = (select data_set from DLP_SCM_TQ_COND_CONFIG_STAGE where scheme_id = (select scheme_id from dlp_scheme_master_stage " +
				"where scheme_name='"+httpSession.getAttribute("schemeName")+"' and circle_id="+circleId+") and ropr=25 and rownum=1) AND uni_field_cat_flag='Y' AND validity_flag='Y' AND circle_id="+circleId;
		
		*/
		try{
			if(httpSession.getAttribute("circleId")!=null){
				int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				String query = "select UNV.UNI_FLD_SEQ_NO,UNV.UNI_FIELD_DISPLAY_VALUE,UNV.DTA_TYPE,UNV.universe_id from DLP_TBL_UNIVERSE_FIELD_MAP unv where UNV.VALIDITY_FLAG='Y' and UNV.UNI_FIELD_CAT_FLAG='Y' and UNV.CIRCLE_ID = ? order by UNV.UNI_FIELD_DISPLAY_VALUE asc";
				//System.out.println("Param Query EA "+query);
				List<ParameterEQModel> paramList = jdbcTemplate.query(query, new Object[]{circleId}, new RowMapper<ParameterEQModel>() {
					@Override
					public ParameterEQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
						ParameterEQModel paramMaster = new ParameterEQModel();
						paramMaster.setParamId(rs.getInt("uni_fld_seq_no"));
						paramMaster.setParamName(rs.getString("uni_field_display_value"));
						paramMaster.setValFlag("C");
						paramMaster.setOprDataType(rs.getString("DTA_TYPE"));
						paramMaster.setUnverseId(rs.getInt("universe_id"));

						return paramMaster;
					}
				});
				return paramList;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

	
	@Override
	public List<EntityAttributeMaster> getEntityAttributeListEa() {
		// TODO Auto-generated method stub
		//int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
		User user = (User)httpSession.getAttribute("appUser");;
		String query="select ATTR_SEQ_NO,DISPLAY_NAME,attr_catg,attr_type,free_text_type_chk,operator_flag from dlp_tbl_entity_attr_mapping where validity_flag='Y' AND entity_agg_flag='Y' AND (circle_id = ? or circle_id is null) order by DISPLAY_NAME asc";
		List<EntityAttributeMaster> enetityAttributeList = jdbcTemplate.query(query, new Object[]{user.getCircleId()},new RowMapper<EntityAttributeMaster>() {
			@Override
			public EntityAttributeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				EntityAttributeMaster enetityAttributeMaster = new EntityAttributeMaster();
				enetityAttributeMaster.setEntityAttributeId(rs.getInt("ATTR_SEQ_NO"));
				enetityAttributeMaster.setEntityAttributeName(rs.getString("DISPLAY_NAME"));
				enetityAttributeMaster.setAttrCatg(rs.getInt("attr_catg"));
				enetityAttributeMaster.setAttrType(rs.getInt("attr_type"));
				enetityAttributeMaster.setFreeTextType(rs.getString("free_text_type_chk"));
				enetityAttributeMaster.setOperatorFlag(rs.getString("free_text_type_chk"));
				return enetityAttributeMaster;
			}
		});
		return enetityAttributeList;
	}

	
	
	@Override
	public List<OprEaModel> getOprList() {
		// TODO Auto-generated method stub
		String query="select operator_id,display_value,ea_var_flag,ea_con_flag,operator_type,number_flag,date_flag,string_flag from dlp_operator_master where validity_flag='Y'";
		List<OprEaModel> oprList = jdbcTemplate.query(query, new RowMapper<OprEaModel>() {
			@Override
			public OprEaModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				OprEaModel opr = new OprEaModel();
				opr.setOprId(rs.getInt("operator_id"));
				opr.setOprName(rs.getString("display_value"));
				opr.setOprType(rs.getString("operator_type"));
				opr.setValFlagcon(rs.getString("ea_con_flag"));
				opr.setValFlagvar(rs.getString("ea_var_flag"));
				opr.setStringFlag(rs.getString("string_flag"));
				opr.setNumberFlag(rs.getString("number_flag"));
				opr.setDataFlag(rs.getString("date_flag"));
				return opr;
			}
		});
		return oprList;
	}

	
	
	@Override
	public List<ValueTypeEQModel> getValueTypeList() {
		String query="select value_type_id,display_value,ea_var_flag,ea_con_flag from dlp_tbl_value_type_master where  validity_flag='Y'";
		List<ValueTypeEQModel> valueTypeList = jdbcTemplate.query(query, new RowMapper<ValueTypeEQModel>() {
			@Override
			public ValueTypeEQModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				ValueTypeEQModel valueType = new ValueTypeEQModel();
				valueType.setValueTypeId(rs.getInt("value_type_id"));
				valueType.setValueTypeName(rs.getString("display_value"));
				valueType.setVarFlag(rs.getString("ea_var_flag"));
				valueType.setConFlag(rs.getString("ea_con_flag"));
				return valueType;
			}
		});
		return valueTypeList;
	}

	
	
	@Override
	public List<DayLvlAggr> getDayLvlAggrList(int circleId) {
		String query="select DAY_LEVEL_AGG_ID,CIRCLE_ID,UNIVERSE_ID,DAY_LEVEL_AGG_FIELD_NAME,DAY_LEVEL_AGG_FIELD_DSP_NAME," +
				" VALIDITY_FLAG  from DLP_EA_CONFIG_DAY_LEVEL_AGG where CIRCLE_ID = ? and VALIDITY_FLAG='Y'";
		//System.out.println("getDayLvlAggrList - query:: "+query);
		List<DayLvlAggr> list = jdbcTemplate.query(query, new Object[]{circleId}, new RowMapper<DayLvlAggr>() {
			@Override
			public DayLvlAggr mapRow(ResultSet rs, int rowNum) throws SQLException {
				DayLvlAggr valueType = new DayLvlAggr();
				valueType.setDayLvlAggrId(rs.getInt("DAY_LEVEL_AGG_ID"));
				valueType.setUniverseId(rs.getInt("UNIVERSE_ID"));
				valueType.setDayLvlAggrFieldName(rs.getString("DAY_LEVEL_AGG_FIELD_NAME"));
				valueType.setDayLvlAggrDisplayName(rs.getString("DAY_LEVEL_AGG_FIELD_DSP_NAME"));
				return valueType;
			}
		});
		return list;
	}

	

}

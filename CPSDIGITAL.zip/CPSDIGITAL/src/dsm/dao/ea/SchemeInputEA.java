package dsm.dao.ea;

import java.util.List;

import dsm.model.ea.DataSetEQModel;
import dsm.model.ea.DataSourceEQModel;
import dsm.model.ea.FunctionEaModel;
import dsm.model.ea.OprEaModel;
import dsm.model.ea.ParameterEQModel;
import dsm.model.ea.SchemeComponentEQModel;
import dsm.model.ea.ValueTypeEQModel;


public class SchemeInputEA {

	public List<SchemeComponentEQModel> schemeList;
	public List<DataSetEQModel> dataSetList;
	public List<DataSourceEQModel> dataSourceList;
	public List<FunctionEaModel> functionList;
	public List<OprEaModel> oprList;
	public List<ParameterEQModel> parameterList;
	public List<ValueTypeEQModel> valueTypeList;
//	public List<ValueTypeEQModel> valueList;
	
	
	public List<SchemeComponentEQModel> getSchemeList() {
		return schemeList;
	}
	public void setSchemeList(List<SchemeComponentEQModel> schemeList) {
		this.schemeList = schemeList;
	}
	public List<DataSetEQModel> getDataSetList() {
		return dataSetList;
	}
	public void setDataSetList(List<DataSetEQModel> dataSetList) {
		this.dataSetList = dataSetList;
	}
	public List<DataSourceEQModel> getDataSourceList() {
		return dataSourceList;
	}
	public void setDataSourceList(List<DataSourceEQModel> dataSourceList) {
		this.dataSourceList = dataSourceList;
	}
	public List<FunctionEaModel> getFunctionList() {
		return functionList;
	}
	public void setFunctionList(List<FunctionEaModel> functionList) {
		this.functionList = functionList;
	}
	public List<OprEaModel> getOprList() {
		return oprList;
	}
	public void setOprList(List<OprEaModel> oprList) {
		this.oprList = oprList;
	}
	public List<ParameterEQModel> getParameterList() {
		return parameterList;
	}
	public void setParameterList(List<ParameterEQModel> parameterList) {
		this.parameterList = parameterList;
	}
	public List<ValueTypeEQModel> getValueTypeList() {
		return valueTypeList;
	}
	public void setValueTypeList(List<ValueTypeEQModel> valueTypeList) {
		this.valueTypeList = valueTypeList;
	}
	
}

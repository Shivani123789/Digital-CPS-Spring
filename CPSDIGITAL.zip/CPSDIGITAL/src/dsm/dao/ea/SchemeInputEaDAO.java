package dsm.dao.ea;

import java.util.List;

import dsm.model.ea.DataSetEQModel;
import dsm.model.ea.DataSourceEQModel;
import dsm.model.ea.DayLvlAggr;
import dsm.model.ea.FunctionEaModel;
import dsm.model.ea.OprEaModel;
import dsm.model.ea.ParameterEQModel;
import dsm.model.ea.SchemeComponentEQModel;
import dsm.model.ea.ValueTypeEQModel;
import dsm.model.form.AttributeTypeMaster;
import dsm.model.form.EntityAttributeMaster;



public interface SchemeInputEaDAO {

	public List<SchemeComponentEQModel> getSchemeList();
	public List<DataSetEQModel> getDataSetList();
	public List<DataSourceEQModel> getDataSourceList(String schemeName);
	public List<FunctionEaModel> getFunctionList();
	public List<ParameterEQModel> getParameterList();
	public List<OprEaModel> getOprList();
	public List<ValueTypeEQModel> getValueTypeList();
	public List<AttributeTypeMaster> getEaFilterDataSet();
	public List<EntityAttributeMaster> getEntityAttributeListEa();
	public List<DayLvlAggr> getDayLvlAggrList(int circleId);
	
}

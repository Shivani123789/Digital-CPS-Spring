package dsm.dao.transData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import dsm.dataBase.query.TransactionQueries;
import dsm.model.DB.CompMaster;
import dsm.model.DB.InputTypeMasterVO;
import dsm.model.DB.PaymentDetailVO;
import dsm.model.DB.PaymentVO;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ShellScriptPojo;
import dsm.model.DB.UniverseMasterVO;
import dsm.model.search.SearchScheme;


public class TransDataDAOImpl implements TransDataDAO {

	private JdbcTemplate jdbcTemplate;
	//private static Logger logger = Logger.getLogger (TransDataDAOImpl.class);	
	 
	@Autowired
	HttpSession httpSession;
	public TransDataDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}


	public List<CompMaster> searchTransactionData(String filtertype, String startDate, String endDate, int circleId){
		
		String query =null;	
		query = " select CM.SCHEME_ID,SM.SCHEME_NAME,CM.COMPONENT_ID,CM.COMPONENET_NAME,TO_CHAR( TO_CHAR(CM.START_DATE,'DD-MON-YYYY') || ' - ' || TO_CHAR(CM.END_DATE,'DD-MON-YYYY')) as START_END_DT,"+
				" TO_CHAR(CM.START_DATE,'DD-MON-YYYY') as STARTDATE, TO_CHAR(CM.END_DATE,'DD-MON-YYYY') as ENDDATE, CM.SCM_STATUS,CM.PAYOUT_STATUS,CM.PAYMENT_STATUS,SM.CIRCLE_ID from DLP_SCHEME_COMP_MAPPING CM, DLP_SCHEME_MASTER SM" +
				" where SM.SCHEME_ID = CM.SCHEME_ID and SM.VALIDITY_FLAG=CM.VALIDITY_FLAG and CM.VALIDITY_FLAG='Y' and TRUNC(CM.START_DATE)>= ? " +
				" and TRUNC(CM.END_DATE) <= ?  and SM.CIRCLE_ID = ? order by CM.INSERT_DATE_TIME DESC";
		//logger.debug("Scheme Search Query:  "+query);
		List<CompMaster> compList = jdbcTemplate.query(query, new Object[]{startDate, endDate, circleId}, new RowMapper<CompMaster>() {
			@Override
			public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompMaster compMaster = new CompMaster();
				compMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				compMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				compMaster.setCompName(rs.getString("COMPONENET_NAME"));
				compMaster.setCompId(rs.getInt("COMPONENT_ID"));
				compMaster.setStartDtStr(rs.getString("STARTDATE"));
				compMaster.setEndDtStr(rs.getString("ENDDATE"));
				compMaster.setScmStatus(rs.getString("SCM_STATUS"));
				compMaster.setPayoutStatus(rs.getString("PAYOUT_STATUS"));
				compMaster.setPaymentStatus(rs.getString("PAYMENT_STATUS"));
				return compMaster;
			}
		});
		return compList;
	}


	public List<SchemeTqMaster> getTransactionSubData(int schemeId,int compId,int circleId){
		String query =null;	
		/*query = " select SM.SCHEME_ID,SM.SCHEME_NAME,TQ.COMPONENT_ID,CM.COMPONENET_NAME,TQ.CONDITION_NAME from DLP_SCM_TQ_COND_CONFIG TQ, DLP_SCHEME_MASTER SM, DLP_SCHEME_COMP_MAPPING CM" +
				" where  SM.SCHEME_ID=CM.SCHEME_ID and SM.SCHEME_ID=TQ.SCHEME_ID and CM.COMPONENT_ID=TQ.COMPONENT_ID and SM.VALIDITY_FLAG=TQ.VALIDITY_FLAG and" +
				" CM.VALIDITY_FLAG=TQ.VALIDITY_FLAG and TQ.SCHEME_ID = "+schemeId+" and TQ.COMPONENT_ID="+compId+" and TQ.VALIDITY_FLAG='Y'";*/
		query = "select SCHEME_ID,COMPONENT_ID,CONDITION_ID,GROUP_ID,CONDITION_ROW_ID,CONDITION_NAME,DATA_SET, " +
				" DECODE(PERF_PARAMETER,'','',(PERF_PARAMETER||' '||DECODE(OPR,'Date Range','is between '||START_DATE||' and '||END_DATE,OPR||' '||value)||' '||LOPR||' '|| " +
				" DECODE(L_PERF_PARAMETER,'','',L_PERF_PARAMETER||' '||DECODE(L_OPR,'Date Range','is between '||L_START_DATE||' and '||L_END_DATE,L_OPR||' '||L_VALUE))||DECODE(ROPR,'Add New Condition','','Close Configration','',' '||ROPR))) as CONDITION," +
				" DECODE(ROPR,'Add New Condition','1','Close Configration','1',0) AS NEXTCOND" +
				" from( SELECT TQ.SCHEME_ID,TQ.COMPONENT_ID, TQ.GROUP_ID,TQ.CONDITION_ID,TQ.CONDITION_ROW_ID,TQ.CONDITION_NAME," +
				" (SELECT DECODE(IP.DISPLAY_VALUE,'Act  Recharge','Activation and Recharge Performance','Retailer','Retailer Performance','Distributor','Distributor Performance',IP.DISPLAY_VALUE) FROM DLP_TBL_INPUT_TYPE_MASTER IP WHERE IP.VALIDITY_FLAG='Y' AND IP.TQ_FLAG='Y' AND IP.INPUT_TYPE_ID=TQ.DATA_SET) AS DATA_SET," +
				" (select UF.UNI_FIELD_DISPLAY_VALUE from DLP_TBL_UNIVERSE_FIELD_MAP UF" +
				" WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID= ?  AND UF.UNI_FLD_SEQ_NO=TQ.PERF_PARAMETER) AS PERF_PARAMETER," +
				" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=TQ.OPR) AS OPR," +
				" TQ.VALUE, TO_CHAR(TQ.START_DATE,'DD-MON-YYYY') AS START_DATE, TO_CHAR(TQ.END_DATE,'DD-MON-YYYY') AS END_DATE, (select OM.DISPLAY_VALUE from DLP_OPERATOR_MASTER OM where OM.VALIDITY_FLAG='Y' and OM.TQ_FLAG='Y' and OM.OPERATOR_TYPE in ('L') and OM.OPERATOR_ID=TQ.LOPR) as LOPR," +
				" (SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID= ?  AND UF.UNI_FLD_SEQ_NO=TQ.L_PERF_PARAMETER) AS L_PERF_PARAMETER," +
				" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=TQ.L_OPR) AS L_OPR," +
				" TQ.L_VALUE, TO_CHAR(TQ.L_START_DATE,'DD-MON-YYYY') AS L_START_DATE, TO_CHAR(TQ.L_END_DATE,'DD-MON-YYYY') AS L_END_DATE," +
				" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L','M') AND OM.OPERATOR_ID=TQ.ROPR) AS ROPR" +
				" from DLP_SCM_TQ_COND_CONFIG TQ  WHERE TQ.VALIDITY_FLAG='Y' AND TQ.SCHEME_ID = ?   AND TQ.COMPONENT_ID = ? ) ORDER BY GROUP_ID,CONDITION_ID,CONDITION_ROW_ID ASC";

		//System.out.println("Scheme Search Query:  "+query);
		List<SchemeTqMaster> tqList = jdbcTemplate.query(query, new Object[]{circleId, circleId, schemeId, compId}, new RowMapper<SchemeTqMaster>() {
			@Override
			public SchemeTqMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeTqMaster tqMaster = new SchemeTqMaster();
				tqMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				//tqMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				tqMaster.setCondId(rs.getInt("CONDITION_ID"));
				tqMaster.setCompId(rs.getInt("COMPONENT_ID"));
				tqMaster.setCondName(rs.getString("CONDITION_NAME"));
				tqMaster.setCondition(rs.getString("CONDITION"));

				return tqMaster;
			}
		});
		return tqList;
	}

	
	public List<SchemeTqMaster> getTransactionSubEAData(int schemeId, int compId,int circleId){
			
		String query = " SELECT SCHEME_ID,COMPONENT_ID,VARIABLE_ID,VARIABLE_NAME, VARIABLE_NAME||'('||ENTITY_TYPE||') = '||FUNCTION||'('||PARAMETER||') '||OPR||' '||VALUE||DECODE(START_DATE,NULL,'',' between '||START_DATE||' and '||END_DATE) AS VAR_VALUE," +
				" DECODE(DATA_SET,1,'Note: '||PARAMETER||' belongs to defined condition '||DATA_SOURCE,'') AS NOTE  from( SELECT EA.SCHEME_ID,EA.COMPONENT_ID,EA.VARIABLE_ID,EA.VARIABLE_NAME," +
				//" (SELECT ET.DISPLAY_VALUE FROM DLP_ENTITY_TYPE_MASTER ET WHERE ET.VALIDITY_FLAG='Y' AND ET.ENTITY_TYPE_ID=EA.ENTITY_TYPE) AS ENTITY_TYPE," +
				" (LTRIM((" +
				"  CASE WHEN EA.ENTITY_TYPE LIKE ('%10%') THEN 'Retailer' END||" +
				"  CASE WHEN EA.ENTITY_TYPE LIKE ('%9%') THEN ',DSE/FOS' END||" +
				"  CASE WHEN EA.ENTITY_TYPE LIKE ('%8%') THEN ',Distributor' END||" +
				"  CASE WHEN EA.ENTITY_TYPE LIKE ('%7%') THEN ',TSM/TSE Territory' END||" +
				"  CASE WHEN EA.ENTITY_TYPE LIKE ('%6%') THEN ',ASM Territory' END||" +
				"  CASE WHEN EA.ENTITY_TYPE LIKE ('%5%') THEN ',Zone' END||" +
				"  CASE WHEN EA.ENTITY_TYPE LIKE ('%4%') THEN ',Sales Head' END||" +
				"  CASE WHEN EA.ENTITY_TYPE LIKE ('%3%') THEN ',Circle Head' END" +
				"  ),',')) AS ENTITY_TYPE," +
				" (SELECT FM.DISPLAY_VALUE FROM DLP_TBL_FUNCTION_MASTER FM WHERE FM.VALIDITY_FLAG='Y' AND FM.ENTITY_AGG_FLAG='Y' AND FM.FUNCTION_ID=EA.FUNCTION) AS FUNCTION," +
				" DECODE(EA.DATA_SET,1,(SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID="+circleId+" AND UF.UNI_FLD_SEQ_NO=EA.PARAMETER),EA.PARAMETER) AS PARAMETER," +
				" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.EA_VAR_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R','A') AND OM.OPERATOR_ID=EA.OPR) AS OPR," +
				" EA.VALUE,TO_CHAR(EA.START_DATE,'DD-Mon-YYYY') AS START_DATE,TO_CHAR(EA.END_DATE,'DD-Mon-YYYY') AS END_DATE," +
				" DECODE(EA.DATA_SET,1,(SELECT TQ.CONDITION_NAME FROM DLP_SCM_TQ_COND_CONFIG TQ WHERE TQ.VALIDITY_FLAG='Y' AND TQ.SCHEME_ID=EA.SCHEME_ID AND TQ.COMPONENT_ID=EA.COMPONENT_ID AND TQ.CONDITION_ID=EA.COND_ID AND ROWNUM=1),EA.DATA_SOURCE) AS DATA_SOURCE," +
				" EA.DATA_SET FROM DLP_SCM_EA_COND_CONFIG EA WHERE EA.VALIDITY_FLAG='Y' AND EA.SCHEME_ID = ?  AND EA.COMPONENT_ID = ? ) ORDER BY VARIABLE_ID ASC";
		//System.out.println("Scheme Search Query:  "+query);
		
		List<SchemeTqMaster> tqList = jdbcTemplate.query(query, new Object[]{schemeId,compId}, new RowMapper<SchemeTqMaster>() {
			@Override
			public SchemeTqMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeTqMaster tqMaster = new SchemeTqMaster();
				tqMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				tqMaster.setCondId(rs.getInt("CONDITION_ID"));
				tqMaster.setCompId(rs.getInt("VARIABLE_ID"));
				tqMaster.setCondName(rs.getString("VARIABLE_NAME"));
				tqMaster.setCondition(rs.getString("VAR_VALUE"));

				return tqMaster;
			}
		});
		return tqList;	
	}

	
	public List<PaymentVO> getTransactionPaymentData(SearchScheme search){
		
		/*String query = "SELECT PAY.PAYMENT_ID, PAY.PAYTO, EM.DISPLAY_VALUE,  TO_CHAR(PAY.PAYMENT_DT_TIME,'DD-MON-YYYY') AS PAYMENT_DT, PAY.PAYMENT_AMOUNT, DECODE(PAY.PAYMENT_TYPE,'T','OFT','O','OFFLINE','V','VTOPUP',PAY.PAYMENT_TYPE) AS TYPE," +
				" PAY.PAYMENT_FILE_NAME, PAY.PAID_BY, PAY.PAYMENT_REMARKS FROM DLP_PAYMENT PAY, DLP_ENTITY_TYPE_MASTER EM  WHERE " +
				" PAY.PAYTO = EM.ENTITY_TYPE_ID AND TRUNC(PAY.PAYMENT_DT_TIME)<='"+search.getEndDate()+"' and ROWNUM between "+(search.getStart()+1)+" AND "+(search.getStart()+search.getLimit())+" ORDER BY PAY.PAYMENT_DT_TIME DESC ";// ROW_NUM between "+(schemeName.getStart()+1)+" AND "+(schemeName.getStart()+schemeName.getLimit())
		*/
		/*String query ="select C.* , (select COUNT(1) from (SELECT PAY.PAYMENT_ID, PAY.PAYTO, EM.DISPLAY_VALUE,  TO_CHAR(PAY.PAYMENT_DT_TIME,'DD-MON-YYYY') AS PAYMENT_DT," +
				" PAY.PAYMENT_AMOUNT, DECODE(PAY.PAYMENT_TYPE,'T','OFT','O','OFFLINE','V','VTOPUP',PAY.PAYMENT_TYPE) as type," +
				" PAY.PAYMENT_FILE_NAME, PAY.PAID_BY, PAY.PAYMENT_REMARKS from DLP_PAYMENT PAY, DLP_ENTITY_TYPE_MASTER EM" +
				" where  PAY.PAYTO = EM.ENTITY_TYPE_ID and TRUNC(PAY.PAYMENT_DT_TIME)<='"+search.getEndDate()+"' ORDER BY PAY.PAYMENT_DT_TIME DESC)) NO_OF_RECORDS from" +
				" ( select  a.*,rownum ROW_NUM from ( select  B.* from (SELECT PAY.PAYMENT_ID, PAY.PAYTO, EM.DISPLAY_VALUE,  TO_CHAR(PAY.PAYMENT_DT_TIME,'DD-MON-YYYY') AS PAYMENT_DT," +
				" PAY.PAYMENT_AMOUNT, DECODE(PAY.PAYMENT_TYPE,'T','OFT','O','OFFLINE','V','VTOPUP',PAY.PAYMENT_TYPE) as type," +
				" PAY.PAYMENT_FILE_NAME, PAY.PAID_BY, PAY.PAYMENT_REMARKS from DLP_PAYMENT PAY, DLP_ENTITY_TYPE_MASTER EM" +
				" where  PAY.PAYTO = EM.ENTITY_TYPE_ID and TRUNC(PAY.PAYMENT_DT_TIME)<='"+search.getEndDate()+"' ORDER BY PAY.PAYMENT_DT_TIME DESC)b)a) c where ROW_NUM between "+(search.getStart()+1)+" AND "+(search.getStart()+search.getLimit());
		
		//System.out.println("Scheme Search Query:  "+query);
		*/
		String TRANS_SEARCH_PAYMENT ="select C.* , (select COUNT(1) from (SELECT PAY.PAYMENT_ID, PAY.PAY_TO, EM.DISPLAY_VALUE,  TO_CHAR(PAY.PAYMENT_DATE,'DD-MON-YYYY') AS PAYMENT_DT," +
				" PAY.PAYMENT_AMOUNT, DECODE(PAY.PAYMENT_TYPE,'T','OTF','O','OFFLINE','V','vTopUp','I','Idea Money',PAY.PAYMENT_TYPE) as type," +
				" PAY.PAID_BY, PAY.PAYMENT_REMARKS from DLP_PAYMENT_"+search.getCircleCode()+" PAY, DLP_ENTITY_TYPE_MASTER EM" +
				" where  PAY.PAY_TO = EM.ENTITY_TYPE_ID AND (TRUNC(PAY.PAYMENT_DATE) between ? and ?) ORDER BY PAY.PAYMENT_DATE DESC)) NO_OF_RECORDS from" +
				" ( select  a.*,rownum ROW_NUM from ( select  B.* from (SELECT PAY.PAYMENT_ID, PAY.PAY_TO, EM.DISPLAY_VALUE,  TO_CHAR(PAY.PAYMENT_DATE,'DD-MON-YYYY') AS PAYMENT_DT," +
				" PAY.PAYMENT_AMOUNT, DECODE(PAY.PAYMENT_TYPE,'T','OTF','O','OFFLINE','V','vTopUp','I','Idea Money',PAY.PAYMENT_TYPE) as type," +
				"  PAY.PAID_BY, PAY.PAYMENT_REMARKS from DLP_PAYMENT_"+search.getCircleCode()+" PAY, DLP_ENTITY_TYPE_MASTER EM" +
				" where  PAY.PAY_TO = EM.ENTITY_TYPE_ID AND (TRUNC(PAY.PAYMENT_DATE) between ? and ?) ORDER BY PAY.PAYMENT_DATE DESC)b)a) c where ROW_NUM between ? AND ?";
		//System.out.println("Scheme Search Query:  "+TRANS_SEARCH_PAYMENT);
		List<PaymentVO> tqList = jdbcTemplate.query(TRANS_SEARCH_PAYMENT,new Object[]{search.getStartDate(), search.getEndDate(),  search.getStartDate(), search.getEndDate(), (search.getStart()+1), (search.getStart()+search.getLimit())}, new RowMapper<PaymentVO>() {
			@Override
			public PaymentVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				PaymentVO tqMaster = new PaymentVO();
				tqMaster.setPaymentId(rs.getInt("PAYMENT_ID"));
				tqMaster.setPayTo(rs.getInt("PAY_TO"));
				tqMaster.setDisplayValue(rs.getString("DISPLAY_VALUE"));
				tqMaster.setPaymentDt(rs.getString("PAYMENT_DT"));
				tqMaster.setPaymentAmt(rs.getFloat("PAYMENT_AMOUNT"));
				tqMaster.setPaymentType(rs.getString("TYPE"));
				//tqMaster.setPaymentFile(rs.getString("PAYMENT_FILE_NAME"));
				tqMaster.setPaidBy(rs.getString("PAID_BY"));
				tqMaster.setPaymentremarks(rs.getString("PAYMENT_REMARKS"));
				tqMaster.setTotalCount(rs.getInt("NO_OF_RECORDS"));
				return tqMaster;
			}
		});
		return tqList;	
	}

	
public List<PaymentDetailVO> getTransactionSubPaymentData(int paymentId, String circleCode){
		
		String query = "select PD.SCHEME_ID, SM.SCHEME_NAME,PD.COMPONENT_ID, CO.COMPONENET_NAME,CO.START_DATE, CO.END_DATE," +
				" sum(PD.PAYMENT_AMOUNT) PAYMENT_AMOUNT,  max(PD.PAYMENT_AMOUNT) MAX_PAYMENT,  min(PD.PAYMENT_AMOUNT) MIN_PAYMENT," +
				"  round(avg(PD.PAYMENT_AMOUNT),2) AVG_PAYMENT,    count(PD.TOTAL_ENTITY) TOTAL_ENTITY " +
				" from DLP_PAYMENT_DETAILS_"+circleCode+" PD,DLP_SCHEME_COMP_MAPPING CO, DLP_SCHEME_MASTER SM where PD.SCHEME_ID=SM.SCHEME_ID and PD.COMPONENT_ID=CO.COMPONENT_ID and" +
				" SM.SCHEME_ID=CO.SCHEME_ID and SM.VALIDITY_FLAG=CO.VALIDITY_FLAG and SM.VALIDITY_FLAG='Y' and PD.PAYMENT_ID = ? "+
				" group by PD.SCHEME_ID,SM.SCHEME_NAME, PD.COMPONENT_ID,  CO.COMPONENET_NAME,  CO.START_DATE,  CO.END_DATE";		
		//System.out.println("Scheme Search Query:  "+query);
		
		List<PaymentDetailVO> tqList = jdbcTemplate.query(query, new Object[]{paymentId}, new RowMapper<PaymentDetailVO>() {
			@Override
			public PaymentDetailVO mapRow(ResultSet rs, int rowNum) throws SQLException {
				PaymentDetailVO tqMaster = new PaymentDetailVO();
				tqMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				tqMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				tqMaster.setCompId(rs.getInt("COMPONENT_ID"));
				tqMaster.setCompName(rs.getString("COMPONENET_NAME"));
				tqMaster.setPaymentAmt(rs.getFloat("PAYMENT_AMOUNT"));
				tqMaster.setMaxPayment(rs.getFloat("MAX_PAYMENT"));
				tqMaster.setMinPayment(rs.getFloat("MIN_PAYMENT"));
				tqMaster.setAvgPayment(rs.getFloat("AVG_PAYMENT"));
				tqMaster.setTotalEntity(rs.getFloat("TOTAL_ENTITY"));
				tqMaster.setStartDt(rs.getString("START_DATE"));
				tqMaster.setEndDt(rs.getString("END_DATE"));
				return tqMaster;
			}
		});
		return tqList;	
	}


public List<InputTypeMasterVO> getTransactionUniverseData(){
	
	//String query = "select INPUT_TYPE_ID, INPUT_TYPE_DESC, DISPLAY_VALUE from DLP_TBL_INPUT_TYPE_MASTER where TQ_FLAG='Y' and VALIDITY_FLAG='Y'";
	
	String query = "SELECT UNIVERSE_ID, UNIVERSE_NAME, UNIVERSE_TBL_PREFIX FROM DLP_TBL_UNIVERSE WHERE VALIDITY_FLAG='Y' ORDER BY UNIVERSE_ID ASC";
	
	//System.out.println("Scheme Search Query:  "+query);
	
	List<InputTypeMasterVO> tqList = jdbcTemplate.query(query, new RowMapper<InputTypeMasterVO>() {
		@Override
		public InputTypeMasterVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			InputTypeMasterVO tqMaster = new InputTypeMasterVO();
			tqMaster.setInputTypeId(rs.getInt("UNIVERSE_ID"));
			//tqMaster.setInputTypeDesc(rs.getString("UNIVERSE_TBL_PREFIX"));
			tqMaster.setDisplayValue(rs.getString("UNIVERSE_NAME"));
			if(rs.getInt("UNIVERSE_ID")==1)
				tqMaster.setInputTypeDesc(""+"<form><input type=\"radio\" name=\"inputtype\" id=\"inputtype\" value=\"HLR\" checked>HLR Unbar<input type=\"radio\" name=\"inputtype\" id=\"inputtype\" value=\"FTA\">FTA Req</form>");
			else
				tqMaster.setInputTypeDesc("");
			return tqMaster;
		}
	});
	return tqList;	
}


public List<UniverseMasterVO> getTransactionSubUniverseData(int universeId, String startDt, String endDt, final String circleCode, String condiParam){
	
	String query = "select UNIVERSE_ID,UNIVERSE_NAME,UNIVERSE_TBL_PREFIX from DLP_TBL_UNIVERSE where UNIVERSE_ID = ? and VALIDITY_FLAG='Y'";
	
	//System.out.println("Scheme Search Query:  "+query);
	
	List<UniverseMasterVO> tqList = jdbcTemplate.query(query, new Object[]{universeId}, new RowMapper<UniverseMasterVO>() {
		@Override
		public UniverseMasterVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			UniverseMasterVO tqMaster = new UniverseMasterVO();
			/*tqMaster.setEventTypeId(rs.getString("SRC_EVENT_TYPE_ID"));
			tqMaster.setTableName(rs.getString("SRC_TABLE_NAME"));
			tqMaster.setUniverseName(rs.getString("UNI_UNIVERSE_NAME")+"_"+circleCode);
			*/
			tqMaster.setEventTypeId(rs.getString("UNIVERSE_ID"));
			tqMaster.setTableName(rs.getString("UNIVERSE_NAME"));
			tqMaster.setUniverseName(rs.getString("UNIVERSE_TBL_PREFIX")+"_"+circleCode);
			return tqMaster;
		}
	});
	if(tqList!=null && tqList.size()!=0)
	tqList=getTransactionSubUniverseData(tqList,startDt,endDt,condiParam);
	return tqList;	
}


private List<UniverseMasterVO> getTransactionSubUniverseData(List<UniverseMasterVO> tqList1,String startdt, String endDt, String condiParam){
	
	UniverseMasterVO um = tqList1.get(0); 
	//String query = "select count(1) AS HEADCOUNT, TO_CHAR(MIN(UNI_EVENT_DATE),'DD-MON-YYYY') AS STARTDATE, TO_CHAR(MAX(UNI_EVENT_DATE),'DD-MON-YYYY') AS ENDDATE from "+um.getUniverseName();
	String query = "select COUNT(1) as HEADCOUNT, TO_CHAR(min(UNI_EVENT_DATE),'DD-MON-YYYY') as STARTDATE, TO_CHAR(max(UNI_EVENT_DATE),'DD-MON-YYYY') as ENDDATE  from  "+um.getUniverseName()+" where trunc(UNI_EVENT_DATE) between  ? and ? ";
	if("HLR".equalsIgnoreCase(condiParam)){
		query = "select COUNT(1) as HEADCOUNT, TO_CHAR(min(HLR_UNBAR_DATE),'DD-MON-YYYY') as STARTDATE, TO_CHAR(max(HLR_UNBAR_DATE),'DD-MON-YYYY') as ENDDATE  from  "+um.getUniverseName()+" where trunc(HLR_UNBAR_DATE) between  ? and  ?";
	}
	
	//System.out.println("condiParam :: "+condiParam+"Scheme Search Query:  "+query);
	List<UniverseMasterVO> tqList = jdbcTemplate.query(query, new Object[]{startdt, endDt}, new RowMapper<UniverseMasterVO>() {
		@Override
		public UniverseMasterVO mapRow(ResultSet rs, int rowNum) throws SQLException {
			UniverseMasterVO tqMaster = new UniverseMasterVO();
			tqMaster.setHeadCount(rs.getLong("HEADCOUNT"));
			tqMaster.setMinDt(rs.getString("STARTDATE"));
			tqMaster.setMaxDt(rs.getString("ENDDATE"));
			return tqMaster;
		}
	});
	return tqList;	
}

@SuppressWarnings("deprecation")
public int getCircleId(String circleCode){
	try{
		return jdbcTemplate.queryForInt(TransactionQueries.CIRCLE_NUMBER, new Object[]{circleCode});
	}catch(Exception e){
		e.printStackTrace();	
	}
	return 0;
}


@SuppressWarnings("deprecation")
@Override
public int getCheckExtractDataTime(ShellScriptPojo shellScript) {
	try{
		return jdbcTemplate.queryForInt(TransactionQueries.TRANS_DATA_LAST_EXTRACT_TIME, new Object[]{shellScript.getSchemeId(), shellScript.getCompId(), shellScript.getConditionId(), shellScript.getType(), shellScript.getCircleId(), shellScript.getQualityType(), shellScript.getPaymentId(), shellScript.getUniverseId()});
	}catch(Exception e){
		e.printStackTrace();	
	}
	return -1;
}


@Override
public void getUpdateExtractDataTime(ShellScriptPojo shellScript) {
	try{
		jdbcTemplate.update(TransactionQueries.UPDATE_TRANS_DATA_LAST_EXTRACT_TIME, new Object[]{shellScript.getUserId(), shellScript.getSchemeId(), shellScript.getCompId(), shellScript.getConditionId(), shellScript.getType(), shellScript.getCircleId(), shellScript.getQualityType(), shellScript.getPaymentId(), shellScript.getUniverseId()});
	}catch(Exception e){
		e.printStackTrace();
	}
	
}


@Override
public void getInsertExtractDataTime(ShellScriptPojo shellScript) {
	try{
		jdbcTemplate.update(TransactionQueries.INSERT_TRANS_DATA_LAST_EXTRACT_TIME, new Object[]{shellScript.getSchemeId(), shellScript.getCompId(), shellScript.getConditionId(), shellScript.getType(), shellScript.getCircleId(), shellScript.getQualityType(), shellScript.getPaymentId(), shellScript.getUniverseId(), shellScript.getUserId()});
	}catch(Exception e){
		e.printStackTrace();
	}
}


@SuppressWarnings("deprecation")
@Override
public int transactionDateValidation(int id, String type) {
	int days = 0;
	try{
		days = jdbcTemplate.queryForInt(TransactionQueries.LIMIT_DATA_DOWNLOAD, new Object[]{id,type});
		return days;
	}catch(Exception e){
		
	}
	return days;
}


@SuppressWarnings("deprecation")
@Override
public int getCheckExtractDataMinLimit(String type) {
	int min = 0;
	try{
		min = jdbcTemplate.queryForInt(TransactionQueries.LIMIT_MINUTES, new Object[]{type});
		return min;
	}catch(Exception e){
		
	}
	return min;
}

@Override
public String getCheckType(String type) {
	Connection connection = null;
	PreparedStatement ps = null;
	ResultSet result = null;
	try{
		connection = jdbcTemplate.getDataSource().getConnection();
		ps = connection.prepareStatement(TransactionQueries.VALIDATE_TYPE);
		ps.setString(1, type);
		result = ps.executeQuery();
		String value=null;
		if(result.next()){
			value = result.getString("TYPE");
		}
		//System.out.println("getCheckType :::=== "+value);
		return value;
	}catch(Exception e){
		e.printStackTrace();
	}finally{
		try {
			if(result!=null)
				result.close();
			if(ps!=null)
				ps.close();
			if(connection!=null)
				connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	return null;
}



}

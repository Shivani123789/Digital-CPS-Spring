package dsm.dao.po;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import dsm.model.DB.CompMaster;
import dsm.model.ea.OprEaModel;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.form.OprMaster;
import dsm.model.form.ValueTypeMaster;
import dsm.model.po.EaVariables;
import dsm.model.po.SchemePoMaster;
import dsm.model.user.User;

public class DsmPoDAOImpl implements DsmPoDAO {

private JdbcTemplate jdbcTemplate;
	

@Autowired
private HttpSession httpSession;

	public DsmPoDAOImpl(DataSource dataSource) {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

	

	
	@Override
	public List<CompMaster> getCompListForPo() {
		int schemeId =0;
		if(httpSession.getAttribute("schemeId")!=null)
		 schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
			String query = "select component_id,componenet_name from dlp_scheme_comp_mapping_stage where scheme_id = ?";
					// and  component_id not in (select  component_id from dlp_scm_po_cond_config_stage where scheme_id = "+schemeId+" and lopr=26)";
		List<CompMaster> listContact = jdbcTemplate.query(query, new Object[]{schemeId}, new RowMapper<CompMaster>() {
			@Override
			public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompMaster compMaster = new CompMaster();
				compMaster.setCompId(rs.getInt("component_id"));
				compMaster.setCompName(rs.getString("componenet_name"));
				return compMaster;
			}
		});
		return listContact;
	}

	
	
	
	
	
	@Override
	public List<ValueTypeMaster> getValueTypeList() {
		// TODO Auto-generated method stub
		String query="select VALUE_TYPE_ID,display_value from dlp_tbl_value_type_master where po_flag='Y' and validity_flag='Y'";
		List<ValueTypeMaster> valueTypeList = jdbcTemplate.query(query, new RowMapper<ValueTypeMaster>() {
			@Override
			public ValueTypeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				ValueTypeMaster valueTypeMaster = new ValueTypeMaster();
				valueTypeMaster.setValueTypeId(rs.getInt("VALUE_TYPE_ID"));
				valueTypeMaster.setValueTypeName(rs.getString("display_value"));
				return valueTypeMaster;
			}
		});
		return valueTypeList;
	}

	
	
	@Override
	public List<OprMaster> getLopr() {
		// TODO Auto-generated method stub
		String query = "select operator_id,display_value,operator_type from dlp_operator_master where validity_flag='Y' and po_flag='Y'";
		List<OprMaster> oprList = jdbcTemplate.query(query, new RowMapper<OprMaster>() {
			@Override
			public OprMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				OprMaster oprMaster = new OprMaster();
				oprMaster.setOprId(rs.getInt("operator_id"));
				oprMaster.setOprName(rs.getString("display_value"));
				oprMaster.setOprType(rs.getString("operator_type"));
				return oprMaster;
			}
		});
		return oprList;
	}

	@Override
	public List<EaVariables> getEaVariables() {
		// TODO Auto-generated method stub
		try{
			if(httpSession.getAttribute("schemeName")!=null){
				String schemeName = (String)httpSession.getAttribute("schemeName");
				int circleId = (Integer)httpSession.getAttribute("circleId");
				String query = "  select component_id,variable_id,variable_name from DLP_SCM_EA_COND_CONFIG_STAGE where scheme_id=(select scheme_id from dlp_scheme_master_stage where " +
						"dlp_scheme_master_stage.scheme_name = ? AND dlp_scheme_master_stage.circle_id = ? )";
				List<EaVariables> varList = jdbcTemplate.query(query, new Object[]{schemeName, circleId},new RowMapper<EaVariables>() {
					@Override
					public EaVariables mapRow(ResultSet rs, int rowNum) throws SQLException {
						EaVariables eavarMaster = new EaVariables();
						eavarMaster.setVariableId(rs.getInt("variable_id"));
						eavarMaster.setVariableName(rs.getString("variable_name"));
						eavarMaster.setCompId(rs.getInt("component_id"));
						eavarMaster.setPoVarFlag("Y");
						return eavarMaster;
					}
				});
				return varList;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<SchemePoMaster> getInputType() {
		// TODO Auto-generated method stub
		String query = "select input_type_id as input_id, display_value input_value  from dlp_tbl_input_type_master where po_flag='Y' and validity_flag='Y'";
		List<SchemePoMaster> inputType = jdbcTemplate.query(query, new RowMapper<SchemePoMaster>()
				{
					@Override
					public SchemePoMaster mapRow(ResultSet rs, int rowNum)	throws SQLException {
						SchemePoMaster inputTypeObj = new SchemePoMaster();
						inputTypeObj.setInputTypeId(rs.getInt("input_id"));
						inputTypeObj.setInputType(rs.getString("input_value"));
						return inputTypeObj;
					}
				});
		return inputType;
	}

	
	
	
	
	@Override
	public List<OprEaModel> getOprList() {
		// TODO Auto-generated method stub
		String query="select operator_id,display_value,ea_var_flag,ea_con_flag,operator_type,number_flag,date_flag,string_flag from dlp_operator_master where validity_flag='Y' and po_flag='Y'";
		List<OprEaModel> oprList = jdbcTemplate.query(query, new RowMapper<OprEaModel>() {
			@Override
			public OprEaModel mapRow(ResultSet rs, int rowNum) throws SQLException {
				OprEaModel opr = new OprEaModel();
				opr.setOprId(rs.getInt("operator_id"));
				opr.setOprName(rs.getString("display_value"));
				opr.setOprType(rs.getString("operator_type"));
				opr.setValFlagcon(rs.getString("ea_con_flag"));
				opr.setValFlagvar(rs.getString("ea_var_flag"));
				opr.setStringFlag(rs.getString("string_flag"));
				opr.setNumberFlag(rs.getString("number_flag"));
				opr.setDataFlag(rs.getString("date_flag"));
				return opr;
			}
		});
		return oprList;
	}

	
	
	
	@Override
	public List<EntityAttributeMaster> getInputParameter() {
		// TODO Auto-generated method stub
		User user = (User)httpSession.getAttribute("appUser");
		String query = "select attr_seq_no,attr_type,attr_catg,display_name,free_text_type_chk from dlp_tbl_entity_attr_mapping where pay_cond_flag='Y' and validity_flag='Y' AND (circle_id = ?  or  circle_id is null)";
		List<EntityAttributeMaster> inputParamList = jdbcTemplate.query(query, new Object[]{user.getCircleId()}, new RowMapper<EntityAttributeMaster>(){
			@Override
			public EntityAttributeMaster mapRow(ResultSet rs, int count) throws SQLException {
				EntityAttributeMaster entAtt = new EntityAttributeMaster();
				entAtt.setEntityAttributeId(rs.getInt("attr_seq_no"));
				entAtt.setEntityAttributeName(rs.getString("display_name"));
				entAtt.setAttrType(rs.getInt("attr_type"));
				entAtt.setAttrCatg(rs.getInt("attr_catg"));
				entAtt.setFreeTextType(rs.getString("free_text_type_chk"));
				entAtt.setPoVarFlag("N");
				return entAtt;
			}
		});
	return inputParamList;
	}
}




	
		
	


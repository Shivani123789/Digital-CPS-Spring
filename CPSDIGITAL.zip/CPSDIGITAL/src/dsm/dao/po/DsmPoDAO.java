package dsm.dao.po;

import java.util.List;

import dsm.model.DB.CompMaster;
import dsm.model.ea.OprEaModel;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.form.OprMaster;
import dsm.model.form.ValueTypeMaster;
import dsm.model.po.EaVariables;
import dsm.model.po.SchemePoMaster;

public interface DsmPoDAO {

	//List<SchemeMaster> searchScheme(Date startDate,Date endDate);
	
	List<OprMaster> getLopr();
	List<EaVariables> getEaVariables();
	List<SchemePoMaster> getInputType();
	List<EntityAttributeMaster> getInputParameter();
	List<ValueTypeMaster> getValueTypeList();
	List<OprEaModel> getOprList();
	List<CompMaster> getCompListForPo();
}

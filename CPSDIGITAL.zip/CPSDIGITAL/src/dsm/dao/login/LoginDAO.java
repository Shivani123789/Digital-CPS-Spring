package dsm.dao.login;

import dsm.model.user.User;

public interface LoginDAO {
	public User getUserDetails(String userName);
}

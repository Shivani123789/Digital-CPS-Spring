package dsm.dao.login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import dsm.dataBase.query.LoginQueries;
import dsm.model.user.User;

public class LoginDAOImpl  implements LoginDAO{
	
	private JdbcTemplate jdbcTemplate;
	
/*	 @Autowired
		private Environment env;
*/
	public LoginDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
    }
	
	public User getUserDetails(String userName){
		//String query = "select cm.circle_number,cm.circle_code,cm.circle_name,DU.ROLE_ID, UPPER(DU.USERNAME) USERNAME from dl_circle_config cm , dsm2_users du  where cm.circle_number = du.circle_id AND du.username='"+userName+"'";
		//System.out.println("Login LOGIN_USER_DETAILS :: "+env.getProperty("LOGIN_USER_DETAILS"));
		//List<User> userDetailList = jdbcTemplate.query(env.getProperty("LOGIN_USER_DETAILS"),new Object[]{userName}, new RowMapper<User>() {
		List<User> userDetailList = jdbcTemplate.query(LoginQueries.LOGIN_USER_DETAILS,new Object[]{userName}, new RowMapper<User>() {	
			@Override
			public User mapRow(ResultSet rs, int rowNum) throws SQLException {
				User user = new User();
				user.setCircleId(rs.getInt("circle_number"));
				user.setUserCircleCode(rs.getString("circle_code"));
				user.setCircleName(rs.getString("circle_name"));
				user.setUserName(rs.getString("USERNAME"));
				user.setRoleId(rs.getInt("ROLE_ID"));
				user.setLastLogin(rs.getString("last_login"));
				user.setRoleName(rs.getString("ROLENAME"));
				user.setUserPrivilege(userPrivilege(rs.getInt("ROLE_ID")));
				user.setUserPrivileges(userPrivileges(rs.getInt("ROLE_ID")));
				user.setSsVersion(ssVersion());
				return user;
			}
		});
		/*
		 * if(userDetailList!=null && userDetailList.size()!=0) return
		 * userDetailList.get(0); return null;
		 */
		if(userDetailList!=null && userDetailList.size()!=0){
			jdbcTemplate.update(LoginQueries.LAST_LOGIN_DB, new Object[]{userName});
			return userDetailList.get(0);
		}
		
		return null;
	}
	
	
	private String ssVersion(){
		try {
			List<String> version = jdbcTemplate.query(LoginQueries.VERSION, new RowMapper<String>() {	
				@Override
				public String mapRow(ResultSet rs, int rowNum)  {
					try {
						String str =(rs.getString("SS_VERSION"));
						return str;	
					} catch (SQLException e) {
						
					}
					return null;
				}
			});
			return version.get(0);
		} catch (Exception e) {
			e.getMessage();
		}
		return null;
	}
	
	
	private List<String> userPrivilege(int role){
		/*String query ="select CHD.MENU_NAME CHD_MENU,NVL(PAR.MENU_NAME,0) PAR_MENU from DSM2_SCHEMES_MENU PAR,DSM2_SCHEMES_MENU CHD" +
				" where PAR.MENU_ID(+) = CHD.PARENT_MENU_ID and CHD.MENU_ID in (select MENU_ID from DSM2_PRIVS where" +
				" PRIV_ID in (select PRIV_ID from DSM2_ROLE_PRIV_MAP where ROLE_ID ="+role+"))" +
				" order by CHD.LEVEL_CODE,NVL(PAR.LEVEL_CODE,0)";
		
		*/
		//System.out.println("LOGIN_USER_MENU :: "+env.getProperty("LOGIN_USER_MENU"));
		//List<String> userPriv = jdbcTemplate.query(env.getProperty("LOGIN_USER_MENU"),new Object[]{role}, new RowMapper<String>() {
			List<String> userPriv = jdbcTemplate.query(LoginQueries.LOGIN_USER_MENU,new Object[]{role}, new RowMapper<String>() {	
			@Override
			public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				String str =(rs.getString("CHD_MENU"));
				return str;
			}
		});
		return userPriv;
	}
	
	private Map<String,Set<String>> userPrivileges(int role){
		/*String query ="select CHD.MENU_NAME CHD_MENU,NVL(PAR.MENU_NAME,0) PAR_MENU from DSM2_SCHEMES_MENU PAR,DSM2_SCHEMES_MENU CHD" +
				" where PAR.MENU_ID(+) = CHD.PARENT_MENU_ID and CHD.MENU_ID in (select MENU_ID from DSM2_PRIVS where" +
				" PRIV_ID in (select PRIV_ID from DSM2_ROLE_PRIV_MAP where ROLE_ID ="+role+"))" +
				" order by CHD.LEVEL_CODE,NVL(PAR.LEVEL_CODE,0)";
		
		*/
		//System.out.println("Login priv details :: "+env.getProperty("LOGIN_USER_MENU"));
		Connection con=null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Map<String,Set<String>> str =new HashMap<String,Set<String>>();
		try {
			 con =  jdbcTemplate.getDataSource().getConnection();
			ps = con.prepareStatement(LoginQueries.LOGIN_USER_MENU);
			//ps = con.prepareStatement(env.getProperty("LOGIN_USER_MENU"));
			ps.setInt(1, role);
			rs = ps.executeQuery();
			SortedSet<String> list = null;
			//Set<String> set = new HashSet<String>();
			while(rs.next()){
				if(!"0".equalsIgnoreCase(rs.getString("PAR_MENU"))){
					list.add(rs.getString("CHD_MENU"));
				}else{
					list = new TreeSet<String>();
					//list.add(rs.getString("CHD_MENU"));
					continue;
				}
				str.put(rs.getString("PAR_MENU"),list);
			}
			 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			if(ps!=null)
				try {
					ps.close();
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		}
		return str;
	}
	
}

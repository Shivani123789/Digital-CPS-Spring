package dsm.dao.report;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import oracle.jdbc.OracleTypes;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import dsm.dataBase.query.ReportQueries;
import dsm.model.DB.DistributorRetSchmPojo;
import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.DistributorStmtSchmPojo;
import dsm.model.DB.SchemeMaster;
import dsm.model.report.Appendix;
import dsm.model.report.ComponentListReport;
import dsm.model.report.ComponentReport;
import dsm.model.report.ConditionReport;
import dsm.model.report.PayoutReport;
import dsm.model.report.ReportCsvDownload;
import dsm.model.report.ReportGenerateMaster;
import dsm.model.report.RetailerPerformanceReport;
import dsm.model.report.TransactionDataReport;

public class ReportGenerateDAOImpl implements ReportGenerateDAO{

	private JdbcTemplate jdbcTemplate;
	
	public ReportGenerateDAOImpl(){
		
	}
	
	public ReportGenerateDAOImpl(DataSource dataSource){
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	@Override
	public List<SchemeMaster> searchScheme(String schemeName) {
		String query = "SELECT scheme_id,scheme_name FROM DLP_SCHEME_MASTER WHERE UPPER(SCHEME_NAME) LIKE UPPER(?) AND VALIDITY_FLAG='Y' ORDER BY UPDATE_DATE_TIME DESC";
		
		List<SchemeMaster> reportList = jdbcTemplate.query(query, new Object[]{"%"+schemeName+"%"}, new RowMapper<SchemeMaster>() {
			@Override
			public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeMaster schemeMaster = new SchemeMaster();
				schemeMaster.setSchemeINputId(rs.getInt("scheme_id"));
				schemeMaster.setSchemeName(rs.getString("scheme_name"));
				return schemeMaster;
			}
		});
		return reportList;
	}
	
	@Override
	public ReportGenerateMaster reportGenerate(int schemeId,int compId,int circleId,String circleCode){
		ReportGenerateMaster rgm = new ReportGenerateMaster();
		List<ComponentListReport> compList= componentListReport(schemeId,compId,circleId);
			rgm.setComponentListReport(compList);
			if(rgm.getComponentListReport()!=null && rgm.getComponentListReport().size()!=0)
			for(ComponentListReport comp : rgm.getComponentListReport()){
				rgm.setVersionNo(comp.getVersionNo());
				rgm.setApprovedBy(comp.getApprovedBy());
				rgm.setApprovedDt(comp.getApprovedDt());
				rgm.setRejectedBy(comp.getRejectedBy());
				rgm.setRejectedDt(comp.getRejectedDt());
				rgm.setPayoutApprovedBy(comp.getPayoutApprovedBy());
				rgm.setPayoutApprovedDt(comp.getPayoutApprovedDt());
				rgm.setUserId(comp.getUserId());
				rgm.setInsertDt(comp.getInsertDt());
				if(comp.getPayoutApprovedBy()!=null){
					PayoutReport pr =	scmPayoutInfo(schemeId,compId,circleCode);
					if(pr!=null){
						rgm.setTotalGrossAmount(pr.getTotalGrossAmount());
						rgm.setTotalNetAmount(pr.getTotalNetAmount());
						rgm.setHeadCount(pr.getHeadCount());
					}
				}
				
				break;
			}
			
		List<Appendix> app = getAppendixList();
		rgm.setAppendix(app);
		return rgm;
	}
	
	private PayoutReport scmPayoutInfo(int scmId, int compId, String circleCode) {
		String query = "SELECT SUM(NET_VALUE) NET_VALUE,SUM(GROSS_VALUE) GROSS_VALUE, COUNT(*) CNT FROM DLP_SCM_PAYOUT_"+circleCode+" WHERE SCM_ID=? AND COMP_ID=? AND VALIDITY_FLAG='Y'  GROUP BY SCM_ID, COMP_ID";
		try {
			List<PayoutReport> reportList = jdbcTemplate.query(query, new Object[]{scmId, compId}, new RowMapper<PayoutReport>() {
				@Override
				public PayoutReport mapRow(ResultSet rs,  int rowNum) throws SQLException {
					PayoutReport schemeMaster = new PayoutReport();
					schemeMaster.setTotalNetAmount(rs.getBigDecimal("NET_VALUE"));
					schemeMaster.setTotalGrossAmount(rs.getBigDecimal("GROSS_VALUE"));
					schemeMaster.setHeadCount(rs.getBigDecimal("CNT"));
					return schemeMaster;
				}
			});
			return	reportList.get(0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/*private SchemeMaster getSchemeMaster(int schemeId) {
		String query="select sm.SCHEME_ID,sm.SCHEME_NAME from dlp_scheme_master_stage st, dlp_scheme_master sm where st.SCHEME_NAME = sm.SCHEME_NAME and sm.validity_flag = 'Y' and st.scheme_id="+schemeId;
		//System.out.println("SchemeMaster Query ::::: "+query);
		List<SchemeMaster> smList = jdbcTemplate.query(query, new RowMapper<SchemeMaster>() {
			@Override
			public SchemeMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeMaster sm = new SchemeMaster();
				sm.setCircleId(rs.getInt("SCHEME_ID"));
				sm.setSchemeName(rs.getString("SCHEME_NAME"));
				return sm;
			}
		});
		return smList.get(0);
	}*/
	
	///////////////////////////////////////////////////////////////////////////////////////////
	//Scheme and Component Names
	
	private List<ComponentListReport> componentListReport(int schemeId,int compId,int circleId){

	/*	String query = "select s.SCHEME_ID,s.SCHEME_NAME,s.CIRCLE_ID,c.COMPONENT_ID,c.COMPONENET_NAME," +
				"TO_CHAR(C.SCHEME_ID || '.' || C.COMPONENT_ID || '.' || C.COMPONENT_VER) as VERSION_NO," +
				" C.SCM_APPROVED_BY, TO_CHAR(C.SCM_APPROVAL_DT,'DD/MON/YYYY') SCM_APPROVAL_DT, C.SCM_REJECTED_BY, TO_CHAR(C.SCM_REJECTION_DT,'DD/MON/YYYY') SCM_REJECTION_DT," +
				" TO_CHAR(C.INSERT_DATE_TIME,'DD/MON/YYYY') INSERT_DATE_TIME, C.USER_ID from DLP_SCHEME_COMP_MAPPING c, DLP_SCHEME_MASTER s " +
				"where s.scheme_id=c.scheme_id and s.scheme_id="+schemeId+" and c.VALIDITY_FLAG='Y' and s.VALIDITY_FLAG='Y' and C.COMPONENT_ID="+compId+" and S.CIRCLE_ID= "+circleId;
		//System.out.println("PDF Query ::::  "+query);
	*/	
		List<ComponentListReport> compReportList =  jdbcTemplate.query(ReportQueries.SCHEME_COMP_NAME, new Object[]{schemeId, compId, circleId}, new RowMapper<ComponentListReport>() {
			@Override
			public ComponentListReport mapRow(ResultSet rs, int rowNum) throws SQLException
			{	
				ComponentListReport compMaster = new ComponentListReport();
				
				compMaster.setSchemeId(rs.getInt("SCHEME_ID"));
				compMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				compMaster.setCircleId(rs.getInt("CIRCLE_ID"));
				compMaster.setConditionId(rs.getInt("COMPONENT_ID"));
				compMaster.setComponentName(rs.getString("COMPONENET_NAME"));
				compMaster.setVersionNo(rs.getString("VERSION_NO"));
				compMaster.setApprovedBy(rs.getString("SCM_APPROVED_BY"));
				compMaster.setApprovedDt(rs.getString("SCM_APPROVAL_DT"));
				compMaster.setRejectedBy(rs.getString("SCM_REJECTED_BY"));
				compMaster.setRejectedDt(rs.getString("SCM_REJECTION_DT"));
				compMaster.setPayoutApprovedBy(rs.getString("PAYOUT_APPROVED_BY"));
				compMaster.setPayoutApprovedDt(rs.getString("PAYOUT_APPROVAL_DT"));
				compMaster.setUserId(rs.getString("USER_ID"));
				compMaster.setInsertDt(rs.getString("INSERT_DATE_TIME"));
				compMaster.setPayToDesc(rs.getString("DESCRIPTION"));
				
				final int compId = rs.getInt("COMPONENT_ID");
				final int schemId = rs.getInt("SCHEME_ID");
				final int circleId = rs.getInt("CIRCLE_ID");
				////System.out.println("******************* COMPONENT_ID :::::: "+compId);
				////System.out.println("******************* SCHEME_ID :::::: "+schemId);
				////System.out.println("******************* CIRCLE_ID :::::: "+circleId);
				List<ComponentReport> compReport = componentList( schemId, compId, circleId);
				compMaster.setComponentReport(compReport);
				List<ConditionReport> condiReport = getConditionList( schemId, compId);
				compMaster.setConditionReport(condiReport);
				List<TransactionDataReport> tranReport = getTransactionQualifyList( schemId, compId,circleId);
				compMaster.setTransDataReport(tranReport);
				List<RetailerPerformanceReport> retailReport = getRetailsPerformanceList(schemId, compId,circleId);
				compMaster.setRetailerReport(retailReport);
				List<PayoutReport> payReport = getPayoutCondition(schemId, compId);
				compMaster.setPayoutReport(payReport);
				
				return compMaster;
			}
		});
		return compReportList;
	
	}
	
	//Scheme and Component Report
	private List<ComponentReport> componentList(int schemeId,int compId,int circleId){
		/*String query = "SELECT SM.SCHEME_NAME,SC.COMPONENET_NAME,TO_CHAR(SC.START_DATE,'DD-MON-YYYY') AS START_DATE,TO_CHAR(SC.END_DATE,'DD-MON-YYYY') AS END_DATE,PF.DISPLAY_VALUE AS FREQUENCY,ET.DISPLAY_VALUE AS PAY_TO,"+
	   " TO_CHAR(TO_CHAR(SC.START_DATE,'DD MON YYYY') || ' - ' || TO_CHAR(SC.END_DATE,'DD MON YYYY')) as START_END_DATE,"+
       " TO_CHAR(ET.DISPLAY_VALUE ||'''s' || ' Sales Vertical Specific ' || VM.DISPLAY_VALUE) as SALES_DESC,"+
       " VM.DISPLAY_VALUE AS VERTICAL,CC.CIRCLE_NAME AS CIRCLE,'ALL' AS REGION,'ALL' AS ZONE,SC.COVERAGE_FLAG,SC.FILE_NAME "+
       " FROM DLP_SCHEME_MASTER       SM,DLP_SCHEME_COMP_MAPPING SC,DLP_PAYOUT_FREEQUENCY   PF,"+
       " DLP_ENTITY_TYPE_MASTER  ET,DLP_VERTICAL_MASTER     VM,DL_CIRCLE_CONFIG        CC "+
       " WHERE SM.SCHEME_ID = SC.SCHEME_ID AND SM.CIRCLE_ID = "+circleId+" AND SM.VALIDITY_FLAG = 'Y' AND SC.VALIDITY_FLAG = 'Y'"+ 
       " AND PF.VALIDITY_FLAG = 'Y' AND PF.FREEQUENCY_ID = SC.FREEQUENCY_ID AND ET.VALIDITY_FLAG = 'Y' "+
       " AND ET.ENTITY_TYPE_ID = SC.PAY_TO AND VM.VALIDITY_FLAG = 'Y' AND VM.VERTICAL_ID = SC.VERTICAL_ID"+ 
       " AND CC.VALID_FOR_EXTRACTION = 'Y' AND CC.CIRCLE_NUMBER = SM.CIRCLE_ID "+
       " AND SM.SCHEME_ID = "+schemeId+" AND SC.COMPONENT_ID = "+compId;*/
	//	//System.out.println("*********** componentList  Component query  :::::::::::::::  "+query);
		List<ComponentReport> compReportList = null;
		try{
		compReportList =  jdbcTemplate.query(ReportQueries.SCHEME_COMP_DETAIL,new Object[]{schemeId, compId,circleId,schemeId, compId,circleId,circleId, schemeId, compId }, new RowMapper<ComponentReport>() {
			@Override
			public ComponentReport mapRow(ResultSet rs, int rowNum) //throws SQLException 
			{
				ComponentReport compMaster = new ComponentReport();
				try{
				compMaster.setSchemeName(rs.getString("SCHEME_NAME"));
				compMaster.setCompName(rs.getString("COMPONENET_NAME"));
				compMaster.setStartDate(rs.getString("START_DATE"));
				compMaster.setEndDate(rs.getString("END_DATE"));
				compMaster.setFrequency(rs.getString("FREQUENCY"));
				compMaster.setPayTo(rs.getString("PAY_TO"));
				compMaster.setVertical(rs.getString("VERTICAL"));
				compMaster.setCircleName(rs.getString("CIRCLE"));
				compMaster.setRegion(rs.getString("REGION"));
				compMaster.setZone(rs.getString("ZONE"));
				compMaster.setCoverageFlag(rs.getString("COVERAGE_FLAG"));
				compMaster.setFileName(rs.getString("FILE_NAME"));
				compMaster.setStartDateEndDate(rs.getString("START_END_DATE"));
				compMaster.setSalesDesc(rs.getString("SALES_DESC"));
				
				}catch(Exception e){
					//System.out.println("************** in catch Exception componentList  mapRow :::::: "+e.getMessage());
					e.printStackTrace();
				}
				return compMaster;
			}
		});
		
		}catch(Exception e){
			//System.out.println("**************out catch Exception componentList  :::::: ");
			e.printStackTrace();
		}
		return compReportList;
	}
	
	
	//Condition Data
	private List<ConditionReport> getConditionList(int schemeId,int compId) {
		/*String query=" SELECT CONDITION_ID,CONDITION_ROW_ID,ENTITY_TYPE||'''s '||ATTRIBUTE_NAME||' '||DECODE(OPR,'Date Range','is between '||START_DATE||' and '||END_DATE,OPR||' '||VALUE)||' '||LOPR||' '|| "+
       " DECODE(L_ENTITY_TYPE,'','',L_ATTRIBUTE_NAME||' '||DECODE(L_OPR,'Date Range','is between '||L_START_DATE||' and '||L_END_DATE,L_OPR||' '||L_VALUE))||DECODE(ROPR,'Add New Condition','','Close Configration','',' '||ROPR) AS CONDITION "+
       "  FROM(  "+
       "  SELECT CC.CONDITION_ID,CC.CONDITION_ROW_ID,(SELECT ET.DISPLAY_VALUE FROM DLP_ENTITY_TYPE_MASTER ET WHERE ET.VALIDITY_FLAG='Y' AND ET.ENTITY_TYPE_ID=CC.ENTITY_TYPE) AS ENTITY_TYPE, "+
       " (SELECT EA.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING EA WHERE EA.VALIDITY_FLAG='Y' AND EA.ATTR_SEQ_NO=CC.ATTRIBUTE_NAME) AS ATTRIBUTE_NAME, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.CO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=CC.OPR) AS OPR, "+
       " CC.VALUE, "+
       " TO_CHAR(CC.START_DATE,'DD-Mon-YYYY') AS START_DATE, "+
       " TO_CHAR(CC.END_DATE,'DD-Mon-YYYY') AS END_DATE, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.CO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L') AND OM.OPERATOR_ID=CC.LOPR) AS LOPR, "+
       " (SELECT ET.DISPLAY_VALUE FROM DLP_ENTITY_TYPE_MASTER ET WHERE ET.VALIDITY_FLAG='Y' AND ET.ENTITY_TYPE_ID=CC.L_ENTITY_TYPE) AS L_ENTITY_TYPE, "+
       " (SELECT EA.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING EA WHERE EA.VALIDITY_FLAG='Y' AND EA.ATTR_SEQ_NO=CC.L_ATTRIBUTE_NAME) AS L_ATTRIBUTE_NAME, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.CO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=CC.L_OPR) AS L_OPR, "+
       " CC.L_VALUE, "+
       " TO_CHAR(CC.L_START_DATE,'DD-Mon-YYYY') AS L_START_DATE, "+
       " TO_CHAR(CC.L_END_DATE,'DD-Mon-YYYY') AS L_END_DATE, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.CO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L') AND OM.OPERATOR_ID=CC.R_OPR) AS ROPR "+ 
       "  FROM DLP_SCM_CO_COND_CONFIG CC "+
       "  WHERE CC.VALIDITY_FLAG='Y' AND CC.SCHEME_ID= "+schemeId+"  AND CC.COMPONENT_ID= "+compId+"  AND CC.ENTITY_TYPE IS NOT NULL) ORDER BY CONDITION_ID,CONDITION_ROW_ID ASC";
*/
		List<ConditionReport> condList = jdbcTemplate.query(ReportQueries.CONDITION_DATA, new Object[]{schemeId, compId}, new RowMapper<ConditionReport>() {
			@Override
			public ConditionReport mapRow(ResultSet rs, int rowNum) throws SQLException {
				ConditionReport covMaster = new ConditionReport();
				covMaster.setConditionId(rs.getInt("CONDITION_ID"));
				covMaster.setConditionRowId(rs.getInt("CONDITION_ROW_ID"));
				covMaster.setCondition(rs.getString("CONDITION"));
				return covMaster;
			}
		});
		return condList;
	}

	
	
	//Transaction Data
	private List<TransactionDataReport> getTransactionQualifyList(int schemeId,int compId,int circle) {
		/*String query=" SELECT  CONDITION_ID, GROUP_ID, CONDITION_NAME, DATA_SET, LISTAGG (CONDITION, ' ') WITHIN GROUP (ORDER BY condition) AS CONDITION from " +
				"(SELECT CONDITION_ID,GROUP_ID,CONDITION_ROW_ID,CONDITION_NAME,DATA_SET, "+
       " PERF_PARAMETER||' '||DECODE(OPR,'Date Range','is between '||START_DATE||' and '||END_DATE,OPR||' '||VALUE)||' '||LOPR||' '|| "+
       " DECODE(L_PERF_PARAMETER,'','',L_PERF_PARAMETER||' '||DECODE(L_OPR,'Date Range','is between '||L_START_DATE||' and '||L_END_DATE,L_OPR||' '||L_VALUE))||DECODE(ROPR,'Add New Condition','','Close Configration','',' '||ROPR) AS CONDITION,DECODE(ROPR,'Add New Condition','1','Close Configration','1',0) AS NEXTCOND "+ 
       "  FROM( "+
       " SELECT TQ.GROUP_ID,TQ.CONDITION_ID,TQ.CONDITION_ROW_ID,TQ.CONDITION_NAME, "+
       " (SELECT DECODE(IP.DISPLAY_VALUE,'Act + Recharge','Activation and Recharge Performance','Retailer','Retailer Performance','Distributor','Distributor Performance',IP.DISPLAY_VALUE) FROM DLP_TBL_INPUT_TYPE_MASTER IP WHERE IP.VALIDITY_FLAG='Y' AND IP.TQ_FLAG='Y' AND IP.INPUT_TYPE_ID=TQ.DATA_SET) AS DATA_SET, "+
       " (SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID= 1  AND UF.UNI_FLD_SEQ_NO=TQ.PERF_PARAMETER) AS PERF_PARAMETER, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=TQ.OPR) AS OPR, "+
       " TQ.VALUE, "+
       " TO_CHAR(TQ.START_DATE,'DD-MON-YYYY') AS START_DATE, "+
       " TO_CHAR(TQ.END_DATE,'DD-MON-YYYY') AS END_DATE, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L') AND OM.OPERATOR_ID=TQ.LOPR) AS LOPR, "+
       " (SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID= 2  AND UF.UNI_FLD_SEQ_NO=TQ.L_PERF_PARAMETER) AS L_PERF_PARAMETER, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=TQ.L_OPR) AS L_OPR, "+
       " TQ.L_VALUE, "+
       " TO_CHAR(TQ.L_START_DATE,'DD-MON-YYYY') AS L_START_DATE, "+
       " TO_CHAR(TQ.L_END_DATE,'DD-MON-YYYY') AS L_END_DATE, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L','M') AND OM.OPERATOR_ID=TQ.ROPR) AS ROPR "+ 
       " FROM DLP_SCM_TQ_COND_CONFIG TQ  "+
       " WHERE TQ.VALIDITY_FLAG='Y' AND TQ.SCHEME_ID = "+schemeId+"   AND TQ.COMPONENT_ID = "+compId+ 
       " ) ORDER BY GROUP_ID,CONDITION_ID,CONDITION_ROW_ID ASC) GROUP BY CONDITION_ID, GROUP_ID, CONDITION_NAME, data_set";
*/
		
		/*String query = "SELECT SCHEME_ID, COMPONENT_ID, CONDITION_ID, GROUP_ID, CONDITION_NAME, DATA_SET, LISTAGG (CONDITION, ' ') WITHIN GROUP (ORDER BY CONDITION_ROW_ID, condition) AS CONDITION" +
				" FROM (SELECT SCHEME_ID, COMPONENT_ID, CONDITION_ID, GROUP_ID, CONDITION_ROW_ID, CONDITION_NAME, DATA_SET, DECODE(PERF_PARAMETER,'','',(PERF_PARAMETER    ||' '  ||DECODE(OPR,'Date Range','is between ' ||START_DATE ||' and '  ||END_DATE,OPR ||' ' ||value) ||' '  ||LOPR ||' ' || " +
				" DECODE(L_PERF_PARAMETER,'','',L_PERF_PARAMETER ||' ' ||DECODE(L_OPR,'Date Range','is between ' ||L_START_DATE  ||' and ' ||L_END_DATE,L_OPR ||' '  ||L_VALUE))" +
				" ||DECODE(ROPR,'Add New Condition','','Close Configration','',' ' ||ROPR)))  AS CONDITION, DECODE(ROPR,'Add New Condition','1','Close Configration','1',0) AS NEXTCOND" +
				" FROM (SELECT TQ.SCHEME_ID,  TQ.COMPONENT_ID, TQ.GROUP_ID, TQ.CONDITION_ID, TQ.CONDITION_ROW_ID, TQ.CONDITION_NAME, (SELECT DECODE(IP.DISPLAY_VALUE,'Act  Recharge','Activation and Recharge Performance','Retailer','Retailer Performance','Distributor','Distributor Performance',IP.DISPLAY_VALUE)" +
				" FROM DLP_TBL_INPUT_TYPE_MASTER IP  WHERE IP.VALIDITY_FLAG='Y' AND IP.TQ_FLAG        ='Y' AND IP.INPUT_TYPE_ID  =TQ.DATA_SET) AS DATA_SET," +
				" (SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID      = "+circle+"  AND UF.UNI_FLD_SEQ_NO =TQ.PERF_PARAMETER) AS PERF_PARAMETER, (SELECT OM.DISPLAY_VALUE  FROM DLP_OPERATOR_MASTER OM" +
				" WHERE OM.VALIDITY_FLAG='Y' AND OM.TQ_FLAG        ='Y'   AND OM.OPERATOR_TYPE IN ('S','R')   AND OM.OPERATOR_ID    =TQ.OPR ) AS OPR," +
				"  TQ.VALUE, TO_CHAR(TQ.START_DATE,'DD-MON-YYYY') AS START_DATE, TO_CHAR(TQ.END_DATE,'DD-MON-YYYY')   AS END_DATE, (SELECT OM.DISPLAY_VALUE" +
				"   FROM DLP_OPERATOR_MASTER OM  WHERE OM.VALIDITY_FLAG='Y'  AND OM.TQ_FLAG        ='Y'   AND OM.OPERATOR_TYPE IN ('L')  AND OM.OPERATOR_ID    =TQ.LOPR" +
				"   ) AS LOPR,  (SELECT UF.UNI_FIELD_DISPLAY_VALUE  FROM DLP_TBL_UNIVERSE_FIELD_MAP UF  WHERE UF.VALIDITY_FLAG='Y'  AND UF.CIRCLE_ID      = "+circle+" AND UF.UNI_FLD_SEQ_NO =TQ.L_PERF_PARAMETER" +
				"   ) AS L_PERF_PARAMETER,  (SELECT OM.DISPLAY_VALUE  FROM DLP_OPERATOR_MASTER OM  WHERE OM.VALIDITY_FLAG='Y'   AND OM.TQ_FLAG        ='Y'  AND OM.OPERATOR_TYPE IN ('S','R')  AND OM.OPERATOR_ID    =TQ.L_OPR" +
				"   ) AS L_OPR,  TQ.L_VALUE, TO_CHAR(TQ.L_START_DATE,'DD-MON-YYYY') AS L_START_DATE, TO_CHAR(TQ.L_END_DATE,'DD-MON-YYYY')   AS L_END_DATE, (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM" +
				"   WHERE OM.VALIDITY_FLAG='Y'   AND OM.TQ_FLAG        ='Y'   AND OM.OPERATOR_TYPE IN ('L','M')   AND OM.OPERATOR_ID    =TQ.ROPR" +
				"  ) AS ROPR FROM DLP_SCM_TQ_COND_CONFIG TQ where TQ.VALIDITY_FLAG='Y'  AND TQ.SCHEME_ID      = "+schemeId+"   AND TQ.COMPONENT_ID   = "+compId+"  ) ORDER BY GROUP_ID,  CONDITION_ID,  CONDITION_ROW_ID ASC)" +
				"GROUP BY SCHEME_ID, COMPONENT_ID,  CONDITION_ID,  GROUP_ID,  CONDITION_NAME,  data_set";
		*/
		
		List<TransactionDataReport> transQualifyList = jdbcTemplate.query(ReportQueries.TRANSACTION_CONDITION, new Object[]{circle,circle,schemeId,compId}, new RowMapper<TransactionDataReport>() {
			@Override
			public TransactionDataReport mapRow(ResultSet rs, int rowNum) throws SQLException {
				TransactionDataReport covMaster = new TransactionDataReport();
				covMaster.setConditionId(rs.getInt("CONDITION_ID"));
				covMaster.setGroupId(rs.getInt("GROUP_ID"));
				//covMaster.setConditionRowId(rs.getInt("CONDITION_ROW_ID"));
				covMaster.setConditionName(rs.getString("CONDITION_NAME"));
				covMaster.setDataSet(rs.getString("DATA_SET"));
				covMaster.setCondition(rs.getString("CONDITION"));
				//covMaster.setNextCondition(rs.getString("NEXTCOND"));
				return covMaster;
			}
		});
		return transQualifyList;
	}

	
	//Retailer Performance
	private List<RetailerPerformanceReport> getRetailsPerformanceList(int schemeId,int compId,int circleId) {
		/*String query=" SELECT VARIABLE_ID,VARIABLE_NAME,VARIABLE_ID||'. '||VARIABLE_NAME||'('||ENTITY_TYPE||') = '||FUNCTION||'('||PARAMETER||') '||OPR||' '||VALUE||DECODE(START_DATE,NULL,'',' between '||START_DATE||' and '||END_DATE) AS VAR_VALUE, "+
       " DECODE(DATA_SET,1,'Note: '||PARAMETER||' belongs to defined condition '||DATA_SOURCE,'') AS NOTE "+
       "  FROM( "+
       "  SELECT EA.VARIABLE_ID,EA.VARIABLE_NAME, "+
       " (SELECT ET.DISPLAY_VALUE FROM DLP_ENTITY_TYPE_MASTER ET WHERE ET.VALIDITY_FLAG='Y' AND ET.ENTITY_TYPE_ID=EA.ENTITY_TYPE) AS ENTITY_TYPE, "+
       " (SELECT FM.DISPLAY_VALUE FROM DLP_TBL_FUNCTION_MASTER FM WHERE FM.VALIDITY_FLAG='Y' AND FM.ENTITY_AGG_FLAG='Y' AND FM.FUNCTION_ID=EA.FUNCTION) AS FUNCTION, "+
       " DECODE(EA.DATA_SET,1,(SELECT UF.UNI_FIELD_DISPLAY_VALUE FROM DLP_TBL_UNIVERSE_FIELD_MAP UF WHERE UF.VALIDITY_FLAG='Y' AND UF.CIRCLE_ID=1 AND UF.UNI_FLD_SEQ_NO=EA.PARAMETER),EA.PARAMETER) AS PARAMETER, "+
       " (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.EA_VAR_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R','A') AND OM.OPERATOR_ID=EA.OPR) AS OPR, "+
       " EA.VALUE,TO_CHAR(EA.START_DATE,'DD-Mon-YYYY') AS START_DATE,TO_CHAR(EA.END_DATE,'DD-Mon-YYYY') AS END_DATE, "+
       " DECODE(EA.DATA_SET,1,(SELECT TQ.CONDITION_NAME FROM DLP_SCM_TQ_COND_CONFIG TQ WHERE TQ.VALIDITY_FLAG='Y' AND TQ.SCHEME_ID=EA.SCHEME_ID AND TQ.COMPONENT_ID=EA.COMPONENT_ID AND TQ.CONDITION_ID=EA.COND_ID AND ROWNUM=1),EA.DATA_SOURCE) AS DATA_SOURCE, "+
       " EA.DATA_SET "+
       "  FROM DLP_SCM_EA_COND_CONFIG EA WHERE EA.VALIDITY_FLAG='Y' AND EA.SCHEME_ID = "+schemeId+"  AND EA.COMPONENT_ID = "+compId+" ) "+
       "  ORDER BY VARIABLE_ID ASC";
		*/
		
		/*String query = " SELECT   VARIABLE_ID, VARIABLE_NAME, VARIABLE_ID  || '. '  || VARIABLE_NAME || '('  || ENTITY_TYPE  || ') = '   || FUNCTION  || '(' || PARAMETER  || ') '  || OPR   || ' '  || VALUE  || DECODE (START_DATE,  NULL, ''," +
				"  ' between ' || START_DATE || ' and ' || END_DATE)  AS VAR_VALUE,    DECODE ( DATA_SET,  1, 'Note: '  || PARAMETER  || ' belongs to defined condition ' || DATA_SOURCE,  ''  )" +
				"  AS NOTE  FROM   (SELECT   EA.VARIABLE_ID,  EA.VARIABLE_NAME, (SELECT   ET.DISPLAY_VALUE  FROM   DLP_ENTITY_TYPE_MASTER ET  WHERE   ET.VALIDITY_FLAG = 'Y'" +
				"  AND ET.ENTITY_TYPE_ID = EA.ENTITY_TYPE)  AS ENTITY_TYPE,  (SELECT   FM.DISPLAY_VALUE FROM   DLP_TBL_FUNCTION_MASTER FM  WHERE       FM.VALIDITY_FLAG = 'Y'" +
				"  AND FM.ENTITY_AGG_FLAG = 'Y'  AND FM.FUNCTION_ID = EA.FUNCTION)   AS FUNCTION,  DECODE ( EA.DATA_SET, 1, (SELECT   UF.UNI_FIELD_DISPLAY_VALUE" +
				"  FROM   DLP_TBL_UNIVERSE_FIELD_MAP UF  WHERE       UF.VALIDITY_FLAG = 'Y'   AND UF.CIRCLE_ID = "+circleId+"  AND UF.UNI_FLD_SEQ_NO = EA.PARAMETER), EA.DATA_SOURCE" +
				"  )  AS PARAMETER, (SELECT   OM.DISPLAY_VALUE FROM   DLP_OPERATOR_MASTER OM   WHERE       OM.VALIDITY_FLAG = 'Y' AND OM.EA_VAR_FLAG = 'Y'" +
				"  AND OM.OPERATOR_TYPE IN ('S', 'R', 'A')   AND OM.OPERATOR_ID = EA.OPR)  AS OPR, EA.VALUE,  TO_CHAR (EA.START_DATE, 'DD-Mon-YYYY') AS START_DATE," +
				"  TO_CHAR (EA.END_DATE, 'DD-Mon-YYYY') AS END_DATE, DECODE (  EA.DATA_SET, 1,  (SELECT   TQ.CONDITION_NAME FROM   DLP_SCM_TQ_COND_CONFIG TQ" +
				"   WHERE       TQ.VALIDITY_FLAG = 'Y'   AND TQ.SCHEME_ID = EA.SCHEME_ID   AND TQ.COMPONENT_ID = EA.COMPONENT_ID    AND TQ.CONDITION_ID = EA.COND_ID" +
				"   AND ROWNUM = 1), EA.DATA_SOURCE ) AS DATA_SOURCE, EA.DATA_SET FROM   DLP_SCM_EA_COND_CONFIG EA  WHERE       EA.VALIDITY_FLAG = 'Y'" +
				"   AND EA.SCHEME_ID = "+schemeId+"   AND EA.COMPONENT_ID = "+compId+") ORDER BY   VARIABLE_ID ASC";
		*/
		/* Formatted on 17-06-2015 11:11:50 (QP5 v5.114.809.3010) */
		/**4-Aug-2015
		 * String query = " SELECT   VARIABLE_ID, VARIABLE_NAME, VARIABLE_ID  || '. ' || VARIABLE_NAME || '(' || ENTITY_TYPE || ') = ' || FUNCTION || '(' || PARAMETER || ') '       || OPR" +
				"  || ' '  || VALUE  || DECODE (START_DATE,  NULL, '', ' between ' || START_DATE || ' and ' || END_DATE) AS VAR_VALUE,  DECODE (DATA_SET, 1, 'Note: ' || PARAMETER  || ' belongs to defined condition '" +
				"  || DATA_SOURCE, '' )  AS NOTE FROM   (SELECT   EA.VARIABLE_ID, EA.VARIABLE_NAME,  (SELECT   ET.DISPLAY_VALUE FROM   DLP_ENTITY_TYPE_MASTER ET  WHERE   ET.VALIDITY_FLAG = 'Y' AND ET.ENTITY_TYPE_ID = EA.ENTITY_TYPE)" +
				"  AS ENTITY_TYPE,  (SELECT   FM.DISPLAY_VALUE FROM   DLP_TBL_FUNCTION_MASTER FM  WHERE       FM.VALIDITY_FLAG = 'Y' AND FM.ENTITY_AGG_FLAG = 'Y' AND FM.FUNCTION_ID = EA.FUNCTION)" +
				"  AS FUNCTION,  DECODE ( EA.DATA_SET,  1, (SELECT   UF.UNI_FIELD_DISPLAY_VALUE FROM   DLP_TBL_UNIVERSE_FIELD_MAP UF  WHERE       UF.VALIDITY_FLAG = 'Y' AND UF.CIRCLE_ID = " +circleId+
				"  AND UF.UNI_FLD_SEQ_NO = EA.PARAMETER), EA.DATA_SOURCE )  AS PARAMETER, (SELECT   OM.DISPLAY_VALUE  FROM   DLP_OPERATOR_MASTER OM  WHERE       OM.VALIDITY_FLAG = 'Y'" +
				"  AND OM.EA_VAR_FLAG = 'Y'  AND OM.OPERATOR_TYPE IN ('S', 'R', 'A', 'V')  AND OM.OPERATOR_ID = EA.OPR)  AS OPR,  CASE  WHEN EA.VALUE_TYPE = 8 THEN (SELECT   '('|| A.DISPLAY_NAME ||')' FROM   DLP_TBL_ENTITY_ATTR_MAPPING A" +
				"  WHERE   EA.VALUE = A.ATTR_SEQ_NO) WHEN EA.VALUE_TYPE = 2   THEN  (SELECT   A.VARIABLE_NAME  FROM   DLP_SCM_EA_COND_CONFIG A   WHERE       A.VALIDITY_FLAG = 'Y'  AND A.SCHEME_ID = EA.SCHEME_ID" +
				"  AND A.COMPONENT_ID = EA.COMPONENT_ID  AND EA.VALUE = A.VARIABLE_ID)  ELSE   EA.VALUE    END   VALUE, TO_CHAR (EA.START_DATE, 'DD-Mon-YYYY') AS START_DATE, TO_CHAR (EA.END_DATE, 'DD-Mon-YYYY') AS END_DATE," +
				"  DECODE ( EA.DATA_SET, 1, (SELECT   TQ.CONDITION_NAME  FROM   DLP_SCM_TQ_COND_CONFIG TQ  WHERE       TQ.VALIDITY_FLAG = 'Y' AND TQ.SCHEME_ID = EA.SCHEME_ID  AND TQ.COMPONENT_ID = EA.COMPONENT_ID" +
				"  AND TQ.CONDITION_ID = EA.COND_ID  AND ROWNUM = 1),  EA.DATA_SOURCE ) AS DATA_SOURCE, EA.DATA_SET  FROM   DLP_SCM_EA_COND_CONFIG EA  WHERE       EA.VALIDITY_FLAG = 'Y'" +
				"  AND EA.SCHEME_ID = "+schemeId+"  AND EA.COMPONENT_ID = "+compId+") ORDER BY   VARIABLE_ID ASC";
		
		 */
		/**
		 * CASE
      			WHEN EA.DATA_SET= 1 
      				THEN (SELECT UF.UNI_FIELD_DISPLAY_VALUE  FROM DLP_TBL_UNIVERSE_FIELD_MAP UF  WHERE UF.VALIDITY_FLAG = 'Y'
        					AND UF.CIRCLE_ID = 1   AND UF.UNI_FLD_SEQ_NO  = EA.PARAMETER ) WHEN EA.DATA_SET=2 AND EA.PARAMETER LIKE 'PAYEE%'
      				THEN (SELECT DESCRIPTION  FROM DLP_ENTITY_TYPE_MASTER ETM  WHERE ETM.VALIDITY_FLAG ='Y' AND ETM.HIERARCHY_COLUMN=EA.PARAMETER )
      				ELSE EA.DATA_SOURCE
    				END PARAMETER
		 */
		/*16-Sept-2015
		 * String query = " SELECT   VARIABLE_ID, VARIABLE_NAME, VARIABLE_ID  || '. ' || VARIABLE_NAME || '(' || ENTITY_TYPE || ') = ' || FUNCTION || '(' || PARAMETER || ') '       || OPR" +
				"  || ' '  || VALUE  || DECODE (START_DATE,  NULL, '', ' between ' || START_DATE || ' and ' || END_DATE) AS VAR_VALUE,  DECODE (DATA_SET, 1, 'Note: ' || PARAMETER  || ' belongs to defined condition '" +
				"  || DATA_SOURCE, '' )  AS NOTE FROM   (SELECT   EA.VARIABLE_ID, EA.VARIABLE_NAME,  (SELECT   ET.DISPLAY_VALUE FROM   DLP_ENTITY_TYPE_MASTER ET  WHERE   ET.VALIDITY_FLAG = 'Y' AND ET.ENTITY_TYPE_ID = EA.ENTITY_TYPE)" +
				"  AS ENTITY_TYPE,  (SELECT   FM.DISPLAY_VALUE FROM   DLP_TBL_FUNCTION_MASTER FM  WHERE       FM.VALIDITY_FLAG = 'Y' AND FM.ENTITY_AGG_FLAG = 'Y' AND FM.FUNCTION_ID = EA.FUNCTION)" +
				"  AS FUNCTION,  CASE" +
				" WHEN EA.DATA_SET= 1" +
				" THEN (SELECT UF.UNI_FIELD_DISPLAY_VALUE  FROM DLP_TBL_UNIVERSE_FIELD_MAP UF  WHERE UF.VALIDITY_FLAG = 'Y'" +
				" AND UF.CIRCLE_ID = "+circleId+"   AND UF.UNI_FLD_SEQ_NO  = EA.PARAMETER ) WHEN EA.DATA_SET=2 AND EA.PARAMETER LIKE 'PAYEE%'" +
				" THEN (SELECT DESCRIPTION  FROM DLP_ENTITY_TYPE_MASTER ETM  WHERE ETM.VALIDITY_FLAG ='Y' AND ETM.HIERARCHY_COLUMN=EA.PARAMETER )" +
				" WHEN EA.DATA_SET= 3 THEN "+
				"    (SELECT ATT.DISPLAY_NAME FROM DLP_TBL_ADD_FIELDS_CONFIG ATT WHERE ATT.FIELD_NAME=EA.PARAMETER AND ATT.TYPE=1)"+
				"  ELSE EA.DATA_SOURCE" +
				" END PARAMETER, (SELECT   OM.DISPLAY_VALUE  FROM   DLP_OPERATOR_MASTER OM  WHERE       OM.VALIDITY_FLAG = 'Y'" +
				"  AND OM.EA_VAR_FLAG = 'Y'  AND OM.OPERATOR_TYPE IN ('S', 'R', 'A', 'V')  AND OM.OPERATOR_ID = EA.OPR)  AS OPR,  CASE  WHEN EA.VALUE_TYPE = 8 THEN (SELECT   '('|| A.DISPLAY_NAME ||')' FROM   DLP_TBL_ENTITY_ATTR_MAPPING A" +
				"  WHERE   EA.VALUE = A.ATTR_SEQ_NO) WHEN EA.VALUE_TYPE = 2   THEN  (SELECT   A.VARIABLE_NAME  FROM   DLP_SCM_EA_COND_CONFIG A   WHERE       A.VALIDITY_FLAG = 'Y'  AND A.SCHEME_ID = EA.SCHEME_ID" +
				"  AND A.COMPONENT_ID = EA.COMPONENT_ID  AND EA.VALUE = A.VARIABLE_ID)  ELSE   EA.VALUE    END   VALUE, TO_CHAR (EA.START_DATE, 'DD-Mon-YYYY') AS START_DATE, TO_CHAR (EA.END_DATE, 'DD-Mon-YYYY') AS END_DATE," +
				"  DECODE ( EA.DATA_SET, 1, (SELECT   TQ.CONDITION_NAME  FROM   DLP_SCM_TQ_COND_CONFIG TQ  WHERE       TQ.VALIDITY_FLAG = 'Y' AND TQ.SCHEME_ID = EA.SCHEME_ID  AND TQ.COMPONENT_ID = EA.COMPONENT_ID" +
				"  AND TQ.CONDITION_ID = EA.COND_ID  AND ROWNUM = 1),  EA.DATA_SOURCE ) AS DATA_SOURCE, EA.DATA_SET  FROM   DLP_SCM_EA_COND_CONFIG EA  WHERE       EA.VALIDITY_FLAG = 'Y'" +
				"  AND EA.SCHEME_ID = "+schemeId+"  AND EA.COMPONENT_ID = "+compId+") ORDER BY   VARIABLE_ID ASC";
		*/
		
		List<RetailerPerformanceReport> entityAggregationList = jdbcTemplate.query(ReportQueries.ENTITY_PERFORMANCE, new Object[]{circleId,circleId, schemeId, compId},new RowMapper<RetailerPerformanceReport>() {
			@Override
			public RetailerPerformanceReport mapRow(ResultSet rs, int rowNum) throws SQLException {
				RetailerPerformanceReport covMaster = new RetailerPerformanceReport();
				covMaster.setVariableId(rs.getInt("VARIABLE_ID"));
				covMaster.setVariableName(rs.getString("VARIABLE_NAME"));
				covMaster.setVariableValue(rs.getString("VAR_VALUE"));
				covMaster.setNote(rs.getString("NOTE"));
				return covMaster;
			}
		});
		return entityAggregationList;
	}
	
	
	
	
	
	
	//Payout Condition
	private List<PayoutReport> getPayoutCondition(int schemeId,int compId) {
		/*String query="   SELECT CONDITION_ID,listagg (condition, ' ') WITHIN GROUP (order by CONDITION_ROW_ID,condition ) as condition,GROSS_NET,AMOUNT,VARIABLE,OVER_ACHIEVEMENT,UNDER_ACHIEVEMENT,UNIT FROM" +
				" (SELECT CONDITION_ID,INPUT_PARAM||' '||OPR||' '||VALUE||DECODE(START_DATE,'','',' between '||START_DATE||' and '||END_DATE)||DECODE(LOPR,'Add New Condition','','Close Condition','',' '||LOPR) AS CONDITION, "+
		" DECODE(LOPR,'Add New Condition','1','Close Condition','1','0') AS NEXT_COND, "+
		" GROSS_NET, AMOUNT, VARIABLE, OVER_ACHIEVEMENT, UNDER_ACHIEVEMENT,UNIT,CONDITION_ROW_ID "+
		"  FROM( "+
		"  SELECT PO.CONDITION_ID,PO.CONDITION_ROW_ID, "+
		" DECODE(PO.INPUT_TYPE,6,PO.INPUT_PARAMETER,(SELECT EA.DISPLAY_NAME FROM DLP_TBL_ENTITY_ATTR_MAPPING EA WHERE EA.VALIDITY_FLAG='Y' AND EA.PAY_COND_FLAG='Y' AND EA.ATTR_SEQ_NO=PO.INPUT_PARAMETER)) AS INPUT_PARAM, "+
		" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.PO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('S','R') AND OM.OPERATOR_ID=PO.OPR) AS OPR, "+
		" PO.VALUE,TO_CHAR(PO.START_DATE,'DD-Mon-YYYY') AS START_DATE,TO_CHAR(PO.END_DATE,'DD-Mon-YYYY') AS END_DATE, "+
		" (SELECT OM.DISPLAY_VALUE FROM DLP_OPERATOR_MASTER OM WHERE OM.VALIDITY_FLAG='Y' AND OM.PO_FLAG='Y' AND OM.OPERATOR_TYPE IN ('L','M') AND OM.OPERATOR_ID=PO.LOPR) AS LOPR, "+
		" PM.GROSS_NET, PM.AMOUNT, PM.VARIABLE, PM.OVER_ACHIEVEMENT, PM.UNDER_ACHIEVEMENT, "+
		" (SELECT UM.DISPLAY_VALUE FROM DLP_UNIT_MASTER UM WHERE UM.VALIDITY_FLAG='Y' AND UM.UNIT_ID=PM.UNIT) AS UNIT "+
		" FROM DLP_SCM_PO_COND_CONFIG PO,DLP_SCM_PO_AMT_CONFIG PM "+
		" WHERE PO.VALIDITY_FLAG='Y' AND PO.SCHEME_ID= "+schemeId+"  AND PO.COMPONENT_ID= "+compId+ 
		" AND PM.VALIDITY_FLAG='Y' AND PM.SCHEME_ID=PO.SCHEME_ID AND PM.COMPONENT_ID=PO.COMPONENT_ID AND PM.CONDITION_ID=PO.CONDITION_ID) "+
		" ORDER BY CONDITION_ID,CONDITION_ROW_ID ASC )  group by   CONDITION_ID,GROSS_NET,AMOUNT,VARIABLE,OVER_ACHIEVEMENT,UNDER_ACHIEVEMENT,UNIT ";
*/
		List<PayoutReport> payoutFilterList = jdbcTemplate.query(ReportQueries.PAYOUT_CONDITION, new Object[]{schemeId, compId}, new RowMapper<PayoutReport>() {
			@Override
			public PayoutReport mapRow(ResultSet rs, int rowNum) throws SQLException {
				PayoutReport covMaster = new PayoutReport();
				covMaster.setConditionId(rs.getInt("CONDITION_ID"));
				covMaster.setConditionName(rs.getString("CONDITION"));
				//covMaster.setNextCondition(rs.getString("NEXT_COND"));
				covMaster.setGrossNet(rs.getString("GROSS_NET"));
				covMaster.setUnit(rs.getString("UNIT"));
				covMaster.setAmount(rs.getFloat("AMOUNT"));
				covMaster.setVariable(rs.getString("VARIABLE"));
				covMaster.setOverAchive(rs.getInt("OVER_ACHIEVEMENT"));
				covMaster.setUnderAchive(rs.getInt("UNDER_ACHIEVEMENT"));
				return covMaster;
			}
		});
		return payoutFilterList;
	}

	
	
	
	
	////////////////////////////////////////////////////////////////////////////
	
	
	
	
	
	
	//
	/*private List<CompMaster> componentList(int schemeId){
		String query = "select comp.scheme_id,scheme.scheme_name, cir.circle_name,comp.component_id,comp.componenet_name, "+ 
					   "comp.start_date,comp.end_date,freq.description,vert.vertical_name,payto.display_value "+ 
					   "from DLP_SCHEME_MASTER scheme, dl_circle_config cir, DLP_SCHEME_COMP_MAPPING comp, "+ 
					   "DLP_Payout_Freequency freq, DLP_Vertical_Master vert, DLP_Entity_Type_Master payto "+  
					   "where freq.freequency_id = comp.freequency_id AND vert.vertical_id = comp.vertical_id "+  
					   "AND payto.entity_type_id = comp.pay_to AND comp.scheme_id=scheme.scheme_id "+ 
					   "AND scheme.circle_id=cir.circle_number 	AND scheme.scheme_id="+schemeId;
		List<CompMaster> compReportList =  jdbcTemplate.query(query, new RowMapper<CompMaster>() {
			@Override
			public CompMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				CompMaster compMaster = new CompMaster();
				compMaster.setSchemeId(rs.getInt("scheme_id"));
				compMaster.setSchemeName(rs.getString("scheme_name"));
				compMaster.setCompId(rs.getInt("component_id"));
				final int compId = rs.getInt("component_id");
				final int schemId = rs.getInt("scheme_id");
				
				List<RegZoneMaster> regZone = getRegionZone( schemId, compId);
				compMaster.setSchemeInputRegZone(regZone);
				List<SchemeTqMaster> transQualifyList = getTransactionQualify( schemId, compId);
				compMaster.setSchemeInputTq(transQualifyList);
				List<SchemeEaMaster> entityAggregationList = getEntityAggregationList(schemId, compId);
				compMaster.setSchemeInputEa(entityAggregationList);
				List<SchemePoAmtMaster> payoutFilterList = getPayoutFilter(schemId,compId);
				compMaster.setSchemeInputPoAmt(payoutFilterList);
				
				compMaster.setCompName(rs.getString("componenet_name"));
				compMaster.setStartDate(rs.getDate("start_date"));
				compMaster.setEndDate(rs.getDate("end_date"));
				compMaster.setFreqName(rs.getString("description"));
				compMaster.setVerticalName(rs.getString("vertical_name"));
				compMaster.setPayToName(rs.getString("display_value"));
				compMaster.setCircleName(rs.getString("circle_name"));
				return compMaster;
			}
		});
		return compReportList;
	}
	
	
	private List<RegZoneMaster> getRegionZone(int schemeId,int compId) {
		String query="select  map.cov_reg_zone_id,scm.component_id, scm.componenet_name, rm.region_description,zm.zone_description "+ 
		" from DLP_COVERAGE_REG_ZONE_MAPPING map, DLP_SCHEME_MASTER sm, dlp_zone_master zm, dlp_region_master rm, "+
		" DLP_SCHEME_COMP_MAPPING scm  where sm.scheme_id = map.scheme_id and map.zone_id = zm.zone_id  "+
		" and zm.region_id = rm.region_id and scm.scheme_id = map.scheme_id and map.componenet_id = scm.component_id "+  
		" and map.scheme_id = "+schemeId+" and map.componenet_id="+compId;

		List<RegZoneMaster> regList = jdbcTemplate.query(query, new RowMapper<RegZoneMaster>() {
			@Override
			public RegZoneMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				RegZoneMaster regMaster = new RegZoneMaster();
				regMaster.setCovRegZoneId(rs.getInt("cov_reg_zone_id"));
				regMaster.setCompId(rs.getInt("component_id"));
				regMaster.setCompName(rs.getString("componenet_name"));
				regMaster.setRegionDesc(rs.getString("region_description"));
				regMaster.setZoneDesc(rs.getString("zone_description"));
				return regMaster;
			}
		});
		return regList;
	}

	
	private List<SchemeTqMaster> getTransactionQualify(int schemeId,int compId) {
		String query="select tq.scheme_id, tq.component_id,	tq.condition_id, tq.condition_name, tq.value, tq.start_date,"+ 
		" tq.end_date,tq.l_start_date,tq.l_end_date,tq.l_value,input.input_type_desc data_set,param.uni_field_display_value param,"+ 
		" lparam.uni_field_display_value l_param, opr.description opr,l_lopr.description l_lopr,lopr.display_value lopr,ropr.display_value ropr,"+ 
		" vt.value_type_desc value_type,lvt.value_type_desc l_value_type"+
		" from DLP_SCM_TQ_COND_CONFIG tq left outer join dlp_tbl_input_type_master input on tq.data_set =input.input_type_id "+   
		" left outer join dlp_tbl_universe_field_map param	on tq.perf_parameter = param.uni_fld_seq_no "+ 
		" left outer join dlp_operator_master opr on tq.opr =opr.operator_id left outer join dlp_tbl_value_type_master vt "+  
		" on tq.value_type =vt.value_type_id left outer join dlp_operator_master lopr on tq.lopr =lopr.operator_id "+  
		" left outer join dlp_tbl_universe_field_map  lparam on tq.l_perf_parameter =lparam.uni_fld_seq_no left outer join dlp_operator_master l_lopr "+  
		" on tq.l_opr =l_lopr.operator_id  left outer join dlp_operator_master ropr on tq.ropr =ropr.operator_id left outer join dlp_tbl_value_type_master lvt "+  
		" on tq.l_value_type =lvt.value_type_id where scheme_id = "+schemeId+" and tq.component_id="+compId;

		List<SchemeTqMaster> transQualifyList = jdbcTemplate.query(query, new RowMapper<SchemeTqMaster>() {
			@Override
			public SchemeTqMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeTqMaster covMaster = new SchemeTqMaster();
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setCondId(rs.getInt("condition_id"));
				covMaster.setCondName(rs.getString("condition_name"));
				covMaster.setDataSetName(rs.getString("data_set"));
				covMaster.setPerfParamName(rs.getString("param"));
				covMaster.setOprName(rs.getString("opr"));
				covMaster.setValueTypeName(rs.getString("value_type"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setStartDate(rs.getDate("start_date"));
				covMaster.setEndDate(rs.getDate("end_date"));
				covMaster.setLoprName(rs.getString("lopr"));
				covMaster.setLperfParamName(rs.getString("l_param"));
				covMaster.setL_loprName(rs.getString("l_lopr"));
				covMaster.setLvalueTypeName(rs.getString("l_value_type"));
				covMaster.setlValue(rs.getString("l_value"));
				covMaster.setlStartDate(rs.getDate("l_start_date"));
				covMaster.setlEndDate(rs.getDate("l_end_date"));
				covMaster.setRoprName(rs.getString("ropr"));
				return covMaster;
			}
		});
		return transQualifyList;
	}

	//
	private List<SchemeEaMaster> getEntityAggregationList(int schemeId,int compId) {
		// TODO Auto-generated method stub
		String query="select ea.component_id,ea.variable_id,ea.variable_name,dst.agg_type_desc data_set,ent.display_value entity_name, "+
				" ds.condition_name data_source,fun.display_value function_name,ea.parameter parameter_name,opr.display_value opr,"+ 
				" ea.value_type,ea.value,ea.start_date,ea.end_date,ea.update_date_time,ea.insert_date_time "+
				" from DLP_SCM_EA_COND_CONFIG ea  left outer join dlp_aggregate_type_master dst "+  
				" on ea.data_set =dst.agg_type_id "+  
				" left outer join dlp_entity_type_master ent "+  
				" on ea.entity_type =ent.entity_type_id  "+
				" left outer join DLP_SCM_TQ_COND_CONFIG ds "+  
				" on ea.data_source =ds.condition_id   "+
				" left outer join dlp_tbl_function_master fun "+  
				" on ea.function =fun.function_id  "+
				" left outer join dlp_operator_master opr "+ 
				" on ea.opr =opr.operator_id  where ds.scheme_id = ea.scheme_id AND ea.scheme_id = "+schemeId+" and ea.component_id= "+compId;
						
		List<SchemeEaMaster> entityAggregationList = jdbcTemplate.query(query, new RowMapper<SchemeEaMaster>() {
			@Override
			public SchemeEaMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemeEaMaster covMaster = new SchemeEaMaster();
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setCondId(rs.getInt("variable_id"));
				covMaster.setVariableId(rs.getInt("variable_id"));
				covMaster.setVariableName(rs.getString("variable_name"));
				covMaster.setDataSetName(rs.getString("data_set"));
				covMaster.setEntityTypeName(rs.getString("entity_name"));
				covMaster.setDataSourceName(rs.getString("data_source"));
				covMaster.setFunctionName(rs.getString("function_name"));
				covMaster.setParameter(rs.getString("parameter_name"));
				covMaster.setOprName(rs.getString("opr"));
				covMaster.setValueType(rs.getString("value_type"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setStartDate(rs.getDate("start_date"));
				covMaster.setEndDate(rs.getDate("end_date"));
				covMaster.setUpdateDate(rs.getDate("update_date_time"));
				covMaster.setInsertDate(rs.getDate("insert_date_time"));
				return covMaster;
			}
		});
		return entityAggregationList;
	}
	
	//
	private List<SchemePoAmtMaster> getPayoutFilter(int schemeId,int compId) {
		String query="select pof.component_id,pof.condition_id,po.value,pof.gross_net,unit.display_value unit,pof.amount, "+ 
					 " var.display_value variable,pof.over_achievement,	pof.under_achievement,pof.update_date_time,pof.insert_date_time "+  
					 " from DLP_SCM_PO_AMT_CONFIG pof left outer join DLP_SCM_PO_COND_CONFIG po on po.condition_id = pof.condition_id "+  
					 " left outer join DLP_Entity_Type_Master var on var.entity_type_id = pof.variable left outer join dlp_unit_master unit "+  
					 " on unit.unit_id = pof.unit where po.scheme_id = pof.scheme_id and pof.scheme_id = "+schemeId+" and pof.component_id="+compId;
		
		List<SchemePoAmtMaster> payoutFilterList = jdbcTemplate.query(query, new RowMapper<SchemePoAmtMaster>() {
			@Override
			public SchemePoAmtMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				SchemePoAmtMaster covMaster = new SchemePoAmtMaster();
				covMaster.setCompId(rs.getInt("component_id"));
				covMaster.setCondId(rs.getInt("condition_id"));
				covMaster.setValue(rs.getString("value"));
				covMaster.setGrossNet(rs.getString("gross_net"));
				covMaster.setUnitName(rs.getString("unit"));
				covMaster.setAmount(rs.getInt("amount"));
				covMaster.setVariableName(rs.getString("variable"));
				covMaster.setOverAch(rs.getInt("over_achievement"));
				covMaster.setUnderAch(rs.getInt("under_achievement"));
				covMaster.setUpdateDate(rs.getDate("update_date_time"));
				covMaster.setInsertDate(rs.getDate("insert_date_time"));
				return covMaster;
			}
		});
		return payoutFilterList;
	}*/

	private List<Appendix> getAppendixList() {
		/*String query="select perf_type,param_name,param_mean,valid_value from DLP_PERF_APPENDIX  ";
		//System.out.println("Appendix Query ::::: "+query);
		*/
		List<Appendix> appendix = jdbcTemplate.query(ReportQueries.APPENDIX, new RowMapper<Appendix>() {
			@Override
			public Appendix mapRow(ResultSet rs, int rowNum) throws SQLException {
				Appendix append = new Appendix();
				append.setPerformanceType(rs.getString("PERF_TYPE"));
				append.setParameterName(rs.getString("PARAM_NAME"));
				append.setParameterMeaning(rs.getString("PARAM_MEAN"));
				append.setValidValue(rs.getString("VALID_VALUE"));
				return append;
			}
		});
		return appendix;
	}
	
	
	public List<DistributorStatementPojo> fetchDistributorStmt(String circle,String distId) throws Exception{
		Connection connection = jdbcTemplate.getDataSource().getConnection();
		PreparedStatement ps = null;
		ResultSet result=null;
		try{
		DistributorStatementPojo distStmtPojo;
		List<DistributorStatementPojo> distStmtPojoList = null;
/**
 * "SELECT STATEMENT_CYCLE_ID,DISTRIBUTOR_STATEMENT_ID,STATEMENT_MONTH,STATEMENT_DATE," +
				"DISTRIBUTOR_DSM2_ID,DISTRIBUTOR_NAME,DISTRIBUTOR_MOBILE_NUM,DISTRIBUTOR_PAN_NO,DISTRIBUOTR_EMAIL,DISTRIBUTOR_ZONE," +
				"CIRCLE,SCM_LIST_ID,NORMAL_GROSS,MNP_GROSS,FLEXI,PAPER,TARGET_GR_ADD_MNP,TARGET_GR_ADD_NMNP,TARGET_GR_ADD_TOTAL," +
				"TOTAL_FLEXI_PAPER,ACHIEVEMENT_PERC_MNP,ACHIEVEMENT_PERC_NMNP,ACHIEVEMENT_PERC_TOTAL,DIST_INVOICE_LINK,INSERT_DATE_TIME," +
				"PAYOUT_GROSS,TOTAL_TDS,TOTAL_NET,RET_PAYOUT_GROSS,RET_TOTAL_TDS,RET_TOTAL_NET,GROSS_ACT FROM DLP_DIST_STATEMENT WHERE CIRCLE = ? and DISTRIBUTOR_DSM2_ID = ?"
 */
		String FETCH_DIST_STMT = "SELECT STATEMENT_CYCLE_ID,DISTRIBUTOR_STATEMENT_ID,STATEMENT_MONTH,STATEMENT_DATE," +
				" DISTRIBUTOR_DSM2_ID,DISTRIBUTOR_NAME,DISTRIBUTOR_MOBILE_NUM,DISTRIBUTOR_PAN_NO,DISTRIBUOTR_EMAIL,DISTRIBUTOR_ZONE," +
				" SCM_LIST_ID,NORMAL_GROSS,MNP_GROSS,FLEXI,PAPER,TARGET_GR_ADD_MNP,TARGET_GR_ADD_NMNP,TARGET_GR_ADD_TOTAL," +
				" TOTAL_FLEXI_PAPER,ACHIEVEMENT_PERC_MNP,ACHIEVEMENT_PERC_NMNP,ACHIEVEMENT_PERC_TOTAL,INSERT_DATE_TIME," +
				" PAYOUT_GROSS,TOTAL_TDS,TOTAL_NET,RET_PAYOUT_GROSS,RET_TOTAL_TDS,RET_TOTAL_NET,GROSS_ACT FROM DLP_DIST_STATEMENT_"+circle+" WHERE DISTRIBUTOR_DSM2_ID = ?";

		ps = connection.prepareStatement(FETCH_DIST_STMT);
		//ps.setString(1, circle);
		ps.setString(1, distId);
		
		result = ps.executeQuery();
		distStmtPojoList = new ArrayList<DistributorStatementPojo>();
		while(result.next()){
			distStmtPojo = new DistributorStatementPojo();
			distStmtPojo.setStmtCycleId(result.getInt("STATEMENT_CYCLE_ID"));
			distStmtPojo.setDistStmtId(result.getInt("DISTRIBUTOR_STATEMENT_ID"));
			distStmtPojo.setMonth(result.getString("STATEMENT_MONTH"));
			distStmtPojo.setDate(result.getString("STATEMENT_DATE"));
			distStmtPojo.setDistDsm2Id(result.getString("DISTRIBUTOR_DSM2_ID"));
			distStmtPojo.setDistName(result.getString("DISTRIBUTOR_NAME"));
			distStmtPojo.setDistMobile(result.getString("DISTRIBUTOR_MOBILE_NUM"));
			distStmtPojo.setDistPanNo(result.getString("DISTRIBUTOR_PAN_NO"));
			distStmtPojo.setDistEmail(result.getString("DISTRIBUOTR_EMAIL"));
			distStmtPojo.setDistZone(result.getString("DISTRIBUTOR_ZONE"));
			//distStmtPojo.setCircle(result.getString("CIRCLE"));
			distStmtPojo.setCircle(circle);
			
			distStmtPojo.setScmListId(result.getInt("SCM_LIST_ID"));
			distStmtPojo.setNormalGross(result.getBigDecimal("NORMAL_GROSS"));
			distStmtPojo.setMnpGross(result.getBigDecimal("MNP_GROSS"));
			distStmtPojo.setFlexi(result.getBigDecimal("FLEXI"));
			distStmtPojo.setPaper(result.getBigDecimal("PAPER"));
			distStmtPojo.setTargetMnp(result.getBigDecimal("TARGET_GR_ADD_MNP"));
			distStmtPojo.setTargetNmnp(result.getBigDecimal("TARGET_GR_ADD_NMNP"));
			distStmtPojo.setTargetTotal(result.getBigDecimal("TARGET_GR_ADD_TOTAL"));
			distStmtPojo.setTotalFexiPaper(result.getBigDecimal("TOTAL_FLEXI_PAPER"));
			distStmtPojo.setAchiveMnp(result.getBigDecimal("ACHIEVEMENT_PERC_MNP"));
			distStmtPojo.setAchiveNmnp(result.getBigDecimal("ACHIEVEMENT_PERC_NMNP"));
			distStmtPojo.setAchiveTotal(result.getBigDecimal("ACHIEVEMENT_PERC_TOTAL"));
			//distStmtPojo.setDistInvoiceLink(result.getString("DIST_INVOICE_LINK"));
			distStmtPojo.setInsertDateTime(result.getString("INSERT_DATE_TIME"));
			distStmtPojo.setPayoutGross(result.getString("PAYOUT_GROSS"));
			distStmtPojo.setTotalTds(result.getBigDecimal("TOTAL_TDS"));
			distStmtPojo.setTotalNet(result.getBigDecimal("TOTAL_NET"));
			distStmtPojo.setRetPayoutGross(result.getBigDecimal("RET_PAYOUT_GROSS"));
			distStmtPojo.setRetTotalTds(result.getBigDecimal("RET_TOTAL_TDS"));
			distStmtPojo.setRetTotalNet(result.getFloat("RET_TOTAL_NET"));
			distStmtPojo.setGrossAct(result.getBigDecimal("GROSS_ACT"));
			distStmtPojo.setDistStmtSchmList(fetchDistStmtScheme(connection, distStmtPojo.getScmListId(), circle));
			distStmtPojo.setDistRetSchmList(fetchDistRetScheme(connection, distStmtPojo.getScmListId(), circle));
			distStmtPojoList.add(distStmtPojo);
		}
		//System.out.println(distStmtPojoList.size());
		return distStmtPojoList;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}finally{
			ps.close();
			connection.close();
		}
	}
	
	private List<DistributorStmtSchmPojo> fetchDistStmtScheme(Connection connection, int scmListId, String circle) throws Exception{
		PreparedStatement ps = null;
		ResultSet result = null;
		DistributorStmtSchmPojo distStmtScmPojo= null;
		List<DistributorStmtSchmPojo> distStmtScmPojoList = new ArrayList<DistributorStmtSchmPojo>();		
		try {			
			/*String query = "select STMT_SCM_ID,SCM_LIST_ID,PAY_TOTAL,PERF_TOTAL,GROSS_PAY_AMT,NET_COMM,TDS_AMOUNT," +
			"SCHEME_ID,COMPONENT_ID,TARGET,ACHIEVED_PERC,SCHEME_COMPONENT_DESC FROM DLP_DIST_STMT_SCM_LIST " +
			"WHERE SCM_LIST_ID = ?";
			*/
			String FETCH_DIST_STMT_SCHEME = "select STMT_SCM_ID,SCM_LIST_ID,PAY_TOTAL,GROSS_PAY_AMT,NET_COMM,TDS_AMOUNT," +
					"SCHEME_ID,COMPONENT_ID,SCHEME_COMPONENT_DESC FROM DLP_DIST_STMT_SCM_LIST_"+circle +
					"WHERE SCM_LIST_ID = ?";
			ps = connection.prepareStatement(FETCH_DIST_STMT_SCHEME);
			ps.setInt(1, scmListId);
			result = ps.executeQuery();
			while(result.next()){
				distStmtScmPojo = new DistributorStmtSchmPojo();				
				distStmtScmPojo.setStatScmId(result.getInt("STMT_SCM_ID"));
				distStmtScmPojo.setSchListId(result.getInt("SCM_LIST_ID"));
				distStmtScmPojo.setPayTotal(result.getBigDecimal("PAY_TOTAL"));
			//	distStmtScmPojo.setRefTotal(result.getBigDecimal("PERF_TOTAL"));
				distStmtScmPojo.setGrossPayAmt(result.getBigDecimal("GROSS_PAY_AMT"));
				distStmtScmPojo.setNetComm(result.getBigDecimal("NET_COMM"));
				distStmtScmPojo.setTdsAmount(result.getBigDecimal("TDS_AMOUNT"));
				distStmtScmPojo.setSchemeId(result.getInt("SCHEME_ID")); 
				distStmtScmPojo.setCompoentId(result.getInt("COMPONENT_ID"));
			//	distStmtScmPojo.setTarget(result.getString("TARGET"));
				//distStmtScmPojo.setAchivedPerc(result.getString("ACHIEVED_PERC"));
				distStmtScmPojo.setSchemeCompDesc(result.getString("SCHEME_COMPONENT_DESC"));
				distStmtScmPojoList.add(distStmtScmPojo);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			ps.close();
		}
		return distStmtScmPojoList;
		
	}
	
	private List<DistributorRetSchmPojo> fetchDistRetScheme(Connection connection, int scmListId, String circle) throws Exception{
		PreparedStatement ps = null;
		ResultSet result = null;
		DistributorRetSchmPojo distRetPojo = null;
		List<DistributorRetSchmPojo> distRetPojoList = new ArrayList<DistributorRetSchmPojo>();		
		try {			
			/*String query = "SELECT SCM_LIST_ID,PAY_TOTAL,PERF_TOTAL,GROSS_PAY_AMT,NET_COMM,TDS_AMOUNT,SCHEME_ID," +
			"COMPONENT_ID,TARGET,ACHIEVED_PERC,SCHEME_COMPONENT_DESC FROM DLP_DIST_RET_SCM_LIST " +
			"WHERE SCM_LIST_ID = ?";*/	
			String FETCH_DIST_RETAIL_SCHEME = "SELECT SCM_LIST_ID,PAY_TOTAL,GROSS_PAY_AMT,NET_COMM,TDS_AMOUNT,SCHEME_ID," +
					"COMPONENT_ID,SCHEME_COMPONENT_DESC FROM DLP_DIST_RET_SCM_LIST_"+circle +
					"WHERE SCM_LIST_ID = ?";
			ps = connection.prepareStatement(FETCH_DIST_RETAIL_SCHEME);
			ps.setInt(1, scmListId);
			result = ps.executeQuery();
			while(result.next()){
				distRetPojo = new DistributorRetSchmPojo();
				distRetPojo.setSchemeListId(result.getInt("SCM_LIST_ID"));
				distRetPojo.setPayTotal(result.getBigDecimal("PAY_TOTAL"));
				//distRetPojo.setRefTotal(result.getFloat("PERF_TOTAL"));PERF_TOTAL,
				distRetPojo.setGrossPayAmt(result.getBigDecimal("GROSS_PAY_AMT"));
				distRetPojo.setNetComm(result.getFloat("NET_COMM"));
				distRetPojo.setTdsAmount(result.getBigDecimal("TDS_AMOUNT"));
				distRetPojo.setSheetId(result.getInt("SCHEME_ID"));
				distRetPojo.setComponentId(result.getInt("COMPONENT_ID"));
				//distRetPojo.setTarget(result.getString("TARGET"));TARGET,
				//distRetPojo.setAchivedPerc(result.getString("ACHIEVED_PERC"));ACHIEVED_PERC,
				distRetPojo.setSchemeCompDesc(result.getString("SCHEME_COMPONENT_DESC"));
				distRetPojoList.add(distRetPojo);
			}			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw e;
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}finally{
			ps.close();
		}
		return distRetPojoList;
	}
	
	public List<ReportGenerateMaster> getReportCategory()
	{
		String query="select Category_Id,Category_Name from DLP_RPT_Category_Master order by Category_Id";
		List<ReportGenerateMaster> reportCategory = jdbcTemplate.query(query, new RowMapper<ReportGenerateMaster>() {
			@Override
			public ReportGenerateMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReportGenerateMaster reportGenMaster = new ReportGenerateMaster();
				reportGenMaster.setCategoryId(rs.getInt("Category_Id"));
				reportGenMaster.setCategoryName(rs.getString("Category_Name"));
				return reportGenMaster;
			}
		});
		//System.out.println("getReportCategory res:"+reportCategory);
		return reportCategory;
		
	}
	
	public List<ReportGenerateMaster> getScmReportCategory()
	{
		String query="Select cat_id,cat_description From Dlp_Scheme_Category Where Validity_Flag='Y' Order By Cat_Description";
		List<ReportGenerateMaster> reportCategory = jdbcTemplate.query(query, new RowMapper<ReportGenerateMaster>() {
			@Override
			public ReportGenerateMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReportGenerateMaster reportGenMaster = new ReportGenerateMaster();
				reportGenMaster.setScmCategoryId(rs.getInt("cat_id"));
				reportGenMaster.setScmCategoryName(rs.getString("cat_description"));
				return reportGenMaster;
			}
		});
		//System.out.println("getScmReportCategory res:"+reportCategory);
		return reportCategory;
		
	}
	
	public List<ReportGenerateMaster> reportNameStore(String circle)
	{
		String query="Select REPORT_ID,REPORT_NAME, REPORT_INPUT_CATEGORY,REPORT_GEN_TYPE,Last_Generation_DT,duration from Dlp_Rpt_Master where "+circle+"_flag='Y' and validity_flag='Y' order by REPORT_ID";
		//System.out.println("ReportGenerationDAOImpl || reportNameStore || query:"+query);
		List<ReportGenerateMaster> reportName = jdbcTemplate.query(query, new RowMapper<ReportGenerateMaster>() {
			@Override
			public ReportGenerateMaster mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReportGenerateMaster reportGenMaster = new ReportGenerateMaster();
				reportGenMaster.setReportId(rs.getInt("REPORT_ID"));
				reportGenMaster.setReportName(rs.getString("REPORT_NAME"));
				reportGenMaster.setReportInputCategory(rs.getInt("REPORT_INPUT_CATEGORY"));
				reportGenMaster.setReportGenType(rs.getInt("REPORT_GEN_TYPE"));
				reportGenMaster.setReportLastGenDateTime(rs.getDate("Last_Generation_DT"));
				reportGenMaster.setDuration(rs.getInt("duration"));
				return reportGenMaster;
			}
		});
		//System.out.println("reportNameStore res:"+reportName.get(0).getReportLastGenDateTime());
		return reportName;
		
	}
	
	public String getReportPath(int reportId)
	{
	
		String query="select Output_File_Path||Output_File_Name||'::'||Report_Gen_Type||'::'||Procedure_Name as Output_File_Path from Dlp_Rpt_Master where report_id="+reportId;
		String reportPath=jdbcTemplate.queryForObject(query, String.class);
		//System.out.println("ReportGeneration || getReportPath || reportPath:"+reportPath);
		return reportPath;
	}
	public String callProcReportScheme(int schemeId,int compId,String startDate,String endDate,String scmStatus,String payoutFlag,String paymentFlag,String entityType,String reportName,String category) 
	{
		String procOutput=null;
		String procName=null;
		String genType=null;
		StringBuffer sb=new StringBuffer();
		try
		{
			
			//System.out.println("callProcReportScheme before proc call ::reportNameId:"+reportName+":::parseDate:"+startDate.split("T")[0]);
			
		String query="select Report_Gen_Type||'::'||procedure_name from dlp_rpt_master where report_name='"+reportName+"'";
		Date startDateFormat=null;
		Date endDateFormat=null;
		DateFormat formatter=new SimpleDateFormat("dd-MMM-yyyy");
		if(startDate!=null && !"".equals(startDate))
			startDateFormat=new java.sql.Date(formatter.parse(startDate.split("T")[0]).getTime());
		if(endDate!=null && !"".equals(endDate))
			endDateFormat= new java.sql.Date(formatter.parse(endDate.split("T")[0]).getTime());
		Connection connection = jdbcTemplate.getDataSource().getConnection();
		String procedureName=jdbcTemplate.queryForObject(query, String.class);
		
		if(procedureName==null || "".equals(procedureName))
		{
		   return "No Procedure to call";
		}
		else
		{
			String tempArray[]=procedureName.split("::");
			genType=tempArray[0];
			procName=tempArray[1];
		}
		if(genType!=null && "2".equals(genType))
		{
		//System.out.println("callProcReportScheme::::::"+procName);
		CallableStatement call = connection.prepareCall("{call "+procName+" (?,?,?,?,?,?,?,?,?,?)}");
		call.setInt(1,schemeId);
		call.setInt(2,compId);
		call.setDate(3, startDateFormat);
		call.setDate(4, endDateFormat);
		call.setString(5, scmStatus);
		call.setString(6, payoutFlag);
		call.setString(7, paymentFlag);
		call.setString(8, entityType);
		call.setString(9, category);
		call.registerOutParameter(10 , OracleTypes.VARCHAR);
		call.execute();
		//System.out.println("clob value:::::"+call.getClob(10));
		 Clob cl = call.getClob(10);
		    BufferedReader br = null;
		    String line;
		    try {
		        br = new BufferedReader(new InputStreamReader(cl.getAsciiStream()));
		        while ((line = br.readLine()) != null) {
		            sb.append(line);
		        }
		    } catch (IOException e) {
		    } finally {
		        if (br != null) {
		            try {
		                br.close();
		            } catch (IOException e) {
		            }
		        }
		    }
		    procOutput=sb.toString();    
		//System.out.println("callProcReportScheme || Prcedure called:"+procOutput);
		}
		else if(genType!=null && "1".equals(genType))
		{
			
			//System.out.println("ReportGenerateDaoImpl || callProcReportScheme || else if block genType:"+schemeId+"-"+compId+"-"+startDateFormat+
			//		"-"+endDateFormat+"-"+scmStatus+"-"+payoutFlag+"-"+paymentFlag+"-"+entityType+"-"+category);
		   //System.out.println("callProcReportScheme || sqlquery used is :"+procName);
			List<ReportCsvDownload> csvList=jdbcTemplate.query(procName,new Object[]{schemeId,compId,startDateFormat,endDateFormat,scmStatus,payoutFlag,paymentFlag,entityType,category} ,new RowMapper<ReportCsvDownload>(){
				@Override
				public ReportCsvDownload mapRow(ResultSet rs, int rowNum) throws SQLException {
					ReportCsvDownload records = new ReportCsvDownload();
					records.setVal1(rs.getString(1));
					records.setVal2(rs.getString(2));
					records.setVal3(rs.getString(3));
					records.setVal4(rs.getString(4));
					records.setVal5(rs.getString(5));
					return records;
				}	
		});
			//System.out.println("csvList:::::List"+csvList);
			if(csvList!=null)
			{
				
				for(ReportCsvDownload temp:csvList)
				{
					sb.append(temp.getVal1());
					sb.append(",");
					sb.append(temp.getVal2());
					sb.append(",");
					sb.append(temp.getVal3());
					sb.append(",");
					sb.append(temp.getVal4());
					sb.append(",");
					sb.append(temp.getVal5());
					sb.append("\n");
					
				}
			}
			procOutput=sb.toString();
			//System.out.println("ReportGenerateDaoImpl || callProcReportScheme || sb:"+sb.toString());
		}
		}
		catch(SQLException  e)
		{
			//System.out.println("Proceudure name is not valid:"+e);
			return "Please check the Data  in table";
		}
		catch(Exception e)
		{
			//System.out.println(" Exception raised is:"+e);
		}
		
		return procOutput;
	}
	@Override
	public String callProcMonthScheme(String startDate,String endDate,String entityId,int conNo,String entityType,String reportName)
	{
		String procOutput=null;
		String procName=null;
		String genType=null;
		StringBuffer sb=new StringBuffer();
		try
		{
		//System.out.println("ReportGenDaoImpl || callProcMonthScheme || BEG:"+startDate+"-"+endDate+"-"+entityId+"-"+conNo+"-"+entityType+"-"+reportName);
		
		String query="select Report_Gen_Type||'::'||procedure_name from dlp_rpt_master where report_name='"+reportName+"'";
		Date startDateFormat=null;
		Date endDateFormat=null;
		DateFormat formatter=new SimpleDateFormat("dd-MMM-yyyy");
		if(startDate!=null && !"".equals(startDate))
			startDateFormat=new java.sql.Date(formatter.parse(startDate.split("T")[0]).getTime());
		if(endDate!=null && !"".equals(endDate))
			endDateFormat= new java.sql.Date(formatter.parse(endDate.split("T")[0]).getTime());
		Connection connection = jdbcTemplate.getDataSource().getConnection();
		String procedureName=jdbcTemplate.queryForObject(query, String.class);
		if(procedureName==null || "".equals(procedureName))
		{
		   return "No Procedure to call";
		}
		else
		{
			String tempArray[]=procedureName.split("::");
			genType=tempArray[0];
			procName=tempArray[1];
		}
		if(genType!=null && "2".equals(genType))
		{
			//System.out.println("startDateFormat:::"+startDateFormat);
		CallableStatement call = connection.prepareCall("{call "+procName+" (?,?,?,?,?,?)}");
		call.setDate(1, startDateFormat);
		call.setDate(2, endDateFormat);
		call.setString(3, entityId);
		call.setInt(4, conNo);
		call.setString(5, entityType);
		call.registerOutParameter(6,OracleTypes.CLOB);
		call.execute();
		 Clob cl = call.getClob(6);
		    BufferedReader br = null;
		    String line;
		    try {
		        br = new BufferedReader(new InputStreamReader(cl.getAsciiStream()));
		        while ((line = br.readLine()) != null) {
		            sb.append(line);
		        }
		    } catch (IOException e) {
		    } finally {
		        if (br != null) {
		            try {
		                br.close();
		            } catch (IOException e) {
		            }
		        }
		    }
		    //System.out.println("callProcMonthScheme || Prcedure called:"+procOutput);
		    procOutput=sb.toString();
		}
		else if(genType!=null && "1".equals(genType))
		{
			List<ReportCsvDownload> csvList=jdbcTemplate.query(procName,new Object[]{startDateFormat,endDateFormat,entityId,conNo,entityType} ,new RowMapper<ReportCsvDownload>(){
			@Override
			public ReportCsvDownload mapRow(ResultSet rs, int rowNum) throws SQLException {
				ReportCsvDownload records = new ReportCsvDownload();
				records.setVal1(rs.getString(1));
				records.setVal2(rs.getString(2));
				records.setVal3(rs.getString(3));
				records.setVal4(rs.getString(4));
				records.setVal5(rs.getString(5));
				return records;
			}	
	});
		//System.out.println("csvList:::::List"+csvList);
		if(csvList!=null)
		{
			
			for(ReportCsvDownload temp:csvList)
			{
				sb.append(temp.getVal1());
				sb.append(",");
				sb.append(temp.getVal2());
				sb.append(",");
				sb.append(temp.getVal3());
				sb.append(",");
				sb.append(temp.getVal4());
				sb.append(",");
				sb.append(temp.getVal5());
				sb.append("\n");
				
			}
		}
		procOutput=sb.toString();
		//System.out.println("ReportGenerateDaoImpl || callProcReportScheme || sb:"+sb.toString());
		}
		}
		catch(SQLException  e)
		{
			//System.out.println("Proceudure name is not valid:"+e);
			return "Please check the Data  in table";
		}
		catch(Exception e)
		{
			//System.out.println("Exception raised . Exception is:"+e);
		}
		return procOutput;
	}
	
}

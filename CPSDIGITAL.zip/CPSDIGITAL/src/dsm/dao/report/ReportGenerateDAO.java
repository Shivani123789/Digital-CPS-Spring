package dsm.dao.report;

import java.util.List;

import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.SchemeMaster;
import dsm.model.report.ReportGenerateMaster;

public interface ReportGenerateDAO {

	public List<SchemeMaster> searchScheme(String Scheme);
	
	public ReportGenerateMaster reportGenerate(int schemeId,int compId,int circleId,String circleCode);
	
	public List<DistributorStatementPojo> fetchDistributorStmt(String circle,String distId) throws Exception;
	
	public List<ReportGenerateMaster> getReportCategory();
	
	public List<ReportGenerateMaster> getScmReportCategory();
	
	public List<ReportGenerateMaster> reportNameStore(String circle) ;
	
	public String getReportPath(int reportId) ;
	
	public String callProcReportScheme(int schemeId,int compId,String startDate,String endDate,String scmStatus,String payoutFlag,String paymentFlag,String entityType,String reportNameId,String category);
	
	public String callProcMonthScheme(String startDate,String EndDate,String entityId,int conNo,String entityType,String reportName);
	
}

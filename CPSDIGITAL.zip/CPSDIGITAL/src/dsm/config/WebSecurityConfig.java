package dsm.config;



import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.servlet.configuration.EnableWebMvcSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.ldap.DefaultSpringSecurityContextSource;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.util.matcher.RequestHeaderRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

import dsm.controller.login.UserAuthenticationErrorHandler;

@Configuration
@EnableWebMvcSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter 
{
	 @Autowired
		private Environment env;

	 @Autowired
		UserAuthenticationErrorHandler uaeh ;
	 
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		try {
			http.csrf().disable();
			http.exceptionHandling().defaultAuthenticationEntryPointFor(ajaxAuthenticationEntryPoint(),  ajaxRequestMatcher());
			http.headers().httpStrictTransportSecurity().disable();
			http.exceptionHandling().accessDeniedPage("/payoutcondition/acessDenied.action");
			http.authorizeRequests()
			//.antMatchers(HttpMethod.OPTIONS, "/**").denyAll()
			//.antMatchers(HttpMethod.TRACE, "/**").denyAll()
			.antMatchers("/").permitAll()
			.antMatchers("*/images/**").permitAll()
			.antMatchers("/resources/**").permitAll()
			.anyRequest().authenticated()
			.and()
			.formLogin()
			.loginPage("/login")
			.loginProcessingUrl("/j_spring_security_check").failureHandler(uaeh)
			.usernameParameter("j_username")
			.passwordParameter("j_password")
			.defaultSuccessUrl("/index.jsp")
			.permitAll()
			.and()
			.logout()
			.logoutUrl("/j_spring_security_logout")
			.deleteCookies("JSESSIONID")
			.invalidateHttpSession(true)
			.logoutSuccessUrl("/login");
			http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED).sessionFixation().migrateSession().maximumSessions(1).expiredUrl("/expired").sessionRegistry(sessionRegistry());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	 @Bean
	 public SessionRegistry sessionRegistry() {
	        SessionRegistry sessionRegistry = new SessionRegistryImpl();
	        return sessionRegistry;
	    }
	 
	@Bean
    public AuthenticationEntryPoint ajaxAuthenticationEntryPoint() {
		System.out.println("WebSecurityConfig ajaxAuthenticationEntryPoint");
		return new AuthenticationEntryPoint() {
    	@Override
		public void commence(HttpServletRequest request, HttpServletResponse response,	AuthenticationException authException) throws IOException, ServletException {
			response.setContentType("application/json");
		    response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		    response.getOutputStream().println("{ \"error\": \"" + authException.getMessage().trim().replace(",", " ") + "\" }");
			
//			String header = request.getHeader("X-Requested-With");
//	        
//			if (StringUtils.hasText(header) && header.equals("XMLHttpRequest") && authException != null) {
//	            response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
//	        } else {
//	           // super.commence(request, response, authException);
//		    }		
		}
    };
    }

    @Bean
    public RequestMatcher ajaxRequestMatcher() {
    	return new RequestHeaderRequestMatcher("X-Requested-With", "XMLHttpRequest");
    }

    
    @Bean
    public CustomLdapAuthoritiesPopulator customLdapAuthoritiesPopulator(){
    	System.out.println("WebSecurityConfig customLdapAuthoritiesPopulator");
    	return new CustomLdapAuthoritiesPopulator();
    }
  
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    	try{
    		System.out.println("WebSecurityConfig configure");
    		DefaultSpringSecurityContextSource contextSource = new DefaultSpringSecurityContextSource(env.getProperty("LDAP_URL"));
    		contextSource.setUserDn(env.getProperty("DOMAIN_USER"));
    		contextSource.setPassword(env.getProperty("DOMAIN_PASSWORD"));
    		contextSource.afterPropertiesSet();
    		auth.ldapAuthentication().ldapAuthoritiesPopulator(customLdapAuthoritiesPopulator())
    		.userSearchFilter(env.getProperty("SEARCH_FILTER"))
    		.contextSource(contextSource);
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    }
            
}
package dsm.config;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.ldap.userdetails.LdapAuthoritiesPopulator;
import org.springframework.stereotype.Component;


@Component
public class CustomLdapAuthoritiesPopulator implements LdapAuthoritiesPopulator {

	@Autowired
	private DataSource dataSource;
	
	private JdbcTemplate jdbcTemplate ;
	
	
	@Override
     public Collection<? extends GrantedAuthority> getGrantedAuthorities(DirContextOperations userData, String username) {
             Collection<GrantedAuthority> gas = new HashSet<GrantedAuthority>();
             System.out.println("CustomLdapAuthoritiesPopulator.getGrantedAuthorities username :::::::::: "+username+" \t userData::"+userData);
             List<String> rights = userRights(username);
             for(String s: rights){
            	 String aa = "role_"+s;
            	 gas.add(new SimpleGrantedAuthority(aa.toUpperCase()));
            	 System.out.println("Roles :::: "+aa.toUpperCase());
             }
             gas.add(new SimpleGrantedAuthority("DummyRole"));
             return gas;
     }

	 
	 public List<String> userRights(String userName){
		 jdbcTemplate = new JdbcTemplate(dataSource);
		 String query = "select R.ROLE_NAME from DSM2_USERS US,DSM2_ROLES R where US.ROLE_ID=R.ROLE_ID and USERNAME='"+userName+"'";
		 //System.out.println("*************  query ::: "+query);
		 List<String> reportList = jdbcTemplate.query(query, new RowMapper<String>() {
			 @Override
			 public String mapRow(ResultSet rs, int rowNum) throws SQLException {
				 String schemeMaster = new String(rs.getString("ROLE_NAME"));
				 System.out.println(" ROLE_NAME :::: "+schemeMaster);
				 return schemeMaster;
			 }
		 });
		 return reportList;
	 }
	 
}

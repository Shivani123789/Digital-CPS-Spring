package dsm.config;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;


import dsm.dao.admin.AdminDAO;
import dsm.dao.admin.AdminDAOImpl;
import dsm.dao.approveNFA.ApproveNFADAO;
import dsm.dao.approveNFA.ApproveNFADAOImpl;
import dsm.dao.bulk.BulkUploadDAO;
import dsm.dao.bulk.BulkUploadDAOImpl;
import dsm.dao.csv.CSVDAO;
import dsm.dao.csv.CSVDAOImpl;
import dsm.dao.ea.SchemeInputEaDAO;
import dsm.dao.ea.SchemeInputEaImpl;
import dsm.dao.form.ConverageInputDAO;
import dsm.dao.form.ConverageInputDAOImpl;
import dsm.dao.form.ConverageInputService;
import dsm.dao.form.ConverageServiceImpl;
import dsm.dao.form.tq.SchemeInputTqDAO;
import dsm.dao.form.tq.SchemeInputTqDAOImpl;
import dsm.dao.login.LoginDAO;
import dsm.dao.login.LoginDAOImpl;
import dsm.dao.master.MasterDAO;
import dsm.dao.master.MasterDAOImpl;
import dsm.dao.po.DsmPoDAO;
import dsm.dao.po.DsmPoDAOImpl;
import dsm.dao.postapp.PostExecDAO;
import dsm.dao.postapp.PostExecDAOImpl;
import dsm.dao.report.ReportGenerateDAO;
import dsm.dao.report.ReportGenerateDAOImpl;
import dsm.dao.save.SchemeInputAllDAO;
import dsm.dao.save.SchemeInputAllDAOImpl;
import dsm.dao.search.SchemeSearchDAO;
import dsm.dao.search.SchemeSearchDAOImpl;
import dsm.dao.stmtGen.StmtGenDAO;
import dsm.dao.stmtGen.StmtGenDAOImpl;
import dsm.dao.transData.TransDataDAO;
import dsm.dao.transData.TransDataDAOImpl;
import dsm.generate.report.PdfViewResolver;
import dsm.service.SchemeInputEAService;
import dsm.service.SchemeInputEQServiceImpl;
import dsm.service.SchemeInputTQService;
import dsm.service.SchemeInputTQServiceImpl;
import dsm.service.admin.AdminService;
import dsm.service.admin.AdminServiceImpl;
import dsm.service.approveNFA.ApproveNFAService;
import dsm.service.approveNFA.ApproveNFAServiceImpl;
import dsm.service.bulk.BulkUploadService;
import dsm.service.bulk.BulkUploadServiceImpl;
import dsm.service.csv.CSVService;
import dsm.service.csv.CSVServiceImpl;
import dsm.service.login.LoginService;
import dsm.service.login.LoginServiceImpl;
import dsm.service.master.MasterService;
import dsm.service.master.MasterServiceImpl;
import dsm.service.po.DsmPoService;
import dsm.service.po.DsmPoServiceImpl;
import dsm.service.postapp.PostExecService;
import dsm.service.postapp.PostExecServiceImpl;
import dsm.service.report.ReportGenerateService;
import dsm.service.report.ReportGenerateServiceImpl;
import dsm.service.save.SaveDataService;
import dsm.service.save.SaveDataServiceImpl;
import dsm.service.search.SchemeSearch;
import dsm.service.search.SchemeSearchImpl;
import dsm.service.stmtGen.StmtGenService;
import dsm.service.stmtGen.StmtGenServiceImpl;
import dsm.service.transData.TransDataSrvc;
import dsm.service.transData.TransDataSrvcImpl;

@Configuration
@ComponentScan(basePackages="dsm")
@Import({ WebSecurityConfig.class })
@EnableWebMvc
//@PropertySource("classpath:db.properties")
@PropertySources({@PropertySource("file:${SCHEME_STUDIO_CONFIG_PATH}LdapConfig/LoginLdap.properties")})
public class MvcConfiguration extends WebMvcConfigurerAdapter{

	/**
	 * @PropertySources({@PropertySource("file:${SCHEME_STUDIO_CONFIG_PATH}LdapConfig/LoginLdap.properties"),@PropertySource("file:${SCHEME_STUDIO_CONFIG_PATH}DBQuery/LoginQueries.properties")})
	 * 
	 */
	
	@Bean
	public ViewResolver getViewResolver(){
		try{
			InternalResourceViewResolver resolver = new InternalResourceViewResolver();
			//resolver.setPrefix("/index");
			//resolver.setOrder(1);
			resolver.setSuffix(".jsp");
			return resolver;	
		}catch(Exception e){
			
		}
		return null;
	}
	
	@Bean(name="multipartResolver")
	public CommonsMultipartResolver multipartResolver() {
	    CommonsMultipartResolver resolver=new CommonsMultipartResolver();
	 //   resolver.setDefaultEncoding("utf-8");
	    return resolver;
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}

	@Bean(name="dataSource")
	public DataSource getDataSource() {
		final JndiDataSourceLookup jndiDS = new JndiDataSourceLookup();
		DataSource dataSource = jndiDS.getDataSource("jndi/schemeStudioPayoutDS");//jndi/cpsdigitalPayoutDS  schemeStudioPayoutDS
		return dataSource;
	}

	
	@Bean
	public HttpSessionEventPublisher httpSessionEventPublisher() {
	    return new HttpSessionEventPublisher();
	}
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfig() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
	@Bean(name="loginDAO")
	public LoginDAO getLoginDAO() {
		return new LoginDAOImpl(getDataSource());
	}
 
	@Bean(name="loginService")
	public LoginService getLoginService() {
		return new LoginServiceImpl();
	}

	@Bean(name="adminDAO")
	public AdminDAO getAdminDAO() {
		return new AdminDAOImpl(getDataSource());
	}
 
	@Bean(name="adminSrvc")
	public AdminService getAdminService() {
		return new AdminServiceImpl();
	}

	@Bean(name="masterDAO")
	public MasterDAO getMasterDAO() {
		return new MasterDAOImpl(getDataSource());
	}
 
	@Bean(name="masterSrvc")
	public MasterService getMasterService() {
		return new MasterServiceImpl();
	}

	@Bean(name="stmtGenDAO")
	public StmtGenDAO getStmtGenDAO() {
		return new StmtGenDAOImpl(getDataSource());
	}
 
	@Bean(name="stmtGenSrvc")
	public StmtGenService getStmtGenService() {
		return new StmtGenServiceImpl();
	}

	@Bean(name="transDataDAO")
	public TransDataDAO getTransDataDAO() {
		return new TransDataDAOImpl(getDataSource());
	}
 
 @Bean(name="transDataSrvc")
	public TransDataSrvc getTransDataSrvc() {
		return new TransDataSrvcImpl();
	}

	
	/*@Bean
	public ConverageInputDAO getConverageInputDAO() {
		return new ConverageInputDAOImpl(getDataSource());
	}*/
	
	 @Bean(name="approveNFADAO")
		public ApproveNFADAO getApproveNFADAO() {
			return new ApproveNFADAOImpl(getDataSource());
		}
	 
	 @Bean(name="approveNFAService")
		public ApproveNFAService getApproveNFAService() {
			return new ApproveNFAServiceImpl();
		}
	
	
	 @Bean(name="bulkUploadDAO")
		public BulkUploadDAO getBulkUploadDAO() {
			return new BulkUploadDAOImpl(getDataSource());
		}
	 
	 @Bean(name="bulkUploadService")
		public BulkUploadService getBulkUploadService() {
			return new BulkUploadServiceImpl();
		}
	 
	 @Bean(name="csvDAO")
		public CSVDAO getCSVDAO() {
			return new CSVDAOImpl(getDataSource());
		}
	 
	 @Bean(name="csvService")
		public CSVService getCSVService() {
			return new CSVServiceImpl();
		}

	
	@Bean(name="dsmPoDao")
	public DsmPoDAO getDsmPoDao() {
		return new DsmPoDAOImpl(getDataSource());
	}
	
	@Bean(name="dsmPoService")
	public DsmPoService getDsmPoService() {
		return new DsmPoServiceImpl();
	}
	
	
	@Bean(name="postExecDAO")
	public PostExecDAO getPostExecDAO() {
		return new PostExecDAOImpl(getDataSource());
	}
	
	@Bean(name="postExecService")
	public PostExecService getPostExecService() {
		return new PostExecServiceImpl();
	}
	
	@Bean(name="schemeEditDAO")
	public SchemeSearchDAO getSchemeEditDAO() {
		return new SchemeSearchDAOImpl(getDataSource());
	}
	
	@Bean(name="schemeSearchService")
	public SchemeSearch getSchemeSearchService() {
		return new SchemeSearchImpl();
	}
	
	 @Bean(name="converagedao")
	public ConverageInputDAO getConverageInputDAO() {
		return new ConverageInputDAOImpl(getDataSource());
	}
	 
	 @Bean(name="schemInputEaDAO")
		public SchemeInputEaDAO getSchemeInputEaDAO() {
			return new SchemeInputEaImpl(getDataSource());
		}
	 
	 @Bean(name="schemeInputDao")
		public SchemeInputTqDAO getSchemeInputTqDAO() {
			return new SchemeInputTqDAOImpl(getDataSource());
		}
	
	 @Bean(name="converageService")
	public ConverageInputService getConverageInputService() {
		return new ConverageServiceImpl();
	}
	 
	 @Bean(name="schemeInputService")
		public SchemeInputTQService getSchemeInputTQService() {
			return new SchemeInputTQServiceImpl();
		}
	 
	 @Bean(name="schemeInputServiceEa")
		public SchemeInputEAService getSchemeInputEAService() {
			return new SchemeInputEQServiceImpl();
		}
	
	 
	 @Bean(name="schemeInputAllDAO")
		public SchemeInputAllDAO getSchemeInputAllDAO() {
			return new SchemeInputAllDAOImpl(getDataSource());
		}
	 
	 @Bean(name="saveDataService")
		public SaveDataService getSaveDataService() {
			return new SaveDataServiceImpl();
		}
	
	 
	 //DUMP Generation
	 
	 @Bean
	   public ViewResolver contentNegotiatingViewResolver(ContentNegotiationManager manager) {
	       ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
	       resolver.setContentNegotiationManager(manager);
	       System.out.println("*****************************************MvcConfiguration:: contentNegotiatingViewResolver ***************************");
	       PdfViewResolver pdf  = new PdfViewResolver();
	       // Define all possible view resolvers
	       List<ViewResolver> resolvers = new ArrayList<ViewResolver>();

	       InternalResourceViewResolver resolver2 = new InternalResourceViewResolver();
			// resolver.setPrefix("/index");
			resolver2.setOrder(2);
			resolver2.setSuffix(".jsp");
	
			// return resolver;
	        // resolvers.add(jaxb2MarshallingXmlViewResolver());
	        // resolvers.add(jsonViewResolver());
			// resolvers.add(resolver2);
	       resolvers.add(pdf);
	       
	       // resolvers.add(excelViewResolver());
	       // resolver.setOrder(2);
	       resolver.setViewResolvers(resolvers);
	       resolver.setOrder(0);
	      // ViewResolver pdf2  = resolvers.get(1);
	       
	       return resolver;
	   }

	 @Bean
	   public ViewResolver pdfViewResolver() {
		 return new PdfViewResolver();
	   }
	
	 @Bean(name="reportGenerateDAO")
		public ReportGenerateDAO getReportGenerateDAO() {
			return new ReportGenerateDAOImpl(getDataSource());
		}
	 
	 @Bean(name="reportGenerateService")
		public ReportGenerateService getReportGenerateService() {
			return new ReportGenerateServiceImpl();
		}

	 
}

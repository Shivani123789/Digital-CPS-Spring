package dsm.module.constant;

public interface SchedularConstants {

	public static final String ERROR = "ERROR";
	public static final String SMS_URL = "SMS_URL";
	public static final String SMS_USER_NAME = "SMS_USER_NAME";
	public static final String SMS_PASSWORD = "SMS_PASSWORD";
	public static final String SMS_CONTENT_TYPE = "&CONTENT_TYPE=Text&TYPE=0";
	public static final String SMS_REMARKS = "UNABLE TO SEND SMS. MOBILE NUMBER IS UNAVAILABLE.";
	public static final String EMAIL_SENDER = "EMAIL_SENDER";
	public static final String EMAIL_HOST = "EMAIL_HOST";
	public static final String EMAIL_PORT = "EMAIL_PORT";
	public static final String OK = "OK";
	public static final String TRUE = "true";
	public static final String FALSE = "false";
	public static final String COMMA = ",";
	public static final String PORT = "25";
	public static final String EMAIL_REMARKS = "UNABLE TO SEND EMAIL. RECIPIENTS OR EMAIL_ID IS UNAVAILABLE.";
	public static final String BLANK = "";
	public static final String PDF_EXT = ".pdf";
	public static final String BACK_SLASH = "/";
	public static final String ZIP_EXT = ".zip";
	public static final String YES = "Y";
	public static final String NO = "N";
	
}


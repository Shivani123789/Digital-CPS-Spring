package dsm.module.constant;

public interface BulkConstants {
	
	public static final String FILE_DATE_PARSE_ERROR = "Please check file date of csv. Date format should be ddmmyyyy.";
	
	public static final String LEFT_BRACKET = "(";
	
	public static final String RIGHT_BRACKET = ")";
	
	public static final String WRONG_FILE_ERROR = "Wrong file uploaded. Please check file extension. It must be xls/xlsx/csv";
	
	public static final String WRONG_FILE_NAMING_CONVENTION = "The file name does not adhere to correct naming convention." +
			"<br> Please refer 'Template' menu from the navigation panel to get the naming convention.";
	
	//public static final String FILE_HEADER_ERROR = "Header name mismatch for one/more mandatory and/or non-mandatory columns. " +
		//	"<br> You may refer the correct header name from the .csv file <br>(downloadable from 'Template' menu)";
	
	public static final String FILE_HEADER_ERROR = "Header name mismatch for one/more mandatory and/or non-mandatory columns. " +
			"<br>Incorrect headers :  ";
	
	public static final String COMMA = ",";
	
	public static final String UNDERSCORE = "_";
	
	public static final String SLASH_DOT = "\\.";
	
	public static final String DDMMYYYY = "ddMMyyyy";
	
	public static final String MAIL_LIST = "EMAIL_LIST";
	
	public static final String  EMAIL = "EMAIL";
	
	public static final String  EMAIL_FILE_NAME = "MAIL_FILE_NAME";

	public static final String DD_MMM_YYYY = "dd-MMM-yyyy";
	
	public static final String DD_MMM_YYYY_AM_PM = "dd-MMM-yyyy h:mm:ss a";
	
	public static final String DD_MMM_YYYY_24 = "dd-MMM-yyyy HH:mm:ss";
	
	public static final String  DOT = ".";
	
	public static final String  CSV= "csv";
	
	public static final String  D = "D";
	
	public static final String  DLP_ENTITY_ADD_ATTR_STAMP = "DLP_ENTITY_ADD_ATTR_STAMP";
	
	public static final String DLP_PP_CONFIGURATION = "DLP_PP_CONFIGURATION"; 
	
	public static final String DLP_MANUAL_PAYOUT = "DLP_MANUAL_PAYOUT";
	
	public static final String  SINGLE_QUOTE = "'";

	public static final String  SINGLE_QUOTE_COMMA = "',";
	
	public static final String QUESTION_MARK = "?";
	
	public static final String QUESTION_MARK_COMMA = "?,";
	
	public static final String SCHEME_BULK_LOAD_CONF_TEMP_ERROR = "Please contact Ops. Unable to fetch data from scheme bulk tables";
	
	public static final String  BLANK = "";
	
	public static final String  FILE_READER_ERROR = "Unable to read file. Please check the uploaded file.";
	
	public static final String  DATE = "DATE";
	
	public static final String  DATA_DATE_ERROR = "Given date field format is wrong. " +
			"<br> The allowed format is DD-MMM-YYYY.<br>"+
			"Row No. is ";
	
	public static final String  DATE_ERROR = "Given date field format is wrong in the file name. " +
			"<br> Please refer 'Template' menu from the navigation panel to get the naming convention.<br>"+
			"You given date format in file name is ";
	
	public static final String  DESTINATION_TABLE_ERROR = "Unable to insert data in table";
	
	public static final String  NULL_ERROR = "Unable to insert data in table. One of the field is empty or mandatory. <br> Record no. is: ";
	
	public static final String  DATA_ERROR = "Unable to insert data in table. ";
	
	public static final String  MONTH_ERROR = "Given 'month acronym' format is wrong in the file name. <br> Please refer 'Template' menu from the navigation panel to get the naming convention.<br>" ;
	
	public static final String  DATA_HEADER_MISMATCH_ERROR = "EITHER <BR> 'Header name mismatch for one/more mandatory and/or non-mandatory columns'. </BR>" +
			"<br> AND/OR <br>'No data is present in the file'. Row No. is ";
	
	public static final String FILE_EXTENSION_ERROR = "Please upload proper csv file.<br> More than one file extension is not allowed.<br>" +
			"You have uploaded a file with incorrect extensions (:PDFX)*.";
	
	public static final String  CSV_FILE_EXTENSION_ERROR = "You have uploaded a file with incorrect extension (.:PDFX)*. <br> Allowed extension for this file type is .csv";
	
	//public static final String CLOSE_CONNECTION = "Please try after sometime. Database is down or Contact Database admin.";
	public static final String CLOSE_CONNECTION = "Database is down. Please try after sometime OR Contact Database admin.";
	
	public static final String UPDATE_ERROR = "Unable to update data.";
	
	public static final String NULL_UPDATE_ERROR  = "Header name mismatch for one/more mandatory and/or non-mandatory columns. <br> " +
			"You may refer the correct header name from the .csv file <br> (downloadable from 'Template' menu)";
	
	public static final String TABLE_ERROR = "Dynamically generated table name is incorrect.";
	
	public static final String COLUMN_ERROR = "Column name is incorrect.";
	
	public static final String NETWORK_ERROR = "Unable to connect to DB. Please try after some time.";
	
	public static final String NO_HEADER_ERROR = "No Headers are found.";
	
    public static final String  NO_DATA_FOUND = "You have uploaded a file with - No data OR Empty record OR Empty file. ";
	
    public static final String  UNABLE_ERROR = "Unable to upload a file. Please try after some time. ";
    
    //public static final String  NO_DATA_FOUND_MIDDLE = "In middle of the file no empty line or empty row is not allowed. <br> The missing Row No. is  ";
    public static final String  NO_DATA_FOUND_MIDDLE = "You have uploaded a file with an empty record in between. <br>Please check missing record no.: ";
	
    public static final String  NO_DATA_HEADER_ERROR = " EITHER  <br> 'Header name mismatch for one/more mandatory and/or non-mandatory columns'. <br> AND/OR <br>" +
    		"'No data is present in the file'.";
	
	//public static final String  NO_DATA_FIRST_ROW = "No data found or empty record or first row is empty or empty file uploaded. ";
	public static final String  NO_DATA_FIRST_ROW = "You have uploaded a file with - No data OR No records OR First record is empty";
	
	public static final String MANDATORY_DATA_REQUIRED = "There exists atleast one mandatory column with no data. <br>Please ensure that no record against mandatory column is left blank." +
			" <br>Please check record no.: ";
	
	//public static final String MANDATORY_FILE_REQUIRED = "There is no file name exits or matches with the given file name;." +
	//		" <br>Row No. is ";
	public static final String MANDATORY_FILE_REQUIRED = "'MAIL_FILE_NAME' given in the file is either not uploaded or there exist a name mismatch with the already uploaded file." +
			" <br>Please check record no: ";
	
	public static final String MANDATORY_DSM2_REF_CODE_REQUIRED = "The DSM2-REF-CODE is not valid." +
			" <br>Please check record no: ";
	
	public static final String MANDATORY_COLUMN_REQUIRED = "All the mandatory header names are not present in the file. <br> Missing mandatory headers:  ";
	
	//public static final String ATLEAT_ONE_MANDATORY_DATA = "Atleast one of the mandatory data is required in the file." +
	//		"<br> Among these DSM2_REF_CODE, VTOPUP_NUMBER, FTA_NUMBER columns data required. <br> Row No. is ";
	//public static final String ATLEAT_ONE_MANDATORY_DATA = "Data in atleast one of the following mandatory columns is required.<br>"+
	//		" Mandatory columns are - DSM2_REF_CODE, VTOPUP_NUMBER, FTA_NUMBER. <br> Row No. is ";
	
	public static final String ENTITY_LIST_SUCCESS  = "All the records for each 'Entity-List' are inserted successfully. :";
	
	public static final String PDFX = ":PDFX";
	
	public static final String MONTHS = "JAN,FEB,MAR,APR,MAY,JUN,JUL,AUG,SEP,OCT,NOV,DEC";
	
	public static final String ADD_ATTR =  "ADD_ATTR";
	
	public static final String SCM_CONFIG = "SCM_CONFIG";
	
	public static final String ADD_ACT_UNI = "ADD_ACT_UNI";
	
	public static final String ADD_DIST_UNI = "ADD_DIST_UNI";
	
	public static final String ADD_RET_UNI = "ADD_RET_UNI";
	
	public static final String ADD_DSE_UNI = "ADD_DSE_UNI";
	
	public static final String ENTITY_LIST = "ENTITY-LIST";
	
	public static final String MANUAL_PAYOUT = "MANUAL-PAYOUT";
	
	public static final String COMMON_CATCH_ERROR = "Please contact Ops team. Unable to upload file due to internal error.";
	
	public static final String DESTINATION_COLUMN_ERROR = "Header names are not matched with table columns. <br>The un-matched header is: ";
	
	public static final String PARTITION_ERROR = "Date in the file name does not map to any partition in the destination table.";
	
	public static final String SUCCESS = "The 'Mail List' is successfully configured";
}

package dsm.module.constant;

public interface DsmConstants {
	
	public static final String GET_DENO_SET = "GetDenoSet";
	public static final String SAVE_CIRCLE_SCHEDULER = "SaveCircleSchedular";
	public static final String DOWNLOAD_SCHEME_EXE_PAYOUT = "DownloadSchemeExePayout";
	
	public static final String TRANS_DATA_LAST_EXTRACT_MSG = "Next 'Data Extraction' can happen after 15 minutes of previous 'Extraction'." ;

	public static final String TRANS_DATA_LAST_EXECUTE_MSG = "Next 'Data Execution' can happen after 2 minutes of previous 'Execution'. " ;
	
	
}

package dsm.module.activitylog;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Appender;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.RollingFileAppender;

public class LogFactory {

	/** The logfactory. */
	private static LogFactory logfactory = new LogFactory();

	/**
	 * private constructor to log the log4j properties file.
	 */
	private LogFactory() {

		Properties prop = new Properties();
		try {
			ClassLoader cl = LogFactory.class.getClassLoader();
			InputStream resourceInputStream = cl
					.getResourceAsStream("log4j_Activity.properties");
			prop.load(resourceInputStream);

		} catch (IOException e) {
			e.printStackTrace();
		}
		PropertyConfigurator.configure(prop);

	}

	/** The loggermap. */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map<String, Logger> loggermap = new HashMap();

	/**
	 * This will retrieve the logger based on logging type (appender name).
	 * 
	 * @param appender
	 *            the appender
	 * 
	 * @return the logger
	 */
	@SuppressWarnings("unchecked")
	public Logger getLogger(String appender) {
		// begin-user-code
		Logger logger = loggermap.get(appender);
		if (logger == null) {
			logger = Logger.getLogger(appender);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			String dateStr = sdf.format(new Date());
			Enumeration<Appender> enumeration = logger.getAllAppenders();
			//String channel = appender.substring(0, appender.lastIndexOf("_"));
			String fileName = appender.substring(appender.lastIndexOf("_")+1);
			//// System.out.println("----------------filename :"+fileName);
			while (enumeration.hasMoreElements()) {
				RollingFileAppender app = ((RollingFileAppender) enumeration
						.nextElement());
			
				StringBuffer sb= new StringBuffer(app.getFile());
				int index = sb.indexOf("date");
				String path = sb.substring(0,index);
				//app.setFile("/home/logs/"+channel+"/" + dateStr + "/" + fileName+".log");
				// new Log location /tmp/portal/logs
				//String lPath = "/wps/wpsadmin/IBM/WebSphere/wp_profile/logs/WebSphere_Portal";
				app.setFile(path + dateStr + "/" + fileName+".log");
				app.activateOptions();
			}
		  loggermap.put(appender, logger);
		}

		return logger;
		// end-user-code
	}

	/**
	 * Static method to load the factory.
	 * 
	 * @return the log factory
	 */
	public static LogFactory getLogFactory() {
		return logfactory;
	}
}


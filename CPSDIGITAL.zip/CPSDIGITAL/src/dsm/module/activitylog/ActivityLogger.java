package dsm.module.activitylog;

import java.util.HashMap;
import java.util.Map;
import org.apache.log4j.lf5.LogLevel;

public class ActivityLogger {


    /**
     * Instantiates a new LMS logger.
     * 
     * @param inputCategory
     *            the input category
     */
    protected ActivityLogger(String inputCategory)
    {
        this.category = inputCategory;
    }

    /** The category. */
    protected String category;

    /** The Constant categorymap. */
    protected static final Map<String, ActivityLogger> categorymap = new HashMap<String, ActivityLogger>();

    /**
     * Checks if is debug.
     * 
     * @return true, if is debug
     */
    public boolean isDebug()
    {
        if (LogFactory.getLogFactory().getLogger(this.getCategory()).isDebugEnabled())
        {
            return true;
        }
        return false;
    }

    /**
     * Checks if is info.
     * 
     * @return true, if is info
     */
    public boolean isInfo()
    {
        if (LogFactory.getLogFactory().getLogger(this.getCategory()).isInfoEnabled())
        {
            return true;
        }
        return false;
    }

    public static ActivityLogger getInstance(String inputCategory)
    {        
        if (categorymap.containsKey(inputCategory.trim()))
        {
            return categorymap.get(inputCategory.trim());
        }
        // if category is not null then, the category is inserted into the map
        // the dreaded sync block for storing in the map
        synchronized (inputCategory)
        {
            // this check has to be done just to make sure that there are no
            // duplicate entries in the map..
            if (!categorymap.containsKey(inputCategory))
            {
            	ActivityLogger logger = new ActivityLogger(inputCategory.trim());
                categorymap.put(inputCategory.trim(), logger);
            }
        }

        return categorymap.get(inputCategory.trim());
    }
 
    /**
     * This method is used to log  system out and system error in log file.
     * 
     * @param logLevel
     *            the log level
     * @param exception
     *            the exception
     * @param message
     *            the message
     * @param methodName
     *            the method name
     * @param className
     *            the class name
     */
/*    public void log(LogLevel logLevel, Throwable exception, String message, String methodName, String className)
    {
        if (logLevel.equals(LogLevel.DEBUG))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_ipopsactivity")
                .debug(message + " " + methodName + " " + className);
        	}
        	else
        	{        		
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").debug(
                    message + " " + methodName + " " + className, exception);
        	}
        }
        else if (logLevel.equals(LogLevel.ERROR))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_ipopsactivity")
                .error(message + " " + methodName + " " + className);
        	}
        	else {
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").error(
                    message + " " + methodName + " " + className, exception);
        	}
        }
        else if (logLevel.equals(LogLevel.FATAL))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_ipopsactivity")
                .fatal(message + " " + methodName + " " + className);
        	}
        	else {
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").fatal(
                    message + " " + methodName + " " + className, exception);
        	}
        }
        else if (logLevel.equals(LogLevel.INFO))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_ipopsactivity")
                .info(message + " " + methodName + " " + className);
        	}
        	else {
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").info(message + " " + methodName + " " + className,
                    exception);
        	}
        }
        else if (logLevel.equals(LogLevel.WARN))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_ipopsactivity")
                .warn(message + " " + methodName + " " + className);
        	}
        	else {
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").warn(message + " " + methodName + " " + className,
                    exception);
        	}
        }

    }
*/

    public void log(LogLevel logLevel, Throwable exception, String message)
    {
        if (logLevel.equals(LogLevel.DEBUG))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_DSM2activity")
                .debug(message);
        	}
        	else
        	{        		
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").debug(
                    message);
        	}
        }
        else if (logLevel.equals(LogLevel.ERROR))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_DSM2activity")
                .error(message );
        	}
        	else {
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").error(
                    message );
        	}
        }
        else if (logLevel.equals(LogLevel.FATAL))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_DSM2activity")
                .fatal(message);
        	}
        	else {
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").fatal(
                    message);
        	}
        }
        else if (logLevel.equals(LogLevel.INFO))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_DSM2activity")
                .info(message);
        	}
        	else {
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").info(message );
        	}
        }
        else if (logLevel.equals(LogLevel.WARN))
        {
        	if(exception == null) {
        		LogFactory.getLogFactory().getLogger(this.getCategory()+"_DSM2activity")
                .warn(message );
        	}
        	else {
            LogFactory.getLogFactory().getLogger(this.getCategory()+"_SystemError").warn(message);
        	}
        }

    }

    
    /**
     * Gets the category.
     * 
     * @return the category
     */
    public String getCategory()
    {
        return category;
    }

    /*
     * When writing a class using the Singleton pattern, only 1 instance of that class can exist at a time. As a result,
     * the class must not be allowed to make a clone. To prevent this, override the clone().
     */
    /*
     * (non-Javadoc)
     * 
     * @see java.lang.Object#clone()
     */
    @Override
    public Object clone() throws CloneNotSupportedException
    {
        throw new CloneNotSupportedException();
    }
   
}

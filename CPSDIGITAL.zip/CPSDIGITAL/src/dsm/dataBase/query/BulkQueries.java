package dsm.dataBase.query;

public interface BulkQueries {
	
	
	public static final String  SCHEME_BULK_LOAD_CONF_TEMP = "SELECT CONF_NAME, SHEET_NAME, SHEET_NUM, PROCEDURE_NAME, COL_READ_COUNT, FILE_ID, HEADER_ROWS, LOADING_METHOD, MAPPING_TABLE," +
			" MAPPING_TABLE_CONNECTION_POOL, MAPPING_FIELD_HEADER_NAME, MAPPING_FIELD_NAME, DESTINATION_TABLE_NAME, type, FEED_NUMBER, FEED_MAPPING" +
			" FROM SCHEME_BULK_LOAD_CONF_TEMP WHERE FILE_ID=? ORDER BY FILE_ID ASC ";
	
	/*public static final String  SCHEME_BULK_LOAD_CONF_TEMP = "SELECT CONF_NAME, SHEET_NAME, SHEET_NUM, PROCEDURE_NAME, COL_READ_COUNT, FILE_ID, HEADER_ROWS, LOADING_METHOD, MAPPING_TABLE," +
			" MAPPING_TABLE_CONNECTION_POOL, MAPPING_FIELD_HEADER_NAME, MAPPING_FIELD_NAME, DESTINATION_TABLE_NAME, type, FEED_NUMBER, FEED_MAPPING" +
			" FROM SCHEME_BULK_UPLOAD_CONFIG WHERE FILE_ID=? ORDER BY FILE_ID ASC ";
	*/
	
	public static final String SCHEME_BULK_COLUMN_TEMP = "SELECT SHEET_NUM, CELL_NAME, CELL_NUM, CELL_TYPE, DB_DATA_TYPE, FILE_ID, DB_COLUMN_NAME" +
			" FROM SCHEME_BULK_COLUMN_TEMP WHERE SHEET_NUM = ? AND FILE_ID = ? ORDER BY  CELL_NUM ASC";

	public static final String query = "SELECT A.FIELD_NAME FIELD_NAME,A.DISPLAY_NAME DISPLAY_NAME, COUNT(*) OVER(PARTITION BY 1) CNT FROM DLP_TBL_ADD_FIELDS_CONFIG A WHERE DISPLAY_NAME IN(:param) AND TYPE=?";
	
	public static final String SELECT_SCHEME_BULK_LOAD_FILE_STATUS = "SELECT RELOAD_ATTEMPTS FROM SCHEME_BULK_LOAD_FILE_STATUS WHERE FILE_NAME=?";

	
	//public static final String INSERT_SCHEME_BULK_LOAD_FILE_STATUS = "INSERT INTO SCHEME_BULK_LOAD_FILE_STATUS VALUES (?, ?, SYSDATE, ?, ?, ?)";
	public static final String INSERT_SCHEME_BULK_LOAD_FILE_STATUS = "INSERT INTO SCHEME_BULK_LOAD_FILE_STATUS (USER_NAME, FILE_NAME, LOAD_DATE_TIME, FILE_STATUS, ERROR_DESC, RELOAD_ATTEMPTS, UNIQUE_FILE_NAME, CIRCLE_CODE) VALUES" +
																	  " (?, ?, SYSDATE, ?, ?, ?, ?, ?)";
	
	public static final String UPDATE_SCHEME_BULK_LOAD_FILE_STATUS = "UPDATE SCHEME_BULK_LOAD_FILE_STATUS SET USER_NAME =?, LOAD_DATE_TIME = SYSDATE, ERROR_DESC = ?, RELOAD_ATTEMPTS = ?  WHERE FILE_NAME = ?";
	
	public static final String DLP_SCHEME_COMP_MAPPING = "SELECT FILE_NAME FROM DLP_SCHEME_COMP_MAPPING WHERE  FILE_NAME=? AND SCHEME_ID=? AND COMPONENT_ID=? AND VALIDITY_FLAG='Y'";
	
	public static final String MANDATORY_DLP_TBL_ADD_FIELDS_CONFIG = "SELECT A.FIELD_NAME FIELD_NAME, A.DISPLAY_NAME DISPLAY_NAME, A.MANDATORY_TYPE, COUNT(*) OVER(PARTITION BY 1) CNT FROM DLP_TBL_ADD_FIELDS_CONFIG A WHERE A.TYPE=? AND A.MANDATORY_TYPE='Y' ";

	public static final String ADDI_MANDATORY_DLP_TBL_ADD_FIELDS_CONFIG = "SELECT A.FIELD_NAME FIELD_NAME, A.DISPLAY_NAME DISPLAY_NAME, A.MANDATORY_TYPE, COUNT(*) OVER(PARTITION BY 1) CNT FROM DLP_TBL_ADD_FIELDS_CONFIG A WHERE A.TYPE=? AND A.CIRCLE_ID = ? AND A.MANDATORY_TYPE='Y' ";

	public static final String DESTINATION_TABLE_COLUMNS = "";
	
	public static final String DOC_FILE = "SELECT FILE_EXTENSION, FILE_NAME_SIZE, FILE_SIZE FROM DLP_DOC_UPLOAD_FILE_VAL_MASTER WHERE upper(FILE_EXTENSION)  = upper(?)";
	
	public static final String DOC_FILE_INSERT = "INSERT INTO DLP_DOC_UPLOAD_FILE_DET (FILE_NAME,PATH,USER_ID,CIRCLE) VALUES(?,?,?,?)";
	
	public static final String DOC_FILE_DROPDOWN = "SELECT LISTTYPE, TYPE_ID FROM DLP_DOC_TYPE_LIST_MASTER";
	
	public static final String SCHEME_BULK_LOAD_FILE_STATUS = "SELECT USER_NAME, FILE_NAME, max(LOAD_DATE_TIME) LOAD_DATE_TIME, FILE_STATUS, ERROR_DESC, RELOAD_ATTEMPTS, UNIQUE_FILE_NAME, CIRCLE_CODE FROM scheme_bulk_load_file_status " +
			"where trunc(load_date_time) between ? and ? and file_name like  ? and circle_code = ? group by file_name,USER_NAME,FILE_STATUS, ERROR_DESC, RELOAD_ATTEMPTS, UNIQUE_FILE_NAME, CIRCLE_CODE";
	
	//public static final String SCHEME_BULK_LOAD_FILE_STATUS_PERF = "SELECT USER_NAME, FILE_NAME, max(LOAD_DATE_TIME) LOAD_DATE_TIME, FILE_STATUS, ERROR_DESC, RELOAD_ATTEMPTS, UNIQUE_FILE_NAME, CIRCLE_CODE FROM scheme_bulk_load_file_status " +
	//		"where trunc(load_date_time) between ? and ? and (file_name like  ? or file_name like  ? or file_name like  ? or file_name like  ?) and circle_code = ? group by file_name,USER_NAME,FILE_STATUS, ERROR_DESC, RELOAD_ATTEMPTS, UNIQUE_FILE_NAME, CIRCLE_CODE";

	public static final String SCHEME_BULK_LOAD_FILE_STATUS_PERF = "Select User_Name, File_Name, Load_Date_Time, File_Status, Error_Desc, Reload_Attempts,"+
	" Unique_File_Name, Circle_Code From Scheme_Bulk_Load_File_Status Where "+
	" Trunc(Load_Date_Time) Between :startDate And :endDate  and circle_code =  :circleCode "+ 
	" Order By Load_Date_Time Desc";
	
	/*public static final String SCHEME_BULK_LOAD_FILE_STATUS_PERF = " select * from (Select User_Name, File_Name, Load_Date_Time, File_Status, Error_Desc, Reload_Attempts,"+
			" Unique_File_Name, Circle_Code From Scheme_Bulk_Load_File_Status Where "+
			" Trunc(Load_Date_Time) Between :startDate And :endDate  And (File_Name Like  '%ADD_ACT_UNI%')   and circle_code =  :circleCode "+ 
			" Order By Load_Date_Time Desc) Where Rownum<2 "+ 
			" Union "+
			" select * from (Select User_Name, File_Name, Load_Date_Time, File_Status, Error_Desc, Reload_Attempts, "+
			" Unique_File_Name, Circle_Code From Scheme_Bulk_Load_File_Status Where  "+
			" Trunc(Load_Date_Time) Between :startDate And :endDate  And (File_Name Like  '%ADD_DSE_UNI%')   and circle_code =  :circleCode "+ 
			" Order By Load_Date_Time Desc) Where Rownum<2 "+
			" union  "+
			" select * from (Select User_Name, File_Name, Load_Date_Time, File_Status, Error_Desc, Reload_Attempts, "+
			" Unique_File_Name, Circle_Code From Scheme_Bulk_Load_File_Status Where  "+
			" Trunc(Load_Date_Time) Between  :startDate And :endDate   And (File_Name Like  '%ADD_RET_UNI%')   and circle_code =  :circleCode "+ 
			" Order By Load_Date_Time Desc) Where Rownum<2 "+
			" union  "+
			" select * from (Select User_Name, File_Name, Load_Date_Time, File_Status, Error_Desc, Reload_Attempts, "+
			" Unique_File_Name, Circle_Code From Scheme_Bulk_Load_File_Status Where  "+
			" Trunc(Load_Date_Time) Between  :startDate And :endDate   And (File_Name Like  '%ADD_DIST_UNI%')   and circle_code =  :circleCode "+ 
			" Order By Load_Date_Time Desc) Where Rownum<2 "+
			" union  "+
			" select * from (Select User_Name, File_Name, Load_Date_Time, File_Status, Error_Desc, Reload_Attempts, "+
			" Unique_File_Name, Circle_Code From Scheme_Bulk_Load_File_Status Where  "+
			" Trunc(Load_Date_Time) Between  :startDate And :endDate   And (File_Name Like  '%_ADD_ATTR_%')   and circle_code =  :circleCode "+ 
			" Order By Load_Date_Time Desc) Where Rownum<2 "+
			" union  "+
			" select * from (Select User_Name, File_Name, Load_Date_Time, File_Status, Error_Desc, Reload_Attempts, "+
			" Unique_File_Name, Circle_Code From Scheme_Bulk_Load_File_Status Where  "+
			" Trunc(Load_Date_Time) Between  :startDate And :endDate   And (File_Name Like  '%_ENTITY-LIST_%')   and circle_code =  :circleCode "+ 
			" Order By Load_Date_Time Desc) Where Rownum<2 "+
			" union  "+
			" select * from (Select User_Name, File_Name, Load_Date_Time, File_Status, Error_Desc, Reload_Attempts, "+
			" Unique_File_Name, Circle_Code From Scheme_Bulk_Load_File_Status Where  "+
			" Trunc(Load_Date_Time) Between  :startDate And :endDate   And (File_Name Like  '%_MANUAL-PAYOUT_%')   and circle_code = :circleCode "+ 
			" Order By Load_Date_Time Desc) Where Rownum<2";
*/	
}





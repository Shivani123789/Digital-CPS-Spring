package dsm.dataBase.query;

public interface StmtGenQueries {

	public static final String EMAIL_CONFIG ="INSERT INTO DLP_STATEMENT_EMAIL (STMT_EID, DISTRIBUTOR_DSM2_ID, CIRCLE, DISTRIBUTOR_MOBILE_NUM, STATEMENT_DATE, " +
			" RECIPIENTS, EMAIL_SUBJECT, EMAIL_CONTENT, SENDER, ATTACHMENT_FLAG, SEND_STATUS, VALIDITY_FLAG, INSERT_DATE_TIME,STATEMENT_CYCLE_DATE)" +
			" VALUES(seq_stmt_eid.nextVal, ?, ?, ?, ?, ?, ?, ? , 'schemes@idea.adityabirla.com', 'Y', 'N', 'Y', sysdate, ?)";
	
	
	/*public static final String EMAIL_CONFIG1 ="merge into DLP_STATEMENT_EMAIL  D" +
			"   using (select count(*) RECORDS from DLP_STATEMENT_EMAIL where DISTRIBUTOR_DSM2_ID=? and STATEMENT_DATE=? and SEND_STATUS='N' and CIRCLE = ?) S" +
			"   on (S.RECORDS = 1)" +
			"   when matched then update set D.UPDATE_DATE_TIME = sysdate, D.ATTACHMENT_PATH='', D.RESPONSE_STATUS='', D.ERROR_DESC=''  where DISTRIBUTOR_DSM2_ID = ? and STATEMENT_DATE = ? and SEND_STATUS='N' and CIRCLE =?" +
			"   when not matched then insert (STMT_EID, DISTRIBUTOR_DSM2_ID, CIRCLE, DISTRIBUTOR_MOBILE_NUM, STATEMENT_DATE, " +
			"   RECIPIENTS, EMAIL_SUBJECT, EMAIL_CONTENT, SENDER, ATTACHMENT_FLAG, SEND_STATUS, VALIDITY_FLAG, INSERT_DATE_TIME,STATEMENT_CYCLE_DATE, STATEMENT_START_DATE, DISTRIBUTOR_NAME, DISTRIBUTOR_FIRST_NAME, DISTRIBUTOR_LAST_NAME)" +
			"   VALUES(seq_stmt_eid.nextVal, ?, ?, ?, ?, ?, ?, ? , 'schemes@idea.adityabirla.com', 'Y', 'N', 'Y', sysdate, ?, ?, ?, ?, ?)";
	*/
	public static final String EMAIL_CONFIG2 ="merge into DLP_CPS_STATEMENT_EMAIL  D" +
			"   using (select count(*) RECORDS from DLP_CPS_STATEMENT_EMAIL where SCM_LST_ID = ? and STATEMENT_DATE=? and SEND_STATUS='N' and CIRCLE = ?) S" +
			"   on (S.RECORDS = 1)" +
			"   when matched then update set D.UPDATE_DATE_TIME = sysdate, D.ATTACHMENT_PATH='', D.RESPONSE_STATUS='', D.ERROR_DESC=''  where SCM_LST_ID = ? and STATEMENT_DATE = ? and SEND_STATUS='N' and CIRCLE =?" +
			"   when not matched then insert (STMT_EID, SCM_LST_ID, CIRCLE, MOBILE_NUM, STATEMENT_DATE, " +
			"   RECIPIENTS, EMAIL_SUBJECT, EMAIL_CONTENT, SENDER, ATTACHMENT_FLAG, SEND_STATUS, VALIDITY_FLAG, INSERT_DATE_TIME,STATEMENT_CYCLE_DATE, STATEMENT_START_DATE, CP_NAME, BENEFICIARY_NAME, APPL_NAME)" +
			"   VALUES(seq_stmt_eid.nextVal, ?, ?, ?, ?, ?, ?, ? , 'schemes@idea.adityabirla.com', 'Y', 'N', 'Y', sysdate, ?, ?, ?, ?, ?)";
	
	public static final String CPS_EMAIL_CONFIG2 ="MERGE INTO DLP_CPS_STATEMENT_EMAIL A" +
			" USING (SELECT * FROM DLP_STMT_SUMMARY_CU WHERE SCM_LIST_ID = ? AND CIRCLE = ? AND CYCLE_END_DT = ? ) B" +
			" ON(A.SCM_LIST_ID = B.SCM_LIST_ID and A.SEND_STATUS='N' and A.CIRCLE = B.CIRCLE)" +
			" WHEN MATCHED THEN UPDATE SET A.UPDATE_DATE_TIME = sysdate, A.ATTACHMENT_PATH='', A.RESPONSE_STATUS='', A.ERROR_DESC='' " +
			" WHEN NOT MATCHED THEN INSERT(A.STMT_EID, A.SCM_LIST_ID, A.CIRCLE, A.MOBILE_NUM, A.STATEMENT_DATE, A.RECIPIENTS, A.EMAIL_SUBJECT," +
			" A.EMAIL_CONTENT, A.SENDER, A.ATTACHMENT_FLAG, A.SEND_STATUS, A.VALIDITY_FLAG, A.INSERT_DATE_TIME,A.STATEMENT_CYCLE_DATE," +
			" A.STATEMENT_START_DATE, A.CP_NAME, A.BENEFICIARY_NAME, A.APPL_NAME,A.CC_RECIPIENTS)" +
			" VALUES(seq_stmt_eid.nextVal, B.SCM_LIST_ID, B.CIRCLE, B.CP_MOBILE_NO, B.CYCLE_END_DT, B.CP_EMAIL, 'Statement for the period  ' || to_char(B.CYCLE_END_DT,'MON-YYYY')," +
			" 'Attached herewith is Invoice Data Statement for '||B.APPLICATION_NAME||'  for the period from '|| TO_CHAR(TRUNC(B.CYCLE_END_DT,'MM'),'DD-MON-YYYY') || '  to  ' || TO_CHAR(B.CYCLE_END_DT,'DD-MON-YYYY')  ," +
			" 'schemes@idea.adityabirla.com'," +
			" 'Y', 'N', 'Y', sysdate, B.STATEMENT_DATE, B.CYCLE_END_DT, B.CP_NAME, B.BENEFICIARY, B.APPLICATION_NAME,B.CP_CC_EMAIL)";
	
}

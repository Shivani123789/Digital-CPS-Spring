package dsm.common.utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;

import dsm.model.DB.PayoutEmailConfigVO;
import dsm.model.DB.PayoutSmsConfigVO;

public class PostSmsNEmailWrapper {

	String SMS_EMAIL_CONFIG ="SmsEmailConfig.properties";
	String path = new File(System.getProperty("SCHEME_STUDIO_CONFIG_PATH")+"SmsEmailConfig/",SMS_EMAIL_CONFIG).getPath();
	Properties props = null;
	
	public boolean sendSms(PayoutSmsConfigVO smsConfig) throws Exception{
		try {
			props = new Properties();
			InputStream input = new FileInputStream(path);
			props.load(input);
			if(smsConfig!=null){
				String msg	= props.getProperty("SMS_URL")+"?USERNAME="+props.getProperty("SMS_USER_NAME")+"&PASSWORD="+props.getProperty("SMS_PASSWORD")+
						"&MOBILENO="+smsConfig.getToNumber()+"&MESSAGE="+smsConfig.getSmsContent()+"&CONTENT_TYPE=Text&TYPE=0";
				System.out.println("SMS URL --->>>"+msg);
				URL smsUrl = new URL(msg);
				HostnameVerifier hostNameVerify = new HostnameVerifier(){
					@Override
					public boolean verify(String urlHostName, SSLSession sslSession) {
						if (urlHostName.equals(sslSession.getPeerHost()))
							System.out.println("Verified :: " + sslSession.getPeerHost() +" --->>>> "+urlHostName);
						else
							System.out.println("Warning: URL host ::'"+urlHostName+" is different to SSLSession host ---->>> "+sslSession.getPeerHost()+"'.");
						return true;
					}
				};
				HttpsURLConnection.setDefaultHostnameVerifier(hostNameVerify);
				HttpsURLConnection urlCon = (HttpsURLConnection) smsUrl.openConnection();
				System.out.println("SMS ResponseMsg :: "+urlCon.getResponseMessage());
				System.out.println("Sms openStream Data :::: ---->>>> ");
				String smsData = new String();
				BufferedReader br = new BufferedReader(new InputStreamReader(smsUrl.openStream()));
				while((smsData=br.readLine())!=null)
					System.out.print(smsData);
				br.close();

				urlCon.disconnect();
				return true;
			}
		}catch(IOException e){
			System.out.println("SMS IOException ::"+e);
		}catch (Exception e) {
			System.out.println("SMS Exception:: "+e);
		}
		return false;
	}
	
	
	public boolean sendMail(PayoutEmailConfigVO config) throws MessagingException
	{
		try{
			props = new Properties();
			InputStream input = new FileInputStream(path);
			props.load(input);
			props.put("mail.smtp.user", props.getProperty("EMAIL_SENDER"));
			props.put("mail.smtp.host", props.getProperty("EMAIL_HOST"));
			props.put("mail.smtp.port", props.getProperty("EMAIL_PORT"));
			props.put("mail.smtp.starttls.enable", "true");
			//props.put("mail.smtp.auth", "false");
			props.put("mail.smtp.socketFactory.port", "25");
			props.put("mail.smtp.socketFactory.fallback", "false");

			Session session = Session.getInstance(props, null); 		

			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(props.getProperty("EMAIL_SENDER")));
			if(config!=null && config.getRecipients()!=null ){
				msg.addRecipients(Message.RecipientType.TO, config.getRecipients());
				System.out.println(config.getRecipients());

				String recipients[] = config.getCcRecipients() != null ? config.getCcRecipients().split(",") : null;
				//Constructing CC Recipients
				if(recipients!=null){
					for(int i=0; i<recipients.length;i++)
					{
						msg.addRecipients(Message.RecipientType.CC, recipients[i].trim());		
					}
				}
				//Constructing Subject
				msg.setSubject(config.getEmailSubject());

				//Constructing Body
				msg.setText(config.getEmailContent());

				//Sending Mail
				Transport.send(msg);

				System.out.println("Email Sent To ------->>"+config.getRecipients());
				return true;
			}
		}catch(MessagingException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}
		return false;
	}
	
	
}

package dsm.common.utility;

import java.util.regex.Pattern;

import dsm.model.form.CircleSchedular;
import dsm.module.constant.DsmConstants;

public class FormValidateUtil {

	
	public String validateCircleScheduler(CircleSchedular circleScheduler, String type) throws Exception
	{
		String result = null;
		if(type.equalsIgnoreCase(DsmConstants.GET_DENO_SET)){
			
			if(circleScheduler.getDenoMonth()==null || "".equalsIgnoreCase(circleScheduler.getDenoMonth())){
				result="Month Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getYear()==null || "".equalsIgnoreCase(circleScheduler.getYear())){
				result=result+"Year Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getNegativeDay() == 0){
				result=result+"Negative Days Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getExeTillDate()==null){
				result=result+"Exe Till Date Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getDenoSet()==null  || "".equalsIgnoreCase(circleScheduler.getDenoSet())){
				result=result+"Deno Set Field is Mandatory.\n <br>";
			}else{
				/*var num = /^[0-9,]+$/;
				if(denoSet.match(num)){
					//result=result+"success";
				}else{
					result=result+'Please input Numeric Characters and , Only';
				}*/
			}
			
			return result;
		}
		
		if(type.equalsIgnoreCase(DsmConstants.SAVE_CIRCLE_SCHEDULER)){
			
			if(circleScheduler.getDelayTime()==0  ){
				result="Delay Time Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getTax()==0){
				result=result+"Tax Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getStartDay()==0){
				result=result+"Start Day Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getEndDay()==0){
				result=result+"End Day Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getStatementDay()==0){
				result=result+"Statement Day Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getSchemeSchedular()==0){
				result=result+"Scheme Scheduler Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getDistMagin()==0){
				result=result+"Distributor Margin Field is Mandatory.\n <br>";
			}
			return result;
		}
		
		if(type=="DownloadSchemeExePayout"){
			if(circleScheduler.getStartDate()==null ){
				result="From Date Field is Mandatory.\n <br>";
			}
			if(circleScheduler.getEndDate()==null){
				result=result+"To Date Field is Mandatory.\n <br>";
			}
			return result;
		}
		return result;
		
	}

	
	
	public String stripXSS(String value)  throws Exception{
		System.out.println("XSS Filter || stripXSS || BEG");    	
		        if (value != null) {
		            // NOTE: It's highly recommended to use the ESAPI library and uncomment the following line to
		            // avoid encoded attacks.
		            // value = ESAPI.encoder().canonicalize(value);

		            // Avoid null characters
		            value = value.replaceAll("", "");

		            // Avoid anything between script tags
		            Pattern scriptPattern = Pattern.compile("<script>(.*?)</script>", Pattern.CASE_INSENSITIVE);
		            value = scriptPattern.matcher(value).replaceAll("");

		            // Avoid anything in a src='...' type of expression
		            scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");

		            scriptPattern = Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");

		            // Remove any lonesome </script> tag
		            scriptPattern = Pattern.compile("</script>", Pattern.CASE_INSENSITIVE);
		            value = scriptPattern.matcher(value).replaceAll("");

		            // Remove any lonesome <script ...> tag
		            scriptPattern = Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");

		            // Avoid eval(...) expressions
		            scriptPattern = Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");

		            // Avoid expression(...) expressions
		            scriptPattern = Pattern.compile("expression\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");

		            // Avoid javascript:... expressions
		            scriptPattern = Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE);
		            value = scriptPattern.matcher(value).replaceAll("");

		            // Avoid vbscript:... expressions
		            scriptPattern = Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE);
		            value = scriptPattern.matcher(value).replaceAll("");

		            // Avoid onload= expressions
		            scriptPattern = Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");
		            
		            // Avoid onerror= expressions
		            scriptPattern = Pattern.compile("onerror(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");
		            if(value.equals("alertId")) {
		            	//Avoid xss as alerts will not work.
		            }else {
		            // Avoid alert expressions
		            scriptPattern = Pattern.compile("alert(.*?)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");
		            }
		            //Avoid <, >, img to completely block elements on page.
		            scriptPattern = Pattern.compile("<img", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");
		            
		            scriptPattern = Pattern.compile("src=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL);
		            value = scriptPattern.matcher(value).replaceAll("");
		            
		            value = value.replaceAll("<", "&lt;").replaceAll(">", "&gt;");
		        }
		        return value;
		    }

	
	
	
}

package dsm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dsm.dao.form.tq.SchemeInputTq;
import dsm.dao.form.tq.SchemeInputTqDAO;
import dsm.model.DB.TransDataCSV;
import dsm.model.DB.TransSubData;
import dsm.model.po.SchemePoMaster;



@Service
public class SchemeInputTQServiceImpl implements SchemeInputTQService {

	@Autowired
	SchemeInputTqDAO schemeInputDao = null;
	
	@Transactional
	public SchemeInputTq getSchemeInputTQDetails() {
		SchemeInputTq schemeInputTq = new  SchemeInputTq();
		schemeInputTq.setSchemeList(schemeInputDao.getComponenetList());
		schemeInputTq.setDataSetList(schemeInputDao.getDataSetList());
		schemeInputTq.setOprList(schemeInputDao.getOprList());
		schemeInputTq.setParamList(schemeInputDao.getParamList());
		schemeInputTq.setValueTypeList(schemeInputDao.getValueTypeList());
		schemeInputTq.setValueList(schemeInputDao.valueList());
		return schemeInputTq;
	}

	public TransDataCSV transDataNotQualify(TransSubData transdata) {
		return schemeInputDao.transDataNotQualify(transdata);
	}

	
	@Override
	public String copyCondition(SchemePoMaster po) throws Exception {
		return schemeInputDao.copyCondition(po);
	}
	
	
	
}

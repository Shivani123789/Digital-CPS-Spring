package dsm.service.master;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dsm.dao.master.MasterDAO;
import dsm.model.form.CircleMaster;
import dsm.model.form.ComponentMasterCombo;
import dsm.model.form.ParamCategory;
import dsm.model.form.PayToMaster;
import dsm.model.form.SchemaMaster;


@Service
public class MasterServiceImpl implements MasterService{

	@Autowired
	private MasterDAO adminDAO;
	
	public List<CircleMaster> getCircleMasterList() throws Exception{
		return  adminDAO.getCircleMasterList();
	}

	@Override
	public List<SchemaMaster> getSchemeMasterList(int circleId,String startDt, String endDt)	throws Exception {
		return adminDAO.getSchemeMasterList(circleId,startDt,endDt);
	}

	@Override
	public List<ComponentMasterCombo> getComponentMasterList(int schemeId) throws Exception {
		return adminDAO.getComponentMasterList(schemeId);
	}

	@Override
	public List<ParamCategory> getParamCatMasterList(int circleId)	throws Exception {
		return adminDAO.getParamCatMasterList(circleId);
	}
	
	@Override
	public List<PayToMaster> getPayToDetails()	throws Exception {
		return adminDAO.getPayToDetails();
	}
}

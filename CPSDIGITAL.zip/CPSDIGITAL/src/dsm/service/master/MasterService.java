package dsm.service.master;

import java.util.List;

import dsm.model.form.CircleMaster;
import dsm.model.form.ComponentMasterCombo;
import dsm.model.form.ParamCategory;
import dsm.model.form.PayToMaster;
import dsm.model.form.SchemaMaster;



public interface MasterService {

	public List<CircleMaster> getCircleMasterList() throws Exception;
	
	public List<SchemaMaster> getSchemeMasterList(int circleId,String startDt, String endDt) throws Exception;
	
	public List<ComponentMasterCombo> getComponentMasterList(int schemeId) throws Exception;
	
	public List<ParamCategory> getParamCatMasterList(int circleId) throws Exception;
	
	public List<PayToMaster> getPayToDetails() throws Exception;
}

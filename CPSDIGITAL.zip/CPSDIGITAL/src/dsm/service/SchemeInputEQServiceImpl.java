package dsm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dsm.dao.ea.SchemeInputEA;
import dsm.dao.ea.SchemeInputEaDAO;
import dsm.model.ea.DataSourceEQModel;
import dsm.model.ea.DayLvlAggr;



@Service
public class SchemeInputEQServiceImpl implements SchemeInputEAService {

	@Autowired
	SchemeInputEaDAO schemInputEaDAO = null;
	
	@Transactional
	public SchemeInputEA getSchemeInputEADetails() {
		SchemeInputEA schemeEA = new SchemeInputEA();
		schemeEA.setSchemeList(schemInputEaDAO.getSchemeList());
		schemeEA.setDataSetList(schemInputEaDAO.getDataSetList());
		schemeEA.setOprList(schemInputEaDAO.getOprList());
		schemeEA.setParameterList(schemInputEaDAO.getParameterList());
		schemeEA.setValueTypeList(schemInputEaDAO.getValueTypeList());
		schemeEA.setFunctionList(schemInputEaDAO.getFunctionList());
		return schemeEA;
	}

	@Override
	public List<DataSourceEQModel> getDataSourceList(String schemeName) {
		return schemInputEaDAO.getDataSourceList(schemeName);
	}

	
	public List<DayLvlAggr> getDayLvlAggrList(int circleId){
		return schemInputEaDAO.getDayLvlAggrList(circleId);
	}

	
}

package dsm.service.po;

import java.util.List;

import dsm.model.form.OprMaster;
import dsm.model.po.EaVariables;

public interface DsmPoService {

	
	List<OprMaster> getLopr();
	List<EaVariables> getEaVariables();

}

package dsm.service.po;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dsm.dao.po.DsmPoDAO;
import dsm.model.form.OprMaster;
import dsm.model.po.EaVariables;


@Service
public class DsmPoServiceImpl implements DsmPoService {

	@Autowired
	DsmPoDAO dsmPoDao = null;

	@Override
	public List<OprMaster> getLopr() {
		return dsmPoDao.getLopr();
	}

	@Override
	public List<EaVariables> getEaVariables() {
		return dsmPoDao.getEaVariables();
	}

		
}

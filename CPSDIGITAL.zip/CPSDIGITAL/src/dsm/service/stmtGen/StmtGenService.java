package dsm.service.stmtGen;

import java.util.List;

import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.PartnerChannelStatementPojo;
import dsm.model.DB.PaymentDetailVO;
import dsm.model.DB.RetailerStmtVO;
import dsm.model.DB.ServiceType;
import dsm.model.DB.StmtGenCycleMaster;
import dsm.model.DB.StmtReqMapping;
import dsm.model.StmGen.StmtCpBean;


public interface StmtGenService {

	public List<StmtGenCycleMaster> searchScheme(String circleCode, String serviceType) throws Exception;
	
	public List<PaymentDetailVO> searchStatementGenerate(String startDt,String endDt,int circleId, String circleCode,int stmtCycleId) throws Exception;
	
	public List<DistributorStatementPojo> searchViewStmtSearch(String endDt, String circleCode, String msisdn, String distId, int start, int limit)  throws Exception;
	
	public List<DistributorStatementPojo> fetchDistributorStmt(String distributorID, String stmtDt, String circle, String stmtCycleDt) throws Exception;
	
	public List<RetailerStmtVO> fetchRetailerStmt(String distDsmId, String stmtDt, String circle) throws Exception;
	
	public String stmtGenEmailConfig(String distDsmId, String startEndDtParam, String circle) throws Exception;
	
	public String selectedStmtGenEmailConfig(String distDsmId, String circle) throws Exception;
	
	public List<StmtReqMapping> searchReqStmtSearch(String endDt, String circleCode, int circleId, String stmtCycleId) throws Exception;
	
	public int deleteSchemeStatementMap(String scmcompId, String circleCode) throws Exception;
	
	public String saveSchemeStatementMap(String scmcompId, String circleCode, String userId,int stmtCycleId) throws Exception;
	
	public int insertSchemeStatementMap(String scmcompId, String circleCode,String userId) throws Exception;
	
	public List<StmtGenCycleMaster> searchStmtPeriod(String circleCode, String serviceType) throws Exception;
	
	public String reqForStmtGenerate(int stmtCycleId,String circleCode) throws Exception;
	
	public List<PartnerChannelStatementPojo> searchViewPartnerChannelStmtSearch(String endDt, String circleCode, String msisdn, String distId, int start, int limit, String stmtCycleId) throws Exception;
	
	public List<PartnerChannelStatementPojo> fetchChannelPartnerStmt(String distributorID, String stmtDt, String circle, String stmtCycleDt) throws Exception;
	
	public List<String> fetchChannelPartnerCircleList(String distributorID, String circle) throws Exception;
	
	public List<StmtCpBean> fetchCpStmt(String cpName, String stmtDt) throws Exception ;
	
	public List<ServiceType> getStmtServiceType() throws Exception ;
}

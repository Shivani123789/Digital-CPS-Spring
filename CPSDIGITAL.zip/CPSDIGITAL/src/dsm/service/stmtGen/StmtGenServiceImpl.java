package dsm.service.stmtGen;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dsm.dao.stmtGen.StmtGenDAO;
import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.PartnerChannelStatementPojo;
import dsm.model.DB.PaymentDetailVO;
import dsm.model.DB.RetailerStmtVO;
import dsm.model.DB.ServiceType;
import dsm.model.DB.StmtGenCycleMaster;
import dsm.model.DB.StmtReqMapping;
import dsm.model.StmGen.StmtCpBean;


@Service
public class StmtGenServiceImpl implements StmtGenService{

	@Autowired
	StmtGenDAO stmtgenDAO;

	@Override
	public List<StmtGenCycleMaster> searchScheme(String circleCode, String serviceType) throws Exception {
		return stmtgenDAO.searchScheme(circleCode, serviceType);
	}

	@Override
	public List<PaymentDetailVO> searchStatementGenerate(String startDt,String endDt, int circleId, String circleCode,int stmtCycleId)  throws Exception{
		return stmtgenDAO.searchStatementGenerate(startDt, endDt, circleId, circleCode,stmtCycleId);
	}

	@Override
	public List<DistributorStatementPojo> searchViewStmtSearch(String endDt, String circleCode, String msisdn, String distId, int start, int limit)  throws Exception{
		return stmtgenDAO.searchViewStmtSearch(endDt, circleCode, msisdn, distId, start,limit);
	}

	@Override
	public List<DistributorStatementPojo> fetchDistributorStmt(String distributorID, String stmtDt, String circle, String stmtCycleDt) throws Exception {
		return stmtgenDAO.fetchDistributorStmt(distributorID, stmtDt, circle, stmtCycleDt);
	}

	@Override
	public List<RetailerStmtVO> fetchRetailerStmt(String distDsmId, String stmtDt, String circle) throws Exception {
		return stmtgenDAO.fetchRetailerStmt(distDsmId, stmtDt, circle);
	}

	@Override
	public String stmtGenEmailConfig(String distDsmId, String startEndDtParam, String circle) throws Exception {
		return stmtgenDAO.stmtGenEmailConfig(distDsmId, startEndDtParam,  circle);
	}
	
	@Override
	public String selectedStmtGenEmailConfig(String distDsmId, String circle) throws Exception {
		return stmtgenDAO.selectedStmtGenEmailConfig(distDsmId, circle);
	}
	
	@Override
	public List<StmtReqMapping> searchReqStmtSearch(String endDt, String circleCode, int circleId, String stmtCycleId)  throws Exception{
		return stmtgenDAO.searchReqStmtSearch(endDt, circleCode, circleId, stmtCycleId);
	}

	@Override
	public int deleteSchemeStatementMap(String scmcompId, String circleCode)	throws Exception {
		return stmtgenDAO.deleteSchemeStatementMap(scmcompId, circleCode);
	}

	@Override
	public String saveSchemeStatementMap(String scmcompId, String circleCode, String userId,int stmtCycleId) throws Exception {
		return stmtgenDAO.saveSchemeStatementMap(scmcompId, circleCode,userId,stmtCycleId);
	}

	@Override
	public int insertSchemeStatementMap(String scmcompId, String circleCode,String userId) throws Exception {
		return stmtgenDAO.insertSchemeStatementMap(scmcompId, circleCode,userId);
	}

	@Override
	public List<StmtGenCycleMaster> searchStmtPeriod(String circleCode,String serviceType)  throws Exception{
		return stmtgenDAO.searchStmtPeriod(circleCode, serviceType);
	}

	@Override
	public String reqForStmtGenerate(int stmtCycleId, String circleCode)  throws Exception{
		return stmtgenDAO.reqForStmtGenerate(stmtCycleId, circleCode);
	}
	
	@Override
	public List<PartnerChannelStatementPojo> searchViewPartnerChannelStmtSearch(String endDt, String circleCode, String msisdn, String distId, int start, int limit, String stmtCycleId) {
		return stmtgenDAO.searchViewPartnerChannelStmtSearch(endDt, circleCode, msisdn, distId, start, limit, stmtCycleId);
	}

	@Override
	public List<PartnerChannelStatementPojo> fetchChannelPartnerStmt(String distributorID, String stmtDt, String circle, String stmtCycleDt) throws Exception {
		return stmtgenDAO.fetchChannelPartnerStmt(distributorID, stmtDt, circle, stmtCycleDt);
	}

	@Override
	public List<String> fetchChannelPartnerCircleList(String distributorID, String circle) {
		return stmtgenDAO.fetchChannelPartnerCircleList(distributorID,circle);
	}

	@Override
	public List<StmtCpBean> fetchCpStmt(String cpName, String stmtDt) throws Exception {
		return stmtgenDAO.fetchCpStmt(cpName, stmtDt);
	}

	@Override
	public List<ServiceType> getStmtServiceType() throws Exception {
		return stmtgenDAO.getStmtServiceType();
	}

}

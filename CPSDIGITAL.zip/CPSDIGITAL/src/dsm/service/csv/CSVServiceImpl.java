package dsm.service.csv;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dsm.dao.csv.CSVDAO;
import dsm.model.DB.CPSPaymentVO;
import dsm.model.DB.CSVModelInput;
import dsm.model.DB.DistributorVO;
import dsm.model.DB.ExecPayoutStatusVO;
import dsm.model.DB.HierarchyMismatchCsvVO;
import dsm.model.DB.PayoutVO;
import dsm.model.DB.RetailerVO;
import dsm.model.report.ReportCsvDownload;


@Service
public class CSVServiceImpl implements CSVService{

	@Autowired
	CSVDAO csvDAO;
	
	@Override
	public List<RetailerVO> retailerCsv(CSVModelInput csvdata) throws Exception{
		return csvDAO.retailerCsv(csvdata); 
	}
	
	@Override
	public List<PayoutVO> payoutCsv(CSVModelInput csvdata) throws Exception{
		return csvDAO.payoutCsv(csvdata);
	}
	
	@Override
	public List<DistributorVO> distributorCsv(CSVModelInput csvdata) throws Exception{
		return csvDAO.distributorCsv(csvdata);
	}
	
	@Override
	public List<PayoutVO> testValidPayoutCsv(CSVModelInput csvdata) throws Exception{
		return csvDAO.testValidPayoutCsv(csvdata);
	}
	
	public List<RetailerVO> payoutRetailerCsv(CSVModelInput csvdata) throws Exception{
		return csvDAO.payoutRetailerCsv(csvdata);
	}
	
	public List<DistributorVO> payoutDistributorCsv(CSVModelInput csvdata) throws Exception{
		return csvDAO.payoutDistributorCsv(csvdata);
	}

	@Override
	public List<ExecPayoutStatusVO> execPayoutStatusCsv(CSVModelInput csvdata)  throws Exception{
		return csvDAO.execPayoutStatusCsv(csvdata);
	}

	@Override
	public List<HierarchyMismatchCsvVO> hierarchyMismatchCsv(CSVModelInput csvdata)  throws Exception{
		return csvDAO.hierarchyMismatchCsv(csvdata);
	}
	
	@Override
	public List<ReportCsvDownload> reportValidPayoutCsv(String csvdata) throws Exception
	{
		return csvDAO.reportValidPayoutCsv(csvdata);
	}

	@Override
	public List<CPSPaymentVO> payoutCPSCsv(CSVModelInput csvdata) throws Exception {
		return csvDAO.payoutCPSCsv(csvdata);
		}
}

package dsm.service.approveNFA;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import dsm.dao.approveNFA.ApproveNFADAO;
import dsm.model.DB.PayoutEmailConfigVO;
import dsm.model.DB.PayoutSmsConfigVO;
import dsm.model.DB.RejectSchemeVO;
import dsm.model.DB.SchemeMaster;

public class ApproveNFAServiceImpl implements ApproveNFAService{

	@Autowired
	ApproveNFADAO approveNFADAO;
	
	public String approveScheme(SchemeMaster schemeMaster) throws Exception{
		return approveNFADAO.approveScheme(schemeMaster);
	}
	
	public String rejectScheme(SchemeMaster schemeMaster) throws Exception{
		return approveNFADAO.rejectScheme(schemeMaster);
	}
	
	public String testValidScheme(SchemeMaster schemeMaster) throws Exception{
		return approveNFADAO.testValidScheme(schemeMaster);
	}

	@SuppressWarnings("unused")
	@Override
	public String rejectScheme(RejectSchemeVO reject) throws Exception {
		
		String msg =  approveNFADAO.rejectScheme(reject);
		dsm.common.utility.PostSmsNEmailWrapper sms = new dsm.common.utility.PostSmsNEmailWrapper();
		PayoutSmsConfigVO smsConfig = approveNFADAO.smsConfigTemplate(reject.getSchemeId(), reject.getCompId(), reject.getCircleId());
		boolean flag = sms.sendSms(smsConfig);
		//System.out.println("\n rejectScheme smsConfigTemplate sendSms ::::::::::::********"+flag +" compName ------->>>>> "+reject.getComponentName());
		boolean updateFlag = flag ? approveNFADAO.updateSmsTransaction(smsConfig) : false;
		PayoutEmailConfigVO emailConfig = approveNFADAO.emailConfigTemplate(reject.getComponentName(), reject.getCircleId());
		String emailMsg="";
		try {
			boolean emailFlag = sms.sendMail(emailConfig);
			emailMsg = emailFlag ? "<br><font color='blue'>Email Sent Successfully.</font>" : "<br><font color='red'>Email Sent Successfully.</font>";
			boolean emailUpdateFlag = emailFlag ? approveNFADAO.updateEmailTransaction(emailConfig) : false;
		//	System.out.println("Email Trans update ------>>>>> "+emailUpdateFlag);

		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//	System.out.println("\n rejectScheme smsConfigTemplate sendSms ::::::::::::********"+flag);
	//	System.out.println("SMS Trans update ------>>>>> "+updateFlag);
		return flag ? msg +"<br><font color='blue'>Sms Sent Successfully.</font>"+emailMsg : msg;
	}
}

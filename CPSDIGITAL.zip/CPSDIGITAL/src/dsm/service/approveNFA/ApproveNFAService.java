package dsm.service.approveNFA;

import dsm.model.DB.RejectSchemeVO;
import dsm.model.DB.SchemeMaster;

public interface ApproveNFAService {
	
	public String approveScheme(SchemeMaster schemeMaster) throws Exception;
	
	public String rejectScheme(SchemeMaster schemeMaster) throws Exception;
	
	public String testValidScheme(SchemeMaster schemeMaster) throws Exception;
	
	public String rejectScheme(RejectSchemeVO reject) throws Exception;
	//public PayoutSmsConfigVO smsConfigTemplate(int schemeId, int compId, int circleId);
	
}

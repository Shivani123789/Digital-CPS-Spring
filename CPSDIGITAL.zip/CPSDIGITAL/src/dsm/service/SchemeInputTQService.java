package dsm.service;

import dsm.dao.form.tq.SchemeInputTq;
import dsm.model.DB.TransDataCSV;
import dsm.model.DB.TransSubData;
import dsm.model.po.SchemePoMaster;



public interface SchemeInputTQService {

	public SchemeInputTq getSchemeInputTQDetails();
	public TransDataCSV transDataNotQualify(TransSubData transdata) ;
	public String copyCondition(SchemePoMaster po) throws Exception;
}

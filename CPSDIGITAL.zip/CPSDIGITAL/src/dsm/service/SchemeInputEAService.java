package dsm.service;

import java.util.List;

import dsm.dao.ea.SchemeInputEA;
import dsm.model.ea.DataSourceEQModel;
import dsm.model.ea.DayLvlAggr;

public interface SchemeInputEAService {

	public SchemeInputEA getSchemeInputEADetails();
	public List<DataSourceEQModel> getDataSourceList(String schemeName);
	public List<DayLvlAggr> getDayLvlAggrList(int circleId);
	
	
}

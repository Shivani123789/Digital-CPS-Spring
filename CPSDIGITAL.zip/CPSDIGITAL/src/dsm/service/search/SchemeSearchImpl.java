package dsm.service.search;

import java.sql.SQLException;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dsm.dao.approveNFA.ApproveNFADAO;
import dsm.dao.search.SchemeSearchDAO;
import dsm.model.DB.BulkRejectionDataPojo;
import dsm.model.DB.CompMaster;
import dsm.model.DB.PayoutEmailConfigVO;
import dsm.model.DB.PayoutSmsConfigVO;
import dsm.model.DB.RegZoneMaster;
import dsm.model.DB.SchemeAcMaster;
import dsm.model.DB.SchemeEaFilterCondMaster;
import dsm.model.DB.SchemeEaMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemePoAmtMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ScmPayoutVO;
import dsm.model.form.BulkLoadErrorFileStatus;
import dsm.model.form.HoldReleaseAmount;
import dsm.model.po.SchemePoMaster;
import dsm.model.search.SearchScheme;
import dsm.model.submit.SubmitScheme;


@Service
public class SchemeSearchImpl implements SchemeSearch {

	@Autowired
	SchemeSearchDAO schemeEditDAO = null;

	@Autowired
	ApproveNFADAO approveNFADAO;
	

	@Override
	public List<RegZoneMaster> getRegZone(String schemeName) throws Exception {
		return null;
	}

	@Override
	public List<SchemeAcMaster> getCoverage(String schemeName)
			throws SQLException {
		return null;
	}

	@Override
	public List<SchemeTqMaster> getTq(String schemeName)  throws Exception{
		return null;
	}

	@Override
	public List<SchemeEaMaster> getEa(String schemeName)  throws Exception{
		return null;
	}

	@Override
	public List<SchemeEaFilterCondMaster> getEaFilter(String schemeName)  throws Exception{
		return null;
	}

	@Override
	public List<SchemePoMaster> getPo(String schemeName)  throws Exception{
		return null;
	}

	@Override
	public List<SchemePoAmtMaster> getPoFilter(String schemeName)  throws Exception{
		return null;
	}

	@Override
	public void loadScheme(SchemeMaster sm)  throws Exception{
		schemeEditDAO.loadScheme(sm);
	}

	@Override
	public void submitScheme(SubmitScheme scheme) throws Exception {
		schemeEditDAO.submitScheme(scheme);
	}

	@Override
	public String validateScheme(SubmitScheme scheme) throws Exception {
		return schemeEditDAO.validateScheme(scheme);
	}

	@Override
	public List<SchemeMaster> loadScheme(String Scheme)  throws Exception{
		return 		schemeEditDAO.loadScheme(Scheme);
	}
	
	@Override
	public List<CompMaster> searchTransactionData(String filtertype, String startDate, String endDate, int circleId, SearchScheme schemeName)  throws Exception{
		return schemeEditDAO.searchTransactionData(filtertype, startDate, endDate, circleId,schemeName);
	}

	@Override
	public List<SchemeTqMaster> getTransactionSubData(String filtertype,int schemeId, int compId,int circleId, String circleCode)  throws Exception{
		return schemeEditDAO.getTransactionSubData(filtertype,schemeId, compId, circleId,circleCode);
	}

	@SuppressWarnings("unused")
	@Override
	public String submitSchemeChange(SearchScheme schemeName)  throws Exception{
	 	String msg = schemeEditDAO.submitSchemeChange(schemeName);
	 	dsm.common.utility.PostSmsNEmailWrapper sms = new dsm.common.utility.PostSmsNEmailWrapper();
		PayoutSmsConfigVO smsConfig = approveNFADAO.smsConfigTemplate(schemeName.getSchemeId(), schemeName.getCompId(), schemeName.getCircleId());
		boolean flag = sms.sendSms(smsConfig);
		//System.out.println("\n rejectScheme smsConfigTemplate sendSms ::::::::::::********"+flag);
		boolean updateFlag = flag ? approveNFADAO.updateSmsTransaction(smsConfig) : false;
		//System.out.println("SMS Trans update ------>>>>> "+updateFlag+" compName ------->>>>>>>>>>> "+schemeName.getComponentName());
		PayoutEmailConfigVO emailConfig = approveNFADAO.emailConfigTemplate(schemeName.getComponentName(), schemeName.getCircleId());
		String emailMsg="";
		try {
			boolean emailFlag = sms.sendMail(emailConfig);
			emailMsg = emailFlag ? "<br><font color='blue'>Email sent successfully.</font>" : "<br><font color='red'>Email sent successfully.</font>";
			boolean emailUpdateFlag = emailFlag ? approveNFADAO.updateEmailTransaction(emailConfig) : false;
			//System.out.println("Email Trans update ------>>>>> "+emailUpdateFlag);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return flag ? msg +"<br><font color='blue'>SMS sent successfully.</font>"+emailMsg : msg +"<br> <font color='red'> Unable to send SMS.</font>"+emailMsg;
	}

	@Override
	public List<ScmPayoutVO> loadHoldDataSearch(SearchScheme holdData, int circleId, String circleCode) throws Exception {
		return schemeEditDAO.loadHoldDataSearch(holdData, circleId, circleCode);
	}

	@Override
	public List<HoldReleaseAmount> getReleaseDataCSV(SearchScheme holdData,	int circleId, String circleCode) throws Exception {
		return schemeEditDAO.getReleaseDataCSV(holdData, circleId, circleCode);
	}
	
	@Override
	public List<SchemeMaster> loadSchemeCreate(SearchScheme Scheme)  throws Exception{
		return 		schemeEditDAO.loadSchemeCreate(Scheme);
	}
	
	
	@Override
	public List<BulkRejectionDataPojo> loadBulkRejFileList(String fileName, String  uniqueFileName, String circle) throws Exception
	{
		String whereColumnFields = " FILE_NAME = ? and circle = ? and Rejection_Reason <> 'NO_REASON'";
		String selectColumnFields = null;
		String confNameType = null;
		
		if(fileName != null && fileName.contains("ADD_ATTR"))
		{
			selectColumnFields = "Dsm2_Ref_Code, Entity_Type, circle, File_Name, Rejection_Reason";
			confNameType="ADD_ATTR";
		}
		else if(fileName!=null && fileName.contains("ADD_ACT_UNI"))
		{
			selectColumnFields="Msisdn, Event_Date, Circle, File_Name, Rejection_Reason";
			confNameType="ADD_ACT_UNI";
		}
		else if(fileName!=null && fileName.contains("ADD_DIST_UNI"))
		{
			selectColumnFields="Dist_Id, Event_Date, Circle, File_Name, Rejection_Reason";
			confNameType="ADD_DIST_UNI";
		}
		else if(fileName!=null && fileName.contains("ADD_DSE_UNI"))
		{
			selectColumnFields="Dse_Id, Event_Date, Circle, File_Name, Rejection_Reason";
			confNameType="ADD_DSE_UNI";
		}else if(fileName!=null && fileName.contains("ADD_RET_UNI"))
		{
			selectColumnFields="Ret_Id, Event_Date, Circle, File_Name, Rejection_Reason";
			confNameType="ADD_RET_UNI";
		}
		else if(fileName!=null && fileName.contains("ENTITY-LIST"))
		{
			selectColumnFields="Producer_Id, Entity_Type, Circle, File_Name, Rejection_Reason";
			confNameType="ENTITY-LIST";
			uniqueFileName = fileName;
		}
		else if(fileName!=null && fileName.contains("MANUAL-PAYOUT"))
		{
			selectColumnFields="Dsm_Ref_Code, Entity_Type, Circle, File_Name, Rejection_Reason";
			confNameType="MANUAL-PAYOUT";
		}
		return schemeEditDAO.loadBulkRejFileList(fileName, uniqueFileName, whereColumnFields, confNameType, selectColumnFields, circle);
	}

	@Override
	public List<BulkLoadErrorFileStatus> getBulkUploadErrorFile(SearchScheme holdData, String circleCode)  throws Exception{
		return null;
	}
	
}

package dsm.service.search;

import java.sql.SQLException;
import java.util.List;

import dsm.model.DB.BulkRejectionDataPojo;
import dsm.model.DB.CompMaster;
import dsm.model.DB.RegZoneMaster;
import dsm.model.DB.SchemeAcMaster;
import dsm.model.DB.SchemeEaFilterCondMaster;
import dsm.model.DB.SchemeEaMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemePoAmtMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ScmPayoutVO;
import dsm.model.form.BulkLoadErrorFileStatus;
import dsm.model.form.HoldReleaseAmount;
import dsm.model.po.SchemePoMaster;
import dsm.model.search.SearchScheme;
import dsm.model.submit.SubmitScheme;

public interface SchemeSearch {
	
	public void submitScheme(SubmitScheme scheme) throws Exception;
	
	public String validateScheme(SubmitScheme scheme) throws Exception;
	
	public List<RegZoneMaster> getRegZone(String schemeName) throws Exception;
	
	public List<SchemeAcMaster> getCoverage(String schemeName) throws SQLException;
	
	public List<SchemeTqMaster> getTq(String schemeName) throws Exception;
	
	public List<SchemeEaMaster> getEa(String schemeName) throws Exception;
	
	public List<SchemeEaFilterCondMaster> getEaFilter(String schemeName) throws Exception;
	
	public List<SchemePoMaster> getPo(String schemeName) throws Exception;
	
	public List<SchemePoAmtMaster> getPoFilter(String schemeName) throws Exception;
	
	public void loadScheme(SchemeMaster sm) throws Exception;
	
	public List<SchemeMaster> loadScheme(String Scheme) throws Exception;
	
	public List<CompMaster> searchTransactionData(String filtertype, String startDate, String endDate, int circleId, SearchScheme schemeName) throws Exception;
	
	public List<SchemeTqMaster> getTransactionSubData(String filtertype,int schemeId, int compId,int circleId, String circleCode) throws Exception;
	
	public String submitSchemeChange(SearchScheme schemeName) throws Exception;
	
	public List<ScmPayoutVO> loadHoldDataSearch(SearchScheme holdData, int circleId, String circleCode) throws Exception;
	
	public List<HoldReleaseAmount> getReleaseDataCSV(SearchScheme holdData, int circleId, String circleCode) throws Exception;
	
	public List<SchemeMaster> loadSchemeCreate(SearchScheme Scheme) throws Exception;
	
	public List<BulkLoadErrorFileStatus> getBulkUploadErrorFile(SearchScheme holdData, String circleCode)  throws Exception;
	
	public List<BulkRejectionDataPojo> loadBulkRejFileList(String fileName, String uniqueFileName, String circleCode)  throws Exception;
	
}

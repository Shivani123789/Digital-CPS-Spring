package dsm.service.bulk;

import java.io.File;
import java.util.Date;
import java.util.List;

import dsm.model.form.BulkLoadFileStatus;
import dsm.model.form.BulkSchemeComponentList;
import dsm.model.form.DocTypeList;
import dsm.model.form.UploadMailStatusData;

public interface BulkUploadService {
	
	public String processFileData(String userName, int file_id, File file, String circleCode, int schemeId, int compId, int circleId,Date startDate,Date endDate)  throws Exception;
	
	//public String fetchFileData(String userName, String confName, File file, String feedNumber, String circle);
	public String fetchFileData(String userName, int file_id, File file, String circle, int schemeId, int compId) throws Exception; 
	
	public BulkSchemeComponentList getBulkSchemeComponentList(String fileName, int circleId) throws Exception;
	
	public BulkSchemeComponentList getDocListType() throws Exception;
	
	//========= Bulk Upload DOC Type ============//
	
	public String validateInputFile(DocTypeList docTypeList) throws Exception;
	
	//public String docFileUpload(DocTypeList docTypeList);
	public int mailFileUpload(DocTypeList docTypeList,String line) throws Exception;
	
	public String processMailFileData(String userName, int file_id, File file, String circleCode, int circleId) throws Exception;
	
	public BulkSchemeComponentList getUploadData(UploadMailStatusData uploadMailStatusData) throws Exception;
	
	public BulkSchemeComponentList getMailData(UploadMailStatusData uploadMailStatusData) throws Exception;
	
	public List<BulkLoadFileStatus> getRejectedFileList(Date stDt, Date enddt, String type, String circleCode)  throws Exception;
	
	
}

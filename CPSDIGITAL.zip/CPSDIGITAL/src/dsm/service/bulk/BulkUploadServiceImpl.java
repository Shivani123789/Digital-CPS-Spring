package dsm.service.bulk;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import dsm.dao.bulk.BulkUploadDAO;
import dsm.model.DB.MappingTableFields;
import dsm.model.DB.SchemeBulkLoadConfVo;
import dsm.model.form.BulkLoadFileStatus;
import dsm.model.form.BulkSchemeComponentList;
import dsm.model.form.DocTypeList;
import dsm.model.form.DocUploadFile;
import dsm.model.form.UploadMailStatusData;
import dsm.module.constant.BulkConstants;

@Service
public class BulkUploadServiceImpl implements BulkUploadService{
	
	private static Logger logger = Logger.getLogger (BulkUploadServiceImpl.class);
	@Autowired
	BulkUploadDAO bulkUploadDAO;
	
	BulkSchemeComponentList bulkSchemeCompList ;//= null;
	@Override
	public String fetchFileData(String userName, int file_id, File file, String circle, int schemeId, int compId)  throws Exception
	{
		return bulkUploadDAO.fetchFileData(userName, file_id, file, circle, schemeId, compId);
	}
	
	@Override
	public BulkSchemeComponentList getBulkSchemeComponentList(String fileName, int circleId) throws Exception{
		if(bulkSchemeCompList!= null){
			bulkSchemeCompList.setBulkSchemeMasterList(bulkUploadDAO.getBulkSchemeMasterStore(fileName,circleId));
			bulkSchemeCompList.setBulkComponentMasterList(bulkUploadDAO.getBulkComponentMasterStore(fileName,circleId));
		}else{
			bulkSchemeCompList = new BulkSchemeComponentList();
			bulkSchemeCompList.setBulkSchemeMasterList(bulkUploadDAO.getBulkSchemeMasterStore(fileName,circleId));
			bulkSchemeCompList.setBulkComponentMasterList(bulkUploadDAO.getBulkComponentMasterStore(fileName,circleId));
		}
		return bulkSchemeCompList;
	}
	
	@Override
	public String processFileData(String userName, int file_id, File file, String circleCode, int schemeId, int compId, int circleId, Date startDate, Date endDate)  throws Exception{
		List<SchemeBulkLoadConfVo> schmeBulkConfData;
		String fileStatus = null;
		String uniqFileName = null;
		try {
			String[] fileName = file.getName().split(BulkConstants.SLASH_DOT);
			String[] str = fileName[0].split("_");
			//File Extension Validation
			if(fileName.length!=2){
				StringBuffer fileExt = new StringBuffer();
				for(int i=1;i<fileName.length;i++){
					fileExt.append(BulkConstants.DOT).append(fileName[i]).append(BulkConstants.COMMA);
				}
				fileStatus = BulkConstants.FILE_EXTENSION_ERROR.replace(BulkConstants.PDFX, fileExt);
				return fileStatus;
			}
			if(!fileName[fileName.length-1].equalsIgnoreCase(BulkConstants.CSV)){
				 fileStatus = BulkConstants.CSV_FILE_EXTENSION_ERROR.replace(BulkConstants.PDFX, fileName[fileName.length-1]);
				 return fileStatus;
			}
			//File Name Validate
			fileStatus = fileNameValidateNew(fileName[0],file_id);
			if(fileStatus!=null){
					return fileStatus;
			}
			
			//Validating the file name with given schemeId and compId only in inclusion and exclusion 
			if(file_id == 4){
				boolean flag = bulkUploadDAO.matchSchemeCompMappingFileNew(schemeId, compId, file.getName());
				if(!flag){
					if(schemeId==0)
						return fileStatus="GIVEN SCHEME ID IS ZERO.";
					if(compId==0)
						return fileStatus="GIVEN COMPONENT ID IS ZERO.";
					return fileStatus="FILE NAME IS NOT MATCHED WITH GIVEN SCHEME AND COMPONENT";
				}
			}
			
			//Loading SchemeBulkConfData
			schmeBulkConfData = bulkUploadDAO.getSchemBulkConfDataNew(file_id);
			
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed = format.parse(str[str.length-1]);

			if(schmeBulkConfData != null && schmeBulkConfData.size() != 0){
			
				//bulkUploadDAO.insertIntoBulkLoadFileDet(file.getName(),circleCode,file_id);
				for (SchemeBulkLoadConfVo schemeBulkLoadVo : schmeBulkConfData) {
					
					if(schemeBulkLoadVo.isErrorFlag()){
						return schemeBulkLoadVo.getErrorDescription();
					}
					logger.debug("in for :::"+file.getName());
					//File Data is setting in SchemeBulkLoadConfVo
					schemeBulkLoadVo.setFileFullName(file.getName());
					schemeBulkLoadVo.setFileUniqueName(fileName[0]+BulkConstants.UNDERSCORE+(Long.toString(new Date().getTime()))+BulkConstants.DOT+fileName[1]);
					schemeBulkLoadVo.setFileNameDate(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
					schemeBulkLoadVo.setFileCircleCode(circleCode);
					schemeBulkLoadVo.setStartDate(startDate);
					schemeBulkLoadVo.setEndDate(endDate);
					//if(file_id == 5)
						uniqFileName = schemeBulkLoadVo.getFileUniqueName();
					//Updating destination table for file type 4 or inclusion n exclusion. If same file name is present their in destination table and changing the IPS_MOVEMENT_FLAG to R.   
					if(schemeBulkLoadVo.getFileId() == 4){
						try{
							bulkUploadDAO.updateDestinationTableNew(circleCode, file.getName(), schemeBulkLoadVo.getDestinationTable());
						}catch(SQLException e){
							logger.error("updateDestinationTableNew : SQLException :: ", e);
							if(e.getMessage().contains("ORA-00942")){
								return BulkConstants.TABLE_ERROR;
							}else if(e.getMessage().contains("ORA-00904")){
								return BulkConstants.COLUMN_ERROR;
							}else if(e.getMessage().toLowerCase().contains("Closed Connection".toLowerCase())){
								return BulkConstants.CLOSE_CONNECTION;
							}else
								return BulkConstants.UPDATE_ERROR;
						}catch(NullPointerException e){
							logger.error("NullPointerException :: ", e);
							return BulkConstants.NULL_UPDATE_ERROR;
						}catch(Exception e){
							logger.error("Exception :: ", e);
							if(e.getMessage().contains("Network")){
								return BulkConstants.NETWORK_ERROR;
							}
							return BulkConstants.UPDATE_ERROR;
						}
					}
					
					//fetching file headers
					MappingTableFields mtf =null;
					if (BulkConstants.CSV.equalsIgnoreCase(fileName[1]) && BulkConstants.D.equalsIgnoreCase(schemeBulkLoadVo.getLoadingMethod())) {
						String line = "";
			//			logger.debug("in csv");
						//Reading file for header names
						BufferedReader br = new BufferedReader(new FileReader(file));	
						if((line = br.readLine()) != null){
				//			logger.debug("Line ::: "+line);
							mtf = bulkUploadDAO.getDestTabColValueNew(line,schemeBulkLoadVo.getType(),circleId);
							if(mtf!=null && !mtf.isErrorFlag()){
								schemeBulkLoadVo.setFieldNames(mtf.getFieldNames());
								schemeBulkLoadVo.setFieldCount(mtf.getFieldCount());
								schemeBulkLoadVo.setFileHeaderNames(line);
								schemeBulkLoadVo.setFileHeaderCount(mtf.getFileHeaderCount());
								schemeBulkLoadVo.setMandatoryColumnNames(mtf.getMandatoryColumns());
								schemeBulkLoadVo.setMandatoryFieldNames(mtf.getMandatoryFieldNames());
								schemeBulkLoadVo.setMandatoryFieldCount(mtf.getMandatoryFieldCount());
							}else{
								br.close();
								return fileStatus = mtf.getErrorCode();
							}
							br.close();
						}else{
							br.close();
							return fileStatus = BulkConstants.NO_DATA_FOUND;
						}
					}
					if(schemeBulkLoadVo.getFileHeaderCount() == schemeBulkLoadVo.getFieldCount()){
						fileStatus = bulkUploadDAO.insertDestinationTableNew(file, schemeBulkLoadVo);
						if(fileStatus != null){
							return fileStatus;
						}
					}else{
						fileStatus = BulkConstants.FILE_HEADER_ERROR + missmatchFileHeaderNew(schemeBulkLoadVo);
						return BulkConstants.FILE_HEADER_ERROR + missmatchFileHeaderNew(schemeBulkLoadVo);
					}
					if(fileStatus == null && (file_id == 2 || file_id == 4)){
						logger.debug("CALLING PROCEDURE >> DLP_ENTITY_ADD_ATTR_STAMP");
						fileStatus = bulkUploadDAO.callProcEntityAddAttrStampNew(schemeBulkLoadVo);
					}else if(fileStatus == null && file_id == 5){
						logger.debug("CALLING PROCEDURE >> DLP_MANUAL_PAYOUT");
						fileStatus =  bulkUploadDAO.callProcDlpPerformConfigNew(schemeBulkLoadVo, userName);
						////System.out.println("processFileData :::: "+fileStatus);
						return fileStatus;
					}else if(fileStatus == null && (file_id==3 || file_id==6 || file_id==7 || file_id==8) ){
						fileStatus =  bulkUploadDAO.callProcDlpCirclePerformParamConfigNew(schemeBulkLoadVo, userName);
						return fileStatus;
					}if(file_id==4 && fileStatus == null){
						fileStatus = BulkConstants.ENTITY_LIST_SUCCESS;
					}
				}
			}else{
				fileStatus=BulkConstants.SCHEME_BULK_LOAD_CONF_TEMP_ERROR;
				return fileStatus;
			}//IOException 
		}catch (ParseException pe) {
			logger.error("ParseException :: ", pe);pe.printStackTrace();
			//fileStatus=pe.getMessage()+" "+BulkConstants.FILE_DATE_PARSE_ERROR + BulkConstants.LEFT_BRACKET + file.getName() + BulkConstants.RIGHT_BRACKET;
			return fileStatus = BulkConstants.FILE_DATE_PARSE_ERROR + BulkConstants.LEFT_BRACKET + file.getName() + BulkConstants.RIGHT_BRACKET;
		}catch (FileNotFoundException errorMessage) {
			//System.err.println("Wrong file uploaded or Please check file extension it must be xls/xlsx or csv");
			logger.error("FileNotFoundException :: ", errorMessage);errorMessage.printStackTrace();
			fileStatus = BulkConstants.WRONG_FILE_ERROR /*+ BulkConstants.LEFT_BRACKET + file.getName() + BulkConstants.RIGHT_BRACKET*/;
			return fileStatus;
		}catch (IOException pe) {
			logger.error("IOException :: ", pe);pe.printStackTrace();
			 fileStatus= BulkConstants.FILE_READER_ERROR /*+ BulkConstants.LEFT_BRACKET + file.getName() + BulkConstants.RIGHT_BRACKET*/;
			 return fileStatus;
		}catch (NullPointerException e) {
			logger.error("NullPointerException :: ", e);e.printStackTrace();
			fileStatus = e.getMessage();
			return fileStatus = BulkConstants.NULL_UPDATE_ERROR;
		}catch (Exception e) {
			logger.error("Exception :: ", e);e.printStackTrace();
			fileStatus = e.getMessage();
			return fileStatus = BulkConstants.UNABLE_ERROR;
		}finally{
			try {
				//if(uniqFileName != null){
					////System.out.println("uniqFileName ::: "+uniqFileName);
					bulkUploadDAO.persistFileDetailNew(userName, file.getName(), fileStatus, uniqFileName, circleCode);
				//}else{
					//bulkUploadDAO.persistFileDetailNew(userName, file.getName(), fileStatus, uniqFileName, circleCode);
				//}
			} catch (Exception e) {
				logger.error("processFileData()  :  Exception :: ",e);
				e.printStackTrace();
			}	
		}	
		return fileStatus;
	} // End of fetchFileData() method

	private String fileNameValidateNew(String fileName, int fileTypeId) throws Exception{
		String[] str = null;
		boolean flag = false;
		String errorMsg = null;
		switch (fileTypeId) {
		case 1:if(fileName!=null && fileName.contains(BulkConstants.SCM_CONFIG)){
			flag=true;
		}
		case 2 :  if(fileName != null && fileName.contains(BulkConstants.ADD_ATTR)){
			str = fileName.split(BulkConstants.UNDERSCORE);
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed;
			try {
				if(!BulkConstants.MONTHS.toLowerCase().contains(str[str.length-2].toLowerCase())){
					errorMsg = BulkConstants.MONTH_ERROR ;//+ str[str.length-2];	
				}if(str[str.length-2].length()!=3){
					errorMsg = BulkConstants.MONTH_ERROR ;//+ str[str.length-2];	
				}
				if(str[str.length-1].length() == 8){
					parsed = format.parse(str[str.length-1]);
			//		logger.debug(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
				}else{
					if(errorMsg==null)
						errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
					else
						errorMsg = errorMsg  + "<br> "+ BulkConstants.DATE_ERROR + str[str.length-1];
				}
			}catch (ParseException e) {
				flag=false;
				errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
				e.printStackTrace();
			}
			if(str.length!=6)
				return BulkConstants.WRONG_FILE_NAMING_CONVENTION + BulkConstants.LEFT_BRACKET + fileName + BulkConstants.RIGHT_BRACKET;
		}
		break;
		
		case 3 : if(fileName != null && fileName.contains(BulkConstants.ADD_ACT_UNI)){
			str = fileName.split(BulkConstants.UNDERSCORE);
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed;
			try {

				if(!BulkConstants.MONTHS.toLowerCase().contains(str[str.length-2].toLowerCase())){
					errorMsg = BulkConstants.MONTH_ERROR;// + str[str.length-2];	
				}if(str[str.length-2].length()!=3){
					errorMsg = BulkConstants.MONTH_ERROR ;//+ str[str.length-2];	
				}
				if(str[str.length-1].length() == 8){
					parsed = format.parse(str[str.length-1]);
					//logger.debug(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
				}else{
					if(errorMsg==null)
						errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
					else
						errorMsg = errorMsg  + "<br> "+ BulkConstants.DATE_ERROR + str[str.length-1];
				}
			}catch (ParseException e) {
				flag=false;
				errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
				e.printStackTrace();
			}
			if(str.length!=7)
				return BulkConstants.WRONG_FILE_NAMING_CONVENTION + BulkConstants.LEFT_BRACKET + fileName + BulkConstants.RIGHT_BRACKET;
		}
		break;
		
		case 4 : if(fileName != null && fileName.contains(BulkConstants.ENTITY_LIST)){
			str = fileName.split(BulkConstants.UNDERSCORE);
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed;
			try {
				if(str[str.length-1].length() == 8){
					parsed = format.parse(str[str.length-1]);
					//logger.debug(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
				}else{
					errorMsg = BulkConstants.DATE_ERROR ;//+ str[str.length-1];
				}
			}catch (ParseException e) {
				flag=false;
				errorMsg = BulkConstants.DATE_ERROR;// + str[str.length-1];
				e.printStackTrace();
			}
			if(str.length!=5)
				return BulkConstants.WRONG_FILE_NAMING_CONVENTION + BulkConstants.LEFT_BRACKET + fileName + BulkConstants.RIGHT_BRACKET;
		}
		break;
		
		case 5 : if(fileName != null && fileName.contains(BulkConstants.MANUAL_PAYOUT)){
			str = fileName.split("_");
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed;
			try {
				if(!BulkConstants.MONTHS.toLowerCase().contains(str[str.length-2].toLowerCase())){
					errorMsg = BulkConstants.MONTH_ERROR;// + str[str.length-2];	
				}if(str[str.length-2].length()!=3){
					errorMsg = BulkConstants.MONTH_ERROR;// + str[str.length-2];	
				}
				if(str[str.length-1].length() == 8){
					parsed = format.parse(str[str.length-1]);
					//logger.debug(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
				}else{
					if(errorMsg==null)
						errorMsg = BulkConstants.DATE_ERROR;// + str[str.length-1];
					else
						errorMsg = errorMsg  + " <br>"+ BulkConstants.DATE_ERROR ;//+ str[str.length-1];
				}
			}catch (ParseException e) {
				flag=false;
				errorMsg = BulkConstants.DATE_ERROR ;//+ str[str.length-1];
				e.printStackTrace();
			}
			if(str.length!=5)
				return BulkConstants.WRONG_FILE_NAMING_CONVENTION + BulkConstants.LEFT_BRACKET + fileName + BulkConstants.RIGHT_BRACKET ;
		}
		break;
		
		case 6 : if(fileName != null && fileName.contains(BulkConstants.ADD_DIST_UNI)){
			str = fileName.split(BulkConstants.UNDERSCORE);
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed;
			try {

				if(!BulkConstants.MONTHS.toLowerCase().contains(str[str.length-2].toLowerCase())){
					errorMsg = BulkConstants.MONTH_ERROR;// + str[str.length-2];	
				}if(str[str.length-2].length()!=3){
					errorMsg = BulkConstants.MONTH_ERROR ;//+ str[str.length-2];	
				}
				if(str[str.length-1].length() == 8){
					parsed = format.parse(str[str.length-1]);
					//logger.debug(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
				}else{
					if(errorMsg==null)
						errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
					else
						errorMsg = errorMsg  + "<br> "+ BulkConstants.DATE_ERROR + str[str.length-1];
				}
			}catch (ParseException e) {
				flag=false;
				errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
				e.printStackTrace();
			}
			if(str.length!=7)
				return BulkConstants.WRONG_FILE_NAMING_CONVENTION + BulkConstants.LEFT_BRACKET + fileName + BulkConstants.RIGHT_BRACKET;
		}
		break;

		case 7 : if(fileName != null && fileName.contains(BulkConstants.ADD_RET_UNI)){
			str = fileName.split(BulkConstants.UNDERSCORE);
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed;
			try {

				if(!BulkConstants.MONTHS.toLowerCase().contains(str[str.length-2].toLowerCase())){
					errorMsg = BulkConstants.MONTH_ERROR;// + str[str.length-2];	
				}if(str[str.length-2].length()!=3){
					errorMsg = BulkConstants.MONTH_ERROR ;//+ str[str.length-2];	
				}
				if(str[str.length-1].length() == 8){
					parsed = format.parse(str[str.length-1]);
					//logger.debug(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
				}else{
					if(errorMsg==null)
						errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
					else
						errorMsg = errorMsg  + "<br> "+ BulkConstants.DATE_ERROR + str[str.length-1];
				}
			}catch (ParseException e) {
				flag=false;
				errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
				e.printStackTrace();
			}
			if(str.length!=7)
				return BulkConstants.WRONG_FILE_NAMING_CONVENTION + BulkConstants.LEFT_BRACKET + fileName + BulkConstants.RIGHT_BRACKET;
		}
		break;

		case 8 : if(fileName != null && fileName.contains(BulkConstants.ADD_DSE_UNI)){
			str = fileName.split(BulkConstants.UNDERSCORE);
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed;
			try {

				if(!BulkConstants.MONTHS.toLowerCase().contains(str[str.length-2].toLowerCase())){
					errorMsg = BulkConstants.MONTH_ERROR;// + str[str.length-2];	
				}if(str[str.length-2].length()!=3){
					errorMsg = BulkConstants.MONTH_ERROR ;//+ str[str.length-2];	
				}
				if(str[str.length-1].length() == 8){
					parsed = format.parse(str[str.length-1]);
					//logger.debug(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
				}else{
					if(errorMsg==null)
						errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
					else
						errorMsg = errorMsg  + "<br> "+ BulkConstants.DATE_ERROR + str[str.length-1];
				}
			}catch (ParseException e) {
				flag=false;
				errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
				e.printStackTrace();
			}
			if(str.length!=7)
				return BulkConstants.WRONG_FILE_NAMING_CONVENTION + BulkConstants.LEFT_BRACKET + fileName + BulkConstants.RIGHT_BRACKET;
		}
		break;

		case 9 : if(fileName != null && fileName.contains(BulkConstants.MAIL_LIST)){
			str = fileName.split(BulkConstants.UNDERSCORE);
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed;
			////System.out.println("trs::"+str.length);
			try {

				if(!BulkConstants.MONTHS.toLowerCase().contains(str[str.length-2].toLowerCase())){
					errorMsg = BulkConstants.MONTH_ERROR;// + str[str.length-2];	
				}if(str[str.length-2].length()!=3){
					errorMsg = BulkConstants.MONTH_ERROR ;//+ str[str.length-2];	
				}
				if(str[str.length-1].length() == 8){
					parsed = format.parse(str[str.length-1]);
					//logger.debug(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
				}else{
					if(errorMsg==null)
						errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
					else
						errorMsg = errorMsg  + "<br> "+ BulkConstants.DATE_ERROR + str[str.length-1];
				}
			}catch (ParseException e) {
				flag=false;
				errorMsg = BulkConstants.DATE_ERROR + str[str.length-1];
				e.printStackTrace();
			}
			if(str.length!=6)
				return BulkConstants.WRONG_FILE_NAMING_CONVENTION + BulkConstants.LEFT_BRACKET + fileName + BulkConstants.RIGHT_BRACKET;
		}
		break;

		}
		//logger.debug("fileNameValidate ::: flag  "+flag);
		//logger.debug("End fileNameValidate() method");
		return errorMsg;
	}
	
	
	private String missmatchFileHeaderNew(SchemeBulkLoadConfVo schemeBulkLoadVo) throws Exception{
		logger.debug("Entered into missmatchFileHeader() method");
		StringBuffer columns = new StringBuffer();
		String[] headerFields =  schemeBulkLoadVo.getFileHeaderNames().split(BulkConstants.COMMA);
		for(String val : headerFields){
			if(!(schemeBulkLoadVo.getFieldNames().containsKey(val)) ){
				columns.append(val).append(BulkConstants.COMMA);
			}
			if("".equalsIgnoreCase(val.trim())){
				columns.append("Should not be empty or blank").append(BulkConstants.COMMA);
			}
		}logger.debug("End missmatchFileHeader() method");
		return columns.toString();
	}
	
	@Override
	public BulkSchemeComponentList getDocListType() throws Exception
	{
		if(bulkSchemeCompList!= null){
			bulkSchemeCompList.setDocTypeList(bulkUploadDAO.getDocListType());
		}else{
			bulkSchemeCompList=new BulkSchemeComponentList();
			bulkSchemeCompList.setDocTypeList(bulkUploadDAO.getDocListType());
		}
		return bulkSchemeCompList;
	}
	
	
	
	//================== Bulk Upload DOC File =============//
	
	@Override
	public String validateInputFile(DocTypeList docTypeList) throws Exception
	{
		String extFile = docTypeList.getUploadDocFile().getOriginalFilename().split("\\.")[1];
		DocUploadFile val = bulkUploadDAO.validateDocFileType(extFile);
		String errorMsg = null;
		int fileNameSize = docTypeList.getUploadDocFile().getOriginalFilename().split("\\.")[0].length();
		long fileSize = docTypeList.getUploadDocFile().getSize();
		
		if(val != null )
		{
			if(fileNameSize <= val.getFileNameSize() ){
				if(fileSize <= ( val.getFileSize() * 1024)){
				}else{
					return	errorMsg = "File size exceeded. Please provide valid file sizing below:"+val.getFileSize()+" Kb";	
				}
			}else{
				return errorMsg = "The file name does not adhere to correct naming convention. <br>Please refer 'Template' menu from the navigation panel to get the naming convention.";
			}
		}else{
			return errorMsg = "The file name does not adhere to correct naming convention. <br>Please refer 'Template' menu from the navigation panel to get the naming convention.";
		}
		
		int count = bulkUploadDAO.insertDocTypeValues(docTypeList);
		if(count == 0){
			return "File is not copied. Please try again.";
		}
		
		return errorMsg;
	}


	
	
	
	
	/*@Override
	public String docFileUpload(DocTypeList docTypeList)
	{
		String val=bulkUploadDAO.insertDocTypeValues(docTypeList);
	    return val;
	}*/
	
	//
	
	@Override
	public int mailFileUpload(DocTypeList docTypeList,String line) throws Exception
	{
		int val=bulkUploadDAO.insertMailTypeValues(docTypeList,line);
	    return val;
	}
	
	@Override
	public BulkSchemeComponentList getUploadData(UploadMailStatusData uploadMailStatusData) throws Exception
	{

		if(bulkSchemeCompList!=null)
		{
			bulkSchemeCompList.setUploadMailStatusData(bulkUploadDAO.getUploadData(uploadMailStatusData));
			return bulkSchemeCompList;
		}
		else
		{
			bulkSchemeCompList= new BulkSchemeComponentList();
			bulkSchemeCompList.setUploadMailStatusData(bulkUploadDAO.getUploadData(uploadMailStatusData));
			return bulkSchemeCompList;
		}
	}
	
	@Override
	public BulkSchemeComponentList getMailData(UploadMailStatusData uploadMailStatusData) throws Exception
	{
		if(bulkSchemeCompList!=null)
		{
			bulkSchemeCompList.setUploadMailStatusData(bulkUploadDAO.getMailData(uploadMailStatusData));
			return bulkSchemeCompList;
		}
		else
		{
			bulkSchemeCompList= new BulkSchemeComponentList();
			bulkSchemeCompList.setUploadMailStatusData(bulkUploadDAO.getMailData(uploadMailStatusData));
			return bulkSchemeCompList;
		}
	}

	@Override
	public String processMailFileData(String userName, int file_id, File file, String circleCode, int circleId) throws Exception {
		List<SchemeBulkLoadConfVo> schmeBulkConfData;
		String fileStatus = null;
		String uniqFileName = null;
		try {
			String[] fileName = file.getName().split(BulkConstants.SLASH_DOT);
			String[] str = fileName[0].split("_");
			//File Extension Validation
			if(fileName.length!=2){
				StringBuffer fileExt = new StringBuffer();
				for(int i=1;i<fileName.length;i++){
					fileExt.append(BulkConstants.DOT).append(fileName[i]).append(BulkConstants.COMMA);
				}
				fileStatus = BulkConstants.FILE_EXTENSION_ERROR.replace(BulkConstants.PDFX, fileExt);
				return fileStatus;
			}
			if(!fileName[fileName.length-1].equalsIgnoreCase(BulkConstants.CSV)){
				 fileStatus = BulkConstants.CSV_FILE_EXTENSION_ERROR.replace(BulkConstants.PDFX, fileName[fileName.length-1]);
				 return fileStatus;
			}
			//File Name Validate
			fileStatus = fileNameValidateNew(fileName[0],file_id);
			if(fileStatus!=null){
					return fileStatus;
			}
			
			//Loading SchemeBulkConfData
			schmeBulkConfData = bulkUploadDAO.getSchemBulkConfDataNew(file_id);
			
			SimpleDateFormat format = new SimpleDateFormat(BulkConstants.DDMMYYYY);
			Date parsed = format.parse(str[str.length-1]);

			if(schmeBulkConfData != null && schmeBulkConfData.size() != 0){
			
				for (SchemeBulkLoadConfVo schemeBulkLoadVo : schmeBulkConfData) {
					
					if(schemeBulkLoadVo.isErrorFlag()){
						return schemeBulkLoadVo.getErrorDescription();
					}
					//File Data is setting in SchemeBulkLoadConfVo
					schemeBulkLoadVo.setFileFullName(file.getName());
					schemeBulkLoadVo.setFileUniqueName(fileName[0]+BulkConstants.UNDERSCORE+(Long.toString(new Date().getTime()))+BulkConstants.DOT+fileName[1]);
					schemeBulkLoadVo.setFileNameDate(new SimpleDateFormat(BulkConstants.DD_MMM_YYYY).format(parsed));
					schemeBulkLoadVo.setFileCircleCode(circleCode);
					
					uniqFileName = schemeBulkLoadVo.getFileUniqueName();
					
					//fetching file headers
					MappingTableFields mtf =null;
					if (BulkConstants.CSV.equalsIgnoreCase(fileName[1]) && BulkConstants.D.equalsIgnoreCase(schemeBulkLoadVo.getLoadingMethod())) {
						String line = "";
						//logger.debug("in csv");
						//Reading file for header names
						BufferedReader br = new BufferedReader(new FileReader(file));	
						if((line = br.readLine()) != null){
							//logger.debug("Line ::: "+line);
							mtf = bulkUploadDAO.getDestTabColValueNew(line,schemeBulkLoadVo.getType(),circleId);
							if(mtf!=null && !mtf.isErrorFlag()){
								schemeBulkLoadVo.setFieldNames(mtf.getFieldNames());
								schemeBulkLoadVo.setFieldCount(mtf.getFieldCount());
								schemeBulkLoadVo.setFileHeaderNames(line);
								schemeBulkLoadVo.setFileHeaderCount(mtf.getFileHeaderCount());
								schemeBulkLoadVo.setMandatoryColumnNames(mtf.getMandatoryColumns());
								schemeBulkLoadVo.setMandatoryFieldNames(mtf.getMandatoryFieldNames());
								schemeBulkLoadVo.setMandatoryFieldCount(mtf.getMandatoryFieldCount());
							}else{
								br.close();
								return fileStatus = mtf.getErrorCode();
							}
							br.close(); 
						}else{
							br.close();
							return fileStatus = BulkConstants.NO_DATA_FOUND;
						}
					}
					if(schemeBulkLoadVo.getFileHeaderCount() == schemeBulkLoadVo.getFieldCount()){
						
						fileStatus = bulkUploadDAO.insertMailDestinationTableNew(file, schemeBulkLoadVo);
						if(fileStatus != null){
							return fileStatus;
						}else{
							fileStatus = BulkConstants.SUCCESS;
						}
					}else{
						fileStatus = BulkConstants.FILE_HEADER_ERROR + missmatchFileHeaderNew(schemeBulkLoadVo);
						return BulkConstants.FILE_HEADER_ERROR + missmatchFileHeaderNew(schemeBulkLoadVo);
					}
				}
			}else{
				fileStatus=BulkConstants.SCHEME_BULK_LOAD_CONF_TEMP_ERROR;
				return fileStatus;
			}//IOException 
		}catch (ParseException pe) {
			logger.error("ParseException :: ", pe);pe.printStackTrace();
			//fileStatus=pe.getMessage()+" "+BulkConstants.FILE_DATE_PARSE_ERROR + BulkConstants.LEFT_BRACKET + file.getName() + BulkConstants.RIGHT_BRACKET;
			return fileStatus = BulkConstants.FILE_DATE_PARSE_ERROR + BulkConstants.LEFT_BRACKET + file.getName() + BulkConstants.RIGHT_BRACKET;
		}catch (FileNotFoundException errorMessage) {
			//System.err.println("Wrong file uploaded or Please check file extension it must be xls/xlsx or csv");
			logger.error("FileNotFoundException :: ", errorMessage);errorMessage.printStackTrace();
			fileStatus = BulkConstants.WRONG_FILE_ERROR /*+ BulkConstants.LEFT_BRACKET + file.getName() + BulkConstants.RIGHT_BRACKET*/;
			return fileStatus;
		}catch (IOException pe) {
			logger.error("IOException :: ", pe);pe.printStackTrace();
			 fileStatus= BulkConstants.FILE_READER_ERROR /*+ BulkConstants.LEFT_BRACKET + file.getName() + BulkConstants.RIGHT_BRACKET*/;
			 return fileStatus;
		}catch (NullPointerException e) {
			logger.error("NullPointerException :: ", e);e.printStackTrace();
			fileStatus = e.getMessage();
			return fileStatus = BulkConstants.NULL_UPDATE_ERROR;
		}catch (Exception e) {
			logger.error("Exception :: ", e);e.printStackTrace();
			fileStatus = e.getMessage();
			return fileStatus = BulkConstants.UNABLE_ERROR;
		}finally{
			try {
					bulkUploadDAO.persistFileDetailNew(userName, file.getName(), fileStatus, uniqFileName, circleCode);
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}	
		return fileStatus;
	} // End of fetchFileData() method

	@Override
	public List<BulkLoadFileStatus> getRejectedFileList(Date stDt, Date enddt, String type, String circleCode)  throws Exception{
		List<BulkLoadFileStatus> blfs = bulkUploadDAO.getRejectedFileList(stDt, enddt, type, circleCode);
		return blfs;
	}

}

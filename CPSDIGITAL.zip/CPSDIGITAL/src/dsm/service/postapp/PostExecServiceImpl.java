package dsm.service.postapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dsm.dao.postapp.PostExecDAO;
import dsm.model.DB.SchemeMaster;
import dsm.model.postapp.PostApprovedScheme;


@Service
public class PostExecServiceImpl implements PostExecService {

	@Autowired
	PostExecDAO postExecDAO= null;

	@Override
	public List<PostApprovedScheme> listScheme(String execDate,
			String approvedBy, String approvedStatus, String approvedDate)  throws Exception{
		return postExecDAO.listScheme(execDate, approvedBy, approvedStatus, approvedDate);
	}

	@Override
	public void updateSchemeStatus(int scheme_id, String approvedBy)  throws Exception{
		postExecDAO.updateSchemeStatus(scheme_id, approvedBy);
	}

	@Override
	public String payoutScheme(PostApprovedScheme schemeMaster)  throws Exception{
		return postExecDAO.payoutScheme(schemeMaster);
	}

	@Override
	public String testValidApproveScheme(SchemeMaster schemeMaster) throws Exception{
		return postExecDAO.testValidApproveScheme(schemeMaster);
	}
}

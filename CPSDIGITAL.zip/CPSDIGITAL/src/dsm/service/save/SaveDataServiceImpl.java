package dsm.service.save;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dsm.dao.save.SchemeInputAllDAO;
import dsm.model.DB.CompMaster;
import dsm.model.DB.RegZoneMaster;
import dsm.model.DB.RoprMaster;
import dsm.model.DB.SchemeAcMaster;
import dsm.model.DB.SchemeEaFilterCondMaster;
import dsm.model.DB.SchemeEaMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemePoAmtMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.po.SchemePoMaster;
import dsm.model.user.User;


@Service
public class SaveDataServiceImpl implements SaveDataService {

	@Autowired
	SchemeInputAllDAO schemInputAllDAO = null;
	
	@Override
	public boolean saveScheme(SchemeMaster sm) {
		schemInputAllDAO.saveScheme(sm);
		return true;
	}

	@Override
	public String saveComponent(CompMaster cm) throws Exception {
		return schemInputAllDAO.saveComponenent(cm);
	}

	@Override
	public void saveRegion(RegZoneMaster reg) throws Exception {
		schemInputAllDAO.saveRegion(reg);
	}

	@Override
	public void deleteRegZone(int regZoneId) {
		schemInputAllDAO.deleteRegZone(regZoneId);
	}

	@Override
	public void updateRegZone(RegZoneMaster rzMaster) {
		schemInputAllDAO.updateRegZone(rzMaster);
	}
	
	@Override
	public void saveAddCovCond(SchemeAcMaster acov) {
		schemInputAllDAO.saveAddCov(acov);
	}

	@Override
	public void saveTq(SchemeTqMaster tq) {
		schemInputAllDAO.saveTq(tq);
	}

	@Override
	public void saveEa(SchemeEaMaster ea) throws SQLException {
		schemInputAllDAO.saveEa(ea);
	}

	@Override
	public void savePo(SchemePoMaster po) throws SQLException {
		schemInputAllDAO.savePo(po);
	}

	@Override
	public void deleteScheme(SchemeMaster sm) {
		schemInputAllDAO.deleteScheme(sm);
	}

	@Override
	public int getCompCount(String SchemeName,int circleId) {
		return schemInputAllDAO.getCompCount(SchemeName,circleId);
		//return 0;
	}

	@Override
	public List<RegZoneMaster> getRegion(String schemeName) {
		return schemInputAllDAO.getRegZone(schemeName);
	}

	@Override
	public List<RoprMaster> getRopr() {
		return schemInputAllDAO.getRopr();
	}

	@Override
	public List<SchemeAcMaster> getCov(String schemeName) throws SQLException {
		return schemInputAllDAO.getCoverage(schemeName);
	}

	@Override
	public List<SchemeTqMaster> getTq(String schemeName) {
		return schemInputAllDAO.getTq(schemeName);
	}

	@Override
	public List<SchemeEaMaster> getEa(String schemeName) {
		return schemInputAllDAO.getEa(schemeName);
	}

	@Override
	public List<SchemePoMaster> getPo(String schemeName) {
		return schemInputAllDAO.getPo(schemeName);
	}

	@Override
	public List<SchemeEaFilterCondMaster> getEaFilter(String schemeName) {
		return schemInputAllDAO.getEaFilter(schemeName);
	}

	@Override
	public List<SchemePoAmtMaster> getPoFilter(String schemeName) {
		return schemInputAllDAO.getPoFilter(schemeName);
	}

	
	@Override
	public List<SchemeEaMaster> getEaVariables(String schemeName) {
		return schemInputAllDAO.getEaVaraibles(schemeName);
	}

	@Override
	public void saveEaFilter(SchemeEaFilterCondMaster ea) {
		schemInputAllDAO.saveEaFilter(ea);
	}
	
	@Override
	public void savePoFilter(SchemePoAmtMaster po) throws SQLException {
		schemInputAllDAO.savePoFilter(po);
	}

	@Override
	public List<SchemePoMaster> getPoValues(String schemeName) {
		return schemInputAllDAO.getPoValues(schemeName);
	}

	@Override
	public boolean schemeNameVal(String schemeName, int circleId) {
		return schemInputAllDAO.schemeNameVal(schemeName, circleId);
	}

	@Override
	public boolean compNameVal(String compName) {
		return schemInputAllDAO.compNameVal(compName);
	}

	@Override
	public int deleteComp(int schemeId, int compId) {
		return schemInputAllDAO.deleteComp(schemeId, compId);
	}

	@Override
	public void updateComp(int schemeId, int compId, CompMaster compInput) {
		 schemInputAllDAO.updateComp(schemeId, compId, compInput);
	}

	@Override
	public void updatePoFilterVflag(String schemeName, int compId, int condId,	SchemePoAmtMaster po) {
		schemInputAllDAO.updatePoFilterVflag(schemeName, compId, condId, po);
	}

	@Override
	public void updatePoVflag(String schemeName, int compId, int condId, SchemePoMaster po) {
		schemInputAllDAO.updatePoVflag(schemeName, compId, condId, po);
	}

	@Override
	public void updateEaVflag(String schemeName, int compId, int condId, SchemeEaMaster ea) {
		schemInputAllDAO.updateEaVflag(schemeName, compId, condId, ea);
	}

	@Override
	public void updateEaFilterVflag(String schemeName, int compId, int condId,	int filtId, SchemeEaFilterCondMaster ea) {
		schemInputAllDAO.updateEaFilterVflag(schemeName, compId, condId, filtId, ea);
	}

	@Override
	public void updateCovVflag(String schemeName, int compId, int condId, SchemeAcMaster addCov) {
		schemInputAllDAO.updateCovVflag(schemeName, compId, condId, addCov);
	}

	@Override
	public void updateRegZoneVflag(RegZoneMaster rzMaster) {
		schemInputAllDAO.updateRegZoneVflag(rzMaster);
	}

	@Override
	public void updateCompVflag(int schemeId, int compId, CompMaster compInput) {
		schemInputAllDAO.updateCompVflag(schemeId, compId, compInput);
	}

	@Override
	public void updateTqVflag(String schemeName, int compId, int condId, SchemeTqMaster tq) {
		schemInputAllDAO.updateTqVflag(schemeName, compId, condId, tq);
	}

	@Override
	public List<SchemeMaster> searchScheme(String Scheme) {
		return schemInputAllDAO.searchScheme(Scheme);
	}

	/*@Override
	public String getCircle(String schemeName) {
		
		return schemInputAllDAO.getCircle(schemeName);
	}*/

	@Override
	public boolean isFileUpload(String schemeName, int compId) {
		return schemInputAllDAO.isFileUpload(schemeName, compId);
	}

	@Override
	public User getUserCircle(String userName) {
		return schemInputAllDAO.getUserCircle(userName);
	}

	public String schemeUpdateOldToNew(SchemeMaster schemeMaster, int month){
		return schemInputAllDAO.schemeUpdateOldToNew(schemeMaster, monthName(schemeMaster.getMonth()));
	}

	@Override
	public boolean eaVarNameVal(String eaVarName) {
		return schemInputAllDAO.eaVarNameVal(eaVarName);
	}

	private String monthName(int month){
		String monthName="";
		switch(month){
		case 0:monthName = "JAN";
		break;
		case 1:monthName = "FEB";
		break;
		case 2:monthName = "MAR";
		break;
		case 3:monthName = "APR";
		break;
		case 4:monthName = "MAY";
		break;
		case 5:monthName = "JUN";
		break;
		case 6:monthName = "JUL";
		break;
		case 7:monthName = "AUG";
		break;
		case 8:monthName = "SEP";
		break;
		case 9:monthName = "OCT";
		break;
		case 10:monthName = "NOV";
		break;
		case 11:monthName = "DEC";
		break;
		}
		return monthName;
	}

	@Override
	public String insertNewRowPo(SchemePoMaster po, String param) throws Exception {
		return schemInputAllDAO.insertNewRowPo(po, param);
	}

	@Override
	public void insertNewRowPo(SchemePoMaster po) throws Exception {
		schemInputAllDAO.insertNewRowPo(po);
	}

}

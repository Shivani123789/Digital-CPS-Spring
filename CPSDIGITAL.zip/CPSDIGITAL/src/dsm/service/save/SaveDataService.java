package dsm.service.save;

import java.sql.SQLException;
import java.util.List;

import dsm.model.DB.CompMaster;
import dsm.model.DB.RegZoneMaster;
import dsm.model.DB.RoprMaster;
import dsm.model.DB.SchemeAcMaster;
import dsm.model.DB.SchemeEaFilterCondMaster;
import dsm.model.DB.SchemeEaMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemePoAmtMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.po.SchemePoMaster;
import dsm.model.user.User;



public interface SaveDataService {

	public boolean eaVarNameVal(String eaVarName);
	
	public boolean saveScheme(SchemeMaster sm);
	
	public void deleteScheme(SchemeMaster sm);
	
	public User getUserCircle(String userName);
	
	public List<SchemeMaster> searchScheme(String Scheme);
	
	public boolean isFileUpload(String schemeName,int compId);
	
	//public String getCircle(String schemeName);
	
	public void updatePoFilterVflag(String schemeName,int compId,int condId,SchemePoAmtMaster po);
	
	public void updatePoVflag(String schemeName,int compId,int condId,SchemePoMaster po);
	
	public void updateEaVflag(String schemeName,int compId,int condId,SchemeEaMaster ea);
	
	public void updateEaFilterVflag(String schemeName,int compId,int condId,int filtId,SchemeEaFilterCondMaster ea);
	
	public void updateCovVflag(String schemeName,int compId,int condId,SchemeAcMaster addCov);
	
	public void updateRegZoneVflag(RegZoneMaster rzMaster);
	
	public void updateCompVflag(int schemeId,int compId,CompMaster compInput);
	
	public void updateTqVflag(String schemeName,int compId,int condId,SchemeTqMaster tq);
	
	public String saveComponent(CompMaster cm) throws Exception;
	
	public void saveRegion(RegZoneMaster reg) throws Exception;
	
	public void deleteRegZone(int regZoneId);
	
	public void updateRegZone(RegZoneMaster rzMaster);
	
	public void saveAddCovCond(SchemeAcMaster acov);
	
	public void saveTq(SchemeTqMaster tq);
	
	public void saveEa(SchemeEaMaster ea) throws SQLException;
	
	public void saveEaFilter(SchemeEaFilterCondMaster ea);
	
	public void savePo(SchemePoMaster po) throws SQLException;
	
	public void savePoFilter(SchemePoAmtMaster po) throws SQLException;
	
	public int getCompCount(String SchemeName,int circleId);
	
	public List<RegZoneMaster> getRegion(String SchemeName);
	
	public List<SchemeAcMaster> getCov(String SchemeName) throws SQLException;
	
	public List<SchemeTqMaster> getTq(String SchemeName);
	
	public List<SchemeEaMaster> getEa(String SchemeName);
	
	public List<SchemeEaMaster> getEaVariables(String SchemeName);
	
	public List<SchemeEaFilterCondMaster> getEaFilter(String schemeName);
	
	public List<SchemePoMaster> getPo(String SchemeName);
	
	public List<SchemePoMaster> getPoValues(String SchemeName);
	
	public List<SchemePoAmtMaster> getPoFilter(String schemeName);
	
	public List<RoprMaster> getRopr();
	
	public boolean schemeNameVal(String schemeName,int circleId);
	
	public boolean compNameVal(String compName);
	
	public int deleteComp(int schemeId,int compId);
	
	public void updateComp(int schemeId,int compId,CompMaster compInput);
	
	public String schemeUpdateOldToNew(SchemeMaster schemeMaster, int month);	
	
	public String insertNewRowPo(SchemePoMaster po, String param) throws Exception;
	
	public void insertNewRowPo(SchemePoMaster po) throws Exception;
}

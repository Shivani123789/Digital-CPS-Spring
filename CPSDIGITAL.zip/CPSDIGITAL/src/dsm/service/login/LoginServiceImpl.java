package dsm.service.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dsm.dao.login.LoginDAO;
import dsm.model.user.User;

@Service
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDAO loginDAO;
	
	@Override
	public User getUserDetails(String userName) {
		return loginDAO.getUserDetails(userName);
	}

}

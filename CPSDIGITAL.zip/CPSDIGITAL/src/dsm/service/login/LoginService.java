package dsm.service.login;

import dsm.model.user.User;

public interface LoginService {
	
	public User getUserDetails(String userName);
}

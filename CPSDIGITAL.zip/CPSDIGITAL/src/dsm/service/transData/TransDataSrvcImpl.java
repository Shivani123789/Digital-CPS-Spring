package dsm.service.transData;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dsm.dao.transData.TransDataDAO;
import dsm.model.DB.CompMaster;
import dsm.model.DB.InputTypeMasterVO;
import dsm.model.DB.PaymentDetailVO;
import dsm.model.DB.PaymentVO;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ShellScriptPojo;
import dsm.model.DB.UniverseMasterVO;
import dsm.module.constant.DsmConstants;


@Service
public class TransDataSrvcImpl implements TransDataSrvc {

	@Autowired
	TransDataDAO transDataDAO = null;

	@Override
	public List<CompMaster> searchTransactionData(String filtertype, String startDate, String endDate, int circleId) {
		
		return transDataDAO.searchTransactionData(filtertype, startDate, endDate, circleId);
	}

	@Override
	public List<SchemeTqMaster> getTransactionSubData(int schemeId, int compId,int circleId) {
		
		return transDataDAO.getTransactionSubData(schemeId, compId, circleId);
	}

	@Override
	public List<SchemeTqMaster> getTransactionSubEAData(int schemeId, int compId,int circleId){
		
		return transDataDAO.getTransactionSubEAData(schemeId, compId, circleId);
	}

	@Override
	public List<PaymentVO> getTransactionPaymentData(dsm.model.search.SearchScheme search) {
		
		return transDataDAO.getTransactionPaymentData(search);
	}

	@Override
	public List<PaymentDetailVO> getTransactionSubPaymentData(int paymentId, String circleCode) {
		
		return transDataDAO.getTransactionSubPaymentData(paymentId, circleCode);
	}

	@Override
	public List<InputTypeMasterVO> getTransactionUniverseData() {
		
		return transDataDAO.getTransactionUniverseData();
	}

	@Override
	public List<UniverseMasterVO> getTransactionSubUniverseData(int universeId, String startDt, String endDt, final String circleCode,String condiParam) {
	
		return transDataDAO.getTransactionSubUniverseData(universeId, startDt,  endDt,circleCode,condiParam);
	}

	@Override
	public String getExtractDataTime(ShellScriptPojo shellScript) {
		int time = transDataDAO.getCheckExtractDataTime(shellScript);
		System.out.println("diff time :::: "+time+"\t type ======>>>> "+shellScript.getType());
		String value="";
		if((time != -1 && time < 3)){
			int i = (time==0 ? 2 : (3 - time));
			if("D".equalsIgnoreCase(shellScript.getType()) || "O".equalsIgnoreCase(shellScript.getType())){
				value = DsmConstants.TRANS_DATA_LAST_EXECUTE_MSG +"<br> Please retry after  "+ i +" minutes.";
				return value;
			}else {
				if((time != -1 && time < 16)){
					int j = (time==0 ? 15 : (16 - time));
					value = DsmConstants.TRANS_DATA_LAST_EXTRACT_MSG +"<br> Please retry after  "+ j +" minutes.";
				return value;
				}
			}
			
		}else if((time != -1 && time > 4) && ("D".equalsIgnoreCase(shellScript.getType()) || "O".equalsIgnoreCase(shellScript.getType()))){
			transDataDAO.getUpdateExtractDataTime(shellScript);
		}else if(time != -1 && time > 17){
			//update code
			transDataDAO.getUpdateExtractDataTime(shellScript);
		}if((time != -1 && time < 16) && !("D".equalsIgnoreCase(shellScript.getType()) || "O".equalsIgnoreCase(shellScript.getType()))){
			int j = (time==0 ? 15 : (16 - time));
			value = DsmConstants.TRANS_DATA_LAST_EXTRACT_MSG +"<br> Please retry after  "+ j +" minutes.";
		return value;
		}else if(time == -1){
			//insert code
			transDataDAO.getInsertExtractDataTime(shellScript);
		}
		return null;
	}
	

	@Override
	public String getExtractDataTimeMinLimit(ShellScriptPojo shellScript) {
		int time = transDataDAO.getCheckExtractDataTime(shellScript);
		int mins = transDataDAO.getCheckExtractDataMinLimit(shellScript.getType());
		System.out.println("diff time :::: "+time+"\t type ======>>>> "+shellScript.getType());
		String value="";
		if((time != -1 && mins != 0 && time < (mins+1))){
					int j = (time==0 ? mins : (((mins+1) - time)));
					value = "Next 'Data Extraction' can happen after "+mins+" minutes of previous 'Extraction'." +"<br> Please retry after  "+ j +" minutes.";
				return value;
		}else if(time != -1 && mins!=0 && time > (mins+2)){
			//update code
			transDataDAO.getUpdateExtractDataTime(shellScript);
		}else if(time == -1){
			transDataDAO.getInsertExtractDataTime(shellScript);
		}
		return null;
	}

	
}

package dsm.service.transData;

import java.util.List;


import dsm.model.DB.CompMaster;
import dsm.model.DB.InputTypeMasterVO;
import dsm.model.DB.PaymentDetailVO;
import dsm.model.DB.PaymentVO;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ShellScriptPojo;
import dsm.model.DB.UniverseMasterVO;
import dsm.model.search.SearchScheme;

public interface TransDataSrvc {

	public List<CompMaster> searchTransactionData(String filtertype, String startDate, String endDate, int circleId);
	
	public List<SchemeTqMaster> getTransactionSubData(int schemeId, int compId,int circleId);
	
	public List<SchemeTqMaster> getTransactionSubEAData(int schemeId, int compId,int circleId);
	
	public List<PaymentVO> getTransactionPaymentData(SearchScheme search);
	
	public List<PaymentDetailVO> getTransactionSubPaymentData(int paymentId, String circleCode);
	
	public List<InputTypeMasterVO> getTransactionUniverseData();
	
	public List<UniverseMasterVO> getTransactionSubUniverseData(int universeId, String startDt, String endDt, final String circleCode, String condiParam);
	
	public String getExtractDataTime(ShellScriptPojo shellScript);
	
	public String getExtractDataTimeMinLimit(ShellScriptPojo shellScript);
}

package dsm.service.admin;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import dsm.dao.admin.AdminDAO;
import dsm.model.DB.AttrMappingFiledSet;
import dsm.model.DB.CheckBaselineVO;
import dsm.model.DB.EntAttrMapping;
import dsm.model.DB.HierarchyMismatchVO;
import dsm.model.DB.HierarchySuspense;
import dsm.model.DB.StmtReqMapping;
import dsm.model.form.CircleSchedular;


@Service
public class AdminServiceImpl implements AdminService{

	@Autowired
	private AdminDAO adminDAO;
	
	@Override
	public List<HierarchySuspense> getHierarchySuspense(String startDt, String endDt, String circleCode) throws Exception{
		return adminDAO.getHierarchySuspense(startDt, endDt, circleCode);
	}

	@Override
	public String getExecuteHierarchyStamp(String startDt, String endDt, String qualify, String circle, int circleId, int unid) {
		return adminDAO.getExecuteHierarchyStamp(startDt, endDt, qualify, circle, circleId, unid);
	}

	@Override
	public String updateCircleSchedular(CircleSchedular circleSchedular) {
		return adminDAO.updateCircleSchedular(circleSchedular);
	}

	@Override
	public CircleSchedular getFrcDenoCircleSchedular(CircleSchedular circleSchedular) {
		return adminDAO.getFrcDenoCircleSchedular(circleSchedular);
	}

	@Override
	public String updateDenoSetCircleSchedular(CircleSchedular circleSchedular) {
		return adminDAO.updateDenoSetCircleSchedular(circleSchedular);
	}

	@Override
	public List<HierarchyMismatchVO> getHierarchyMismatch(String circleCode,String startDt, String endDt, String type) throws Exception {
		return adminDAO.getHierarchyMismatch(circleCode, startDt, endDt, type);
	}

	@Override
	public List<CheckBaselineVO> getScmDataAnalysis(int circleCode, String startDt, String endDt, int schemeId, int compId, String type)
			throws Exception {
		return adminDAO.getScmDataAnalysis(circleCode, startDt, endDt, schemeId, compId, type);
	}

	@Override
	public List<EntAttrMapping> getAttrMapping(int circleId) throws Exception {
		return adminDAO.getAttrMapping(circleId);
	}

	@Override
	public List<AttrMappingFiledSet> getAttrMappingFieldSet(int circleId, String attriType) throws Exception {
		return adminDAO.getAttrMappingFieldSet(circleId,attriType);
	}

	@Override
	public String saveAttrMapping(EntAttrMapping obj) throws Exception {
		return adminDAO.saveAttrMapping(obj);
	}

	@Override
	public String updateAttrMapping(EntAttrMapping obj) throws Exception {
		return adminDAO.updateAttrMapping(obj);
	}

	@Override
	public boolean deleteAttrMapping(EntAttrMapping obj) throws Exception {
		return adminDAO.deleteAttrMapping(obj);
	}

	@Override
	public List<AttrMappingFiledSet> getAttrMappingCoreFieldSet() throws Exception {
		return adminDAO.getAttrMappingCoreFieldSet();
	}
	
	@Override
	public List<StmtReqMapping> getStmtReq(int circleId, String circleCode, String endDt, String serviceType) throws Exception {
		return adminDAO.getStmtReq(circleId,circleCode,endDt,serviceType);
	}

	@Override
	public List<StmtReqMapping> removeScmStmtReq(String circleCode,	String endDt, String stmtCycleId) throws Exception {
		return adminDAO.removeScmStmtReq(circleCode, endDt, stmtCycleId);
	}

	
}

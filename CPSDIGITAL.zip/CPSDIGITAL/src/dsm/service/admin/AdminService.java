package dsm.service.admin;

import java.util.List;

import dsm.model.DB.AttrMappingFiledSet;
import dsm.model.DB.CheckBaselineVO;
import dsm.model.DB.EntAttrMapping;
import dsm.model.DB.HierarchyMismatchVO;
import dsm.model.DB.HierarchySuspense;
import dsm.model.DB.StmtReqMapping;
import dsm.model.form.CircleSchedular;



public interface AdminService {

	public List<HierarchySuspense> getHierarchySuspense(String startDt, String endDt, String circleCode) throws Exception;
	
	public String getExecuteHierarchyStamp(String startDt, String endDt, String qualify, String circle, int circleId, int unid);
	
	public String updateCircleSchedular(CircleSchedular circleSchedular);
	
	public CircleSchedular getFrcDenoCircleSchedular(CircleSchedular circleSchedular);
	
	public String updateDenoSetCircleSchedular(CircleSchedular circleSchedular);public List<HierarchyMismatchVO> getHierarchyMismatch(String circleCode, String startDt, String endDt, String type) throws Exception;
	
	public List<CheckBaselineVO> getScmDataAnalysis(int circleCode, String startDt, String endDt, int schemeId, int compId, String type) throws Exception;

	public List<EntAttrMapping> getAttrMapping(int circleId) throws Exception;

	public List<AttrMappingFiledSet> getAttrMappingFieldSet(int circleId, String attriType) throws Exception;
	
	public String saveAttrMapping(EntAttrMapping obj) throws Exception;

	public String updateAttrMapping(EntAttrMapping obj) throws Exception;

	public boolean deleteAttrMapping(EntAttrMapping obj) throws Exception;

	public List<AttrMappingFiledSet> getAttrMappingCoreFieldSet() throws Exception;
	
	public List<StmtReqMapping> getStmtReq(int circleId, String circleCode, String endDt, String serviceType) throws Exception;
	
	public List<StmtReqMapping> removeScmStmtReq(String circleCode, String endDt, String stmtCycleId) throws Exception;
	

}

package dsm.service.report;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dsm.dao.report.ReportGenerateDAO;
import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.SchemeMaster;
import dsm.model.report.ReportGenerateMaster;

@Service
public class ReportGenerateServiceImpl implements ReportGenerateService{

	@Autowired
	ReportGenerateDAO reportGenerateDAO;
	
	@Override
	public List<SchemeMaster> searchScheme(String Scheme) {
		return reportGenerateDAO.searchScheme(Scheme);
	}

	@Override
	public ReportGenerateMaster reportGenerate(int schemeId,int compId,int circleId,String circleCode){
		return reportGenerateDAO.reportGenerate(schemeId,compId,circleId,circleCode);
	}
	
	@Override
	public List<DistributorStatementPojo> fetchDistributorStmt(String circle,String distId) throws Exception{
		return reportGenerateDAO.fetchDistributorStmt(circle,distId);
	}
	
	@Override
	public List<ReportGenerateMaster> getReportCategory() 
	{
		return reportGenerateDAO.getReportCategory();
	}
	
	@Override
	public List<ReportGenerateMaster> getScmReportCategory() 
	{
		return reportGenerateDAO.getScmReportCategory();
	}
	
	@Override
	public List<ReportGenerateMaster> reportNameStore(String circle) 
	{
		return reportGenerateDAO.reportNameStore(circle);
	}
	
	@Override
	public String getReportPath(int reportId)
	{
		return reportGenerateDAO.getReportPath(reportId);
	}
	
	@Override
	public String callProcReportScheme(int schemeId,int compId,String startDate,String endDate,String scmStatus,String payoutFlag,String paymentFlag,String entityType,String reportNameId,String category)
	{
		return reportGenerateDAO.callProcReportScheme(schemeId,compId,startDate, endDate, scmStatus, payoutFlag, paymentFlag, entityType, reportNameId,category);
	}
	
	@Override
	public String callProcMonthScheme(String startDate,String EndDate,String entityId,int conNo,String entityType,String reportName)
	{
		return reportGenerateDAO.callProcMonthScheme(startDate,EndDate,entityId, conNo, entityType,reportName);
	}
	

}

package dsm.service.report;

import java.util.List;

import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.SchemeMaster;
import dsm.model.report.ReportGenerateMaster;

public interface ReportGenerateService {

	public List<SchemeMaster> searchScheme(String schemeName) throws Exception;
	
	public ReportGenerateMaster reportGenerate(int schemeId,int compId,int circleId,String circleCode) throws Exception;
	
	public List<DistributorStatementPojo> fetchDistributorStmt(String circle,String distId) throws Exception;
	
	public List<ReportGenerateMaster> getReportCategory() throws Exception;
	
	public List<ReportGenerateMaster> getScmReportCategory() throws Exception;
	
	public List<ReportGenerateMaster> reportNameStore(String circle) throws Exception;
	
	public String getReportPath(int reportId) throws Exception;
	
	public String callProcReportScheme(int schemeId,int compId,String startDate,String endDate,String scmStatus,String payoutFlag,String paymentFlag,String entityType,String reportNameId,String category) throws Exception;
	
	public String callProcMonthScheme(String startDate,String EndDate,String entityId,int conNo,String entityType,String reportName) throws Exception;
	
}

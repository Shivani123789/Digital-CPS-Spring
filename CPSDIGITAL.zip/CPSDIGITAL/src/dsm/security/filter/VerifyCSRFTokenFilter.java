package dsm.security.filter;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class VerifyCSRFTokenFilter implements Filter {

	static SecureRandom	csrftoken	= new SecureRandom();
	//Properties prop = null;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		//String cpsHostIp = new File(System.getProperty("SCHEME_STUDIO_CONFIG_PATH")).getPath();
		//cpsHostIp = cpsHostIp + "/LdapConfig/LoginLdap.properties";
		//prop = new Properties();
		//InputStream in;
		/*try {
			//in = new FileInputStream(cpsHostIp);
			//prop.load(in);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	@Override
	public void destroy() {
	}
	
	
	public boolean isAjaxRequest(HttpServletRequest request) {
		//System.out.println("isAjaxRequest :: "+ ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))));
		return "XMLHttpRequest".equals(request.getHeader("X-Requested-With"));
	}

	@SuppressWarnings({ "unchecked", "unused" })
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		/*String tokenfromcookie[] = new String[10];
		String csrftoken = null;
		String truetokenfromcookie =null;
		int length = 0;
		boolean flag = false;
		HttpServletRequest httprequest = (HttpServletRequest) request;
		HttpSession session = httprequest.getSession();
		Set<String> cookieStr = null;
		if (httprequest.getMethod().equalsIgnoreCase("POST")) {
			try {
				HttpServletResponse httpresponse = (HttpServletResponse) response;
				Cookie cookie[] = httprequest.getCookies();
				for (int i = 0; i < cookie.length; i++) {
					if (cookie[i].getName().equals("csrf")) {
						tokenfromcookie[i] = cookie[i].getValue();
						length++;
					}
				}

				if (isAjaxRequest(httprequest)) {
					csrftoken = httprequest.getHeader("csrf");
				} else {
					csrftoken = httprequest.getParameter("csrf");
					System.out.println("csrftoken :: "+csrftoken);
				}
				if (csrftoken == null || tokenfromcookie.length==0) {
					httpresponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
				} else {
					for(int i=0; i<length; i++)
					{
						if(csrftoken.equals(tokenfromcookie[i]))
						{
							truetokenfromcookie = tokenfromcookie[i];
						}
					}
					if (csrftoken.equals(truetokenfromcookie)) {
						cookieStr = (Set<String>) session.getAttribute("csrfVal");
						for(String str : cookieStr){
							if(str.equalsIgnoreCase(truetokenfromcookie)){
								flag = true;
							}
						}
						System.out.println("flag :::: "+flag);
						if(flag){
							chain.doFilter(request, response);
						}else{
							httpresponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
						}
					} else {
						httpresponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
					}

				}
			} catch (IOException ioe) {
				System.err.println("File not found");
			} catch (ServletException se) {
				System.err.println("VerifyCSRFTokenFilter.doFilter() Exception " + se);
			} catch (NullPointerException npe) {
				System.err.println("VerifyCSRFTokenFilter.doFilter() Exception " + npe);
			} catch (Exception e) {
				System.err.println("VerifyCSRFTokenFilter.doFilter() Exception " + e);
			}
		} else {
			chain.doFilter(request, response);
		}
		 */	













		String tokenfromcookie[] = new String[10];
		//	String csrftoken = null;
		//	String truetokenfromcookie =null;
		int length = 0;
		boolean flag = false;
		HttpServletResponse httpresponse1 = (HttpServletResponse) response;
		HttpServletRequest httprequest = (HttpServletRequest) request;
		HttpSession session = httprequest.getSession(false);
		Set<String> cookStr = null;
		Set<String> setCookStr = new HashSet<String>();

		//String cpsHost = prop.getProperty("CPS_HOST_IP");
		String host = httprequest.getLocalAddr();
		String host1 = httprequest.getServerName();
		//System.out.println("LocalAddr :: "+host+"  :::::::::::  ServerName :: "+host1+"  ::: Status :: "+httpresponse1.getStatus());
		httpresponse1.getStatus();
		if(session != null){
			cookStr = (Set<String>) session.getAttribute("csrfVal");
			//System.out.println("VerifyCSRFTokenFilter :: cookStr :: "+cookStr);172.24.164.5
		}
		//if (cpsHost!= null && cpsHost.equalsIgnoreCase(host1) && cpsHost.equalsIgnoreCase(host)) {
		if(host1!=null || host!=null){
			if (httprequest.getMethod().equalsIgnoreCase("POST") ) {
				try {
					HttpServletResponse httpresponse = (HttpServletResponse) response;
					Cookie cookie[] = httprequest.getCookies();
					//System.out.println("httpresponse :::: "+httpresponse.getStatus());
					for (int i = 0; i < cookie.length; i++) {
						if (cookie[i].getName().equals("csrf")) {
							tokenfromcookie[i] = cookie[i].getValue();
							//if(i!=0)
							//{
							if(request.getParameter("csrf")!=null)
							{
								if(request.getParameter("csrf").contains(tokenfromcookie[i]))
								{
									for(String str : cookStr){
										if(str.equalsIgnoreCase(tokenfromcookie[i])){
											flag = true;
										}
									}
									//	System.out.println("flag :::: "+flag);
									if(flag){
										chain.doFilter(request, response);
									}/*else{
									httpresponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
								}*/
									// chain.doFilter(request, response);
								}
							}
							//}
							//else
							//System.out.println("unable to process req");
							//httpresponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
							length++;
						}
					} 

					/*if (isAjaxRequest(httprequest)) {
					csrftoken = httprequest.getHeader("csrf");
					System.out.println("VerifyCSRFTokenFilter ::: if :::: "+csrftoken);
				} else {

					csrftoken = httprequest.getParameter("csrf");

					System.out.println("VerifyCSRFTokenFilter ::::: else :::: "+csrftoken);
				}
				if (csrftoken == null || tokenfromcookie.length==0) {
					System.out.println("VerifyCSRFTokenFilter :::::: csrftoken == null");
					chain.doFilter(request, response);
				httpresponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
				} else {
					for(int i=0; i<length; i++)
					{
						if(csrftoken.equals(tokenfromcookie[i]))
						{
							truetokenfromcookie = tokenfromcookie[i];
							System.out.println("truetokenfromcookie::::::::::::"+truetokenfromcookie);
						}
					}
					if (csrftoken.equals(truetokenfromcookie)) {
						System.out.println("csrftoken :::::::"+csrftoken);
						chain.doFilter(request, response);
					} else {
						System.out.println("VerifyCSRFTokenFilter :::::: csrftoken .eql"+ truetokenfromcookie );
						httpresponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
					}
					//csrftoken="23456789";

				}*/ 
				} catch (IOException ioe) {
					System.err.println("File not found");
				} catch (ServletException se) {
					System.err.println("VerifyCSRFTokenFilter.doFilter() Exception " + se);
				} catch (NullPointerException npe) {
					System.err.println("VerifyCSRFTokenFilter.doFilter() Exception " + npe);
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				//System.out.println("VerifyCSRFTokenFilter :::::: else  :::::" );
				if(!httprequest.getMethod().equals("OPTIONS") && !httprequest.getMethod().equals("TRACE"))
					chain.doFilter(request, response);
				else
					httpresponse1.sendError(HttpServletResponse.SC_UNAUTHORIZED);
			}
		}else{
			httpresponse1.sendError(HttpServletResponse.SC_UNAUTHORIZED);
		}
}
}
package dsm.security.filter;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
//import javax.servlet.annotation.WebFilter;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class SetCSRFTokenFilter implements Filter {

	static SecureRandom csrftoken = new SecureRandom();
	
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void destroy() {
    }

    @SuppressWarnings("unchecked")
	@Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {
    	try {
    		HttpServletRequest httprequest = (HttpServletRequest) request;
    		HttpSession session = httprequest.getSession(false);
    		((HttpServletResponse) response).resetBuffer();
    		//System.out.println("SetCSRFToken || doFilter::::"+csrftoken.nextLong());
    		Cookie cookie = new Cookie("csrf",""+csrftoken.nextLong());
    		Set<String> cookStr = null;
    		if(session != null && session.getAttribute("csrfVal")!=null){
    			cookStr = (Set<String>) session.getAttribute("csrfVal");
    			cookStr.add(cookie.getValue());
    			session.setAttribute("csrfVal", cookStr);
    		}else if(session != null){
    			cookStr = new HashSet<String>();
    			cookStr.add(cookie.getValue());
    			session.setAttribute("csrfVal", cookStr);	
    		}
    		/*cookie.setHttpOnly(true);
    		cookie.setSecure(true);*/
    		((HttpServletResponse) response).addCookie(cookie);
    		HttpServletResponse httpresponse = (HttpServletResponse) response;
    		//System.out.println("httpresponse :::: "+httpresponse.getStatus());
    		chain.doFilter(request, response);
		}catch (IOException ioe){
			System.err.println("File not found");
		}catch (ServletException se) {
			System.err.println("SetCSRFTokenFilter.doFilter() Exception " + se);
		}catch (NullPointerException npe) {
			System.err.println("SetCSRFTokenFilter.doFilter() Exception " +npe);
		}catch (Exception e) {
			System.err.println("SetCSRFTokenFilter.doFilter() Exception " +e);
		}
    }

}

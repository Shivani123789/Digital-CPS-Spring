package dsm.security.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class XSSFilter implements Filter {

	//Properties prop = null;
	
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {/*
    	String cpsHostIp = new File(System.getProperty("SCHEME_STUDIO_CONFIG_PATH")).getPath();
		cpsHostIp = cpsHostIp + "/LdapConfig/LoginLdap.properties";
		prop = new Properties();
		InputStream in;
		try {
			in = new FileInputStream(cpsHostIp);
			prop.load(in);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    */}

    @Override
    public void destroy() {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    	try {
    //	System.out.println("XSS Filter Block || BEG");
    	HttpServletResponse httpresponse1 = (HttpServletResponse) response;
		HttpServletRequest httprequest = (HttpServletRequest) request;
		String host = httprequest.getLocalAddr();
		String host1 = httprequest.getServerName();
		httpresponse1.setHeader("X-Powered-By","");
		 if (httprequest.isSecure())
		 {
			 httpresponse1.setHeader("Strict-Transport-Security", "max-age=31622400; includeSubDomains");
		 	httpresponse1.setHeader("X-XSS-Protection", "1; mode=block ");
		 }
		else
				httpresponse1.sendError(HttpServletResponse.SC_UNAUTHORIZED);
		/*String cpsHostIp = new File(System.getProperty("SCHEME_STUDIO_CONFIG_PATH")).getPath();
		cpsHostIp = cpsHostIp + "LdapConfig/LoginLdap.properties";
		
		InputStream in = new FileInputStream(cpsHostIp);
		
		Properties prop = new Properties();
		prop.load(in);
		*/
		
		//String cpsHost = prop.getProperty("CPS_HOST_IP");
		
		//	System.out.println("LocalAddr1 :: "+host+"  :::::::::::  ServerName1 :: "+host1+"  ::: Status1 :: "+httpresponse1.getStatus());
		//if (cpsHost!=null && cpsHost.equalsIgnoreCase(host1) && cpsHost.equalsIgnoreCase(host))
		if(host1!=null || host!=null)
    		chain.doFilter(new XSSRequestWrapper((HttpServletRequest) request), response);
		else
			httpresponse1.sendError(HttpServletResponse.SC_UNAUTHORIZED);
		}catch (IOException ioe){
			System.err.println("File not found");
		}catch (ServletException se) {
			System.err.println("XSSFilter.doFilter Exception " + se);
		}catch (NullPointerException npe) {
			System.err.println("XSSFilter.doFilter Exception " +npe);
		}catch (Exception e) {
			System.err.println("XSSFilter.doFilter Exception " +e);
		}
    }

}
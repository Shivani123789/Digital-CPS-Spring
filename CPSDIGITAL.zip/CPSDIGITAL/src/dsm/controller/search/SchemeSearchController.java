package dsm.controller.search;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
//import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
//import org.apache.taglibs.standard.tag.common.core.SetSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.dao.form.ConverageInputService;
import dsm.dao.search.SchemeSearchDAO;
import dsm.model.DB.CompMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ScmPayoutVO;
import dsm.model.DB.UpdateCalander;
import dsm.model.form.HoldReleaseAmount;
import dsm.model.form.SchemeCompNFAList;
import dsm.model.submit.SubmitScheme;
import dsm.model.search.SearchScheme;
import dsm.model.user.User;
import dsm.service.search.SchemeSearch;


@Controller
@Scope("session")
@RequestMapping(value="/searchscheme")
public class SchemeSearchController {
	
	@Autowired
	private HttpSession httpSession;

	@Autowired
	private ConverageInputService converageService;
	
	@Autowired
	private SchemeSearch schemeSearchService;
	
	@Autowired
	SchemeSearchDAO schemeEditDAO = null;

	private static Logger logger = Logger.getLogger (SchemeSearchController.class);
	


	
	@RequestMapping(value="submitSchemeChange.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> submitSchemeChange(SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Payout Approval  :: SchemeSearchController : submitSchemeChange()  : Start :: User Id = "+user.getUserName() );
	
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 4 || user.getRoleId() == 5 || user.getRoleId() == 7)){
			try{
				if(httpSession.getAttribute("circleId")!=null)
				{
				int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				schemeName.setCircleId(circleId);
				}
				schemeName.setUserId(user.getUserName());
				
			//	modelMap.put("data",schemeEditDAO.submitSchemePayment(schemeName));
				modelMap.put("success", Boolean.TRUE);
				
				String result = schemeSearchService.submitSchemeChange(schemeName);
				
				modelMap.put("errorMessage", result);
				
				//if(result.equals("Success!!!"))
					modelMap.put("success", Boolean.TRUE);
				//else
				//	modelMap.put("success", Boolean.FALSE);
					if(logger.isDebugEnabled())
						logger.debug("Approvals --> Payout Approval  :: SchemeSearchController : submitSchemeChange()  : Start :: User Id = "+user.getUserName() );
							
			} catch (Exception e) {
				logger.error("Approvals --> Payout Approval  :: SchemeSearchController : submitSchemeChange()   :: User Id = "+user.getUserName()+" Exception :: ",e );
				e.printStackTrace();
				modelMap.put("success", Boolean.FALSE);
				modelMap.put("errorMessage", e.getMessage());
			}
	
		}else{
			modelMap.put("success",Boolean.FALSE);
			modelMap.put("errorMessage", "You are not having this privilege access...");
		}
				return modelMap;
	}

	
	
	
	
	@RequestMapping(value="submitSchemePayment.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> submitSchemePayment(SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Payment  :: SchemeSearchController : submitSchemePayment()  : Start :: User Id = "+user.getUserName() );
	
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 4 || user.getRoleId() == 5 || user.getRoleId() == 7)){
			try{

				if(httpSession.getAttribute("circleId")!=null)
				{
					int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
					schemeName.setCircleId(circleId);
				}
				schemeName.setUserId(user.getUserName());

				//	modelMap.put("data",schemeEditDAO.submitSchemePayment(schemeName));
				modelMap.put("success", Boolean.TRUE);

				logger.debug(" schemeName.getSchemeComp() ::::::: "+ schemeName.getSchemeComp());
				String result = schemeEditDAO.submitSchemePayment(schemeName);

				modelMap.put("errorMessage", result);

				if(result.equals("Success!!!"))
					modelMap.put("success", Boolean.TRUE);
				else
					modelMap.put("success", Boolean.FALSE);
				if(logger.isDebugEnabled())
					logger.debug("Approvals --> Payment  :: SchemeSearchController : submitSchemePayment()  : End :: User Id = "+user.getUserName() );
			
			} catch (Exception e) {
				logger.error("Approvals --> Payment  :: SchemeSearchController : submitSchemePayment()  : User Id = "+user.getUserName()+" Exception ::", e );
				e.printStackTrace();
				modelMap.put("success", Boolean.FALSE);
				modelMap.put("errorMessage", e.getMessage());
			}

		}else{
			modelMap.put("success",Boolean.FALSE);
			modelMap.put("errorMessage", "You are not having this privilege access...");

		}
		return modelMap;
	}

	
	
	
	
	@RequestMapping(value="updateCalander.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> updateCalander(@ModelAttribute UpdateCalander cal) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Execution Calendar  :: SchemeSearchController : updateCalander()  : Start :: User Id = "+user.getUserName() );
	
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 4 || user.getRoleId() == 5 || user.getRoleId() == 6 || user.getRoleId() == 7)){
			try{
				cal.setCircleId(user.getCircleId());
				schemeEditDAO.updateCalander(cal);	
				modelMap.put("success", true);
	
			} catch (Exception e) {
				logger.error("SchemeSearchController : updateCalander()  : Exception :: ",e);
				e.printStackTrace();
				modelMap.put("success", false);
			}
		}else{
			modelMap.put("success", false);
			modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Execution Calendar  :: SchemeSearchController : updateCalander()  : End :: User Id = "+user.getUserName() );
	
		return modelMap;
	}

	
	@RequestMapping(value="getFilterSchemeCal.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getFilterSchemeCal(@ModelAttribute SearchScheme schemeName) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Execution Calendar  :: SchemeSearchController : getFilterSchemeCal()  : Start :: User Id = "+user.getUserName() );
	
		try{
			if(((schemeName.getStartDate()==null) ||(schemeName.getStartDate().length()<1 ))
					||(schemeName.getEndDate()==null)
					)
			{
				Calendar cal = Calendar.getInstance();
				cal.setTime(Calendar.getInstance().getTime());
				cal.add(Calendar.DATE, -30);
				Date dateBefore30Days = cal.getTime();
				
				DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
				
				String startDate = df.format(dateBefore30Days);
				String endDate = df.format(new Date());
				schemeName.setStartDate(startDate);
				schemeName.setEndDate(endDate);
				schemeName.setCondParam("A");
			}
			if(httpSession.getAttribute("circleId")!=null)
			{
				int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				
				schemeName.setCircleId(circleId);
				schemeName.setCircleCode(user.getUserCircleCode());
			//
		
			}
			
			//logger.debug("nullllllllllllllllll"+schemeName.isStage());
			modelMap.put("data",schemeEditDAO.searchSchemeExecCal(schemeName));
			if(logger.isDebugEnabled())
				logger.debug("Approvals --> Execution Calendar  :: SchemeSearchController : getFilterSchemeCal()  : End :: User Id = "+user.getUserName() );
			
		} catch (Exception e) {
			logger.error("SchemeSearchController : getFilterSchemeCal()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	
	@RequestMapping(value="getFilterSchemeApprove.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getFilterSchemeApprove(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Payout Approval  :: SchemeSearchController : getFilterSchemeApprove()  : Start :: User Id = "+user.getUserName() );
	
	//	logger.info("Entered into getFilterSchemeApprove ");
		try{
			logger.debug("SCMName :: "+schemeName.getSchemeComp()+" :: == SID::"+schemeName.getSchemeId());
			if(((schemeName.getStartDate()==null) || (schemeName.getStartDate().length()<1 )) || (schemeName.getEndDate()==null))
			{
				Calendar cal = Calendar.getInstance();
				cal.setTime(Calendar.getInstance().getTime());
				cal.add(Calendar.DATE, -30);
				Date dateBefore30Days = cal.getTime();

				DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");

				String startDate = df.format(dateBefore30Days);
				String endDate = df.format(new Date());
				schemeName.setStartDate(startDate);
				schemeName.setEndDate(endDate);
				schemeName.setCondParam("A");
			}
			if(httpSession.getAttribute("circleId")!=null)
			{
				int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				schemeName.setCircleId(circleId);
				schemeName.setCircleCode(user.getUserCircleCode());
			}
			modelMap.put("data",schemeEditDAO.searchSchemeApprove(schemeName));
			if(logger.isDebugEnabled())
				logger.debug("Approvals --> Payout Approval  :: SchemeSearchController : getFilterSchemeApprove()  : End :: User Id = "+user.getUserName() );
		
		} catch (Exception e) {
			logger.error("SchemeSearchController : getFilterSchemeApprove()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
	
	
	@RequestMapping(value="getFilterSchemeView.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getFilterSchemeView(@ModelAttribute SearchScheme schemeName) throws Exception {
		logger.debug("SchemeSearchController getFilterSchemeView Begin ");
		logger.debug("SchemeSearchController getFilterSchemeView CondParam :: "+schemeName.getCondParam()+" FileName::"+schemeName.getFileName()+" stdate::"+schemeName.getStartDate());
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> View  :: SchemeSearchController : getFilterSchemeView()  : Start :: User Id = "+user.getUserName() );
	
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 || user.getRoleId() == 4)){
			try{
				logger.debug(schemeName.getStartDate());
				logger.debug(schemeName.getEndDate());
				logger.debug(schemeName.getCondParam());
				logger.debug(schemeName.getFileName());
				if(((schemeName.getStartDate()==null) ||(schemeName.getStartDate().length()<1 ))
						||(schemeName.getEndDate()==null)
						)
				{
					Calendar cal = Calendar.getInstance();
					cal.setTime(Calendar.getInstance().getTime());
					cal.add(Calendar.DATE, -30);
					Date dateBefore30Days = cal.getTime();
					
					DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
					
					String startDate = df.format(dateBefore30Days);
					String endDate = df.format(new Date());
					schemeName.setStartDate(startDate);
					schemeName.setEndDate(endDate);
					schemeName.setCondParam("D");
				}
				if(httpSession.getAttribute("circleId")!=null)
				{
					int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
					
				schemeName.setCircleId(circleId);
				//
			
				}
				if(schemeName.getFilterBy() != -1){
					if(schemeName.getFilterBy()==1 || schemeName.getFilterBy()==3){
						schemeName.setChangeDesc("or COMP.FILE_NAME is  null");
					}else if(schemeName.getFilterBy()==2){
						schemeName.setChangeDesc("");
					}
					if(schemeName.getFilterBy()==3){
						schemeName.setFileName("ABCDEF12");
						schemeName.setChangeDesc("or COMP.FILE_NAME is null");
					}
				}else{
					schemeName.setChangeDesc("or COMP.FILE_NAME is null");
				}
				
				logger.debug("FileCondi :: "+schemeName.getChangeDesc()+" fileSel ::"+schemeName.getFilterBy());
				//logger.debug("nullllllllllllllllll"+schemeName.isStage());
				
				modelMap.put("data",schemeEditDAO.searchSchemeView(schemeName));
			//	logger.debug("SchemeSearchController getFilterSchemeView End ");
				if(logger.isDebugEnabled())
					logger.debug("Configuration --> View  :: SchemeSearchController : getFilterSchemeView()  : End :: User Id = "+user.getUserName() );
			
			} catch (Exception e) {
				//logger.error("SchemeSearchController : getFilterSchemeView()  : Exception :: "+e.getMessage());
				//e.printStackTrace();
				modelMap.put("success", false);
			}
		}else{
			modelMap.put("success", false);
		}
				return modelMap;
	}

	
	@RequestMapping(value="getFilterSchemeSubmit.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getFilterSchemeSubmit(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Submission  :: SchemeSearchController : getFilterSchemeSubmit()  : Start :: User Id = "+user.getUserName() );

		try{
			if(schemeName.getStartDate()==null && httpSession.getAttribute("startDate")!=null)
			{
				schemeName.setStartDate(httpSession.getAttribute("startDate").toString());
				schemeName.setEndDate(httpSession.getAttribute("endDate").toString());
				schemeName.setCondParam(httpSession.getAttribute("condParam").toString());
				schemeName.setSchemeComp(httpSession.getAttribute("schemeComp").toString());
				schemeName.setSchemeId(Integer.parseInt(httpSession.getAttribute("schemeId").toString()));
				schemeName.setComponentName(httpSession.getAttribute("componentName").toString());
				schemeName.setPayTo(Integer.parseInt(httpSession.getAttribute("payTo").toString()));
				//schemeName.setPage(Integer.parseInt(httpSession.getAttribute("page").toString()));
				//schemeName.setStart(Integer.parseInt(httpSession.getAttribute("start").toString()));
				
			}
			else
			{
				httpSession.setAttribute("startDate", schemeName.getStartDate());
				httpSession.setAttribute("endDate", schemeName.getEndDate());
				httpSession.setAttribute("condParam", schemeName.getCondParam());
				httpSession.setAttribute("schemeComp", schemeName.getSchemeComp());
				httpSession.setAttribute("schemeId", schemeName.getSchemeId());
				httpSession.setAttribute("componentName", schemeName.getComponentName());
				httpSession.setAttribute("payTo", schemeName.getPayTo());
				//httpSession.setAttribute("page", schemeName.getPage());
				//httpSession.setAttribute("start", schemeName.getStart());
				
			}
			if(((schemeName.getStartDate()==null) ||(schemeName.getStartDate().length()<1 ))
					||(schemeName.getEndDate()==null)
					)
			{
				Calendar cal = Calendar.getInstance();
				cal.setTime(Calendar.getInstance().getTime());
				cal.add(Calendar.DATE, -30);
				Date dateBefore30Days = cal.getTime();
				
				DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
				
				String startDate = df.format(dateBefore30Days);
				String endDate = df.format(new Date());
				schemeName.setStartDate(startDate);
				schemeName.setEndDate(endDate);
			
				schemeName.setCondParam("W");
			}
			if(httpSession.getAttribute("circleId")!=null)
			{
				int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				
			schemeName.setCircleId(circleId);
			
		
			}
			
			List<SchemeMaster>  sm = schemeEditDAO.searchSchemeSubmit(schemeName);
			if((sm.size()!=0))
				modelMap.put("totalCount",sm.get(0).getTotalRow());
				modelMap.put("page",schemeName.getPage());
				
			modelMap.put("data",sm);
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Submission  :: SchemeSearchController : getFilterSchemeSubmit()  : End :: User Id = "+user.getUserName() );
		
		} catch (Exception e) {
			logger.error("SchemeSearchController : getFilterSchemeSubmit()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}


	@RequestMapping(value="getFilterSchemeNFA.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getFilterSchemeNFA(@ModelAttribute SearchScheme schemeName, @RequestParam Map<String,String> requestParams) throws Exception {
		
		//logger.debug("Bengin SchemeSearchController getFilterSchemeNFA method ::: ");
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Scheme Approval  :: SchemeSearchController : getFilterSchemeNFA()  : Start :: User Id = "+user.getUserName() );

		try{
			logger.debug("getSchemeComp scm:: "+schemeName.getSchemeComp()+" :::: schemeComp ::::"+requestParams.get("schemeComp"));
			logger.debug("getSchemeId sid:: "+schemeName.getSchemeId()+" :::: schemeId ::::"+requestParams.get("schemeId"));
			logger.debug("getStartDate getStartDate:: "+schemeName.getStartDate());
			if(schemeName.getStartDate()==null)
			{
				schemeName.setStartDate(httpSession.getAttribute("startDate").toString());
				schemeName.setEndDate(httpSession.getAttribute("endDate").toString());
				schemeName.setCondParam(httpSession.getAttribute("condParam").toString());
				schemeName.setSchemeComp(httpSession.getAttribute("schemeComp").toString());
				schemeName.setSchemeId(Integer.parseInt(httpSession.getAttribute("schemeId").toString()));
				schemeName.setPayTo(Integer.parseInt(httpSession.getAttribute("payTo").toString()));
				schemeName.setComponentName(httpSession.getAttribute("componentName").toString());
			}
			else
			{
				httpSession.setAttribute("startDate", schemeName.getStartDate());
				httpSession.setAttribute("endDate", schemeName.getEndDate());
				httpSession.setAttribute("condParam", schemeName.getCondParam());
				httpSession.setAttribute("schemeComp", schemeName.getSchemeComp());
				httpSession.setAttribute("schemeId", schemeName.getSchemeId());
				httpSession.setAttribute("payTo", schemeName.getPayTo());
				httpSession.setAttribute("componentName", schemeName.getComponentName());
			}
				if(schemeName != null && schemeName.getEndDate()!=null)
				schemeName.setCircleId(user.getCircleId());

			if(schemeName != null && schemeName.getStartDate()!=null && schemeName.getEndDate()!=null)
			{
				List<SchemeCompNFAList> nfaList = schemeEditDAO.searchSchemeNFA(schemeName);
				modelMap.put("data",nfaList);
				if((nfaList.size()!=0))
				modelMap.put("totalCount",nfaList.get(0).getTotalCount());
//				if(nfaList.isEmpty()){
//					modelMap.put("success", );
//				//	modelMap.put("data", 0);
//					
//				}
				if(logger.isDebugEnabled())
					logger.debug("Approvals --> Scheme Approval  :: SchemeSearchController : getFilterSchemeNFA()  : End :: User Id = "+user.getUserName() );

			}

		} catch (Exception e) {
			logger.error("SchemeSearchController : getFilterSchemeNFA()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}


	
	@RequestMapping(value="loadScheme.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> loadScheme(String schemeName) throws Exception {
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create  :: SchemeSearchController : loadScheme()  : Start :: User Id = "+user.getUserName() );

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			if(schemeName!=null)
			modelMap.put("data",schemeSearchService.loadScheme(schemeName));
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create  :: SchemeSearchController : loadScheme()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("SchemeSearchController : loadScheme()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}


/*	@RequestMapping(value="loadSchemeForEdit.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> loadSchemeForEdit(String schemeName) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			//logger.debug("schemeName :::: "+schemeName+"\t eq::"+ !"".equalsIgnoreCase(schemeName));
		//	if(schemeName!=null && !"".equalsIgnoreCase(schemeName))
			modelMap.put("data",schemeEditDAO.loadSchemeForEdit(schemeName));
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}
*/
	
	@RequestMapping(value="loadSchemeForEdit.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> loadSchemeForEdit(SearchScheme searchScheme) throws Exception {
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create  :: SchemeSearchController : loadSchemeForEdit()  : Start :: User Id = "+user.getUserName() );

		//logger.debug("SchemeSearchController || loadSchemeForEdit || BEG ");
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			
			if(searchScheme.getStartDate()!=null && searchScheme.getStartDate().length()!=0)
			{
				httpSession.setAttribute("startDateEdit", searchScheme.getStartDate());
				httpSession.setAttribute("endDateEdit", searchScheme.getEndDate());
				httpSession.setAttribute("payToEdit", searchScheme.getPayTo());
			}
			else
			{
				searchScheme.setStartDate(httpSession.getAttribute("startDateEdit").toString());
				searchScheme.setEndDate(httpSession.getAttribute("endDateEdit").toString());
				searchScheme.setPayTo(Integer.parseInt(httpSession.getAttribute("payToEdit").toString()));
				
			}
			
			//logger.debug("schemeName :::: "+schemeName+"\t eq::"+ !"".equalsIgnoreCase(schemeName));
		//	if(schemeName!=null && !"".equalsIgnoreCase(schemeName))
			modelMap.put("data",schemeEditDAO.loadSchemeForEdit(searchScheme));
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create  :: SchemeSearchController : loadSchemeForEdit()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("SchemeSearchController : loadSchemeForEdit()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	@RequestMapping(value="loadCompForEdit.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> loadCompForEdit(SearchScheme searchScheme,@RequestParam Map<String,String> requestParams) throws Exception {
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create  :: SchemeSearchController : loadCompForEdit()  : Start :: User Id = "+user.getUserName() );

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			int scmId =  Integer.parseInt(requestParams.get("schemeId"));
			System.out.println("scmid :::: "+scmId);
			   if(scmId != 0)
				 httpSession.setAttribute("schemeId", searchScheme.getSchemeId());
			   else
				 searchScheme.setSchemeId(scmId);
			
			modelMap.put("data",schemeEditDAO.loadCompForEdit(searchScheme));
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create  :: SchemeSearchController : loadCompForEdit()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
logger.error("SchemeSearchController : loadCompForEdit()  : Exception :: ",e);
			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}

	
	
	

	
	@RequestMapping(value="showError.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> showError(SubmitScheme schemeName) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Submission  :: SchemeSearchController : showError()  : Start :: User Id = "+user.getUserName() );

		if(user != null && ( user.getRoleId() == 1 || user.getRoleId() == 2)){
			try{
				//schemeName.setCircleId(3);
				schemeName.setSubmitDate(new Date());
				schemeName.setUserId(1);
				schemeName.setStartDate(new Date());
				schemeName.setEndDate(new Date());
				schemeName.setValidityFlag("S");
				schemeName.setCircleCode(httpSession.getAttribute("circleCode").toString());
				schemeName.setUserName(user.getUserName());
				schemeName.setCircleId(user.getCircleId());
				String result = schemeEditDAO.showError(schemeName);  //schemeSearchService.validateScheme(schemeName);
				modelMap.put("success",Boolean.TRUE);
				modelMap.put("errorMessage", result);
				if(logger.isDebugEnabled())
					logger.debug("Configuration --> Submission  :: SchemeSearchController : showError()  : End :: User Id = "+user.getUserName() );

			}
			 catch (Exception e) {
				 logger.error("SchemeSearchController : showError()  : Exception :: ",e);
				e.printStackTrace();
				modelMap.put("success",Boolean.FALSE);
				modelMap.put("errorMessage", e.getMessage());
			}
		}else{
			modelMap.put("success",Boolean.FALSE);
			modelMap.put("errorMessage", "You are not having this privilege access...");
		}
				return modelMap;
	}
	

	
	
	
	
	
	
	@RequestMapping(value="submitScheme.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> submitScheme(SubmitScheme schemeName,HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Submission  :: SchemeSearchController : submitScheme()  : Start :: User Id = "+user.getUserName() );

		if(user!=null && (user.getRoleId() == 1 || user.getRoleId() == 2)){
			
			String schName = (String)httpSession.getAttribute("schemeName");
			if(schName !=null && schName.equalsIgnoreCase(schemeName.getSchemeName())){
				httpSession.removeAttribute("schemeName");
			}
			try{
				schemeName.setSubmitDate(new Date());
				schemeName.setUserId(1);
				schemeName.setStartDate(new Date());
				schemeName.setEndDate(new Date());
				schemeName.setValidityFlag("S");
				schemeName.setCircleCode(httpSession.getAttribute("circleCode").toString());
				schemeName.setUserName(user.getUserName());
				schemeName.setCircleId(user.getCircleId());
				String result =  schemeSearchService.validateScheme(schemeName);
				modelMap.put("success",Boolean.TRUE);
				modelMap.put("errorMessage", result);
				if(logger.isDebugEnabled())
					logger.debug("Configuration --> Submission  :: SchemeSearchController : submitScheme()  : End :: User Id = "+user.getUserName() );

			}
			 catch (Exception e) {
				 logger.error("SchemeSearchController : submitScheme()  : Exception :: ",e);
				e.printStackTrace();
				modelMap.put("success",Boolean.FALSE);
				modelMap.put("errorMessage", e.getMessage());
			}
				
		}else{
			modelMap.put("success",Boolean.FALSE);
			modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		return modelMap;
	}
	
	
	
	


	@RequestMapping(value="getFilterSchemePayment.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getFilterSchemePayment(@ModelAttribute SearchScheme schemeName) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Payment  :: SchemeSearchController : getFilterSchemePayment()  : Start :: User Id = "+user.getUserName() );

		try{
			logger.debug(schemeName.getStartDate());
			logger.debug(schemeName.getEndDate());
			logger.debug(schemeName.getPayTo());
			if(((schemeName.getStartDate()==null) || (schemeName.getStartDate().length()<1 )) || (schemeName.getEndDate()==null))
			{
				Calendar cal = Calendar.getInstance();
				cal.setTime(Calendar.getInstance().getTime());
				cal.add(Calendar.DATE, -30);
				Date dateBefore30Days = cal.getTime();
				
				DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
				
				String startDate = df.format(dateBefore30Days);
				String endDate = df.format(new Date());
				schemeName.setStartDate(startDate);
				schemeName.setEndDate(endDate);
				schemeName.setCondParam("C");
			}
			if(httpSession.getAttribute("circleId")!=null)
			{
				int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
				
				schemeName.setCircleId(circleId);
			//
		
			}
			
			//logger.debug("nullllllllllllllllll"+schemeName.isStage());
			modelMap.put("data",schemeEditDAO.searchSchemePayment(schemeName));
			if(logger.isDebugEnabled())
				logger.debug("Approvals --> Payment  :: SchemeSearchController : getFilterSchemePayment()  : End :: User Id = "+user.getUserName() );
		
		} catch (Exception e) {
			logger.error("SchemeSearchController : getFilterSchemePayment()  : Exception :: ",e);
			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}
	
	
	@RequestMapping(value="getTransDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransDataSearch(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Reports --> Transaction Data --> Scheme Data :: SchemeSearchController : getTransDataSearch()  : Start :: User Id = "+user.getUserName() );

		try{
			if(schemeName != null && schemeName.getEndDate()!=null)
				schemeName.setCircleId(user.getCircleId());
			if(schemeName != null && schemeName.getStartDate()!=null && schemeName.getEndDate()!=null)
			{
				List<CompMaster> compList = schemeEditDAO.searchTransactionData(schemeName.getCondParam(),schemeName.getStartDate(),schemeName.getEndDate(),schemeName.getCircleId(),schemeName);
				modelMap.put("data",compList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Reports --> Transaction Data --> Scheme Data :: SchemeSearchController : getTransDataSearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("SchemeSearchController : getTransDataSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}


	@RequestMapping(value="getTransSubDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransSubDataSearch(@ModelAttribute SearchScheme schemeName,HttpServletRequest request) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Reports --> Transaction Data --> Scheme Data :: SchemeSearchController : getTransSubDataSearch()  : Start :: User Id = "+user.getUserName() );

		try{
			if(schemeName != null && schemeName.getEndDate()!=null){
				schemeName.setCircleId(user.getCircleId());
				schemeName.setCircleCode(user.getUserCircleCode());
			}if(schemeName != null && schemeName.getSchemeId()!=0)
			{
				
				if("AA".equalsIgnoreCase(schemeName.getPaymentRemarks())){
					List<SchemeTqMaster> tqList = schemeEditDAO.getTransactionSubDataTarget(schemeName.getPaymentRemarks(),schemeName.getSchemeId(), schemeName.getCompId(),user.getCircleId(),user.getUserCircleCode());
					modelMap.put("data",tqList);
				}else{
					List<SchemeTqMaster> tqList = schemeEditDAO.getTransactionSubData(schemeName.getPaymentRemarks(),schemeName.getSchemeId(), schemeName.getCompId(),user.getCircleId(),user.getUserCircleCode());
					modelMap.put("data",tqList);
				}
			}
			if(logger.isDebugEnabled())
				logger.debug("Reports --> Transaction Data --> Scheme Data :: SchemeSearchController : getTransSubDataSearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("SchemeSearchController : getTransSubDataSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}
	
	
	@RequestMapping(value="getHoldDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getHoldDataSearch(@ModelAttribute SearchScheme holdData) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Hold/Release Payment --> Hold Payment :: SchemeSearchController : getHoldDataSearch()  : Start :: User Id = "+user.getUserName() );

		try{
			//modelMap.put("success", false);
			logger.debug("sd: "+holdData.getStartDate()+" ed: "+holdData.getEndDate()+" cond::"+holdData.getCondParam()+" typ:"+holdData.getPayTo());
			List<ScmPayoutVO> payoutList =  schemeEditDAO.loadHoldDataSearch(holdData,user.getCircleId(),user.getUserCircleCode());
			modelMap.put("data",payoutList);
			if(logger.isDebugEnabled())
				logger.debug("Approvals --> Hold/Release Payment --> Hold Payment :: SchemeSearchController : getHoldDataSearch()  : End :: User Id = "+user.getUserName() );
			
		} catch (Exception e) {
			logger.error("SchemeSearchController : getHoldDataSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}
	
	@RequestMapping(value="saveHoldDataAmt.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> saveHoldDataAmt(@ModelAttribute HoldReleaseAmount holdData) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Hold/Release Payment --> Hold Payment :: SchemeSearchController : saveHoldDataAmt()  : Start :: User Id = "+user.getUserName() );

		try{
			logger.debug("holdAmt::::::"+holdData.getHoldAmt());
			holdData.setCircleCode(user.getUserCircleCode());
			holdData.setUserId(user.getUserName());
			String payoutList =  schemeEditDAO.saveHoldAmountData(holdData);
			modelMap.put("success", true);
			modelMap.put("errorMessage",payoutList);
			if(logger.isDebugEnabled())
				logger.debug("Approvals --> Hold/Release Payment --> Hold Payment :: SchemeSearchController : saveHoldDataAmt()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("SchemeSearchController : saveHoldDataAmt()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}

	
	
	@RequestMapping(value="getTotalHoldAmount.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> getTotalHoldAmount(@ModelAttribute SearchScheme holdData) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Hold/Release Payment --> Hold Payment :: SchemeSearchController : getTotalHoldAmount()  : Start :: User Id = "+user.getUserName() );

		try{
			modelMap.put("success", true);
			logger.debug("sd: "+holdData.getStartDate()+" ed: "+holdData.getEndDate()+" cond::"+holdData.getCondParam()+" typ:"+holdData.getPayTo());
			ScmPayoutVO payoutList =  schemeEditDAO.getTotalHoldAmount(holdData,user.getCircleId(),user.getUserCircleCode());
			modelMap.put("totalAmount",payoutList.getTotalAmt());
			modelMap.put("producerId",payoutList.getProducerId());
			modelMap.put("ftaNumber",payoutList.getFtaNumber());
			modelMap.put("vtopupNumber",payoutList.getVtopupNumber());
			modelMap.put("holdAmt",payoutList.getHoldAmt());
			modelMap.put("payToId",payoutList.getPayToId());
			modelMap.put("netHoldAmt",payoutList.getNetHoldAmt());
			if(logger.isDebugEnabled())
				logger.debug("Approvals --> Hold/Release Payment --> Hold Payment :: SchemeSearchController : getTotalHoldAmount()  : End :: User Id = "+user.getUserName() );
			
		} catch (Exception e) {
			logger.error("SchemeSearchController : getTotalHoldAmount()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}
	
	@RequestMapping(value="holdDataProducers.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> holdDataProducers(@ModelAttribute SearchScheme holdData) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Hold/Release Payment --> Hold Payment :: SchemeSearchController : holdDataProducers()  : Start :: User Id = "+user.getUserName() );

		try{
			logger.debug("holdAmt::::::"+holdData.getHoldAmt());
			//holdData.setCircleCode(user.getUserCircleCode());
			//holdData.setUserId(user.getUserName());
			List<HoldReleaseAmount> prodList =  schemeEditDAO.holdDataProducers(holdData,user.getCircleId(),user.getUserCircleCode());
			//modelMap.put("success", true);
			modelMap.put("data",prodList);
			if(logger.isDebugEnabled())
				logger.debug("Approvals --> Hold/Release Payment --> Hold Payment :: SchemeSearchController : holdDataProducers()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("SchemeSearchController : holdDataProducers()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}
	
	@RequestMapping(value="getTotalReleaseAmount.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTotalReleaseAmount(@ModelAttribute SearchScheme releaseData) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Hold/Release Payment --> Release Payment :: SchemeSearchController : getTotalReleaseAmount()  : Start :: User Id = "+user.getUserName() );

		try{
			modelMap.put("success", true);
			logger.debug("getTotalReleaseAmount: "+releaseData.getStartDate()+" ed: "+releaseData.getEndDate());
			List<HoldReleaseAmount> holdReleaseAmount =  schemeEditDAO.getTotalReleaseAmount(releaseData,user.getCircleId(),user.getUserCircleCode());
		modelMap.put("data",holdReleaseAmount);
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Hold/Release Payment --> Release Payment :: SchemeSearchController : getTotalReleaseAmount()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("SchemeSearchController : getTotalReleaseAmount()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}
	
	@RequestMapping(value="updateRelReq.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> updateRelReq(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Hold/Release Payment :: SchemeSearchController : updateRelReq()  : Start :: User Id = "+user.getUserName() );

		String updateRelReqData=requestParams.get("relReqData");
		String remarksVal=requestParams.get("remarksVal");
		logger.debug("SearchSchemeController || updateRelReq || relReqData:"+remarksVal);
		try{
			modelMap.put("success", true);
			logger.debug("SearchSchemeController || updateRelReq || requestParams:"+updateRelReqData);
			String holdReleaseAmount =  schemeEditDAO.updateRelReq(updateRelReqData,remarksVal,user.getCircleId(),user.getUserCircleCode());
			modelMap.put("success", true);
			modelMap.put("errorMessage",holdReleaseAmount);
			if(logger.isDebugEnabled())
				logger.debug("Approvals --> Hold/Release Payment :: SchemeSearchController : updateRelReq()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("SchemeSearchController : updateRelReq()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
}
	
	@RequestMapping(value="loadSchemeCreate.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> loadSchemeCreate(SearchScheme searchScheme) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		httpSession.setAttribute("updateVersion",Boolean.FALSE);
		if(searchScheme.getStartDate()!=null && searchScheme.getStartDate().length()!=0)
		{
			httpSession.setAttribute("startDateCreate", searchScheme.getStartDate());
			httpSession.setAttribute("endDateCreate", searchScheme.getEndDate());
			httpSession.setAttribute("payToCreate", searchScheme.getPayTo());
		}
		else
		{
			searchScheme.setStartDate(httpSession.getAttribute("startDateCreate").toString());
			searchScheme.setEndDate(httpSession.getAttribute("endDateCreate").toString());
			searchScheme.setPayTo(Integer.parseInt(httpSession.getAttribute("payToCreate").toString()));
			
		}
		logger.debug(" SchemeSearch || loadScheme || scheme1: "+searchScheme.getStartDate()+" || endDate:"+searchScheme.getEndDate()+" || payTo:"+searchScheme.getPayTo());
		
		try{
			if(searchScheme!=null)
			modelMap.put("data",schemeSearchService.loadSchemeCreate(searchScheme));
			modelMap.put("success",true);
			
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		logger.debug("data existed===============================>"+modelMap.get("data"));
		return modelMap;
	}
}

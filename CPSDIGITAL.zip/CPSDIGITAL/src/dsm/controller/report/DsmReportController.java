package dsm.controller.report;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.OutputStream;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import dsm.controller.csv.GenerateCSV;
import dsm.model.DB.DistributorStatementPojo;
import dsm.model.DB.PartnerChannelStatementPojo;
import dsm.model.DB.SchemeMaster;
import dsm.model.report.ReportCsvDownload;
import dsm.model.report.ReportGenerateMaster;
import dsm.model.user.User;
import dsm.service.csv.CSVService;
import dsm.service.report.ReportGenerateService;
import dsm.service.stmtGen.StmtGenService;

@Controller
@Scope("session")
@RequestMapping(value="/reports")
public class DsmReportController {

	@Autowired
	private HttpSession httpSession;
	
	@Autowired
	private ReportGenerateService reportGenerateService;
	
	@Autowired
	ServletContext context;
	
	@Autowired
	StmtGenService stmtGenSrvc = null;
	
	@Autowired
	private CSVService csvService;

	private static Logger logger = Logger.getLogger (DsmReportController.class);
	
	@RequestMapping(value="getSearchScheme.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getSearchScheme(String schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			modelMap.put("data",reportGenerateService.searchScheme(schemeName));
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	
	
	/**
     * Handle request to the default page
     */
    @RequestMapping(value = "/reportHomePage.action", method = RequestMethod.POST)
    public String viewHome() {
    	
        return "/report";
    }
    
    /**
	 * Handle request to download a PDF document 
	 */
	@RequestMapping(value = "/downloadPDF.action", method = RequestMethod.GET)
	public ModelAndView downloadExcel(@ModelAttribute SchemeMaster sm,HttpServletRequest request) {
		
		String schemeId = request.getParameter("output");
		String compId = request.getParameter("compId");
		String csvType = request.getParameter("csvType");
		
		User user = (User)httpSession.getAttribute("appUser");
		
		if(logger.isDebugEnabled())
			logger.debug("Reports --> Statment --> View Statement  :: DsmReportController : downloadExcel()  : Start :: User Id = "+user.getUserName() );
		
		logger.debug("csvType :::::: "+csvType);
		
		ReportGenerateMaster reportList = null;
		try{
			//String output =	ServletRequestUtils.getStringParameter(request, "output");
			if(schemeId != null){
				reportList = reportGenerateService.reportGenerate(Integer.parseInt(schemeId),Integer.parseInt(compId),user.getCircleId(),user.getUserCircleCode());
				reportList.setCsvType(csvType);
			}
			if(logger.isDebugEnabled())
				logger.debug("Reports --> Statment --> View Statement  :: DsmReportController : downloadExcel()  : End :: User Id = "+user.getUserName() );
			
		} catch (Exception e) {
				logger.error("Reports --> Statment --> View Statement  :: DsmReportController : downloadExcel()   :: User Id = "+user.getUserName()+" Exception :: ",e );
				e.printStackTrace();
		}
		return new ModelAndView("pdfView", "reportList", reportList);
	}

	/*@RequestMapping(value = "/downloadDistributorViewStmtPDF.action", method = RequestMethod.GET)
	public ModelAndView downloadDistributorViewStmtPDF(@RequestParam Map<String,String> requestParams) {
		User user = (User)httpSession.getAttribute("appUser");
		String distributorId = requestParams.get("distDsm2Id");
		String[] str = requestParams.get("startEndDtParam").split("TO");
		
		List<DistributorStatementPojo> distVoList = null;
	
				try{
					if(user!=null && distributorId != null && str!=null){
						distVoList = stmtGenSrvc.fetchDistributorStmt(distributorId, str[1].trim(), user.getUserCircleCode(),requestParams.get("stmtCycleDt"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("distPdfView", "distributorList", distVoList.get(0));
	}
	*/
	
	@RequestMapping(value = "/downloadChannelPartnerViewStmtPDF.action", method = RequestMethod.GET)
	public ModelAndView downloadDistributorViewStmtPDF(@RequestParam Map<String,String> requestParams) {
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Reports --> Statment --> View Statement  :: DsmReportController : downloadDistributorViewStmtPDF()  : Start :: User Id = "+user.getUserName() );
		
		String distributorId = requestParams.get("distDsm2Id");
		String[] str = requestParams.get("startEndDtParam").split("TO");
		
		List<PartnerChannelStatementPojo> distVoList = null;
	
				try{
					if(user!=null && distributorId != null && str!=null){
						distVoList = stmtGenSrvc.fetchChannelPartnerStmt(distributorId, str[1].trim(), user.getUserCircleCode(),requestParams.get("stmtCycleDt"));
			}
		} catch (Exception e) {
			logger.error("Reports --> Statment --> View Statement  :: DsmReportController : downloadDistributorViewStmtPDF()  :: User Id = "+user.getUserName()+" Exception ::",e );
			e.printStackTrace();
		}
		if(logger.isDebugEnabled())
					logger.debug("Reports --> Statment --> View Statement  :: DsmReportController : downloadDistributorViewStmtPDF()  : End :: User Id = "+user.getUserName() );
				
		return new ModelAndView("distPdfView", "channelPartnerList", distVoList.get(0));
	}
	
	@RequestMapping(value = "/getReportCategory.action")
	public @ResponseBody Map<String,? extends Object> getReportCategory() {
		User user = (User)httpSession.getAttribute("appUser");
    	if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : getReportCategory()  : Start :: User Id = "+user.getUserName() );
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
				try{
					logger.debug("DsmReportController || getReportCategory || BEG ");
					modelMap.put("data",reportGenerateService.getReportCategory());
					modelMap.put("success", true);
			}
		 catch (Exception e) {
			 		logger.error("Reports --> Report  :: DsmReportController : getReportCategory()  :: User Id = "+user.getUserName() +" Exception :: ",e);
		}
				if(logger.isDebugEnabled())
					logger.debug("Reports --> Report  :: DsmReportController : getReportCategory()  : End :: User Id = "+user.getUserName() );
					
		return modelMap;
	}
	

	@RequestMapping(value = "/getScmReportCategory.action")
	public @ResponseBody Map<String,? extends Object> getScmReportCategory() {
		User user = (User)httpSession.getAttribute("appUser");
    	if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : getScmReportCategory()  : Start :: User Id = "+user!=null ? user.getUserName():"" );
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
				try{
					logger.debug("DsmReportController || getScmReportCategory || BEG ");
					modelMap.put("data",reportGenerateService.getScmReportCategory());
					modelMap.put("success", true);
			}
		 catch (Exception e) {
			 		logger.error("Reports --> Report  :: DsmReportController : getScmReportCategory()  :: User Id = "+user!=null ? user.getUserName():""+" Exception ::",e );
				}
				if(logger.isDebugEnabled())
					logger.debug("Reports --> Report  :: DsmReportController : getScmReportCategory()  : End :: User Id = "+user!=null ? user.getUserName():"" );
		return modelMap;
	}
	
	
	@RequestMapping(value = "/getReportName.action")
	public @ResponseBody Map<String,? extends Object> reportNameStore() {
		User user = (User)httpSession.getAttribute("appUser");
    	if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : reportNameStore()  : Start :: User Id = "+user.getUserName() );
		
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
				try{
				//	User user = (User)httpSession.getAttribute("appUser");
					logger.debug("DsmReportController || reportNameStore || BEG ");
					modelMap.put("data",reportGenerateService.reportNameStore(user.getUserCircleCode()));
					modelMap.put("success", true);
					
				}
		 catch (Exception e) {
			 		logger.error("Reports --> Report  :: DsmReportController : reportNameStore()   :: User Id = "+user.getUserName()+" Exception ::",e );
		}
				if(logger.isDebugEnabled())
					logger.debug("Reports --> Report  :: DsmReportController : reportNameStore()  : End :: User Id = "+user.getUserName() );
					
		return modelMap;
	}
	
	@RequestMapping(value="downloadReport.action")
	public void downloadReport(@RequestParam Map<String,String> requestParams, HttpServletRequest request, HttpServletResponse response) throws Exception {
		User user = (User)httpSession.getAttribute("appUser");
    	if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : downloadReport()  : Start :: User Id = "+user.getUserName() );
		
		try {
	    	int BUFFER_SIZE = 100000;
	       logger.debug("DsmReportController || downloadReport || BEG:");
	       String reportPathGenType=reportGenerateService.getReportPath(Integer.parseInt(requestParams.get("reportId")));
	       logger.debug("DsmReportController || downloadReport || reportPath:"+reportPathGenType);
	       String tempReportPathGenType[]=  reportPathGenType.split("::");
	       logger.debug("DsmReportController || downloadReport || type: "+tempReportPathGenType[1]);
	       if(reportPathGenType==null || "".equals(reportPathGenType))
	       {
	    	   logger.debug("No path available for string");
	    	   
	       }
	       else
	       {
	    	 
		       if(tempReportPathGenType[1].equals("1"))
		       {
		    	logger.debug("Entered into 1 block:"+tempReportPathGenType[2]);   
		    	   StringBuffer buffer = new StringBuffer();
		   		ByteArrayInputStream bis=null; 
		    	response.setContentType("text/csv");
				response.setHeader("Cache-Control", "max-age=30");
				response.setHeader("Content-Disposition","attachment;filename=SummaryReport.csv");
				//GenerateCSV csvGenerator = new GenerateCSV();
				String query=tempReportPathGenType[2];
				List<ReportCsvDownload> tempList=csvService.reportValidPayoutCsv(query);
				buffer.append("\n");
				if(tempList!=null)
				{
					logger.debug("DsmReportController || downloadReport || list found:"+tempList);
					for(ReportCsvDownload temp:tempList)
					{
						buffer.append(temp.getVal1());
						buffer.append(",");
						buffer.append(temp.getVal2());
						buffer.append(",");
						buffer.append(temp.getVal3());
						buffer.append(",");
						buffer.append(temp.getVal4());
						buffer.append(",");
						buffer.append(temp.getVal5());
						buffer.append("\n");
					}
				}
				byte requestBytes[] =((buffer.toString())).getBytes();
				bis = new ByteArrayInputStream(requestBytes);
				byte[] buf = new byte[4000];
				int len;
				while ((len = bis.read(buf)) > 0){
					response.getOutputStream().write(buf, 0, len);
				}
				bis.close();
				response.getOutputStream().flush(); 
				if(bis!=null) {
					bis.close();
					response.getOutputStream().flush(); 
				}
		       }
		       else
		       {
		    	   logger.debug("DsmReportController || downloadReport || downloadReportFile:");   
		       
	       File downloadReportFile=new File(tempReportPathGenType[0]);
	       if(!downloadReportFile.exists())
	       {
	    	   logger.debug("File Not Found in given name and path");
	       }

	       FileInputStream inputStream=new FileInputStream(downloadReportFile);
	       String mimeType=context.getMimeType(tempReportPathGenType[0]);
	       if(mimeType==null)
	       {
	    	   mimeType = "application/octet-stream";
	       }
	    	logger.debug("downloadReport || mimeType:"+mimeType);
	    	response.setContentType(mimeType);
	    	response.setContentLength((int)downloadReportFile.length());
	    	String headerKey = "Content-Disposition";
	        String headerValue = String.format("attachment; filename=\"%s\"",downloadReportFile.getName());
	        response.setHeader(headerKey, headerValue);
	        OutputStream outStream=response.getOutputStream();
	        byte buffer[]=new byte[BUFFER_SIZE];
	        int bytesRead=-1;
	        while ((bytesRead = inputStream.read(buffer)) != -1) {
	            outStream.write(buffer, 0, bytesRead);
	        }
	        inputStream.close();
	        outStream.close();
	       }
	    }
	 
	    } 
	    catch(FileNotFoundException fne)
	    {
	    	logger.debug("File not found :"+request.getContextPath()+"/index.jsp");
	    	response.sendRedirect(request.getContextPath()+"/index.jsp?value=returnReport");
	    }
	    catch (Exception e){
	     //   LOGGER.debug("Request could not be completed at this moment. Please try again.");
	        e.printStackTrace();
	        logger.error("Reports --> Report  :: DsmReportController : downloadReport()   :: User Id = "+user.getUserName() +" Exception ::",e);
	    }
		if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : downloadReport()  : End :: User Id = "+user.getUserName() );
		
	}
	
    @RequestMapping(value="callProcReportScheme.action")
	public @ResponseBody String callProcReportScheme(HttpServletRequest request,HttpServletResponse response)
    {
    	User user = (User)httpSession.getAttribute("appUser");
    	if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : callProcReportScheme()  : Start :: User Id = "+user.getUserName() );
		
    	try{
    	
    	logger.debug("values are :"+request.getParameter("schemeId")+":"+request.getParameter("compId")+":"+request.getParameter("scmStartDate")+":"+request.getParameter("scmEndDate")+":"+request.getParameter("scmStatus")+":"+request.getParameter("payoutStatus")+":"+request.getParameter("paymentStatus")+request.getParameter("entityType")+":"+request.getParameter("reportName")+":"+request.getParameter("genType"));
    	int schemeId=0;
    	int compId=0;
    	if(request.getParameter("schemeId")!=null && !"".equals(request.getParameter("schemeId")))
    			schemeId=Integer.parseInt(request.getParameter("schemeId"));
    	if(request.getParameter("compId")!=null && !"".equals(request.getParameter("compId")))
    		    compId=Integer.parseInt(request.getParameter("compId"));
    	String outputMsg=reportGenerateService.callProcReportScheme(schemeId,compId,request.getParameter("scmStartDate"),request.getParameter("scmEndDate"),request.getParameter("scmStatus"),request.getParameter("payoutStatus"),request.getParameter("paymentStatus"),request.getParameter("entityType"),request.getParameter("reportName"),request.getParameter("scmCategory"));
    	if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : callProcReportScheme()  : End :: User Id = "+user.getUserName() );
		
    	//logger.debug("callProcReportScheme || outputMsg:"+outputMsg);
    	return "{\"success\":true, \"resMessage\":\""+outputMsg+"\"}";
    	}
    	catch(Exception e)
    	{
    		logger.error("Reports --> Report  :: DsmReportController : callProcReportScheme()   :: User Id = "+user.getUserName()+" Exception :: ",e );
    		return "Please try again";
    	}
    	
    }
    @RequestMapping(value="downloadSchemeReport.action")
    public void downloadSchemeReport(@RequestParam Map<String,String> requestParams, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	User user = (User)httpSession.getAttribute("appUser");
    	try{
    		
    		if(logger.isDebugEnabled())
    			logger.debug("Reports --> Report  :: DsmReportController : downloadSchemeReport()  : Start :: User Id = "+user.getUserName() );
    		
    	logger.debug("values are :"+request.getParameter("schemeId")+":"+request.getParameter("compId")+":"+request.getParameter("scmStartDate")+":"+request.getParameter("scmEndDate")+":"+request.getParameter("scmStatus")+":"+request.getParameter("payoutStatus")+":"+request.getParameter("paymentStatus")+request.getParameter("entityType")+":"+request.getParameter("genType"));
    	int schemeId=0;
    	int compId=0;

    	if(request.getParameter("schemeId")!=null && !"".equals(request.getParameter("schemeId")) && !"null".equals(request.getParameter("schemeId")))
    			schemeId=Integer.parseInt(request.getParameter("schemeId"));
    	if(request.getParameter("compId")!=null && !"".equals(request.getParameter("compId")) && !"null".equals(request.getParameter("compId")))
    	{
    		logger.debug(request.getParameter("compId")+":Comp Value found");
    		    compId=Integer.parseInt(request.getParameter("compId"));
    	}
    	String startDate=request.getParameter("scmStartDate");
    	String endDate=request.getParameter("scmEndDate");
    	String outputMsg=reportGenerateService.callProcReportScheme(schemeId,compId,startDate,endDate,request.getParameter("scmStatus"),request.getParameter("payoutStatus"),request.getParameter("paymentStatus"),request.getParameter("entityType"),request.getParameter("reportName"),request.getParameter("scmCategory"));
    	if(request.getParameter("genType")!=null && request.getParameter("genType").equals("1"))
    	{
    		logger.debug("DsmReportController || callProcReportScheme || query block:"+request.getParameter("genType"));
    		ByteArrayInputStream bis=null; 
	    	response.setContentType("text/csv");
			response.setHeader("Cache-Control", "max-age=30");
			response.setHeader("Content-Disposition","attachment;filename=Download.csv");
			byte requestBytes[] =((outputMsg.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
    	}
    	if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : downloadSchemeReport()  : End :: User Id = "+user.getUserName() );
		
    	}
    	catch(Exception e)
    	{
    			logger.debug("Reports --> Report  :: DsmReportController : downloadSchemeReport()   :: User Id = "+user.getUserName() +" Exception :: ",e);
    	}
    }
    
    
    @RequestMapping(value="downloadMonthReport.action")
    public void downloadMonthReport(@RequestParam Map<String,String> requestParams, HttpServletRequest request, HttpServletResponse response) throws Exception
    {
    	User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : downloadMonthReport()  : Start :: User Id = "+user.getUserName() );
		
    	try{
    	int contactNo=0;
    	logger.debug("DsmReportController || downloadMonthReport || values are :"+request.getParameter("monthBasedstartDate")+":"+request.getParameter("monthBasedEndDate")+":"+request.getParameter("monthBasedEntityId")+":"+request.getParameter("monthBasedConNo")+":"+request.getParameter("monthEntityType")+":"+request.getParameter("reportName"));
    	String startDate=request.getParameter("monthBasedstartDate");
    	String endDate=request.getParameter("monthBasedEndDate");
       	if(request.getParameter("monthBasedConNo")!=null && !"".equals(request.getParameter("monthBasedConNo")) && !"null".equals(request.getParameter("monthBasedConNo")))
   			contactNo=Integer.parseInt(request.getParameter("monthBasedConNo"));
    	String outputMsg=reportGenerateService.callProcMonthScheme(request.getParameter("monthBasedstartDate"),request.getParameter("monthBasedEndDate"),request.getParameter("monthBasedEntityId"),contactNo,request.getParameter("monthEntityType"),request.getParameter("reportName"));
    	if(request.getParameter("genType")!=null && request.getParameter("genType").equals("1"))
    	{
    		logger.debug("DsmReportController || callProcReportScheme || query block:"+request.getParameter("genType"));
    		ByteArrayInputStream bis=null; 
	    	response.setContentType("text/csv");
			response.setHeader("Cache-Control", "max-age=30");
			response.setHeader("Content-Disposition","attachment;filename=Download.csv");
			byte requestBytes[] =((outputMsg.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
    	}
    	if(logger.isDebugEnabled())
			logger.debug("Reports --> Report  :: DsmReportController : downloadMonthReport()  : End :: User Id = "+user.getUserName() );
		
    	}
    	catch(Exception e)
    	{
    		if(logger.isDebugEnabled())
    			logger.debug("Reports --> Report  :: DsmReportController : downloadMonthReport()   :: User Id = "+user.getUserName() +" Exception :: ",e);
    		}
    	
    
    	
    }
    
    @RequestMapping(value="callProcMonthScheme.action")
   	public @ResponseBody String callProcMonthScheme(HttpServletRequest request) throws Exception
       {
       	int contactNo=0;
       	logger.debug("values are :"+request.getParameter("monthBasedstartDate")+":"+request.getParameter("monthBasedEndDate")+":"+request.getParameter("monthBasedEntityId")+":"+request.getParameter("monthBasedConNo")+":"+request.getParameter("monthEntityType")+":"+request.getParameter("reportName"));
       	if(request.getParameter("monthBasedConNo")!=null && !"".equals(request.getParameter("monthBasedConNo")))
       			contactNo=Integer.parseInt(request.getParameter("monthBasedConNo"));
       	String outputMsg=reportGenerateService.callProcMonthScheme(request.getParameter("monthBasedstartDate"),request.getParameter("monthBasedEndDate"),request.getParameter("monthBasedEntityId"),contactNo,request.getParameter("monthEntityType"),request.getParameter("reportName"));
       	logger.debug("callProcReportScheme || outputMsg:"+outputMsg);
       	return "{\"success\":true, \"resMessage\":\""+outputMsg+"\"}";
       }
   	
    
/*	@RequestMapping(value="/downloadLogFile.action")
	public void getLogFile(HttpSession session,HttpServletResponse response) throws Exception {
	    try {
	        String filePathToBeServed = "DsmReportController.java";
	        File fileToDownload = new File(filePathToBeServed);
	        InputStream inputStream = new FileInputStream(fileToDownload);
	        response.setContentType("application/force-download");
	        response.setHeader("Content-Disposition", "attachment; filename=abcd.txt"); 
	        IOUtils.copy(inputStream, response.getOutputStream());
	        response.flushBuffer();
	        inputStream.close();
	    } catch (Exception e){
	     //   LOGGER.debug("Request could not be completed at this moment. Please try again.");
	        e.printStackTrace();
	    }

	}
*/	
}

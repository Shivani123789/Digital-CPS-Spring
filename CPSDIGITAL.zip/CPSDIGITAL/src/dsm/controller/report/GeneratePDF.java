package dsm.controller.report;

import java.awt.Color;
//import java.util.List;
//import java.util.Map;

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
//import com.lowagie.text.pdf.PdfWriter;

//import dsm.model.DB.DistributorVO;
import dsm.model.report.Appendix;
import dsm.model.report.ComponentListReport;
import dsm.model.report.ComponentReport;
import dsm.model.report.ConditionReport;
import dsm.model.report.PayoutReport;
import dsm.model.report.ReportGenerateMaster;
import dsm.model.report.RetailerPerformanceReport;
import dsm.model.report.TransactionDataReport;

public class GeneratePDF {

	public StringBuffer downloadGeneratePDF(ReportGenerateMaster rgm)throws Exception
	{
		 Document doc = new Document();
		
		 // get data model which is passed by the Spring container
		//ReportGenerateMaster rgm = (ReportGenerateMaster)model.get("revenueData");

		/*Font fonta = FontFactory.getFont(FontFactory.HELVETICA_BOLDOBLIQUE);
		fonta.setColor(BaseColor.BLACK);*/

		Font fonth = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
		fonth.setColor(Color.BLACK);
		fonth.setSize(12);

		Chunk cht = new Chunk("Configured Scheme Details",fonth);
		Paragraph head = new Paragraph(cht);
		head.setAlignment(Element.ALIGN_CENTER);

		/*		Chunk cht2 = new Chunk("Configured Scheme Details",fonta);
		Paragraph head2 = new Paragraph(cht2);
		head.setAlignment(Element.ALIGN_CENTER);*/

		doc.add(head);
		//doc.add(head2);
		doc.add(new Paragraph(""));
		doc.add(new Paragraph(""));

		/*Image image;
		try {
			image = Image.getInstance("world.gif");
			image.setAlignment(Image.RIGHT);
			doc.add(image);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}*/

		System.out.println("****************** PdfRevenueReportView ********************** ");
		//List<ComponentListReport> compList = rgm.getComponentListReport();
		try{
			//	System.out.println("PDFBuilder Size :: "+rgm!=null ? rgm.getComponentListReport().size():"null");
			if(rgm.getComponentListReport()!=null && rgm.getComponentListReport().size()!=0)
				for(ComponentListReport comp : rgm.getComponentListReport()){

					Font font = FontFactory.getFont(FontFactory.TIMES_BOLD);
					font.setColor(Color.GRAY);

					PdfPTable schemeTable = new PdfPTable(2);
					schemeTable.setWidthPercentage(100.0f);

					Chunk ch1 = new Chunk("Scheme Name",font);
					Paragraph sch = new Paragraph(ch1);
					PdfPCell schemecell = new PdfPCell(sch);
					schemecell.setBorder(0);


					Chunk ch2 = new Chunk("Component Name",font);
					Paragraph compPara = new Paragraph(ch2);
					PdfPCell compcell = new PdfPCell(compPara);
					compcell.setBorder(0);

					Chunk ch3 = new Chunk(comp.getSchemeName());
					Paragraph sch1 = new Paragraph(ch3);
					PdfPCell schemeValcell = new PdfPCell(sch1);
					schemeValcell.setBorder(0);

					Chunk ch4 = new Chunk(comp.getComponentName());
					Paragraph comp1 = new Paragraph(ch4);
					PdfPCell compValcell = new PdfPCell(comp1);
					compValcell.setBorder(0);

					schemeTable.addCell(schemecell);
					schemeTable.addCell(compcell);
					schemeTable.addCell(schemeValcell);
					schemeTable.addCell(compValcell);

					doc.add(schemeTable);




					//PdfPTable parantTable = new PdfPTable(1);
					schemeTable.setWidthPercentage(100.0f);

					PdfPTable childTable = new PdfPTable(5);
					childTable.setWidthPercentage(100f);

					System.out.println("************** comp.getComponentReport() :::: "+comp.getComponentReport());
					//List<ComponentReport> compReport = comp.getComponentReport();
					if(comp.getComponentReport()!=null && comp.getComponentReport().size()!=0)
						for(ComponentReport componentList :  comp.getComponentReport()){

							PdfPCell blankL01 = new PdfPCell(new Paragraph(""));
							blankL01.setColspan(1);
							blankL01.setBorder(0);

							PdfPCell blankL02 = new PdfPCell(new Paragraph(""));
							blankL02.setColspan(2);
							blankL02.setBorder(0);
							//blankL01.setHorizontalAlignment();

							PdfPCell blankL05 = new PdfPCell(new Paragraph(""));
							blankL05.setColspan(5);
							blankL05.setBorder(0);


							Chunk chc1 = new Chunk("Period",font);
							Paragraph p1 = new Paragraph(chc1);
							PdfPCell pc1 = new PdfPCell(p1);
							pc1.setBorder(0);
							pc1.setNoWrap(true);

							Chunk chc1a = new Chunk(componentList.getStartDate()+" - "+ componentList.getEndDate());
							Paragraph p1a = new Paragraph(chc1a);
							PdfPCell  pc1a = new PdfPCell(p1a);
							pc1a.setBorder(0);
							pc1a.setNoWrap(true);

							Chunk chc2 = new Chunk("Payout Frequency",font);
							Paragraph p2 = new Paragraph(chc2);
							PdfPCell pc2 = new PdfPCell(p2);
							pc2.setBorder(0);
							pc2.setNoWrap(true);

							Chunk chc2a = new Chunk(componentList.getFrequency());
							Paragraph p2a = new Paragraph(chc2a);
							PdfPCell  pc2a = new PdfPCell(p2a);
							pc2a.setBorder(0);
							pc2a.setNoWrap(true);

							Chunk chc3 = new Chunk("Payee Entity",font);
							Paragraph p3 = new Paragraph(chc3);
							PdfPCell pc3 = new PdfPCell(p3);
							pc3.setBorder(0);
							pc3.setNoWrap(true);

							Chunk chc3a = new Chunk(componentList.getPayTo());
							Paragraph p3a = new Paragraph(chc3a);
							PdfPCell  pc3a = new PdfPCell(p3a);
							pc3a.setBorder(0);
							pc3a.setNoWrap(true);

							//
							Chunk chc21 = new Chunk("Applicable For");
							Paragraph p21 = new Paragraph(chc21);
							PdfPCell pc21 = new PdfPCell(p21);
							pc21.setBorder(0);
							pc21.setNoWrap(true);

							Chunk chc22 = new Chunk("Circle",font);
							Paragraph p22 = new Paragraph(chc22);
							PdfPCell pc22 = new PdfPCell(p22);
							pc22.setBorder(0);
							pc22.setNoWrap(true);

							Chunk chc22a = new Chunk(componentList.getCircleName());
							Paragraph p22a = new Paragraph(chc22a);
							PdfPCell  pc22a = new PdfPCell(p22a);
							pc22a.setBorder(0);
							pc22a.setNoWrap(true);

							Chunk chc23 = new Chunk("Region",font);
							Paragraph p23 = new Paragraph(chc23);
							PdfPCell pc23 = new PdfPCell(p23);
							pc23.setBorder(0);
							pc23.setNoWrap(true);

							Chunk chc23a = new Chunk(componentList.getRegion());
							Paragraph p23a = new Paragraph(chc23a);
							PdfPCell  pc23a = new PdfPCell(p23a);
							pc23a.setBorder(0);
							pc23a.setNoWrap(true);

							Chunk chc24 = new Chunk("Zone",font);
							Paragraph p24 = new Paragraph(chc24);
							PdfPCell pc24 = new PdfPCell(p24);
							pc24.setBorder(0);
							pc24.setNoWrap(true);

							Chunk chc24a = new Chunk(componentList.getZone());
							Paragraph p24a = new Paragraph(chc24a);
							PdfPCell  pc24a = new PdfPCell(p24a);
							pc24a.setBorder(0);
							pc24a.setNoWrap(true);

							Chunk chc25 = new Chunk("Sales vartical",font);
							Paragraph p25 = new Paragraph(chc25);
							PdfPCell pc25 = new PdfPCell(p25);
							pc25.setBorder(0);
							pc25.setNoWrap(true);

							Chunk chc25a = new Chunk(componentList.getVertical());
							Paragraph p25a = new Paragraph(chc25a);
							PdfPCell  pc25a = new PdfPCell(p25a);
							pc25a.setBorder(0);
							pc25a.setNoWrap(true);

							childTable.addCell(pc1);
							childTable.addCell(blankL02);
							childTable.addCell(pc2);
							childTable.addCell(pc3);
							childTable.addCell(pc1a);
							childTable.addCell(pc2a);
							childTable.addCell(pc3a);
							childTable.addCell(blankL05);

							childTable.addCell(pc21);
							childTable.addCell(pc22);
							childTable.addCell(pc23);
							childTable.addCell(pc24);
							childTable.addCell(pc25);
							childTable.addCell(blankL01);
							childTable.addCell(pc22a);
							childTable.addCell(pc23a);
							childTable.addCell(pc24a);
							childTable.addCell(pc25a);
							childTable.addCell(blankL05);
							if(comp.getConditionReport()!=null && comp.getConditionReport().size()!=0)
								for(ConditionReport condList : comp.getConditionReport()){
									Chunk chc26 = new Chunk(condList.getCondition());
									Paragraph p26 = new Paragraph(chc26);
									PdfPCell pc26 = new PdfPCell(p26);
									pc26.setBorder(0);
									pc26.setColspan(5);
									pc26.setNoWrap(true);
									pc26.setHorizontalAlignment(Element.ALIGN_CENTER);
									childTable.addCell(pc26);
								}

						}

					//parantTable.addCell(childTable);

					doc.add(childTable);

					// Transaction
					doc.add(new Paragraph("Transaction Data to be Considered",font));

					PdfPTable transTable = new PdfPTable(4);
					transTable.setWidthPercentage(100.0f);
					transTable.setWidths(new float[] {1.8f, 3.0f, 3.0f, 5.0f});
					transTable.setSpacingBefore(10);

					PdfPCell cell3 = new PdfPCell();
					cell3.setBackgroundColor(Color.BLUE);
					Font font2 = FontFactory.getFont(FontFactory.TIMES);
					font2.setColor(Color.BLACK);

					cell3.setPhrase(new Phrase("SNo.", font2));
					transTable.addCell(cell3);

					cell3.setPhrase(new Phrase("Condition Name", font2));
					transTable.addCell(cell3);

					cell3.setPhrase(new Phrase("TypeOfData", font2));
					transTable.addCell(cell3);

					cell3.setPhrase(new Phrase("Criteria", font2));
					transTable.addCell(cell3);
					int tqcount=1;
					System.out.println("************** comp.getTransDataReport() :::: "+comp.getTransDataReport());

					if(comp.getTransDataReport()!=null || comp.getTransDataReport().size()!=0)
						for (TransactionDataReport tq : comp.getTransDataReport()) {
							transTable.addCell(String.valueOf(tqcount));
							transTable.addCell(tq.getConditionName());
							transTable.addCell(tq.getDataSet());
							transTable.addCell(tq.getCondition());
							tqcount++;
						}
					doc.add(transTable);

					System.out.println("************** comp.getRetailerReport() :::: "+comp.getRetailerReport());

					//Retailer
					doc.add(new Paragraph("Retailer Performance",font));
					int eaCount=1;
					if(comp.getRetailerReport()!=null || comp.getRetailerReport().size()!=0)
						for(RetailerPerformanceReport ea : comp.getRetailerReport()){
							Paragraph schEA = new Paragraph();
							schEA.add(String.valueOf(eaCount));
							schEA.add(ea.getVariableName());
							schEA.setSpacingAfter(10);
							schEA.add(ea.getVariableValue());
							schEA.add("["+"]");
							doc.add(schEA);
							eaCount++;
						}


					doc.add(new Paragraph("Payment Condition",font));
					PdfPTable payoutTable = new PdfPTable(8);
					PdfPCell cell2 = new PdfPCell();
					cell2.setBackgroundColor(Color.BLUE);


					payoutTable.setWidthPercentage(100.0f);
					payoutTable.setWidths(new float[] {1.8f, 5.0f, 2.0f, 2.0f,4.0f, 2.0f, 3.0f, 3.0f});
					payoutTable.setSpacingBefore(10);

					cell2.setPhrase(new Phrase("SNo.", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Payment Terms", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Amt", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Unit", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Performance", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("G/N", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Over Ach.", font2));
					payoutTable.addCell(cell2);

					cell2.setPhrase(new Phrase("Under Ach.", font2));
					payoutTable.addCell(cell2);

					System.out.println("************** comp.getPayoutReport() :::: "+comp.getPayoutReport());

					int payoutCount=1;
					if(comp.getPayoutReport()!= null || comp.getPayoutReport().size()!=0)
						for (PayoutReport po : comp.getPayoutReport()) {
							payoutTable.addCell(String.valueOf(payoutCount));
							payoutTable.addCell(po.getConditionName());
							payoutTable.addCell(String.valueOf(po.getAmount()));
							payoutTable.addCell(po.getUnit());
							payoutTable.addCell(po.getVariable());
							payoutTable.addCell(po.getGrossNet());
							payoutTable.addCell(String.valueOf(po.getOverAchive()));
							payoutTable.addCell(String.valueOf(po.getUnderAchive()));
							payoutCount++;
						}

					doc.add(payoutTable);






					doc.newPage();
				}
		}catch(Exception e){
			e.getMessage();	
		}
		Font font1 = FontFactory.getFont(FontFactory.TIMES_BOLDITALIC);
		font1.setColor(Color.RED);
		doc.add(new Paragraph("Appendix",font1));

		PdfPTable table = new PdfPTable(4);
		table.setWidthPercentage(100.0f);
		table.setWidths(new float[] {3.3f, 3.0f, 6.3f, 3.3f});
		table.setSpacingBefore(10);

		// define font for table header row
		Font fontw = FontFactory.getFont(FontFactory.TIMES);
		fontw.setColor(Color.WHITE);

		// define table header cell
		PdfPCell cell = new PdfPCell();
		cell.setBackgroundColor(Color.BLUE);
		//cell.setPadding(4);

		// write table header 
		cell.setPhrase(new Phrase("Performance Type", fontw));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Parameter Name", fontw));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Parameter Meaning", fontw));
		table.addCell(cell);

		cell.setPhrase(new Phrase("Valid Value (If Any)", fontw));
		table.addCell(cell);

		//System.out.println("PDFBuilder getAppendix Size :: "+rgm!=null ? rgm.getAppendix().size():"null");
		if(rgm!=null && rgm.getAppendix()!=null && rgm.getAppendix().size()!=0)
			for (Appendix app : rgm.getAppendix()) {
				table.addCell(app.getPerformanceType());
				table.addCell(app.getParameterName());
				table.addCell(app.getParameterMeaning());
				table.addCell(app.getValidValue());
			}
		doc.add(table);
	StringBuffer sb = new StringBuffer(doc.toString());
	
		return sb;
	
	}
}

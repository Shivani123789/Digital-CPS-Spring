package dsm.controller.stmtGen;


import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.controller.csv.GenerateCSV;
import dsm.dao.stmtGen.StmtGenDAO;
import dsm.generate.report.CircleWiseStmtPdfZip;
import dsm.generate.report.RetailerPdfZip;
import dsm.model.DB.CSVModelInput;

import dsm.model.DB.PartnerChannelStatementPojo;
import dsm.model.DB.PaymentDetailVO;
import dsm.model.DB.ServiceType;
import dsm.model.DB.StmtGenCycleMaster;
import dsm.model.DB.StmtReqMapping;
import dsm.model.DB.TransSubData;
import dsm.model.StmGen.StmtCpBean;
import dsm.model.search.SearchScheme;
import dsm.model.user.User;
import dsm.service.stmtGen.StmtGenService;


@Controller
@Scope("session")
@RequestMapping(value="/stmtGen")
public class StmtGenController {

	@Autowired
	private HttpSession httpSession;

	@Autowired
	StmtGenDAO stmtGenDAO = null;
	
	@Autowired
	StmtGenService stmtGenSrvc = null;

	private static Logger logger = Logger.getLogger (StmtGenController.class);

	@RequestMapping(value="getStmtGenSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransDataSearch(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Statement --> View Statement :: StmtGenController : getTransDataSearch()  : Start :: User Id = "+user.getUserName() );

		try{
			if(user!=null){
				if(requestParams.get("serviceType3")!=null)
				httpSession.setAttribute("serviceType3",requestParams.get("serviceType3"));
				String serviceType = requestParams.get("serviceType3")!=null? requestParams.get("serviceType3"):(String)httpSession.getAttribute("serviceType3");
				List<StmtGenCycleMaster> compList = stmtGenSrvc.searchScheme(user.getUserCircleCode(),serviceType);
				modelMap.put("data",compList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : getTransDataSearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : getTransDataSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
	
	//getViewStmtSearch
	@RequestMapping(value="getStmtGenViewSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getStmtGenViewSearch(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Statement --> View Statement :: StmtGenController : getStmtGenViewSearch()  : Start :: User Id = "+user.getUserName() );

		try{
			if(user!=null && requestParams.get("startEndDt") != null && requestParams.get("stmtCycleId") != null){
				String[] str = requestParams.get("startEndDt").split("TO");
				List<PaymentDetailVO> stmtGenList = stmtGenSrvc.searchStatementGenerate(str[0].trim(), str[1].trim(), user.getCircleId(),user.getUserCircleCode(), Integer.parseInt(requestParams.get("stmtCycleId")));
				modelMap.put("data",stmtGenList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : getStmtGenViewSearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : getStmtGenViewSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
	
	@RequestMapping(value="getViewStmtSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getViewStmtSearch(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Statement --> View Statement :: StmtGenController : getViewStmtSearch()  : Start :: User Id = "+user.getUserName() );
		try{
			logger.debug("  page ::"+schemeName.getPage()+"\t start::"+schemeName.getStart()+"\t limit::"+schemeName.getLimit()+"\t stdate :: "+schemeName.getStartEndDt());
			if(schemeName.getStartEndDt()==null && httpSession.getAttribute("startEndDt")!=null){
				schemeName.setStartEndDt(httpSession.getAttribute("startEndDt").toString());
				schemeName.setMsisdn(httpSession.getAttribute("msisdn").toString());
				schemeName.setDistId(httpSession.getAttribute("distId").toString());
				schemeName.setStmtCycleId(httpSession.getAttribute("stmtCycleId").toString());
			}else{
				httpSession.setAttribute("startEndDt", schemeName.getStartEndDt());
				httpSession.setAttribute("msisdn", schemeName.getMsisdn());
				schemeName.setStart(0);
				schemeName.setPage(1);
				modelMap.put("page",1);
				httpSession.setAttribute("distId", schemeName.getDistId());
				httpSession.setAttribute("stmtCycleId", schemeName.getStmtCycleId());
			}
			if(user != null && schemeName != null && schemeName.getStartEndDt()!=null)
			{	
				String[] str = schemeName.getStartEndDt().split("TO");

				//List<DistributorStatementPojo> compList = stmtGenSrvc.searchViewStmtSearch(str[1].trim(),user.getUserCircleCode(),schemeName.getMsisdn()!=null?schemeName.getMsisdn():"",schemeName.getDistId()!=null?schemeName.getDistId():"", schemeName.getStart(),schemeName.getLimit());
				//System.out.println("stmtcycleId ::: "+schemeName.getStmtCycleId());
				
				List<PartnerChannelStatementPojo> compList = stmtGenSrvc.searchViewPartnerChannelStmtSearch(str[1].trim(),user.getUserCircleCode(),schemeName.getMsisdn()!=null?schemeName.getMsisdn():"",schemeName.getDistId()!=null?schemeName.getDistId():"", schemeName.getStart(),schemeName.getLimit(), schemeName.getStmtCycleId());
				//System.out.println("compList ::: "+compList);
				if((compList.size()!=0))
					modelMap.put("totalCount",compList.get(0).getTotalCount());	
					modelMap.put("page",schemeName.getPage());
				//System.out.println("After set Page ::: "+schemeName.getPage()+"\t start::"+schemeName.getStart());
				modelMap.put("data",compList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : getViewStmtSearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : getViewStmtSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
	
	
	@RequestMapping(value="/generateDistRetailerStmtPDFZip.action")
	public void  generateDistRetailerStmtPDFZip(@RequestParam Map<String,String> requestParams, HttpServletRequest request, HttpServletResponse response) throws Exception {
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : generateDistRetailerStmtPDFZip()  : Start :: User Id = "+user.getUserName() );

			//System.out.println(""+requestParams.get("distDsm2Id")+"\t"+requestParams.get("startEndDtParam"));
			RetailerPdfZip rpz = new RetailerPdfZip();
			if(user != null  &&  requestParams.get("distDsm2Id") != null  &&  requestParams.get("startEndDtParam") != null ){
				/*StringBuffer path = new StringBuffer();
				path.append("https://");
				path.append(request.getServerName());
				path.append(":");
				path.append(request.getServerPort());
				path.append(request.getContextPath());
				path.append("/resources/images/ideaLogo.jpg");
				*/
				StringBuffer path = new StringBuffer(System.getProperty("SCHEME_STUDIO_CONFIG_PATH")+"Images/ideaLogo.jpg");
				String[] str = requestParams.get("startEndDtParam").split("TO");
				
				rpz.setCircleId(user.getCircleId());
				rpz.setZipFileName(requestParams.get("distDsm2Id"));
				rpz.setImagePath(path.toString());
				
				rpz.setRetailerList(stmtGenSrvc.fetchRetailerStmt(requestParams.get("distDsm2Id"), str[1].trim(), user.getUserCircleCode()));
				if(rpz.getRetailerList() != null && rpz.getRetailerList().size() != 0)
				{
					rpz.start();
				}
				
				TransSubData trans = new TransSubData();
				trans.setCircleId(user.getCircleId());
				trans.setFileName(requestParams.get("distDsm2Id")+".zip");
				trans.setDownloadLink("true");
				trans.setErrorDesc("");
				
				httpSession.setAttribute("retailerData", trans);
				response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : generateDistRetailerStmtPDFZip()  : End :: User Id = "+user.getUserName() );

		}catch(IllegalThreadStateException ite){
			response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
		}catch(NullPointerException e){
			//property not found
			response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
			//e.printStackTrace();
		}catch(Exception e){
			logger.error("StmtGenController : generateDistRetailerStmtPDFZip()  : Exception :: ",e);
			e.printStackTrace();
		}
 	}

	
	@RequestMapping(value="/downloadDistRetailerStmtPDFZip.action")
	public void  getDistRetailerStmtPDFZip(HttpServletRequest request, HttpServletResponse response) throws Exception {
		User user = (User)httpSession.getAttribute("appUser");
		try{
			String path	= new File(System.getProperty("SCHEME_STUDIO_FILE_PATH")).getPath();
			if(path != null){
				if(logger.isDebugEnabled())
					logger.debug("Statement --> View Statement :: StmtGenController : getDistRetailerStmtPDFZip()  : Start :: User Id = "+user.getUserName() );

				TransSubData transData = new TransSubData();
				if(request.getParameter("downloadLink") != null && "true".equalsIgnoreCase(request.getParameter("downloadLink"))){
					transData.setErrorDesc("");
					//transData.setErrorDesc("No file found. Please try again.");
					transData.setDownloadLink("false");
					transData.setFileName(request.getParameter("distDsm2Id"));
					transData.setCircleId(user.getCircleId());
				}else{
					transData.setErrorDesc("");
					transData.setDownloadLink("true");
				}
				
				//File Path
				StringBuffer zipFilePath = new StringBuffer();
				zipFilePath.append(path).append("/").append(user.getCircleId()).append("/").append(transData.getFileName());//.append(".zip");//.append(transData.getCircleId()).append("_");
				
				File downloadFile = new File(zipFilePath.toString());
				transData.setFileName(downloadFile.getName());
				//System.out.println("filePath ==>>"+zipFilePath+" :: "+downloadFile.exists());
				httpSession.setAttribute("retailerData", transData);
				//If file found
				if(downloadFile.exists()){
					FileInputStream inStream = new FileInputStream(downloadFile);
					//System.out.println("inStream available :: "+inStream.available());
					//System.out.println("file length :: "+downloadFile.length());
					if(downloadFile.length() != -1 ){
						response.setContentType("application/zip");
						response.setContentLength((int) downloadFile.length());
						transData.setErrorDesc("File Downloaded Successfully.");
						String headerKey = "Content-Disposition";
						String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
						response.setHeader(headerKey, headerValue);
						transData.setDownloadLink("true");
						
						OutputStream outStream = response.getOutputStream();
						byte[] buffer = new byte[4096];
						int bytesRead = -1;
						while ((bytesRead = inStream.read(buffer)) != -1) {
							outStream.write(buffer, 0, bytesRead);
						}
						inStream.close();
						outStream.close();
					}else{
						//No record found
						transData.setErrorDesc("No file found.");
						response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
					}
				}else{
					//file not exist
					transData.setErrorDesc("No file found.");
					response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
				}
			}else{
				//path is not found
				response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : getDistRetailerStmtPDFZip()  : End :: User Id = "+user.getUserName() );

		}catch(NullPointerException e){
			//property not found
			response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
			//e.printStackTrace();
		}catch(Exception e){
			logger.error("StmtGenController : getDistRetailerStmtPDFZip()  : Exception :: ",e);
			e.printStackTrace();
		}
 	}


	@RequestMapping(value="selectedStmtGenEmailConfig.action")
	public @ResponseBody Map<String,? extends Object> selectedStmtGenEmailConfig(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : selectedStmtGenEmailConfig()  : Start :: User Id = "+user.getUserName() );

			if(user!=null){
				String distId = requestParams.get("distId");
				String value = stmtGenSrvc.selectedStmtGenEmailConfig(distId, user.getUserCircleCode());
				modelMap.put("success",false);
				modelMap.put("errorMessage",value);
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : selectedStmtGenEmailConfig()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : selectedStmtGenEmailConfig()  : Exception ::",e);
			e.printStackTrace();
			//modelMap.put("success", false);
		}
		return modelMap;
	}

	
	@RequestMapping(value="stmtGenEmailConfig.action")
	public @ResponseBody Map<String,? extends Object> stmtGenEmailConfig(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(user!=null){
				if(logger.isDebugEnabled())
					logger.debug("Statement --> View Statement :: StmtGenController : stmtGenEmailConfig()  : Start :: User Id = "+user.getUserName() );

				String distId = requestParams.get("distId");
				String startEndDtParam = requestParams.get("startEndDtParam");
				String value = stmtGenSrvc.stmtGenEmailConfig(distId, startEndDtParam, user.getUserCircleCode());
				modelMap.put("success",false);
				modelMap.put("errorMessage",value);
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : stmtGenEmailConfig()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : stmtGenEmailConfig()  : Exception :: ",e);
			e.printStackTrace();
			//modelMap.put("success", false);
		}
		return modelMap;
	}

	@RequestMapping(value="getTempReqStore.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTempReqStore(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Statement --> Statement Request :: StmtGenController : getTempReqStore()  : Start :: User Id = "+user!=null?user.getUserName():"" );

			if(user!=null && requestParams.get("startDate")!=null){
			String stmtDt = requestParams.get("startDate");
			String stmtCycleId = requestParams.get("stmtCycleId");
			
			String[] str = stmtDt.split("TO");
			//System.out.println("\t startdt ::"+requestParams.get("startDate")+""+str[1]);
			List<StmtReqMapping> compList = stmtGenSrvc.searchReqStmtSearch(str[1],user.getUserCircleCode(),user.getCircleId(),stmtCycleId);
			modelMap.put("data",compList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> Statement Request :: StmtGenController : getTempReqStore()  : End :: User Id = "+user.getUserName() );

		}catch(Exception e){
			logger.error("StmtGenController : getTempReqStore()  : Exception :: ",e);
			e.printStackTrace();
		}
			return modelMap;
	}
	
	@RequestMapping(value="insertSchemeStatementMap.action")
	public @ResponseBody Map<String,? extends Object> insertSchemeStatementMap(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(user!=null){
				if(logger.isDebugEnabled())
					logger.debug("Statement --> Statement Request :: StmtGenController : insertSchemeStatementMap()  : Start :: User Id = "+user.getUserName() );

				String stmtDownData = requestParams.get("stmtDownData");
				
				//System.out.println("stmtDownData::::::::"+stmtDownData);	
				int i = stmtGenSrvc.insertSchemeStatementMap(stmtDownData, user.getUserCircleCode(),user.getUserName());
				modelMap.put("success",false);
				if(i!=0){
					modelMap.put("errorMessage","true");					
				}else{
					modelMap.put("errorMessage","false");
				}
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> Statement Request :: StmtGenController : insertSchemeStatementMap()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : insertSchemeStatementMap()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("errorMessage","false");
		}
		return modelMap;
	}

	
	@RequestMapping(value="deleteSchemeStatementMap.action")
	public @ResponseBody Map<String,? extends Object> deleteSchemeStatementMap(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(user!=null){
				if(logger.isDebugEnabled())
					logger.debug("Statement --> Statement Request :: StmtGenController : deleteSchemeStatementMap()  : Start :: User Id = "+user.getUserName() );

				String stmtDownData = requestParams.get("stmtDownData");
				//System.out.println("stmtDownData::::::::"+stmtDownData);	
				int i = stmtGenSrvc.deleteSchemeStatementMap(stmtDownData, user.getUserCircleCode());
				modelMap.put("success",false);
				if(i!=0){
					modelMap.put("errorMessage","true");					
				}else{
					modelMap.put("errorMessage","false");
				}
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> Statement Request :: StmtGenController : deleteSchemeStatementMap()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : deleteSchemeStatementMap()  : Exception :: ",e);
			e.printStackTrace();
		}
		return modelMap;
	}

	
	@RequestMapping(value="reqForStmtGenerate.action")
	public @ResponseBody Map<String,? extends Object> reqForStmtGenerate(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(user!=null){
				if(logger.isDebugEnabled())
					logger.debug("Statement --> Statement Request :: StmtGenController : reqForStmtGenerate()  : Start :: User Id = "+user.getUserName() );

				int stmtDownData = Integer.parseInt(requestParams.get("stmtDownData"));
				String value = stmtGenSrvc.reqForStmtGenerate(stmtDownData, user.getUserCircleCode());
				if("1".equals(value))
				{
					modelMap.put("success",true);
					modelMap.put("message",value);
				}
				else
				{
					modelMap.put("success",false);
					modelMap.put("message",value);
				}
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> Statement Request :: StmtGenController : reqForStmtGenerate()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : reqForStmtGenerate()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("message","Unable to process statement generation");
		}
		return modelMap;
	}
	
	
	@RequestMapping(value="searchStmtPeriod.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getSearchStmtPeriod(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Statement --> Statement Req/View Statement :: StmtGenController : getSearchStmtPeriod()  : Start :: User Id = "+user.getUserName() );

			if(user!=null){
				if(requestParams.get("serviceType") != null)
					httpSession.setAttribute("serviceType", requestParams.get("serviceType"));
				String serviceType = requestParams.get("serviceType") != null ? requestParams.get("serviceType") : (String)httpSession.getAttribute("serviceType"); 
						
			List<StmtGenCycleMaster> compList = stmtGenSrvc.searchStmtPeriod(user.getUserCircleCode(), serviceType);
				modelMap.put("data",compList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> Statement Req/View Statement :: StmtGenController : getSearchStmtPeriod()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : getSearchStmtPeriod()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
	
	@RequestMapping(value="/generateCircleWiseStmtPDFZip.action")
	public void  generateCircleWiseStmtPDFZip(@RequestParam Map<String,String> requestParams, HttpServletRequest request, HttpServletResponse response) throws Exception {
		try{
			User user = (User)httpSession.getAttribute("appUser");
			//System.out.println(""+requestParams.get("distDsm2Id")+"\t"+requestParams.get("startEndDtParam"));
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : generateCircleWiseStmtPDFZip()  : Start :: User Id = "+user.getUserName() );

			String distributorId = requestParams.get("distDsm2Id");
			String[] str = requestParams.get("startEndDtParam").split("TO");

			List<PartnerChannelStatementPojo> distVoList = null;
			List<String> circleList =  null;
			try{
				if(user!=null && distributorId != null && str!=null){
					distVoList = stmtGenSrvc.fetchChannelPartnerStmt(distributorId, str[1].trim(), user.getUserCircleCode(),requestParams.get("stmtCycleDt"));
					if(user.getUserCircleCode().equalsIgnoreCase("CU"))
						circleList = stmtGenSrvc.fetchChannelPartnerCircleList(distributorId, user.getUserCircleCode());							
				}
			} catch (Exception e) {
				e.printStackTrace();
			}


			CircleWiseStmtPdfZip rpz = new CircleWiseStmtPdfZip();
			if(user != null  &&  requestParams.get("distDsm2Id") != null  &&  requestParams.get("startEndDtParam") != null ){
				StringBuffer path = new StringBuffer();
				if(request.isSecure())
					path.append("https://");
				else
					path.append("http://");
				path.append(request.getServerName());
				path.append(":");
				path.append(request.getServerPort());
				path.append(request.getContextPath());
				path.append("/resources/images/ideaLogo.jpg");

				rpz.generateCircleWiseStmtPdf(distVoList, path.toString(), circleList, user.getCircleId(), user.getUserCircleCode()+"_"+requestParams.get("distDsm2Id")+".zip");
				TransSubData trans = new TransSubData();
				trans.setCircleId(user.getCircleId());
				trans.setFileName(user.getUserCircleCode()+"_"+requestParams.get("distDsm2Id")+".zip");
				trans.setDownloadLink("true");
				trans.setErrorDesc("");

				httpSession.setAttribute("retailerData", trans);
				response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
				if(logger.isDebugEnabled())
					logger.debug("Statement --> View Statement :: StmtGenController : generateCircleWiseStmtPDFZip()  : End :: User Id = "+user.getUserName() );
			}
		}catch(IllegalThreadStateException ite){
			response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
		}catch(NullPointerException e){
			//property not found
			response.sendRedirect(request.getContextPath()+"/retailerStmtDataDownload.jsp");
			//e.printStackTrace();
		}catch(Exception e){
			logger.error("StmtGenController : generateCircleWiseStmtPDFZip()  : Exception :: ",e);
			e.printStackTrace();
		}
	}

	
	@RequestMapping(value = "/generateCircleWiseCsv.action", method = RequestMethod.GET)//downloadValidPayoutReportCSV
	public void testValidDownloadCSV(@ModelAttribute CSVModelInput csvModel, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User user = (User)httpSession.getAttribute("appUser");
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 4 || user.getRoleId() == 5 || user.getRoleId() == 7)){
			response.setContentType("text/csv");
			response.setHeader("Cache-Control", "max-age=30");
			response.setHeader("Content-Disposition","attachment;filename=Download.csv");
			GenerateCSV csvGenerator = new GenerateCSV();

			String cpName=request.getParameter("cpName");
			String yearMonth=request.getParameter("startEndDtParam").substring(3, 11);

			StringBuilder buffer = null;
			ByteArrayInputStream bis=null;
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : testValidDownloadCSV()  : Start :: User Id = "+user.getUserName() );

			try{
				if(cpName != null){
					List<StmtCpBean> outputVo = stmtGenSrvc.fetchCpStmt(cpName,yearMonth);
					//System.out.println("csv :: "+outputVo.size());
					if(outputVo!=null && !outputVo.isEmpty()){
						buffer = csvGenerator.constructCpStringBuffer(outputVo);
					}
				}
				if(buffer==null){
					buffer=new StringBuilder(); 
				}
				byte requestBytes[] =((buffer.toString())).getBytes();
				bis = new ByteArrayInputStream(requestBytes);
				byte[] buf = new byte[4000];
				int len;
				while ((len = bis.read(buf)) > 0){
					response.getOutputStream().write(buf, 0, len);
				}
				bis.close();
				response.getOutputStream().flush(); 
				if(logger.isDebugEnabled())
					logger.debug("Statement --> View Statement :: StmtGenController : testValidDownloadCSV()  : End :: User Id = "+user.getUserName() );

			} catch (Exception exe) {
				logger.error("StmtGenController : testValidDownloadCSV()  : Exception :: ",exe);
				exe.printStackTrace();
			} finally {
				if(bis!=null) {
					bis.close();
					response.getOutputStream().flush(); 
				}
			}
		}
	}
	
	
	
	@RequestMapping(value="serviceType.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getServiceType() throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Statement --> View Statement :: StmtGenController : getServiceType()  : Start :: User Id = "+user.getUserName() );

		try{
			if(user!=null){
			List<ServiceType> compList = stmtGenSrvc.getStmtServiceType();
				modelMap.put("data",compList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Statement --> View Statement :: StmtGenController : getServiceType()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("StmtGenController : getServiceType()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	
}

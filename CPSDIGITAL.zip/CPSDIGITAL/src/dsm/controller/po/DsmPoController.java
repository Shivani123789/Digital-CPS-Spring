package dsm.controller.po;

//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

//import org.apache.taglibs.standard.tag.common.core.SetSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.dao.form.ConverageInputService;
//import dsm.dao.form.CoverageOutput;
import dsm.dao.po.DsmPoDAO;
import dsm.model.form.EntityAttributeMaster;
//import dsm.model.DB.CompMaster;
//import dsm.model.form.EntityAttributeMaster;
import dsm.model.po.EaVariables;
//import dsm.model.submit.SubmitScheme;
import dsm.model.search.SearchScheme;
import dsm.service.po.DsmPoService;
//import dsm.service.search.SchemeSearch;


@Controller
@Scope("session")
@RequestMapping(value="/po")
public class DsmPoController {
	
	@Autowired
	private HttpSession httpSession;

	
	@Autowired
	private DsmPoService dsmPoService;

	
	@Autowired
	private DsmPoDAO  poDao;

	
	
	
	
	@Autowired
	private ConverageInputService converageService;

	

	
	
	
	@RequestMapping(value="getCompListPo.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getCompListPo(SearchScheme schemeName) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			
			modelMap.put("data", poDao.getCompListForPo());
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}

	
	
	
	@RequestMapping(value="getLoprList.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getLoprList(SearchScheme schemeName) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			
			modelMap.put("data", dsmPoService.getLopr());
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}

	
	@RequestMapping(value="getEaVariabes.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getEaVariabes(SearchScheme schemeName) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			
			//CoverageOutput output=converageService.getConverageDetails();
			List<EaVariables> var = dsmPoService.getEaVariables();
			List<EntityAttributeMaster> entityAttr = poDao.getInputParameter();
			if(entityAttr!=null && var!=null)
			for(EntityAttributeMaster entatt : entityAttr)
			{
				EaVariables obj = new EaVariables();

				obj.setVariableId(entatt.getEntityAttributeId());
				obj.setVariableName(entatt.getEntityAttributeName());
				obj.setPoAttrType(entatt.getAttrType());
				obj.setPoAttrCatg(entatt.getAttrCatg());
				obj.setOprType(entatt.getFreeTextType());
				var.add(obj);

			}
			

			modelMap.put("data", var);
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}

	@RequestMapping(value="getPOVariabes.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getPOVariabes(SearchScheme schemeName) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			
			//CoverageOutput output=converageService.getConverageDetails();
			List<EaVariables> var = dsmPoService.getEaVariables();
			/*List<EntityAttributeMaster> entityAttr = poDao.getInputParameter();
			if(entityAttr!=null && var!=null)
			for(EntityAttributeMaster entatt : entityAttr)
			{
				EaVariables obj = new EaVariables();

				obj.setVariableId(entatt.getEntityAttributeId());
				obj.setVariableName(entatt.getEntityAttributeName());
				obj.setPoAttrType(entatt.getAttrType());
				obj.setPoAttrCatg(entatt.getAttrCatg());
				obj.setOprType(entatt.getFreeTextType());
				var.add(obj);

			}*/
			

			modelMap.put("data", var);
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}

	
	@RequestMapping(value="getInputType.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getInputType() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			
			modelMap.put("data", poDao.getInputType());
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}
	
	
	@RequestMapping(value="getOpr.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getOpr() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			
			modelMap.put("data", poDao.getOprList());
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}



	
	@RequestMapping(value="getValueType.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getValueType() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			
			modelMap.put("data", poDao.getValueTypeList());
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			//	return modelMap;
		}
		return modelMap;
	}

	
	
}

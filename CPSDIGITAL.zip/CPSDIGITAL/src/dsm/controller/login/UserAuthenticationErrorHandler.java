package dsm.controller.login;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Service;



@Service
public class UserAuthenticationErrorHandler implements AuthenticationFailureHandler/*ApplicationListener<AuthenticationFailureBadCredentialsEvent>*/ {

	@Autowired
	private DataSource dataSource;
	
	
	//private JdbcTemplate jdbcTemplate ;
	
	private static Logger logger = Logger.getLogger (UserAuthenticationErrorHandler.class);
	
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException authEx)	throws IOException, ServletException {
		@SuppressWarnings("deprecation")
		UsernamePasswordAuthenticationToken user =(UsernamePasswordAuthenticationToken)authEx.getAuthentication();
		try{
			inValidateCredentials(user.getName(),user.getCredentials().toString(),request.getRemoteAddr());
		}catch(Exception e){
			e.printStackTrace();
		}
		request.getSession().setAttribute("errorFl", "true");
		response.sendRedirect("login?error=true");
	}
	
	
	private void inValidateCredentials(String userName,String pwd, String ip){
		try{
			/*String encodePassword = "";
			if(pwd!=null){
				byte[] asBytes = Base64.encodeBase64(pwd.getBytes());
				encodePassword = new String(asBytes, "utf-8");
			}*/
			/*if(userName!=null){
			jdbcTemplate = new JdbcTemplate(dataSource);
			String sql=" insert into dsm2_users_history_log select USERNAME,ROLE_ID,CIRCLE_ID,EMAIL,PHONE,CREATED_BY,CREATED_DATE,'"+userName+"',sysdate,FIRSTNAME," +
					" LASTNAME,MIDDLENAME,PASSWORD,PASSWORD_DT,IS_BLOCKED,ISADMIN,'"+encodePassword+"','"+ip+"','Y' from dsm2_users where username = ? ";
			jdbcTemplate.update(sql, new Object[]{userName});
			
			String sql1="Update Dsm2_Users Set WRONG_PASSWORD_FLAG='Y', Retry_Count= Nvl(Retry_Count,0)+1 Where Username=? ";//and NVL(Retry_Count,0)<5
			jdbcTemplate.update(sql1, new Object[]{userName});
			}*/
			
			logger.debug("USER Login UnSuccess  || USER ID : "+userName+ " HOST IP :: "+ip);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
package dsm.controller.login;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import dsm.model.user.User;
import dsm.service.login.LoginService;
import dsm.service.save.SaveDataService;

@Controller
public class MainController {

	@Autowired
	private SaveDataService saveDataService;

	@Autowired
	private LoginService loginService;
	
	
	@Autowired
	private HttpSession httpSession;
	
	private static Logger logger = Logger.getLogger (MainController.class);
	
	@RequestMapping(value =  "/hello**", method = RequestMethod.GET)
	public ModelAndView defaultPage() {

		ModelAndView model = new ModelAndView();
		model.addObject("title", "Spring Security Login Form - Database Authentication");
		model.addObject("message", "This is hello page!");
		model.setViewName("hello");
		return model;
	}


	@RequestMapping(value="getLogoutUser.action",method=RequestMethod.GET)
	public  ModelAndView  getLogoutUser(HttpServletRequest request) throws Exception {
		ModelAndView model = new ModelAndView();
		try{
			User user = (User)httpSession.getAttribute("appUser");
			System.out.println("MainController || getUserDetails || USER Logout Success || USER ID :"+user.getUserName()+" || Host IP : "+request.getRemoteAddr()+"");
			logger.debug("MainController || getUserDetails || USER Logout Success || USER ID :"+user.getUserName()+" || Host IP : "+request.getRemoteAddr()+"");
			model.setViewName("login");
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return model;
		}
	}

	
	
	@RequestMapping(value="getUserDetails.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,Object>  getUserDetails(HttpServletRequest request) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			System.out.println("MainController userDetail.getUsername()************ :: "+userDetail.getUsername());
			logger.debug("MainController || getUserDetails || USER Login Success || USER ID :"+userDetail.getUsername()+" || Host IP : "+request.getRemoteAddr()+" || Welcome");
			httpSession.setAttribute("editMode", "NO");
			//httpSession.setAttribute("circleId",saveDataService.getUserCircle(userDetail.getUsername()).getCircleId());
			httpSession.setAttribute("userId",userDetail.getUsername());
			System.out.println("*************:: "+userDetail);
			User user = loginService.getUserDetails(userDetail.getUsername());
			if(user!=null){
				httpSession.setAttribute("circleCode", user.getUserCircleCode());
				Set<String> roles = new HashSet<String>();
				Collection<? extends GrantedAuthority> authorities = userDetail.getAuthorities();
				for (GrantedAuthority grantedAuthority : authorities) {
					roles.add(grantedAuthority.getAuthority());
				}
				user.setUserRole(roles);

				StringBuffer userInfo = new StringBuffer();
				userInfo.append("[").append("User Name: "+userDetail.getUsername()).append(" | Circle: "+user.getUserCircleCode()).
				append(" | Roles: "+user.getUserRole()).append(" | UserPriv: ").append(user.getUserPrivilege()).append(" ]");
				System.out.println("****  userInfo ***** :::: "+userInfo.toString());
				httpSession.setAttribute("appUser", user);
				httpSession.setAttribute("circleId",user.getCircleId());
				modelMap.put("data", user);
				modelMap.put("success", true);
			}else{
				modelMap.put("success", false);
				httpSession.invalidate();
			}
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
			//modelMap.put("data", "Testing for unauth........");
		}
		return modelMap;
	}

		
	@RequestMapping(value = "/admin**", method = RequestMethod.GET)
	public ModelAndView adminPage() {
		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			UserDetails userDetail = (UserDetails) auth.getPrincipal();
			//auth.getAuthorities().
			//System.out.println(userDetail);
			model.addObject("username", userDetail.getUsername());
		}
		model.addObject("title", "Spring Security Login Form - Database Authentication");
		model.addObject("message", (UserDetails)auth.getCredentials());
		model.setViewName("admin");
		return model;
	}

	@RequestMapping(value = {"/","/login"}, method = RequestMethod.GET)
	public ModelAndView  login(@RequestParam(value = "error",  required = false) String error, 
					     @RequestParam(value = "logout", required = false) String logout) throws Exception {
		
		/*System.out.println("MainController.login 	error::"+error+"\t logout::"+logout+ "user ::: "+httpSession.getAttribute("appUser"));
		ModelAndView model = new ModelAndView();
		
		if (error != null) {
			error="Invalid username and password!";
			model.addObject("error", "Invalid username and password!");
			model.setViewName("login");
		}
		if (logout != null) {
			model.addObject("msg", "You've been logged out successfully.");
			model.setViewName("login?reload=true");
		}
		model.setViewName("login");
		return model;*/
		
		ModelAndView model = new ModelAndView();
		if(httpSession != null)
			error=(String)httpSession.getAttribute("errorFl");
		if (error != null) {
			error="Invalid username and password!";
			model.addObject("error", "Invalid username and password!");
			model.setViewName("login");
		}
		if (logout != null) {
			model.addObject("msg", "You've been logged out successfully.");
			model.setViewName("login?reload=true");
		}
		if(httpSession!=null){
			httpSession.invalidate();
		}
		model.setViewName("login");
		return model;
	
	}
	
	//for 403 access denied page
	@RequestMapping(value = "/403", method = RequestMethod.GET)
	public ModelAndView accesssDenied() {
		ModelAndView model = new ModelAndView();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		UserDetails userDetail = (UserDetails) auth.getPrincipal();
		System.out.println("MainController accesssDenied user info"+userDetail);
		if (!(auth instanceof AnonymousAuthenticationToken)) {
			model.addObject("username", userDetail.getUsername());
		}
		model.setViewName("403");
		return model;
	}

	
	
}
package dsm.controller.postapp;

//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.Calendar;
//import java.util.Date;
import java.util.HashMap;
//import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
//import org.apache.taglibs.standard.tag.common.core.SetSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

//import dsm.dao.form.ConverageInputService;
import dsm.dao.search.SchemeSearchDAO;
//import dsm.model.DB.CompMaster;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.ShellScriptPojo;
import dsm.model.postapp.PostApprovedScheme;
//import dsm.model.submit.SubmitScheme;
//import dsm.model.search.SearchScheme;
import dsm.model.user.User;
import dsm.service.postapp.PostExecService;
//import dsm.service.search.SchemeSearch;
import dsm.service.transData.TransDataSrvc;


@Controller
@Scope("session")
@RequestMapping(value="/postexec")
public class PostExecutionController {
	
	@Autowired
	private HttpSession httpSession;

	@Autowired
	private PostExecService postExecService;

	@Autowired
	SchemeSearchDAO schemeEditDAO = null;

	@Autowired
	TransDataSrvc transDataSrvc = null;

	private static Logger logger = Logger.getLogger (PostExecutionController.class);
	
/*	@RequestMapping(value="getSchemeList.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getschemeList(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
	//	httpSession.setAttribute("updateVersion",Boolean.FALSE);
		try{
			if(((schemeName.getStartDate()==null) ||(schemeName.getStartDate().length()<1 ))
					||(schemeName.getEndDate()==null)
					)
			{
				Calendar cal = Calendar.getInstance();
				cal.setTime(Calendar.getInstance().getTime());
				cal.add(Calendar.DATE, -30);
				Date dateBefore30Days = cal.getTime();
				
				DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
				
				String startDate = df.format(dateBefore30Days);
				String endDate = df.format(new Date());
				schemeName.setStartDate(startDate);
				schemeName.setEndDate(endDate);
					
			}
			if(httpSession.getAttribute("circleId")!=null)
			{
				int circleId = Integer.valueOf(httpSession.getAttribute("circleId").toString());
			schemeName.setCircleId(circleId);
			}
			schemeName.setCondParam("A");
			
			//logger.debug("nullllllllllllllllll"+schemeName.isStage());
			modelMap.put("data",schemeEditDAO.searchSchemeView(
					schemeName.getStartDate(),
					schemeName.getEndDate(),
					schemeName.getCondParam(),
					schemeName.getCircleId()));
		
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
*/
	
	@RequestMapping(value="updateScheme.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> updateScheme(PostApprovedScheme schemeName,HttpServletRequest request) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User appUser = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Payout Approval   :: PostExecutionController : updateScheme()  : Start :: User Id = "+appUser.getUserName() );
		
		if(appUser != null && (appUser.getRoleId() == 1 || appUser.getRoleId() == 4 || appUser.getRoleId() == 5 || appUser.getRoleId() == 7)){
			logger.debug(" DSM POST EXEC COntroller :::::"+schemeName.getSchemeId());
			if(request.getParameter("schemeId")!=null)
				schemeName.setSchemeId(Integer.parseInt(request.getParameter("schemeId")));
			if(request.getParameter("compId")!=null)
				schemeName.setCompId(Integer.parseInt(request.getParameter("compId")));

			schemeName.setCircleId(appUser.getCircleId());
			schemeName.setUserCode(appUser.getUserName());
			try{
				String value = postExecService.payoutScheme(schemeName);
				modelMap.put("success",Boolean.TRUE);
				modelMap.put("errorMessage", value);
			} catch (Exception e) {
				logger.error("Approvals --> Payout Approval   :: PostExecutionController : updateScheme()   :: User Id = "+appUser.getUserName()+" Exception ::",e );
				e.printStackTrace();
				modelMap.put("success", false);
			}
		}else{
			modelMap.put("success",Boolean.FALSE);
			modelMap.put("errorMessage", "You are not having this privilege access...");			
		}
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Payout Approval   :: PostExecutionController : updateScheme()  : End :: User Id = "+appUser.getUserName() );
		
		return modelMap;
	}

	
	
	@RequestMapping(value="testValidateApproveScheme.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 	testValidateScheme(SchemeMaster schemeMaster,HttpServletRequest request) throws Exception  {
		Map<String, Object> data = new HashMap<String, Object>();
		User appUser = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Payout Approval   :: PostExecutionController : testValidateScheme()  : Start :: User Id = "+appUser.getUserName() );
		
		if(appUser != null && (appUser.getRoleId() == 1 || appUser.getRoleId() == 4 || appUser.getRoleId() == 5 || appUser.getRoleId() == 7)){
			logger.debug(" DSM Post EXEC Controller :::::"+schemeMaster.getSchemeINputId());
			String schemeId =  request.getParameter("output");
			String compId = request.getParameter("compId");
			String condiType = request.getParameter("condiType");
			if(schemeMaster!= null){
				schemeMaster=new SchemeMaster();
			}
			schemeMaster.setCircleId(appUser.getCircleId());
			schemeMaster.setUserName(appUser.getUserName());
			schemeMaster.setCompID(Integer.parseInt(compId));
			schemeMaster.setSchemeINputId(Integer.parseInt(schemeId));
			schemeMaster.setStatus("O");
			try
			{
				ShellScriptPojo shellScript = new ShellScriptPojo();
				shellScript.setSchemeId(schemeId);
				shellScript.setCompId(compId);
				shellScript.setConditionId("0");
				shellScript.setType(schemeMaster.getStatus());
				shellScript.setCircleId(String.valueOf(appUser.getCircleId()));
				shellScript.setQualityType("0");
				shellScript.setPaymentId("0");
				shellScript.setUniverseId("0");

				if(appUser != null )
				{
					shellScript.setUserId(appUser.getUserName());
					String value = transDataSrvc.getExtractDataTime(shellScript);
					data.put("success", false);
					data.put("errorMessage", value);
					if(value != null)
						return data;
				}

				String value = postExecService.testValidApproveScheme(schemeMaster);
				data.put("success",Boolean.TRUE);
				data.put("errorMessage", value);
				//	data.put("Message", postExecService.testValidApproveScheme(schemeMaster));
				/*if(flag)
				{
					data.put("success",Boolean.TRUE);
					data.put("errorMessage", value);
				}
				else
				{
					data.put("success",Boolean.FALSE);
					data.put("errorMessage", value);
				}*/

			}catch(Exception e)
			{
				logger.error("Approvals --> Payout Approval   :: PostExecutionController : testValidateScheme()   :: User Id = "+appUser.getUserName()+" Exception ::",e );
				e.printStackTrace();
				data.put("success",Boolean.FALSE);
				data.put("errorMessage", e.getMessage().toString());
			}


		}else{
			data.put("success",Boolean.FALSE);
			data.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Payout Approval   :: PostExecutionController : testValidateScheme()  : End :: User Id = "+appUser.getUserName() );
		
		return data;
	}
}

package dsm.controller.bulkUpload;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import dsm.model.DB.BulkUploadMaster;
import dsm.model.form.BulkLoadFileStatus;
import dsm.model.form.BulkRejectFileDetails;
import dsm.model.form.BulkSchemeComponentList;
import dsm.model.form.DocTypeList;
import dsm.model.form.UploadMailStatusData;
import dsm.model.user.User;
import dsm.service.bulk.BulkUploadService;

@Controller
@Scope("session")
@RequestMapping(value="/bulkUpload")
public class DsmBulkUploadController {

	@Autowired
	private HttpSession httpSession;
	
	@Autowired
	private BulkUploadService bulkUploadService;
		
	private static Logger logger = Logger.getLogger (DsmBulkUploadController.class);
	
	@RequestMapping(value="bulkFileUpload.action",method=RequestMethod.POST)
	public @ResponseBody /*Map<String, Object>*/String isBulkFileUpload(BulkUploadMaster bulkFile) throws Exception {
		String value = null;
		User appUser = (User)httpSession.getAttribute("appUser");
		if(appUser != null && (appUser.getRoleId() == 1 || appUser.getRoleId() == 2)){
			try{
				String[] fileName = bulkFile.getFileUpload().getOriginalFilename().split("_");

				if(bulkFile.getFileUpload().getOriginalFilename() != null && !"".equalsIgnoreCase(bulkFile.getFileUpload().getOriginalFilename().trim())){
					if(logger.isDebugEnabled()){
						logger.debug("Configuration --> Bulk Upload file # DsmBulkUploadController : isBulkFileUpload() Start  :: UserId = "+appUser.getUserName());
						logger.debug("DsmBulkUploadController . isBulkFileUpload :: compId :: "+bulkFile.getComponentId()+" Scheme :: "+bulkFile.getSchemeId()+"  FileName :: "+bulkFile.getFileUpload().getOriginalFilename()+"\t stdt:: "+bulkFile.getStartDate()+"\t enddt::: "+bulkFile.getEndDate());
					}
					
					if(fileName[0].equalsIgnoreCase(appUser.getUserCircleCode()))
					{
						if(fileNameValidate(bulkFile.getFileUpload().getOriginalFilename(), bulkFile.getFileTypeId())){
							File file = convert(bulkFile.getFileUpload());
							if( bulkFile.getFileTypeId()==1)
								value = bulkUploadService.fetchFileData(appUser.getUserName(), bulkFile.getFileTypeId(), file, appUser.getUserCircleCode(), bulkFile.getSchemeId(), bulkFile.getComponentId());
							else
								value = bulkUploadService.processFileData(appUser.getUserName(), bulkFile.getFileTypeId(), file, appUser.getUserCircleCode(), bulkFile.getSchemeId(), bulkFile.getComponentId(), appUser.getCircleId(),bulkFile.getStartDate(),bulkFile.getEndDate());
								logger.debug("DsmBulkUploadController . isBulkFileUpload :: value :: "+value);
						}else{
							value="The file name does not adhere to correct naming convention. <br>Please refer 'Template' menu from the navigation panel to get the naming convention.";
						}
					}else{
						value="Wrong Circle File Uploaded. ";  
					}
					if(value != null)
					{
						//	data.put("success",Boolean.TRUE);
						//	data.put("errorMessage", value);
					}
					else
					{
						//	data.put("success",Boolean.FALSE);
						//	data.put("errorMessage", value);
					}
				}else{
					value = "Please upload a file.";
				}
			}catch(Exception e)
			{
				logger.error("",e);
				e.printStackTrace();
				//data.put("success",Boolean.FALSE);
				//data.put("errorMessage",e.getMessage());
				return "{\"success\":false, \"errorMessage\":\""+e.getMessage()+"\"}";
			}
			logger.debug("isBulkFileUpload ======>>>>>>> "+value);
			if(value!=null){
				value = value.replace("\"", "\'");
				value = value.replace(",", " ");
				value = value.replace(":", " ");
			}
			return "{\"success\":true, \"errorMessage\":\""+value.trim().toString()+"\"}";		
		}else{
			value = "You are not having this privilege access...";
			return "{\"success\":true, \"errorMessage\":\""+value.trim().toString()+"\"}";
		}
	}

	
	
	@RequestMapping(value="/getBulkSchemeList.action")
	public @ResponseBody Map<String,? extends Object> getBulkSchemeList(BulkSchemeComponentList bscl) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User appUser = (User)httpSession.getAttribute("appUser");
		try{
			System.out.println("filename :: "+bscl.getFileUpload()+"\t fileId :: "+bscl.getPayTo());
			if(appUser!=null && appUser.getCircleId()!=0){
				if(bscl!=null && bscl.getFileUpload()!=null )
				httpSession.setAttribute("fileName", bscl.getFileUpload());
				else{
					if(httpSession.getAttribute("fileName")!=null)
					bscl.setFileUpload(httpSession.getAttribute("fileName").toString());
				}
			BulkSchemeComponentList output=bulkUploadService.getBulkSchemeComponentList(bscl.getFileUpload(), appUser.getCircleId());
			modelMap.put("data", output.getBulkSchemeMasterList());
			System.out.println("output.getBulkSchemeMasterList() :::: "+output.getBulkSchemeMasterList());
			}
			return modelMap;
			
		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}
	
	@RequestMapping(value="/getBulkComponentList.action")
	public @ResponseBody Map<String,? extends Object> getBulkComponentList(BulkSchemeComponentList bscl) throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User appUser = (User)httpSession.getAttribute("appUser");
		try{
			if(appUser!=null && appUser.getCircleId()!=0){
				if(bscl!=null && bscl.getFileUpload()!=null)
					httpSession.setAttribute("fileName", bscl.getFileUpload());
					else{
						bscl.setFileUpload(httpSession.getAttribute("fileName").toString());
					}
			BulkSchemeComponentList output=bulkUploadService.getBulkSchemeComponentList(bscl.getFileUpload(), appUser.getCircleId());
			modelMap.put("data", output.getBulkComponentMasterList());
			System.out.println("output.getBulkComponentMasterList()  :::: "+output.getBulkComponentMasterList());
			}
			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}
	
	private File convert(MultipartFile file) throws IOException
	{    
	    File convFile = new File(file.getOriginalFilename());
	    convFile.createNewFile(); 
	    FileOutputStream fos = new FileOutputStream(convFile); 
	    fos.write(file.getBytes());
	    fos.close(); 
	    return convFile;
	}
	
	public File multipartToFile(MultipartFile multipart) throws IllegalStateException, IOException 
	{
	        File convFile = new File( multipart.getOriginalFilename());
	        multipart.transferTo(convFile);
	        return convFile;
	}
	
	private boolean fileNameValidate(String fileName, int fileTypeId){
		System.out.println("fileName:: "+fileName+"\t fileTypeId::: "+fileTypeId);
		
		boolean flag = false;
		switch (fileTypeId) {
		case 1:if(fileName!=null && fileName.contains("SCM_CONFIG")){
			flag=true;
		}
		case 2:if(fileName != null && fileName.contains("ADD_ATTR")){
			flag=true;
		}
		break;
		case 3:if(fileName != null && fileName.contains("ADD_ACT_UNI")){
			flag=true;
		}
		break;
		case 4:if(fileName != null && fileName.contains("ENTITY-LIST")){
			flag=true;
		}
		break;
		case 5:if(fileName != null && fileName.contains("MANUAL-PAYOUT")){
			flag=true;
		}
		break;
		case 6:if(fileName != null && fileName.contains("ADD_DIST_UNI")){
			flag=true;
		}
		break;
		case 7:if(fileName != null && fileName.contains("ADD_RET_UNI")){
			flag=true;
		}
		break;
		case 8:if(fileName != null && fileName.contains("ADD_DSE_UNI")){
			flag=true;
		}
		break;
		case 9:if(fileName != null && fileName.contains("EMAIL_LIST")){
			flag=true;
		}
		break;
		}
		System.out.println("fileNameValidate ::: flag  "+flag);
		return flag;
	}
	
	@RequestMapping(value="/getDocListType.action")
	public @ResponseBody Map<String,? extends Object> getDocListType() throws Exception
	{
		//System.out.println("bulkUploadService || getDocListType || docTypeList:"+docTypeList.getDocFileType()+"::::"+docTypeList.getUploadDocFile().getName());
		Map<String,Object> modelMap = new HashMap<String,Object>();
		User appUser = (User)httpSession.getAttribute("appUser");
		try
		{
			if(appUser!=null && appUser.getCircleId()!=0)
			{
				
				BulkSchemeComponentList output=bulkUploadService.getDocListType();
				modelMap.put("data",output.getDocTypeList());
				
			}
			
			
			
		}
		catch(Exception e)
		{
			
			System.out.println("Exception raised---->Exception is:::::"+e);
			
		}
		return modelMap;
		
	}
	
	@RequestMapping(value="/docFileUpload.action",method=RequestMethod.POST)
	public @ResponseBody String docFileUpload(DocTypeList docTypeList) throws Exception
	{
		User appUser = (User)httpSession.getAttribute("appUser");
		System.out.println("docTypeList.getTypeId() ::::: "+docTypeList.getTypeId()+"\t file type:::: "+docTypeList.getDocFileType());
		String outputMsg=null;
		try{
		if(docTypeList != null && "2".equalsIgnoreCase(docTypeList.getDocFileType()))
	    {
			/*outputMsg = bulkUploadService.validateInputFile(docTypeList);
			if(outputMsg!=null)
			{
				return "{\"success\":false,\"outputMsg\":\""+outputMsg+"\"}";
			}*/
			String fileName = docTypeList.getUploadDocFile().getOriginalFilename();
			Calendar cal = Calendar.getInstance();
			String[] valuedate = fileName.split("_");
			SimpleDateFormat format = new SimpleDateFormat("yyyyMM");
			Date date = format.parse(valuedate[1]);
			cal.setTime(date);
			int month = Integer.parseInt(valuedate[1].substring(4));
			if(valuedate[0].equalsIgnoreCase(appUser.getUserCircleCode())){
				if(month>=1 && month<=12 ){
					MultipartFile file=docTypeList.getUploadDocFile();
					docTypeList.setCircleCode(appUser.getUserCircleCode());
					docTypeList.setFilePath(System.getProperty("SCHEME_STUDIO_FILE_REPOSITORY"));
					docTypeList.setUserName(appUser.getUserName());
					outputMsg = bulkUploadService.validateInputFile(docTypeList);
					if(outputMsg!=null)
					{
						return "{\"success\":false,\"outputMsg\":\""+outputMsg+"\"}";
					}
					if(outputMsg==null){
						File multiFile=new File(System.getProperty("SCHEME_STUDIO_FILE_REPOSITORY")+docTypeList.getUploadDocFile().getOriginalFilename());
						System.out.println("docFileUpload || File path:"+System.getProperty("SCHEME_STUDIO_FILE_REPOSITORY")+docTypeList.getUploadDocFile().getOriginalFilename());
						file.transferTo(multiFile);
						outputMsg = "File is uploaded successfully.";
					}
				}else{
					//return "{\"success\":false,\"outputMsg\":\"File year and month is not correct.\"}";
					return "{\"success\":false,\"outputMsg\":\"File naming convention is not adhered appropriately. <br> 'Year and Month' given in 'File name' is incorrect.\"}";
				}
			}else{
				//return "{\"success\":false,\"outputMsg\":\"File circle Code is not correct.\"}";
				//return "{\"success\":false,\"outputMsg\":\"'Circle code' given in 'File name' is incorrect.\"}";
				return "{\"success\":false,\"outputMsg\":\"File naming convention is not adhered appropriately. <br> 'Circle code' given in 'File name' is incorrect.\"}";
			}
	    }
	    else if(docTypeList != null && "9".equalsIgnoreCase(docTypeList.getDocFileType()))
	    {

	    	String[] fileName = docTypeList.getUploadDocFile().getOriginalFilename().split("_");
	    	docTypeList.setTypeId(Integer.parseInt(docTypeList.getDocFileType()));
	    	
	    	if(docTypeList.getUploadDocFile().getOriginalFilename() != null && !"".equalsIgnoreCase(docTypeList.getUploadDocFile().getOriginalFilename().trim())){
	    		if(fileName[0].equalsIgnoreCase(appUser.getUserCircleCode())){
	    			if(fileNameValidate(docTypeList.getUploadDocFile().getOriginalFilename(), docTypeList.getTypeId())){
	    				File file = convert(docTypeList.getUploadDocFile());
	    				outputMsg = bulkUploadService.processMailFileData(appUser.getUserName(), docTypeList.getTypeId(), file, appUser.getUserCircleCode(), appUser.getCircleId());
	    			}else{
	    				//value="File name does not adhere to correct naming convention.";
	    				outputMsg="The file name does not adhere to correct naming convention. <br>Please refer 'Template' menu from the navigation panel to get the naming convention.";
	    			}
	    		}else{ 
	    			outputMsg="Wrong Circle File Uploaded. ";
	    		}
	    	}else{
	    		outputMsg = "Please upload a file.";
	    	}
	    }  
		return "{\"success\":true, \"outputMsg\":\""+outputMsg+"\"}";
		
		}catch(ParseException e){
			e.printStackTrace();
			outputMsg=e.getMessage().replace("\"", " ");
			return "{\"success\":true, \"outputMsg\":\"The file name does not adhere to correct naming convention. <br>Please refer 'Template' menu from the navigation panel to get the naming convention.\"}";
		}catch(NumberFormatException e){
			e.printStackTrace();
			outputMsg=e.getMessage().replace("\"", " ");
			return "{\"success\":false, \"outputMsg\":\""+outputMsg+"\"}";
		}catch(Exception e){
			e.printStackTrace();
			outputMsg=e.getMessage().replace("\"", " ");
			return "{\"success\":false, \"outputMsg\":\""+outputMsg+"\"}";
		}
	}
		
	
	@RequestMapping(value="/getUploadData.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object>  getUploadData(UploadMailStatusData uploadMailStatusData) throws Exception
	{
		try{
		User appUser = (User)httpSession.getAttribute("appUser");
		uploadMailStatusData.setCircleCode(appUser.getUserCircleCode());
        System.out.println("DsmBulkUploadController || getUploaData || BEG: circleCode:"+appUser.getUserCircleCode());
		Map<String,Object> modelMap = new HashMap<String,Object>();
		BulkSchemeComponentList getData=bulkUploadService.getUploadData(uploadMailStatusData);
		modelMap.put("data",getData.getUploadMailStatusData());
		return modelMap;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value="/getMailData.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object>  getMailData(UploadMailStatusData uploadMailStatusData) throws Exception
	{
		try{
		User appUser = (User)httpSession.getAttribute("appUser");
		 System.out.println("DsmBulkUploadController || getMailData || BEG: circleCode:"+appUser.getUserCircleCode());
		uploadMailStatusData.setCircleCode(appUser.getUserCircleCode());
		Map<String,Object> modelMap = new HashMap<String,Object>();
		BulkSchemeComponentList getData = bulkUploadService.getMailData(uploadMailStatusData);
		modelMap.put("data",getData.getUploadMailStatusData());
		return modelMap;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	@RequestMapping(value="/getRejectedFileList.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> getRejectedFileList(BulkLoadFileStatus bulkRejectFileDetails) throws Exception
	{
		try{
		User user = (User)httpSession.getAttribute("appUser");
		Map<String,Object> modelMap = new HashMap<String,Object>();
		System.out.println("DsmBulkUploadController || getRejectedFileList || BEG start Date :::: "+bulkRejectFileDetails.getStartDt() +"\t enddate :::: "+bulkRejectFileDetails.getEndDt()+"\t type:: "+bulkRejectFileDetails.getUploadBulkFileType());
		modelMap.put("data",bulkUploadService.getRejectedFileList(bulkRejectFileDetails.getStartDt(), bulkRejectFileDetails.getEndDt(), bulkRejectFileDetails.getUploadBulkFileType(),user.getUserCircleCode()));
		return modelMap;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
}

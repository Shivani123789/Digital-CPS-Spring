package dsm.controller.form.ea;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.dao.ea.SchemeInputEA;
import dsm.dao.ea.SchemeInputEaDAO;
import dsm.dao.form.ConverageInputService;
import dsm.dao.save.SchemeInputAllDAO;
import dsm.model.DB.SchemeEaMaster;
import dsm.model.ea.DataSourceEQModel;
import dsm.model.ea.DayLvlAggr;
import dsm.model.ea.ParameterEQModel;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.form.EntityMaster;
import dsm.model.user.User;
import dsm.service.SchemeInputEAService;


@Controller
@RequestMapping(value="/schemeinput_ea")


public class SchemeInputEaController {

	@Autowired
	private HttpSession httpSession;

	 @Autowired
	    private SchemeInputEAService schemeInputServiceEa;
	
	 
	 @Autowired
		SchemeInputEaDAO schemInputEaDAO = null;
		
	 @Autowired
	    private ConverageInputService converageService;
	 
	 @Autowired
		private SchemeInputAllDAO schemeInputDao;
	 
	 @Autowired
	 SchemeInputEaDAO eaDao;
		

	 
	 @RequestMapping(value="/getEaFilterDataSet.action")
		public @ResponseBody Map<String,? extends Object> getEaFilterDataSet() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				
				modelMap.put("data", eaDao.getEaFilterDataSet());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
		}

	 
	 
	 
	 @RequestMapping(value="/getScmCmpList.action")
		public @ResponseBody Map<String,? extends Object> getScmCmpList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputEA ea =schemeInputServiceEa.getSchemeInputEADetails();
				modelMap.put("data", ea.getSchemeList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
		}
	 
	 @RequestMapping(value="/getDataSetList.action")
		public @ResponseBody Map<String,? extends Object> getDataSetList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputEA ea =schemeInputServiceEa.getSchemeInputEADetails();
				modelMap.put("data", ea.getDataSetList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
}
	 
	 
	 @RequestMapping(value="/getEntityList.action")
		public @ResponseBody Map<String,? extends Object> getEntityList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				dsm.dao.form.CoverageOutput output = converageService.getConverageDetails();
				modelMap.put("data", output.getEntityList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
		}
	
	 
	 
	 @RequestMapping(value="/getDataSourceList.action")
		public @ResponseBody Map<String,? extends Object> getDataSourceList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				//SchemeInputEA ea =schemeInputServiceEa.getSchemeInputEADetails();
				List<DataSourceEQModel> ds = schemeInputServiceEa.getDataSourceList(httpSession.getAttribute("schemeName").toString());
				
				List<SchemeEaMaster> var = schemeInputDao.getEaVaraibles(httpSession.getAttribute("schemeName").toString());
				
				for(SchemeEaMaster s: var)
				{
					DataSourceEQModel obj = new DataSourceEQModel();
					obj.setDataSourceId(s.getVariableId());
					obj.setDataSourceName(s.getVariableName());
					obj.setCompId(s.getCompId());
					obj.setValFlag("V");
					ds.add(obj);
				}
				
				DataSourceEQModel objAdd = new DataSourceEQModel();
				
				objAdd.setDataSourceId(0);
				objAdd.setDataSourceName("Additional");
				objAdd.setValFlag("A");
				ds.add(objAdd);
				
				
				DataSourceEQModel objCore = new DataSourceEQModel();
				
				objCore.setDataSourceId(1);
				objCore.setDataSourceName("Core");
				objCore.setValFlag("A");
				ds.add(objCore);
				
				
				
				
				modelMap.put("data", ds);

				
				return modelMap;

			} catch (Exception e) {	
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
	 	}
	 
	 
	 @RequestMapping(value="/getFunctionList.action")
		public @ResponseBody Map<String,? extends Object> getFunctionList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputEA ea =schemeInputServiceEa.getSchemeInputEADetails();
				modelMap.put("data", ea.getFunctionList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
	 	}
	 
	 
	 @RequestMapping(value="/getParameterList.action")
		public @ResponseBody Map<String,? extends Object> getParameterList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				//SchemeInputEA ea =schemeInputServiceEa.getSchemeInputEADetails();
				
				SchemeInputEA ea = new SchemeInputEA();
				ea.setParameterList(schemInputEaDAO.getParameterList());
				
				dsm.dao.form.CoverageOutput output = converageService.getConverageDetails();
				
				List<ParameterEQModel> param  =ea.getParameterList(); 
				List<EntityMaster> entityList = output.getEntityList();
				List<EntityAttributeMaster> entityAtt = schemInputEaDAO.getEntityAttributeListEa();
				
				for(EntityMaster ent : entityList)
				{
					ParameterEQModel obj = new ParameterEQModel();
					
					obj.setParamId(ent.getEntityId());
					obj.setParamName(ent.getEntityName());
					obj.setValFlag("E");
					param.add(obj);
					
				}
				
				List<SchemeEaMaster> var = schemeInputDao.getEaVaraibles(httpSession.getAttribute("schemeName").toString());
				
				
				for(SchemeEaMaster s:var )
				{
					ParameterEQModel obj = new ParameterEQModel();
					obj.setParamId(s.getVariableId());
					obj.setParamName(s.getVariableName());
					
					obj.setValFlag("V");
					param.add(obj);
				}
				
				
				for(EntityAttributeMaster s:entityAtt )
				{
					ParameterEQModel obj = new ParameterEQModel();
					obj.setParamId(s.getEntityAttributeId());
					obj.setParamName(s.getEntityAttributeName());
					obj.setAttrCatg(s.getAttrCatg());
					obj.setAttrType(s.getAttrType());
					
					obj.setValFlag("AC");
					param.add(obj);
				}
				
				
				modelMap.put("data", param);
				
	
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
	 	}
	 
	 
	 @RequestMapping(value="/getOprList.action")
		public @ResponseBody Map<String,? extends Object> getOprList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputEA ea =schemeInputServiceEa.getSchemeInputEADetails();
				modelMap.put("data", ea.getOprList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
	 	}
	 
	 
	 @RequestMapping(value="/getValueTypeList.action")
	 public @ResponseBody Map<String,? extends Object> getValueTypeList() throws Exception {
		 Map<String,Object> modelMap = new HashMap<String,Object>(3);
		 try{
			 SchemeInputEA ea =schemeInputServiceEa.getSchemeInputEADetails();
			 modelMap.put("data", ea.getValueTypeList());
			 return modelMap;
		 } catch (Exception e) {
			 e.printStackTrace();
			 modelMap.put("success", false);
			 return modelMap;
		 }
	 }
	 
	 @RequestMapping(value="/getDayLvlAggrList.action")
	 public @ResponseBody Map<String,? extends Object> getDayLvlAggrList() throws Exception {
		 Map<String,Object> modelMap = new HashMap<String,Object>(3);
		 try{
			 User appUser = (User)httpSession.getAttribute("appUser");
			 List<DayLvlAggr> ea = schemeInputServiceEa.getDayLvlAggrList(appUser.getCircleId());
			 modelMap.put("data", ea);
			 return modelMap;
		 } catch (Exception e) {
			 e.printStackTrace();
			 modelMap.put("success", false);
			 return modelMap;
		 }
	 }
	
	 	
}

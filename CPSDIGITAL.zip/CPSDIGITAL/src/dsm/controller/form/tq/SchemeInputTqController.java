package dsm.controller.form.tq;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.controller.save.ResponseVO;
import dsm.dao.form.tq.SchemeInputTq;
import dsm.dao.form.tq.SchemeInputTqDAO;
import dsm.model.po.SchemePoMaster;
import dsm.model.user.User;
import dsm.service.SchemeInputTQService;


@Controller
@RequestMapping(value="/schemeinput_tq")
public class SchemeInputTqController {

	
	 @Autowired
	    private SchemeInputTQService schemeInputService;

	 @Autowired
		private HttpSession httpSession;

	 @Autowired
	 SchemeInputTqDAO tqDao;
	
	 private static Logger logger = Logger.getLogger (SchemeInputTqController.class);
	 
	 @RequestMapping(value="getCompListTq.action",method=RequestMethod.GET)
	 public @ResponseBody Map<String,? extends Object> getCompListTq() throws Exception {

	 	Map<String,Object> modelMap = new HashMap<String,Object>(3);
	 	
	 	try{
	 		modelMap.put("data",tqDao.getCompListForTq());
	 		
	 		return modelMap;

	 	} catch (Exception e) {
	 		
	 		e.printStackTrace();
	 		
	 		modelMap.put("success", false);

	 		return modelMap;
	 	}
	 }

	 
	 
	 
	 @RequestMapping(value="getTqValueList.action",method=RequestMethod.GET)
	 public @ResponseBody Map<String,? extends Object> getTqValueList() throws Exception {

	 	Map<String,Object> modelMap = new HashMap<String,Object>(3);
	 	
	 	try{
	 		//System.out.println("scheme name for comp List  : "+httpSession.getAttribute("schemeName"));
	 		//CoverageOutput output=converageService.getCompList(httpSession.getAttribute("schemeName").toString());
	 		modelMap.put("data",schemeInputService.getSchemeInputTQDetails().getValueList());
	 		
	 		return modelMap;

	 	} catch (Exception e) {
	 		
	 		e.printStackTrace();
	 		
	 		modelMap.put("success", false);

	 		return modelMap;
	 	}
	 }
	 
	 @RequestMapping(value="/getScmCmpList.action")
		public @ResponseBody Map<String,? extends Object> getScmCmpList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputTq tq =schemeInputService.getSchemeInputTQDetails();
				modelMap.put("data", tq.getSchemeList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
		}
		
	 
	 @RequestMapping(value="/getdataSetList.action")
		public @ResponseBody Map<String,? extends Object> getdataSetList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputTq tq =schemeInputService.getSchemeInputTQDetails();
				modelMap.put("data", tq.getDataSetList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
		}
		
	 
	 @RequestMapping(value="/getParamList.action")
		public @ResponseBody Map<String,? extends Object> getParamList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputTq tq =schemeInputService.getSchemeInputTQDetails();
				modelMap.put("data", tq.getParamList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
		}
	 
	 @RequestMapping(value="/getOprList.action")
		public @ResponseBody Map<String,? extends Object> getOprList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputTq tq =schemeInputService.getSchemeInputTQDetails();
				modelMap.put("data", tq.getOprList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
		}
	 
	 @RequestMapping(value="/getValueTypeList.action")
		public @ResponseBody Map<String,? extends Object> getValueTypeList() throws Exception {

			Map<String,Object> modelMap = new HashMap<String,Object>(3);
			
			try{
				SchemeInputTq tq =schemeInputService.getSchemeInputTQDetails();
				modelMap.put("data", tq.getValueTypeList());
				
				return modelMap;

			} catch (Exception e) {
				
				e.printStackTrace();
				
				modelMap.put("success", false);

				return modelMap;
			}
		}
	 	
	 	@RequestMapping(value="copyCondition.action", method=RequestMethod.POST)
		@ResponseBody
		public ResponseVO copyPO(@ModelAttribute SchemePoMaster po) throws IOException,Exception
		{
			ResponseVO respVo = new ResponseVO();
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Payout Rules :: SchemeInputTqController : copyPO() : Start :  User Name = "+user.getUserName() );
			
			if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
			{
				int schemeId = Integer.valueOf(httpSession.getAttribute("schemeId").toString());
				if(schemeId!=0 && po != null){
					po.setSchemeId(schemeId);
					//po.setProcessType()
				}
				String  r =  schemeInputService.copyCondition(po);
				if(r==null)
				{
					respVo.setSuccess(false);
					respVo.setMessage("Unable to perform copy condition operation. Please try again.");	
				}
				else
				{
					respVo.setSuccess(true);
					respVo.setMessage(r);
				}
			}else{
				respVo.setSuccess(false);
				respVo.setMessage("You are not having this privilege access...");
			}
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Payout Rules :: SchemeInputTqController : copyPO() : End :  User Name = "+user.getUserName() );
			
			return respVo;
		}
}

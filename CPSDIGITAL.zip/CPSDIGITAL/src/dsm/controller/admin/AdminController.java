package dsm.controller.admin;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.common.utility.DateUtility;
import dsm.model.DB.AttrMappingFiledSet;
import dsm.model.DB.CheckBaselineVO;
import dsm.model.DB.EntAttrMapping;
import dsm.model.DB.HierarchyMismatchVO;
import dsm.model.DB.HierarchySuspense;
import dsm.model.DB.StmtReqMapping;
import dsm.model.form.CircleSchedular;
import dsm.model.user.User;
import dsm.service.admin.AdminService;


@Controller
@Scope("session")
@RequestMapping(value="/admin")
public class AdminController {

	@Autowired
	private HttpSession httpSession;
	
	@Autowired
	AdminService adminSrvc = null;

	private static Logger logger = Logger.getLogger (AdminController.class);

	@RequestMapping(value="getHierarchySuspense.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getCircleMaster(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Hierarchy Suspense # AdminController : getCircleMaster() Start  :: UserId = "+user.getUserName());
			}
			if(requestParams.get("startDate") != null){
				List<HierarchySuspense> hierMap = adminSrvc.getHierarchySuspense(requestParams.get("startDate"), requestParams.get("endDate"), requestParams.get("circleCodeParam"));
				modelMap.put("data",hierMap);
			}
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Hierarchy Suspense # AdminController : getCircleMaster() End  :: UserId = "+user.getUserName());
			}
		} catch (Exception e) {
			logger.error("AdminController : getCircleMaster() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	@RequestMapping(value="getExecHierarchyStamp.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> getExecHierarchyStamp(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Hierarchy Suspense # AdminController : getExecHierarchyStamp() Start  :: UserId = "+user.getUserName());
			}
			if(requestParams.get("startDt") != null){
				String result = adminSrvc.getExecuteHierarchyStamp(requestParams.get("startDt"), requestParams.get("endDt"), requestParams.get("qualifyType"), user.getUserCircleCode(), user.getCircleId(), Integer.parseInt(requestParams.get("unid")));
				modelMap.put("success",true);
				modelMap.put("errorMessage", result);
			}
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Hierarchy Suspense # AdminController : getExecHierarchyStamp() End  :: UserId = "+user.getUserName());
			}
		} catch (Exception e) {
			logger.error("AdminController : getExecHierarchyStamp() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", "Unable to execute Procedure");
		}
		return modelMap;
	}
	
	@RequestMapping(value="updateCircleSchedular.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> updateCircleSchedular(CircleSchedular circleSchedular) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Circle Scheduler # AdminController : updateCircleSchedular() Start  :: UserId = "+user.getUserName());
				logger.debug(circleSchedular.getCircleId()+"\t "+circleSchedular.getDelayTime()+"\t "+circleSchedular.getDistMagin());
			}
			if(circleSchedular != null){
				String result = adminSrvc.updateCircleSchedular(circleSchedular);
				modelMap.put("success",true);
				modelMap.put("errorMessage", result);
			}
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Circle Scheduler # AdminController : updateCircleSchedular() End  :: UserId = "+user.getUserName());
			}
		} catch (Exception e) {
			logger.error("AdminController : updateCircleSchedular() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", "Unable to update.");
		}
		return modelMap;
	}
	
	@SuppressWarnings("deprecation")
	@RequestMapping(value="updateFrcDenoCircleSchedular.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> updateFrcDenoCircleSchedular(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			CircleSchedular circleSchedular = new CircleSchedular();
			circleSchedular.setCircleId(Integer.parseInt(requestParams.get("circleId")));
			circleSchedular.setDenoMonth(requestParams.get("month")+"-"+requestParams.get("year"));
			circleSchedular.setNegativeDay(Integer.parseInt(requestParams.get("circleId")));
			circleSchedular.setDenoSet(requestParams.get("denoSet"));
			circleSchedular.setStartDtStr(DateUtility.getFirstDay(new Date(requestParams.get("month")+"/01/"+requestParams.get("year"))));
			circleSchedular.setEndDtStr(DateUtility.getLastDay(new Date(requestParams.get("month")+"/01/"+requestParams.get("year"))));
			circleSchedular.setExeTillDate(new Date(requestParams.get("exeTillDate")));
			circleSchedular.setMonth(requestParams.get("month"));
			circleSchedular.setYear(requestParams.get("year"));
			
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Circle Scheduler # AdminController : updateFrcDenoCircleSchedular() Start  :: UserId = "+user.getUserName());
				logger.debug(circleSchedular.getCircleId()+"\t stDt:: "+circleSchedular.getStartDtStr()+"\t extDT::: "+requestParams.get("exeTillDate"));
			}
			if(requestParams.get("month") != null && requestParams.get("year")!=null){
				String result = adminSrvc.updateDenoSetCircleSchedular(circleSchedular);
				modelMap.put("success",true);
				modelMap.put("errorMessage", result);
			}
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Circle Scheduler # AdminController : updateFrcDenoCircleSchedular() End  :: UserId = "+user.getUserName());
			}
		} catch (Exception e) {
			logger.error("AdminController : updateFrcDenoCircleSchedular() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", "Unable to update.");
		}
		return modelMap;
	}
	
	@RequestMapping(value="getFrcDenoCircleSchedular.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> getFrcDenoCircleSchedular(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			CircleSchedular circleSchedular = new CircleSchedular();
			circleSchedular.setCircleId(Integer.parseInt(requestParams.get("circleId")));
			circleSchedular.setDenoMonth(requestParams.get("month")+"-"+requestParams.get("year"));
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Circle Scheduler # AdminController : getFrcDenoCircleSchedular() Start  :: UserId = "+user.getUserName());
				logger.debug("monthDeno ::: "+circleSchedular.getDenoMonth()+"  \t circleId::"+circleSchedular.getCircleId());
			}

			if(requestParams.get("month") != null && requestParams.get("year")!=null){
				CircleSchedular result = adminSrvc.getFrcDenoCircleSchedular(circleSchedular);
				modelMap.put("success",true);
				modelMap.put("denoSet", result.getDenoSet());
				modelMap.put("exeTillDate", result.getExeTillDate());
				modelMap.put("negativeDays", result.getNegativeDay());
			}
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Circle Scheduler # AdminController : getFrcDenoCircleSchedular() End  :: UserId = "+user.getUserName());
			}
		} catch (Exception e) {
			logger.error("AdminController : getFrcDenoCircleSchedular() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", "No data found / Unable to fetch data.");
		}
		return modelMap;
	}
	
	@RequestMapping(value="getHierarchyMismatch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getHierarchyMismatch(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Hierarchy Suspense # AdminController : getHierarchyMismatch() Start  :: UserId = "+user.getUserName());
				logger.debug("stDt::"+requestParams.get("startDate")+"\t enDT:: "+ requestParams.get("endDate")+"\t cir:: "+ requestParams.get("circleCodeParam")+"\t type:: "+requestParams.get("typeParam"));
			}
			if(requestParams.get("startDate")!=null && requestParams.get("circleCodeParam")!=null && requestParams.get("typeParam")!=null){
				List<HierarchyMismatchVO> hierMap = adminSrvc.getHierarchyMismatch( requestParams.get("circleCodeParam"),requestParams.get("startDate"), requestParams.get("endDate"),requestParams.get("typeParam"));
				modelMap.put("data",hierMap);
			}
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Hierarchy Suspense # AdminController : getHierarchyMismatch() End  :: UserId = "+user.getUserName());
			}
		} catch (Exception e) {
			logger.error("AdminController : getHierarchyMismatch() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	
	@RequestMapping(value="getScmDataAnalysis.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getScmDataAnalysis(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Data Analysis # AdminController : getScmDataAnalysis() Start  :: UserId = "+user.getUserName());
				logger.debug("getScmDataAnalysis stDt:: "+requestParams.get("startDate")+"\t eDt:: "+requestParams.get("endDate")+"\t cid:: "+requestParams.get("circleId")+"\t scID:: "+requestParams.get("schemeId")+"\t compId:: "+requestParams.get("compId")+"\t type:: "+requestParams.get("typeParam"));
			}
			if(requestParams.get("startDate")!=null && requestParams.get("circleId")!=null && requestParams.get("typeParam")!=null  && 
					requestParams.get("schemeId")!=null  && requestParams.get("compId")!=null && requestParams.get("endDate")!=null){
				List<CheckBaselineVO> hierMap = adminSrvc.getScmDataAnalysis(Integer.parseInt(requestParams.get("circleId")),requestParams.get("startDate"), requestParams.get("endDate"),Integer.parseInt(requestParams.get("schemeId")),Integer.parseInt(requestParams.get("compId")),requestParams.get("typeParam").trim());
				modelMap.put("data",hierMap);
			}
			if(logger.isDebugEnabled()){
				logger.debug("Admin --> Data Analysis # AdminController : getScmDataAnalysis() End  :: UserId = "+user.getUserName());
			}
		} catch (Exception e) {
			logger.error("AdminController : getScmDataAnalysis() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}


	@RequestMapping(value="getAttrConfigStore.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getAttrConfigStore(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : getAttrConfigStore() Start  :: UserId = "+user.getUserName());
			List<EntAttrMapping> attrMappingStore = adminSrvc.getAttrMapping(user.getCircleId());
			modelMap.put("data",attrMappingStore);
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : getAttrConfigStore() End  :: UserId = "+user.getUserName());
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
	
	
	
	@RequestMapping(value="saveAttrConfigStore.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> saveAttrConfigStore(@ModelAttribute EntAttrMapping obj ) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : saveAttrConfigStore() Start  :: UserId = "+user.getUserName());

			String value="";
			if(obj.getId()>0){
				modelMap.put("success", true);
				modelMap.put("errorMessage", "Not allowed to add attribute. Attribute already exists.");
				return 	modelMap;
			}
			obj.setInsertTime(new Date());
			obj.setUpdateTime(new Date());
			obj.setFunctionFlag("Y");
			obj.setOprFlag("Y");
			obj.setValFlag("Y");
			obj.setCircleId(user.getCircleId());			

			if("Y".equals(obj.getTqFlag()))
				obj.setTqFlag("Y");
			else
				obj.setTqFlag("N");

			if("Y".equals(obj.getEntAggFlag()))
				obj.setEntAggFlag("Y");
			else
				obj.setEntAggFlag("N");

			if("Y".equals(obj.getPayCondFlag()))
				obj.setPayCondFlag("Y");
			else
				obj.setPayCondFlag("N");

			if("Y".equals(obj.getCovFlag()))
				obj.setCovFlag("Y");
			else
				obj.setCovFlag("N");

			if(obj.getAttrCatg().equals("Additional"))
				obj.setSrcTblName("DLP_TBL_ENTITY_ADD_ATT_PRESTAG");
			else
				obj.setSrcTblName("DL_ENTITY_HIERARCHY_STAG");

			if(obj.getFreeTxtType().equals("Date")){
				obj.setFreeTxtType("D");
				obj.setDataType("date");
			}else
				if(obj.getFreeTxtType().equals("String")){
					obj.setFreeTxtType("S");
					obj.setDataType("varchar2(50)");
				}else
					if(obj.getFreeTxtType().equals("Number")){
						obj.setFreeTxtType("N");
						obj.setDataType("varchar2(50)");
					}else{
						modelMap.put("success", true);
						modelMap.put("errorMessage", "Data Type is mandatory.");
						return modelMap;
					}
			value = adminSrvc.saveAttrMapping(obj);
			modelMap.put("success", true);
			//modelMap.put("errorMessage", "Added Sucessfully");
			modelMap.put("errorMessage", value);
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : saveAttrConfigStore() End  :: UserId = "+user.getUserName());

		} catch (Exception e) {
			logger.error("AdminController : saveAttrConfigStore() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", e.getMessage());
		}
		return modelMap;
	}
	
	
	@RequestMapping(value="updateAttrConfigStore.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> updateAttrConfigStore(@ModelAttribute EntAttrMapping obj ) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : updateAttrConfigStore() Start  :: UserId = "+user.getUserName());

			if(obj.getId() == 0){
				modelMap.put("success", true);
				modelMap.put("errorMessage", "Not Allowed to update Attribute.");
				return modelMap;
			}
			obj.setInsertTime(new Date());
			obj.setUpdateTime(new Date());
			obj.setFunctionFlag("Y");
			obj.setOprFlag("Y");
			obj.setValFlag("Y");
			obj.setCircleId(user.getCircleId());			

			if("Y".equals(obj.getTqFlag()))
				obj.setTqFlag("Y");
			else
				obj.setTqFlag("N");

			if("Y".equals(obj.getEntAggFlag()))
				obj.setEntAggFlag("Y");
			else
				obj.setEntAggFlag("N");

			if("Y".equals(obj.getPayCondFlag()))
				obj.setPayCondFlag("Y");
			else
				obj.setPayCondFlag("N");

			if("Y".equals(obj.getCovFlag()))
				obj.setCovFlag("Y");
			else
				obj.setCovFlag("N");

			if(obj.getAttrCatg().equals("Additional"))
				obj.setSrcTblName("DLP_TBL_ENTITY_ADD_ATT_PRESTAG");
			else
				obj.setSrcTblName("DL_ENTITY_HIERARCHY_STAG");

			if("Date".equals(obj.getFreeTxtType())){
				obj.setFreeTxtType("D");
				obj.setDataType("date");
			}else
				if("String".equals(obj.getFreeTxtType())){
					obj.setFreeTxtType("S");
					obj.setDataType("varchar2(50)");
				}else
					if("Number".equals(obj.getFreeTxtType())){
						obj.setFreeTxtType("N");
						obj.setDataType("varchar2(50)");
					}else{
						modelMap.put("success", true);
						modelMap.put("errorMessage", "Data Type is mandatory.");
						return modelMap;
					}
			String value = adminSrvc.updateAttrMapping(obj);
			modelMap.put("success", true);
			modelMap.put("errorMessage", value);
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : updateAttrConfigStore() End  :: UserId = "+user.getUserName());

		} catch (Exception e) {
			logger.error("AdminController : updateAttrConfigStore() :: Exception ::",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", e.getMessage());
		}
		return modelMap;
	}
	
	@RequestMapping(value="deleteAttrConfigStore.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> deleteAttrConfigStore(@ModelAttribute EntAttrMapping obj ) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : deleteAttrConfigStore() Start  :: UserId = "+user.getUserName());

			obj.setInsertTime(new Date());
			obj.setUpdateTime(new Date());
			obj.setFunctionFlag("Y");
			obj.setOprFlag("Y");
			obj.setValFlag("N");

			if(!obj.getTqFlag().equals("Y"))
				obj.setTqFlag("N");

			if(!obj.getEntAggFlag().equals("Y"))
				obj.setTqFlag("N");

			if(!obj.getPayCondFlag().equals("Y"))
				obj.setTqFlag("N");

			if(obj.getAttrCatg().equals("Additional"))
				obj.setSrcTblName("DLP_TBL_ENTITY_ADD_ATT_PRESTAG");
			else
				obj.setSrcTblName("DL_ENTITY_HIERARCHY_STAG");

			if(obj.getFreeTxtType().equals("Date"))
				obj.setFreeTxtType("D");

			if(obj.getFreeTxtType().equals("String"))
				obj.setFreeTxtType("S");

			if(obj.getFreeTxtType().equals("Number"))
				obj.setFreeTxtType("N");

			adminSrvc.deleteAttrMapping(obj);

			modelMap.put("success", true);
			modelMap.put("errorMessage", "Deleted Sucessfully");
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : deleteAttrConfigStore() End  :: UserId = "+user.getUserName());
		} catch (Exception e) {
			logger.error("AdminController : deleteAttrConfigStore() :: Exception ::",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", e.getMessage());
		}
		return modelMap;
	}
	
	@RequestMapping(value="getAttrMappingFieldSet.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getAttrMappingFieldSet(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled())
				logger.debug("Admin --> Attribute Config # AdminController : getAttrMappingFieldSet() Start  :: UserId = "+user.getUserName());
			String attrType = requestParams.get("attrTypeName");
			if( attrType != null){
				httpSession.setAttribute("attrType", attrType);
			}else{
				attrType = (String)httpSession.getAttribute("attrType");
			}
			httpSession.setAttribute("attrType", attrType);
			logger.debug("attrType :::: "+attrType);
			List<AttrMappingFiledSet> attrMappingStore = adminSrvc.getAttrMappingFieldSet(user.getCircleId(),attrType);
			modelMap.put("data",attrMappingStore);
			if(logger.isDebugEnabled())
				logger.debug("Reports --> Statement # AdminController : getAttrMappingFieldSet() End  :: UserId = "+user.getUserName());
		} catch (Exception e) {
			logger.error("AdminController : getAttrMappingFieldSet() Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	
	@RequestMapping(value="getStmtReqStore.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getStmtReqStore(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			String stmtDt = requestParams.get("startDate");
			String stmtCycleId = requestParams.get("stmtCycleId");
			if(stmtDt!=null){
				String[] str = stmtDt.split("TO");
				if(logger.isDebugEnabled())
					logger.debug("Reports --> Statement # AdminController : getStmtReqStore() Start  :: UserId = "+user.getUserName()+" :: circle = "+user.getUserCircleCode()+" :: EndDT = "+str[1]);
				List<StmtReqMapping> removeMap=new ArrayList<StmtReqMapping>();
				List<StmtReqMapping> attrMappingStore = adminSrvc.getStmtReq(user.getCircleId(),user.getUserCircleCode(),str[1],requestParams.get("serviceType"));

				List<StmtReqMapping> removeMappingStore = adminSrvc.removeScmStmtReq(user.getUserCircleCode(), str[1],stmtCycleId);
				//attrMappingStore.removeAll(removeMappingStore);
				for(StmtReqMapping val : attrMappingStore){
					for(StmtReqMapping value :  removeMappingStore){
						if(val.getScmId()==value.getScmId()){
							if(val.getCompId()==value.getCompId())
								removeMap.add(val);
						}
					}	
				}
				attrMappingStore.removeAll(removeMap);
				modelMap.put("data",attrMappingStore);
			}
			if(logger.isDebugEnabled())
				logger.debug("Reports --> Statement # AdminController : getStmtReqStore() End  :: UserId = "+user.getUserName());
			
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
}

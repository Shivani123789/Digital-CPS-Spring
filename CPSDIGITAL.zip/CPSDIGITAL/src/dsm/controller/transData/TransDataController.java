package dsm.controller.transData;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.common.utility.FormValidateUtil;
import dsm.dao.transData.TransDataDAO;
import dsm.generate.report.ExecuteShellScript;
import dsm.model.DB.CompMaster;
import dsm.model.DB.InputTypeMasterVO;
import dsm.model.DB.PaymentDetailVO;
import dsm.model.DB.PaymentVO;
import dsm.model.DB.SchemeTqMaster;
import dsm.model.DB.ShellScriptPojo;
import dsm.model.DB.TransSubData;
import dsm.model.DB.UniverseMasterVO;
import dsm.model.search.SearchScheme;
import dsm.model.user.User;
import dsm.service.transData.TransDataSrvc;
//import javax.servlet.RequestDispatcher;


@Controller
@Scope("session")
@RequestMapping(value="/transData")
public class TransDataController {

	@Autowired
	private HttpSession httpSession;

	@Autowired
	TransDataDAO transDataDAO = null;
	
	@Autowired
	TransDataSrvc transDataSrvc = null;

	private static Logger logger = Logger.getLogger (TransDataController.class);

	@RequestMapping(value="getTransDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransDataSearch(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Report --> Transaction Data :: TransDataController : getTransDataSearch()  : Start :: User Id = "+user.getUserName() );

			if(schemeName != null && schemeName.getEndDate()!=null)
				schemeName.setCircleId(user.getCircleId());
			if(schemeName != null && schemeName.getStartDate()!=null && schemeName.getEndDate()!=null)
			{
				List<CompMaster> compList = transDataDAO.searchTransactionData(schemeName.getCondParam(),schemeName.getStartDate(),schemeName.getEndDate(),schemeName.getCircleId());
				modelMap.put("data",compList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Report --> Transaction Data :: TransDataController : getTransDataSearch()  : End :: User Id = "+user.getUserName() );
		} catch (Exception e) {
			logger.error("TransDataController : getTransDataSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}


	@RequestMapping(value="getTransSubDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransSubDataSearch(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Report --> Transaction Data :: TransDataController : getTransSubDataSearch()  : Start :: User Id = "+user.getUserName() );

			if(schemeName != null && schemeName.getEndDate()!=null)
				schemeName.setCircleId(user.getCircleId());
			if(schemeName != null && schemeName.getSchemeId()!=0 && schemeName.getCompId()!=0)
			{
				List<SchemeTqMaster> tqList = transDataDAO.getTransactionSubData(schemeName.getSchemeId(), schemeName.getCompId(),schemeName.getCircleId());
				modelMap.put("data",tqList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Report --> Transaction Data :: TransDataController : getTransSubDataSearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
				logger.error("TransDataController : getTransSubDataSearch()  : Exception :: ", e );
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}


	@RequestMapping(value="getTransSubDataEASearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransSubDataEASearch(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Report --> Transaction Data :: TransDataController : getTransSubDataEASearch()  : Start :: User Id = "+user.getUserName() );

			if(schemeName != null && schemeName.getEndDate()!=null)
				schemeName.setCircleId(user.getCircleId());
			if(schemeName != null && schemeName.getSchemeId()!=0)
			{
				List<SchemeTqMaster> tqList = transDataDAO.getTransactionSubData(schemeName.getSchemeId(), schemeName.getCompId(),schemeName.getCircleId());
				modelMap.put("data",tqList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Report --> Transaction Data :: TransDataController : getTransSubDataEASearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("TransDataController : getTransSubDataEASearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}


	@RequestMapping(value="getTransPaymentDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransPaymentDataSearch(@ModelAttribute SearchScheme schemeName) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Report --> Payment Data :: TransDataController : getTransPaymentDataSearch()  : Start :: User Id = "+user.getUserName() );

			if(schemeName != null && schemeName.getEndDate()!=null){
				schemeName.setCircleId(user.getCircleId());
				schemeName.setCircleCode(user.getUserCircleCode());
			}
			if(schemeName.getEndDate()==null){
				schemeName.setEndDate(httpSession.getAttribute("endDate").toString());
			}else{
				httpSession.setAttribute("endDate", schemeName.getEndDate());
			}
			if(schemeName != null && schemeName.getEndDate()!=null)
			{
				List<PaymentVO> tqList = transDataDAO.getTransactionPaymentData(schemeName);
				if((tqList.size()!=0))
					modelMap.put("totalCount",tqList.get(0).getTotalCount());
				modelMap.put("data",tqList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Report --> Payment Data :: TransDataController : getTransPaymentDataSearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("TransDataController : getTransPaymentDataSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	@RequestMapping(value="getTransSubPaymentDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransSubPaymentDataSearch(@ModelAttribute SearchScheme schemeName, HttpServletRequest request) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Report --> Payment Data :: TransDataController : getTransSubPaymentDataSearch()  : Start :: User Id = "+user.getUserName() );

			if(schemeName != null && schemeName.getEndDate()!=null)
				schemeName.setCircleId(user.getCircleId());
			int payId = Integer.parseInt(request.getParameter("paymentId"));
			if(schemeName != null )
			{
				schemeName.setCircleCode(user.getUserCircleCode());
				List<PaymentDetailVO> tqList = transDataDAO.getTransactionSubPaymentData(payId,user.getUserCircleCode());
				modelMap.put("data",tqList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Report --> Payment Data :: TransDataController : getTransSubPaymentDataSearch()  : End :: User Id = "+user.getUserName() );

		} catch (Exception e) {
			logger.error("TransDataController : getTransSubPaymentDataSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}


	@RequestMapping(value="getTransUniverseDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransUniverseDataSearch() throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(logger.isDebugEnabled())
				logger.debug("Report --> Universe Data :: TransDataController : getTransUniverseDataSearch()  : Start :: User Id = "+user.getUserName() );
			List<InputTypeMasterVO> tqList = transDataDAO.getTransactionUniverseData();
			modelMap.put("data",tqList);
			if(logger.isDebugEnabled())
				logger.debug("Report --> Universe Data :: TransDataController : getTransUniverseDataSearch()  : End :: User Id = "+user.getUserName() );
		} catch (Exception e) {
			logger.error("TransDataController : getTransUniverseDataSearch()  : Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	@RequestMapping(value="getTransSubUniverseDataSearch.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTransSubUniverseDataSearch(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			if(logger.isDebugEnabled())
				logger.debug("Report --> Universe Data :: TransDataController : getTransSubUniverseDataSearch()  : Start :: User Id = "+user.getUserName() );
			int universeId = Integer.parseInt(requestParams.get("inputTypeId"));
			String startDt = requestParams.get("startDt");
			String endDt = requestParams.get("endDt");
			String condiParam =  requestParams.get("condiParam");
			logger.debug(" condiParam :: "+condiParam+" universeId :: "+universeId);
			if(user != null )
			{
				List<UniverseMasterVO> tqList = transDataDAO.getTransactionSubUniverseData(universeId,startDt,endDt,user.getUserCircleCode(),condiParam);
				modelMap.put("data",tqList);
			}
			if(logger.isDebugEnabled())
				logger.debug("Report --> Universe Data :: TransDataController : getTransSubUniverseDataSearch()  : End :: User Id = "+user.getUserName() );
		} catch (Exception e) {
			logger.error("TransDataController : getTransSubUniverseDataSearch()  : Exception :: ", e );
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("Error", "Problem in Shell Script");
		}
		return modelMap;
	}

	@RequestMapping(value="getTransExecUniverseDataSearch.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object> getTransExecUniverseDataSearch(@RequestParam Map<String,String> requestParams) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		try{
			DateFormat formatter = new SimpleDateFormat("dd-MMM-yy");
			if(logger.isDebugEnabled())
				logger.debug("Report --> Universe Data :: TransDataController : getTransExecUniverseDataSearch()  : Start :: User Id = "+user.getUserName() );
			
			ShellScriptPojo shellScript = new ShellScriptPojo();
		
			shellScript.setSchemeId(requestParams.get("schemeId") == null ? "0" : requestParams.get("schemeId"));
			shellScript.setCompId(requestParams.get("compId") == null ? "0" : requestParams.get("compId"));
			if("AA".equalsIgnoreCase(requestParams.get("condiParam"))){
				shellScript.setConditionId("0");
			}else{
				shellScript.setConditionId(requestParams.get("condId") == null ? "0" : requestParams.get("condId"));	
			}
			shellScript.setType(requestParams.get("condiParam"));
			shellScript.setCircleId(String.valueOf(user.getCircleId()));
			shellScript.setQualityType(requestParams.get("qualifyType") == null ? "1" : requestParams.get("qualifyType"));
			shellScript.setPaymentId(requestParams.get("paymentId") == null ? "0" : requestParams.get("paymentId"));
			shellScript.setUniverseId(requestParams.get("inputTypeId") == null ? "0" : requestParams.get("inputTypeId"));
			shellScript.setStartDt(requestParams.get("startDt") == null ? "null" :"'"+ requestParams.get("startDt")+"'");
			shellScript.setEndDt(requestParams.get("endDt") == null ? "null" : "'"+requestParams.get("endDt")+"'");
			
			if(("UD".equalsIgnoreCase(requestParams.get("condiParam"))) || ("HLR".equalsIgnoreCase(requestParams.get("condiParam"))) || ("FTA".equalsIgnoreCase(requestParams.get("condiParam"))))
			{
				Date startDateParam = null;
				Date endDateParam = null;

				if(requestParams.get("startDt")!=null && requestParams.get("endDt")!=null){
					startDateParam=formatter.parse(requestParams.get("startDt"));
					endDateParam=formatter.parse(requestParams.get("endDt"));

				}else{
					modelMap.put("errorMessage", "Start date and end date is mandatory.");
					modelMap.put("success", false);
					return modelMap;
				}

				long timeDiff = TimeUnit.DAYS.convert(endDateParam.getTime() - startDateParam.getTime(),TimeUnit.MILLISECONDS);
				int days = transDataDAO.transactionDateValidation(Integer.parseInt(requestParams.get("inputTypeId")), requestParams.get("condiParam"));
				//System.out.println("timeDiff ::: "+timeDiff);
				if((timeDiff+1) > days)
				{
					//System.out.println(" TransDataController || getTransExecUniverseDataSearch || if block");
					modelMap.put("errorMessage", "You can not extract data for more than "+days+" days");
					//modelMap.put("errorMessage", "Difference between start and end dates should be less than or equal to "+days);
					modelMap.put("success", false);
					return modelMap;
				}

				
				
			}
			if(user != null )
			{
				shellScript.setUserId(user.getUserName());
				//String value = transDataSrvc.getExtractDataTime(shellScript);
				String value = transDataSrvc.getExtractDataTimeMinLimit(shellScript);
				modelMap.put("success", false);
				modelMap.put("errorMessage", value);
				if(value != null)
					return modelMap;
			}
			
			if(user != null )
			{
				ExecuteShellScript shell = new ExecuteShellScript();
				String value = shell.callShellScript(shellScript);
				modelMap.put("success", true);
				modelMap.put("errorMessage", value);
				
				//shell = null;
			}
			if(logger.isDebugEnabled())
				logger.debug("Report --> Universe Data :: TransDataController : getTransExecUniverseDataSearch()  : End :: User Id = "+user.getUserName() );
			
		} catch (Exception e) {
				logger.error("TransDataController : getTransExecUniverseDataSearch()  : Exception :: ", e );
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", "Shell script returned error.");
		}
		return modelMap;
	}

	
	@RequestMapping(value="/getTransDataCSVDownload.action")
	public void  getTransNotQualifyData(@ModelAttribute TransSubData transData,HttpServletRequest request, HttpServletResponse response) throws Exception {
		try{
			String path	= new File(System.getProperty("SCHEME_STUDIO_FILE_PATH")).getPath();
			if(path != null){
				User user = (User)httpSession.getAttribute("appUser");
				if(user != null)
					transData.setCircleId(user.getCircleId());
				if(logger.isDebugEnabled())
					logger.debug("Report --> Transaction Data :: TransDataController : getTransNotQualifyData()  : End :: User Id = "+user.getUserName() );
				
				//new XSSRequestWrapper(request);
				//httpSession.setAttribute("transData", transData);
				if(request.getParameter("transSubDataType") != null){
					//System.out.println("check value== "+request.getParameter("transSubDataType"));
					String value = transDataDAO.getCheckType(request.getParameter("transSubDataType"));
					//System.out.println("check value== "+value);
					if(value == null){
						transData.setDownloadLink("false");
						transData.setErrorDesc("No file found or given type is invalid. ");
						////System.out.println("Test in valid ...................");
						response.sendRedirect(request.getContextPath()+"/errorPage.jsp");
						return;
					}
				}
				
				FormValidateUtil fvu = new FormValidateUtil();
				//System.out.println("path ::: "+path + "  schemeId::"+request.getParameter("schemeId"));
				if(request.getParameter("downloadLink")!=null && "true".equalsIgnoreCase(request.getParameter("downloadLink"))){
					transData= new TransSubData();
					transData.setSchemeId(request.getParameter("schemeId") == null ? 0 : Integer.parseInt(request.getParameter("schemeId")));
					transData.setCompId(request.getParameter("compId") == null ? 0 : Integer.parseInt(request.getParameter("compId")));
					transData.setConditionId(request.getParameter("conditionId") == null ? 0 : Integer.parseInt(request.getParameter("conditionId")));
					transData.setTransSubDataType(fvu.stripXSS(request.getParameter("transSubDataType")) == null ? "0" : (fvu.stripXSS(request.getParameter("transSubDataType"))));
					transData.setPaymentId(request.getParameter("paymentId") == null ? 0 : Integer.parseInt(request.getParameter("paymentId")));
					transData.setUniverseId(request.getParameter("universeId") == null ? 0 : Integer.parseInt(request.getParameter("universeId")));
					transData.setQualifyType(request.getParameter("qualifyType") == null ? 0 : Integer.parseInt(request.getParameter("qualifyType")));
					transData.setErrorDesc("No file found. Please extract again.");
					transData.setDownloadLink("false");
					if(!("HS".equalsIgnoreCase(request.getParameter("transSubDataType"))))
						transData.setCircleId(user.getCircleId());
					else{
						int circleId =  transDataDAO.getCircleId(request.getParameter("circleCode") == null ? user.getUserCircleCode() : request.getParameter("circleCode"));
						transData.setCircleId(circleId);
					}
				}else{
					transData.setErrorDesc("");
					transData.setDownloadLink("true");
				}
				//File Path
				StringBuffer csvFilePath = new StringBuffer();
				csvFilePath.append(path).append("/").append(transData.getCircleId()).append("/").append(transData.getTransSubDataType()).append("_");//.append(transData.getCircleId()).append("_");
				csvFilePath.append(transData.getSchemeId()).append("_").append(transData.getCompId()).append("_").append(transData.getConditionId()).append("_");
				csvFilePath.append(transData.getQualifyType()).append("_").append(transData.getPaymentId()).append("_").append(transData.getUniverseId()).append(".zip");
				File downloadFile = new File(csvFilePath.toString());
				transData.setFileName(downloadFile.getName());
				////System.out.println(downloadFile.exists());
				httpSession.setAttribute("transData", transData);
				//If file found
				if(downloadFile.exists()){
					FileInputStream inStream = new FileInputStream(downloadFile);
					//System.out.println("inStream available :: "+inStream.available());
					//System.out.println("file length :: "+downloadFile.length());
					if(downloadFile.length() != -1 ){
						response.setContentType("application/zip");
						response.setContentLength((int) downloadFile.length());
						transData.setErrorDesc("File Downloaded Successfully.");
						String headerKey = "Content-Disposition";
						String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
						response.setHeader(headerKey, headerValue);

						OutputStream outStream = response.getOutputStream();
						byte[] buffer = new byte[4096];
						int bytesRead = -1;
						while ((bytesRead = inStream.read(buffer)) != -1) {
							outStream.write(buffer, 0, bytesRead);
						}
						inStream.close();
						outStream.close();
					}else{
						//No record found
						response.sendRedirect(request.getContextPath()+"/transDataDownload.jsp");
					}
				}else{
					//file not exist
					//transData.setErrorDesc("Please wait .");
					response.sendRedirect(request.getContextPath()+"/transDataDownload.jsp");
				}
			}else{
				//path is not found
				response.sendRedirect(request.getContextPath()+"/transDataDownload.jsp");
			}
		}catch(NullPointerException e){
			//property not found
			response.sendRedirect(request.getContextPath()+"/transDataDownload.jsp");
			//e.printStackTrace();
		}catch(Exception e){
				logger.error("TransDataController : getTransNotQualifyData()  : Exception :: ", e);
				e.printStackTrace();
		}
 	}
 

	
	@RequestMapping(value="/getTransDataCSVFileValidateDownload.action",method=RequestMethod.POST)
	public @ResponseBody Map<String,? extends Object>  getTransDataCSVFileValidateDownload(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			String path	= new File(System.getProperty("SCHEME_STUDIO_FILE_PATH")).getPath();
			if(path != null){
				User user = (User)httpSession.getAttribute("appUser");
				if(logger.isDebugEnabled())
					logger.debug("Report --> Transaction Data :: TransDataController : getTransDataCSVFileValidateDownload()  : Start :: User Id = "+user.getUserName() +"  DownloadFile Name = "+request.getParameter("zipFileName"));
				
				//File Path
				StringBuffer csvFilePath = new StringBuffer();
				
				csvFilePath.append(path).append("/").append(user.getCircleId()).append("/").append(request.getParameter("zipFileName"));

				File downloadFile = new File(csvFilePath.toString());
				//System.out.println("File exists value== "+downloadFile.exists());
				
				modelMap.put("success", Boolean.FALSE);
				modelMap.put("errorMessage", downloadFile.exists());
				
				if(logger.isDebugEnabled())
					logger.debug("Report --> Transaction Data :: TransDataController : getTransDataCSVFileValidateDownload()  : End :: User Id = "+user.getUserName() );
				
			}
		}catch(NullPointerException e){
			logger.error("TransDataController : getTransDataCSVFileValidateDownload() NullException :: ",e);
			e.printStackTrace();
		}catch(Exception e){
			logger.error("TransDataController : getTransDataCSVFileValidateDownload() Exception :: ",e);
			e.printStackTrace();
		}
		return modelMap;
 	}

}

package dsm.controller.csv;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import dsm.model.DB.BulkRejectionDataPojo;
import dsm.model.DB.CPSPaymentVO;
import dsm.model.DB.CheckBaselineVO;
import dsm.model.DB.DistributorVO;
import dsm.model.DB.ExecPayoutStatusVO;
import dsm.model.DB.HierarchyMismatchCsvVO;
import dsm.model.DB.PayoutVO;
import dsm.model.DB.RetailerVO;
import dsm.model.DB.ScmPayoutVO;
import dsm.model.DB.TransDataCSV;
import dsm.model.StmGen.StmtCpBean;
import dsm.model.form.BulkLoadErrorFileStatus;
import dsm.model.form.HoldReleaseAmount;

public class GenerateCSV {

	public StringBuffer constructDistributorStringBuffer(List<DistributorVO>  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		//  List<DistributorVO> listVO = null;
		try{
			buffer.append("Distributor_MSISDN");
			buffer.append(", ");
			buffer.append("Amount");
			buffer.append(", ");
			buffer.append("Remarks");
			buffer.append(", ");
			buffer.append("Region");
			buffer.append(", ");
			buffer.append("Zone");
			buffer.append("\n");	
			
			  if(ouputVo!=null){
				 
				   for(DistributorVO   object: ouputVo){
					buffer.append(object.getDistributorMsisd());
				    buffer.append(", ");   
					buffer.append(object.getAmount());
					buffer.append(", ");
					buffer.append(object.getRemarks());
					buffer.append(", ");
					buffer.append(object.getRegion());
					buffer.append(", ");
					buffer.append(object.getZone());
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
				  
			   	
			
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER DISTRIBUTOR CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}
	
	public StringBuffer constructRetailerStringBuffer(List<RetailerVO>  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			buffer.append("Retailer_MSISDN");
			buffer.append(", ");
			buffer.append("Amount");
			buffer.append(", ");
			buffer.append("Remarks");
			buffer.append(", ");
			buffer.append("Region");
			buffer.append(", ");
			buffer.append("Zone");
			buffer.append("\n");	
			
			  if(ouputVo!=null){
				 
				   for(RetailerVO   object: ouputVo){
					buffer.append(object.getRetailerMsisd());
				    buffer.append(", ");   
					buffer.append(object.getAmount());
					buffer.append(", ");
					buffer.append(object.getRemarks());
					buffer.append(", ");
					buffer.append(object.getRegion());
					buffer.append(", ");
					buffer.append(object.getZone());
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
				  
			   	
			
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER RETAILERS CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}
	
	public StringBuffer constructPayoutStringBuffer(List<PayoutVO>  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			buffer.append("CIRCLE_CODE");
			buffer.append(",");
			buffer.append("REGION");
			buffer.append(",");
			buffer.append("ZONE");
			buffer.append(",");
			buffer.append("SCM_NAME");
			buffer.append(",");
			buffer.append("COMP_NAME");
			buffer.append(",");
			buffer.append("PAY_TO");
			buffer.append(",");
			buffer.append("ENTITY_ID");
			buffer.append(",");
			buffer.append("ENTITY_NAME");
			buffer.append(",");
			buffer.append("VTOPUP_NUMBER");
			buffer.append(",");
			buffer.append("FTA_NUMBER");
			buffer.append(",");
			buffer.append("PAY_NOS");
			buffer.append(",");
			buffer.append("UNDER_ACHIEVEMENT");
			buffer.append(",");
			buffer.append("OVER_ACHIEVEMENT");
			buffer.append(",");
			buffer.append("GROSS_NET");
			buffer.append(",");
			buffer.append("UNIT");
			buffer.append(",");
			buffer.append("GROSS_VALUE");
			buffer.append(",");
			buffer.append("NET_VALUE");
			buffer.append(",");
			buffer.append("TAX");
			
			buffer.append("\n");	
			  if(ouputVo!=null){
				   for(PayoutVO   object: ouputVo){
					buffer.append(object.getCircleCode());
				    buffer.append(",");   
				    buffer.append(object.getRegion());
				    buffer.append(",");
				    buffer.append(object.getZone());
				    buffer.append(",");
				    buffer.append(xssValidation(object.getSchemeName()));
					buffer.append(",");
					buffer.append(xssValidation(object.getComponentName()));
					buffer.append(",");
					buffer.append(object.getPayTo());
				    buffer.append(",");   
					buffer.append(object.getEntityId());
					buffer.append(",");
					buffer.append(object.getEntityName());
					buffer.append(",");
					buffer.append(object.getVtopUpNumber());
					buffer.append(",");
					buffer.append(object.getFtaNumber());
					buffer.append(",");
					buffer.append(object.getPayNos());
					buffer.append(",");
					buffer.append(object.getUnderAchieveStr());
					buffer.append(",");
					buffer.append(object.getOverAchieveStr());
					buffer.append(",");
					buffer.append(object.getGrossNet());
				    buffer.append(",");   
					buffer.append(object.getUnit());
					buffer.append(",");
					buffer.append(object.getGrossValue());
					buffer.append(",");
					buffer.append(object.getNetValue());
					buffer.append(",");
					buffer.append(object.getTax());
					
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER PAYOUT CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}
	
	
	public StringBuffer constructTransDataCSVStringBuffer(TransDataCSV  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			if(ouputVo != null && ouputVo.getColumnName()!=null && ouputVo.getColumnName().size()!=0){
				for(String columnName : ouputVo.getColumnName()){
					buffer.append(columnName);
					buffer.append(", ");
				}
				buffer.append("Error_Message");
				buffer.append("\n");
			}
			ouputVo.setColumnName(null);//=null;
			  if(ouputVo!=null && ouputVo.getValues()!=null && ouputVo.getValues().size()!=0){
				  for (Map.Entry<Integer, List> entry : ouputVo.getValues().entrySet()) {
					  Integer key = entry.getKey();
					  List values = entry.getValue();
					  Iterator itr = values.iterator();
				        while(itr.hasNext()){
				        	buffer.append(itr.next());
						    buffer.append(", ");   
						}
				        buffer.append("");
						buffer.append("\n");
					  }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
					   buffer.append("\n"); 
				   }
			  ouputVo.setValues(null);
			  ouputVo=null;
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING USER CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}
	
	
	public StringBuffer constructPayoutStatusStringBuffer(List<ExecPayoutStatusVO>  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			buffer.append("CIRCLE_NAME");
			buffer.append(", ");
			buffer.append("SCM_ID");
			buffer.append(", ");
			buffer.append("SCHEME_NAME");
			buffer.append(", ");
			buffer.append("COMP_ID");
			buffer.append(", ");
			buffer.append("COMPONENET_NAME");
			buffer.append(", ");
			buffer.append("CON_VAR_ID");
			buffer.append(", ");
			buffer.append("CONFIG_ID");
			buffer.append(", ");
			buffer.append("CONFIG_TYPE_ID");
			buffer.append(", ");
			buffer.append("TABLE_ID");
			buffer.append(", ");
			buffer.append("TABLE_NAME");
			buffer.append(", ");
			buffer.append("START_TIME");
			buffer.append(", ");
			buffer.append("END_TIME");
			buffer.append("\n");	
			  if(ouputVo!=null){
				   for(ExecPayoutStatusVO   object: ouputVo){
					buffer.append(object.getCircleName());
				    buffer.append(", ");   
					buffer.append(object.getSchemeId());
					buffer.append(", ");
					buffer.append(object.getSchemeName());
					buffer.append(", ");
					buffer.append(object.getCompId());
				    buffer.append(", ");   
					buffer.append(object.getCompName());
					buffer.append(", ");
					buffer.append(object.getConVarId());
					buffer.append(", ");
					buffer.append(object.getConfigId());
				    buffer.append(", ");   
					buffer.append(object.getConfigTypeId());
					buffer.append(", ");
					buffer.append(object.getTableId());
					buffer.append(", ");
					buffer.append(object.getTableName());
					buffer.append(", ");
					buffer.append(object.getStartDT());
					buffer.append(", ");
					buffer.append(object.getEndDT());
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER PAYOUT CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}

	public StringBuffer constructHierarchyMisStringBuffer(List<HierarchyMismatchCsvVO>  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			buffer.append("CIRCLE");
			buffer.append(", ");
			buffer.append("HIERARCHY_DATE");
			buffer.append(", ");
			buffer.append("SYSTEMS_INVOLVED");
			buffer.append(", ");
			buffer.append("ENTITY_TYPE");
			buffer.append(", ");
			buffer.append("MOBILE_NUMBER");
			buffer.append(", ");
			buffer.append("FIRST_SYS_MGR");
			buffer.append(", ");
			buffer.append("SECOND_SYS_MGR");
			buffer.append(", ");
			buffer.append("REMARKS");
			buffer.append("\n");	
			  if(ouputVo!=null){
				   for(HierarchyMismatchCsvVO   object: ouputVo){
					buffer.append(object.getCircle());
				    buffer.append(", ");   
					buffer.append(object.getHierDt());
					buffer.append(", ");
					buffer.append(object.getSystemInvolved());
					buffer.append(", ");
					buffer.append(object.getEntityType());
				    buffer.append(", ");   
					buffer.append(object.getMobileNo());
					buffer.append(", ");
					buffer.append(object.getFirstSysMgr());
					buffer.append(", ");
					buffer.append(object.getSecondSysMgr());
				    buffer.append(", ");   
					buffer.append(object.getRemarks());
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER PAYOUT CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}

	
	public StringBuffer constructScmDataAnalysisStringBuffer(List<CheckBaselineVO>  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			buffer.append("CIRCLE");
			buffer.append(", ");
			buffer.append("SCHEME_ID");
			buffer.append(", ");
			buffer.append("SCHEME_NAME");
			buffer.append(", ");
			buffer.append("COMPONENT_ID");
			buffer.append(", ");
			buffer.append("COMPONENT_NAME");
			buffer.append(", ");
			buffer.append("START_DATE");
			buffer.append(", ");
			buffer.append("END_DATE");
			buffer.append(", ");
			buffer.append("PARAM_CATEGORY");
			buffer.append(", ");
			buffer.append("PARAM_NAME");
			buffer.append(", ");
			buffer.append("TOTAL");
			buffer.append(", ");
			buffer.append("VALUE_COUNT");
			buffer.append(", ");
			buffer.append("MISSING_VALUE_COUNT");
			buffer.append(", ");
			buffer.append("REMARKS");
			buffer.append("\n");	
			  if(ouputVo!=null){
				   for(CheckBaselineVO   object: ouputVo){
					buffer.append(object.getCircleId());
				    buffer.append(", ");   
					buffer.append(object.getSchemeId());
					buffer.append(", ");
					buffer.append(object.getSchemeName());
					buffer.append(", ");
					buffer.append(object.getCompId());
				    buffer.append(", ");   
					buffer.append(object.getCompName());
					buffer.append(", ");
					buffer.append(object.getStartDt());
					buffer.append(", ");
					buffer.append(object.getEndDt());
				    buffer.append(", ");   
				    buffer.append(object.getParamCat());
				    buffer.append(", ");   
				    buffer.append(object.getParamName());
				    buffer.append(", ");   
				    buffer.append(object.getRowCount());
				    buffer.append(", ");   
				    buffer.append(object.getValueCount());
				    buffer.append(", ");   
				    buffer.append(object.getMissingValueCount());
				    buffer.append(", ");   
				    buffer.append(object.getRemarks());
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER PAYOUT CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}

	
	
	public StringBuffer constructHoldDataStringBuffer(List<ScmPayoutVO>  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			buffer.append("SCHEME_ID");
			buffer.append(",");
			buffer.append("SCHEME_NAME");
			buffer.append(",");
			buffer.append("COMPONENT_ID");
			buffer.append(",");
			buffer.append("COMPONENT_NAME");
			buffer.append(",");
			buffer.append("START_DATE");
			buffer.append(",");
			buffer.append("END_DATE");
			buffer.append(",");
			buffer.append("PAY_TO");
			buffer.append(",");
			buffer.append("PAYOUT_STATUS");
			buffer.append(",");
			buffer.append("PAYMENT_STATUS");
			buffer.append(",");
			buffer.append("PAYMENT_AMOUNT");
			buffer.append(",");
			buffer.append("PAYMENT_DATE");
			buffer.append(",");
			buffer.append("PAYMENT_TYPE");
			buffer.append(",");
			buffer.append("PRODUCER_ID");
			buffer.append(",");
			buffer.append("VTOPUP_NUMBER");
			buffer.append(",");
			buffer.append("FTA_NUMBER");
			buffer.append(",");
			buffer.append("REMARKS");
			buffer.append("\n");	
			  if(ouputVo!=null){
				   for(ScmPayoutVO   object: ouputVo){
					buffer.append(object.getScmId());
				    buffer.append(",");   
					buffer.append(object.getScmName());
					buffer.append(",");
					buffer.append(object.getCompId());
					buffer.append(",");
					buffer.append(object.getCompName());
				    buffer.append(",");   
					buffer.append(object.getStartDt());
					buffer.append(",");
					buffer.append(object.getEndDt());
					buffer.append(",");
					buffer.append(object.getPayTo());
				    buffer.append(",");   
				    buffer.append(object.getPayoutStatus());
				    buffer.append(",");   
				    buffer.append(object.getPaymentStatus());
				    buffer.append(",");   
				    buffer.append(object.getAmount());
				    buffer.append(",");   
				    buffer.append(object.getPaymentDt());
				    buffer.append(",");   
				    buffer.append(object.getPaymentType());
				    buffer.append(",");   
				    buffer.append(object.getProducerId());
				    buffer.append(",");   
				    buffer.append(object.getVtopupNumber());
				    buffer.append(",");   
				    buffer.append(object.getFtaNumber());
				    buffer.append(",");   
				    buffer.append(object.getRemarks());
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER PAYOUT CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}
	
	public StringBuffer constructReleaseDataStringBuffer(List<HoldReleaseAmount>  ouputVo)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			buffer.append("TRANSACTION_DATE");
			buffer.append(",");
			buffer.append("PAYMENT_TYPE");
			buffer.append(",");
			buffer.append("HOLD_AMOUNT");
			buffer.append(",");
			buffer.append("HOLD_RELEASE_REQUEST");
			buffer.append(",");
			buffer.append("RELEASE_REQUEST_DT");
			buffer.append(",");
			buffer.append("HOLD_RELEASE_STATUS");
			buffer.append(",");
			buffer.append("HOLD_STATUS");
			buffer.append(",");
			buffer.append("RELEASE_DATE");
			buffer.append(",");
			buffer.append("USER_ID");
			buffer.append(",");
			buffer.append("PRODUCER_ID");
			buffer.append(",");
			buffer.append("VTOPUP_NUMBER");
			buffer.append(",");
			buffer.append("FTA_NUMBER");
			buffer.append(",");
			buffer.append("REMARKS");
			buffer.append("\n");	
			  if(ouputVo!=null){
				   for(HoldReleaseAmount   object: ouputVo){
					buffer.append(object.getTransactionDate());
				    buffer.append(",");   
					buffer.append(object.getPaymentType());
					buffer.append(",");
					buffer.append(object.getHoldAmt());
					buffer.append(",");
					buffer.append(object.getHoldReleaseRequest());
				    buffer.append(",");   
					buffer.append(object.getReleaseReqDate());
					buffer.append(",");
					buffer.append(object.getHoldReleaseStatus());
					buffer.append(",");
					buffer.append(object.getHoldStatus());
				    buffer.append(",");   
				    buffer.append(object.getReleaseDate());
				    buffer.append(",");   
				    buffer.append(object.getUserId());
				    buffer.append(",");   
				    buffer.append(object.getProducerId());
				    buffer.append(",");   
				    buffer.append(object.getVtopupNumber());
				    buffer.append(",");   
				    buffer.append(object.getFtaNumber());
				    buffer.append(",");   
				    buffer.append(object.getRemarks());
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER PAYOUT CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}

	
	/*public StringBuffer constructBulkUploadErrorFileStringBuffer(List<BulkLoadErrorFileStatus>  ouputVo, String type)throws Exception
	{
		StringBuffer buffer=new StringBuffer();
		try{
			
			buffer.append("DSM_REF_CODE");
			buffer.append(",");
			buffer.append("PRODUCER_ID");
			buffer.append(",");
			buffer.append("DSM2_REF_CODE");
			buffer.append(",");
			buffer.append("RET_ID");
			buffer.append(",");
			buffer.append("DSE_ID");
			buffer.append(",");
			buffer.append("DIST_ID");
			buffer.append(",");
			buffer.append("MSISDN");
			buffer.append(",");
			
			buffer.append("EVENT_DATE");
			buffer.append(",");
			buffer.append("USER_ID");
			buffer.append(",");
			buffer.append("CIRCLE_CODE");
			buffer.append(",");
			buffer.append("FILE_NAME");
			buffer.append(",");
			buffer.append("REJECTION_REASON");
			buffer.append("\n");	
			  if(ouputVo!=null){
				   for(BulkLoadErrorFileStatus   object: ouputVo){
					buffer.append(object.getDsmrefcode());
				    buffer.append(",");   
					buffer.append(object.getProducerId());
					buffer.append(",");
					buffer.append(object.getDsmrefcode());
					buffer.append(",");
					buffer.append(object.getRetId());
				    buffer.append(",");   
					buffer.append(object.getDseId());
					buffer.append(",");
					buffer.append(object.getDistId());
					buffer.append(",");
					buffer.append(object.getMsisdn());
				    buffer.append(",");   
				    buffer.append(object.getEventDt());
				    buffer.append(",");   
				    buffer.append(object.getUserName());
				    buffer.append(",");   
				    buffer.append(object.getCircleCode());
				    buffer.append(",");   
				    buffer.append(object.getFileName());
				    buffer.append(",");   
				    buffer.append(object.getRejectionReason());
					buffer.append("\n");
				   }
				}else{
					   buffer.append("NO RECORDS AVAILABLE.");
						buffer.append("\n"); 
				   }
		}catch(Exception exe){
			buffer.append("ERROR WHILE DOWNLOADING  USER PAYOUT CVS.");
			exe.printStackTrace();
		}
		return buffer;
	}
*/
	
	
	 public StringBuffer constructRejectionListStringBuffer(List<BulkRejectionDataPojo> bulkRejMap,String confNameType)
	 {
		 StringBuffer buffer=new StringBuffer();
		 try{
			 if(confNameType.equals("ADD_ATTR"))
			 {
				 buffer.append("DSM2_REF_CODE");
				 buffer.append(",");
				 buffer.append("ENTITY_TYPE");
				 buffer.append(",");
			 }else if(confNameType.equals("ADD_ACT_UNI"))
			 {
				 buffer.append("MSISDN");
				 buffer.append(",");
				 buffer.append("EVENT_DATE");
				 buffer.append(",");
			 }else if(confNameType.equals("ADD_DIST_UNI"))
			 {
				 buffer.append("DIST_ID");
				 buffer.append(",");
				 buffer.append("EVENT_DATE");
				 buffer.append(",");
			 }else if(confNameType.equals("ADD_DSE_UNI"))
			 {
				 buffer.append("DSE_ID");
				 buffer.append(",");
				 buffer.append("EVENT_DATE");
				 buffer.append(",");
			 }else if(confNameType.equals("ADD_RET_UNI"))
			 {
				 buffer.append("RET_ID");
				 buffer.append(",");
				 buffer.append("EVENT_DATE");
				 buffer.append(",");
			 }else if(confNameType.equals("ENTITY-LIST"))
			 {
				 buffer.append("PRODUCER_ID");
				 buffer.append(",");
				 buffer.append("ENTITY_TYPE");
				 buffer.append(",");
			 }else if(confNameType.equals("MANUAL-PAYOUT"))
			 {
				 buffer.append("DSM_REF_CODE");
				 buffer.append(",");
				 buffer.append("ENTITY_TYPE");
				 buffer.append(",");
			 }
			 buffer.append("CIRCLE");
			 buffer.append(",");
			 buffer.append("FILE_NAME");
			 buffer.append(",");
			 buffer.append("REJECTION_REASON");
			 buffer.append("\n");
			 if(bulkRejMap!=null)
			 {
				 for(BulkRejectionDataPojo obj:bulkRejMap)
				 {
					 if(confNameType.equals("ADD_ATTR"))
					 {
						 buffer.append(obj.getDsm2RefCode());
						 buffer.append(",");
						 buffer.append(obj.getEntityType());
						 buffer.append(",");
					 }else if(confNameType.equals("ADD_ACT_UNI"))
					 {
						 buffer.append(obj.getMsisdn());
						 buffer.append(",");
						 buffer.append(obj.getEventDate());
						 buffer.append(",");
					 }else if(confNameType.equals("ADD_DIST_UNI"))
					 {
						 buffer.append(obj.getDistId());
						 buffer.append(",");
						 buffer.append(obj.getEventDate());
						 buffer.append(",");
					 }else if(confNameType.equals("ADD_DSE_UNI"))
					 {
						 buffer.append(obj.getDseId());
						 buffer.append(",");
						 buffer.append(obj.getEventDate());
						 buffer.append(",");
					 }else if(confNameType.equals("ADD_RET_UNI"))
					 {
						 buffer.append(obj.getRetId());
						 buffer.append(",");
						 buffer.append(obj.getEventDate());
						 buffer.append(",");
					 }else if(confNameType.equals("ENTITY-LIST"))
					 {
						 buffer.append(obj.getProducerId());
						 buffer.append(",");
						 buffer.append(obj.getEntityType());
						 buffer.append(",");
					 }else if(confNameType.equals("MANUAL-PAYOUT"))
					 {
						 buffer.append(obj.getDsmRefCode());
						 buffer.append(",");
						 buffer.append(obj.getEntityType());
						 buffer.append(",");
					 }
					 buffer.append(obj.getCircle());
					 buffer.append(",");
					 buffer.append(obj.getFileName());
					 buffer.append(",");
					 buffer.append(obj.getRejectionReason());
					 buffer.append("\n");
				 }
			 }
			 else
			 {
				 buffer.append("NO RECORDS AVAILABLE.");
				 buffer.append("\n"); 
			 }
		 }catch(Exception exe){
			 buffer.append("ERROR WHILE DOWNLOADING  USER BULK UPLOAD FILE CVS.");
			 exe.printStackTrace();
		 }
		 return buffer;
	 }
	 
	 
	 public StringBuffer constructCPStringBuffer(List<CPSPaymentVO>  ouputVo)throws Exception
		{
			StringBuffer buffer=new StringBuffer();
			try{
				buffer.append("PRODUCER_ID");
				buffer.append(", ");
				buffer.append("ENTITY_NAME");
				buffer.append(", ");
				buffer.append("AMOUNT");
				buffer.append(", ");
				buffer.append("REMARKS");
				buffer.append(", ");
				buffer.append("CONTACT_NUMBER");
				buffer.append(", ");
				buffer.append("REGION");
				buffer.append(", ");
				buffer.append("ZONE");
				buffer.append("\n");	
				
				  if(ouputVo!=null){
					 
					   for(CPSPaymentVO   object: ouputVo){
						buffer.append(object.getProducerId());
					    buffer.append(", ");   
					    buffer.append(object.getEntityName());
					    buffer.append(", ");   
						buffer.append(object.getAmount());
						buffer.append(", ");
						buffer.append(object.getRemarks());
						buffer.append(", ");
						buffer.append(object.getContactNumber());
						buffer.append(", ");
						buffer.append(object.getRegion());
						buffer.append(", ");
						buffer.append(object.getZone());
						buffer.append("\n");
					   }
					}else{
						   buffer.append("NO RECORDS AVAILABLE.");
							buffer.append("\n"); 
					   }
			}catch(Exception exe){
				buffer.append("ERROR WHILE DOWNLOADING  USER RETAILERS CVS.");
				exe.printStackTrace();
			}
			return buffer;
		}

	 
	 public StringBuilder constructCpStringBuffer(List<StmtCpBean>  ouputVo)throws Exception
		{
		 	StringBuilder buffer=new StringBuilder();
			try{
				buffer.append("CP_ID");
				buffer.append(",");
				buffer.append("SCM_MONTH");
				buffer.append(",");
				buffer.append("USAGE_TYPE");
				buffer.append(",");
				buffer.append("PARTNER_SUBSCRIBER_COUNT");
				buffer.append(",");
				buffer.append("TOTAL_SUBSCRIBER_CNT");
				buffer.append(",");
				buffer.append("TOTAL_REVENUE");
				buffer.append(",");
				buffer.append("NET_REVENUE");
				buffer.append(",");
				buffer.append("POOL_PER");
				buffer.append(",");
				buffer.append("Pool_Amount");
				buffer.append(",");
				buffer.append("Total_Streams");
				buffer.append(",");
				buffer.append("Partner_Streams");
				buffer.append(",");
				buffer.append("Mkt_Share_Per");
				buffer.append(",");
				buffer.append("Partner_Payout");
				buffer.append("\n");	
				  if(ouputVo!=null){
					   for(StmtCpBean   object: ouputVo){
						buffer.append(object.getCpId());
					    buffer.append(",");   
					    buffer.append(object.getScmMonth());
					    buffer.append(",");
					    buffer.append(object.getUsageType());
					    buffer.append(",");
					    buffer.append(object.getSubscriberCount());
					    buffer.append(",");
					    buffer.append(object.getTotalSubscriberCount());
						buffer.append(",");
						buffer.append(object.getTotalRevenue());
						buffer.append(",");
						buffer.append(object.getNetRevenue());
					    buffer.append(",");   
						buffer.append(object.getPoolPer());
						buffer.append(",");
						buffer.append(object.getPoolAmount());
						buffer.append(",");
						buffer.append(object.getTotalStreams());
						buffer.append(",");
						buffer.append(object.getPartnerStreams());
						buffer.append(",");
						buffer.append(object.getMktSharePer());
						buffer.append(",");
						buffer.append(object.getPartnerPayout());
						buffer.append("\n");
					   }
					}else{
						   buffer.append("NO RECORDS AVAILABLE.");
							buffer.append("\n"); 
					   }
			}catch(Exception exe){
				buffer.append("ERROR WHILE DOWNLOADING  USER PAYOUT CVS.");
				exe.printStackTrace();
			}
			return buffer;
		}
	 
	 
	 private String xssValidation(String value){
		 value = value.replace("@", " @ ").replace("+", " ").replace("-", " ").replace("=", " ").replace("*", " ").replace("/", " ").replace(";", " ").replace("\\"," ");
		 return value;
	 }
}

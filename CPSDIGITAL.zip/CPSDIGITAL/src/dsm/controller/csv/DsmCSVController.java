package dsm.controller.csv;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import dsm.dao.csv.CSVDAO;
import dsm.model.DB.BulkRejectionDataPojo;
import dsm.model.DB.CPSPaymentVO;
import dsm.model.DB.CSVModelInput;
import dsm.model.DB.CheckBaselineVO;
import dsm.model.DB.DistributorVO;
import dsm.model.DB.ExecPayoutStatusVO;
import dsm.model.DB.HierarchyMismatchCsvVO;
import dsm.model.DB.PayoutVO;
import dsm.model.DB.RetailerVO;
import dsm.model.DB.ScmPayoutVO;

import dsm.model.form.BulkLoadErrorFileStatus;
import dsm.model.form.HoldReleaseAmount;
import dsm.model.search.SearchScheme;
import dsm.model.user.User;
import dsm.service.admin.AdminService;
import dsm.service.csv.CSVService;
import dsm.service.search.SchemeSearch;
@Controller
@Scope("session")
@RequestMapping(value="/csv")
public class DsmCSVController {

	@Autowired
	private HttpSession httpSession;
	
	@Autowired
	private CSVService csvService;
	
	@Autowired
	CSVDAO csvDownload;
	
	@Autowired
	AdminService adminSrvc = null;

	@Autowired
	private SchemeSearch schemeSearchService;

	private static Logger logger = Logger.getLogger (DsmCSVController.class);
	
	/*@RequestMapping(value = "/downloadCSV.action", method = RequestMethod.GET)
	public void distributorDownloadCSV(@ModelAttribute CSVModelInput csvModel, HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/csv");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition","attachment;filename="+request.getParameter("csvType")+"Download.csv");
		GenerateCSV csvGenerator = new GenerateCSV();
		User user = (User)httpSession.getAttribute("appUser");
		
		String csvType = request.getParameter("csvType");
		String schemeId = request.getParameter("schemeId");
		String fromDate = request.getParameter("fromDate");
		String toDate = request.getParameter("toDate");
		String compId = request.getParameter("compId");
		
		if(csvType!=null){
			csvModel.setCsvType(csvType);
			csvModel.setCircleId(user.getCircleId());
			csvModel.setCircleCode(user.getUserCircleCode());
		}if(schemeId != null)
			csvModel.setSchemeId(schemeId);
		if(fromDate!=null)
			csvModel.setFromDate(fromDate);
		if(toDate!=null)
			csvModel.setToDate(toDate);
		if(toDate!=null)
			csvModel.setCompId(Integer.parseInt(compId));
		
		StringBuffer buffer = null;
		ByteArrayInputStream bis=null;

		try{
			if(schemeId != null){
				if(csvType.equalsIgnoreCase("Distributor")){
					List<DistributorVO> outputVo = csvService.distributorCsv(csvModel);
					buffer = csvGenerator.constructDistributorStringBuffer(outputVo);
				}else if(csvType.equalsIgnoreCase("Retailer")){
					List<RetailerVO> outputVo = csvService.retailerCsv(csvModel);
					buffer = csvGenerator.constructRetailerStringBuffer(outputVo);
				}else if(csvType.equalsIgnoreCase("Payout")){
					List<PayoutVO> outputVo = csvService.payoutCsv(csvModel);
					buffer = csvGenerator.constructPayoutStringBuffer(outputVo);
				}
			}
			if(buffer==null){
				buffer=new StringBuffer(); 
			}
			byte requestBytes[] =((buffer.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
		} catch (Exception exe) {
			exe.printStackTrace();
		} finally {
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
		}
	}
	*/
	
	
	@RequestMapping(value = "/downloadValidPayoutCSV.action", method = RequestMethod.GET)//downloadValidPayoutReportCSV
	public void testValidDownloadCSV(@ModelAttribute CSVModelInput csvModel, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User user = (User)httpSession.getAttribute("appUser");
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 4 || user.getRoleId() == 5 || user.getRoleId() == 7)){
			response.setContentType("text/csv");
			response.setHeader("Cache-Control", "max-age=30");
			response.setHeader("Content-Disposition","attachment;filename="+request.getParameter("csvType")+"Download.csv");
			GenerateCSV csvGenerator = new GenerateCSV();
			if(logger.isDebugEnabled()){
				logger.debug("Approvals --> Scheme Approval # DsmCSVController : testValidDownloadCSV() Start  :: UserId = "+user.getUserName());
			}

			String csvType = request.getParameter("csvType");
			String schemeId = request.getParameter("schemeId");
			String fromDate = request.getParameter("fromDate");
			String toDate = request.getParameter("toDate");
			String compId = request.getParameter("compId");
			String compStatus = request.getParameter("compStatus");

			if(compStatus!=null){
				if("Draft".equalsIgnoreCase(compStatus))
					csvModel.setCompStatus("D");
				if("Approve".equalsIgnoreCase(compStatus))
					csvModel.setCompStatus("A");
				if("Rejection".equalsIgnoreCase(compStatus))
					csvModel.setCompStatus("R");
			}

			if(csvType!=null){
				csvModel.setCsvType(csvType);
				csvModel.setCircleCode(user.getUserCircleCode());
			}if(schemeId != null)
				csvModel.setSchemeId(schemeId);
			if(fromDate!=null)
				csvModel.setFromDate(fromDate);
			if(toDate!=null)
				csvModel.setToDate(toDate);
			if(compId!=null)
				csvModel.setCompId(Integer.parseInt(compId));
			if(csvModel!=null && csvModel.getFromDate()!=null)
				csvModel.setCircleId(user.getCircleId());


			StringBuffer buffer = null;
			ByteArrayInputStream bis=null;

			try{
				if(schemeId != null){
					List<PayoutVO> outputVo = csvService.testValidPayoutCsv(csvModel);
					buffer = csvGenerator.constructPayoutStringBuffer(outputVo);
				}
				if(buffer==null){
					buffer=new StringBuffer(); 
				}
				byte requestBytes[] =((buffer.toString())).getBytes();
				bis = new ByteArrayInputStream(requestBytes);
				byte[] buf = new byte[4000];
				int len;
				while ((len = bis.read(buf)) > 0){
					response.getOutputStream().write(buf, 0, len);
				}
				bis.close();
				response.getOutputStream().flush(); 
			} catch (Exception exe) {
				logger.error("DsmCSVController : testValidDownloadCSV() Exception :: ",exe);
				exe.printStackTrace();
			} finally {
				if(bis!=null) {
					bis.close();
					response.getOutputStream().flush(); 
				}
			}
			if(logger.isDebugEnabled()){
				logger.debug("Approvals --> Scheme Approval # DsmCSVController : testValidDownloadCSV() End  :: UserId = "+user.getUserName());
			}
		}
	}
	
	@RequestMapping(value = "/downloadValidPayoutReportCSV.action", method = RequestMethod.GET)//
	public void downloadValidPayoutReportCSV(@ModelAttribute CSVModelInput csvModel, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User user = (User)httpSession.getAttribute("appUser");
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 || user.getRoleId() == 3 || user.getRoleId() == 6)){
			response.setContentType("text/csv");
			response.setHeader("Cache-Control", "max-age=30");
			response.setHeader("Content-Disposition","attachment;filename="+request.getParameter("csvType")+"Download.csv");
			GenerateCSV csvGenerator = new GenerateCSV();

			if(logger.isDebugEnabled()){
				logger.debug("Approvals --> Scheme Approval # DsmCSVController : downloadValidPayoutReportCSV() Start  :: UserId = "+user.getUserName());
			}
			String csvType = request.getParameter("csvType");
			String schemeId = request.getParameter("schemeId");
			String fromDate = request.getParameter("fromDate");
			String toDate = request.getParameter("toDate");
			String compId = request.getParameter("compId");
			String compStatus = request.getParameter("compStatus");

			if(compStatus!=null){
				if("Draft".equalsIgnoreCase(compStatus))
					csvModel.setCompStatus("D");
				if("Approve".equalsIgnoreCase(compStatus))
					csvModel.setCompStatus("A");
				if("Rejection".equalsIgnoreCase(compStatus))
					csvModel.setCompStatus("R");
			}

			if(csvType!=null){
				csvModel.setCsvType(csvType);
				csvModel.setCircleCode(user.getUserCircleCode());
			}if(schemeId != null)
				csvModel.setSchemeId(schemeId);
			if(fromDate!=null)
				csvModel.setFromDate(fromDate);
			if(toDate!=null)
				csvModel.setToDate(toDate);
			if(compId!=null)
				csvModel.setCompId(Integer.parseInt(compId));
			if(csvModel!=null && csvModel.getFromDate()!=null)
				csvModel.setCircleId(user.getCircleId());


			StringBuffer buffer = null;
			ByteArrayInputStream bis=null;

			try{
				if(schemeId != null){
					List<PayoutVO> outputVo = csvService.testValidPayoutCsv(csvModel);
					buffer = csvGenerator.constructPayoutStringBuffer(outputVo);
				}
				if(buffer==null){
					buffer=new StringBuffer(); 
				}
				byte requestBytes[] =((buffer.toString())).getBytes();
				bis = new ByteArrayInputStream(requestBytes);
				byte[] buf = new byte[4000];
				int len;
				while ((len = bis.read(buf)) > 0){
					response.getOutputStream().write(buf, 0, len);
				}
				bis.close();
				response.getOutputStream().flush(); 
			} catch (Exception exe) {
				exe.printStackTrace();
			} finally {
				if(bis!=null) {
					bis.close();
					response.getOutputStream().flush(); 
				}
			}
			if(logger.isDebugEnabled()){
				logger.debug("Approvals --> Scheme Approval # DsmCSVController : downloadValidPayoutReportCSV() End  :: UserId = "+user.getUserName());
			}
		}

	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	@RequestMapping(value = "/retailerCSV.action", method = RequestMethod.GET)
	public void retailerDownloadCSV(@ModelAttribute CSVModelInput csvModel,HttpServletResponse response) throws IOException {

		response.setContentType("text/csv");
		response.setContentType("application/text");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition","attachment;filename=Retailer.csv");
		GenerateCSV csvGenerator = new GenerateCSV();
		StringBuffer buffer = null;
		ByteArrayInputStream bis=null;
		try{
			List<RetailerVO> outputVo = csvService.retailerCsv(csvModel);
			buffer = csvGenerator.constructRetailerStringBuffer(outputVo);
			if(buffer==null){
				buffer=new StringBuffer(); 
			}
			byte requestBytes[] =((buffer.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
		} catch (Exception exe) {
			exe.printStackTrace();
		} finally {
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
		}
	}
	*/
	
	@RequestMapping(value = "/payoutStatusCSV.action", method = RequestMethod.GET)
	public void payoutStatusDownloadCSV(@RequestParam Map<String,String> requestParams,HttpServletResponse response) throws IOException {

		response.setContentType("text/csv");
		response.setContentType("application/text");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition","attachment;filename=PayoutStatus.csv");
		GenerateCSV csvGenerator = new GenerateCSV();
		User user = (User)httpSession.getAttribute("appUser");
		
		StringBuffer buffer = null;
		ByteArrayInputStream bis=null;
		try{
			System.out.println("payoutStatusDownloadCSV ::: circle: "+requestParams.get("circleId")+"\t fromdate:"+requestParams.get("fromDate")+"\t Todate:"+requestParams.get("toDate"));
			CSVModelInput csvModel = new CSVModelInput();
			csvModel.setCircleId(Integer.parseInt(requestParams.get("circleId")));
			csvModel.setFromDate(requestParams.get("fromDate"));
			csvModel.setToDate(requestParams.get("toDate"));
			csvModel.setCircleCode(user.getUserCircleCode());
			
			List<ExecPayoutStatusVO> outputVo = csvService.execPayoutStatusCsv(csvModel);
			buffer = csvGenerator.constructPayoutStatusStringBuffer(outputVo);
			if(buffer==null){
				buffer=new StringBuffer(); 
			}
			byte requestBytes[] =((buffer.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
		} catch (Exception exe) {
			exe.printStackTrace();
		} finally {
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
		}
	}

	
	
	
	@RequestMapping(value = "/downloadPaymentCSV.action", method = RequestMethod.GET)
	public void downloadPaymentCSV(@ModelAttribute CSVModelInput csvModel, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User user = (User)httpSession.getAttribute("appUser");
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() != 5)){
			response.setContentType("text/csv");
			response.setHeader("Cache-Control", "max-age=30");
			response.setHeader("Content-Disposition","attachment;filename="+request.getParameter("csvType")+"Download.csv");
			GenerateCSV csvGenerator = new GenerateCSV();
			String csvType = request.getParameter("csvType");
			String schemeId = request.getParameter("schemeId");
			String fromDate = request.getParameter("fromDate");
			String toDate = request.getParameter("toDate");
			//String schemecomp = request.getParameter("schemecomp");

			if(csvType!=null){
				csvModel.setCsvType(csvType);
				csvModel.setCircleCode(user.getUserCircleCode());
			}if(schemeId != null)
				csvModel.setSchemeId(schemeId);
			if(fromDate!=null)
				csvModel.setFromDate(fromDate);
			if(toDate!=null)
				csvModel.setToDate(toDate);

			StringBuffer buffer = null;
			ByteArrayInputStream bis=null;

			try{
				if(schemeId != null){
					if(csvType.equalsIgnoreCase("Distributor")){
						List<DistributorVO> outputVo = csvService.distributorCsv(csvModel);
						buffer = csvGenerator.constructDistributorStringBuffer(outputVo);
					}else if(csvType.equalsIgnoreCase("Retailer")){
						List<RetailerVO> outputVo = csvService.retailerCsv(csvModel);
						buffer = csvGenerator.constructRetailerStringBuffer(outputVo);
					}else if(csvType.equalsIgnoreCase("Payout")){
						List<PayoutVO> outputVo = csvService.payoutCsv(csvModel);
						buffer = csvGenerator.constructPayoutStringBuffer(outputVo);
					}
				}
				if(buffer==null){
					buffer=new StringBuffer(); 
				}
				byte requestBytes[] =((buffer.toString())).getBytes();
				bis = new ByteArrayInputStream(requestBytes);
				byte[] buf = new byte[4000];
				int len;
				while ((len = bis.read(buf)) > 0){
					response.getOutputStream().write(buf, 0, len);
				}
				bis.close();
				response.getOutputStream().flush(); 
			} catch (Exception exe) {
				exe.printStackTrace();
			} finally {
				if(bis!=null) {
					bis.close();
					response.getOutputStream().flush(); 
				}
			}
		}
	}
		
	
	@RequestMapping(value = "/payoutDownloadCSV.action", method = RequestMethod.GET)
	public void payoutDownloadCSV(@ModelAttribute CSVModelInput csvModel, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User user = (User)httpSession.getAttribute("appUser");
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 4 || user.getRoleId() == 5 || user.getRoleId() == 7)){
	
			response.setContentType("text/csv");
			response.setHeader("Cache-Control", "max-age=30");
			response.setHeader("Content-Disposition","attachment;filename="+request.getParameter("csvType")+"Download.csv");
			GenerateCSV csvGenerator = new GenerateCSV();

			String csvType = request.getParameter("csvType");
			String schemeId = request.getParameter("schemeId");
			String compId = request.getParameter("compId");

			StringBuffer buffer = null;
			ByteArrayInputStream bis=null;

			try{

				if(csvType!=null){
					csvModel.setCsvType(csvType);
					csvModel.setCircleId(user.getCircleId());
					csvModel.setCircleCode(user.getUserCircleCode());
				}if(schemeId != null)
					csvModel.setSchemeId(schemeId);
				if(compId != null)
					csvModel.setCompId(Integer.parseInt(compId));
				csvModel.setCircleCode(user.getUserCircleCode());
				csvModel.setCircleId(user.getCircleId());

				if(schemeId != null){
					if(csvType.equalsIgnoreCase("Distributor")){
						List<DistributorVO> outputVo = csvService.payoutDistributorCsv(csvModel);
						buffer = csvGenerator.constructDistributorStringBuffer(outputVo);
					}else if(csvType.equalsIgnoreCase("Retailer")){
						List<RetailerVO> outputVo = csvService.payoutRetailerCsv(csvModel);
						buffer = csvGenerator.constructRetailerStringBuffer(outputVo);
					}else if(csvType.equalsIgnoreCase("CP") || csvType.equalsIgnoreCase("Platform")){
						List<CPSPaymentVO> outputVo = csvService.payoutCPSCsv(csvModel);
						buffer = csvGenerator.constructCPStringBuffer(outputVo);
					}
				}
				if(buffer==null){
					buffer=new StringBuffer(); 
				}
				byte requestBytes[] =((buffer.toString())).getBytes();
				bis = new ByteArrayInputStream(requestBytes);
				byte[] buf = new byte[4000];
				int len;
				while ((len = bis.read(buf)) > 0){
					response.getOutputStream().write(buf, 0, len);
				}
				bis.close();
				response.getOutputStream().flush(); 
			} catch (Exception exe) {
				exe.printStackTrace();
			} finally {
				if(bis!=null) {
					bis.close();
					response.getOutputStream().flush(); 
				}
			}

		}

	}
	
	@RequestMapping(value = "/downloadSchemeTemplates.action", method = RequestMethod.GET)
	public void downloadSchemeTemplates(HttpServletRequest request, HttpServletResponse response) throws IOException {

		User user = (User)httpSession.getAttribute("appUser");
		if(user!=null && (user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 || user.getRoleId() == 3 || user.getRoleId() == 4 || user.getRoleId() == 7))){
			try{
				String path	= new File(System.getProperty("SCHEME_STUDIO_CONFIG_PATH")).getPath();
				String fileName = fileNameConvention(request.getParameter("sno")!=null ?Integer.parseInt(request.getParameter("sno")) : 0 );
				if(path != null){
					//File Path
					StringBuffer csvFilePath = new StringBuffer();
					csvFilePath.append(path).append("/").append("Templates").append("/").append(fileName);//.append(transData.getCircleId()).append("_");

					File downloadFile = new File(csvFilePath.toString());
					System.out.println(downloadFile.exists());
					//If file found
					if(downloadFile.exists()){
						FileInputStream inStream = new FileInputStream(downloadFile);
						System.out.println("inStream available :: "+inStream.available());
						System.out.println("file length :: "+downloadFile.length());
						if(downloadFile.length() != -1 ){
							response.setContentType("text/csv");
							response.setContentLength((int) downloadFile.length());
							//transData.setErrorDesc("File Downloaded Successfully.");
							String headerKey = "Content-Disposition";
							String headerValue = String.format("attachment; filename=\"%s\"", downloadFile.getName());
							response.setHeader(headerKey, headerValue);

							OutputStream outStream = response.getOutputStream();
							byte[] buffer = new byte[4096];
							int bytesRead = -1;
							while ((bytesRead = inStream.read(buffer)) != -1) {
								outStream.write(buffer, 0, bytesRead);
							}
							inStream.close();
							outStream.close();
						}
					}
				}
			} catch (Exception exe) {
				exe.printStackTrace();
			} 

		}
	}
	
	
	private String fileNameConvention(int fileTypeId){
		String fileName=null;
		switch (fileTypeId) {
		case 1:{
			fileName="Template_SCM_CONFIG.xls";
		}break;
		case 2:{
			fileName="Template_ADD_ATTR.csv";
		}
		break;
		case 3:{
			fileName="Template_ADD_ACT_UNI.csv";
		}
		break;
		case 4:{
			fileName="Template_ADD_DIST_UNI.csv";
		}
		break;
		case 5:{
			fileName="Template_ADD_RET_UNI.csv";
		}
		break;
		case 6:{
			fileName="Template_ADD_DSE_UNI.csv";
		}
		break;
		case 7:{
			fileName="Template_ENTITY-LIST.csv";
		}
		break;
		case 8:{
			fileName="Template_MANUAL-PAYOUT.csv";
		}
		break;
		case 9:{
			fileName="Template_SchemeNFA.pdf";
		}
		break;
		case 10:{
			fileName="Template_EMAIL_LIST.csv";
		}
		break;
		}
		return fileName;
	}
	
	
	@RequestMapping(value = "/hierarchyMismatchDownloadCSV.action", method = RequestMethod.GET)
	public void hierarchyMisDownloadCSV(@ModelAttribute CSVModelInput csvModel, HttpServletRequest request, HttpServletResponse response) throws IOException {

		response.setContentType("text/csv");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition","attachment;filename="+request.getParameter("csvType")+"Download.csv");
		GenerateCSV csvGenerator = new GenerateCSV();
		//User user = (User)httpSession.getAttribute("appUser");
		
		String csvType = request.getParameter("csvType");
		String circleCode = request.getParameter("circleCode");
		String toDate = request.getParameter("toDate");
		
		StringBuffer buffer = null;
		ByteArrayInputStream bis=null;

		try{

			if(csvType!=null)
				csvModel.setCsvType(csvType);
			if(circleCode != null)
				csvModel.setCircleCode(circleCode);
			if(toDate != null)
				csvModel.setToDate(toDate);
			
			if(csvModel != null){
					List<HierarchyMismatchCsvVO> outputVo = csvService.hierarchyMismatchCsv(csvModel);
					buffer = csvGenerator.constructHierarchyMisStringBuffer(outputVo);
			}
			if(buffer==null){
				buffer=new StringBuffer(); 
			}
			byte requestBytes[] =((buffer.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
		} catch (Exception exe) {
			exe.printStackTrace();
		} finally {
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
		}
	}

	
	
	@RequestMapping(value = "/scmDataAnalysisDownloadCSV.action", method = RequestMethod.GET)
	public void scmDataAnalysisDownloadCSV(@RequestParam Map<String,String> requestParams, HttpServletResponse response) throws IOException {

		response.setContentType("text/csv");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition","attachment;filename=ScmDataAnalysisDownload.csv");
		GenerateCSV csvGenerator = new GenerateCSV();
		
		StringBuffer buffer = null;
		ByteArrayInputStream bis=null;
		try{
			String act = requestParams.get("typeParam");
			if(act.contains("Act")){
				act="Act + Recharge";
			}
			if(requestParams.get("startDate")!=null && requestParams.get("circleId")!=null && requestParams.get("typeParam")!=null  && 
					requestParams.get("schemeId")!=null  && requestParams.get("compId")!=null && requestParams.get("endDate")!=null){
				List<CheckBaselineVO> hierMap = adminSrvc.getScmDataAnalysis(Integer.parseInt(requestParams.get("circleId")),requestParams.get("startDate"), requestParams.get("endDate"),Integer.parseInt(requestParams.get("schemeId")),Integer.parseInt(requestParams.get("compId")),act);
				System.out.println("csv Map :::: "+hierMap);
				buffer = csvGenerator.constructScmDataAnalysisStringBuffer(hierMap);
			}
			if(buffer==null){
				buffer=new StringBuffer(); 
			}
			byte requestBytes[] =((buffer.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
		} catch (Exception exe) {
			exe.printStackTrace();
		} finally {
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
		}
	}

	
	
	@RequestMapping(value = "/holdDataDownloadCSV.action", method = RequestMethod.GET)
	public void holdDataDownloadCSV(@RequestParam Map<String,String> requestParams, HttpServletResponse response) throws IOException {

		response.setContentType("text/csv");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition","attachment;filename=HoldDataDownload.csv");
		GenerateCSV csvGenerator = new GenerateCSV();
		User user = (User)httpSession.getAttribute("appUser");
		StringBuffer buffer = null;
		ByteArrayInputStream bis=null;
		try{
			if(requestParams.get("startDate")!=null && requestParams.get("payTo")!=null  && 
					requestParams.get("paymentType")!=null  && requestParams.get("condParam")!=null && requestParams.get("endDate")!=null){
				SearchScheme holdData = new SearchScheme();
				holdData.setStartDate(requestParams.get("startDate"));
				holdData.setEndDate(requestParams.get("endDate"));
				holdData.setPayTo(Integer.parseInt(requestParams.get("payTo")));
				holdData.setPaymentType(requestParams.get("paymentType"));
				holdData.setCondParam(requestParams.get("condParam"));
				
				List<ScmPayoutVO> hierMap = schemeSearchService.loadHoldDataSearch(holdData, user.getCircleId(), user.getUserCircleCode());
				System.out.println("csv Map :::: "+hierMap);
				buffer = csvGenerator.constructHoldDataStringBuffer(hierMap);
			}
			if(buffer==null){
				buffer=new StringBuffer(); 
			}
			byte requestBytes[] =((buffer.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
		} catch (Exception exe) {
			exe.printStackTrace();
		} finally {
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
		}
	}

	
	@RequestMapping(value = "/relDataDownloadCSV.action", method = RequestMethod.GET)
	public void relDataDownloadCSV(@RequestParam Map<String,String> requestParams, HttpServletResponse response) throws IOException {
		response.setContentType("text/csv");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition","attachment;filename=ReleaseDataDownload.csv");
		GenerateCSV csvGenerator = new GenerateCSV();
		User user = (User)httpSession.getAttribute("appUser");
		StringBuffer buffer = null;
		ByteArrayInputStream bis=null;
		try{
			if(requestParams.get("startDate")!=null && requestParams.get("radioType")!=null  && 
					requestParams.get("payType")!=null  && requestParams.get("endDate")!=null){
				SearchScheme holdData = new SearchScheme();
				holdData.setStartDate(requestParams.get("startDate"));
				holdData.setEndDate(requestParams.get("endDate"));
				holdData.setPayTo(Integer.parseInt(requestParams.get("radioType")));
				holdData.setCompId(Integer.parseInt(requestParams.get("payType")));
				holdData.setCondParam(requestParams.get("searchVal"));
				
				List<HoldReleaseAmount> hierMap = schemeSearchService.getReleaseDataCSV(holdData, user.getCircleId(), user.getUserCircleCode());
				System.out.println("csv Map :::: "+hierMap);
				buffer = csvGenerator.constructReleaseDataStringBuffer(hierMap);
			}
			if(buffer==null){
				buffer=new StringBuffer(); 
			}
			byte requestBytes[] =((buffer.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
		} catch (Exception exe) {
			exe.printStackTrace();
		} finally {
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
		}
	}


	
	
	/*public void bulkUploadErrorFileDataDownloadCSV(@RequestParam Map<String,String> requestParams, HttpServletResponse response) throws IOException {
		response.setContentType("text/csv");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition","attachment;filename=BulkUploadErrorFileDownload.csv");
		GenerateCSV csvGenerator = new GenerateCSV();
		User user = (User)httpSession.getAttribute("appUser");
		StringBuffer buffer = null;
		ByteArrayInputStream bis=null;
		try{
			if(requestParams.get("fileName")!=null && requestParams.get("uniqueFileName")!=null  && 
					requestParams.get("payType")!=null  && requestParams.get("circleCode")!=null){
				SearchScheme holdData = new SearchScheme();
				holdData.setStartDate(requestParams.get("startDate"));
				holdData.setEndDate(requestParams.get("endDate"));
				holdData.setPayTo(Integer.parseInt(requestParams.get("radioType")));
				holdData.setCompId(Integer.parseInt(requestParams.get("payType")));
				holdData.setCondParam(requestParams.get("searchVal"));
				
				List<BulkLoadErrorFileStatus> hierMap = schemeSearchService.getReleaseDataCSV(holdData, user.getCircleId(), user.getUserCircleCode());
				System.out.println("csv Map :::: "+hierMap);
				buffer = csvGenerator.constructReleaseDataStringBuffer(hierMap);
			}
			if(buffer==null){
				buffer=new StringBuffer(); 
			}
			byte requestBytes[] =((buffer.toString())).getBytes();
			bis = new ByteArrayInputStream(requestBytes);
			byte[] buf = new byte[4000];
			int len;
			while ((len = bis.read(buf)) > 0){
				response.getOutputStream().write(buf, 0, len);
			}
			bis.close();
			response.getOutputStream().flush(); 
		} catch (Exception exe) {
			exe.printStackTrace();
		} finally {
			if(bis!=null) {
				bis.close();
				response.getOutputStream().flush(); 
			}
		}
	}
*/

	@RequestMapping(value = "/downloadRejRecords.action", method = RequestMethod.GET)
	public void downloadRejRecords(@RequestParam Map<String,String> requestParams,HttpServletRequest request, HttpServletResponse response) throws Exception{
			response.setContentType("text/csv");
			response.setHeader("Cache-Control", "max-age=30");
			response.setHeader("Content-Disposition","attachment;filename=BulkRejectionFileList.csv");
			GenerateCSV csvGenerator = new GenerateCSV();
		    String fileName = request.getParameter("fileName");
		    String uniqueFileName = request.getParameter("uniqueFileName");
			User user = (User)httpSession.getAttribute("appUser");
			StringBuffer buffer = null;
			ByteArrayInputStream bis = null;
			
			System.out.println("DSMCSVController || downloadRejRecords || BEG || fileName:"+fileName+" circle:"+user.getUserCircleCode());
			
			List<BulkRejectionDataPojo> bulkRejMap = schemeSearchService.loadBulkRejFileList(fileName, uniqueFileName, user.getUserCircleCode());
				buffer = csvGenerator.constructRejectionListStringBuffer(bulkRejMap,fileNameParam(fileName));
				
				try
				{
				if(buffer==null){
					buffer=new StringBuffer(); 
				}
				byte requestBytes[] =((buffer.toString())).getBytes();
				bis = new ByteArrayInputStream(requestBytes);
				byte[] buf = new byte[4000];
				int len;
				while ((len = bis.read(buf)) > 0){
					response.getOutputStream().write(buf, 0, len);
				}
				bis.close();
				response.getOutputStream().flush(); 
			} catch (Exception exe) {
				exe.printStackTrace();
			} finally {
				if(bis!=null) {
					bis.close();
					response.getOutputStream().flush(); 
				}
				
			}
	}

	private String fileNameParam(String fileName){
		String paramType = null;
		
		if(fileName != null && fileName.contains("ADD_ATTR")){
			paramType = "ADD_ATTR";
		}
		else if(fileName != null && fileName.contains("ADD_ACT_UNI")){
			paramType = "ADD_ACT_UNI";
		}
		else if(fileName != null && fileName.contains("ENTITY-LIST")){
			paramType = "ENTITY-LIST";
		}
		else if(fileName != null && fileName.contains("MANUAL-PAYOUT")){
			paramType = "MANUAL-PAYOUT";
		}
		else if(fileName != null && fileName.contains("ADD_DIST_UNI")){
			paramType = "ADD_DIST_UNI";
		}
		else if(fileName != null && fileName.contains("ADD_RET_UNI")){
			paramType = "ADD_RET_UNI";
		}
		else if(fileName != null && fileName.contains("ADD_DSE_UNI")){
			paramType = "ADD_DSE_UNI";
		}
		else if(fileName != null && fileName.contains("EMAIL_LIST")){
			paramType = "EMAIL_LIST";
		}
		return paramType;
	}
	
}

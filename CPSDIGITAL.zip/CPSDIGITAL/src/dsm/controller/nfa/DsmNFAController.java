package dsm.controller.nfa;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
//import org.springframework.validation.BindingResult;
//import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.dao.approveNFA.ApproveNFADAO;
//import dsm.model.DB.ApproveNFA;
import dsm.model.DB.RejectSchemeVO;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.ShellScriptPojo;
import dsm.model.user.User;
import dsm.service.approveNFA.ApproveNFAService;
import dsm.service.transData.TransDataSrvc;

@Controller
@Scope("session")
@RequestMapping(value="/nfa")
public class DsmNFAController {
	
	@Autowired
	private HttpSession httpSession;
	
	@Autowired
	private ApproveNFAService approveNFAService;
	
	@Autowired
	ApproveNFADAO nfaDao;

	@Autowired
	TransDataSrvc transDataSrvc = null;

	private static Logger logger = Logger.getLogger (DsmNFAController.class);
	
	@RequestMapping(value="rejectScheme.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 	rejectScheme(RejectSchemeVO reject,HttpServletRequest request) throws Exception  {
		
		Map<String, Object> data = new HashMap<String, Object>();
		User appUser = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Scheme Approval :: DsmNFAController : rejectScheme : Start ::  User Name = "+appUser.getUserName() +" ");

		if(appUser != null && (appUser.getRoleId() == 1 || appUser.getRoleId() != 4 || appUser.getRoleId() != 5)){
			reject.setCircleId(appUser.getCircleId());
			reject.setUserId(appUser.getUserName());

			if(request.getParameter("compId")!=null)
				reject.setCompId(Integer.parseInt(request.getParameter("compId")));
			try
			{
				String value = approveNFAService.rejectScheme(reject);
				data.put("success",Boolean.TRUE);
				data.put("errorMessage", value);
			}catch(Exception e)
			{
				logger.error("Approvals --> Scheme Approval :: DsmNFAController : rejectScheme ::  User Name = "+appUser.getUserName() +" Exception ::",e);
				data.put("success",Boolean.FALSE);
				data.put("errorMessage", e.getMessage().toString());
			}
	
		}else{
			data.put("success",Boolean.FALSE);
			data.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Scheme Approval :: DsmNFAController : rejectScheme() : End :  User Name = "+appUser.getUserName() +" ");

		return data;
	}

	
	
	
	@RequestMapping(value="approveScheme.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 	approveScheme(SchemeMaster schemeMaster,HttpServletRequest request) throws Exception  {
		User appUser = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Scheme Approval :: DsmNFAController : approveScheme() : Start :  User Name = "+appUser.getUserName() );

		Map<String, Object> data = new HashMap<String, Object>();
		if(appUser != null && (appUser.getRoleId() == 1 || appUser.getRoleId() != 5)){
			schemeMaster.setCircleId(appUser.getCircleId());
			schemeMaster.setUserName(appUser.getUserName());
			if(request.getParameter("compId")!=null)
			schemeMaster.setCompId(Integer.parseInt(request.getParameter("compId")));
			try
			{
				String value = approveNFAService.approveScheme(schemeMaster);
				data.put("success",Boolean.TRUE);
				data.put("errorMessage", value);
				/*if(flag)
				{
					data.put("success",Boolean.TRUE);
					data.put("errorMessage", value);
				}
				else
				{
					data.put("success",Boolean.FALSE);
					data.put("errorMessage", value);
				}*/
				
			}catch(Exception e)
			{
				logger.error("Approvals --> Scheme Approval :: DsmNFAController : approveScheme() ::  User Name = "+appUser.getUserName()+" Exception ::",e );

				//logger.debug(e);
				data.put("success",Boolean.FALSE);
				data.put("errorMessage", e.getMessage().toString());
			}
		}else{
			data.put("success",Boolean.FALSE);
			data.put("errorMessage", "You are not having this privilege access...");			
		}
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Scheme Approval :: DsmNFAController : approveScheme() : End :  User Name = "+appUser.getUserName() );
			return data;
	}

	
	@RequestMapping(value="testValidateScheme.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 	testValidateScheme(SchemeMaster schemeMaster,HttpServletRequest request) throws Exception  {
		User appUser = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Scheme Approval :: DsmNFAController : testValidateScheme() : Start :  User Name = "+appUser.getUserName() );
			logger.debug(" DSM NFA COntroller scid N compId :::::"+schemeMaster.getSchemeINputId()+request.getParameter("output")+request.getParameter("compId"));
		String schemeId =  request.getParameter("output");
		String compId = request.getParameter("compId");
		if(schemeMaster!= null){
			schemeMaster=new SchemeMaster();
		}
		schemeMaster.setCircleId(appUser.getCircleId());
		schemeMaster.setUserName(appUser.getUserName());
		schemeMaster.setCompID(Integer.parseInt(compId));
		schemeMaster.setSchemeINputId(Integer.parseInt(schemeId));
		schemeMaster.setStatus("D");
		Map<String, Object> data = new HashMap<String, Object>();
		try
		{
			
			ShellScriptPojo shellScript = new ShellScriptPojo();
			
			shellScript.setSchemeId(schemeId);
			shellScript.setCompId(compId);
			shellScript.setConditionId("0");
			shellScript.setType(schemeMaster.getStatus());
			shellScript.setCircleId(String.valueOf(appUser.getCircleId()));
			shellScript.setQualityType("0");
			shellScript.setPaymentId("0");
			shellScript.setUniverseId("0");
			
			if(appUser != null )
			{
				shellScript.setUserId(appUser.getUserName());
				String value = transDataSrvc.getExtractDataTime(shellScript);
				data.put("success", false);
				data.put("errorMessage", value);
				if(value != null)
					return data;
			}
			
			String value = nfaDao.testValidScheme(schemeMaster);
			data.put("success",Boolean.TRUE);
			data.put("errorMessage", value);
			/*if(flag)
			{
				data.put("success",Boolean.TRUE);
				data.put("errorMessage", value);
			}
			else
			{
				data.put("success",Boolean.FALSE);
				data.put("errorMessage", value);
			}*/
			
		}catch(Exception e)
		{
			logger.error("Approvals --> Scheme Approval :: DsmNFAController : testValidateScheme() ::  User Name = "+appUser.getUserName()+" Exception ::",e );
			
			data.put("success",Boolean.FALSE);
			data.put("errorMessage", e.getMessage().toString());
		}
		if(logger.isDebugEnabled())
			logger.debug("Approvals --> Scheme Approval :: DsmNFAController : testValidateScheme() : End :  User Name = "+appUser.getUserName() );
		
		return data;
	}
	
	

}

package dsm.controller.master;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

//import dsm.model.DB.CSVModelInput;
import dsm.model.form.CircleMaster;
import dsm.model.form.ComponentMasterCombo;
import dsm.model.form.ParamCategory;
import dsm.model.form.SchemaMaster;
//import dsm.model.user.User;
import dsm.service.master.MasterService;


@Controller
@Scope("session")
@RequestMapping(value="/master")
public class MasterDataController {

	@Autowired
	private HttpSession httpSession;

	@Autowired
	private MasterService masterSrvc = null;

	private static Logger logger = Logger.getLogger (MasterDataController.class);

	@RequestMapping(value="getCircleMaster.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getCircleMaster() throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			List<CircleMaster> circleList = masterSrvc.getCircleMasterList();
			modelMap.put("data",circleList);
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	@RequestMapping(value="getSchemeMasterList.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getSchemeMasterList(@ModelAttribute CircleMaster circleId) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			logger.debug("circleId.getEndDate ::::  "+circleId.getEndDate());
			List<SchemaMaster> schemaList = masterSrvc.getSchemeMasterList(circleId.getCircleId()==0?1:circleId.getCircleId(),circleId.getStartDate()==null ? "" :circleId.getStartDate(), circleId.getEndDate()==null ? "": circleId.getEndDate());
			modelMap.put("data",schemaList);
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	@RequestMapping(value="getComponentMasterList.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getComponentMasterList(@ModelAttribute SchemaMaster schemeId) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			List<ComponentMasterCombo> compList = masterSrvc.getComponentMasterList(schemeId.getSchemaId());
			modelMap.put("data",compList);
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}

	@RequestMapping(value="getParamCatMasterList.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getParamCatMasterList(@ModelAttribute CircleMaster circleId) throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			List<ParamCategory> paramList = masterSrvc.getParamCatMasterList(circleId.getCircleId()==0?1:circleId.getCircleId());
			modelMap.put("data",paramList);
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
		}
		return modelMap;
	}
	
	@RequestMapping(value="/getPayToCreate.action")
	public @ResponseBody Map<String,? extends Object> getPayToCreate() throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			modelMap.put("data",masterSrvc.getPayToDetails());
			return modelMap;
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
			return modelMap;
		}
	}
	
	
}

package dsm.controller.save;

//import java.io.File;
//import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
//import org.springframework.ldap.core.AttributesMapper;
//import org.springframework.ldap.core.LdapTemplate;
//import org.springframework.ldap.core.support.LdapContextSource;
//import org.springframework.ldap.filter.AndFilter;
//import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.multipart.commons.CommonsMultipartFile;
//import org.springframework.web.servlet.ModelAndView;

import dsm.dao.form.ConverageInputDAO;
import dsm.dao.form.ConverageInputService;
import dsm.dao.form.CoverageOutput;
import dsm.dao.save.SchemeInputAllDAO;
import dsm.model.DB.CompMaster;
import dsm.model.DB.RegZoneMaster;
import dsm.model.DB.SchemeAcMaster;
import dsm.model.DB.SchemeEaFilterCondMaster;
import dsm.model.DB.SchemeEaMaster;
import dsm.model.DB.SchemeInputAll;
import dsm.model.DB.SchemeMaster;
import dsm.model.DB.SchemePoAmtMaster;
import dsm.model.DB.SchemeTqMaster;
//import dsm.model.ea.DataSourceEQModel;
import dsm.model.form.EntityAttributeMaster;
import dsm.model.form.RegionMaster;
import dsm.model.form.ZoneMaster;
import dsm.model.po.SchemePoMaster;
//import dsm.model.search.SearchScheme;
import dsm.model.user.User;
import dsm.service.bulk.BulkUploadService;
import dsm.service.save.SaveDataService;
import dsm.service.search.SchemeSearch;

@Controller
@Scope("session")
@RequestMapping(value="/payoutcondition")
//@SessionAttributes("schemeName")


public class DsmController {
	
	
	@Autowired
	private HttpSession httpSession;

	@Autowired
	private ConverageInputService converageService;

	@Autowired
	private SaveDataService saveDataService;

	@Autowired
	private SchemeSearch schemeSearchService;

	@Autowired
	private SchemeInputAllDAO schemeInputDao;
	
	@Autowired
	private ConverageInputDAO covDao;
	
	@Autowired
	private BulkUploadService bulkUploadService;
	
	private static Logger logger = Logger.getLogger (DsmController.class);
	
	
	
	@RequestMapping(value="getCompForCov.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getCompForCov() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			modelMap.put("data", covDao.getCompListForCoverage());
			
			
			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);
			modelMap.put("errorMessage",e.getMessage());

			return modelMap;
		}
	}

	
	
	
	
	@RequestMapping(value="isFileUpload.action",method=RequestMethod.POST)
	public @ResponseBody String isFileUpload(CompMaster comp) throws Exception {
	boolean value = false;
			//Map<String,Object> modelMap = new HashMap<String,Object>(3);
			//httpSession.setAttribute("updateVersion",Boolean.FALSE);
			try{
				value = saveDataService.isFileUpload(httpSession.getAttribute("schemeName").toString(), comp.getCompId());
				if(value)
					return "Yes";
				else
					return "No";
			} catch (Exception e) {

				e.printStackTrace();

			return "No";	
				
			}
			
		}

	
	
/*@RequestMapping(value="getCircle.action",method=RequestMethod.POST)
public @ResponseBody String getCircle(String schemeName) throws Exception {
String circle = null;
		//Map<String,Object> modelMap = new HashMap<String,Object>(3);
		//httpSession.setAttribute("updateVersion",Boolean.FALSE);
		logger.info("Enter into DsmController. getCircle");
		try{
			circle = saveDataService.getCircle(schemeName);
		} catch (Exception e) {
			e.printStackTrace();
		return circle;	

			//	return modelMap;
		}
		return circle;
	}
*/
	

	

	@RequestMapping(value="getCurrentScheme.action",method=RequestMethod.GET)
	public @ResponseBody String getCurrentScheme() throws Exception {
		try{
		httpSession.setAttribute("updateVersion",Boolean.FALSE);

		if(httpSession.getAttribute("schemeName")!=null)
			return httpSession.getAttribute("schemeName").toString();
		else
		{
			User user = (User)httpSession.getAttribute("appUser");
			if(user!=null){
			httpSession.setAttribute("userId", user.getUserName());
			httpSession.setAttribute("circleId", user.getCircleId());
		}httpSession.setAttribute("schemeName", schemeInputDao.getCurrentScheme());
			httpSession.setAttribute("schemeId",schemeInputDao.getSchemeId(schemeInputDao.getCurrentScheme()));
			return schemeInputDao.getCurrentScheme();
		}
		}catch(Exception e){
			e.printStackTrace();
		}
		return "";
	}


	@RequestMapping(value="resetScheme.action",method=RequestMethod.POST)
	public @ResponseBody String resetScheme(@ModelAttribute SchemeMaster sm) throws Exception {
		httpSession.setAttribute("editMode", "YES");
		httpSession.setAttribute("schemeName", sm.getSchemeName());
		int scmId = schemeInputDao.getSchemeId(sm.getSchemeName());
		sm.setCircleId(Integer.valueOf(httpSession.getAttribute("circleId").toString()));
		schemeSearchService.loadScheme(sm);
		httpSession.setAttribute("schemeId", scmId);
		return "success";
	}

	@RequestMapping(value="clearScheme.action",method=RequestMethod.POST)
	public @ResponseBody String clearScheme(@ModelAttribute SchemeMaster sm) throws Exception {
		httpSession.setAttribute("schemeName", null);
		return "success";
	}


	@RequestMapping(value="resetUpdateFlag.action",method=RequestMethod.POST)
	public @ResponseBody Object resetUpdateFlag(@ModelAttribute ResponseVO sm) throws Exception {
		Boolean status = Boolean.valueOf(sm.isSuccess());
		httpSession.setAttribute("updateVersion",status);

		return "success";
	}

	@RequestMapping(value="updateTq.action", method=RequestMethod.POST)
	@ResponseBody
	public Map<String,? extends Object> updateTq(@ModelAttribute SchemeTqMaster tq, BindingResult result, HttpSession session) throws IOException
	{
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : updateTq()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			try
			{
				if ((result.hasErrors()||(!(result.hasErrors()))))
				{
					tq.setUpdateDate(new Date());
						tq.setValFlag("Y");
						saveDataService.updateTqVflag(httpSession.getAttribute("schemeName").toString()
								, tq.getCompId()
								, tq.getCondId(), tq);

						tq.setSchemeName(httpSession.getAttribute("schemeName").toString());
						tq.setCircleId(Integer.valueOf(httpSession.getAttribute("circleId").toString()));
						tq.setProcessType("G");
						tq.setReConfigId(tq.getReConfigId()+1);
						tq.setGroupId(1);
						tq.setValFlag("Y");
						if(tq.getValue()==null)
							tq.setValue(tq.getValueListName());
						if(tq.getlValue()==null)
							tq.setlValue(tq.getLvalueListName());
						schemeInputDao.updateTq(httpSession.getAttribute("schemeName").toString()
								, tq.getCompId()
								, tq.getCondId(),
								tq.getCondRowId(),
								tq);
	//
			//		}

						modelMap.put("tqData",tq);		
					modelMap.put("success", true);
				}
			}catch(Exception e)
			{
				logger.error("Configuration --> Create --> Transaction Qualifications  :: DsmController : updateTq()   :: User Id = "+user.getUserName() +" Exception :: ",e);
				modelMap.put("errorMessage",e.getMessage());
				modelMap.put("success", false);
			}
		}else{
		modelMap.put("success",Boolean.FALSE);
		modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : updateTq()  : End :: User Id = "+user.getUserName() );
		
		return modelMap;
	}

	@RequestMapping(value="updateEaFilter.action", method=RequestMethod.POST)
	@ResponseBody
	public Map<String,? extends Object> updateEaFilter(@ModelAttribute SchemeEaFilterCondMaster eaFilter, BindingResult result, HttpSession session) throws IOException
	{
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : updateEaFilter()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			try{

				if ((result.hasErrors()||(!(result.hasErrors()))))
				{
					eaFilter.setUpdateDate(new Date());
						eaFilter.setValFlag("Y");
						eaFilter.setUpdateDate(new Date());
					
						eaFilter.setSchemeName(httpSession.getAttribute("schemeName").toString());
						eaFilter.setProcessType("G");
						
						if(eaFilter.getValue()==null)
						eaFilter.setValue(eaFilter.getValueListName());
							
							schemeInputDao.updateEaFilter(httpSession.getAttribute("schemeName").toString(), eaFilter.getCompId(),eaFilter.getVariableId(), eaFilter.getVariableRowId(), eaFilter);

					
						modelMap.put("errorMessage", "successs");
						modelMap.put("success", true);

				
				}
					
					
				
			}
			catch (Exception e) {
					logger.error("Configuration --> Create --> Filter Aggregates  :: DsmController : updateEaFilter()   :: User Id = "+user.getUserName()+" Exception ::",e );
				e.printStackTrace();
				modelMap.put("errorMessage", e.getMessage().toString());
				modelMap.put("success", false);

				//	return modelMap;
			}
		}else{
		modelMap.put("success",Boolean.FALSE);
		modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : updateEaFilter()  : End :: User Id = "+user.getUserName() );
		
		return modelMap;
	}

	@RequestMapping(value="updateEa.action", method=RequestMethod.POST)
	@ResponseBody
	public Map<String,? extends Object> updateEa(@ModelAttribute SchemeEaMaster ea, BindingResult result, HttpServletRequest request) throws IOException
	{
		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Performance Aggregates  :: DsmController : updateEa()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			
			try{
				logger.debug("entityType :::: "+request.getParameter("entityType"));
				ea.setValFlag("Y");
				if ((result.hasErrors()||(!(result.hasErrors())))) 
				{
					ea.setUpdateDate(new Date());
					
					if(ea.getValue()!=null)
					{
						
					}
					else
					{
						if(ea.getValueListName()!=null)
						ea.setValue(ea.getValueListName());
					}
					
						schemeInputDao.updateEa(httpSession.getAttribute("schemeName").toString(), ea.getCompId(),ea.getCondId(),ea.getCondRowId(), ea);
						modelMap.put("success", true);
						modelMap.put("success",Boolean.TRUE);
						modelMap.put("errorMessage", "Congrats !!!! Form Submited Successfully");
				}
				
			}
			catch (Exception e)
			{
				logger.error("Configuration --> Create --> Performance Aggregates  :: DsmController : updateEa()   :: User Id = "+user.getUserName()+" Exception ::",e );
				e.printStackTrace();
				modelMap.put("errorMessage", e.getMessage());
				modelMap.put("success", false);
			}
		}else{
		modelMap.put("success",Boolean.FALSE);
		modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Performance Aggregates  :: DsmController : updateEa()  : End :: User Id = "+user.getUserName() );
		
		return modelMap;
	}


	@RequestMapping(value="removeComp.action", method=RequestMethod.POST)
	@ResponseBody
	public Map<String,? extends Object> removeComp(@ModelAttribute CompMaster comp) throws IOException
	{
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Component  :: DsmController : removeComp()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 )){
			try
			{
			int r = 	saveDataService.deleteComp(comp.getSchemeId(), comp.getCompId());
			if(r==0)
			{
				modelMap.put("success",Boolean.FALSE);
				modelMap.put("errorMessage", "Submited Comp can't be deleted");
			}
			else
				modelMap.put("success", true);
			}
			catch(Exception e)
			{
				modelMap.put("success", false);
				return modelMap;
			}
		}else{
			modelMap.put("success",Boolean.FALSE);
			modelMap.put("errorMessage", "You are not having this privilege access...");			
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Component  :: DsmController : removeComp()  : End :: User Id = "+user.getUserName() );
		
				return modelMap;

	}

	@RequestMapping(value="updateComp.action", method=RequestMethod.POST)
	@ResponseBody
	public /*Map<String,? extends Object>*/String updateComp(@ModelAttribute CompMaster comp) throws IOException
	{
		logger.debug("updateComp ************* cat:::::  "+comp.getCategory());
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Component  :: DsmController : updateComp()  : Start :: User Id = "+user.getUserName() );
		
		String value="";
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 )){
			
			if(httpSession.getAttribute("schemeName")!=null)
			{
				try
				{
					
					int schemeId = schemeInputDao.getSchemeId((String)httpSession.getAttribute("schemeName"), user.getCircleId());
					
					comp.setUpdateTime(new Date());
					comp.setValFlag("Y");
					comp.setCompVer(1);
					comp.setSchemeId(schemeId);
					saveDataService.updateComp(comp.getSchemeId(), comp.getCompId(), comp);
					/*if (comp.getFileUpload() != null && comp.getFileUpload().getOriginalFilename() != null && !"".equalsIgnoreCase(comp.getFileUpload().getOriginalFilename().trim())  && (comp.getUploadId()==1) ) {
						String[] fileName = comp.getFileUpload().getOriginalFilename().split("_");
						logger.debug("OriginalFilename :: "+comp.getFileUpload().getOriginalFilename()+" \t FileName ::"+comp.getFileName());
						if(fileName[0].equalsIgnoreCase(user.getUserCircleCode()))
						{
							if(fileNameValidate(comp.getFileUpload().getOriginalFilename(), 4)){
								File file = convert(comp.getFileUpload());
								value = bulkUploadService.fetchFileData(user.getUserName(), 4, file, user.getUserCircleCode(), comp.getSchemeId(), comp.getCompId());
							}else{
								value="File name does not adhere to correct naming convention.";
							}
						}else{
							value="Wrong Circle Code File Uploaded. ";
						}
					}*/
					modelMap.put("success","true");
					modelMap.put("errorMessage", "COMPONENT UPDATED SUCESSFULLY. "+value.toUpperCase());
					value = "COMPONENT UPDATED SUCESSFULLY. "+value.toUpperCase();
				}
				catch(Exception e)
				{
					logger.error("Configuration --> Create --> Component  :: DsmController : updateComp()   :: User Id = "+user.getUserName()+" Exception :: ",e );
					e.printStackTrace();
					modelMap.put("success", false);
					modelMap.put("errorMessage",e.getMessage());
					return "{\"success\":false, \"errorMessage\":\""+e.getMessage()+"\"}";
				}
			}else
			{
				modelMap.put("success", false);
				modelMap.put("errorMessage","Session Out");
				value = "Session Out";

			}
			logger.debug("End updateComp *************"+modelMap);
			//return "{\"success\":true, \"errorMessage\":\"COMPONENT UPDATED SUCESSFULLY.............. \"}";
	
		}else{
			modelMap.put("success",Boolean.FALSE);
			modelMap.put("errorMessage", "You are not having this privilege access...");
			
			value = "You are not having this privilege access...";
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Component  :: DsmController : updateComp()  : End :: User Id = "+user.getUserName() );
		
				return "{\"success\":true, \"errorMessage\":\""+value+"\"}";
		//return modelMap;
	}



	@RequestMapping(value="removeEaFilter.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO removeEaFilter(@ModelAttribute SchemeEaFilterCondMaster eaFilter) throws IOException
	{
		ResponseVO respVo = new ResponseVO();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : removeEaFilter()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			try
			{
				schemeInputDao.deleteEaFilter(httpSession.getAttribute("schemeName").toString(),eaFilter.getCompId(),eaFilter.getVariableId(),eaFilter.getVariableRowId());
				respVo.setSuccess(true);
			}catch(Exception e)
			{
					logger.error("Configuration --> Create --> Filter Aggregates  :: DsmController : removeEaFilter()   :: User Id = "+user.getUserName()+" Exception :: ",e );
				
				respVo.setSuccess(false);	
				respVo.setMessage(e.getMessage());
			}
		}else{
		respVo.setSuccess(false);	
		respVo.setMessage("You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : removeEaFilter()  : End :: User Id = "+user.getUserName() );
		
		return respVo;
	}

	@RequestMapping(value="addEaFilter.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 
	addEaFilter(@ModelAttribute("eaForm") SchemeEaFilterCondMaster eaFilterMaster
			, BindingResult result, HttpSession session) throws Exception  {

		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : addEaFilter()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if ((result.hasErrors()||(!(result.hasErrors())))) {
				eaFilterMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));

				if(eaFilterMaster.getValue()==null)
					eaFilterMaster.setValue(eaFilterMaster.getValueListName());
				
				
				eaFilterMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
//				eaFilterMaster.setVariableRowId(saveDataService.getEaFilterCondCount(httpSession.getAttribute("schemeName").toString(), eaFilterMaster.getVariableId()));
				eaFilterMaster.setVariableRowId(schemeInputDao.getEaFilterCondCount(httpSession.getAttribute("schemeName").toString(), eaFilterMaster.getVariableId(),eaFilterMaster.getCompId()));

				eaFilterMaster.setProcessType("G");
				eaFilterMaster.setReConfigId(1);
				eaFilterMaster.setValFlag("Y");
				eaFilterMaster.setUpdateDate(new Date());
				eaFilterMaster.setInsertDate(new Date());
				eaFilterMaster.setrOpr(1);
				saveDataService.saveEaFilter(eaFilterMaster);
				data.put("success",Boolean.TRUE);
				data.put("errorMessage", "Congrats !!!! Form Submited Successfully");
			}
			
		}else{
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : addEaFilter()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}


	/*@RequestMapping(value="removeTq.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO removeTq(@ModelAttribute SchemeTqMaster tq) throws IOException
	{
		ResponseVO respVo = new ResponseVO();
		 int r=  schemeInputDao.deleteTq(httpSession.getAttribute("schemeName").toString(), tq.getCompId(), tq.getCondId(),tq.getCondRowId());
		if(r==0)
		{
			respVo.setSuccess(false);
			respVo.setMessage("Please delete in desc order");	
			
		}
		else
		{
			respVo.setSuccess(true);
			respVo.setMessage("Tq deleted sucessfully");
		
		}
		return respVo;
	}*/
	@RequestMapping(value="removeTq.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO removeTq(@ModelAttribute SchemeTqMaster tq) throws IOException
	{
		ResponseVO respVo = new ResponseVO();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : removeTq()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			int r=  schemeInputDao.deleteTq(httpSession.getAttribute("schemeName").toString(), tq.getPerfParamName());
			if(r==0)
			{
				respVo.setSuccess(false);
				respVo.setMessage("Unable to perform delete. Please try again.");	
			}
			else
			{
				respVo.setSuccess(true);
				respVo.setMessage("Tq deleted sucessfully");
			}
		}else{
			respVo.setSuccess(false);
			respVo.setMessage("You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : removeTq()  : End :: User Id = "+user.getUserName() );
		
		return respVo;
	}

	
/*	@RequestMapping(value="removeEa.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO removeEa(@ModelAttribute SchemeEaMaster ea) throws IOException
	{
		ResponseVO respVo = new ResponseVO();
		try
		{
			schemeInputDao.deleteEa(httpSession.getAttribute("schemeName").toString(), ea.getCompId(), ea.getVariableId(),ea.getCondRowId());
			respVo.setSuccess(true);
		}catch(Exception e)
		{
			respVo.setSuccess(false);
			respVo.setMessage(e.getMessage());
		}
		return respVo;
	}*/

	@RequestMapping(value="removeEa.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO removeEa(@ModelAttribute SchemeEaMaster ea) throws IOException
	{
		ResponseVO respVo = new ResponseVO();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : removeEa()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			try
			{
				schemeInputDao.deleteEa(httpSession.getAttribute("schemeName").toString(), ea.getParameter());
				respVo.setSuccess(true);
			}catch(Exception e)
			{
					logger.error("Configuration --> Create --> Filter Aggregates  :: DsmController : removeEa()   :: User Id = "+user.getUserName()+" Exception :: ",e );
				
				respVo.setSuccess(false);
				respVo.setMessage(e.getMessage());
			}
		}else{
		respVo.setSuccess(false);
		respVo.setMessage("You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : removeEa()  : End :: User Id = "+user.getUserName() );
		
		return respVo;
	}


	@RequestMapping(value="getTqOprList.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTqOprList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			modelMap.put("data",converageService.getConverageDetails().getTqOprList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="getUnitList.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getUnitList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			modelMap.put("data",converageService.getConverageDetails().getUnitList() );

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="getPoValues.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getPoValues() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			modelMap.put("data",saveDataService.getPoValues(httpSession.getAttribute("schemeName").toString()) );
			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="getPoFilter.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getPoFilter() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : getPoFilter()  : Start :: User Id = "+user.getUserName() );
		
		try{
			modelMap.put("data",saveDataService.getPoFilter(httpSession.getAttribute("schemeName").toString()) );
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : getPoFilter()  : End :: User Id = "+user.getUserName() );
			
			return modelMap;

		} catch (Exception e) {
				logger.error("Configuration --> Create --> Payout Rules  :: DsmController : getPoFilter()   :: User Id = "+user.getUserName()+" Exception :: ",e );
			e.printStackTrace();
			modelMap.put("success", false);
			return modelMap;
		}
	}

	@RequestMapping(value="removePo.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO removePo(@ModelAttribute SchemePoMaster po) throws IOException
	{
		ResponseVO respVo = new ResponseVO();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : removePo()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			try
			{
				//saveDataService.deletePo(httpSession.getAttribute("schemeName").toString(),po.getCompId(),po.getCondId());
			//int result = 	schemeInputDao.deletePoCond(httpSession.getAttribute("schemeName").toString(),po.getCompId(),po.getCondId(),po.getCondRowId());
				int result = 	schemeInputDao.deletePoCond(httpSession.getAttribute("schemeName").toString(),po.getValueListName());	
			if(result==1)
			{
				respVo.setSuccess(true);
				respVo.setMessage("Condition deleted sucessfully");
			}
				else
				{	
					respVo.setSuccess(false);
					respVo.setMessage("Unable to perform delete operation. Please try again.");	
					
				}
			}catch(Exception e)
			{
				logger.error("Configuration --> Create --> Payout Rules  :: DsmController : removePo()   :: User Id = "+user.getUserName() +"Exception ::",e);
				respVo.setSuccess(false);
				respVo.setMessage(e.getMessage());		
			}
		}else{
		respVo.setSuccess(false);
		respVo.setMessage("You are not having this privilege access...");		
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : removePo()  : End :: User Id = "+user.getUserName() );
		
		return respVo;
	}

	@RequestMapping(value="updatePo.action", method=RequestMethod.POST)
	@ResponseBody
	public Map<String,? extends Object> updatePo(@ModelAttribute SchemePoMaster po, BindingResult result, HttpSession session) throws IOException
	{

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : updatePo()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{

			try
			{
				po.setValFlag("Y");
				if ((result.hasErrors()||(!(result.hasErrors()))))
				{
					
					
					if(po.getOprName()!=null)
						po.setOpr(Integer.valueOf(po.getOprName()));
					if(po.getLoprName()!=null)
					{
						po.setLopr(Integer.valueOf(po.getLoprName()));
					//logger.debug("LOPR+  "+po.getLopr());
					
					}

					if(po.getUnitName()!=null)
						po.setUnit(Integer.valueOf(po.getUnitName()));

					po.setUpdateDate(new Date());


					po.setCircleId((Integer)httpSession.getAttribute("circleId"));
					
					po.setSchemeName(httpSession.getAttribute("schemeName").toString());
					
					po.setProcessType("G");
					po.setInsertDate(new Date());
					po.setUpdateDate(new Date());
					po.setValFlag("Y");
			
					
					
					logger.debug("Erroor amt"+po.getAmount());

						schemeInputDao.updatePo(httpSession.getAttribute("schemeName").toString()
								,po.getCompId()
								,po.getCondId(),
								po.getCondRowId(),
								po);

					
					//	modelMap.put("poData",po);
						modelMap.put("success",Boolean.TRUE);

				}
			}
			catch(Exception e)
			{
					logger.error("Configuration --> Create --> Payout Rules  :: DsmController : updatePo()   :: User Id = "+user.getUserName()+" Exception ::",e );
				
				modelMap.put("errorMessage", e.getMessage());
				e.printStackTrace();
				
				modelMap.put("success",Boolean.FALSE);
			}
			
		}else{
		modelMap.put("success",Boolean.FALSE);
		modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : updatePo()  : End :: User Id = "+user.getUserName() );
		
		return modelMap;
	}

	@RequestMapping(value="addPoFilter.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 
	addPoFilter(@ModelAttribute("PoFilterForm") SchemePoAmtMaster poFilterMaster
			, BindingResult result, HttpSession session) throws Exception  {


		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : addPoFilter()  : Start :: User Id = "+user.getUserName() );
		
		if(httpSession.getAttribute("schemeName")!=null)
		{

			if ((result.hasErrors()||(!(result.hasErrors())))) {

				//logger.debug(result);
				try
				{
					poFilterMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));

					poFilterMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
					poFilterMaster.setProcessType("G");
					poFilterMaster.setReConfigId(1);
					poFilterMaster.setValFlag("Y");
					poFilterMaster.setUpdateDate(new Date());
					poFilterMaster.setInsertDate(new Date());

					saveDataService.savePoFilter(poFilterMaster);
					data.put("success",Boolean.TRUE);
					data.put("errorMessage", "Congrats !!!! Form Submited Successfully");


				}catch(Exception e)
				{
						logger.error("Configuration --> Create --> Filter Aggregates  :: DsmController : addPoFilter()  :: User Id = "+user.getUserName()+" Exception :: ",e );
					data.put("success",Boolean.FALSE);
					data.put("errorMessage", e.getMessage());
				}
			}
		}	

		else
		{
			data.put("success",Boolean.FALSE);
			data.put("errorMessage", "Session TimeOut");

		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : addPoFilter()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}

	
	@RequestMapping(value="getPo.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getPo() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : getPo()  : Start :: User Id = "+user.getUserName() );
		
		try{
			if(httpSession.getAttribute("schemeName")!=null)
			modelMap.put("data",saveDataService.getPo(httpSession.getAttribute("schemeName").toString()) );
			else{
				modelMap.put("success", false);
				modelMap.put("errorMessage", "Please try after sometime. Or Refresh the page. Or Re-load the scheme. ");
			}
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : getPo()  : End :: User Id = "+user.getUserName() );
			
			return modelMap;

		} catch (Exception e) {
				logger.error("Configuration --> Create --> Payout Rules  :: DsmController : getPo()   :: User Id = "+user.getUserName() +" Exception ::",e);
			
			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="getEaFilter.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getEaFilter() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : getEaFilter()  : Start :: User Id = "+user.getUserName() );
		
		try{
			modelMap.put("data",saveDataService.getEaFilter(httpSession.getAttribute("schemeName").toString()));
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Filter Aggregates  :: DsmController : getEaFilter()  : End :: User Id = "+user.getUserName() );
			
			return modelMap;

		} catch (Exception e) {
				logger.error("Configuration --> Create --> Filter Aggregates  :: DsmController : getEaFilter()  :: User Id = "+user.getUserName()+" Exception :: ",e );
			
			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="getEaVariables.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getEaVariables() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			modelMap.put("data",saveDataService.getEaVariables(httpSession.getAttribute("schemeName").toString()) );

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}



	@RequestMapping(value="getTq.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getTq() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : getTq()  : Start :: User Id = "+user.getUserName() );
		
		try{
			if(httpSession.getAttribute("schemeName")!=null)
			modelMap.put("data",saveDataService.getTq(httpSession.getAttribute("schemeName").toString()) );
			else{
				modelMap.put("success", false);
				modelMap.put("errorMessage", "Please try after sometime. Or Refresh the page. Or Re-load the scheme. ");
			}
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : addTq()  : End :: User Id = "+user.getUserName() );
							
			return modelMap;

		} catch (Exception e) {
				logger.error("Configuration --> Create --> Transaction Qualifications  :: DsmController : addTq()   :: User Id = "+user.getUserName() +" Exception :: ",e);
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage", e.getMessage());
			return modelMap;
		}
	}


	//coverage actions list
	@RequestMapping(value="getCov.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getCov() throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage :: DsmController : getCov()  : Start :: User Id = "+user.getUserName() );
		
		if(httpSession.getAttribute("schemeName")!=null)
		{
			try{
				modelMap.put("data",saveDataService.getCov(httpSession.getAttribute("schemeName").toString()) );
			} catch (Exception e) {
					logger.error("Configuration --> Create --> Coverage :: DsmController : getCov()   :: User Id = "+user.getUserName() +" Exception :: ",e);
				modelMap.put("errorMessage", e.getMessage().toString());
				modelMap.put("success", false);
			}
		}else{
			modelMap.put("data", null);
			modelMap.put("success", false);
			modelMap.put("errorMessage", "Please try after sometime. Or Refresh the page. Or Re-load the scheme. ");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage :: DsmController : getCov()  : End :: User Id = "+user.getUserName() );
		
		return modelMap;
	}

	@RequestMapping(value="updateCov.action", method=RequestMethod.POST)

	public @ResponseBody Map<String,? extends Object> updateCov(@ModelAttribute SchemeAcMaster cov, BindingResult result, HttpSession session) throws IOException
	{
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage :: DsmController : updateCov()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if((httpSession.getAttribute("schemeName")!=null)&&(httpSession.getAttribute("updateVersion")!=null))
			{
				if ((result.hasErrors()||(!(result.hasErrors())))) 
				{
					try
					{
						cov.setValFlag("Y");
						cov.setUpdateDate(new Date());
						
							if(cov.getValue()==null)
								cov.setValue(cov.getValueListName());
							if(cov.getlValue()==null)
								cov.setlValue(cov.getLvalueListName());

							cov.setCircleId((Integer)httpSession.getAttribute("circleId"));
							
							cov.setSchemeId(Integer.valueOf(httpSession.getAttribute("schemeId").toString()));
							schemeInputDao.updateCov(httpSession.getAttribute("schemeName").toString(), cov.getCompId(), cov.getCondId(),cov.getCondRowId(), cov);

							schemeInputDao.deleteExtraCov(cov.getSchemeId(), cov.getCompId());
							
							modelMap.put("covData",cov);
							modelMap.put("success", true);

					}
					catch (Exception e) {
							logger.error("Configuration --> Create --> Coverage :: DsmController : updateCov()   :: User Id = "+user.getUserName()+" Exception ::",e );
						e.printStackTrace();
						modelMap.put("errorMessage", e.getMessage().toString());
						modelMap.put("success", false);
					}
				}
			}
			else
			{
				//httpSession.setAttribute("schemeName","scheme222");
				httpSession.setAttribute("updateVersion",false);
				modelMap.put("errorMessage", "Session Out");
				modelMap.put("success", false);

			}
			
		}else{
		modelMap.put("success",Boolean.FALSE);
		modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage :: DsmController : updateCov()  : End :: User Id = "+user.getUserName() );
		
		return modelMap;
	}

	
	@RequestMapping(value="removeCov.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO  removeCov(@ModelAttribute SchemeAcMaster cov) throws IOException
	{
		ResponseVO respVo = new ResponseVO();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage :: DsmController : removeCov()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			try
			{
				//int  r = schemeInputDao.deleteCov(httpSession.getAttribute("schemeName").toString(), cov.getCompId(),cov.getCondId(),cov.getCondRowId());
				int  r = schemeInputDao.deleteCov(httpSession.getAttribute("schemeName").toString(),cov.getCo_ValueTypeName());
				if(r==0)
				{
					respVo.setSuccess(false);
					respVo.setMessage("Please delete in desc order");
					
				}
				else
				{
				respVo.setSuccess(true);
				respVo.setMessage("cov deleted sucessfully");
				}
				
				}
			catch(Exception e)
			{
				logger.error("Configuration --> Create --> Coverage :: DsmController : removeCov()   :: User Id = "+user.getUserName()+" Exception :: ",e );
				respVo.setSuccess(false);
				respVo.setMessage(e.getMessage());
			}

		}else{
			respVo.setSuccess(false);
			respVo.setMessage("You are not having this privilege access...");
			
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage :: DsmController : removeCov()  : End :: User Id = "+user.getUserName() );
		
				return respVo;

	}


	@RequestMapping(value="getRopr.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getRopr() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			modelMap.put("data",saveDataService.getRopr() );

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}


	@RequestMapping(value="getRegZone.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getRegZone() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : getRegZone()  : Start :: User Id = "+user.getUserName() );
		try{
			modelMap.put("data",saveDataService.getRegion(httpSession.getAttribute("schemeName").toString()) );
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Region & Zone :: DsmController : getRegZone()  : End :: User Id = "+user.getUserName() );

			return modelMap;
		} catch (Exception e) {
			logger.error("Configuration --> Create --> Region & Zone :: DsmController : getRegZone()   :: User Id = "+user.getUserName()+" Exception :: ",e );
			e.printStackTrace();
			modelMap.put("success", false);
			return modelMap;
		}
	}

	@RequestMapping(value="updateRegZone.action", method=RequestMethod.POST)
	@ResponseBody
	public Map<String,? extends Object> updateRegZone(@ModelAttribute RegZoneMaster regZone) throws IOException
	{

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : updateRegZone()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			try
			{
				regZone.setValFlag("Y");
				regZone.setUpdateTime(new Date());
				regZone.setInsertTime(new Date());
				
				regZone.setSchemeName(httpSession.getAttribute("schemeName").toString());
				regZone.setCircleId((Integer)httpSession.getAttribute("circleId"));
				saveDataService.updateRegZone(regZone);
						
				modelMap.put("success", Boolean.TRUE);
			}
			catch(Exception e)
			{
				logger.error("Configuration --> Create --> Region & Zone :: DsmController : updateRegZone()  :: User Id = "+user.getUserName()+" Exception :: ",e );
				
				modelMap.put("errorMessage",e.getMessage());
				modelMap.put("success", Boolean.FALSE);

				return modelMap;
			}

		}else{
		modelMap.put("success",Boolean.FALSE);
		modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : updateRegZone()  : End :: User Id = "+user.getUserName() );
		
				return modelMap;

	}

	@RequestMapping(value="removeRegZone.action", method=RequestMethod.POST)
	@ResponseBody
	public Map<String,? extends Object> removeRegZone(@ModelAttribute RegZoneMaster regZone) throws IOException
	{
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : removeRegZone()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2)){
			try
			{
				saveDataService.deleteRegZone(regZone.getCovRegZoneId());
				modelMap.put("success", true);
			}
			catch(Exception e)
			{
				logger.error("Configuration --> Create --> Region & Zone :: DsmController : removeRegZone()   :: User Id = "+user.getUserName()+" Exception ::",e );
				
				modelMap.put("errorMessage",e.getMessage());
				modelMap.put("success", Boolean.FALSE);
				return modelMap;
			}
		}else{
			modelMap.put("success",Boolean.FALSE);
			modelMap.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : removeRegZone()  : End :: User Id = "+user.getUserName() );
		
		return modelMap;

	}


	@RequestMapping(value="getCompMaster.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getCompMaster() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			if(httpSession.getAttribute("schemeName")!=null){
				CoverageOutput output=converageService.getCompList(httpSession.getAttribute("schemeName").toString());
				modelMap.put("data", output.getCompMasterList());
				int schemeId = 0;
				if(output.getCompMasterList().size()>0)
					schemeId = output.getCompMasterList().get(0).getSchemeId();
				httpSession.setAttribute("schemeId",schemeId );
			}
			return modelMap;

		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
			modelMap.put("errorMessage",e.getMessage());
			return modelMap;
		}
	}

	@RequestMapping(value="getCompMasterReg.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getCompMasterReg() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			if(httpSession.getAttribute("schemeName")!=null){
			CoverageOutput output=converageService.getCompListReg(httpSession.getAttribute("schemeName").toString());
			modelMap.put("data", output.getCompMasterListReg());
			
			int schemeId = 0;
			if(output.getCompMasterList().size()>0)
			 schemeId = output.getCompMasterList().get(0).getSchemeId();
			
			httpSession.setAttribute("schemeId",schemeId );
			}
			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);
			modelMap.put("errorMessage",e.getMessage());

			return modelMap;
		}
	}

	@RequestMapping(value="/getInputTypes.action")
	public @ResponseBody Map<String,? extends Object> getInputTypes() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getPayoutConditionList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getInputParameters.action")
	public @ResponseBody Map<String,? extends Object> getInputParameters() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getPayToList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getSchemeComponents.action")
	public @ResponseBody Map<String,? extends Object> getSchemeComponents() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getPayoutConditionList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getOprs.action")
	public @ResponseBody Map<String,? extends Object> getOprs() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getPayoutConditionList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getValueTypes.action")
	public @ResponseBody Map<String,? extends Object> getValueTypes() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getPayoutConditionList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getPayoutFreq.action")
	public @ResponseBody Map<String,? extends Object> getPayoutFreq() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getPayoutList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}


	@RequestMapping(value="/getVerticals.action")
	public @ResponseBody Map<String,? extends Object> getVerticals() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getVerticalList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getPayTo.action")
	public @ResponseBody Map<String,? extends Object> getPayTo() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getPayToList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}


	@RequestMapping(value="/getScheme.action")
	public @ResponseBody Map<String,? extends Object> getScheme() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getSchemeList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="getCircles.action")
	public @ResponseBody Map<String,? extends Object> getCircles() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getCircleList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getRegions.action")
	public @ResponseBody Map<String,? extends Object> getRegions() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : getRegions()  : Start :: User Id = "+user.getUserName() );
		
		try{
			CoverageOutput output=converageService.getConverageDetails();
			 List<RegionMaster> regList = output.getRegionList();
			
			 if(!regList.contains("ALL"))
			 {
			 RegionMaster allRegion = new RegionMaster();
			 allRegion.setRegionId(0);
			 allRegion.setRegionDesc("ALL");
			 regList.add(allRegion);
			 }
			 modelMap.put("data", regList);
			 if(logger.isDebugEnabled())
					logger.debug("Configuration --> Create --> Region & Zone :: DsmController : getRegions()  : End :: User Id = "+user.getUserName() );
				
			return modelMap;

		} catch (Exception e) {
				logger.error("Configuration --> Create --> Region & Zone :: DsmController : getRegions()   :: User Id = "+user.getUserName()+" Exception ::", e );
			
			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getZones.action")
	public @ResponseBody Map<String,? extends Object> getZones() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : getZones()  : Start :: User Id = "+user.getUserName() );
		
		try{
			CoverageOutput output=converageService.getConverageDetails();
			
			 List<ZoneMaster> zoneList = output.getZoneList();
			
			 if(!zoneList.contains("ALL"))
			 {
				 
				 ZoneMaster zoneAll = new ZoneMaster();
				 
				 zoneAll.setZoneId(0);
				 zoneAll.setZoneDesc("ALL");
				 zoneList.add(zoneAll);
				 
			 }
			
			modelMap.put("data", zoneList);
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Region & Zone :: DsmController : getZones()  : End :: User Id = "+user.getUserName() );
			
			return modelMap;

		} catch (Exception e) {
				logger.error("Configuration --> Create --> Region & Zone :: DsmController : getZones()  :: User Id = "+user.getUserName()+" Exception :: ",e );
			e.printStackTrace();
			modelMap.put("success", false);
			return modelMap;
		}
	}

	@RequestMapping(value="/getUploadList.action")
	public @ResponseBody Map<String,? extends Object> UploadList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getUploadList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getEntityList.action")
	public @ResponseBody Map<String,? extends Object> EntityList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getEntityList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getAttributeTypeList.action")
	public @ResponseBody Map<String,? extends Object> getAttributeTypeList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getAttributeTypeList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="/getFunctionList.action")
	public @ResponseBody Map<String,? extends Object> getFunctionList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getFunctionList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}


	@RequestMapping(value="/getEntityAttributeList.action")
	public @ResponseBody Map<String,? extends Object> getEntityAttributeList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getEntityAttributeList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}
	
	
	@RequestMapping(value="/getEaValueList.action")
	public @ResponseBody Map<String,? extends Object> getEaValueList() throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		try{
			User user = (User)httpSession.getAttribute("appUser");
			if(user!=null){
				List<EntityAttributeMaster> valueList = schemeInputDao.getEaValueList();
				if(httpSession.getAttribute("schemeName")!=null){
					List<SchemeEaMaster> var = schemeInputDao.getEaVaraibles(httpSession.getAttribute("schemeName").toString());
					for(SchemeEaMaster s: var)
					{
						EntityAttributeMaster obj = new EntityAttributeMaster();
						obj.setEntityAttributeId(s.getVariableId());
						obj.setEntityAttributeName(s.getVariableName());
						obj.setCompId(s.getCompId());
						obj.setVarFlag("Y");
						valueList.add(obj);
					}
				}
				modelMap.put("data", valueList);
				return modelMap;
			}
			return null;
		} catch (Exception e) {
			e.printStackTrace();
			modelMap.put("success", false);
			return modelMap;
		}
	}


	@RequestMapping(value="/getOprList.action")
	public @ResponseBody Map<String,? extends Object> getOprList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getOprList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}


	@RequestMapping(value="/getValueTypeList.action")
	public @ResponseBody Map<String,? extends Object> getValueTypeList() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);

		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getValueTypeList());

			return modelMap;

		} catch (Exception e) {

			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}


	
	@RequestMapping(value="removeScheme.action", method=RequestMethod.POST)
	@ResponseBody
	public String removeScheme(@ModelAttribute SchemeMaster scheme) throws IOException
	{
		saveDataService.deleteScheme(scheme);
		return scheme.getSchemeName();
	}

	
	
	@RequestMapping(value="acessDenied.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 
	accessDenied(HttpServletResponse response
			, HttpSession session) throws Exception  {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "Access Denied");
	return data;
	}

	@RequestMapping(value="timeOut.action", method=RequestMethod.GET)
	public @ResponseBody Map<String, ? extends Object> 
	timeOut(HttpServletResponse response
			, HttpSession session) throws Exception  {
		Map<String, Object> data = new HashMap<String, Object>();
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "Time Out");
	return data;
	}
	
	

	@RequestMapping(value="saveRegionZone.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 	saveRegionZone(@ModelAttribute("regionZoneForm") RegZoneMaster regionZone, BindingResult result, HttpSession session) throws Exception  {
		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : saveRegionZone()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 )){

			try
			{
				//Region Zone master submit
				int regSerial = 1;
				
				if ((result.hasErrors()||(!(result.hasErrors()))))
				{
						
					
				regionZone.setSchemeName(httpSession.getAttribute("schemeName").toString());
				regionZone.setCircleId(Integer.valueOf(httpSession.getAttribute("circleId").toString()));
				regionZone.setCovRegZoneSerialId(regSerial);
				regionZone.setUpdateTime(new Date());
				regionZone.setInsertTime(new Date());
				regionZone.setValFlag("Y");
				
				regionZone.setUserId("TEST");
				if(regionZone.getRegionId()==0)
				{
					regionZone.setZoneId(0);
					saveDataService.saveRegion(regionZone);
				}
				else
				{		
				saveDataService.saveRegion(regionZone);
				}
				
				data.put("success",Boolean.TRUE);
				data.put("errorMessage", "Congrats !!!! Form Submited Successfully");
			}
			}	catch(Exception e)	{
				
					logger.error("Configuration --> Create --> Region & Zone :: DsmController : saveRegionZone()  :: User Id = "+user.getUserName()+" Exception :: ",e );
				
				data.put("success",Boolean.FALSE);
				e.printStackTrace();
				data.put("errorMessage","Region Zone Already Exist");
			}
			
		}else{
			data.put("success",Boolean.FALSE);
			data.put("errorMessage", "You are not having this privilege access...");
			
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Region & Zone :: DsmController : saveRegionZone()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}


	@RequestMapping(value="addTq.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object>	addTq(@ModelAttribute("tqForm") SchemeTqMaster tqMaster
			, BindingResult result, HttpSession session)  throws Exception 
			{
		
		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : addTq()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if ((result.hasErrors()||(!(result.hasErrors()))))
			{
				try
				{
					
			/*		if((tqMaster.getlRopr()==1) || (tqMaster.getlRopr()==2) || (tqMaster.getlRopr()==25)|| (tqMaster.getlRopr()==24)|| (tqMaster.getlRopr()==26)|| (tqMaster.getlRopr()==25|| (tqMaster.getlRopr()==23)))
					{
						if(tqMaster.getCondName()!=null)
						{
							httpSession.setAttribute("dataSetId", tqMaster.getDataSet());
							httpSession.setAttribute("compId", tqMaster.getCompId());
							httpSession.setAttribute("condName", tqMaster.getCondName());
							tqMaster.setCondId(schemeInputDao.getTqCondCount(httpSession.getAttribute("schemeName").toString(),tqMaster.getCompId())+1);
							httpSession.setAttribute("condId", tqMaster.getCondId());
						}
						else
						{
							tqMaster.setCondName(httpSession.getAttribute("condName").toString());
							tqMaster.setCondId(Integer.valueOf(httpSession.getAttribute("condId").toString()));
							tqMaster.setDataSet	(Integer.valueOf(httpSession.getAttribute("dataSetId").toString()));
							tqMaster.setCompId(Integer.valueOf(httpSession.getAttribute("compId").toString()));

							
						}
					}
					
				*/	
					
					 int newcond = schemeInputDao.getTqCondCount(tqMaster.getCondName(),tqMaster.getCompId());
		
					 if(newcond==0)
					 {
						 tqMaster.setCondId(schemeInputDao.getTqCondMaxCount(tqMaster.getCompId())+1);
						 
					 }	 
					 else
					 {
						 tqMaster.setCondId(schemeInputDao.getTqCondMaxCount(tqMaster.getCompId()));					 
						 
					 }
					 
					// tqMaster.setCondRowId(1);
					tqMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));

					tqMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
					tqMaster.setProcessType("G");
					tqMaster.setReConfigId(1);
					if(tqMaster.getValue()==null)
						tqMaster.setValue(tqMaster.getValueListName());
					if(tqMaster.getlValue()==null)
						tqMaster.setlValue(tqMaster.getLvalueListName());

					tqMaster.setGroupId(1);
					tqMaster.setCondRowId(schemeInputDao.getTqCondRowCount(tqMaster.getSchemeName(), tqMaster.getCondId(),tqMaster.getCompId())+1);
					tqMaster.setValFlag("Y");
					tqMaster.setUpdateDate(new Date());
					tqMaster.setInsertDate(new Date());
					saveDataService.saveTq(tqMaster);
					data.put("success",Boolean.TRUE);
					data.put("errorMessage", "Congrats !!!! Form Submited Successfully");
					data.put("tqData",tqMaster);

					if(logger.isDebugEnabled())
						logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : addTq()  : Start :: User Id = "+user.getUserName() );
							
				}catch(Exception e)
				{
						logger.error("Configuration --> Create --> Transaction Qualifications  :: DsmController : addTq()  :: User Id = "+user.getUserName()+" Exception :: ",e );
					
					data.put("success",Boolean.FALSE);
					data.put("errorMessage",e.getMessage());

				}

			}
		}else{
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Transaction Qualifications  :: DsmController : addTq()  : End :: User Id = "+user.getUserName() );
		
		return data;
			}

	@RequestMapping(value="getEa.action",method=RequestMethod.GET)
	public @ResponseBody Map<String,? extends Object> getEa() throws Exception {

		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Performance Aggregates  :: DsmController : getEa()  : Start :: User Id = "+user.getUserName() );
		
		try{
			if(httpSession.getAttribute("schemeName")!=null)
			modelMap.put("data",saveDataService.getEa(httpSession.getAttribute("schemeName").toString()) );
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Performance Aggregates  :: DsmController : addEa()  : End :: User Id = "+user.getUserName() );
			
			return modelMap;

		} catch (Exception e) {
				logger.error("Configuration --> Create --> Performance Aggregates  :: DsmController : addEa()  :: User Id = "+user.getUserName()+" Exception :: ",e );
			
			e.printStackTrace();

			modelMap.put("success", false);

			return modelMap;
		}
	}

	@RequestMapping(value="addEa.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 	addEa(@ModelAttribute("eaForm") SchemeEaMaster eaMaster, BindingResult result, HttpSession session) throws Exception  {
		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Performance Aggregates  :: DsmController : addEa()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if(httpSession.getAttribute("schemeName")!=null)
			{
				if ((result.hasErrors()||(!(result.hasErrors())))) {
					try
					{
						if(saveDataService.eaVarNameVal(eaMaster.getVariableName()))
						{
							if(eaMaster.getValue()!=null)
							{
							}
							else
							{
								if(eaMaster.getValueListName()!=null)
									eaMaster.setValue(eaMaster.getValueListName());
							}
							eaMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));
							eaMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
							eaMaster.setProcessType("G");
							eaMaster.setReConfigId(1);
							eaMaster.setCondId(schemeInputDao.getEaCondCount(httpSession.getAttribute("schemeName").toString(),eaMaster.getCompId())+1);
							eaMaster.setVariableId(schemeInputDao.getEaCondCount(httpSession.getAttribute("schemeName").toString(),eaMaster.getCompId())+1);
							eaMaster.setValFlag("Y");
							eaMaster.setUpdateDate(new Date());
							eaMaster.setInsertDate(new Date());
							saveDataService.saveEa(eaMaster);
							data.put("success",Boolean.TRUE);
							data.put("errorMessage", "Form Submited Successfully");
						}
						else
						{
							data.put("success",Boolean.FALSE);
							data.put("errorMessage", "Varaible Already Exist");
						}
					}catch(Exception e)
					{
						if(logger.isDebugEnabled())
							logger.debug("Configuration --> Create --> Performance Aggregates  :: DsmController : addEa()  :: User Id = "+user.getUserName()+" Exception :: ",e );
						
						e.printStackTrace();
						data.put("success",Boolean.FALSE);
						data.put("errorMessage",e.getMessage());
					}
				}
			}
		}else{
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Performance Aggregates  :: DsmController : addEa()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}



	@RequestMapping(value="addScheme.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 	addScheme(@ModelAttribute("schemeForm") SchemeMaster schemeMaster, BindingResult result, HttpSession session) throws Exception  {
		String errMsgAllReadyConfig="Scheme name is already configured";
		String schemeName = null;
		httpSession.setAttribute("editMode", "NO");
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage  :: DsmController : addScheme()  : Start :: User Id = "+user.getUserName() );
		
		session.setAttribute("schemeName", schemeName);
		schemeMaster.setUserId(user.getUserName());
		schemeMaster.setCircleId(user.getCircleId());
		httpSession.removeAttribute("schemeName");
		Map<String, Object> data = new HashMap<String, Object>();
		String flag = null;
		try
		{
			String schemeNameOld = schemeMaster.getSchemeNameOld();
			if(schemeNameOld != null && !("".equalsIgnoreCase(schemeNameOld.trim())) && schemeNameOld.length() != 0 )
			{
				logger.debug("schemeMaster.getMonth() ::::::::::::::::::::::::::: "+schemeMaster.getMonth());
				if(!schemeMaster.getSchemeName().equals(schemeNameOld.trim())){
					flag = saveDataService.schemeUpdateOldToNew(schemeMaster,schemeMaster.getMonth());
					data.put("success",Boolean.TRUE);
					data.put("schemeName", schemeMaster.getSchemeName());
					data.put("createMode", "Copied");
					if(flag!=null && flag.contains(errMsgAllReadyConfig))
					{
						data.put("success",Boolean.FALSE);
					}
					data.put("errorMessage",flag);
					httpSession.setAttribute("schemeName", schemeMaster.getSchemeName());
				}else
				{
					data.put("success",Boolean.FALSE);
					data.put("errorMessage","Two Scheme Name should be different.");
				}

			}else{
				//char v = 'I';
				schemeMaster.setValidityFlag("Y");
				schemeMaster.setUpdateTime(new Date());
				schemeMaster.setInsertTime(new Date());
				httpSession.setAttribute("schemeName", schemeMaster.getSchemeName());
				httpSession.setAttribute("circleId", schemeMaster.getCircleId());
				if(saveDataService.schemeNameVal(schemeMaster.getSchemeName(), schemeMaster.getCircleId()))
				{
					saveDataService.saveScheme(schemeMaster);
					data.put("success",Boolean.TRUE);
					data.put("schemeName", schemeMaster.getSchemeName());
					data.put("createMode", "is created Successfully");
					//data.put("errorMessage","Successfully");
				} 
				else
				{
					data.put("success",Boolean.FALSE);
					data.put("errorMessage","Scheme already exists.");
				}
			}
		}catch(Exception e)
		{
				logger.error("Configuration --> Create --> Coverage  :: DsmController : addScheme()  :: User Id = "+user.getUserName()+" Exception :: ",e );
			
			data.put("success",Boolean.FALSE);
			data.put("errorMessage", e.getMessage().toString());
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage  :: DsmController : addScheme()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}



	@RequestMapping(value="addCoverage.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> 	addCoverage(@ModelAttribute("coverageForm")  SchemeAcMaster coverageMaster, BindingResult result, HttpSession session) throws Exception  {
		Map<String, Object> data = new HashMap<String, Object>();
		
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage  :: DsmController : addCoverage()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if(httpSession.getAttribute("schemeName")!=null)
			{
				if ((result.hasErrors()||(!(result.hasErrors())))) {
					try
					{
						httpSession.setAttribute("compId", coverageMaster.getCompId());
						coverageMaster.setCircleId(Integer.valueOf(httpSession.getAttribute("circleId").toString()));
						//		logger.debug(result.toString());
						coverageMaster.setProcessType("G");
						coverageMaster.setReConfigId(1);
						if(coverageMaster.getValue() == null)
							coverageMaster.setValue(coverageMaster.getValueListName());
						if(coverageMaster.getlValue() == null)
							coverageMaster.setlValue(coverageMaster.getLvalueListName());

						coverageMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());

						int condCount = schemeInputDao.getcovCondCount(httpSession.getAttribute("schemeName").toString(),coverageMaster.getCompId());

						if(condCount==0)
							coverageMaster.setCondId(schemeInputDao.getcovCondCount(httpSession.getAttribute("schemeName").toString(),coverageMaster.getCompId())+1);
						else
							coverageMaster.setCondId(schemeInputDao.getcovCondCount(httpSession.getAttribute("schemeName").toString(),coverageMaster.getCompId()));

						coverageMaster.setCondRowId(schemeInputDao.getcovCondRowCount(coverageMaster.getSchemeName(), coverageMaster.getCondId(),coverageMaster.getCompId())+1);
						coverageMaster.setValFlag("Y");
						coverageMaster.setUpdateDate(new Date());
						coverageMaster.setInsertDate(new Date());
						coverageMaster.setCircleId(Integer.valueOf(httpSession.getAttribute("circleId").toString()));
						saveDataService.saveAddCovCond(coverageMaster);
						data.put("success",Boolean.TRUE);
						data.put("covData",coverageMaster);
						data.put("errorMessage", "Congrats !!!! Form submited successfully");
					}catch(Exception e)
					{
							logger.error("Configuration --> Create --> Coverage  :: DsmController : addCoverage()  :: User Id = "+user.getUserName()+" Exception :: ",e );
						
						data.put("success",Boolean.FALSE);
						e.printStackTrace();
						data.put("errorMessage", e.getMessage().toString());
					}
				} 
			}
			else
			{
				data.put("success",Boolean.FALSE);
				data.put("errorMessage", "Session Out");
			}
			
		}else{
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Coverage  :: DsmController : addCoverage()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}



	@RequestMapping(value="addComp.action", method=RequestMethod.POST)
	public @ResponseBody /*Map<String, ? extends Object>*/String 	addComp(@ModelAttribute("compForm") CompMaster compMaster, BindingResult result,
			//,@RequestParam("fileUpload") MultipartFile file,
			HttpServletRequest request, HttpServletResponse response, HttpSession session) throws Exception  {
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Component  :: DsmController : addComp()  : Start :: User Id = "+user.getUserName() );
		
		Map<String, Object> data = new HashMap<String, Object>();
		String value="";
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 )){
			logger.debug("Category :::::::::::::::::  "+compMaster.getCategory());
			if(httpSession.getAttribute("schemeName")!=null)
			{
				int schemeId =  schemeInputDao.getSchemeId((String)httpSession.getAttribute("schemeName"), user.getCircleId());
				logger.debug("schemeID::: "+schemeId+"\t scid:::: "+request.getParameter("schemeId")+"\t scname:: "+httpSession.getAttribute("schemeName"));
				if(schemeId==0){
					value = "Scheme is not valid/Not exists. ";
					return "{\"success\":false, \"errorMessage\":\""+value+"\"}";
				}
				 
				compMaster.setSchemeId(schemeId);
				//response.setContentType("text/html");//application/json
				//response.setContentType("application/json");//
				if (result.hasErrors()){
					for(ObjectError error : result.getAllErrors()){
						System.err.println("Error: " + error.getCode() + " - " + error.getDefaultMessage());
					}
				}
				if ((result.hasErrors()||(!(result.hasErrors()))))
				{
					try
					{
						compMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));

						int compCount = saveDataService.getCompCount(httpSession.getAttribute("schemeName").toString(),(Integer)httpSession.getAttribute("circleId"));
						compMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
						if("NO".equals(httpSession.getAttribute("editMode").toString()))
							compMaster.setCompId(compCount+1);
						else
						{
							int masterId = schemeInputDao.getCompCountFromMaster(httpSession.getAttribute("schemeName").toString(),(Integer)httpSession.getAttribute("circleId"));

							if(masterId>compCount) 
								compMaster.setCompId(masterId+1);
							else
								compMaster.setCompId(compCount+1);
						}
						compMaster.setCompVer(1);
						compMaster.setUpdateTime(new Date());
						compMaster.setInsertTime(new Date());
						compMaster.setScmStatus("I");
						compMaster.setUserName(user.getUserName());
						compMaster.setValFlag("Y");

						if("NO".equals(httpSession.getAttribute("editMode").toString()))
						{
				
						if(saveDataService.compNameVal(compMaster.getCompName()))
						{
							String duplicate  = saveDataService.saveComponent(compMaster);
							if(duplicate != null){
								return "{\"success\":false, \"errorMessage\":\""+duplicate+"\"}";
							}
							/*if (compMaster.getFileUpload() != null && compMaster.getFileUpload().getOriginalFilename() != null && !"".equalsIgnoreCase(compMaster.getFileUpload().getOriginalFilename().trim())  && (compMaster.getUploadId()==1) ) {
								String[] fileName = compMaster.getFileUpload().getOriginalFilename().split("_");
								logger.debug("OriginalFilename :: "+compMaster.getFileUpload().getOriginalFilename()+" \t FileName ::"+compMaster.getFileName());
								if(fileName[0].equalsIgnoreCase(user.getUserCircleCode()))
								{
									if(fileNameValidate(compMaster.getFileUpload().getOriginalFilename(), 4)){
										File file = convert(compMaster.getFileUpload());
										value = bulkUploadService.fetchFileData(user.getUserName(), 4, file, user.getUserCircleCode(), compMaster.getSchemeId(), compMaster.getCompId());
									}else{
										value="File name does not adhere to correct naming convention.";
									}
								}else{
									value="Wrong Circle Code File Uploaded. ";
								}
							}*/
							
						}
						
						else
						{
							data.put("success",Boolean.FALSE);
							data.put("errorMessage", "Component Already Exist");
							value = "Component Already Exist";
						}
						
						}
						
						else
						{
		//					saveDataService.saveComponent(compMaster);
							String duplicate  = saveDataService.saveComponent(compMaster);
							if(duplicate != null){
								return "{\"success\":false, \"errorMessage\":\""+duplicate+"\"}";
							}

							/*if (compMaster.getFileUpload() != null && compMaster.getFileUpload().getOriginalFilename() != null && !"".equalsIgnoreCase(compMaster.getFileUpload().getOriginalFilename().trim())  && (compMaster.getUploadId()==1) ) {
								String[] fileName = compMaster.getFileUpload().getOriginalFilename().split("_");
								logger.debug("OriginalFilename :: "+compMaster.getFileUpload().getOriginalFilename()+" \t FileName ::"+compMaster.getFileName());
								if(fileName[0].equalsIgnoreCase(user.getUserCircleCode()))
								{
									if(fileNameValidate(compMaster.getFileUpload().getOriginalFilename(), 4)){
										File file = convert(compMaster.getFileUpload());
										value = bulkUploadService.fetchFileData(user.getUserName(), 4, file, user.getUserCircleCode(), compMaster.getSchemeId(), compMaster.getCompId());
									}else{
										value="File name does not adhere to correct naming convention.";
									}
								}else{
									value="Wrong Circle Code File Uploaded. ";
								}
							}*/

						}
						data.put("success",Boolean.TRUE);
						data.put("errorMessage", "Component created successfully, "+value);
						
						value = "Component created successfully, "+value;
						
					}catch(Exception e)
					{
							logger.error("Configuration --> Create --> Component  :: DsmController : addComp()  :: User Id = "+user.getUserName()+" Exception ", e );
						
						//logger.debug(e);
						data.put("success",Boolean.FALSE);
						data.put("errorMessage",e.getMessage());
						return "{\"success\":false, \"errorMessage\":\""+e.getMessage()+"\"}";
					}
				}
			
		else
			{
				data.put("success",Boolean.FALSE);

				data.put("errorMessage", "Scheme not availaible");
				value ="Scheme not availaible";
			}
			
		}
			//return data;
	
		}else{
			data.put("success",Boolean.FALSE);
			data.put("errorMessage", "You are not having this privilege access...");
			value ="You are not having this privilege access...";
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Component  :: DsmController : addComp()  : End :: User Id = "+user.getUserName() );
		
				return "{\"success\":true, \"errorMessage\":\""+value+"\"}";
	}


	@RequestMapping(value="addPo.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> addPo(@ModelAttribute("poForm") SchemePoMaster poMaster, BindingResult result, HttpSession session) throws Exception  {
	
		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : addPo()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if ((result.hasErrors()||(!(result.hasErrors())))) {
				if(httpSession.getAttribute("schemeName")!=null)
				{
				try
				{
					if((poMaster.getValueListName()!=null ) &&(poMaster.getValueListName().length()!=0))
					{
						poMaster.setValue(poMaster.getValueListName());
					}
					
				poMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));
				poMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
				poMaster.setProcessType("G");
				poMaster.setReConfigId(1);
				poMaster.setInputType("0");
				poMaster.setValueType("0");
				
				//BigDecimal amt = 0;
				poMaster.setAmount(new BigDecimal(0));
				//poMaster.setCondRowId(1);
				//if((poMaster.getLopr()!=1)&&(poMaster.getLopr()!=2) )
				poMaster.setCondId(schemeInputDao.getPoCondCount(httpSession.getAttribute("schemeName").toString(),poMaster.getCompId())+1);
				//poMaster.setCondId(2);
				poMaster.setCondRowId(schemeInputDao.getPoFiltersRowCount(poMaster.getSchemeName(), poMaster.getCondId(),poMaster.getCompId())+1);
				//else
				//{	
				//poMaster.setCondId(saveDataService.getPoFiltersCount(httpSession.getAttribute("schemeName").toString()));
				//if(poMaster.getCondId()==0)
				//{
					//poMaster.setCondId(saveDataService.getPoFiltersCount(httpSession.getAttribute("schemeName").toString())+1);
			//	logger.debug("Cond NO  "+poMaster.getCondId());
				
				//}
				//poMaster.setCondRowId(saveDataService.getPoFiltersCount(httpSession.getAttribute("schemeName").toString())+1);
				//}
				poMaster.setValFlag("Y");
				poMaster.setUpdateDate(new Date());
				poMaster.setInsertDate(new Date());
				
				saveDataService.savePo(poMaster);
			
				if((poMaster.getLopr()==1) || (poMaster.getLopr()==2))
				{
					poMaster.setCondRowId(schemeInputDao.getPoFiltersRowCount(poMaster.getSchemeName(), poMaster.getCondId(),poMaster.getCompId())+1);
					SchemeInputAll schemeInput = new SchemeInputAll();
					
					
					
					if((poMaster.getrValueListName()!=null ) &&(poMaster.getrValueListName().length()!=0))
					{
						poMaster.setValue(poMaster.getrValueListName());
						
					}
					
					
					schemeInput.setSchemeInputPo(poMaster);
					schemeInputDao.savePayoutCondMasterRight(schemeInput);
					if((poMaster.getRlopr()!=1) && (poMaster.getRlopr()!=2))
						schemeInputDao.savePayoutCondAmtMaster(schemeInput);
				}
				
				data.put("success",Boolean.TRUE);
				data.put("poData",poMaster);
				data.put("errorMessage", "Congrats !!!! Form Submited Successfully");
		
				}
				catch(Exception e)
				{
					//logger.debug("ERRRRO"+e);
						logger.error("Configuration --> Create --> Payout Rules  :: DsmController : copyPo()  :: User Id = "+user.getUserName()+" Exception ::",e );
					
					data.put("success",Boolean.FALSE);
					e.printStackTrace();
					data.put("errorMessage",e.getMessage());
					
				}
				}
				else
				{
					data.put("success",Boolean.FALSE);
					data.put("errorMessage","No Scheme Found");
					
				}
			}
			
		}else{
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : addPo()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}


	@RequestMapping(value="copyPo.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO copyPo(@ModelAttribute SchemePoMaster poMaster,BindingResult result) throws IOException
	{
	
		ResponseVO respVo = new ResponseVO();	
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : copyPo()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if ((result.hasErrors()||(!(result.hasErrors())))) {
				if(httpSession.getAttribute("schemeName")!=null)
				{
				try
				{
					poMaster.setSchemeId(Integer.valueOf(httpSession.getAttribute("schemeId").toString()));
					//schemeInputDao.copyPo(poMaster);
				respVo.setSuccess(true);
				respVo.setMessage(schemeInputDao.copyPo(poMaster));	
				}
				catch(Exception e)
				{
						logger.error("Configuration --> Create --> Payout Rules  :: DsmController : copyPo()  :: User Id = "+user.getUserName() +" Exception :: ",e);
					
					respVo.setSuccess(false);
					//data.put("success",Boolean.FALSE);
					e.printStackTrace();
					respVo.setMessage(e.getMessage());
					//data.put("errorMessage",e.getMessage());
					
				}
				}
				else
				{
					
				}
				
			}
			
		}else{
			respVo.setSuccess(false);
		respVo.setMessage("You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : copyPo()  : End :: User Id = "+user.getUserName() );
		
		return respVo;
	}

	
	
	
	/*private File convert(MultipartFile file) throws IOException
	{    
	    File convFile = new File(file.getOriginalFilename());
	    convFile.createNewFile(); 
	    FileOutputStream fos = new FileOutputStream(convFile); 
	    fos.write(file.getBytes());
	    fos.close(); 
	    return convFile;
	}
	
	
	private boolean fileNameValidate(String fileName, int fileTypeId){
		boolean flag = false;
		switch (fileTypeId) {
		case 4:if(fileName != null && fileName.contains("ENTITY-LIST")){
			flag=true;
		}
		break;
		}
		return flag;
	}

*/


	@RequestMapping(value="/getCategory.action")
	public @ResponseBody Map<String,? extends Object> getCategory() throws Exception {
		Map<String,Object> modelMap = new HashMap<String,Object>(3);
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Component  :: DsmController : getCategory()  : Start :: User Id = "+user.getUserName() );
		
		try{
			CoverageOutput output=converageService.getConverageDetails();
			modelMap.put("data", output.getCategoryDet());
			if(logger.isDebugEnabled())
				logger.debug("Configuration --> Create --> Component  :: DsmController : getCategory()  : End :: User Id = "+user.getUserName() );
			
			return modelMap;
		} catch (Exception e) {
				logger.error("Configuration --> Create --> Component  :: DsmController : getCategory()  :: User Id = "+user.getUserName()+" Exception ::",e );
			
			e.printStackTrace();
			modelMap.put("success", false);
			return modelMap;
		}
	}

	
	@RequestMapping(value="insertNewRowPo.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> insertNewRowPo(@ModelAttribute("poForm") SchemePoMaster poMaster, BindingResult result, HttpSession session) throws Exception  {
	
		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowPo()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if ((result.hasErrors()||(!(result.hasErrors())))) {
				if(httpSession.getAttribute("schemeName")!=null)
				{
				try
				{
					if((poMaster.getValueListName()!=null ) &&(poMaster.getValueListName().length()!=0))
					{
						poMaster.setValue(poMaster.getValueListName());
					}
					
				poMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));
				poMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
				poMaster.setProcessType("G");
				poMaster.setReConfigId(1);
				poMaster.setInputType("0");
				poMaster.setValueType("0");
				poMaster.setAmount(new BigDecimal(0));
				poMaster.setCondRowId(schemeInputDao.getPoFiltersRowCount(poMaster.getSchemeName(), poMaster.getCondId(),poMaster.getCompId())+1);
				poMaster.setValFlag("Y");
				poMaster.setUpdateDate(new Date());
				poMaster.setInsertDate(new Date());
				
				saveDataService.savePo(poMaster);
			
				if((poMaster.getLopr()==1) || (poMaster.getLopr()==2))
				{
					poMaster.setCondRowId(schemeInputDao.getPoFiltersRowCount(poMaster.getSchemeName(), poMaster.getCondId(),poMaster.getCompId())+1);
					SchemeInputAll schemeInput = new SchemeInputAll();
				
					if((poMaster.getrValueListName()!=null ) &&(poMaster.getrValueListName().length()!=0))
					{
						poMaster.setValue(poMaster.getrValueListName());
					}
					
					schemeInput.setSchemeInputPo(poMaster);
					schemeInputDao.savePayoutCondMasterRight(schemeInput);

					if((poMaster.getRlopr()!=1) && (poMaster.getRlopr()!=2))
						schemeInputDao.savePayoutCondAmtMaster(schemeInput);
				}
				
				data.put("success",Boolean.TRUE);
				data.put("poData",poMaster);
				data.put("errorMessage", "Congrats !!!! Form Submited Successfully");
		
				}
				catch(Exception e)
				{
						logger.error("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowPo()  :: User Id = "+user.getUserName()+" Exception :: ",e );
					
					//logger.debug("ERRRRO"+e);
					data.put("success",Boolean.FALSE);
					e.printStackTrace();
					data.put("errorMessage",e.getMessage());
					
				}
				}
				else
				{
					data.put("success",Boolean.FALSE);
					data.put("errorMessage","No Scheme Found");
					
				}
			}
			
		}else{
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "You are not having this privilege access...");
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowPo()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}


	
//////new next	
	@SuppressWarnings("unused")
	@RequestMapping(value="insertNewRowNextPo.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> insertNewRowNextPo(@ModelAttribute("poForm") SchemePoMaster poMaster, BindingResult result, HttpSession session) throws Exception  {
	
		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowNextPo()  : Start :: User Id = "+user.getUserName() );
		
		String paramName = poMaster.getCompId()+","+poMaster.getCondId()+","+poMaster.getCondRowId();
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if ((result.hasErrors()||(!(result.hasErrors())))) {
				if(httpSession.getAttribute("schemeName")!=null)
				{
				try
				{
					
					
					if((poMaster.getValueListName()!=null ) &&(poMaster.getValueListName().length()!=0))
					{
						poMaster.setValue(poMaster.getValueListName());
					}
					
				String value = saveDataService.insertNewRowPo(poMaster, paramName)	;
				//if(value==null){
				poMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));
				poMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
				poMaster.setProcessType("G");
				poMaster.setReConfigId(1);
				poMaster.setInputType("0");
				poMaster.setValueType("0");
				poMaster.setAmount(new BigDecimal(0));
				poMaster.setCondRowId(poMaster.getCondRowId() + 1);
				//poMaster.setCondRowId(poMaster.getCondRowId() );
				poMaster.setValFlag("Y");
				poMaster.setUpdateDate(new Date());
				poMaster.setInsertDate(new Date());
				
				saveDataService.insertNewRowPo(poMaster);
			
/*				if((poMaster.getLopr()==1) || (poMaster.getLopr()==2))
				{
					poMaster.setCondRowId(schemeInputDao.getPoFiltersRowCount(poMaster.getSchemeName(), poMaster.getCondId(),poMaster.getCompId())+1);
					SchemeInputAll schemeInput = new SchemeInputAll();
				
					if((poMaster.getrValueListName()!=null ) &&(poMaster.getrValueListName().length()!=0))
					{
						poMaster.setValue(poMaster.getrValueListName());
					}
					
					schemeInput.setSchemeInputPo(poMaster);
					schemeInputDao.savePayoutCondMasterRight(schemeInput);

					if((poMaster.getRlopr()!=1) && (poMaster.getRlopr()!=2))
						schemeInputDao.savePayoutCondAmtMaster(schemeInput);
				}*/
				
				data.put("success",Boolean.TRUE);
				data.put("poData",poMaster);
				data.put("errorMessage", "Congrats !!!! Form Submited Successfully");
				}
			//	}
				catch(Exception e)
				{
					logger.error("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowNextPo()  :: User Id = "+user.getUserName() +" Exception :: ",e);
					data.put("success",Boolean.FALSE);
					e.printStackTrace();
					data.put("errorMessage",e.getMessage());
				}
				}
				else
				{
					data.put("success",Boolean.FALSE);
					data.put("errorMessage","No Scheme Found");
					
				}
			}
			
		}else{
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "You are not having this privilege access...");
	}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowNextPo()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}

	@SuppressWarnings("unused")
	@RequestMapping(value="insertNewEmptyRowPo.action", method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> insertNewRowPrevPo(@ModelAttribute("poForm") SchemePoMaster poMaster, BindingResult result, HttpSession session) throws Exception  {
	
		Map<String, Object> data = new HashMap<String, Object>();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowPrevPo()  : Start :: User Id = "+user.getUserName() );
		
		String paramName = poMaster.getCompId()+","+poMaster.getCondId()+","+poMaster.getCondRowId();
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			if ((result.hasErrors()||(!(result.hasErrors())))) {
				if(httpSession.getAttribute("schemeName")!=null)
				{
				try
				{
					
					if((poMaster.getValueListName()!=null ) &&(poMaster.getValueListName().length()!=0))
					{
						poMaster.setValue(poMaster.getValueListName());
					}
					
					logger.debug("poMaster.getInsertEmptyRowType()  =====>>>>>> "+poMaster.getInsertEmptyRowType());
					
					if(poMaster.getInsertEmptyRowType() != 0){
						String value = saveDataService.insertNewRowPo(poMaster, paramName)	;		
					}
				
				//if(value==null){
				poMaster.setCircleId((Integer)httpSession.getAttribute("circleId"));
				poMaster.setSchemeName(httpSession.getAttribute("schemeName").toString());
				poMaster.setProcessType("G");
				poMaster.setReConfigId(1);
				poMaster.setInputType("0");
				poMaster.setValueType("0");
				poMaster.setAmount(new BigDecimal(0));
				if(poMaster.getInsertEmptyRowType() == 0)
					poMaster.setCondRowId(schemeInputDao.getPoFiltersRowCount(poMaster.getSchemeName(), poMaster.getCondId(),poMaster.getCompId()) + 1);
				else if(poMaster.getInsertEmptyRowType() == 1)
					poMaster.setCondRowId(poMaster.getCondRowId() + 1 );
				else if(poMaster.getInsertEmptyRowType() == 2)
					poMaster.setCondRowId(poMaster.getCondRowId());
				poMaster.setValFlag("Y");
				poMaster.setUpdateDate(new Date());
				poMaster.setInsertDate(new Date());
				
				if(poMaster.getInsertEmptyRowType() == 0)
					saveDataService.savePo(poMaster);
				else
					saveDataService.insertNewRowPo(poMaster);
			
				if((poMaster.getLopr()==1) || (poMaster.getLopr()==2) && poMaster.getInsertEmptyRowType() == 0)
				{
					poMaster.setCondRowId(schemeInputDao.getPoFiltersRowCount(poMaster.getSchemeName(), poMaster.getCondId(),poMaster.getCompId())+1);
					SchemeInputAll schemeInput = new SchemeInputAll();
				
					if((poMaster.getrValueListName()!=null ) &&(poMaster.getrValueListName().length()!=0))
					{
						poMaster.setValue(poMaster.getrValueListName());
					}
					
					schemeInput.setSchemeInputPo(poMaster);
					schemeInputDao.savePayoutCondMasterRight(schemeInput);

					if((poMaster.getRlopr()!=1) && (poMaster.getRlopr()!=2))
						schemeInputDao.savePayoutCondAmtMaster(schemeInput);
				}
				
				data.put("success",Boolean.TRUE);
				data.put("poData",poMaster);
				data.put("errorMessage", "Congrats !!!! Form Submited Successfully");
				}
				catch(Exception e)
				{
						logger.error("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowPrevPo()   :: User Id = "+user.getUserName() +" Exception ::",e);
					
					data.put("success",Boolean.FALSE);
					e.printStackTrace();
					data.put("errorMessage",e.getMessage());
					
				}
				}
				else
				{
					data.put("success",Boolean.FALSE);
					data.put("errorMessage","No Scheme Found");
					
				}
			}
			
		}else{
		data.put("success",Boolean.FALSE);
		data.put("errorMessage", "You are not having this privilege access...");
	}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : insertNewRowPrevPo()  : End :: User Id = "+user.getUserName() );
		
		return data;
	}

	
	
	@RequestMapping(value="insertMultiRowPo.action", method=RequestMethod.POST)
	@ResponseBody
	public ResponseVO insertMultiRowPo(@ModelAttribute SchemePoMaster po) throws IOException
	{
		ResponseVO respVo = new ResponseVO();
		User user = (User)httpSession.getAttribute("appUser");
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : insertMultiRowPo()  : Start :: User Id = "+user.getUserName() );
		
		if(user != null && (user.getRoleId() == 1 || user.getRoleId() == 2 ))
		{
			try
			{
				int result = 	schemeInputDao.insertMultiRowPo(po.getValueListName());	
			if(result==1)
			{
				respVo.setSuccess(true);
				respVo.setMessage("Condition copied sucessfully");
			}
				else
				{	
					respVo.setSuccess(false);
					respVo.setMessage("Unable to perform copy operation. Please try again.");	
				}
			
			}catch(Exception e)
			{
					logger.error("Configuration --> Create --> Payout Rules  :: DsmController : insertMultiRowPo()  :: User Id = "+user.getUserName()+" Exception ::",e );
				
				respVo.setSuccess(false);
				respVo.setMessage(e.getMessage());		
			}
		}else{
		respVo.setSuccess(false);
		respVo.setMessage("You are not having this privilege access...");		
		}
		if(logger.isDebugEnabled())
			logger.debug("Configuration --> Create --> Payout Rules  :: DsmController : insertMultiRowPo()  : End :: User Id = "+user.getUserName() );
		
		return respVo;
	}
	
	
}

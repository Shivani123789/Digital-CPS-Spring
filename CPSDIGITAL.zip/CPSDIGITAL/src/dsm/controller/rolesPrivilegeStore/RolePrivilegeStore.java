package dsm.controller.rolesPrivilegeStore;

//import java.util.HashMap;
//import java.util.List;
import java.util.Map;
import java.util.Set;
//import java.util.SortedSet;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import dsm.model.user.User;

@Controller
@Scope("session")
@RequestMapping(value="/menu")
public class RolePrivilegeStore {

	@Autowired
	private HttpSession httpSession;
	
	private static Logger logger = Logger.getLogger (RolePrivilegeStore.class);
	
	@RequestMapping(value="getUserMenuDetails.action",method=RequestMethod.GET)
	public @ResponseBody  String  getUserDetails() throws Exception {
	
		try{
		User user = (User)httpSession.getAttribute("appUser");
		String data = generateJSON(user);
		return data;
	} catch (Exception e) {
		e.printStackTrace();
	}
	return null;
	}
	
	private String generateJSON(User user){
		StringBuffer sb = new StringBuffer();
		Map<String,Set<String>> menuItems=user.getUserPrivileges();
		logger.debug("name:"+user.getUserName()+" cid:"+user.getCircleId()+" cirName:"+user.getCircleName()+" circode:"+user.getUserCircleCode()+" priv:"+user.getUserPrivilege()+" roles:"+user.getUserRole());
		
	/*	if(user.getUserPrivileges()!=null){
			Map<String,Set<String>> map=user.getUserPrivileges();
			for (Map.Entry<String, Set<String>> entry : map.entrySet()) {
				String key = entry.getKey();
				SortedSet<String> values = (SortedSet)entry.getValue();
				logger.debug("Key = " + key);
				for(String val:values)
				logger.debug("Values = " + val + "n");
				
			}
		}
	*///Menu and MenuItems 
		boolean flag =false;
		sb.append("{").append("text : '.' ,").append(" children: [");
		for (Map.Entry<String, Set<String>> entry : menuItems.entrySet()) {
			if(flag)
				sb.append(",");
			sb.append("{text:'"+entry.getKey()+"',  expanded: false, children:[");	
			Set<String> values = entry.getValue();
			int i=0;
			for(String subMenu : values){
				i++;
				sb.append("{text:'"+subMenu+"',").append("id:'"+subToIdGenerate(subMenu)+"', leaf:true }");
				if(values.size()!=i){
					sb.append(",");
				}
			}flag =true;
			sb.append("]}");
		}
		sb.append("]} ");
	logger.debug("RolePrivilegeStore || END :"+sb);
		return sb.toString();
	}
	
	
	private String subToIdGenerate(String subMenu){
		return subMenu.replaceAll(" ", "-");
	}
}

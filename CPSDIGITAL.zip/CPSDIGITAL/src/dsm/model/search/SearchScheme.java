package dsm.model.search;

import java.math.BigDecimal;


public class SearchScheme {

	private String changeDesc;
	private String startDate;
	private String endDate;
	private int limit;
	private int payTo;
	private int schemeId;
	private int totalCount;
	private int compId;
	private int page;
	private int start;
	private String condParam;
	private String isStage;
	private String isMaster;
	private int circleId;
	private int filterBy;
	private String paymentType;
	private String paymentRemarks;
	private String schemeComp;
	private String userId;
	private String startEndDt;
	private String msisdn;
	private String componentName;
	private String fileName;
	private String payToStr;
	private String circleCode;
	private String stmtCycleId;
	
	private BigDecimal totalAmt;
	private BigDecimal holdAmt;
	private String releaseType;
	private String distId;
	
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getFilterBy() {
		return filterBy;
	}
	public void setFilterBy(int filterBy) {
		this.filterBy = filterBy;
	}
	public String getCondParam() {
		return condParam;
	}
	public void setCondParam(String condParam) {
		this.condParam = condParam;
	}
	public String isStage() {
		return isStage;
	}
	public void setStage(String isStage) {
		this.isStage = isStage;
	}
	public String isMaster() {
		return isMaster;
	}
	public void setMaster(String isMaster) {
		this.isMaster = isMaster;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public int getPayTo() {
		return payTo;
	}
	public void setPayTo(int payTo) {
		this.payTo = payTo;
	}
	public String getSchemeComp() {
		return schemeComp;
	}
	public void setSchemeComp(String schemeComp) {
		this.schemeComp = schemeComp;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPaymentRemarks() {
		return paymentRemarks;
	}
	public void setPaymentRemarks(String paymentRemarks) {
		this.paymentRemarks = paymentRemarks;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public String getChangeDesc() {
		return changeDesc;
	}
	public void setChangeDesc(String changeDesc) {
		this.changeDesc = changeDesc;
	}
	public String getStartEndDt() {
		return startEndDt;
	}
	public void setStartEndDt(String startEndDt) {
		this.startEndDt = startEndDt;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getPayToStr() {
		return payToStr;
	}
	public void setPayToStr(String payToStr) {
		this.payToStr = payToStr;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public BigDecimal getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(BigDecimal totalAmt) {
		this.totalAmt = totalAmt;
	}
	public BigDecimal getHoldAmt() {
		return holdAmt;
	}
	public void setHoldAmt(BigDecimal holdAmt) {
		this.holdAmt = holdAmt;
	}
	public String getReleaseType() {
		return releaseType;
	}
	public void setReleaseType(String releaseType) {
		this.releaseType = releaseType;
	}
	public String getDistId() {
		return distId;
	}
	public void setDistId(String distId) {
		this.distId = distId;
	}
	public String getStmtCycleId() {
		return stmtCycleId;
	}
	public void setStmtCycleId(String stmtCycleId) {
		this.stmtCycleId = stmtCycleId;
	}
	
	
}

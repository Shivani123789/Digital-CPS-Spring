package dsm.model.ea;

public class SchemeComponentEQModel {

	private int scmCompId;
	
	private String scmCompName;

	public String getScmCompName() {
		return scmCompName;
	}

	public void setScmCompName(String scmCompName) {
		this.scmCompName = scmCompName;
	}

	public int getScmCompId() {
		return scmCompId;
	}

	public void setScmCompId(int scmCompId) {
		this.scmCompId = scmCompId;
	}
}

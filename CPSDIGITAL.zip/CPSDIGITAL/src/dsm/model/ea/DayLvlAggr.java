package dsm.model.ea;

public class DayLvlAggr {

	private int dayLvlAggrId;
	private int circleId;
	private int universeId;
	private String dayLvlAggrFieldName;
	private String dayLvlAggrDisplayName;
	private String validityFlag;
	
	public long getDayLvlAggrId() {
		return dayLvlAggrId;
	}
	public void setDayLvlAggrId(int dayLvlAggrId) {
		this.dayLvlAggrId = dayLvlAggrId;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public int getUniverseId() {
		return universeId;
	}
	public void setUniverseId(int universeId) {
		this.universeId = universeId;
	}
	public String getDayLvlAggrFieldName() {
		return dayLvlAggrFieldName;
	}
	public void setDayLvlAggrFieldName(String dayLvlAggrFieldName) {
		this.dayLvlAggrFieldName = dayLvlAggrFieldName;
	}
	public String getDayLvlAggrDisplayName() {
		return dayLvlAggrDisplayName;
	}
	public void setDayLvlAggrDisplayName(String dayLvlAggrDisplayName) {
		this.dayLvlAggrDisplayName = dayLvlAggrDisplayName;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}

	
}

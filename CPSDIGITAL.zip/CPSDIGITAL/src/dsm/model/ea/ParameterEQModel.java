package dsm.model.ea;

public class ParameterEQModel {

	private int paramId;
	private String paramName;
	private String valFlag;
	private String oprDataType;
	private int attrType;
	private int attrCatg;
	private int unverseId;
	public int getParamId() {
		return paramId;
	}
	public void setParamId(int paramId) {
		this.paramId = paramId;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public String getOprDataType() {
		return oprDataType;
	}
	public void setOprDataType(String oprDataType) {
		this.oprDataType = oprDataType;
	}
	public int getUnverseId() {
		return unverseId;
	}
	public void setUnverseId(int unverseId) {
		this.unverseId = unverseId;
	}
	public int getAttrType() {
		return attrType;
	}
	public void setAttrType(int attrType) {
		this.attrType = attrType;
	}
	public int getAttrCatg() {
		return attrCatg;
	}
	public void setAttrCatg(int attrCatg) {
		this.attrCatg = attrCatg;
	}
}

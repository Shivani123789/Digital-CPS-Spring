package dsm.model.ea;

public class ValueTypeEQModel {

	private int valueTypeId;
	private String valueTypeName;
	private String varFlag;
	private String conFlag;
	public int getValueTypeId() {
		return valueTypeId;
	}
	public void setValueTypeId(int valueTypeId) {
		this.valueTypeId = valueTypeId;
	}
	public String getValueTypeName() {
		return valueTypeName;
	}
	public void setValueTypeName(String valueTypeName) {
		this.valueTypeName = valueTypeName;
	}
	public String getVarFlag() {
		return varFlag;
	}
	public void setVarFlag(String varFlag) {
		this.varFlag = varFlag;
	}
	public String getConFlag() {
		return conFlag;
	}
	public void setConFlag(String conFlag) {
		this.conFlag = conFlag;
	}
}

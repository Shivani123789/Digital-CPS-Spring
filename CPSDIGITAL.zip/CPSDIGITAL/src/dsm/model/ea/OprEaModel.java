package dsm.model.ea;

public class OprEaModel {

	
	private String oprType;
	private int oprId;
	private String oprName;
	private String valFlagvar;
	private String valFlagcon;
	private String numberFlag;
	private String stringFlag;
	private String dataFlag;
	public int getOprId() {
		return oprId;
	}
	public void setOprId(int oprId) {
		this.oprId = oprId;
	}
	public String getOprName() {
		return oprName;
	}
	public void setOprName(String oprName) {
		this.oprName = oprName;
	}
	public String getOprType() {
		return oprType;
	}
	public void setOprType(String oprType) {
		this.oprType = oprType;
	}
	
	public String getValFlagvar() {
		return valFlagvar;
	}
	public void setValFlagvar(String valFlagvar) {
		this.valFlagvar = valFlagvar;
	}
	public String getValFlagcon() {
		return valFlagcon;
	}
	public void setValFlagcon(String valFlagcon) {
		this.valFlagcon = valFlagcon;
	}
	public String getDataFlag() {
		return dataFlag;
	}
	public void setDataFlag(String dataFlag) {
		this.dataFlag = dataFlag;
	}
	public String getStringFlag() {
		return stringFlag;
	}
	public void setStringFlag(String stringFlag) {
		this.stringFlag = stringFlag;
	}
	public String getNumberFlag() {
		return numberFlag;
	}
	public void setNumberFlag(String numberFlag) {
		this.numberFlag = numberFlag;
	}
	
}

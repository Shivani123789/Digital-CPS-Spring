package dsm.model.ea;

public class DataSourceEQModel {

	private int dataSourceId;
	private String dataSourceName;
	private int compId;
	private String valFlag;
	
	public int getDataSourceId() {
		return dataSourceId;
	}
	public void setDataSourceId(int dataSourceId) {
		this.dataSourceId = dataSourceId;
	}
	public String getDataSourceName() {
		return dataSourceName;
	}
	public void setDataSourceName(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
}

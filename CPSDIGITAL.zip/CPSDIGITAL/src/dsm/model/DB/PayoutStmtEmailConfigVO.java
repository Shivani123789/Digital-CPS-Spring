package dsm.model.DB;

import java.util.Date;

public class PayoutStmtEmailConfigVO {

	private int stmtEid;
	private String distDsm2Id;
	private String circleCode;
	private String distMsisdn;
	private Date stmtDate;
	private String emailSubject;
	private String emailContent;
	private String sender;
	private String recipients;
	private String ccRecipients;
	private String attachmentFlag;
	private String attachmentPath;
	private String sendStatus;
	private String sendDateTime;
	private String validityFlag;
	private Date updateDateTime;
	private Date insertDateTime;
	private String responseStatus;
	private String errorDesc;
	
	public int getStmtEid() {
		return stmtEid;
	}
	public void setStmtEid(int stmtEid) {
		this.stmtEid = stmtEid;
	}
	public String getDistDsm2Id() {
		return distDsm2Id;
	}
	public void setDistDsm2Id(String distDsm2Id) {
		this.distDsm2Id = distDsm2Id;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public String getDistMsisdn() {
		return distMsisdn;
	}
	public void setDistMsisdn(String distMsisdn) {
		this.distMsisdn = distMsisdn;
	}
	public Date getStmtDate() {
		return stmtDate;
	}
	public void setStmtDate(Date stmtDate) {
		this.stmtDate = stmtDate;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public String getEmailContent() {
		return emailContent;
	}
	public void setEmailContent(String emailContent) {
		this.emailContent = emailContent;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getRecipients() {
		return recipients;
	}
	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}
	public String getCcRecipients() {
		return ccRecipients;
	}
	public void setCcRecipients(String ccRecipients) {
		this.ccRecipients = ccRecipients;
	}
	public String getAttachmentFlag() {
		return attachmentFlag;
	}
	public void setAttachmentFlag(String attachmentFlag) {
		this.attachmentFlag = attachmentFlag;
	}
	public String getAttachmentPath() {
		return attachmentPath;
	}
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}
	public String getSendStatus() {
		return sendStatus;
	}
	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}
	public String getSendDateTime() {
		return sendDateTime;
	}
	public void setSendDateTime(String sendDateTime) {
		this.sendDateTime = sendDateTime;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public Date getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	public Date getInsertDateTime() {
		return insertDateTime;
	}
	public void setInsertDateTime(Date insertDateTime) {
		this.insertDateTime = insertDateTime;
	}
	public String getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	
	
}

package dsm.model.DB;

import java.util.LinkedList;
import java.util.List;

public class CompListContainer {

	private List<CompMaster> compList = new LinkedList<CompMaster>();
	//private List<RegZoneMaster> regList = new LinkedList<RegZoneMaster>();
	public List<CompMaster> getCompList() {
		return compList;
	}

	public void setCompList(List<CompMaster> compList) {
		this.compList = compList;
	}
	
}

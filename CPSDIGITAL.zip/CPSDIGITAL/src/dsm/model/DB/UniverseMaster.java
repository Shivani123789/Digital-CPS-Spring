package dsm.model.DB;

public class UniverseMaster {

	private int universeId;
	private String universeName;
	private String universeTablePrefix;
	private String validityFlag;
	
	public int getUniverseId() {
		return universeId;
	}
	public void setUniverseId(int universeId) {
		this.universeId = universeId;
	}
	public String getUniverseName() {
		return universeName;
	}
	public void setUniverseName(String universeName) {
		this.universeName = universeName;
	}
	public String getUniverseTablePrefix() {
		return universeTablePrefix;
	}
	public void setUniverseTablePrefix(String universeTablePrefix) {
		this.universeTablePrefix = universeTablePrefix;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	
	
}

package dsm.model.DB;

import java.util.Date;

public class SchemeTqMaster {

	//DLP_SCM_TQ_COND_CONFIG
	
	private String processType;
	private int schemeId;
	private int circleId;
	private String schemeName;
	private int compId;
	private String compName;
	private int reConfigId;
	private int groupId;
	private int condId;
	private String condName;
	private int condRowId;
	private int dataSet;
	private String dataSetName;
	private int perfParmeter;
	private String perfParamName;
	private int opr;
	private String oprName;
	private int valueType;
	private String valueTypeName;
	private String value;
	private String ValueListName;
	private String LvalueListName;
	private Date startDate;
	private Date endDate;
	private int Lopr;
	private String loprName;
	private int lPrefparameter;
	private String lperfParamName;
	private int lOpr;
private String condition;
	
	private long headCount;
	private float grossnet;
	private float maxAmt;
	private float minAmt;
	private float avgAmt;
	
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public long getHeadCount() {
		return headCount;
	}
	public void setHeadCount(long headCount) {
		this.headCount = headCount;
	}
	public float getGrossnet() {
		return grossnet;
	}
	public void setGrossnet(float grossnet) {
		this.grossnet = grossnet;
	}
	public float getMaxAmt() {
		return maxAmt;
	}
	public void setMaxAmt(float maxAmt) {
		this.maxAmt = maxAmt;
	}
	public float getMinAmt() {
		return minAmt;
	}
	public void setMinAmt(float minAmt) {
		this.minAmt = minAmt;
	}
	public float getAvgAmt() {
		return avgAmt;
	}
	public void setAvgAmt(float avgAmt) {
		this.avgAmt = avgAmt;
	}
	public String getDataSetName() {
		return dataSetName;
	}
	public void setDataSetName(String dataSetName) {
		this.dataSetName = dataSetName;
	}
	public String getPerfParamName() {
		return perfParamName;
	}
	public void setPerfParamName(String perfParamName) {
		this.perfParamName = perfParamName;
	}
	public String getOprName() {
		return oprName;
	}
	public void setOprName(String oprName) {
		this.oprName = oprName;
	}
	public String getValueTypeName() {
		return valueTypeName;
	}
	public void setValueTypeName(String valueTypeName) {
		this.valueTypeName = valueTypeName;
	}
	public String getLperfParamName() {
		return lperfParamName;
	}
	public void setLperfParamName(String lperfParamName) {
		this.lperfParamName = lperfParamName;
	}
	public String getL_loprName() {
		return l_loprName;
	}
	public void setL_loprName(String l_loprName) {
		this.l_loprName = l_loprName;
	}
	private String l_loprName;
	private int lValueType;
	private String lvalueTypeName;
	private String lValue;
	private Date lStartDate;
	private Date lEndDate;
	private int lRopr;
	private String roprName;
	private String valFlag;
	private Date updateDate;
	private Date insertDate;
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getReConfigId() {
		return reConfigId;
	}
	public void setReConfigId(int reConfigId) {
		this.reConfigId = reConfigId;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public int getCondId() {
		return condId;
	}
	public void setCondId(int condId) {
		this.condId = condId;
	}
	public String getCondName() {
		return condName;
	}
	public void setCondName(String condName) {
		this.condName = condName;
	}
	public int getCondRowId() {
		return condRowId;
	}
	public void setCondRowId(int condRowId) {
		this.condRowId = condRowId;
	}
	public int getDataSet() {
		return dataSet;
	}
	public void setDataSet(int dataSet) {
		this.dataSet = dataSet;
	}
	public int getPerfParmeter() {
		return perfParmeter;
	}
	public void setPerfParmeter(int perfParmeter) {
		this.perfParmeter = perfParmeter;
	}
	public int getOpr() {
		return opr;
	}
	public void setOpr(int opr) {
		this.opr = opr;
	}
	public int getValueType() {
		return valueType;
	}
	public void setValueType(int valueType) {
		this.valueType = valueType;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getLopr() {
		return Lopr;
	}
	public void setLopr(int lopr) {
		this.Lopr = lopr;
	}
	public int getlPrefparameter() {
		return lPrefparameter;
	}
	public void setlPrefparameter(int lPrefparameter) {
		this.lPrefparameter = lPrefparameter;
	}
	public int getlOpr() {
		return lOpr;
	}
	public void setlOpr(int lOpr) {
		this.lOpr = lOpr;
	}
	public int getlValueType() {
		return lValueType;
	}
	public void setlValueType(int lValueType) {
		this.lValueType = lValueType;
	}
	public String getlValue() {
		return lValue;
	}
	public void setlValue(String lValue) {
		this.lValue = lValue;
	}
	public Date getlStartDate() {
		return lStartDate;
	}
	public void setlStartDate(Date lStartDate) {
		this.lStartDate = lStartDate;
	}
	public Date getlEndDate() {
		return lEndDate;
	}
	public void setlEndDate(Date lEndDate) {
		this.lEndDate = lEndDate;
	}
	public int getlRopr() {
		return lRopr;
	}
	public void setlRopr(int lRopr) {
		this.lRopr = lRopr;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getLoprName() {
		return loprName;
	}
	public void setLoprName(String loprName) {
		this.loprName = loprName;
	}
	public String getRoprName() {
		return roprName;
	}
	public void setRoprName(String roprName) {
		this.roprName = roprName;
	}
	public String getLvalueTypeName() {
		return lvalueTypeName;
	}
	public void setLvalueTypeName(String lvalueTypeName) {
		this.lvalueTypeName = lvalueTypeName;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getValueListName() {
		return ValueListName;
	}
	public void setValueListName(String valueListName) {
		ValueListName = valueListName;
	}
	public String getLvalueListName() {
		return LvalueListName;
	}
	public void setLvalueListName(String lvalueListName) {
		LvalueListName = lvalueListName;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	
	
}

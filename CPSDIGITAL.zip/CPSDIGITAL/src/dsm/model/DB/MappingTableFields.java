package dsm.model.DB;

import java.util.List;
import java.util.Map;

public class MappingTableFields extends ExceptionVo  {
	
	private String fileHeaderNames;
	private int fieldCount;
	private int fileHeaderCount;
	private String mandatoryColumns;
	
	private Map<String,String> fieldNames;
	private Map<String,String> mandatoryFieldNames;
	private int mandatoryFieldCount;
	private List<String> destTabColumns;
	
	private String fieldName;
	private String displayName;
	private String type;
	private String tableName;
	private String columnName;
	
	public int getFieldCount() {
		return fieldCount;
	}
	public void setFieldCount(int fieldCount) {
		this.fieldCount = fieldCount;
	}
	public Map<String,String> getFieldNames() {
		return fieldNames;
	}
	public void setFieldNames(Map<String,String> fieldNames) {
		this.fieldNames = fieldNames;
	}
	public String getFileHeaderNames() {
		return fileHeaderNames;
	}
	public void setFileHeaderNames(String fileHeaderNames) {
		this.fileHeaderNames = fileHeaderNames;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public int getFileHeaderCount() {
		return fileHeaderCount;
	}
	public void setFileHeaderCount(int fileHeaderCount) {
		this.fileHeaderCount = fileHeaderCount;
	}
	public String getMandatoryColumns() {
		return mandatoryColumns;
	}
	public void setMandatoryColumns(String mandatoryColumns) {
		this.mandatoryColumns = mandatoryColumns;
	}
	public Map<String,String> getMandatoryFieldNames() {
		return mandatoryFieldNames;
	}
	public void setMandatoryFieldNames(Map<String,String> mandatoryFieldNames) {
		this.mandatoryFieldNames = mandatoryFieldNames;
	}
	public int getMandatoryFieldCount() {
		return mandatoryFieldCount;
	}
	public void setMandatoryFieldCount(int mandatoryFieldCount) {
		this.mandatoryFieldCount = mandatoryFieldCount;
	}
	public List<String> getDestTabColumns() {
		return destTabColumns;
	}
	public void setDestTabColumns(List<String> destTabColumns) {
		this.destTabColumns = destTabColumns;
	}

}

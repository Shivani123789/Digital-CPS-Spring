package dsm.model.DB;

import java.math.BigDecimal;
import java.util.List;

public class DistributorStatementPojo {

	private int stmtCycleId;
	private int distStmtId;
	private String month;
	private String date;
	private String distDsm2Id;
	private String distName;
	private String distMobile;
	private String distPanNo;
	private String distEmail;
	private String distZone;
	private String circle;
	private int scmListId;
	private BigDecimal normalGross;
	private BigDecimal mnpGross;
	private BigDecimal flexi;
	private BigDecimal paper;
	private BigDecimal targetMnp;
	private BigDecimal targetNmnp;
	private BigDecimal targetTotal;
	private BigDecimal totalFexiPaper;
	private BigDecimal achiveMnp;
	private BigDecimal achiveNmnp;
	private BigDecimal achiveTotal;
	//private String distInvoiceLink;
	private String insertDateTime;
	private String payoutGross;
	private BigDecimal totalTds;
	private BigDecimal totalNet;
	private BigDecimal retPayoutGross;
	private BigDecimal retTotalTds;
	private double retTotalNet;
	private BigDecimal grossAct;
	//private BigDecimal totalNos;
	//private BigDecimal totalRate;
	//private BigDecimal totalRetNos;
	//private BigDecimal totalRetRate;
	private String stmtCycleDt;
	private String paymentDt;
	private String arCode;
	private String firstName;
	private String lastName;
	
	private List<DistributorStmtSchmPojo> distStmtSchmList;
	private List<DistributorRetSchmPojo> distRetSchmList;

	private int totalCount;
	
	public int getStmtCycleId() {
		return stmtCycleId;
	}

	public void setStmtCycleId(int stmtCycleId) {
		this.stmtCycleId = stmtCycleId;
	}

	public int getDistStmtId() {
		return distStmtId;
	}

	public void setDistStmtId(int distStmtId) {
		this.distStmtId = distStmtId;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getDistDsm2Id() {
		return distDsm2Id;
	}

	public void setDistDsm2Id(String distDsm2Id) {
		this.distDsm2Id = distDsm2Id;
	}

	public String getDistName() {
		return distName;
	}

	public void setDistName(String distName) {
		this.distName = distName;
	}

	public String getDistMobile() {
		return distMobile;
	}

	public void setDistMobile(String distMobile) {
		this.distMobile = distMobile;
	}

	public String getDistPanNo() {
		return distPanNo;
	}

	public void setDistPanNo(String distPanNo) {
		this.distPanNo = distPanNo;
	}

	public String getDistEmail() {
		return distEmail;
	}

	public void setDistEmail(String distEmail) {
		this.distEmail = distEmail;
	}

	public String getDistZone() {
		return distZone;
	}

	public void setDistZone(String distZone) {
		this.distZone = distZone;
	}

	public String getCircle() {
		return circle;
	}

	public void setCircle(String circle) {
		this.circle = circle;
	}

	public int getScmListId() {
		return scmListId;
	}

	public void setScmListId(int scmListId) {
		this.scmListId = scmListId;
	}

	public BigDecimal getNormalGross() {
		return normalGross;
	}

	public void setNormalGross(BigDecimal normalGross) {
		this.normalGross = normalGross;
	}

	public BigDecimal getMnpGross() {
		return mnpGross;
	}

	public void setMnpGross(BigDecimal mnpGross) {
		this.mnpGross = mnpGross;
	}

	public BigDecimal getFlexi() {
		return flexi;
	}

	public void setFlexi(BigDecimal flexi) {
		this.flexi = flexi;
	}

	public BigDecimal getPaper() {
		return paper;
	}

	public void setPaper(BigDecimal paper) {
		this.paper = paper;
	}

	public BigDecimal getTargetMnp() {
		return targetMnp;
	}

	public void setTargetMnp(BigDecimal targetMnp) {
		this.targetMnp = targetMnp;
	}

	public BigDecimal getTargetNmnp() {
		return targetNmnp;
	}

	public void setTargetNmnp(BigDecimal targetNmnp) {
		this.targetNmnp = targetNmnp;
	}

	public BigDecimal getTargetTotal() {
		return targetTotal;
	}

	public void setTargetTotal(BigDecimal targetTotal) {
		this.targetTotal = targetTotal;
	}

	public BigDecimal getTotalFexiPaper() {
		return totalFexiPaper;
	}

	public void setTotalFexiPaper(BigDecimal totalFexiPaper) {
		this.totalFexiPaper = totalFexiPaper;
	}

	public BigDecimal getAchiveMnp() {
		return achiveMnp;
	}

	public void setAchiveMnp(BigDecimal achiveMnp) {
		this.achiveMnp = achiveMnp;
	}

	public BigDecimal getAchiveNmnp() {
		return achiveNmnp;
	}

	public void setAchiveNmnp(BigDecimal achiveNmnp) {
		this.achiveNmnp = achiveNmnp;
	}

	public BigDecimal getAchiveTotal() {
		return achiveTotal;
	}

	public void setAchiveTotal(BigDecimal achiveTotal) {
		this.achiveTotal = achiveTotal;
	}

	/*public String getDistInvoiceLink() {
		return distInvoiceLink;
	}

	public void setDistInvoiceLink(String distInvoiceLink) {
		this.distInvoiceLink = distInvoiceLink;
	}*/

	public String getInsertDateTime() {
		return insertDateTime;
	}

	public void setInsertDateTime(String insertDateTime) {
		this.insertDateTime = insertDateTime;
	}

	public String getPayoutGross() {
		return payoutGross;
	}

	public void setPayoutGross(String payoutGross) {
		this.payoutGross = payoutGross;
	}

	public BigDecimal getTotalTds() {
		return totalTds;
	}

	public void setTotalTds(BigDecimal totalTds) {
		this.totalTds = totalTds;
	}

	public BigDecimal getTotalNet() {
		return totalNet;
	}

	public void setTotalNet(BigDecimal totalNet) {
		this.totalNet = totalNet;
	}

	public BigDecimal getRetPayoutGross() {
		return retPayoutGross;
	}

	public void setRetPayoutGross(BigDecimal retPayoutGross) {
		this.retPayoutGross = retPayoutGross;
	}

	public BigDecimal getRetTotalTds() {
		return retTotalTds;
	}

	public void setRetTotalTds(BigDecimal retTotalTds) {
		this.retTotalTds = retTotalTds;
	}

	public double getRetTotalNet() {
		return retTotalNet;
	}

	public void setRetTotalNet(double retTotalNet) {
		this.retTotalNet = retTotalNet;
	}

	public BigDecimal getGrossAct() {
		return grossAct;
	}

	public void setGrossAct(BigDecimal grossAct) {
		this.grossAct = grossAct;
	}

	public List<DistributorStmtSchmPojo> getDistStmtSchmList() {
		return distStmtSchmList;
	}

	public void setDistStmtSchmList(
			List<DistributorStmtSchmPojo> distStmtSchmList) {
		this.distStmtSchmList = distStmtSchmList;
	}

	public List<DistributorRetSchmPojo> getDistRetSchmList() {
		return distRetSchmList;
	}

	public void setDistRetSchmList(List<DistributorRetSchmPojo> distRetSchmList) {
		this.distRetSchmList = distRetSchmList;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	/*public BigDecimal getTotalNos() {
		return totalNos;
	}

	public void setTotalNos(BigDecimal totalNos) {
		this.totalNos = totalNos;
	}

	public BigDecimal getTotalRate() {
		return totalRate;
	}

	public void setTotalRate(BigDecimal totalRate) {
		this.totalRate = totalRate;
	}

	public BigDecimal getTotalRetNos() {
		return totalRetNos;
	}

	public void setTotalRetNos(BigDecimal totalRetNos) {
		this.totalRetNos = totalRetNos;
	}

	public BigDecimal getTotalRetRate() {
		return totalRetRate;
	}

	public void setTotalRetRate(BigDecimal totalRetRate) {
		this.totalRetRate = totalRetRate;
	}
*/
	public String getStmtCycleDt() {
		return stmtCycleDt;
	}

	public void setStmtCycleDt(String stmtCycleDt) {
		this.stmtCycleDt = stmtCycleDt;
	}

	public String getPaymentDt() {
		return paymentDt;
	}

	public void setPaymentDt(String paymentDt) {
		this.paymentDt = paymentDt;
	}

	public String getArCode() {
		return arCode;
	}

	public void setArCode(String arCode) {
		this.arCode = arCode;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

}
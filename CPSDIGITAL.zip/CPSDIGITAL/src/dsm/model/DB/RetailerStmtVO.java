package dsm.model.DB;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

public class RetailerStmtVO {
	
	private int stmtCycleId;
	private int retailerStmtId;
	private String stmtMonth;
	private Date stmtDt;
	private String retailerDsm2Id;
	private String retailerFirmName; 
	private String retailerMsisdn; 
	private String retailerAddress; 
	private String retailerZone; 
	private String distributorName; 
	private String distributorDsm2Id; 
	private String tsm; 
	private String asm; 
	private String zbm; 
	private String tsmId; 
	private String asmId; 
	private String zbmId; 
	private String tsmMsisdn; 
	private String asmMsisdn; 
	private String zbmMsisdn; 
	private String circleCode;
	private int scmListId;        
	private int normalGross;        
	private int mnpGross;        
	private BigDecimal totalNet;        
	//private String retailerInvoiceLink; 
	//private String retailerOwnName; 
	private int grossAct;      
	private BigDecimal payoutGross;
	//private BigDecimal totalNos;
	private BigDecimal totalTds;
	//private BigDecimal totalRate;
	private BigDecimal targetGrAddMnp;
	private BigDecimal targetGrAddNmnp;
	private BigDecimal targetGrAddTotal;
	private BigDecimal achievementPercMnp;
	private BigDecimal achievementPercNmnp;
	private BigDecimal achievementPercTotal;
	private String paymentDt;
	
	private List<RetailerStmtScmList> retailerSubList;
	
	public BigDecimal getPayoutGross() {
		return payoutGross;
	}
	public void setPayoutGross(BigDecimal payoutGross) {
		this.payoutGross = payoutGross;
	}
	/*public BigDecimal getTotalNos() {
		return totalNos;
	}
	public void setTotalNos(BigDecimal totalNos) {
		this.totalNos = totalNos;
	}*/
	public BigDecimal getTotalTds() {
		return totalTds;
	}
	public void setTotalTds(BigDecimal totalTds) {
		this.totalTds = totalTds;
	}
	/*public BigDecimal getTotalRate() {
		return totalRate;
	}
	public void setTotalRate(BigDecimal totalRate) {
		this.totalRate = totalRate;
	}*/
	public BigDecimal getTargetGrAddMnp() {
		return targetGrAddMnp;
	}
	public void setTargetGrAddMnp(BigDecimal targetGrAddMnp) {
		this.targetGrAddMnp = targetGrAddMnp;
	}
	public BigDecimal getTargetGrAddNmnp() {
		return targetGrAddNmnp;
	}
	public void setTargetGrAddNmnp(BigDecimal targetGrAddNmnp) {
		this.targetGrAddNmnp = targetGrAddNmnp;
	}
	public BigDecimal getTargetGrAddTotal() {
		return targetGrAddTotal;
	}
	public void setTargetGrAddTotal(BigDecimal targetGrAddTotal) {
		this.targetGrAddTotal = targetGrAddTotal;
	}
	public BigDecimal getAchievementPercMnp() {
		return achievementPercMnp;
	}
	public void setAchievementPercMnp(BigDecimal achievementPercMnp) {
		this.achievementPercMnp = achievementPercMnp;
	}
	public BigDecimal getAchievementPercNmnp() {
		return achievementPercNmnp;
	}
	public void setAchievementPercNmnp(BigDecimal achievementPercNmnp) {
		this.achievementPercNmnp = achievementPercNmnp;
	}
	public BigDecimal getAchievementPercTotal() {
		return achievementPercTotal;
	}
	public void setAchievementPercTotal(BigDecimal achievementPercTotal) {
		this.achievementPercTotal = achievementPercTotal;
	}
	private Map<String,List<RetailerStmtScmList>> retailerSubMap;
	
	
	public List<RetailerStmtScmList> getRetailerSubList() {
		return retailerSubList;
	}
	public void setRetailerSubList(List<RetailerStmtScmList> retailerSubList) {
		this.retailerSubList = retailerSubList;
	}
	public int getStmtCycleId() {
		return stmtCycleId;
	}
	public void setStmtCycleId(int stmtCycleId) {
		this.stmtCycleId = stmtCycleId;
	}
	public int getRetailerStmtId() {
		return retailerStmtId;
	}
	public void setRetailerStmtId(int retailerStmtId) {
		this.retailerStmtId = retailerStmtId;
	}
	public String getStmtMonth() {
		return stmtMonth;
	}
	public void setStmtMonth(String stmtMonth) {
		this.stmtMonth = stmtMonth;
	}
	public Date getStmtDt() {
		return stmtDt;
	}
	public void setStmtDt(Date stmtDt) {
		this.stmtDt = stmtDt;
	}
	public String getRetailerDsm2Id() {
		return retailerDsm2Id;
	}
	public void setRetailerDsm2Id(String retailerDsm2Id) {
		this.retailerDsm2Id = retailerDsm2Id;
	}
	public String getRetailerFirmName() {
		return retailerFirmName;
	}
	public void setRetailerFirmName(String retailerFirmName) {
		this.retailerFirmName = retailerFirmName;
	}
	public String getRetailerMsisdn() {
		return retailerMsisdn;
	}
	public void setRetailerMsisdn(String retailerMsisdn) {
		this.retailerMsisdn = retailerMsisdn;
	}
	public String getRetailerAddress() {
		return retailerAddress;
	}
	public void setRetailerAddress(String retailerAddress) {
		this.retailerAddress = retailerAddress;
	}
	public String getRetailerZone() {
		return retailerZone;
	}
	public void setRetailerZone(String retailerZone) {
		this.retailerZone = retailerZone;
	}
	public String getDistributorName() {
		return distributorName;
	}
	public void setDistributorName(String distributorName) {
		this.distributorName = distributorName;
	}
	public String getDistributorDsm2Id() {
		return distributorDsm2Id;
	}
	public void setDistributorDsm2Id(String distributorDsm2Id) {
		this.distributorDsm2Id = distributorDsm2Id;
	}
	public String getTsm() {
		return tsm;
	}
	public void setTsm(String tsm) {
		this.tsm = tsm;
	}
	public String getAsm() {
		return asm;
	}
	public void setAsm(String asm) {
		this.asm = asm;
	}
	public String getZbm() {
		return zbm;
	}
	public void setZbm(String zbm) {
		this.zbm = zbm;
	}
	public String getTsmId() {
		return tsmId;
	}
	public void setTsmId(String tsmId) {
		this.tsmId = tsmId;
	}
	public String getAsmId() {
		return asmId;
	}
	public void setAsmId(String asmId) {
		this.asmId = asmId;
	}
	public String getZbmId() {
		return zbmId;
	}
	public void setZbmId(String zbmId) {
		this.zbmId = zbmId;
	}
	public String getTsmMsisdn() {
		return tsmMsisdn;
	}
	public void setTsmMsisdn(String tsmMsisdn) {
		this.tsmMsisdn = tsmMsisdn;
	}
	public String getAsmMsisdn() {
		return asmMsisdn;
	}
	public void setAsmMsisdn(String asmMsisdn) {
		this.asmMsisdn = asmMsisdn;
	}
	public String getZbmMsisdn() {
		return zbmMsisdn;
	}
	public void setZbmMsisdn(String zbmMsisdn) {
		this.zbmMsisdn = zbmMsisdn;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public int getScmListId() {
		return scmListId;
	}
	public void setScmListId(int scmListId) {
		this.scmListId = scmListId;
	}
	public int getNormalGross() {
		return normalGross;
	}
	public void setNormalGross(int normalGross) {
		this.normalGross = normalGross;
	}
	public int getMnpGross() {
		return mnpGross;
	}
	public void setMnpGross(int mnpGross) {
		this.mnpGross = mnpGross;
	}
	public BigDecimal getTotalNet() {
		return totalNet;
	}
	public void setTotalNet(BigDecimal totalNet) {
		this.totalNet = totalNet;
	}
	/*public String getRetailerInvoiceLink() {
		return retailerInvoiceLink;
	}
	public void setRetailerInvoiceLink(String retailerInvoiceLink) {
		this.retailerInvoiceLink = retailerInvoiceLink;
	}
	public String getRetailerOwnName() {
		return retailerOwnName;
	}
	public void setRetailerOwnName(String retailerOwnName) {
		this.retailerOwnName = retailerOwnName;
	}*/
	public int getGrossAct() {
		return grossAct;
	}
	public void setGrossAct(int grossAct) {
		this.grossAct = grossAct;
	}
	public Map<String,List<RetailerStmtScmList>> getRetailerSubMap() {
		return retailerSubMap;
	}
	public void setRetailerSubMap(Map<String,List<RetailerStmtScmList>> retailerSubMap) {
		this.retailerSubMap = retailerSubMap;
	}
	public String getPaymentDt() {
		return paymentDt;
	}
	public void setPaymentDt(String paymentDt) {
		this.paymentDt = paymentDt;
	}
		
	
}

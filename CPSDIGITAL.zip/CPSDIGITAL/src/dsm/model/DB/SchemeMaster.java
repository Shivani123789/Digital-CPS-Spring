package dsm.model.DB;

import java.util.Date;

public class SchemeMaster {

	//DLP_SCHEME_MASTER
	private String payTo;
	private int totalRow;
	private String rejectComment;
	private String remarks;
	private String vtopUpFlag;
	private Date execDate;
	private int compId;
	private String compName;
	private int compID;
	private int payAmt;
	private String status;
	private String execFreq;
	private int schemeINputId;
	private int schemeINputVer;
	private int circleId;
	private String schemeName;
	private String desc;
	//private Date startDate;
	//private Date endDate;
	private String startDate;
	private String endDate;
	
	private String validityFlag;
	private String userId;
	private Date updateTime;
	private Date insertTime;
	private String schemeNameOld;
	private String userName;
	private String schemeStatus;
	private int maxPay;
	private int minPay;
	private Date stmGenDate;
	
	private String payAmtStr;
	private String maxPayStr;
	private String minPayStr;
	
	private String fileName;
	private String region;
	private String zone;
	
	private int month;
	
	private String autoCopyFlag;
	private Date aggrementEndDate;
	private String autoApprovalFlag;
	
	public String getAutoCopyFlag() {
		return autoCopyFlag;
	}
	public void setAutoCopyFlag(String autoCopyFlag) {
		this.autoCopyFlag = autoCopyFlag;
	}
	public Date getAggrementEndDate() {
		return aggrementEndDate;
	}
	public void setAggrementEndDate(Date aggrementEndDate) {
		this.aggrementEndDate = aggrementEndDate;
	}
	public String getAutoApprovalFlag() {
		return autoApprovalFlag;
	}
	public void setAutoApprovalFlag(String autoApprovalFlag) {
		this.autoApprovalFlag = autoApprovalFlag;
	}
	public SchemeMaster() {
		super();
	}
	public int getSchemeINputId() {
		return schemeINputId;
	}
	public void setSchemeINputId(int schemeINputId) {
		this.schemeINputId = schemeINputId;
	}
	public int getSchemeINputVer() {
		return schemeINputVer;
	}
	public void setSchemeINputVer(int schemeINputVer) {
		this.schemeINputVer = schemeINputVer;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	
	public String getSchemeNameOld() {
		return schemeNameOld;
	}
	public void setSchemeNameOld(String schemeNameOld) {
		this.schemeNameOld = schemeNameOld;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public int getCompID() {
		return compID;
	}
	public void setCompID(int compID) {
		this.compID = compID;
	}
	
	public String getSchemeStatus() {
		return schemeStatus;
	}
	public void setSchemeStatus(String schemeStatus) {
		this.schemeStatus = schemeStatus;
	}
	public String getPayTo() {
		return payTo;
	}
	public void setPayTo(String payTo) {
		this.payTo = payTo;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}

	public String getVtopUpFlag() {
		return vtopUpFlag;
	}
	public void setVtopUpFlag(String vtopUpFlag) {
		this.vtopUpFlag = vtopUpFlag;
	}

	public Date getExecDate() {
		return execDate;
	}
	public void setExecDate(Date execDate) {
		this.execDate = execDate;
	}

	public int getPayAmt() {
		return payAmt;
	}
	public void setPayAmt(int payAmt) {
		this.payAmt = payAmt;
	}

	public int getMaxPay() {
		return maxPay;
	}
	public void setMaxPay(int maxPay) {
		this.maxPay = maxPay;
	}
	
	public int getMinPay() {
		return minPay;
	}
	
	public void setMinPay(int minPay) {
		this.minPay = minPay;
	}

	public Date getExecStartDate() {
		return execStartDate;
	}
	public void setExecStartDate(Date execStartDate) {
		this.execStartDate = execStartDate;
	}
	
	private Date execStartDate;

	public Date getExecEndDate() {
		return execEndDate;
	}
	public void setExecEndDate(Date execEndDate) {
		this.execEndDate = execEndDate;
	}

	private Date execEndDate;
	public Date getPayoutAppDate() {
		return payoutAppDate;
	}
	public void setPayoutAppDate(Date payoutAppDate) {
		this.payoutAppDate = payoutAppDate;
	}

	private Date payoutAppDate;
	public Date getStmGenDate() {
		return stmGenDate;
	}
	public void setStmGenDate(Date stmGenDate) {
		this.stmGenDate = stmGenDate;
	}
	
	public String getExecFreq() {
		return execFreq;
	}
	public void setExecFreq(String execFreq) {
		this.execFreq = execFreq;
	}
	public String getRejectComment() {
		return rejectComment;
	}
	public void setRejectComment(String rejectComment) {
		this.rejectComment = rejectComment;
	}
	public int getTotalRow() {
		return totalRow;
	}
	public void setTotalRow(int totalRow) {
		this.totalRow = totalRow;
	}
	public String getPayAmtStr() {
		return payAmtStr;
	}
	public void setPayAmtStr(String payAmtStr) {
		this.payAmtStr = payAmtStr;
	}
	public String getMaxPayStr() {
		return maxPayStr;
	}
	public void setMaxPayStr(String maxPayStr) {
		this.maxPayStr = maxPayStr;
	}
	public String getMinPayStr() {
		return minPayStr;
	}
	public void setMinPayStr(String minPayStr) {
		this.minPayStr = minPayStr;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}

	
	
	
	
}

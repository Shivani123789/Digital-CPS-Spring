package dsm.model.DB;

import java.math.BigDecimal;

/**
 * @author jeet_thakur
 * 
 */
public class DistributorStmtSchmPojo {

	private int statScmId;
	private int schListId;
	private BigDecimal payTotal;
	//private BigDecimal refTotal;
	private BigDecimal grossPayAmt;
	private BigDecimal netComm;
	private BigDecimal tdsAmount;
	private int schemeId;
	private int compoentId;
	//private String target;
	//private String achivedPerc;
	private String schemeCompDesc;
	//private String paymentMode;
	private String unit;
	private BigDecimal rate;

	public int getStatScmId() {
		return statScmId;
	}

	public void setStatScmId(int statScmId) {
		this.statScmId = statScmId;
	}

	public int getSchListId() {
		return schListId;
	}

	public void setSchListId(int schListId) {
		this.schListId = schListId;
	}

	public BigDecimal getPayTotal() {
		return payTotal;
	}

	public void setPayTotal(BigDecimal payTotal) {
		this.payTotal = payTotal;
	}

	/*public BigDecimal getRefTotal() {
		return refTotal;
	}

	public void setRefTotal(BigDecimal refTotal) {
		this.refTotal = refTotal;
	}*/

	public BigDecimal getGrossPayAmt() {
		return grossPayAmt;
	}

	public void setGrossPayAmt(BigDecimal grossPayAmt) {
		this.grossPayAmt = grossPayAmt;
	}

	public BigDecimal getNetComm() {
		return netComm;
	}

	public void setNetComm(BigDecimal netComm) {
		this.netComm = netComm;
	}

	public BigDecimal getTdsAmount() {
		return tdsAmount;
	}

	public void setTdsAmount(BigDecimal tdsAmount) {
		this.tdsAmount = tdsAmount;
	}

	public int getSchemeId() {
		return schemeId;
	}

	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}

	public int getCompoentId() {
		return compoentId;
	}

	public void setCompoentId(int compoentId) {
		this.compoentId = compoentId;
	}

	/*public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}*/

	/*public String getAchivedPerc() {
		return achivedPerc;
	}

	public void setAchivedPerc(String achivedPerc) {
		this.achivedPerc = achivedPerc;
	}*/

	public String getSchemeCompDesc() {
		return schemeCompDesc;
	}

	public void setSchemeCompDesc(String schemeCompDesc) {
		this.schemeCompDesc = schemeCompDesc;
	}

	/*public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}*/

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

}
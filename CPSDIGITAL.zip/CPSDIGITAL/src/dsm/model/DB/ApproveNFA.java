package dsm.model.DB;

import java.util.Date;
import java.util.List;

import dsm.model.form.SchemeCompNFAList;

public class ApproveNFA {

	private List<SchemeMaster> schemeIdList;
	private int schemeINputId;
	private String schemeName;
	private Date insertTime;
	private String validityFlag;
	private String name;
	private int circleId;
	
	private List<SchemeCompNFAList> schemeCompList;
	
	
	
	public List<SchemeCompNFAList> getSchemeCompList() {
		return schemeCompList;
	}

	public void setSchemeCompList(List<SchemeCompNFAList> schemeCompList) {
		this.schemeCompList = schemeCompList;
	}

	public int getCircleId() {
		return circleId;
	}

	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}

	public List<SchemeMaster> getSchemeIdList() {
		return schemeIdList;
	}

	public void setSchemeIdList(List<SchemeMaster> schemeIdList) {
		this.schemeIdList = schemeIdList;
	}

	public int getSchemeINputId() {
		return schemeINputId;
	}

	public void setSchemeINputId(int schemeINputId) {
		this.schemeINputId = schemeINputId;
	}

	public String getSchemeName() {
		return schemeName;
	}

	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public Date getInsertTime() {
		return insertTime;
	}

	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}

	public String getValidityFlag() {
		return validityFlag;
	}

	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}

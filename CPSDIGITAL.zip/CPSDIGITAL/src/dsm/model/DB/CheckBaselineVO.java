package dsm.model.DB;

public class CheckBaselineVO {
	private int schemeId;
	private int compId;
	private String schemeName;
	private String compName;
	private int reconfigId;
	private String startDt;
	private String endDt;
	private String paramCat;
	private String paramName;
	private int configStatus;
	private String fieldName;
	private String tableName;
	private int rowCount;
	private int valueCount;
	private int missingValueCount;
	private String remarks;
	private int circleId;
	private String exeDt;
	private String fullHierStampCount;
	private String partialHierStampCount;
	private String missingHierStampCount;
	
	
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getReconfigId() {
		return reconfigId;
	}
	public void setReconfigId(int reconfigId) {
		this.reconfigId = reconfigId;
	}
	public String getStartDt() {
		return startDt;
	}
	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}
	public String getEndDt() {
		return endDt;
	}
	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}
	public String getParamCat() {
		return paramCat;
	}
	public void setParamCat(String paramCat) {
		this.paramCat = paramCat;
	}
	public String getParamName() {
		return paramName;
	}
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	public int getConfigStatus() {
		return configStatus;
	}
	public void setConfigStatus(int configStatus) {
		this.configStatus = configStatus;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public int getRowCount() {
		return rowCount;
	}
	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}
	public int getValueCount() {
		return valueCount;
	}
	public void setValueCount(int valueCount) {
		this.valueCount = valueCount;
	}
	public int getMissingValueCount() {
		return missingValueCount;
	}
	public void setMissingValueCount(int missingValueCount) {
		this.missingValueCount = missingValueCount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getExeDt() {
		return exeDt;
	}
	public void setExeDt(String exeDt) {
		this.exeDt = exeDt;
	}
	public String getFullHierStampCount() {
		return fullHierStampCount;
	}
	public void setFullHierStampCount(String fullHierStampCount) {
		this.fullHierStampCount = fullHierStampCount;
	}
	public String getPartialHierStampCount() {
		return partialHierStampCount;
	}
	public void setPartialHierStampCount(String partialHierStampCount) {
		this.partialHierStampCount = partialHierStampCount;
	}
	public String getMissingHierStampCount() {
		return missingHierStampCount;
	}
	public void setMissingHierStampCount(String missingHierStampCount) {
		this.missingHierStampCount = missingHierStampCount;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	
	
	
	
}

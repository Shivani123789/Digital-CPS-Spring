package dsm.model.DB;

import java.math.BigDecimal;

public class PartnerChannelStmtScmListPojo {

	private int scmListId;
	private int scmId;
	private int compId;
	private String modelName;
	private String serviceType;
	private String cpId;
	private BigDecimal grossRevenue;
	private BigDecimal totalDeduction;
	private BigDecimal netRevenue;
	private BigDecimal usagesPercent;
	private BigDecimal revenueShare;
	private BigDecimal revenueSharePercent;
	private BigDecimal subTotal;
	private String circle;
	private String schemeName;
	private String compName;
	private String amtInWords;
	
	public int getScmListId() {
		return scmListId;
	}
	public void setScmListId(int scmListId) {
		this.scmListId = scmListId;
	}
	public int getScmId() {
		return scmId;
	}
	public void setScmId(int scmId) {
		this.scmId = scmId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	public String getServiceType() {
		return serviceType;
	}
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
	public String getCpId() {
		return cpId;
	}
	public void setCpId(String cpId) {
		this.cpId = cpId;
	}
	public BigDecimal getGrossRevenue() {
		return grossRevenue;
	}
	public void setGrossRevenue(BigDecimal grossRevenue) {
		this.grossRevenue = grossRevenue;
	}
	public BigDecimal getTotalDeduction() {
		return totalDeduction;
	}
	public void setTotalDeduction(BigDecimal totalDeduction) {
		this.totalDeduction = totalDeduction;
	}
	public BigDecimal getNetRevenue() {
		return netRevenue;
	}
	public void setNetRevenue(BigDecimal netRevenue) {
		this.netRevenue = netRevenue;
	}
	public BigDecimal getUsagesPercent() {
		return usagesPercent;
	}
	public void setUsagesPercent(BigDecimal usagesPercent) {
		this.usagesPercent = usagesPercent;
	}
	public BigDecimal getRevenueShare() {
		return revenueShare;
	}
	public void setRevenueShare(BigDecimal revenueShare) {
		this.revenueShare = revenueShare;
	}
	public BigDecimal getRevenueSharePercent() {
		return revenueSharePercent;
	}
	public void setRevenueSharePercent(BigDecimal revenueSharePercent) {
		this.revenueSharePercent = revenueSharePercent;
	}
	public BigDecimal getSubTotal() {
		return subTotal;
	}
	public void setSubTotal(BigDecimal subTotal) {
		this.subTotal = subTotal;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getAmtInWords() {
		return amtInWords;
	}
	public void setAmtInWords(String amtInWords) {
		this.amtInWords = amtInWords;
	}
	
	
	
	}
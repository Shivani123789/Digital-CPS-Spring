package dsm.model.DB;

import java.math.BigDecimal;

public class RetailerStmtScmList {

	private String schemeCompDesc;
	private String schemeType;
	private int stmtScmId;
	private int scmListId;
	private BigDecimal paytotal;
	//private float perftotal;
	private BigDecimal grossPayAmt;
	private BigDecimal netComm;
	private BigDecimal tdsAmount;
	private int schemeId;
	private int compId;
	//private String paymentMode;
	private String unit;
	private BigDecimal rate;
	
	public String getSchemeCompDesc() {
		return schemeCompDesc;
	}
	public void setSchemeCompDesc(String schemeCompDesc) {
		this.schemeCompDesc = schemeCompDesc;
	}
	public String getSchemeType() {
		return schemeType;
	}
	public void setSchemeType(String schemeType) {
		this.schemeType = schemeType;
	}
	public int getStmtScmId() {
		return stmtScmId;
	}
	public void setStmtScmId(int stmtScmId) {
		this.stmtScmId = stmtScmId;
	}
	public int getScmListId() {
		return scmListId;
	}
	public void setScmListId(int scmListId) {
		this.scmListId = scmListId;
	}
	public BigDecimal getPaytotal() {
		return paytotal;
	}
	public void setPaytotal(BigDecimal paytotal) {
		this.paytotal = paytotal;
	}
	/*public float getPerftotal() {
		return perftotal;
	}
	public void setPerftotal(float perftotal) {
		this.perftotal = perftotal;
	}*/
	public BigDecimal getGrossPayAmt() {
		return grossPayAmt;
	}
	public void setGrossPayAmt(BigDecimal grossPayAmt) {
		this.grossPayAmt = grossPayAmt;
	}
	public BigDecimal getNetComm() {
		return netComm;
	}
	public void setNetComm(BigDecimal netComm) {
		this.netComm = netComm;
	}
	public BigDecimal getTdsAmount() {
		return tdsAmount;
	}
	public void setTdsAmount(BigDecimal tdsAmount) {
		this.tdsAmount = tdsAmount;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	/*public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}*/
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public BigDecimal getRate() {
		return rate;
	}
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

	
	
}

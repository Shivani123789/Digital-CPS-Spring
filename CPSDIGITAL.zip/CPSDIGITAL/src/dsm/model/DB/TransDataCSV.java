package dsm.model.DB;

import java.util.List;
import java.util.Map;

import dsm.controller.csv.GenerateCSV;

public class TransDataCSV {

	private boolean isError;
	private String status;
	private List<String> columnName;
	private Map<Integer, List> values;
	private GenerateCSV genCSV;
	private StringBuffer generateCsv;
	
	public List<String> getColumnName() {
		return columnName;
	}
	public void setColumnName(List<String> columnName) {
		this.columnName = columnName;
	}
	public Map<Integer, List> getValues() {
		return values;
	}
	public void setValues(Map<Integer, List> values) {
		this.values = values;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public boolean isError() {
		return isError;
	}
	public void setError(boolean isError) {
		this.isError = isError;
	}
	public GenerateCSV getGenCSV() {
		return genCSV;
	}
	public void setGenCSV(GenerateCSV genCSV) {
		this.genCSV = genCSV;
	}
	public StringBuffer getGenerateCsv() {
		return generateCsv;
	}
	public void setGenerateCsv(StringBuffer generateCsv) {
		this.generateCsv = generateCsv;
	}
	
}

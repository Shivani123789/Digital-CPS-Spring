package dsm.model.DB;

import java.util.Date;

public class BulkRejectionDataPojo {
	
	String msisdn;
	Date eventDate;
	String circle;
	String fileName;
	String rejectionReason;
	String distId;
	String dseId;
	String retId;
	String dsm2RefCode;
	String producerId;
	String dsmRefCode;
	
	public String getDsmRefCode() {
		return dsmRefCode;
	}
	public void setDsmRefCode(String dsmRefCode) {
		this.dsmRefCode = dsmRefCode;
	}
	public Date getEventDate() {
		return eventDate;
	} 
	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}
	String entityType;
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	public String getDistId() {
		return distId;
	}
	public void setDistId(String distId) {
		this.distId = distId;
	}
	public String getDseId() {
		return dseId;
	}
	public void setDseId(String dseId) {
		this.dseId = dseId;
	}
	public String getRetId() {
		return retId;
	}
	public void setRetId(String retId) {
		this.retId = retId;
	}
	public String getDsm2RefCode() {
		return dsm2RefCode;
	}
	public void setDsm2RefCode(String dsm2RefCode) {
		this.dsm2RefCode = dsm2RefCode;
	}
	public String getProducerId() {
		return producerId;
	}
	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	
	
	
	

}

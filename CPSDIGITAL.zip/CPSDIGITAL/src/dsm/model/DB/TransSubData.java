package dsm.model.DB;

public class TransSubData {

	private String transSubDataType;
	private int schemeId;
	private int compId;
	private int qualifyType;
	private int conditionId;
	private int circleId;
	private int paymentId;
	private int universeId;
	private String fileName;
	private boolean isError;
	private String errorDesc;
	private String downloadLink;
	
	public boolean isError() {
		return isError;
	}
	public void setError(boolean isError) {
		this.isError = isError;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public int getUniverseId() {
		return universeId;
	}
	public void setUniverseId(int universeId) {
		this.universeId = universeId;
	}
	public String getTransSubDataType() {
		return transSubDataType;
	}
	public void setTransSubDataType(String transSubDataType) {
		this.transSubDataType = transSubDataType;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getQualifyType() {
		return qualifyType;
	}
	public void setQualifyType(int qualifyType) {
		this.qualifyType = qualifyType;
	}
	public int getConditionId() {
		return conditionId;
	}
	public void setConditionId(int conditionId) {
		this.conditionId = conditionId;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getDownloadLink() {
		return downloadLink;
	}
	public void setDownloadLink(String downloadLink) {
		this.downloadLink = downloadLink;
	}
	
	
	
}

package dsm.model.DB;

public class RoprMaster {

	private int oprId;
	private String oprName;
	private String coFlag;
	private String tqFlag;
	private String poFlag;
	public int getOprId() {
		return oprId;
	}
	public void setOprId(int oprId) {
		this.oprId = oprId;
	}
	public String getOprName() {
		return oprName;
	}
	public void setOprName(String oprName) {
		this.oprName = oprName;
	}
	
	public String getTqFlag() {
		return tqFlag;
	}
	public void setTqFlag(String tqFlag) {
		this.tqFlag = tqFlag;
	}
	public String getCoFlag() {
		return coFlag;
	}
	public void setCoFlag(String coFlag) {
		this.coFlag = coFlag;
	}
	public String getPoFlag() {
		return poFlag;
	}
	public void setPoFlag(String poFlag) {
		this.poFlag = poFlag;
	}
}

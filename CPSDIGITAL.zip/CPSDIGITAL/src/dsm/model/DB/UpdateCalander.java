package dsm.model.DB;

import java.util.Date;

public class UpdateCalander {
	
	
	private int circleId;
	private int compId;
	private int schemeINputId;
	private Date execStartDate;
	private Date execEndDate;
	private Date stmGenDate;
	private Date payoutAppDate;
	public Date getExecEndDate() {
		return execEndDate;
	}
	public void setExecEndDate(Date execEndDate) {
		this.execEndDate = execEndDate;
	}
	public Date getExecStartDate() {
		return execStartDate;
	}
	public void setExecStartDate(Date execStartDate) {
		this.execStartDate = execStartDate;
	}
	public Date getStmGenDate() {
		return stmGenDate;
	}
	public void setStmGenDate(Date stmGenDate) {
		this.stmGenDate = stmGenDate;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getSchemeINputId() {
		return schemeINputId;
	}
	public void setSchemeINputId(int schemeINputId) {
		this.schemeINputId = schemeINputId;
	}
	public Date getPayoutAppDate() {
		return payoutAppDate;
	}
	public void setPayoutAppDate(Date payoutAppDate) {
		this.payoutAppDate = payoutAppDate;
	}

}

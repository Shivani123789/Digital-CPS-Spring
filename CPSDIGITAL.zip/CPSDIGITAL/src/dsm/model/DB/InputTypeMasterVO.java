package dsm.model.DB;

import java.util.Date;

public class InputTypeMasterVO {

	private int inputTypeId;
	private String inputTypeDesc;
	private String displayValue;
	private String coFlag;
	private String tqFalg;
	private String eaConFlag;
	private String eaVarFlag;
	private String poFlag;
	private String validityFlag;
	private Date updateDt ;
	private Date inserDt;
	private String dataSource;
	private String condiParam;
	
	public int getInputTypeId() {
		return inputTypeId;
	}
	public void setInputTypeId(int inputTypeId) {
		this.inputTypeId = inputTypeId;
	}
	public String getInputTypeDesc() {
		return inputTypeDesc;
	}
	public void setInputTypeDesc(String inputTypeDesc) {
		this.inputTypeDesc = inputTypeDesc;
	}
	public String getDisplayValue() {
		return displayValue;
	}
	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}
	public String getCoFlag() {
		return coFlag;
	}
	public void setCoFlag(String coFlag) {
		this.coFlag = coFlag;
	}
	public String getTqFalg() {
		return tqFalg;
	}
	public void setTqFalg(String tqFalg) {
		this.tqFalg = tqFalg;
	}
	public String getEaConFlag() {
		return eaConFlag;
	}
	public void setEaConFlag(String eaConFlag) {
		this.eaConFlag = eaConFlag;
	}
	public String getEaVarFlag() {
		return eaVarFlag;
	}
	public void setEaVarFlag(String eaVarFlag) {
		this.eaVarFlag = eaVarFlag;
	}
	public String getPoFlag() {
		return poFlag;
	}
	public void setPoFlag(String poFlag) {
		this.poFlag = poFlag;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public Date getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}
	public Date getInserDt() {
		return inserDt;
	}
	public void setInserDt(Date inserDt) {
		this.inserDt = inserDt;
	}
	public String getDataSource() {
		return dataSource;
	}
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getCondiParam() {
		return condiParam;
	}
	public void setCondiParam(String condiParam) {
		this.condiParam = condiParam;
	}
	
	
}

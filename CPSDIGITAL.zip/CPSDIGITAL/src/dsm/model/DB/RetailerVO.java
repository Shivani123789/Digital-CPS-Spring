package dsm.model.DB;

public class RetailerVO {
	private String retailerMsisd;
	private float amount;
	private String remarks;
	private String region;
	private String zone;
	
	public String getRetailerMsisd() {
		return retailerMsisd;
	}
	public void setRetailerMsisd(String retailerMsisd) {
		this.retailerMsisd = retailerMsisd;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	
	
}

package dsm.model.DB;

import java.util.Date;

import org.springframework.web.multipart.commons.CommonsMultipartFile;
//import org.springframework.web.multipart.MultipartFile;

public class CompMaster {
	//DLP_SCHEME_COMP_MAPPING

	private String csrf;
	private String payoutStatus;
	private String startDtStr;
	private String endDtStr;
	private String paymentStatus;
	private int schemeId;
	private String schemeName;
	private CommonsMultipartFile fileUpload;
	private int compId;
	private int compVer;
	private int circleId;
	private String compName;
	private Date startDate;
	private Date endDate;
	private String scmStatus;
	private String userName;
	private int freqId;
	private String freqName;
	private int uploadList;
	private int verticalId;
	private String verticalName;

	private String coverageFlag;

	private int payTo;
	private String payToName;

	private String covFlag;
	private String fileName;
	private String valFlag;
	private int uploadId;

	private Date updateTime;
	private Date insertTime;
	private String category;
	private int categoryId;
	
	private String systemType;
	private int systemId;
	
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	//private List<RegZoneMaster> regZone;
	//private List<SchemeAcMaster> addCov;
	//private List<SchemeTqMaster> tranQal;
	//private List<SchemeEaMaster> entityAggr;
	//private List<SchemePoMaster> payoutCond;
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getCompVer() {
		return compVer;
	}
	public void setCompVer(int compVer) {
		this.compVer = compVer;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}




	public int getPayTo() {
		return payTo;
	}
	public void setPayTo(int payTo) {
		this.payTo = payTo;
	}
	public String getCovFlag() {
		return covFlag;
	}
	public void setCovFlag(String covFlag) {
		this.covFlag = covFlag;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public String getCoverageFlag() {
		return coverageFlag;
	}
	public void setCoverageFlag(String coverageFlag) {
		this.coverageFlag = coverageFlag;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getFreqId() {
		return freqId;
	}
	public void setFreqId(int freqId) {
		this.freqId = freqId;
	}
	public int getVerticalId() {
		return verticalId;
	}
	public void setVerticalId(int verticalId) {
		this.verticalId = verticalId;
	}

	public int getUploadList() {
		return uploadList;
	}
	public void setUploadList(int uploadList) {
		this.uploadList = uploadList;
	}

	public int getUploadId() {
		return uploadId;
	}
	public void setUploadId(int uploadId) {
		this.uploadId = uploadId;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getFreqName() {
		return freqName;
	}
	public void setFreqName(String freqName) {
		this.freqName = freqName;
	}
	public String getVerticalName() {
		return verticalName;
	}
	public void setVerticalName(String verticalName) {
		this.verticalName = verticalName;
	}
	public String getPayToName() {
		return payToName;
	}
	public void setPayToName(String payToName) {
		this.payToName = payToName;
	}
	public CommonsMultipartFile getFileUpload() {
		return fileUpload;
	}
	public void setFileUpload(CommonsMultipartFile fileUpload) {
		this.fileUpload = fileUpload;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getScmStatus() {
		return scmStatus;
	}
	public void setScmStatus(String scmStatus) {
		this.scmStatus = scmStatus;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getStartDtStr() {
		return startDtStr;
	}
	public void setStartDtStr(String startDtStr) {
		this.startDtStr = startDtStr;
	}
	public String getEndDtStr() {
		return endDtStr;
	}
	public void setEndDtStr(String endDtStr) {
		this.endDtStr = endDtStr;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getPayoutStatus() {
		return payoutStatus;
	}
	public void setPayoutStatus(String payoutStatus) {
		this.payoutStatus = payoutStatus;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCsrf() {
		return csrf;
	}
	public void setCsrf(String csrf) {
		this.csrf = csrf;
	}
	public String getSystemType() {
		return systemType;
	}
	public void setSystemType(String systemType) {
		this.systemType = systemType;
	}
	public int getSystemId() {
		return systemId;
	}
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}
	

}

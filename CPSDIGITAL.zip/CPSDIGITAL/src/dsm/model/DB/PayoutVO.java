package dsm.model.DB;

public class PayoutVO {
	private String circleCode;
	private String schemeName;
	private String componentName;
	private String payTo;
	private String entityId;
	private String grossNet;
	private String payNos;
	private String unit;
	private int grossValue;
	private float netValue;
	private float tax;
	
	private long headCount;
	private float grossnet;
	private float maxAmt;
	private float minAmt;
	private float avgAmt;
	private String vtopUpNumber;
	private String ftaNumber;
	private String producerId;
	private String entityName;
	private int underAchieve;
	private int overAchieve;
	
	private String underAchieveStr;
	private String overAchieveStr;
	
	private String region;
	private String zone;
	
	
	public float getGrossnet() {
		return grossnet;
	}
	public void setGrossnet(float grossnet) {
		this.grossnet = grossnet;
	}
	public float getMaxAmt() {
		return maxAmt;
	}
	public void setMaxAmt(float maxAmt) {
		this.maxAmt = maxAmt;
	}
	public float getMinAmt() {
		return minAmt;
	}
	public void setMinAmt(float minAmt) {
		this.minAmt = minAmt;
	}
	public float getAvgAmt() {
		return avgAmt;
	}
	public void setAvgAmt(float avgAmt) {
		this.avgAmt = avgAmt;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public String getPayTo() {
		return payTo;
	}
	public void setPayTo(String payTo) {
		this.payTo = payTo;
	}
	public String getEntityId() {
		return entityId;
	}
	public void setEntityId(String entityId) {
		this.entityId = entityId;
	}
	public String getGrossNet() {
		return grossNet;
	}
	public void setGrossNet(String grossNet) {
		this.grossNet = grossNet;
	}
	public String getPayNos() {
		return payNos;
	}
	public void setPayNos(String payNos) {
		this.payNos = payNos;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public int getGrossValue() {
		return grossValue;
	}
	public void setGrossValue(int grossValue) {
		this.grossValue = grossValue;
	}
	public float getNetValue() {
		return netValue;
	}
	public void setNetValue(float netValue) {
		this.netValue = netValue;
	}
	public float getTax() {
		return tax;
	}
	public void setTax(float tax) {
		this.tax = tax;
	}
	public long getHeadCount() {
		return headCount;
	}
	public void setHeadCount(long headCount) {
		this.headCount = headCount;
	}
	public String getVtopUpNumber() {
		return vtopUpNumber;
	}
	public void setVtopUpNumber(String vtopUpNumber) {
		this.vtopUpNumber = vtopUpNumber;
	}
	public String getFtaNumber() {
		return ftaNumber;
	}
	public void setFtaNumber(String ftaNumber) {
		this.ftaNumber = ftaNumber;
	}
	public String getEntityName() {
		return entityName;
	}
	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}
	public int getUnderAchieve() {
		return underAchieve;
	}
	public void setUnderAchieve(int underAchieve) {
		this.underAchieve = underAchieve;
	}
	public int getOverAchieve() {
		return overAchieve;
	}
	public void setOverAchieve(int overAchieve) {
		this.overAchieve = overAchieve;
	}
	public String getUnderAchieveStr() {
		return underAchieveStr;
	}
	public void setUnderAchieveStr(String underAchieveStr) {
		this.underAchieveStr = underAchieveStr;
	}
	public String getOverAchieveStr() {
		return overAchieveStr;
	}
	public void setOverAchieveStr(String overAchieveStr) {
		this.overAchieveStr = overAchieveStr;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getProducerId() {
		return producerId;
	}
	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}

	
}

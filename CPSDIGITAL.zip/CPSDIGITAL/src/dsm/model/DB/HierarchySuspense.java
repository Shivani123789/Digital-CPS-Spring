package dsm.model.DB;

public class HierarchySuspense {

	private String scm;
	private int retailer;
	private int dse;
	private int dist;
	private int internalSales;
	private int unid;
	
	public String getScm() {
		return scm;
	}
	public void setScm(String scm) {
		this.scm = scm;
	}
	public int getRetailer() {
		return retailer;
	}
	public void setRetailer(int retailer) {
		this.retailer = retailer;
	}
	public int getDse() {
		return dse;
	}
	public void setDse(int dse) {
		this.dse = dse;
	}
	public int getDist() {
		return dist;
	}
	public void setDist(int dist) {
		this.dist = dist;
	}
	public int getInternalSales() {
		return internalSales;
	}
	public void setInternalSales(int internalSales) {
		this.internalSales = internalSales;
	}
	public int getUnid() {
		return unid;
	}
	public void setUnid(int unid) {
		this.unid = unid;
	}
	
	
}

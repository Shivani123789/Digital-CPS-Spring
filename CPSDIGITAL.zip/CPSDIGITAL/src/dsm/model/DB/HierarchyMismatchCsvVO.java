package dsm.model.DB;

public class HierarchyMismatchCsvVO {
	private String circle;
	private String hierDt;
	private String systemInvolved;
	private String entityType;
	private String mobileNo;
	private String firstSysMgr;
	private String secondSysMgr;
	private String remarks;

	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public String getHierDt() {
		return hierDt;
	}
	public void setHierDt(String hierDt) {
		this.hierDt = hierDt;
	}
	public String getSystemInvolved() {
		return systemInvolved;
	}
	public void setSystemInvolved(String systemInvolved) {
		this.systemInvolved = systemInvolved;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstSysMgr() {
		return firstSysMgr;
	}
	public void setFirstSysMgr(String firstSysMgr) {
		this.firstSysMgr = firstSysMgr;
	}
	public String getSecondSysMgr() {
		return secondSysMgr;
	}
	public void setSecondSysMgr(String secondSysMgr) {
		this.secondSysMgr = secondSysMgr;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
}

package dsm.model.DB;

import java.math.BigDecimal;
import java.util.Date;

public class SchemePoAmtMaster {
	//DLP_SCM_TQ_COND_CONFIG
	private String processType;
	private int schemeId;
	private int circleId;
	private int compId;
	private String compName;
	private String value;
	private int reConfigId;
	private int condId;
	private String grossNet;
	private int unit;
	private String unitName;
	private BigDecimal amount;
	private String variable;
	private String variableName;
	private int overAch;
	private int underAch;
	
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getReConfigId() {
		return reConfigId;
	}
	public void setReConfigId(int reConfigId) {
		this.reConfigId = reConfigId;
	}
	public int getCondId() {
		return condId;
	}
	public void setCondId(int condId) {
		this.condId = condId;
	}
	
	
	
	
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getLopr() {
		return lopr;
	}
	public void setLopr(int lopr) {
		this.lopr = lopr;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public String getGrossNet() {
		return grossNet;
	}
	public void setGrossNet(String grossNet) {
		this.grossNet = grossNet;
	}
	public int getUnit() {
		return unit;
	}
	public void setUnit(int unit) {
		this.unit = unit;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getVariable() {
		return variable;
	}
	public void setVariable(String variable) {
		this.variable = variable;
	}
	public int getOverAch() {
		return overAch;
	}
	public void setOverAch(int overAch) {
		this.overAch = overAch;
	}
	public int getUnderAch() {
		return underAch;
	}
	public void setUnderAch(int underAch) {
		this.underAch = underAch;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	public String getVariableName() {
		return variableName;
	}
	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	private Date startDate;
	private Date endDate;
	private int lopr;
	private String schemeName;
	private String valFlag;
	private Date updateDate;
	private Date insertDate;
	
	
	
}

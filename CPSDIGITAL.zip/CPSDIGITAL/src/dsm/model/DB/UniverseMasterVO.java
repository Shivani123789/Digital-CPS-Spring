package dsm.model.DB;

import java.util.Date;

public class UniverseMasterVO {
	
	private int universeId;
	private int feedNumber;
	private String eventTypeId;
	private String transDataType;
	private String tableName;
	private String universeName;
	private String stampFlag;
	private String uniHierMapField;
	private String hierMapTable;
	private String hierMapField;
	private String tableSpaceName;
	private String userId;
	private String validityFlag;
	private Date updateDt;
	private Date insertDt;
	private String hierUniEventDt;
	private String count;
	private String minDt;
	private String maxDt;
	private long headCount;
	
	public long getHeadCount() {
		return headCount;
	}
	public void setHeadCount(long headCount) {
		this.headCount = headCount;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getMinDt() {
		return minDt;
	}
	public void setMinDt(String minDt) {
		this.minDt = minDt;
	}
	public String getMaxDt() {
		return maxDt;
	}
	public void setMaxDt(String maxDt) {
		this.maxDt = maxDt;
	}
	public int getUniverseId() {
		return universeId;
	}
	public void setUniverseId(int universeId) {
		this.universeId = universeId;
	}
	public int getFeedNumber() {
		return feedNumber;
	}
	public void setFeedNumber(int feedNumber) {
		this.feedNumber = feedNumber;
	}
	public String getEventTypeId() {
		return eventTypeId;
	}
	public void setEventTypeId(String eventTypeId) {
		this.eventTypeId = eventTypeId;
	}
	public String getTransDataType() {
		return transDataType;
	}
	public void setTransDataType(String transDataType) {
		this.transDataType = transDataType;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getUniverseName() {
		return universeName;
	}
	public void setUniverseName(String universeName) {
		this.universeName = universeName;
	}
	public String getStampFlag() {
		return stampFlag;
	}
	public void setStampFlag(String stampFlag) {
		this.stampFlag = stampFlag;
	}
	public String getUniHierMapField() {
		return uniHierMapField;
	}
	public void setUniHierMapField(String uniHierMapField) {
		this.uniHierMapField = uniHierMapField;
	}
	public String getHierMapTable() {
		return hierMapTable;
	}
	public void setHierMapTable(String hierMapTable) {
		this.hierMapTable = hierMapTable;
	}
	public String getHierMapField() {
		return hierMapField;
	}
	public void setHierMapField(String hierMapField) {
		this.hierMapField = hierMapField;
	}
	public String getTableSpaceName() {
		return tableSpaceName;
	}
	public void setTableSpaceName(String tableSpaceName) {
		this.tableSpaceName = tableSpaceName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public Date getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(Date updateDt) {
		this.updateDt = updateDt;
	}
	public Date getInsertDt() {
		return insertDt;
	}
	public void setInsertDt(Date insertDt) {
		this.insertDt = insertDt;
	}
	public String getHierUniEventDt() {
		return hierUniEventDt;
	}
	public void setHierUniEventDt(String hierUniEventDt) {
		this.hierUniEventDt = hierUniEventDt;
	}

	
	
	
}

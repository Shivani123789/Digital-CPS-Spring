package dsm.model.DB;

import dsm.model.po.SchemePoMaster;
public class SchemeInputAll {
	
	private SchemeMaster schemeInputCov;
	private CompMaster schemeInputComp;
	
	private SchemeAcMaster schemeInputAc;
	private SchemeEaMaster schemeInputEa;
	private SchemeEaFilterCondMaster schemeInputEaFilter;
	private SchemeTqMaster schemeInputTq;
	private SchemePoMaster schemeInputPo;
	private SchemePoAmtMaster schemeInputPoAmt;
	private RegZoneMaster schemeInputRegZone;
	public SchemeMaster getSchemeInputCov() {
		return schemeInputCov;
	}
	public void setSchemeInputCov(SchemeMaster schemeInputCov) {
		this.schemeInputCov = schemeInputCov;
	}
	public CompMaster getSchemeInputComp() {
		return schemeInputComp;
	}
	public void setSchemeInputComp(CompMaster schemeInputComp) {
		this.schemeInputComp = schemeInputComp;
	}
	
	public SchemeAcMaster getSchemeInputAc() {
		return schemeInputAc;
	}
	public void setSchemeInputAc(SchemeAcMaster schemeInputAc) {
		this.schemeInputAc = schemeInputAc;
	}
	public SchemeEaMaster getSchemeInputEa() {
		return schemeInputEa;
	}
	public void setSchemeInputEa(SchemeEaMaster schemeInputEa) {
		this.schemeInputEa = schemeInputEa;
	}
	public SchemeTqMaster getSchemeInputTq() {
		return schemeInputTq;
	}
	public void setSchemeInputTq(SchemeTqMaster schemeInputTq) {
		this.schemeInputTq = schemeInputTq;
	}
	public SchemePoMaster getSchemeInputPo() {
		return schemeInputPo;
	}
	public void setSchemeInputPo(SchemePoMaster schemeInputPo) {
		this.schemeInputPo = schemeInputPo;
	}
	public RegZoneMaster getSchemeInputRegZone() {
		return schemeInputRegZone;
	}
	public void setSchemeInputRegZone(RegZoneMaster schemeInputRegZone) {
		this.schemeInputRegZone = schemeInputRegZone;
	}
	public SchemeEaFilterCondMaster getSchemeInputEaFilter() {
		return schemeInputEaFilter;
	}
	public void setSchemeInputEaFilter(SchemeEaFilterCondMaster schemeInputEaFilter) {
		this.schemeInputEaFilter = schemeInputEaFilter;
	}
	public SchemePoAmtMaster getSchemeInputPoAmt() {
		return schemeInputPoAmt;
	}
	public void setSchemeInputPoAmt(SchemePoAmtMaster schemeInputPoAmt) {
		this.schemeInputPoAmt = schemeInputPoAmt;
	}
	
	
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

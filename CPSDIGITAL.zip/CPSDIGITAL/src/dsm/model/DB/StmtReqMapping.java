package dsm.model.DB;

	
public class StmtReqMapping {
	private int compId;
	private int scmId;
	private String compName;
	private String scmName;
	private String payTo;
	private String payoutApprovalDt;
	private int paymentId;
	private int payToId;
	private String payoutStatus;
	private String paymentStatus;
	private String scmApproveDt;
	private String startDt;
	private String endDt;
	private String paymentDt;
	
	
	public String getPayoutApprovalDt() {
		return payoutApprovalDt;
	}
	public void setPayoutApprovalDt(String payoutApprovalDt) {
		this.payoutApprovalDt = payoutApprovalDt;
	}
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public int getCompId() {
		return compId;
	}
	public String getPayTo() {
		return payTo;
	}
	public void setPayTo(String payTo) {
		this.payTo = payTo;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getScmId() {
		return scmId;
	}
	public void setScmId(int scmId) {
		this.scmId = scmId;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getScmName() {
		return scmName;
	}
	public void setScmName(String scmName) {
		this.scmName = scmName;
	}
	public int getPayToId() {
		return payToId;
	}
	public void setPayToId(int payToId) {
		this.payToId = payToId;
	}
	public String getPayoutStatus() {
		return payoutStatus;
	}
	public void setPayoutStatus(String payoutStatus) {
		this.payoutStatus = payoutStatus;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getScmApproveDt() {
		return scmApproveDt;
	}
	public void setScmApproveDt(String scmApproveDt) {
		this.scmApproveDt = scmApproveDt;
	}
	public String getStartDt() {
		return startDt;
	}
	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}
	public String getEndDt() {
		return endDt;
	}
	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}
	public String getPaymentDt() {
		return paymentDt;
	}
	public void setPaymentDt(String paymentDt) {
		this.paymentDt = paymentDt;
	}
	

}

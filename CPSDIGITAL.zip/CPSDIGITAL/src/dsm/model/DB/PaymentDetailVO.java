package dsm.model.DB;

public class PaymentDetailVO {

	private int paymentId;
	private int schemeId;
	private String schemeName;
	private int compId;
	private String compName;
	private float paymentAmt;
	private float totalEntity;
	private float maxPayment;
	private float minPayment;
	private float avgPayment;
	private String paymentUserId;
	private String insertDt;
	private String updateDt;
	private String startDt;
	private String endDt;
	private String paymentMode;
	private String paymentStatus;
	
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public float getPaymentAmt() {
		return paymentAmt;
	}
	public void setPaymentAmt(float paymentAmt) {
		this.paymentAmt = paymentAmt;
	}
	public float getTotalEntity() {
		return totalEntity;
	}
	public void setTotalEntity(float totalEntity) {
		this.totalEntity = totalEntity;
	}
	public float getMaxPayment() {
		return maxPayment;
	}
	public void setMaxPayment(float maxPayment) {
		this.maxPayment = maxPayment;
	}
	public float getMinPayment() {
		return minPayment;
	}
	public void setMinPayment(float minPayment) {
		this.minPayment = minPayment;
	}
	public float getAvgPayment() {
		return avgPayment;
	}
	public void setAvgPayment(float avgPayment) {
		this.avgPayment = avgPayment;
	}
	public String getPaymentUserId() {
		return paymentUserId;
	}
	public void setPaymentUserId(String paymentUserId) {
		this.paymentUserId = paymentUserId;
	}
	public String getInsertDt() {
		return insertDt;
	}
	public void setInsertDt(String insertDt) {
		this.insertDt = insertDt;
	}
	public String getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getStartDt() {
		return startDt;
	}
	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}
	public String getEndDt() {
		return endDt;
	}
	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}


}

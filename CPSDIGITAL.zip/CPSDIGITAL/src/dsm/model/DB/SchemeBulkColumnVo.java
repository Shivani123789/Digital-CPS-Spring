/**
 * 
 */
package dsm.model.DB;

/**
 * @author jeet_thakur
 * 
 */
public class SchemeBulkColumnVo {

	private int SheetNum;
	private String cellName;
	private int cellNum;
	private String cellType;
	private String dbDataType;
	private int fileId;
	private String dbColumnName;
	
	
	public int getSheetNum() {
		return SheetNum;
	}

	public void setSheetNum(int sheetNum) {
		SheetNum = sheetNum;
	}

	public String getCellName() {
		return cellName;
	}

	public void setCellName(String cellName) {
		this.cellName = cellName;
	}

	public int getCellNum() {
		return cellNum;
	}

	public void setCellNum(int cellNum) {
		this.cellNum = cellNum;
	}

	public String getCellType() {
		return cellType;
	}

	public void setCellType(String cellType) {
		this.cellType = cellType;
	}

	public String getDbDataType() {
		return dbDataType;
	}

	public void setDbDataType(String dbDataType) {
		this.dbDataType = dbDataType;
	}

	public int getFileId() {
		return fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getDbColumnName() {
		return dbColumnName;
	}

	public void setDbColumnName(String dbColumnName) {
		this.dbColumnName = dbColumnName;
	}

}

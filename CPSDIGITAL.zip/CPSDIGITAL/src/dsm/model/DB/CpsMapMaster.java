package dsm.model.DB;

public class CpsMapMaster {

	private String mapDescription;
	private int mapId;
	private String category;
	private String mapTableName;
	private int systemId;
	
	public String getMapDescription() {
		return mapDescription;
	}
	public void setMapDescription(String mapDescription) {
		this.mapDescription = mapDescription;
	}
	public int getMapId() {
		return mapId;
	}
	public void setMapId(int mapId) {
		this.mapId = mapId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getMapTableName() {
		return mapTableName;
	}
	public void setMapTableName(String mapTableName) {
		this.mapTableName = mapTableName;
	}
	public int getSystemId() {
		return systemId;
	}
	public void setSystemId(int systemId) {
		this.systemId = systemId;
	}
	
	
}

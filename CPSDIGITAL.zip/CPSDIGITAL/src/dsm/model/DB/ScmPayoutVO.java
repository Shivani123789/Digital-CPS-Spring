package dsm.model.DB;

import java.math.BigDecimal;

public class ScmPayoutVO {
	private int scmId;
	private int compId;
	private int reConfigId;
	private String scmName;
	private String compName;
	private String producerId;
	private String ftaNumber;
	private String vtopupNumber;
	private String payoutStatus;
	private String paymentStatus;
	private String startDt;
	private String endDt;
	private BigDecimal totalAmt;
	private BigDecimal amount;
	private BigDecimal holdAmt;
	private int payToId;
	private String payTo;
	private String paymentDt;
	private String paymentType;
	private String remarks;
	private String totalEntity;
	private BigDecimal netHoldAmt;
	
	public int getScmId() {
		return scmId;
	}
	public void setScmId(int scmId) {
		this.scmId = scmId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getReConfigId() {
		return reConfigId;
	}
	public void setReConfigId(int reConfigId) {
		this.reConfigId = reConfigId;
	}
	public String getScmName() {
		return scmName;
	}
	public void setScmName(String scmName) {
		this.scmName = scmName;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getProducerId() {
		return producerId;
	}
	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}
	public String getFtaNumber() {
		return ftaNumber;
	}
	public void setFtaNumber(String ftaNumber) {
		this.ftaNumber = ftaNumber;
	}
	public String getVtopupNumber() {
		return vtopupNumber;
	}
	public void setVtopupNumber(String vtopupNumber) {
		this.vtopupNumber = vtopupNumber;
	}
	public String getPayoutStatus() {
		return payoutStatus;
	}
	public void setPayoutStatus(String payoutStatus) {
		this.payoutStatus = payoutStatus;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	public String getStartDt() {
		return startDt;
	}
	public void setStartDt(String startDt) {
		this.startDt = startDt;
	}
	public String getEndDt() {
		return endDt;
	}
	public void setEndDt(String endDt) {
		this.endDt = endDt;
	}
	public BigDecimal getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(BigDecimal totalAmt) {
		this.totalAmt = totalAmt;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getHoldAmt() {
		return holdAmt;
	}
	public void setHoldAmt(BigDecimal holdAmt) {
		this.holdAmt = holdAmt;
	}
	public String getPayTo() {
		return payTo;
	}
	public void setPayTo(String payTo) {
		this.payTo = payTo;
	}
	public int getPayToId() {
		return payToId;
	}
	public void setPayToId(int payToId) {
		this.payToId = payToId;
	}
	public String getPaymentDt() {
		return paymentDt;
	}
	public void setPaymentDt(String paymentDt) {
		this.paymentDt = paymentDt;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getTotalEntity() {
		return totalEntity;
	}
	public void setTotalEntity(String totalEntity) {
		this.totalEntity = totalEntity;
	}
	public BigDecimal getNetHoldAmt() {
		return netHoldAmt;
	}
	public void setNetHoldAmt(BigDecimal netHoldAmt) {
		this.netHoldAmt = netHoldAmt;
	}
	
}

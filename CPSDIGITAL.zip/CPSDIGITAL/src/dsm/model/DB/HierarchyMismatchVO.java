package dsm.model.DB;

public class HierarchyMismatchVO {

	private String circleCode;
	private String hierarchyDate;
	private String systemsInvolved;
	private int retMissingFirstSys;
	private int retMissingSecondSys;
	private int dseMissingFirstSys;
	private int dseMissingSecondSys;
	private int distMissingFirstSys;
	private int distMissingSecondSys;
	private int tsmMissingFirstSys;
	private int tsmMissingSecondSys;
	private int asmMissingFirstSys;
	private int asmMissingSecondSys;
	private int zbmMissingFirstSys;
	private int zbmMissingSecondSys;
	private int shMissingFirstSys;
	private int shMissingSecondSys;
	private int chMissingFirstSys;
	private int chMissingSecondSys;
	private int retMgrMismatch;
	private int dseMgrMismatch;
	private int distMgrMismatch;
	private int tsmMgrMismatch;
	private int asmMgrMismatch;
	private int zbmMgrMismatch;
	private int shMgrMismatch;
	private int totalMissing;
	private int totalMismatch;
	
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public String getHierarchyDate() {
		return hierarchyDate;
	}
	public void setHierarchyDate(String hierarchyDate) {
		this.hierarchyDate = hierarchyDate;
	}
	public String getSystemsInvolved() {
		return systemsInvolved;
	}
	public void setSystemsInvolved(String systemsInvolved) {
		this.systemsInvolved = systemsInvolved;
	}
	public int getRetMissingFirstSys() {
		return retMissingFirstSys;
	}
	public void setRetMissingFirstSys(int retMissingFirstSys) {
		this.retMissingFirstSys = retMissingFirstSys;
	}
	public int getRetMissingSecondSys() {
		return retMissingSecondSys;
	}
	public void setRetMissingSecondSys(int retMissingSecondSys) {
		this.retMissingSecondSys = retMissingSecondSys;
	}
	public int getDseMissingFirstSys() {
		return dseMissingFirstSys;
	}
	public void setDseMissingFirstSys(int dseMissingFirstSys) {
		this.dseMissingFirstSys = dseMissingFirstSys;
	}
	public int getDseMissingSecondSys() {
		return dseMissingSecondSys;
	}
	public void setDseMissingSecondSys(int dseMissingSecondSys) {
		this.dseMissingSecondSys = dseMissingSecondSys;
	}
	public int getDistMissingFirstSys() {
		return distMissingFirstSys;
	}
	public void setDistMissingFirstSys(int distMissingFirstSys) {
		this.distMissingFirstSys = distMissingFirstSys;
	}
	public int getDistMissingSecondSys() {
		return distMissingSecondSys;
	}
	public void setDistMissingSecondSys(int distMissingSecondSys) {
		this.distMissingSecondSys = distMissingSecondSys;
	}
	public int getTsmMissingFirstSys() {
		return tsmMissingFirstSys;
	}
	public void setTsmMissingFirstSys(int tsmMissingFirstSys) {
		this.tsmMissingFirstSys = tsmMissingFirstSys;
	}
	public int getTsmMissingSecondSys() {
		return tsmMissingSecondSys;
	}
	public void setTsmMissingSecondSys(int tsmMissingSecondSys) {
		this.tsmMissingSecondSys = tsmMissingSecondSys;
	}
	public int getAsmMissingFirstSys() {
		return asmMissingFirstSys;
	}
	public void setAsmMissingFirstSys(int asmMissingFirstSys) {
		this.asmMissingFirstSys = asmMissingFirstSys;
	}
	public int getAsmMissingSecondSys() {
		return asmMissingSecondSys;
	}
	public void setAsmMissingSecondSys(int asmMissingSecondSys) {
		this.asmMissingSecondSys = asmMissingSecondSys;
	}
	public int getZbmMissingFirstSys() {
		return zbmMissingFirstSys;
	}
	public void setZbmMissingFirstSys(int zbmMissingFirstSys) {
		this.zbmMissingFirstSys = zbmMissingFirstSys;
	}
	public int getZbmMissingSecondSys() {
		return zbmMissingSecondSys;
	}
	public void setZbmMissingSecondSys(int zbmMissingSecondSys) {
		this.zbmMissingSecondSys = zbmMissingSecondSys;
	}
	public int getShMissingFirstSys() {
		return shMissingFirstSys;
	}
	public void setShMissingFirstSys(int shMissingFirstSys) {
		this.shMissingFirstSys = shMissingFirstSys;
	}
	public int getShMissingSecondSys() {
		return shMissingSecondSys;
	}
	public void setShMissingSecondSys(int shMissingSecondSys) {
		this.shMissingSecondSys = shMissingSecondSys;
	}
	public int getChMissingFirstSys() {
		return chMissingFirstSys;
	}
	public void setChMissingFirstSys(int chMissingFirstSys) {
		this.chMissingFirstSys = chMissingFirstSys;
	}
	public int getChMissingSecondSys() {
		return chMissingSecondSys;
	}
	public void setChMissingSecondSys(int chMissingSecondSys) {
		this.chMissingSecondSys = chMissingSecondSys;
	}
	public int getRetMgrMismatch() {
		return retMgrMismatch;
	}
	public void setRetMgrMismatch(int retMgrMismatch) {
		this.retMgrMismatch = retMgrMismatch;
	}
	public int getDseMgrMismatch() {
		return dseMgrMismatch;
	}
	public void setDseMgrMismatch(int dseMgrMismatch) {
		this.dseMgrMismatch = dseMgrMismatch;
	}
	public int getDistMgrMismatch() {
		return distMgrMismatch;
	}
	public void setDistMgrMismatch(int distMgrMismatch) {
		this.distMgrMismatch = distMgrMismatch;
	}
	public int getTsmMgrMismatch() {
		return tsmMgrMismatch;
	}
	public void setTsmMgrMismatch(int tsmMgrMismatch) {
		this.tsmMgrMismatch = tsmMgrMismatch;
	}
	public int getAsmMgrMismatch() {
		return asmMgrMismatch;
	}
	public void setAsmMgrMismatch(int asmMgrMismatch) {
		this.asmMgrMismatch = asmMgrMismatch;
	}
	public int getZbmMgrMismatch() {
		return zbmMgrMismatch;
	}
	public void setZbmMgrMismatch(int zbmMgrMismatch) {
		this.zbmMgrMismatch = zbmMgrMismatch;
	}
	public int getShMgrMismatch() {
		return shMgrMismatch;
	}
	public void setShMgrMismatch(int shMgrMismatch) {
		this.shMgrMismatch = shMgrMismatch;
	}
	public int getTotalMissing() {
		return totalMissing;
	}
	public void setTotalMissing(int totalMissing) {
		this.totalMissing = totalMissing;
	}
	public int getTotalMismatch() {
		return totalMismatch;
	}
	public void setTotalMismatch(int totalMismatch) {
		this.totalMismatch = totalMismatch;
	}
	
	
}

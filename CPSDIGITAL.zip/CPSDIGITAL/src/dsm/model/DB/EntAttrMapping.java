package dsm.model.DB;

import java.util.Date;

public class EntAttrMapping {

	private int id;
	private String attrType;
	private String functionFlag;
	private String srcTblName;
	private String srcTblField;
	private String displayName;
	private String covFlag;
	private String tqFlag;
	private String entAggFlag;
	private String payCondFlag;
	private String oprFlag;
	private String attrCatg;
	private String freeTxtType;
	private String valFlag;
	private Date updateTime;
	private Date insertTime;
	private String dataType;
	private int circleId;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAttrType() {
		return attrType;
	}
	public void setAttrType(String attrType) {
		this.attrType = attrType;
	}
	public String getSrcTblName() {
		return srcTblName;
	}
	public void setSrcTblName(String srcTblName) {
		this.srcTblName = srcTblName;
	}
	public String getSrcTblField() {
		return srcTblField;
	}
	public void setSrcTblField(String srcTblField) {
		this.srcTblField = srcTblField;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getCovFlag() {
		return covFlag;
	}
	public void setCovFlag(String covFlag) {
		this.covFlag = covFlag;
	}
	public String getTqFlag() {
		return tqFlag;
	}
	public void setTqFlag(String tqFlag) {
		this.tqFlag = tqFlag;
	}
	public String getEntAggFlag() {
		return entAggFlag;
	}
	public void setEntAggFlag(String entAggFlag) {
		this.entAggFlag = entAggFlag;
	}
	public String getPayCondFlag() {
		return payCondFlag;
	}
	public void setPayCondFlag(String payCondFlag) {
		this.payCondFlag = payCondFlag;
	}
	public String getOprFlag() {
		return oprFlag;
	}
	public void setOprFlag(String oprFlag) {
		this.oprFlag = oprFlag;
	}
	public String getAttrCatg() {
		return attrCatg;
	}
	public void setAttrCatg(String attrCatg) {
		this.attrCatg = attrCatg;
	}
	public String getFreeTxtType() {
		return freeTxtType;
	}
	public void setFreeTxtType(String freeTxtType) {
		this.freeTxtType = freeTxtType;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public String getFunctionFlag() {
		return functionFlag;
	}
	public void setFunctionFlag(String functionFlag) {
		this.functionFlag = functionFlag;
	}
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}

	
}

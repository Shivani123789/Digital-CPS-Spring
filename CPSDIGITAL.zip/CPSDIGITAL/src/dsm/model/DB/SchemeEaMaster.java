package dsm.model.DB;

import java.util.Date;


public class SchemeEaMaster {
	//DLP_SCM_EA_COND_CONFIG
	
	
	private String entityParameter;
	private String ValueListName;
	private String processType;
	private int condRowId;
	private int circleId;
	private int schemeId;
	private String schemeName;
	
	private int compId;
	private String compName;
	
	private int reConfigId;
	
	private int variableId;
	private String variableName;
	
	private int dataSet;
	private String dataSetName;
	
	//private int entityType;
	private String entityType;
	private String entityTypeName;
	private String entityTypeId;
	
	private String dataSourceCond;
	private String dataSourceVar;
	private int dataSource;
	private String dataSourceName;
	
	private int function;
	private String functionName;
	private String parameter;
	
	private int opr;
	private String oprName;
	private String valueType;
	private String value;
	private Date startDate;
	private Date endDate;
	
	private int filter;
	private String valFlag;
	private Date updateDate;
	private Date insertDate;
	private String colName;
	
	private int condId;
	private String varRowId;
	
	private String daylvlAggr;
	private int daylvlAggrId;
	//private int daylvlAggrId;
	
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getReConfigId() {
		return reConfigId;
	}
	public void setReConfigId(int reConfigId) {
		this.reConfigId = reConfigId;
	}
	public int getVariableId() {
		return variableId;
	}
	public void setVariableId(int variableId) {
		this.variableId = variableId;
	}
	public String getVariableName() {
		return variableName;
	}
	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}
	public int getDataSet() {
		return dataSet;
	}
	public void setDataSet(int dataSet) {
		this.dataSet = dataSet;
	}
	public String getEntityType() {
		return entityType;
	}
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}
	public int getDataSource() {
		return dataSource;
	}
	public void setDataSource(int dataSource) {
		this.dataSource = dataSource;
	}
	public int getFunction() {
		return function;
	}
	public void setFunction(int function) {
		this.function = function;
	}
	public String getParameter() {
		return parameter;
	}
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	public int getOpr() {
		return opr;
	}
	public void setOpr(int opr) {
		this.opr = opr;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getFilter() {
		return filter;
	}
	public void setFilter(int filter) {
		this.filter = filter;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	public int getCondId() {
		return condId;
	}
	public void setCondId(int condId) {
		this.condId = condId;
	}
	public String getVarRowId() {
		return varRowId;
	}
	public void setVarRowId(String varRowId) {
		this.varRowId = varRowId;
	}
	
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}

	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}

	public String getDataSetName() {
		return dataSetName;
	}
	public void setDataSetName(String dataSetName) {
		this.dataSetName = dataSetName;
	}

	public String getEntityTypeName() {
		return entityTypeName;
	}
	public void setEntityTypeName(String entityTypeName) {
		this.entityTypeName = entityTypeName;
	}

	public String getDataSourceName() {
		return dataSourceName;
	}
	public void setDataSourceName(String dataSourceName) {
		this.dataSourceName = dataSourceName;
	}

	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public String getOprName() {
		return oprName;
	}
	public void setOprName(String oprName) {
		this.oprName = oprName;
	}
	
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}

	public String getDataSourceCond() {
		return dataSourceCond;
	}
	public void setDataSourceCond(String dataSourceCond) {
		this.dataSourceCond = dataSourceCond;
	}

	public String getDataSourceVar() {
		return dataSourceVar;
	}
	public void setDataSourceVar(String dataSourceVar) {
		this.dataSourceVar = dataSourceVar;
	}

	public String getValueListName() {
		return ValueListName;
	}
	public void setValueListName(String valueListName) {
		ValueListName = valueListName;
	}

	public String getEntityParameter() {
		return entityParameter;
	}
	public void setEntityParameter(String entityParameter) {
		this.entityParameter = entityParameter;
	}

	public int getCondRowId() {
		return condRowId;
	}
	public void setCondRowId(int condRowId) {
		this.condRowId = condRowId;
	}
	public String getEntityTypeId() {
		return entityTypeId;
	}
	public void setEntityTypeId(String entityTypeId) {
		this.entityTypeId = entityTypeId;
	}
	public String getDaylvlAggr() {
		return daylvlAggr;
	}
	public void setDaylvlAggr(String daylvlAggr) {
		this.daylvlAggr = daylvlAggr;
	}
	public int getDaylvlAggrId() {
		return daylvlAggrId;
	}
	public void setDaylvlAggrId(int daylvlAggrId) {
		this.daylvlAggrId = daylvlAggrId;
	}


	
}

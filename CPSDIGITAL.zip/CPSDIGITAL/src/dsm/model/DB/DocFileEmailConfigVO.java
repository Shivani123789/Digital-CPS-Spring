package dsm.model.DB;

import java.math.BigDecimal;
import java.sql.Clob;
import java.sql.SQLException;
import java.util.Date;

public class DocFileEmailConfigVO {
	
	private int circleId;      
	private String sender;
	private String mailFileName; 
	private String circleCode;
	private String dsmRefCode; 
	private String recipients; 
	private String ccRecipients; 
	private String emailSubject; 
	private String emailContent;          
	private String attachmentFlag;   
	private String attachmentPath; 
	private String sendStatus;
	private Date sendDateTime;          
	private String validityFlag;   
	private Date updateDateTime;          
	private Date insertDateTime;
	private Clob clobEmailContent;
	private String responseStatus;
	private String remarks;
	private BigDecimal recordSeqNo;
	
	
	
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getSender() {
		return sender;
	}
	public void setSender(String sender) {
		this.sender = sender;
	}
	public String getRecipients() {
		return recipients;
	}
	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}
	public String getCcRecipients() {
		return ccRecipients;
	}
	public void setCcRecipients(String ccRecipients) {
		this.ccRecipients = ccRecipients;
	}
	public String getEmailSubject() {
		return emailSubject;
	}
	public void setEmailSubject(String emailSubject) {
		this.emailSubject = emailSubject;
	}
	public String getEmailContent() {
		if(clobEmailContent!=null){
			try {
				emailContent = clobEmailContent.getSubString(1, (int)clobEmailContent.length());
			} catch (SQLException e) {
				e.printStackTrace();
				return null;
			}
		}
		return emailContent;
	}
	public void setEmailContent(String emailContent) {
		this.emailContent = emailContent;
	}
	public String getAttachmentFlag() {
		return attachmentFlag;
	}
	public void setAttachmentFlag(String attachmentFlag) {
		this.attachmentFlag = attachmentFlag;
	}
	public String getAttachmentPath() {
		return attachmentPath;
	}
	public void setAttachmentPath(String attachmentPath) {
		this.attachmentPath = attachmentPath;
	}
	public String getSendStatus() {
		return sendStatus;
	}
	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}
	public Date getSendDateTime() {
		return sendDateTime;
	}
	public void setSendDateTime(Date sendDateTime) {
		this.sendDateTime = sendDateTime;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public Date getUpdateDateTime() {
		return updateDateTime;
	}
	public void setUpdateDateTime(Date updateDateTime) {
		this.updateDateTime = updateDateTime;
	}
	public Date getInsertDateTime() {
		return insertDateTime;
	}
	public void setInsertDateTime(Date insertDateTime) {
		this.insertDateTime = insertDateTime;
	}
	public Clob getClobEmailContent() {
		return clobEmailContent;
	}
	public void setClobEmailContent(Clob clobEmailContent) {
		this.clobEmailContent = clobEmailContent;
	}
	public String getResponseStatus() {
		return responseStatus;
	}
	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public String getMailFileName() {
		return mailFileName;
	}
	public void setMailFileName(String mailFileName) {
		this.mailFileName = mailFileName;
	}
	public String getDsmRefCode() {
		return dsmRefCode;
	}
	public void setDsmRefCode(String dsmRefCode) {
		this.dsmRefCode = dsmRefCode;
	}
	public BigDecimal getRecordSeqNo() {
		return recordSeqNo;
	}
	public void setRecordSeqNo(BigDecimal recordSeqNo) {
		this.recordSeqNo = recordSeqNo;
	}
}

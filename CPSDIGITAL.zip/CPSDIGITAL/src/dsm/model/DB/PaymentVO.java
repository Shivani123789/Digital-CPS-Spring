package dsm.model.DB;

public class PaymentVO {


	private int paymentId;
	private int payTo;
	private String paymentType;
	private String paymentDt;
	private String paymentFile;
	private String paidBy;
	private float paymentAmt;
	private String paymentremarks;
	private String validityFlag;
	private String updateDt;
	private String insertDt;
	private String displayValue;
	private int totalCount;
	private int countEntity;
	private int countScheme;
	
	public int getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}
	public int getPayTo() {
		return payTo;
	}
	public void setPayTo(int payTo) {
		this.payTo = payTo;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPaymentDt() {
		return paymentDt;
	}
	public void setPaymentDt(String paymentDt) {
		this.paymentDt = paymentDt;
	}
	public String getPaymentFile() {
		return paymentFile;
	}
	public void setPaymentFile(String paymentFile) {
		this.paymentFile = paymentFile;
	}
	public String getPaidBy() {
		return paidBy;
	}
	public void setPaidBy(String paidBy) {
		this.paidBy = paidBy;
	}
	public float getPaymentAmt() {
		return paymentAmt;
	}
	public void setPaymentAmt(float paymentAmt) {
		this.paymentAmt = paymentAmt;
	}
	public String getPaymentremarks() {
		return paymentremarks;
	}
	public void setPaymentremarks(String paymentremarks) {
		this.paymentremarks = paymentremarks;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public String getUpdateDt() {
		return updateDt;
	}
	public void setUpdateDt(String updateDt) {
		this.updateDt = updateDt;
	}
	public String getInsertDt() {
		return insertDt;
	}
	public void setInsertDt(String insertDt) {
		this.insertDt = insertDt;
	}
	public String getDisplayValue() {
		return displayValue;
	}
	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public int getCountEntity() {
		return countEntity;
	}
	public void setCountEntity(int countEntity) {
		this.countEntity = countEntity;
	}
	public int getCountScheme() {
		return countScheme;
	}
	public void setCountScheme(int countScheme) {
		this.countScheme = countScheme;
	}

	

}

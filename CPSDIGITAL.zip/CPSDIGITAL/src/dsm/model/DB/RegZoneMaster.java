package dsm.model.DB;

import java.util.Date;

public class RegZoneMaster {
	
	
	private int covRegZoneId;
	private int covRegZoneSerialId;
	
	private int schemeId;
	private String schemeName;
	private int compId;
	private String compName;
	private int circleId;
	private int regionId;
	private String regionDesc;
	private String zoneDesc;
	private int zoneId;
	private String valFlag;
	private String userId;
	private Date updateTime;
	private Date insertTime;
	public int getCovRegZoneId() {
		return covRegZoneId;
	}
	public void setCovRegZoneId(int covRegZoneId) {
		this.covRegZoneId = covRegZoneId;
	}
	public int getCovRegZoneSerialId() {
		return covRegZoneSerialId;
	}
	public void setCovRegZoneSerialId(int covRegZoneSerialId) {
		this.covRegZoneSerialId = covRegZoneSerialId;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public int getRegionId() {
		return regionId;
	}
	public void setRegionId(int i) {
		this.regionId = i;
	}
	public int getZoneId() {
		return zoneId;
	}
	public void setZoneId(int zoneId) {
		this.zoneId = zoneId;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public Date getInsertTime() {
		return insertTime;
	}
	public void setInsertTime(Date insertTime) {
		this.insertTime = insertTime;
	}
	public String getRegionDesc() {
		return regionDesc;
	}
	public void setRegionDesc(String regionDesc) {
		this.regionDesc = regionDesc;
	}
	public String getZoneDesc() {
		return zoneDesc;
	}
	public void setZoneDesc(String zoneDesc) {
		this.zoneDesc = zoneDesc;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	
		
}

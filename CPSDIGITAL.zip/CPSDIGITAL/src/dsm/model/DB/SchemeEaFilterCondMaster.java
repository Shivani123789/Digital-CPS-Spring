package dsm.model.DB;

import java.util.Date;

public class SchemeEaFilterCondMaster {
	//DLP_SCM_TQ_COND_CONFIG
	
	private String ValueListName;
	private String processType;
	private int circleId;
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getReConfigId() {
		return reConfigId;
	}
	public void setReConfigId(int reConfigId) {
		this.reConfigId = reConfigId;
	}
	public int getVariableId() {
		return variableId;
	}
	public void setVariableId(int variableId) {
		this.variableId = variableId;
	}
	
	public int getDataSet() {
		return dataSet;
	}
	public void setDataSet(int dataSet) {
		this.dataSet = dataSet;
	}
	
	public String getParameter() {
		return parameter;
	}
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	public int getOpr() {
		return opr;
	}
	public void setOpr(int opr) {
		this.opr = opr;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	
	public int getVariableRowId() {
		return variableRowId;
	}
	public void setVariableRowId(int variableRowId) {
		this.variableRowId = variableRowId;
	}
	public int getrOpr() {
		return rOpr;
	}
	public void setrOpr(int rOpr) {
		this.rOpr = rOpr;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getVariableName() {
		return variableName;
	}
	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getDataSetName() {
		return dataSetName;
	}
	public void setDataSetName(String dataSetName) {
		this.dataSetName = dataSetName;
	}
	public String getRoprName() {
		return roprName;
	}
	public void setRoprName(String roprName) {
		this.roprName = roprName;
	}
	public String getOprName() {
		return oprName;
	}
	public void setOprName(String oprName) {
		this.oprName = oprName;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getValueListName() {
		return ValueListName;
	}
	public void setValueListName(String valueListName) {
		ValueListName = valueListName;
	}
	private int schemeId;
	private String schemeName;
	private int compId;
	private int reConfigId;
	private int variableId;
	private String variableName;
	private int variableRowId;
	private int dataSet;
	private String dataSetName;
	private String parameter;
	private int opr;
	private String oprName;
	private String valueType;
	private String value;
	private Date startDate;
	private Date endDate;
	private int rOpr;
	private String roprName;
	private String valFlag;
	private Date updateDate;
	private Date insertDate;
	private String compName;
	
	
}

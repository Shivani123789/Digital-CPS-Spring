package dsm.model.DB;


public class ExecPayoutStatusVO {

	private int circleId;
	private int schemeId;
	private int compId;
	private int configId;
	private int configTypeId;
	private int conVarId;
	private int tableId;
	private String tableName;
	private String startDT;
	private String endDT;
	private String insertDT;
	private String schemeName;
	private String compName;
	private String circleName;
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getConfigId() {
		return configId;
	}
	public void setConfigId(int configId) {
		this.configId = configId;
	}
	public int getConfigTypeId() {
		return configTypeId;
	}
	public void setConfigTypeId(int configTypeId) {
		this.configTypeId = configTypeId;
	}
	public int getConVarId() {
		return conVarId;
	}
	public void setConVarId(int conVarId) {
		this.conVarId = conVarId;
	}
	public int getTableId() {
		return tableId;
	}
	public void setTableId(int tableId) {
		this.tableId = tableId;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getStartDT() {
		return startDT;
	}
	public void setStartDT(String startDT) {
		this.startDT = startDT;
	}
	public String getEndDT() {
		return endDT;
	}
	public void setEndDT(String endDT) {
		this.endDT = endDT;
	}
	public String getInsertDT() {
		return insertDT;
	}
	public void setInsertDT(String insertDT) {
		this.insertDT = insertDT;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getCircleName() {
		return circleName;
	}
	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}
	
	
	
}

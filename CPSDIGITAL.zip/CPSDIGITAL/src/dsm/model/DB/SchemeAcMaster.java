package dsm.model.DB;

import java.util.Date;


public class SchemeAcMaster {

		//DLP_SCM_CO_COND_CONFIG
		
		private String processType;
		
		private int schemeId;
		private String schemeName;
		private int circleId;
		private int compId;
		
		private String compName;
		
		private int reConfigId;
		
		private int condId;
		
		private int condRowId;
		
		private int entityId;
		private String entityName;
		
		private int attrType;
		private String attrTypeName;
		
		private int function;
		private String functionName;
		
		private int attrName;
		private String attrMappingName;
		
		private int opr;
		private String oprName;
		
		private int co_ValueType;
		private String co_ValueTypeName;
		
		private int co_vFunction;
		public String getLfunctionName() {
			return lfunctionName;
		}
		public void setLfunctionName(String lfunctionName) {
			this.lfunctionName = lfunctionName;
		}
		public String getLattNameString() {
			return lattNameString;
		}
		public void setLattNameString(String lattNameString) {
			this.lattNameString = lattNameString;
		}
		public String getLloprName() {
			return lloprName;
		}
		public void setLloprName(String lloprName) {
			this.lloprName = lloprName;
		}
		public String getLvalueTypeName() {
			return lvalueTypeName;
		}
		public void setLvalueTypeName(String lvalueTypeName) {
			this.lvalueTypeName = lvalueTypeName;
		}
		public String getLvfunctionName() {
			return lvfunctionName;
		}
		public void setLvfunctionName(String lvfunctionName) {
			this.lvfunctionName = lvfunctionName;
		}
		public String getLvalueName() {
			return lvalueName;
		}
		public void setLvalueName(String lvalueName) {
			this.lvalueName = lvalueName;
		}
		private String co_functionName;
		
		//private String valueField;
		private String value;
		private String ValueListName;
		public String getValue() {
			return value;
		}
		public void setValue(String value) {
			this.value = value;
		}
		
		private Date startDate;
		
		private Date endDate;
		
		private int Lopr;
		private String loprName;
		
		private int lEntityType;
		private String lentityTypeName;
		
		private int lAttrType;
		private String lattrTypeName;
		
		private int lFunction;
		private String lfunctionName;
		
		private int lAttName;
		private String lattNameString;
		
		private int lOpr;
		private String lloprName;
		private int lValueType;
		private String lvalueTypeName;
		private int lVfunction;
		private String lvfunctionName;
		private String lValue;
		private String LvalueListName;
		private String lvalueName;
		private Date lStartDate;
		private Date lEndDate;
		private int rOpr;
		private String roprName;
		private String valFlag;
		private Date updateDate;
		private Date insertDate;
		public int getLopr() {
			return Lopr;
		}
		public void setLopr(int lopr) {
			Lopr = lopr;
		}
		public int getlEntityType() {
			return lEntityType;
		}
		public void setlEntityType(int lEntityType) {
			this.lEntityType = lEntityType;
		}
		public int getlAttrType() {
			return lAttrType;
		}
		public void setlAttrType(int lAttrType) {
			this.lAttrType = lAttrType;
		}
		public int getlFunction() {
			return lFunction;
		}
		public void setlFunction(int lFunction) {
			this.lFunction = lFunction;
		}
		public int getlAttName() {
			return lAttName;
		}
		public void setlAttName(int lAttName) {
			this.lAttName = lAttName;
		}
		public int getlOpr() {
			return lOpr;
		}
		public void setlOpr(int lOpr) {
			this.lOpr = lOpr;
		}
		public int getlValueType() {
			return lValueType;
		}
		public void setlValueType(int lValueType) {
			this.lValueType = lValueType;
		}
		public int getlVfunction() {
			return lVfunction;
		}
		public void setlVfunction(int lVfunction) {
			this.lVfunction = lVfunction;
		}
		public String getlValue() {
			return lValue;
		}
		public void setlValue(String lValue) {
			this.lValue = lValue;
		}
		public Date getlStartDate() {
			return lStartDate;
		}
		public void setlStartDate(Date lStartDate) {
			this.lStartDate = lStartDate;
		}
		public Date getlEndDate() {
			return lEndDate;
		}
		public void setlEndDate(Date lEndDate) {
			this.lEndDate = lEndDate;
		}
		public int getrOpr() {
			return rOpr;
		}
		public void setrOpr(int rOpr) {
			this.rOpr = rOpr;
		}
		public String getValFlag() {
			return valFlag;
		}
		public void setValFlag(String valFlag) {
			this.valFlag = valFlag;
		}
		public Date getUpdateDate() {
			return updateDate;
		}
		public void setUpdateDate(Date updateDate) {
			this.updateDate = updateDate;
		}
		public Date getInsertDate() {
			return insertDate;
		}
		public void setInsertDate(Date insertDate) {
			this.insertDate = insertDate;
		}
		
		public int getAttrType() {
			return attrType;
		}
		public void setAttrType(int attrType) {
			this.attrType = attrType;
		}
		public int getFunction() {
			return function;
		}
		public void setFunction(int function) {
			this.function = function;
		}
		public int getAttrName() {
			return attrName;
		}
		public void setAttrName(int attrName) {
			this.attrName = attrName;
		}
		public int getOpr() {
			return opr;
		}
		public void setOpr(int opr) {
			this.opr = opr;
		}
		public int getCo_ValueType() {
			return co_ValueType;
		}
		public void setCo_ValueType(int co_ValueType) {
			this.co_ValueType = co_ValueType;
		}
		public int getCo_vFunction() {
			return co_vFunction;
		}
		public void setCo_vFunction(int co_vFunction) {
			this.co_vFunction = co_vFunction;
		}
		
		public Date getStartDate() {
			return startDate;
		}
		public void setStartDate(Date startDate) {
			this.startDate = startDate;
		}
		public Date getEndDate() {
			return endDate;
		}
		public void setEndDate(Date endDate) {
			this.endDate = endDate;
		}
		
		
		public String getProcessType() {
			return processType;
		}
		public void setProcessType(String processType) {
			this.processType = processType;
		}
		public int getSchemeId() {
			return schemeId;
		}
		public void setSchemeId(int schemeId) {
			this.schemeId = schemeId;
		}
		public int getCompId() {
			return compId;
		}
		public void setCompId(int compId) {
			this.compId = compId;
		}
		public int getReConfigId() {
			return reConfigId;
		}
		public void setReConfigId(int reConfigId) {
			this.reConfigId = reConfigId;
		}
		public int getCondId() {
			return condId;
		}
		public void setCondId(int condId) {
			this.condId = condId;
		}
		public int getCondRowId() {
			return condRowId;
		}
		public void setCondRowId(int condRowId) {
			this.condRowId = condRowId;
		}
		public int getEntityId() {
			return entityId;
		}
		public void setEntityId(int entityId) {
			this.entityId = entityId;
		}
		
		public String getCompName() {
			return compName;
		}
		public void setCompName(String compName) {
			this.compName = compName;
		}
		public String getLoprName() {
			return loprName;
		}
		public void setLoprName(String loprName) {
			this.loprName = loprName;
		}
		public String getRoprName() {
			return roprName;
		}
		public void setRoprName(String roprName) {
			this.roprName = roprName;
		}
		public String getEntityName() {
			return entityName;
		}
		public void setEntityName(String entityName) {
			this.entityName = entityName;
		}
		public String getAttrTypeName() {
			return attrTypeName;
		}
		public void setAttrTypeName(String attrTypeName) {
			this.attrTypeName = attrTypeName;
		}
		public String getFunctionName() {
			return functionName;
		}
		public void setFunctionName(String functionName) {
			this.functionName = functionName;
		}
		public String getAttrMappingName() {
			return attrMappingName;
		}
		public void setAttrMappingName(String attrMappingName) {
			this.attrMappingName = attrMappingName;
		}
		public String getOprName() {
			return oprName;
		}
		public void setOprName(String oprName) {
			this.oprName = oprName;
		}
		public String getCo_ValueTypeName() {
			return co_ValueTypeName;
		}
		public void setCo_ValueTypeName(String co_ValueTypeName) {
			this.co_ValueTypeName = co_ValueTypeName;
		}
		public String getCo_functionName() {
			return co_functionName;
		}
		public void setCo_functionName(String co_functionName) {
			this.co_functionName = co_functionName;
		}
		
		public String getLentityTypeName() {
			return lentityTypeName;
		}
		public void setLentityTypeName(String lentityTypeName) {
			this.lentityTypeName = lentityTypeName;
		}
		public String getLattrTypeName() {
			return lattrTypeName;
		}
		public void setLattrTypeName(String lattrTypeName) {
			this.lattrTypeName = lattrTypeName;
		}
		public String getSchemeName() {
			return schemeName;
		}
		public void setSchemeName(String schemeName) {
			this.schemeName = schemeName;
		}
		public String getLvalueListName() {
			return LvalueListName;
		}
		public void setLvalueListName(String lvalueListName) {
			LvalueListName = lvalueListName;
		}
		public String getValueListName() {
			return ValueListName;
		}
		public void setValueListName(String valueListName) {
			ValueListName = valueListName;
		}
		public int getCircleId() {
			return circleId;
		}
		public void setCircleId(int circleId) {
			this.circleId = circleId;
		}
		
				
}

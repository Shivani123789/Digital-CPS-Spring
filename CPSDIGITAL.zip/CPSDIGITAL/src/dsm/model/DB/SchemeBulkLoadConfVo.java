/**
 * 
 */
package dsm.model.DB;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

@SuppressWarnings("serial")
public class SchemeBulkLoadConfVo extends ExceptionVo implements Serializable {

	
	private String confName;
	private String SheetName;
	private int SheetNum;
	private String procedureName;
	private int colReadCount;
	private int fileId;
	private int headerRows;
	private String loadingMethod;
	private String mappingTable;
	private String mappingTableConnectionPool;
	private String mappingFieldHeaderName;
	private String mappingFieldName;
	private String destinationTable;
	private String type;
	private String feedNumber;
	private String feedMapping;
	private Date startDate;
	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	private Date endDate;
	//Constant common columns. Table SCHEME_BULK_COLUMN_TEMP 
	private List<SchemeBulkColumnVo> cellValue;
	

	//Mapping Table fieldName
	private Map<String,String> fieldNames;
	private int fieldCount;
	private String mandatoryColumnNames;
	private Map<String,String> mandatoryFieldNames;
	private int mandatoryFieldCount;
	
	//File related Names
	private String fileHeaderNames;
	private int fileHeaderCount;
	private String fileFullName;
	private String fileNameDate;
	private String fileCircleCode;
	private String fileUniqueName;
	
	//
	private int paramNum;
	private String[] dbType;
	
	
	private String columnNames;
	private String mappingTableJndi;
	private ExceptionVo exceptionVo;

	public int getFileId() {
		return fileId;
	}

	public void setFileId(int fileId) {
		this.fileId = fileId;
	}

	public String getConfName() {
		return confName;
	}

	public void setConfName(String confName) {
		this.confName = confName;
	}

	public String getSheetName() {
		return SheetName;
	}

	public void setSheetName(String sheetName) {
		SheetName = sheetName;
	}

	public int getSheetNum() {
		return SheetNum;
	}

	public void setSheetNum(int sheetNum) {
		SheetNum = sheetNum;
	}

	public List<SchemeBulkColumnVo> getCellValue() {
		return cellValue;
	}

	public void setCellValue(List<SchemeBulkColumnVo> cellValue) {
		this.cellValue = cellValue;
	}

	public String getProcedureName() {
		return procedureName;
	}

	public void setProcedureName(String procedureName) {
		this.procedureName = procedureName;
	}

	public int getParamNum() {
		return paramNum;
	}

	public void setParamNum(int paramNum) {
		this.paramNum = paramNum;
	}

	public String[] getDbType() {
		return dbType;
	}

	public void setDbType(String[] dbType) {
		this.dbType = dbType;
	}

	public int getHeaderRows() {
		return headerRows;
	}

	public void setHeaderRows(int headerRows) {
		this.headerRows = headerRows;
	}

	public String getLoadingMethod() {
		return loadingMethod;
	}

	public void setLoadingMethod(String loadingMethod) {
		this.loadingMethod = loadingMethod;
	}

	public String getMappingTable() {
		return mappingTable;
	}

	public void setMappingTable(String mappingTable) {
		this.mappingTable = mappingTable;
	}

	public String getMappingTableJndi() {
		return mappingTableJndi;
	}

	public void setMappingTableJndi(String mappingTableJndi) {
		this.mappingTableJndi = mappingTableJndi;
	}

	public String getMappingFieldHeaderName() {
		return mappingFieldHeaderName;
	}

	public void setMappingFieldHeaderName(String mappingFieldHeaderName) {
		this.mappingFieldHeaderName = mappingFieldHeaderName;
	}

	public String getMappingFieldName() {
		return mappingFieldName;
	}

	public void setMappingFieldName(String mappingFieldName) {
		this.mappingFieldName = mappingFieldName;
	}

	public String getDestinationTable() {
		return destinationTable;
	}

	public void setDestinationTable(String destinationTable) {
		this.destinationTable = destinationTable;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public ExceptionVo getExceptionVo() {
		return exceptionVo;
	}

	public void setExceptionVo(ExceptionVo exceptionVo) {
		this.exceptionVo = exceptionVo;
	}

	public String getColumnNames() {
		return columnNames;
	}

	public void setColumnNames(String columnNames) {
		this.columnNames = columnNames;
	}

	public String getFeedNumber() {
		return feedNumber;
	}

	public void setFeedNumber(String feedNumber) {
		this.feedNumber = feedNumber;
	}

	public String getFeedMapping() {
		return feedMapping;
	}

	public void setFeedMapping(String feedMapping) {
		this.feedMapping = feedMapping;
	}

	public int getColReadCount() {
		return colReadCount;
	}

	public void setColReadCount(int colReadCount) {
		this.colReadCount = colReadCount;
	}

	public String getMappingTableConnectionPool() {
		return mappingTableConnectionPool;
	}

	public void setMappingTableConnectionPool(String mappingTableConnectionPool) {
		this.mappingTableConnectionPool = mappingTableConnectionPool;
	}

	public Map<String,String> getFieldNames() {
		return fieldNames;
	}

	public void setFieldNames(Map<String,String> fieldNames) {
		this.fieldNames = fieldNames;
	}

	public int getFieldCount() {
		return fieldCount;
	}

	public void setFieldCount(int fieldCount) {
		this.fieldCount = fieldCount;
	}

	public String getFileHeaderNames() {
		return fileHeaderNames;
	}

	public void setFileHeaderNames(String fileHeaderNames) {
		this.fileHeaderNames = fileHeaderNames;
	}

	public int getFileHeaderCount() {
		return fileHeaderCount;
	}

	public void setFileHeaderCount(int fileHeaderCount) {
		this.fileHeaderCount = fileHeaderCount;
	}

	public String getFileFullName() {
		return fileFullName;
	}

	public void setFileFullName(String fileFullName) {
		this.fileFullName = fileFullName;
	}

	public String getFileNameDate() {
		return fileNameDate;
	}

	public void setFileNameDate(String fileNameDate) {
		this.fileNameDate = fileNameDate;
	}

	public String getFileCircleCode() {
		return fileCircleCode;
	}

	public void setFileCircleCode(String fileCircleCode) {
		this.fileCircleCode = fileCircleCode;
	}

	public String getFileUniqueName() {
		return fileUniqueName;
	}

	public void setFileUniqueName(String fileUniqueName) {
		this.fileUniqueName = fileUniqueName;
	}

	public String getMandatoryColumnNames() {
		return mandatoryColumnNames;
	}

	public void setMandatoryColumnNames(String mandatoryColumnNames) {
		this.mandatoryColumnNames = mandatoryColumnNames;
	}

	public Map<String,String> getMandatoryFieldNames() {
		return mandatoryFieldNames;
	}

	public void setMandatoryFieldNames(Map<String,String> mandatoryFieldNames) {
		this.mandatoryFieldNames = mandatoryFieldNames;
	}

	public int getMandatoryFieldCount() {
		return mandatoryFieldCount;
	}

	public void setMandatoryFieldCount(int mandatoryFieldCount) {
		this.mandatoryFieldCount = mandatoryFieldCount;
	}

}
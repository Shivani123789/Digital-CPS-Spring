package dsm.model.DB;

public class DistributorVO {
	private String distributorMsisd;
	private float amount;
	private String remarks;
	private String region;
	private String zone;
	
	
	public String getDistributorMsisd() {
		return distributorMsisd;
	}
	public void setDistributorMsisd(String distributorMsisd) {
		this.distributorMsisd = distributorMsisd;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	
	
}

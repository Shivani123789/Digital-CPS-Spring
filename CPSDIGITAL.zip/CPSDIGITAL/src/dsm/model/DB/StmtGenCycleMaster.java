package dsm.model.DB;

public class StmtGenCycleMaster {
	
	private int stmtCycleId;
	private String cycle;
	private String startEndDt;
	private String cycleStatus;
	private String stmtDt;
	private int noOfStmt;
	private String stmtMonth;
	private String stmtGenStatus;
	private int countId;
	private String cycleEndDt;
	
	public String getCycle() {
		return cycle;
	}
	public void setCycle(String cycle) {
		this.cycle = cycle;
	}
	public String getStartEndDt() {
		return startEndDt;
	}
	public void setStartEndDt(String startEndDt) {
		this.startEndDt = startEndDt;
	}
	public String getCycleStatus() {
		return cycleStatus;
	}
	public void setCycleStatus(String cycleStatus) {
		this.cycleStatus = cycleStatus;
	}
	public String getStmtDt() {
		return stmtDt;
	}
	public void setStmtDt(String stmtDt) {
		this.stmtDt = stmtDt;
	}
	public int getNoOfStmt() {
		return noOfStmt;
	}
	public void setNoOfStmt(int noOfStmt) {
		this.noOfStmt = noOfStmt;
	}
	public String getStmtMonth() {
		return stmtMonth;
	}
	public void setStmtMonth(String stmtMonth) {
		this.stmtMonth = stmtMonth;
	}
	public int getStmtCycleId() {
		return stmtCycleId;
	}
	public void setStmtCycleId(int stmtCycleId) {
		this.stmtCycleId = stmtCycleId;
	}
	public String getStmtGenStatus() {
		return stmtGenStatus;
	}
	public void setStmtGenStatus(String stmtGenStatus) {
		this.stmtGenStatus = stmtGenStatus;
	}
	public int getCountId() {
		return countId;
	}
	public void setCountId(int countId) {
		this.countId = countId;
	}
	public String getCycleEndDt() {
		return cycleEndDt;
	}
	public void setCycleEndDt(String cycleEndDt) {
		this.cycleEndDt = cycleEndDt;
	}
	
	
}

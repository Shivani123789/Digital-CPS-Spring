package dsm.model.DB;

import java.math.BigDecimal;
import java.util.List;

public class PartnerChannelStatementPojo {

	private String circle;
	private int stmtCycleId; 
	private String stmtNo;
	private String stmtDt;
	private String cycleDt; 
	private String cpId;
	private String cpName;
	private String partnerType; 
	private String mobileNo;
	private String panNo;
	private String email; 
	private String address;
	private String country;
	private String contractEndDt; 
	private int scmListId;
	private BigDecimal grandTotal ;
	private String amtWords; 
	private String beneficiary;
	private String accountNo;
	private String bankName; 
	private String ifscCode;
	private String bankBranch;
	private BigDecimal totGrossAmt ; 
	private BigDecimal  totNetAmt;
	private String strNo;
	private String applicationName;
	private int totalCount;
	private List<PartnerChannelStmtScmListPojo> monthScmList;
	
	
	public String getCircle() {
		return circle;
	}
	public void setCircle(String circle) {
		this.circle = circle;
	}
	public int getStmtCycleId() {
		return stmtCycleId;
	}
	public void setStmtCycleId(int stmtCycleId) {
		this.stmtCycleId = stmtCycleId;
	}
	public String getStmtNo() {
		return stmtNo;
	}
	public void setStmtNo(String stmtNo) {
		this.stmtNo = stmtNo;
	}
	public String getStmtDt() {
		return stmtDt;
	}
	public void setStmtDt(String stmtDt) {
		this.stmtDt = stmtDt;
	}
	public String getCycleDt() {
		return cycleDt;
	}
	public void setCycleDt(String cycleDt) {
		this.cycleDt = cycleDt;
	}
	public String getCpId() {
		return cpId;
	}
	public void setCpId(String cpId) {
		this.cpId = cpId;
	}
	public String getCpName() {
		return cpName;
	}
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}
	public String getPartnerType() {
		return partnerType;
	}
	public void setPartnerType(String partnerType) {
		this.partnerType = partnerType;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getContractEndDt() {
		return contractEndDt;
	}
	public void setContractEndDt(String contractEndDt) {
		this.contractEndDt = contractEndDt;
	}
	public int getScmListId() {
		return scmListId;
	}
	public void setScmListId(int scmListId) {
		this.scmListId = scmListId;
	}
	public BigDecimal getGrandTotal() {
		return grandTotal;
	}
	public void setGrandTotal(BigDecimal grandTotal) {
		this.grandTotal = grandTotal;
	}
	public String getAmtWords() {
		return amtWords;
	}
	public void setAmtWords(String amtWords) {
		this.amtWords = amtWords;
	}
	public String getBeneficiary() {
		return beneficiary;
	}
	public void setBeneficiary(String beneficiary) {
		this.beneficiary = beneficiary;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public String getBankBranch() {
		return bankBranch;
	}
	public void setBankBranch(String bankBranch) {
		this.bankBranch = bankBranch;
	}
	public BigDecimal getTotGrossAmt() {
		return totGrossAmt;
	}
	public void setTotGrossAmt(BigDecimal totGrossAmt) {
		this.totGrossAmt = totGrossAmt;
	}
	public BigDecimal getTotNetAmt() {
		return totNetAmt;
	}
	public void setTotNetAmt(BigDecimal totNetAmt) {
		this.totNetAmt = totNetAmt;
	}
	public String getStrNo() {
		return strNo;
	}
	public void setStrNo(String strNo) {
		this.strNo = strNo;
	}
	public String getApplicationName() {
		return applicationName;
	}
	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}
	public List<PartnerChannelStmtScmListPojo> getMonthScmList() {
		return monthScmList;
	}
	public void setMonthScmList(List<PartnerChannelStmtScmListPojo> monthScmList) {
		this.monthScmList = monthScmList;
	}
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	
	
	
}
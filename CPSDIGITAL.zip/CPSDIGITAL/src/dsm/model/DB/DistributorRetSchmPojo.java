package dsm.model.DB;

import java.math.BigDecimal;

/**
 * @author jeet_thakur
 * 
 */
public class DistributorRetSchmPojo {

	private int schemeListId;
	private BigDecimal payTotal;
	//private float refTotal;
	private BigDecimal grossPayAmt;
	private float netComm;
	private BigDecimal tdsAmount;
	private int sheetId;
	private int componentId;
	//private String target;
	//private String achivedPerc;
	private String schemeCompDesc;
	private String unit;
	private BigDecimal rate;
	

	public int getSchemeListId() {
		return schemeListId;
	}

	public void setSchemeListId(int schemeListId) {
		this.schemeListId = schemeListId;
	}

	public BigDecimal getPayTotal() {
		return payTotal;
	}

	public void setPayTotal(BigDecimal payTotal) {
		this.payTotal = payTotal;
	}

	/*public float getRefTotal() {
		return refTotal;
	}

	public void setRefTotal(float refTotal) {
		this.refTotal = refTotal;
	}*/

	public BigDecimal getGrossPayAmt() {
		return grossPayAmt;
	}

	public void setGrossPayAmt(BigDecimal grossPayAmt) {
		this.grossPayAmt = grossPayAmt;
	}

	public float getNetComm() {
		return netComm;
	}

	public void setNetComm(float netComm) {
		this.netComm = netComm;
	}

	public BigDecimal getTdsAmount() {
		return tdsAmount;
	}

	public void setTdsAmount(BigDecimal tdsAmount) {
		this.tdsAmount = tdsAmount;
	}

	public int getSheetId() {
		return sheetId;
	}

	public void setSheetId(int sheetId) {
		this.sheetId = sheetId;
	}

	public int getComponentId() {
		return componentId;
	}

	public void setComponentId(int componentId) {
		this.componentId = componentId;
	}

	/*public String getTarget() {
		return target;
	}

	public void setTarget(String target) {
		this.target = target;
	}

	public String getAchivedPerc() {
		return achivedPerc;
	}

	public void setAchivedPerc(String achivedPerc) {
		this.achivedPerc = achivedPerc;
	}*/

	public String getSchemeCompDesc() {
		return schemeCompDesc;
	}

	public void setSchemeCompDesc(String schemeCompDesc) {
		this.schemeCompDesc = schemeCompDesc;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public BigDecimal getRate() {
		return rate;
	}

	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}

}
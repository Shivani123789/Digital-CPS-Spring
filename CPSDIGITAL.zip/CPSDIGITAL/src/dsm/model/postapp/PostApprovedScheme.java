package dsm.model.postapp;

import java.util.Date;

public class PostApprovedScheme {

	//DLP_SCHEME_MASTER
	
	private int schemeId;
	private int reConfingId;
	private int circleId;
	private String userCode;
	private String schemeName;
	private String aaprovedBy;
	private String approvedStatus;
	private String approvedRemarks;
	private Date approvedDate;
	private Date execDate;
	private int compId;
	private String compName;
	
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	
	
	public int getReConfingId() {
		return reConfingId;
	}
	public void setReConfingId(int reConfingId) {
		this.reConfingId = reConfingId;
	}


	public String getAaprovedBy() {
		return aaprovedBy;
	}
	public void setAaprovedBy(String aaprovedBy) {
		this.aaprovedBy = aaprovedBy;
	}


	public String getApprovedStatus() {
		return approvedStatus;
	}
	public void setApprovedStatus(String approvedStatus) {
		this.approvedStatus = approvedStatus;
	}


	public String getApprovedRemarks() {
		return approvedRemarks;
	}
	public void setApprovedRemarks(String approvedRemarks) {
		this.approvedRemarks = approvedRemarks;
	}


	public Date getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}


	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}


	public Date getExecDate() {
		return execDate;
	}
	public void setExecDate(Date execDate) {
		this.execDate = execDate;
	}


	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getUserCode() {
		return userCode;
	}
	public void setUserCode(String userCode) {
		this.userCode = userCode;
	}


	
}

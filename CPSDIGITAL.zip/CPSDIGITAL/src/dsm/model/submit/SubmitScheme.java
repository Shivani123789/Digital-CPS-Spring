package dsm.model.submit;

import java.util.Date;

public class SubmitScheme {

	//DLP_SCHEME_MASTER
	
	private int schemeINputId;
	
	private String userName;
	public int getSchemeINputId() {
		return schemeINputId;
	}
	public void setSchemeINputId(int schemeINputId) {
		this.schemeINputId = schemeINputId;
	}
	
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	
	public Date getSubmitDate() {
		return submitDate;
	}
	public void setSubmitDate(Date submitDate) {
		this.submitDate = submitDate;
	}


	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}


	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}


	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}


	private int circleId;
	private String schemeName;
	private String desc;
	private Date startDate;
	private Date endDate;
	private String validityFlag;
	private int userId;
	private Date submitDate;
	private int compId;
	private String circleCode;
}

package dsm.model.report;


import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import dsm.model.DB.SchemeMaster;

public class ReportGenerateMaster {

	private int schemeId;
	private String SchemeName;
	private String circleName;
	private String csvType;
	private String versionNo;
	private String approvedBy;
	private String rejectedBy;
	private String approvedDt;
	private String rejectedDt;
	private String payoutApprovedBy;
	private String payoutApprovedDt;
	private BigDecimal totalNetAmount;
	private BigDecimal totalGrossAmount;
	private BigDecimal headCount;
	private String payToDesc;
	private int categoryId;
	private String categoryName;
	private int reportId;
	private String reportName;
	private int reportInputCategory;
	private int reportGenType;
	private Date reportLastGenDateTime;
	private int duration;
	private int scmCategoryId;
	private String scmCategoryName;
	
	
	public int getScmCategoryId() {
		return scmCategoryId;
	}
	public void setScmCategoryId(int scmCategoryId) {
		this.scmCategoryId = scmCategoryId;
	}
	public String getScmCategoryName() {
		return scmCategoryName;
	}
	public void setScmCategoryName(String scmCategoryName) {
		this.scmCategoryName = scmCategoryName;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public Date getReportLastGenDateTime() {
		return reportLastGenDateTime;
	}
	public void setReportLastGenDateTime(Date reportLastGenDateTime) {
		this.reportLastGenDateTime = reportLastGenDateTime;
	}
	
	public int getCategoryId() {
		return categoryId;
	}
	public int getReportId() {
		return reportId;
	}
	public void setReportId(int reportId) {
		this.reportId = reportId;
	}
	public String getReportName() {
		return reportName;
	}
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}
	public int getReportInputCategory() {
		return reportInputCategory;
	}
	public void setReportInputCategory(int reportInputCategory) {
		this.reportInputCategory = reportInputCategory;
	}
	public int getReportGenType() {
		return reportGenType;
	}
	public void setReportGenType(int reportGenType) {
		this.reportGenType = reportGenType;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	private String userId;
	private String insertDt;
	
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getRejectedBy() {
		return rejectedBy;
	}
	public void setRejectedBy(String rejectedBy) {
		this.rejectedBy = rejectedBy;
	}
	public String getApprovedDt() {
		return approvedDt;
	}
	public void setApprovedDt(String approvedDt) {
		this.approvedDt = approvedDt;
	}
	public String getRejectedDt() {
		return rejectedDt;
	}
	public void setRejectedDt(String rejectedDt) {
		this.rejectedDt = rejectedDt;
	}
	private List<SchemeMaster> schemeMaster;
	private List<ComponentListReport> componentListReport;
	private List<Appendix> appendix;
	
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public String getSchemeName() {
		return SchemeName;
	}
	public void setSchemeName(String schemeName) {
		SchemeName = schemeName;
	}
	public String getCircleName() {
		return circleName;
	}
	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}
	public List<SchemeMaster> getSchemeMaster() {
		return schemeMaster;
	}
	public void setSchemeMaster(List<SchemeMaster> schemeMaster) {
		this.schemeMaster = schemeMaster;
	}
	public List<ComponentListReport> getComponentListReport() {
		return componentListReport;
	}
	public void setComponentListReport(List<ComponentListReport> componentListReport) {
		this.componentListReport = componentListReport;
	}
	public List<Appendix> getAppendix() {
		return appendix;
	}
	public void setAppendix(List<Appendix> appendix) {
		this.appendix = appendix;
	}
	public String getCsvType() {
		return csvType;
	}
	public void setCsvType(String csvType) {
		this.csvType = csvType;
	}
	public String getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getInsertDt() {
		return insertDt;
	}
	public void setInsertDt(String insertDt) {
		this.insertDt = insertDt;
	}
	public String getPayoutApprovedBy() {
		return payoutApprovedBy;
	}
	public void setPayoutApprovedBy(String payoutApprovedBy) {
		this.payoutApprovedBy = payoutApprovedBy;
	}
	public String getPayoutApprovedDt() {
		return payoutApprovedDt;
	}
	public void setPayoutApprovedDt(String payoutApprovedDt) {
		this.payoutApprovedDt = payoutApprovedDt;
	}
	public BigDecimal getTotalNetAmount() {
		return totalNetAmount;
	}
	public void setTotalNetAmount(BigDecimal totalNetAmount) {
		this.totalNetAmount = totalNetAmount;
	}
	public BigDecimal getTotalGrossAmount() {
		return totalGrossAmount;
	}
	public void setTotalGrossAmount(BigDecimal totalGrossAmount) {
		this.totalGrossAmount = totalGrossAmount;
	}
	public BigDecimal getHeadCount() {
		return headCount;
	}
	public void setHeadCount(BigDecimal headCount) {
		this.headCount = headCount;
	}
	public String getPayToDesc() {
		return payToDesc;
	}
	public void setPayToDesc(String payToDesc) {
		this.payToDesc = payToDesc;
	}
	
	
	
}

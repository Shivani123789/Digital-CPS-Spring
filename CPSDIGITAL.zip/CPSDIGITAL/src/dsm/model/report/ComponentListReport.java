package dsm.model.report;

import java.util.List;

public class ComponentListReport {

	private int circleId;
	private int conditionId;
	private int schemeId;
	private String schemeName;
	private String componentName;
	private String versionNo;
	private String approvedBy;
	private String rejectedBy;
	private String approvedDt;
	private String rejectedDt;
	private String payoutApprovedBy;
	private String payoutApprovedDt;
	private String userId;
	private String insertDt;
	private String payToDesc;
	
	private List<ComponentReport> componentReport;
	private List<ConditionReport> conditionReport;
	private List<TransactionDataReport> transDataReport;
	private List<RetailerPerformanceReport> retailerReport;
	private List<PayoutReport> payoutReport;
	
	
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public String getComponentName() {
		return componentName;
	}
	public void setComponentName(String componentName) {
		this.componentName = componentName;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public int getConditionId() {
		return conditionId;
	}
	public void setConditionId(int conditionId) {
		this.conditionId = conditionId;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	public List<ComponentReport> getComponentReport() {
		return componentReport;
	}
	public void setComponentReport(List<ComponentReport> componentReport) {
		this.componentReport = componentReport;
	}
	public List<ConditionReport> getConditionReport() {
		return conditionReport;
	}
	public void setConditionReport(List<ConditionReport> conditionReport) {
		this.conditionReport = conditionReport;
	}
	public List<TransactionDataReport> getTransDataReport() {
		return transDataReport;
	}
	public void setTransDataReport(List<TransactionDataReport> transDataReport) {
		this.transDataReport = transDataReport;
	}
	public List<RetailerPerformanceReport> getRetailerReport() {
		return retailerReport;
	}
	public void setRetailerReport(List<RetailerPerformanceReport> retailerReport) {
		this.retailerReport = retailerReport;
	}
	public List<PayoutReport> getPayoutReport() {
		return payoutReport;
	}
	public void setPayoutReport(List<PayoutReport> payoutReport) {
		this.payoutReport = payoutReport;
	}
	public String getApprovedBy() {
		return approvedBy;
	}
	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}
	public String getRejectedBy() {
		return rejectedBy;
	}
	public void setRejectedBy(String rejectedBy) {
		this.rejectedBy = rejectedBy;
	}
	public String getApprovedDt() {
		return approvedDt;
	}
	public void setApprovedDt(String approvedDt) {
		this.approvedDt = approvedDt;
	}
	public String getRejectedDt() {
		return rejectedDt;
	}
	public void setRejectedDt(String rejectedDt) {
		this.rejectedDt = rejectedDt;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getInsertDt() {
		return insertDt;
	}
	public void setInsertDt(String insertDt) {
		this.insertDt = insertDt;
	}
	public String getPayoutApprovedBy() {
		return payoutApprovedBy;
	}
	public void setPayoutApprovedBy(String payoutApprovedBy) {
		this.payoutApprovedBy = payoutApprovedBy;
	}
	public String getPayoutApprovedDt() {
		return payoutApprovedDt;
	}
	public void setPayoutApprovedDt(String payoutApprovedDt) {
		this.payoutApprovedDt = payoutApprovedDt;
	}
	public String getPayToDesc() {
		return payToDesc;
	}
	public void setPayToDesc(String payToDesc) {
		this.payToDesc = payToDesc;
	}
	
	
}

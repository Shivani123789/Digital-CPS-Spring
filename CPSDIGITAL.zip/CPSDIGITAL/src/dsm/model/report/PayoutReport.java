package dsm.model.report;

import java.math.BigDecimal;

public class PayoutReport {

	private int conditionId;
	private String conditionName;
	private String nextCondition;
	private String grossNet;
	private float amount;
	private String variable;
	private String unit;
	private int overAchive;
	private int underAchive;
	
	private BigDecimal totalNetAmount;
	private BigDecimal totalGrossAmount;
	private BigDecimal headCount;
	
	public int getConditionId() {
		return conditionId;
	}
	public void setConditionId(int conditionId) {
		this.conditionId = conditionId;
	}
	public String getConditionName() {
		return conditionName;
	}
	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}
	public String getNextCondition() {
		return nextCondition;
	}
	public void setNextCondition(String nextCondition) {
		this.nextCondition = nextCondition;
	}
	public String getGrossNet() {
		return grossNet;
	}
	public void setGrossNet(String grossNet) {
		this.grossNet = grossNet;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getVariable() {
		return variable;
	}
	public void setVariable(String variable) {
		this.variable = variable;
	}
	public String getUnit() {
		return unit;
	}
	public void setUnit(String unit) {
		this.unit = unit;
	}
	public int getOverAchive() {
		return overAchive;
	}
	public void setOverAchive(int overAchive) {
		this.overAchive = overAchive;
	}
	public int getUnderAchive() {
		return underAchive;
	}
	public void setUnderAchive(int underAchive) {
		this.underAchive = underAchive;
	}
	public BigDecimal getTotalNetAmount() {
		return totalNetAmount;
	}
	public void setTotalNetAmount(BigDecimal totalNetAmount) {
		this.totalNetAmount = totalNetAmount;
	}
	public BigDecimal getTotalGrossAmount() {
		return totalGrossAmount;
	}
	public void setTotalGrossAmount(BigDecimal totalGrossAmount) {
		this.totalGrossAmount = totalGrossAmount;
	}
	public BigDecimal getHeadCount() {
		return headCount;
	}
	public void setHeadCount(BigDecimal headCount) {
		this.headCount = headCount;
	}
	
	
}

package dsm.model.report;

public class ConditionReport {

	private int conditionId;
	private int conditionRowId;
	private String condition;
	
	public int getConditionId() {
		return conditionId;
	}
	public void setConditionId(int conditionId) {
		this.conditionId = conditionId;
	}
	public int getConditionRowId() {
		return conditionRowId;
	}
	public void setConditionRowId(int conditionRowId) {
		this.conditionRowId = conditionRowId;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	
	
}

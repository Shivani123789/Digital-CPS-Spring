package dsm.model.report;

public class Appendix {

	private String performanceType;
	private String parameterName;
	private String parameterMeaning;
	private String validValue;
	public String getPerformanceType() {
		return performanceType;
	}
	public void setPerformanceType(String performanceType) {
		this.performanceType = performanceType;
	}
	public String getParameterName() {
		return parameterName;
	}
	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}
	public String getParameterMeaning() {
		return parameterMeaning;
	}
	public void setParameterMeaning(String parameterMeaning) {
		this.parameterMeaning = parameterMeaning;
	}
	public String getValidValue() {
		return validValue;
	}
	public void setValidValue(String validValue) {
		this.validValue = validValue;
	}
	
	
	
}

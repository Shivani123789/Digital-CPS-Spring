package dsm.model.report;

public class TransactionDataReport {

	private int conditionId;
	private int groupId;
	private int conditionRowId;
	private String conditionName;
	private String dataSet;
	private String condition;
	private String nextCondition;
	
	public int getConditionId() {
		return conditionId;
	}
	public void setConditionId(int conditionId) {
		this.conditionId = conditionId;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public int getConditionRowId() {
		return conditionRowId;
	}
	public void setConditionRowId(int conditionRowId) {
		this.conditionRowId = conditionRowId;
	}
	public String getConditionName() {
		return conditionName;
	}
	public void setConditionName(String conditionName) {
		this.conditionName = conditionName;
	}
	public String getDataSet() {
		return dataSet;
	}
	public void setDataSet(String dataSet) {
		this.dataSet = dataSet;
	}
	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}
	public String getNextCondition() {
		return nextCondition;
	}
	public void setNextCondition(String nextCondition) {
		this.nextCondition = nextCondition;
	}
	
	
}

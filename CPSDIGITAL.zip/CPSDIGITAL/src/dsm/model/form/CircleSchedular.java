package dsm.model.form;

import java.util.Date;

public class CircleSchedular {

	private String circleCode;
	private int circleId;
	private int delayTime;
	private int tax;
	private int startDay;
	private int endDay;
	private int statementDay;
	private int schemeSchedular;
	private int distMagin;
	private String denoMonth;
	private Date exeTillDate;
	private String denoSet;
	private int negativeDay;
	private String month;
	private String year;
	private Date startDate;
	private Date endDate;
	private String startDtStr;
	private String endDtStr;
	
	
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public int getDelayTime() {
		return delayTime;
	}
	public void setDelayTime(int delayTime) {
		this.delayTime = delayTime;
	}
	public int getTax() {
		return tax;
	}
	public void setTax(int tax) {
		this.tax = tax;
	}
	public int getStartDay() {
		return startDay;
	}
	public void setStartDay(int startDay) {
		this.startDay = startDay;
	}
	public int getEndDay() {
		return endDay;
	}
	public void setEndDay(int endDay) {
		this.endDay = endDay;
	}
	public int getStatementDay() {
		return statementDay;
	}
	public void setStatementDay(int statementDay) {
		this.statementDay = statementDay;
	}
	public int getSchemeSchedular() {
		return schemeSchedular;
	}
	public void setSchemeSchedular(int schemeSchedular) {
		this.schemeSchedular = schemeSchedular;
	}
	public int getDistMagin() {
		return distMagin;
	}
	public void setDistMagin(int distMagin) {
		this.distMagin = distMagin;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getDenoMonth() {
		return denoMonth;
	}
	public void setDenoMonth(String denoMonth) {
		this.denoMonth = denoMonth;
	}
	public Date getExeTillDate() {
		return exeTillDate;
	}
	public void setExeTillDate(Date exeTillDate) {
		this.exeTillDate = exeTillDate;
	}
	public String getDenoSet() {
		return denoSet;
	}
	public void setDenoSet(String denoSet) {
		this.denoSet = denoSet;
	}
	public int getNegativeDay() {
		return negativeDay;
	}
	public void setNegativeDay(int negativeDay) {
		this.negativeDay = negativeDay;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getStartDtStr() {
		return startDtStr;
	}
	public void setStartDtStr(String startDtStr) {
		this.startDtStr = startDtStr;
	}
	public String getEndDtStr() {
		return endDtStr;
	}
	public void setEndDtStr(String endDtStr) {
		this.endDtStr = endDtStr;
	}
	
	
}

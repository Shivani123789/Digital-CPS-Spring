package dsm.model.form;

import java.util.Date;

import org.codehaus.jackson.annotate.JsonAutoDetect;

@JsonAutoDetect
public class PayoutFrequency {
	
	private int freqId;
	private int frequencyType;
	private String description;
	private Date insertDateTime;
	private String displayValue;
	private String validityFlag;
	/**
	 * @return the frequencyId
	 */
	
	/**
	 * @return the frequencyType
	 */
	public int getFrequencyType() {
		return frequencyType;
	}
	/**
	 * @param frequencyType the frequencyType to set
	 */
	public void setFrequencyType(int frequencyType) {
		this.frequencyType = frequencyType;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the insertDateTime
	 */
	public Date getInsertDateTime() {
		return insertDateTime;
	}
	/**
	 * @param insertDateTime the insertDateTime to set
	 */
	public void setInsertDateTime(Date insertDateTime) {
		this.insertDateTime = insertDateTime;
	}
	/**
	 * @return the displayValue
	 */
	public String getDisplayValue() {
		return displayValue;
	}
	/**
	 * @param displayValue the displayValue to set
	 */
	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}
	/**
	 * @return the validityFlag
	 */
	public String getValidityFlag() {
		return validityFlag;
	}
	/**
	 * @param validityFlag the validityFlag to set
	 */
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public int getFreqId() {
		return freqId;
	}
	public void setFreqId(int freqId) {
		this.freqId = freqId;
	}

}

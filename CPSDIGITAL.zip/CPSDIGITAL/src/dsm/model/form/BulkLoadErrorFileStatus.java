package dsm.model.form;



public class BulkLoadErrorFileStatus {
	
	private String fileName;
	private String msisdn;
	private String userName;
	private String circleCode;
	private String rejectionReason;
	private String eventDt;
	private String distId;
	private String dseId;
	private String retId;
	private String dsmrefcode;
	private String producerId;
	
	
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getMsisdn() {
		return msisdn;
	}
	public void setMsisdn(String msisdn) {
		this.msisdn = msisdn;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public String getRejectionReason() {
		return rejectionReason;
	}
	public void setRejectionReason(String rejectionReason) {
		this.rejectionReason = rejectionReason;
	}
	public String getEventDt() {
		return eventDt;
	}
	public void setEventDt(String eventDt) {
		this.eventDt = eventDt;
	}
	public String getDistId() {
		return distId;
	}
	public void setDistId(String distId) {
		this.distId = distId;
	}
	public String getDseId() {
		return dseId;
	}
	public void setDseId(String dseId) {
		this.dseId = dseId;
	}
	public String getRetId() {
		return retId;
	}
	public void setRetId(String retId) {
		this.retId = retId;
	}
	public String getDsmrefcode() {
		return dsmrefcode;
	}
	public void setDsmrefcode(String dsmrefcode) {
		this.dsmrefcode = dsmrefcode;
	}
	public String getProducerId() {
		return producerId;
	}
	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}
	
		

}

package dsm.model.form;


import java.util.Date;
import java.util.List;



public class Coverage {

	private int scmNo;
	private String scmName;
	private int compNo;
	private String compName;
	private Date startDate;
	private Date endDate;
	private List<PayoutFrequency> payoutFrequencyList;
	private List<VerticalMaster> verticalList;
	private List<PayToMaster> PayToList;
	private List<CircleMaster> circleList;
	private List<RegionMaster> regionList;
	private List<ZoneMaster> zoneList;
	private List coverageUploadList;
	private List<UploadMaster> coverageTypeList;
	private String fileName;
	       
	/**
	 * @return the scmNo
	 */
	public int getScmNo() {
		return scmNo;
	}
	/**
	 * @param scmNo the scmNo to set
	 */
	public void setScmNo(int scmNo) {
		this.scmNo = scmNo;
	}
	/**
	 * @return the scmName
	 */
	public String getScmName() {
		return scmName;
	}
	/**
	 * @param scmName the scmName to set
	 */
	public void setScmName(String scmName) {
		this.scmName = scmName;
	}
	/**
	 * @return the compNo
	 */
	public int getCompNo() {
		return compNo;
	}
	/**
	 * @param compNo the compNo to set
	 */
	public void setCompNo(int compNo) {
		this.compNo = compNo;
	}
	/**
	 * @return the compName
	 */
	public String getCompName() {
		return compName;
	}
	/**
	 * @param compName the compName to set
	 */
	public void setCompName(String compName) {
		this.compName = compName;
	}
	/**
	 * @return the startDate
	 */
	public Date getStartDate() {
		return startDate;
	}
	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	/**
	 * @return the endDate
	 */
	public Date getEndDate() {
		return endDate;
	}
	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	/**
	 * @return the payoutFrequencyList
	 */
	public List<PayoutFrequency> getPayoutFrequencyList() {
		return payoutFrequencyList;
	}
	/**
	 * @param payoutFrequencyList the payoutFrequencyList to set
	 */
	public void setPayoutFrequencyList(List<PayoutFrequency> payoutFrequencyList) {
		this.payoutFrequencyList = payoutFrequencyList;
	}
	/**
	 * @return the verticalList
	 */
	public List<VerticalMaster> getVerticalList() {
		return verticalList;
	}
	/**
	 * @param verticalList the verticalList to set
	 */
	public void setVerticalList(List<VerticalMaster> verticalList) {
		this.verticalList = verticalList;
	}
	/**
	 * @return the payToList
	 */
	public List<PayToMaster> getPayToList() {
		return PayToList;
	}
	/**
	 * @param payToList the payToList to set
	 */
	public void setPayToList(List<PayToMaster> payToList) {
		PayToList = payToList;
	}
	/**
	 * @return the circleList
	 */
	public List<CircleMaster> getCircleList() {
		return circleList;
	}
	/**
	 * @param circleList the circleList to set
	 */
	public void setCircleList(List<CircleMaster> circleList) {
		this.circleList = circleList;
	}
	/**
	 * @return the regionList
	 */
	public List<RegionMaster> getRegionList() {
		return regionList;
	}
	/**
	 * @param regionList the regionList to set
	 */
	public void setRegionList(List<RegionMaster> regionList) {
		this.regionList = regionList;
	}
	/**
	 * @return the zoneList
	 */
	public List<ZoneMaster> getZoneList() {
		return zoneList;
	}
	/**
	 * @param zoneList the zoneList to set
	 */
	public void setZoneList(List<ZoneMaster> zoneList) {
		this.zoneList = zoneList;
	}
	/**
	 * @return the coverageUploadList
	 */
	public List getCoverageUploadList() {
		return coverageUploadList;
	}
	/**
	 * @param coverageUploadList the coverageUploadList to set
	 */
	public void setCoverageUploadList(List coverageUploadList) {
		this.coverageUploadList = coverageUploadList;
	}
	/**
	 * @return the coverageTypeList
	 */
	public List<UploadMaster> getCoverageTypeList() {
		return coverageTypeList;
	}
	/**
	 * @param coverageTypeList the coverageTypeList to set
	 */
	public void setCoverageTypeList(List<UploadMaster> coverageTypeList) {
		this.coverageTypeList = coverageTypeList;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
}

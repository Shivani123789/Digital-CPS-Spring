package dsm.model.form;

public class BulkRejectFileDetails {
	
	
  private	int seqNoIndex;
  private String bulkUploadedFileName;
  private String bulkFileUploadedDate;
  private String downloadFile;
  
public int getSeqNoIndex() {
	return seqNoIndex;
}
public void setSeqNoIndex(int seqNoIndex) {
	this.seqNoIndex = seqNoIndex;
}
public String getBulkUploadedFileName() {
	return bulkUploadedFileName;
}
public void setBulkUploadedFileName(String bulkUploadedFileName) {
	this.bulkUploadedFileName = bulkUploadedFileName;
}
public String getBulkFileUploadedDate() {
	return bulkFileUploadedDate;
}
public void setBulkFileUploadedDate(String bulkFileUploadedDate) {
	this.bulkFileUploadedDate = bulkFileUploadedDate;
}
public String getDownloadFile() {
	return downloadFile;
}
public void setDownloadFile(String downloadFile) {
	this.downloadFile = downloadFile;
}
}

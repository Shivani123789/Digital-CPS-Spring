package dsm.model.form;

public class DocUploadFile {

	private int fileSize;
	private int fileNameSize;
	private String fileExt;
	
	public int getFileSize() {
		return fileSize;
	}
	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}
	public int getFileNameSize() {
		return fileNameSize;
	}
	public void setFileNameSize(int fileNameSize) {
		this.fileNameSize = fileNameSize;
	}
	public String getFileExt() {
		return fileExt;
	}
	public void setFileExt(String fileExt) {
		this.fileExt = fileExt;
	}
	
	
}

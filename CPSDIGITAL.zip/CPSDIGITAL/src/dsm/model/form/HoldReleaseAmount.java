package dsm.model.form;

import java.math.BigDecimal;

public class HoldReleaseAmount {

	private BigDecimal holdAmt;
	private BigDecimal totalAmt;
	private String circleCode;
	private String ftaNumber;
	private String vtopupNumber;
	private String producerId;
	private String paymentType;
	private String userId;
	private String transactionDate;
	private String releaseStatus;
	private String releaseReqDate;
	private String releaseDate;
	private String remarks;
	private String holdReleaseRequest;
	private String holdReleaseStatus;
	private String holdStatus;
	private int payToId;
	
	public String getReleaseStatus() {
		return releaseStatus;
	}
	public void setReleaseStatus(String releaseStatus) {
		this.releaseStatus = releaseStatus;
	}
	public String getReleaseReqDate() {
		return releaseReqDate;
	}
	public void setReleaseReqDate(String releaseReqDate) {
		this.releaseReqDate = releaseReqDate;
	}
	public String getReleaseDate() {
		return releaseDate;
	}
	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}
	public BigDecimal getHoldAmt() {
		return holdAmt;
	}
	public void setHoldAmt(BigDecimal holdAmt) {
		this.holdAmt = holdAmt;
	}
	public BigDecimal getTotalAmt() {
		return totalAmt;
	}
	public void setTotalAmt(BigDecimal totalAmt) {
		this.totalAmt = totalAmt;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public String getFtaNumber() {
		return ftaNumber;
	}
	public void setFtaNumber(String ftaNumber) {
		this.ftaNumber = ftaNumber;
	}
	public String getVtopupNumber() {
		return vtopupNumber;
	}
	public void setVtopupNumber(String vtopupNumber) {
		this.vtopupNumber = vtopupNumber;
	}
	public String getProducerId() {
		return producerId;
	}
	public void setProducerId(String producerId) {
		this.producerId = producerId;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getHoldReleaseRequest() {
		return holdReleaseRequest;
	}
	public void setHoldReleaseRequest(String holdReleaseRequest) {
		this.holdReleaseRequest = holdReleaseRequest;
	}
	public String getHoldReleaseStatus() {
		return holdReleaseStatus;
	}
	public void setHoldReleaseStatus(String holdReleaseStatus) {
		this.holdReleaseStatus = holdReleaseStatus;
	}
	public String getHoldStatus() {
		return holdStatus;
	}
	public void setHoldStatus(String holdStatus) {
		this.holdStatus = holdStatus;
	}
	public int getPayToId() {
		return payToId;
	}
	public void setPayToId(int payToId) {
		this.payToId = payToId;
	}
	
	
	
}

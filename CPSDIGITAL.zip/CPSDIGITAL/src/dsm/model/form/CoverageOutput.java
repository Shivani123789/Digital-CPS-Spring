package dsm.model.form;

import java.util.List;

public class CoverageOutput {
	private List<PayoutFrequency> payoutFreqList;
	private List<PayToMaster> payToMasterList;
	private List<RegionMaster> RegionListMasterList;
	private List<VerticalMaster> verticalMasterList;
	private List<EntityMaster> entityMasterList;
	/**
	 * @return the payoutFreqList
	 */
	public List<PayoutFrequency> getPayoutFreqList() {
		return payoutFreqList;
	}
	/**
	 * @param payoutFreqList the payoutFreqList to set
	 */
	public void setPayoutFreqList(List<PayoutFrequency> payoutFreqList) {
		this.payoutFreqList = payoutFreqList;
	}
	/**
	 * @return the payToMasterList
	 */
	public List<PayToMaster> getPayToMasterList() {
		return payToMasterList;
	}
	/**
	 * @param payToMasterList the payToMasterList to set
	 */
	public void setPayToMasterList(List<PayToMaster> payToMasterList) {
		this.payToMasterList = payToMasterList;
	}
	/**
	 * @return the regionListMasterList
	 */
	public List<RegionMaster> getRegionListMasterList() {
		return RegionListMasterList;
	}
	/**
	 * @param regionListMasterList the regionListMasterList to set
	 */
	public void setRegionListMasterList(List<RegionMaster> regionListMasterList) {
		RegionListMasterList = regionListMasterList;
	}
	/**
	 * @return the verticalMasterList
	 */
	public List<VerticalMaster> getVerticalMasterList() {
		return verticalMasterList;
	}
	/**
	 * @param verticalMasterList the verticalMasterList to set
	 */
	public void setVerticalMasterList(List<VerticalMaster> verticalMasterList) {
		this.verticalMasterList = verticalMasterList;
	}
	public List<EntityMaster> getEntityMasterList() {
		return entityMasterList;
	}
	public void setEntityMasterList(List<EntityMaster> entityMasterList) {
		this.entityMasterList = entityMasterList;
	}
	
	
	

}

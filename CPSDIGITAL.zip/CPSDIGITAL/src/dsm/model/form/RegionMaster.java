package dsm.model.form;

import java.util.Date;

public class RegionMaster {

	private int regionId;
	private int circleId;
	private String regionDesc;
	private String displayValue;
	private Date insertDateTime;
	private boolean validityFlag;
	/**
	 * @return the regionId
	 */
	public int getRegionId() {
		return regionId;
	}
	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}
	/**
	 * @return the circleId
	 */
	public int getCircleId() {
		return circleId;
	}
	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	/**
	 * @return the regionDesc
	 */
	public String getRegionDesc() {
		return regionDesc;
	}
	/**
	 * @param regionDesc the regionDesc to set
	 */
	public void setRegionDesc(String regionDesc) {
		this.regionDesc = regionDesc;
	}
	/**
	 * @return the displayValue
	 */
	public String getDisplayValue() {
		return displayValue;
	}
	/**
	 * @param displayValue the displayValue to set
	 */
	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}
	/**
	 * @return the insertDateTime
	 */
	public Date getInsertDateTime() {
		return insertDateTime;
	}
	/**
	 * @param insertDateTime the insertDateTime to set
	 */
	public void setInsertDateTime(Date insertDateTime) {
		this.insertDateTime = insertDateTime;
	}
	/**
	 * @return the validityFlag
	 */
	public boolean isValidityFlag() {
		return validityFlag;
	}
	/**
	 * @param validityFlag the validityFlag to set
	 */
	public void setValidityFlag(boolean validityFlag) {
		this.validityFlag = validityFlag;
	}

	
}

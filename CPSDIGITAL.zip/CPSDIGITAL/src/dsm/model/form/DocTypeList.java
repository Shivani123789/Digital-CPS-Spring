package dsm.model.form;

import org.springframework.web.multipart.MultipartFile;

public class DocTypeList {
	
	private String docFileType;
	private String userName;
	private String circleCode;
	private String filePath;
	private int typeId;
	
	private MultipartFile uploadDocFile;

	

	public MultipartFile getUploadDocFile() {
		return uploadDocFile;
	}

	public void setUploadDocFile(MultipartFile uploadDocFile) {
		this.uploadDocFile = uploadDocFile;
	}

	public String getDocFileType() {
		return docFileType;
	}

	public void setDocFileType(String docFileType) {
		this.docFileType = docFileType;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCircleCode() {
		return circleCode;
	}

	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}
	
	

}

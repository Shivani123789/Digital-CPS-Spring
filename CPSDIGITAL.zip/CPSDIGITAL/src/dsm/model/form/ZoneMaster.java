package dsm.model.form;

import java.util.Date;

public class ZoneMaster {
	
	private int zoneId;
	private int circleId;
	private int regionId;
	private String zoneDesc;
	private String displayValue;
	private Date insertDateTime;
	private boolean validityFlag;
	/**
	 * @return the zoneId
	 */
	public int getZoneId() {
		return zoneId;
	}
	/**
	 * @param zoneId the zoneId to set
	 */
	public void setZoneId(int zoneId) {
		this.zoneId = zoneId;
	}
	/**
	 * @return the circleId
	 */
	public int getCircleId() {
		return circleId;
	}
	/**
	 * @param circleId the circleId to set
	 */
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	/**
	 * @return the regionId
	 */
	public int getRegionId() {
		return regionId;
	}
	/**
	 * @param regionId the regionId to set
	 */
	public void setRegionId(int regionId) {
		this.regionId = regionId;
	}
	/**
	 * @return the zoneDesc
	 */
	public String getZoneDesc() {
		return zoneDesc;
	}
	/**
	 * @param zoneDesc the zoneDesc to set
	 */
	public void setZoneDesc(String zoneDesc) {
		this.zoneDesc = zoneDesc;
	}
	/**
	 * @return the displayValue
	 */
	public String getDisplayValue() {
		return displayValue;
	}
	/**
	 * @param displayValue the displayValue to set
	 */
	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}
	/**
	 * @return the insertDateTime
	 */
	public Date getInsertDateTime() {
		return insertDateTime;
	}
	/**
	 * @param insertDateTime the insertDateTime to set
	 */
	public void setInsertDateTime(Date insertDateTime) {
		this.insertDateTime = insertDateTime;
	}
	/**
	 * @return the validityFlag
	 */
	public boolean isValidityFlag() {
		return validityFlag;
	}
	/**
	 * @param validityFlag the validityFlag to set
	 */
	public void setValidityFlag(boolean validityFlag) {
		this.validityFlag = validityFlag;
	}
	
	

}

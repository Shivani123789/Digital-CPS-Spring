package dsm.model.form;



public class EntityAttributeMaster {
	
	private int entityAttributeId;
	private String entityAttributeName;
	private String varFlag;
	private int compId;
	private String poVarFlag;

	
	private int attrCatg;
	private String operatorFlag;
	private int attrType;
	private String freeTextType;
	public String getEntityAttributeName() {
		return entityAttributeName;
	}
	public void setEntityAttributeName(String entityAttributeName) {
		this.entityAttributeName = entityAttributeName;
	}
	public int getEntityAttributeId() {
		return entityAttributeId;
	}
	public void setEntityAttributeId(int entityAttributeId) {
		this.entityAttributeId = entityAttributeId;
	}
	public int getAttrCatg() {
		return attrCatg;
	}
	public void setAttrCatg(int attrCatg) {
		this.attrCatg = attrCatg;
	}
	public int getAttrType() {
		return attrType;
	}
	public void setAttrType(int attrType) {
		this.attrType = attrType;
	}
	public String getFreeTextType() {
		return freeTextType;
	}
	public void setFreeTextType(String freeTextType) {
		this.freeTextType = freeTextType;
	}
	public String getOperatorFlag() {
		return operatorFlag;
	}
	public void setOperatorFlag(String operatorFlag) {
		this.operatorFlag = operatorFlag;
	}
	public String getVarFlag() {
		return varFlag;
	}
	public void setVarFlag(String varFlag) {
		this.varFlag = varFlag;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getPoVarFlag() {
		return poVarFlag;
	}
	public void setPoVarFlag(String poVarFlag) {
		this.poVarFlag = poVarFlag;
	}

}

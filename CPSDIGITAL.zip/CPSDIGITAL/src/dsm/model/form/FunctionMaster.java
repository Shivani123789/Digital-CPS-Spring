package dsm.model.form;

public class FunctionMaster {
	private int functioId;
	private String functionName;
	public int getFunctioId() {
		return functioId;
	}
	public void setFunctioId(int functioId) {
		this.functioId = functioId;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

}

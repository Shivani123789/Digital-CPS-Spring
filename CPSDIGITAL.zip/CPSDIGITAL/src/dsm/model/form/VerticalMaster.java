package dsm.model.form;

import java.io.Serializable;
import java.util.Date;

public class VerticalMaster implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	private int verticalId;
	private String verticalName;
	private Date insertDateTime;
	private String displayValue;
	private String validityFlag;
	/**
	 * @return the verticalId
	 */
	public int getVerticalId() {
		return verticalId;
	}
	/**
	 * @param verticalId the verticalId to set
	 */
	public void setVerticalId(int verticalId) {
		this.verticalId = verticalId;
	}
	/**
	 * @return the verticalName
	 */
	public String getVerticalName() {
		return verticalName;
	}
	/**
	 * @param verticalName the verticalName to set
	 */
	public void setVerticalName(String verticalName) {
		this.verticalName = verticalName;
	}
	/**
	 * @return the insertDateTime
	 */
	public Date getInsertDateTime() {
		return insertDateTime;
	}
	/**
	 * @param insertDateTime the insertDateTime to set
	 */
	public void setInsertDateTime(Date insertDateTime) {
		this.insertDateTime = insertDateTime;
	}
	/**
	 * @return the displayValue
	 */
	public String getDisplayValue() {
		return displayValue;
	}
	/**
	 * @param displayValue the displayValue to set
	 */
	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}
	/**
	 * @return the validityFlag
	 */
	public String getValidityFlag() {
		return validityFlag;
	}
	/**
	 * @param validityFlag the validityFlag to set
	 */
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	
	
	

}

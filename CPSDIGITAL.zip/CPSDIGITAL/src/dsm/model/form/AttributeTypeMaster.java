package dsm.model.form;

public class AttributeTypeMaster {
	
	private int attributeTypeId;
	private String attributeTypeName;
	private String eaFilterConFlag;
	private String eaFilterVarFlag;
	public int getAttributeTypeId() {
		return attributeTypeId;
	}
	public void setAttributeTypeId(int attributeTypeId) {
		this.attributeTypeId = attributeTypeId;
	}
	public String getAttributeTypeName() {
		return attributeTypeName;
	}
	public void setAttributeTypeName(String attributeTypeName) {
		this.attributeTypeName = attributeTypeName;
	}
	public String getEaFilterConFlag() {
		return eaFilterConFlag;
	}
	public void setEaFilterConFlag(String eaFilterConFlag) {
		this.eaFilterConFlag = eaFilterConFlag;
	}
	public String getEaFilterVarFlag() {
		return eaFilterVarFlag;
	}
	public void setEaFilterVarFlag(String eaFilterVarFlag) {
		this.eaFilterVarFlag = eaFilterVarFlag;
	}

}

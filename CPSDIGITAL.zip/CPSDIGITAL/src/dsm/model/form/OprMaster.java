package dsm.model.form;

public class OprMaster {
	
	private int oprId;
	private String oprName;
	private String oprType;
	private String numberFlag;
	private String dateFlag;
	private String stringFlag;
	
	
	public String getOprName() {
		return oprName;
	}
	public void setOprName(String oprName) {
		this.oprName = oprName;
	}
	public int getOprId() {
		return oprId;
	}
	public void setOprId(int oprId) {
		this.oprId = oprId;
	}
	public String getOprType() {
		return oprType;
	}
	public void setOprType(String oprType) {
		this.oprType = oprType;
	}
	public String getNumberFlag() {
		return numberFlag;
	}
	public void setNumberFlag(String numberFlag) {
		this.numberFlag = numberFlag;
	}
	
	public String getStringFlag() {
		return stringFlag;
	}
	public void setStringFlag(String stringFlag) {
		this.stringFlag = stringFlag;
	}
	public String getDateFlag() {
		return dateFlag;
	}
	public void setDateFlag(String dateFlag) {
		this.dateFlag = dateFlag;
	}

}

package dsm.model.form;

import java.io.Serializable;

public class SchemaMaster implements Serializable{
	 
	
	private static final long serialVersionUID = 1L;
	private int schemaId;
	private int circleId;
	private String schemaName;
	//private String validityFlag;
	//private Date insertDataTime;
	
	public int getSchemaId() {
		return schemaId;
	}
	public void setSchemaId(int schemaId) {
		this.schemaId = schemaId;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getSchemaName() {
		return schemaName;
	}
	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}
	/*public String getValidityFlag() {
		return validityFlag;
	}
	public void setValidityFlag(String validityFlag) {
		this.validityFlag = validityFlag;
	}
	public Date getInsertDataTime() {
		return insertDataTime;
	}
	public void setInsertDataTime(Date insertDataTime) {
		this.insertDataTime = insertDataTime;
	}*/
	
	

}

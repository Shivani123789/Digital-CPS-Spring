package dsm.model.form;

import java.util.Date;

public class UploadMailStatusData {

	private String uploadTypeStatus;
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	private Date insertedDate;
	private String dataFileName;
	private String userId;
	private int seqNo;
	private String dsm2RefCode;
	private Date mailStartDate;
	private Date mailInsertDate;
	private Date mailUpdatedDate;
	private String mailSendStatus;
	private String mailStatus;
	private Date mailSendDate;
	private String errorMsg;
	private String email;
	private String entityMail;
	private Date startDateStatus;
	private Date endDateStatus;
	private Date sendDate;
	private String circleCode;
	
	
	
	
	
	public Date getSendDate() {
		return sendDate;
	}
	public void setSendDate(Date sendDate) {
		this.sendDate = sendDate;
	}
	public Date getStartDateStatus() {
		return startDateStatus;
	}
	public void setStartDateStatus(Date startDateStatus) {
		this.startDateStatus = startDateStatus;
	}
	public Date getEndDateStatus() {
		return endDateStatus;
	}
	public void setEndDateStatus(Date endDateStatus) {
		this.endDateStatus = endDateStatus;
	}
	public String getEntityMail() {
		return entityMail;
	}
	public void setEntityMail(String entityMail) {
		this.entityMail = entityMail;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDsm2RefCode() {
		return dsm2RefCode;
	}
	public void setDsm2RefCode(String dsm2RefCode) {
		this.dsm2RefCode = dsm2RefCode;
	}
	public Date getMailStartDate() {
		return mailStartDate;
	}
	public void setMailStartDate(Date mailStartDate) {
		this.mailStartDate = mailStartDate;
	}
	public Date getMailInsertDate() {
		return mailInsertDate;
	}
	public void setMailInsertDate(Date mailInsertDate) {
		this.mailInsertDate = mailInsertDate;
	}
	public Date getMailUpdatedDate() {
		return mailUpdatedDate;
	}
	public void setMailUpdatedDate(Date mailUpdatedDate) {
		this.mailUpdatedDate = mailUpdatedDate;
	}
	public String getMailSendStatus() {
		return mailSendStatus;
	}
	public void setMailSendStatus(String mailSendStatus) {
		this.mailSendStatus = mailSendStatus;
	}
	public String getMailStatus() {
		return mailStatus;
	}
	public void setMailStatus(String mailStatus) {
		this.mailStatus = mailStatus;
	}
	public Date getMailSendDate() {
		return mailSendDate;
	}
	public void setMailSendDate(Date mailSendDate) {
		this.mailSendDate = mailSendDate;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public int getSeqNo() {
		return seqNo;
	}
	public void setSeqNo(int seqNo) {
		this.seqNo = seqNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUploadTypeStatus() {
		return uploadTypeStatus;
	}
	public void setUploadTypeStatus(String uploadTypeStatus) {
		this.uploadTypeStatus = uploadTypeStatus;
	}
	public Date getInsertedDate() {
		return insertedDate;
	}
	public void setInsertedDate(Date insertedDate) {
		this.insertedDate = insertedDate;
	}
	public String getDataFileName() {
		return dataFileName;
	}
	public void setDataFileName(String dataFileName) {
		this.dataFileName = dataFileName;
	}
	
	
	
}

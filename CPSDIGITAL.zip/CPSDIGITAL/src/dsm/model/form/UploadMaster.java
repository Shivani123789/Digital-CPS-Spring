package dsm.model.form;

import java.util.Date;

public class UploadMaster {
	
	private int listId;
	private String covFlag;
	private String displayValue;
	private boolean validityFlag;
	private Date insertDateTime;
	private String dataSource;
	/**
	 * @return the listId
	 */
	public int getListId() {
		return listId;
	}
	/**
	 * @param listId the listId to set
	 */
	public void setListId(int listId) {
		this.listId = listId;
	}
	/**
	 * @return the description
	 */
	
	/**
	 * @return the displayValue
	 */
	public String getDisplayValue() {
		return displayValue;
	}
	/**
	 * @param displayValue the displayValue to set
	 */
	public void setDisplayValue(String displayValue) {
		this.displayValue = displayValue;
	}
	/**
	 * @return the validityFlag
	 */
	public boolean isValidityFlag() {
		return validityFlag;
	}
	/**
	 * @param validityFlag the validityFlag to set
	 */
	public void setValidityFlag(boolean validityFlag) {
		this.validityFlag = validityFlag;
	}
	/**
	 * @return the insertDateTime
	 */
	public Date getInsertDateTime() {
		return insertDateTime;
	}
	/**
	 * @param insertDateTime the insertDateTime to set
	 */
	public void setInsertDateTime(Date insertDateTime) {
		this.insertDateTime = insertDateTime;
	}
	/**
	 * @return the dataSource
	 */
	public String getDataSource() {
		return dataSource;
	}
	/**
	 * @param dataSource the dataSource to set
	 */
	public void setDataSource(String dataSource) {
		this.dataSource = dataSource;
	}
	public String getCovFlag() {
		return covFlag;
	}
	public void setCovFlag(String covFlag) {
		this.covFlag = covFlag;
	}

}

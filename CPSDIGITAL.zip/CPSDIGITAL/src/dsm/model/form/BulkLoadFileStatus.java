package dsm.model.form;

import java.util.Date;


public class BulkLoadFileStatus {
	
	private String fileName;
	private String unquieFileName;
	private String userName;
	private String circleCode;
	private String fileStatus;
	private String loadDateTime;
	private String errorDesc;
	private int reloadattempts;
	
	//search
	private Date startDt;
	private Date endDt;
	private String uploadBulkFileType;
	
	
	
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getUnquieFileName() {
		return unquieFileName;
	}
	public void setUnquieFileName(String unquieFileName) {
		this.unquieFileName = unquieFileName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getCircleCode() {
		return circleCode;
	}
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	public String getFileStatus() {
		return fileStatus;
	}
	public void setFileStatus(String fileStatus) {
		this.fileStatus = fileStatus;
	}
	public String getLoadDateTime() {
		return loadDateTime;
	}
	public void setLoadDateTime(String loadDateTime) {
		this.loadDateTime = loadDateTime;
	}
	public String getErrorDesc() {
		return errorDesc;
	}
	public void setErrorDesc(String errorDesc) {
		this.errorDesc = errorDesc;
	}
	public int getReloadattempts() {
		return reloadattempts;
	}
	public void setReloadattempts(int reloadattempts) {
		this.reloadattempts = reloadattempts;
	}
	public String getUploadBulkFileType() {
		return uploadBulkFileType;
	}
	public void setUploadBulkFileType(String uploadBulkFileType) {
		this.uploadBulkFileType = uploadBulkFileType;
	}
	public Date getStartDt() {
		return startDt;
	}
	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}
	public Date getEndDt() {
		return endDt;
	}
	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}
	
	
	

}

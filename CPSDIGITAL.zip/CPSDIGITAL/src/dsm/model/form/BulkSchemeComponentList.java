package dsm.model.form;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class BulkSchemeComponentList {

	private int payTo;
	private String fileUpload;
	//private MultipartFile fileUpload;
	public List<BulkSchemeMasterStore> bulkSchemeMasterList;
	public List<BulkComponentMasterStore> bulkComponentMasterList;
	
	private List<DocTypeList> docTypeList;
	
    private List<UploadMailStatusData> uploadMailStatusData;
    

	public List<UploadMailStatusData> getUploadMailStatusData() {
		return uploadMailStatusData;
	}

	public void setUploadMailStatusData(
			List<UploadMailStatusData> uploadMailStatusData) {
		this.uploadMailStatusData = uploadMailStatusData;
	}

	public List<DocTypeList> getDocTypeList() {
		return docTypeList;
	}

	public void setDocTypeList(List<DocTypeList> docTypeList) {
		this.docTypeList = docTypeList;
	}

	public List<BulkSchemeMasterStore> getBulkSchemeMasterList() {
		return bulkSchemeMasterList;
	}

	public void setBulkSchemeMasterList(
			List<BulkSchemeMasterStore> bulkSchemeMasterList) {
		this.bulkSchemeMasterList = bulkSchemeMasterList;
	}

	public List<BulkComponentMasterStore> getBulkComponentMasterList() {
		return bulkComponentMasterList;
	}

	public void setBulkComponentMasterList(
			List<BulkComponentMasterStore> bulkComponentMasterList) {
		this.bulkComponentMasterList = bulkComponentMasterList;
	}

	public int getPayTo() {
		return payTo;
	}

	public void setPayTo(int payTo) {
		this.payTo = payTo;
	}

	public String getFileUpload() {
		String file =fileUpload;
		if(fileUpload!=null){
			int i = file.lastIndexOf("\\");
			if(i!=-1){
				fileUpload=file.substring(i+1, file.length());
				System.out.println("lastindex ::::: "+i+"\tfile Name :::::::::"+file.substring(i+1, file.length()));
			}
		}
		return fileUpload;
	}

	public void setFileUpload(String fileUpload) {
		this.fileUpload = fileUpload;
	}
	
	
	
}

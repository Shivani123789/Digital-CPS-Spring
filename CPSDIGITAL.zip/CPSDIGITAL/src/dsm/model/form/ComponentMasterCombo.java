package dsm.model.form;

import java.io.Serializable;

public class ComponentMasterCombo implements Serializable{

	private static final long serialVersionUID = 1L;
	private int compId;
	private String compName;
	private int schemaId;
	
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public int getSchemaId() {
		return schemaId;
	}
	public void setSchemaId(int schemaId) {
		this.schemaId = schemaId;
	}
	
}

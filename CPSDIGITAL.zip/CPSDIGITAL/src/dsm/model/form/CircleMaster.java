package dsm.model.form;

public class CircleMaster {
	
	
	private int circleId;
	private String circleCode;
	private String circleName;
	private String validExtraction;
	private int dlaySCHTime;
	private String startDate;
	private String endDate;
	/**
	 * @return the circleNo
	 */
	
	/**
	 * @return the circleCode
	 */
	public String getCircleCode() {
		return circleCode;
	}
	/**
	 * @param circleCode the circleCode to set
	 */
	public void setCircleCode(String circleCode) {
		this.circleCode = circleCode;
	}
	/**
	 * @return the circleName
	 */
	public String getCircleName() {
		return circleName;
	}
	/**
	 * @param circleName the circleName to set
	 */
	public void setCircleName(String circleName) {
		this.circleName = circleName;
	}
	/**
	 * @return the validExtraction
	 */
	public String getValidExtraction() {
		return validExtraction;
	}
	/**
	 * @param validExtraction the validExtraction to set
	 */
	public void setValidExtraction(String validExtraction) {
		this.validExtraction = validExtraction;
	}
	/**
	 * @return the dlaySCHTime
	 */
	public int getDlaySCHTime() {
		return dlaySCHTime;
	}
	/**
	 * @param dlaySCHTime the dlaySCHTime to set
	 */
	public void setDlaySCHTime(int dlaySCHTime) {
		this.dlaySCHTime = dlaySCHTime;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	
	
	
	

}

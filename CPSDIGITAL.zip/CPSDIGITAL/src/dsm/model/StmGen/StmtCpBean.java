package dsm.model.StmGen;

public class StmtCpBean {

	private String cpId;
	private String cpName;
	private String scmMonth;
	private  String usageType;
	private String subscriberCount;
	private String totalRevenue;
	private String netRevenue;
	private String poolPer;
	private String poolAmount;
	private String totalStreams;
	private String partnerStreams;
	private String mktSharePer;
	private String partnerPayout;
	private String totalSubscriberCount;
	
	
	
	public String getCpName() {
		return cpName;
	}
	public void setCpName(String cpName) {
		this.cpName = cpName;
	}
	public String getCpId() {
		return cpId;
	}
	public void setCpId(String cpId) {
		this.cpId = cpId;
	}
	public String getScmMonth() {
		return scmMonth;
	}
	public void setScmMonth(String scmMonth) {
		this.scmMonth = scmMonth;
	}
	public String getUsageType() {
		return usageType;
	}
	public void setUsageType(String usageType) {
		this.usageType = usageType;
	}
	public String getSubscriberCount() {
		return subscriberCount;
	}
	public void setSubscriberCount(String subscriberCount) {
		this.subscriberCount = subscriberCount;
	}
	public String getTotalRevenue() {
		return totalRevenue;
	}
	public void setTotalRevenue(String totalRevenue) {
		this.totalRevenue = totalRevenue;
	}
	public String getNetRevenue() {
		return netRevenue;
	}
	public void setNetRevenue(String netRevenue) {
		this.netRevenue = netRevenue;
	}
	public String getPoolPer() {
		return poolPer;
	}
	public void setPoolPer(String poolPer) {
		this.poolPer = poolPer;
	}
	public String getPoolAmount() {
		return poolAmount;
	}
	public void setPoolAmount(String poolAmount) {
		this.poolAmount = poolAmount;
	}
	public String getTotalStreams() {
		return totalStreams;
	}
	public void setTotalStreams(String totalStreams) {
		this.totalStreams = totalStreams;
	}
	public String getPartnerStreams() {
		return partnerStreams;
	}
	public void setPartnerStreams(String partnerStreams) {
		this.partnerStreams = partnerStreams;
	}
	public String getMktSharePer() {
		return mktSharePer;
	}
	public void setMktSharePer(String mktSharePer) {
		this.mktSharePer = mktSharePer;
	}
	public String getPartnerPayout() {
		return partnerPayout;
	}
	public void setPartnerPayout(String partnerPayout) {
		this.partnerPayout = partnerPayout;
	}
	public String getTotalSubscriberCount() {
		return totalSubscriberCount;
	}
	public void setTotalSubscriberCount(String totalSubscriberCount) {
		this.totalSubscriberCount = totalSubscriberCount;
	}
	
	
	

}

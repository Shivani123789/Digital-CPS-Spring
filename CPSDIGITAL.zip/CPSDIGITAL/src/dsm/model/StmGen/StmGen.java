package dsm.model.StmGen;

public class StmGen {

	private int cycleId;
	private String schemePeriod;
	public String getSchemePeriod() {
		return schemePeriod;
	}
	public void setSchemePeriod(String schemePeriod) {
		this.schemePeriod = schemePeriod;
	}
	public int getCycleId() {
		return cycleId;
	}
	public void setCycleId(int cycleId) {
		this.cycleId = cycleId;
	}

}

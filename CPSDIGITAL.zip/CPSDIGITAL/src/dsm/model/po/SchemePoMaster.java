package dsm.model.po;

import java.math.BigDecimal;
import java.util.Date;

public class SchemePoMaster {
	//DLP_SCM_TQ_COND_CONFIG
	private String processType;
	private int schemeId;
	private int circleId;
	private String loprName;
	private String schemeName;
	private int compId;
	private String compName;
	private int reConfigId;
	private int condId;
	private int condRowId;
	private String inputType;
	private String rinputType;
	private String eaVariable;
	private String reaVariable;
	private String ValueListName;
	private String rValueListName;
	private int inputTypeId;
	private int rinputTypeId;
	private int insertEmptyRowType;
	
	public String getRinputType() {
		return rinputType;
	}
	public void setRinputType(String rinputType) {
		this.rinputType = rinputType;
	}
	public int getRinputTypeId() {
		return rinputTypeId;
	}
	public void setRinputTypeId(int rinputTypeId) {
		this.rinputTypeId = rinputTypeId;
	}
	public String getRinputParameter() {
		return rinputParameter;
	}
	public void setRinputParameter(String rinputParameter) {
		this.rinputParameter = rinputParameter;
	}
	public int getRopr() {
		return ropr;
	}
	public void setRopr(int ropr) {
		this.ropr = ropr;
	}
	public String getRvalueType() {
		return rvalueType;
	}
	public void setRvalueType(String rvalueType) {
		this.rvalueType = rvalueType;
	}
	public String getRvalue() {
		return rvalue;
	}
	public void setRvalue(String rvalue) {
		this.rvalue = rvalue;
	}
	public Date getRstartDate() {
		return rstartDate;
	}
	public void setRstartDate(Date rstartDate) {
		this.rstartDate = rstartDate;
	}
	public Date getRendDate() {
		return rendDate;
	}
	public void setRendDate(Date rendDate) {
		this.rendDate = rendDate;
	}
	public int getRlopr() {
		return rlopr;
	}
	public void setRlopr(int rlopr) {
		this.rlopr = rlopr;
	}
	private String inputParameter;
	private String rinputParameter;
	
	private int opr;
	private int ropr;
	private String oprName;
	private String valueType;
	private String rvalueType;
	private String value;
	private String rvalue;
	//private List<SchemePoAmtMaster> poAmt;
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public int getSchemeId() {
		return schemeId;
	}
	public void setSchemeId(int schemeId) {
		this.schemeId = schemeId;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public int getReConfigId() {
		return reConfigId;
	}
	public void setReConfigId(int reConfigId) {
		this.reConfigId = reConfigId;
	}
	public int getCondId() {
		return condId;
	}
	public void setCondId(int condId) {
		this.condId = condId;
	}
	public int getCondRowId() {
		return condRowId;
	}
	public void setCondRowId(int condRowId) {
		this.condRowId = condRowId;
	}
	public String getInputType() {
		return inputType;
	}
	public void setInputType(String inputType) {
		this.inputType = inputType;
	}
	public String getInputParameter() {
		return inputParameter;
	}
	public void setInputParameter(String inputParameter) {
		this.inputParameter = inputParameter;
	}
	public int getOpr() {
		return opr;
	}
	public void setOpr(int opr) {
		this.opr = opr;
	}
	public String getValueType() {
		return valueType;
	}
	public void setValueType(String valueType) {
		this.valueType = valueType;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public int getLopr() {
		return lopr;
	}
	public void setLopr(int lopr) {
		this.lopr = lopr;
	}
	public String getValFlag() {
		return valFlag;
	}
	public void setValFlag(String valFlag) {
		this.valFlag = valFlag;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Date getInsertDate() {
		return insertDate;
	}
	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}
	
	public String getCompName() {
		return compName;
	}
	public void setCompName(String compName) {
		this.compName = compName;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public String getOprName() {
		return oprName;
	}
	public void setOprName(String oprName) {
		this.oprName = oprName;
	}
	public int getCircleId() {
		return circleId;
	}
	public void setCircleId(int circleId) {
		this.circleId = circleId;
	}
	public String getGrossNet() {
		return grossNet;
	}
	public void setGrossNet(String grossNet) {
		this.grossNet = grossNet;
	}
	public int getUnit() {
		return unit;
	}
	public void setUnit(int unit) {
		this.unit = unit;
	}
	public String getUnitName() {
		return unitName;
	}
	public void setUnitName(String unitName) {
		this.unitName = unitName;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getVariable() {
		return variable;
	}
	public void setVariable(String variable) {
		this.variable = variable;
	}
	public String getVariableName() {
		return variableName;
	}
	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}
	public int getOverAch() {
		return overAch;
	}
	public void setOverAch(int overAch) {
		this.overAch = overAch;
	}
	public int getUnderAch() {
		return underAch;
	}
	public void setUnderAch(int underAch) {
		this.underAch = underAch;
	}
	public int getInputTypeId() {
		return inputTypeId;
	}
	public void setInputTypeId(int inputTypeId) {
		this.inputTypeId = inputTypeId;
	}
	public String getEaVariable() {
		return eaVariable;
	}
	public void setEaVariable(String eaVariable) {
		this.eaVariable = eaVariable;
	}
	public String getValueListName() {
		return ValueListName;
	}
	public void setValueListName(String valueListName) {
		ValueListName = valueListName;
	}
	public String getReaVariable() {
		return reaVariable;
	}
	public void setReaVariable(String reaVariable) {
		this.reaVariable = reaVariable;
	}
	public String getrValueListName() {
		return rValueListName;
	}
	public void setrValueListName(String rValueListName) {
		this.rValueListName = rValueListName;
	}
	public String getLoprName() {
		return loprName;
	}
	public void setLoprName(String loprName) {
		this.loprName = loprName;
	}
	public int getGrossNetInt() {
		return grossNetInt;
	}
	public void setGrossNetInt(int grossNetInt) {
		this.grossNetInt = grossNetInt;
	}
	public String getPaymentVariable() {
		return paymentVariable;
	}
	public void setPaymentVariable(String paymentVariable) {
		this.paymentVariable = paymentVariable;
	}
	public int getInsertEmptyRowType() {
		return insertEmptyRowType;
	}
	public void setInsertEmptyRowType(int insertEmptyRowType) {
		this.insertEmptyRowType = insertEmptyRowType;
	}
	private Date startDate;
	private Date rstartDate;
	private Date endDate;
	private Date rendDate;
	private int lopr;
	private int rlopr;
	private int grossNetInt;
	private String paymentVariable;
	private String valFlag;
	private String grossNet;
	private int unit;
	private String unitName;
	private BigDecimal amount;
	private String variable;
	private String variableName;
	private int overAch;
	private int underAch;
	
	private Date updateDate;
	private Date insertDate;
	
}

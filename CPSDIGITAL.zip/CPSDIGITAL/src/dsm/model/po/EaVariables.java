package dsm.model.po;

public class EaVariables {

	/**
	 * @param args
	 */
	
	private int compId;
	private int variableId;
	private  String variableName;
	private  String poVarFlag;
	private int poAttrType;
	private int poAttrCatg;
	
	private String oprType;
	public String getVariableName() {
		return variableName;
	}
	public void setVariableName(String variableName) {
		this.variableName = variableName;
	}
	public int getVariableId() {
		return variableId;
	}
	public void setVariableId(int variableId) {
		this.variableId = variableId;
	}
	public String getPoVarFlag() {
		return poVarFlag;
	}
	public void setPoVarFlag(String poVarFlag) {
		this.poVarFlag = poVarFlag;
	}
	public int getPoAttrType() {
		return poAttrType;
	}
	public void setPoAttrType(int poAttrType) {
		this.poAttrType = poAttrType;
	}
	public int getPoAttrCatg() {
		return poAttrCatg;
	}
	public void setPoAttrCatg(int poAttrCatg) {
		this.poAttrCatg = poAttrCatg;
	}
	public int getCompId() {
		return compId;
	}
	public void setCompId(int compId) {
		this.compId = compId;
	}
	public String getOprType() {
		return oprType;
	}
	public void setOprType(String oprType) {
		this.oprType = oprType;
	}

}

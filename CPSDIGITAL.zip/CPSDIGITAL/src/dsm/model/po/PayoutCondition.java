package dsm.model.po;

public class PayoutCondition {

private int schemeComponenetId;
private String schemeComponenet;	
private String inputType;
private int inputTypeId;
private String inputParameter;
private String opr;
private int oprId;
private int valueId;
private String valueType;
private int unitId;
private String unitName;
private int lopr;
public String getInputType() {
	return inputType;
}

public void setInputType(String inputType) {
	this.inputType = inputType;
}

public int getInputTypeId() {
	return inputTypeId;
}

public void setInputTypeId(int inputTypeId) {
	this.inputTypeId = inputTypeId;
}

public String getInputParameter() {
	return inputParameter;
}

public void setInputParameter(String inputParameter) {
	this.inputParameter = inputParameter;
}

public String getSchemeComponenet() {
	return schemeComponenet;
}

public void setSchemeComponenet(String schemeComponenet) {
	this.schemeComponenet = schemeComponenet;
}

public int getSchemeComponenetId() {
	return schemeComponenetId;
}

public void setSchemeComponenetId(int schemeComponenetId) {
	this.schemeComponenetId = schemeComponenetId;
}

public String getOpr() {
	return opr;
}

public void setOpr(String opr) {
	this.opr = opr;
}

public int getOprId() {
	return oprId;
}

public void setOprId(int oprId) {
	this.oprId = oprId;
}

public int getValueId() {
	return valueId;
}

public void setValueId(int valueId) {
	this.valueId = valueId;
}

public String getValueType() {
	return valueType;
}

public void setValueType(String valueType) {
	this.valueType = valueType;
}

public int getUnitId() {
	return unitId;
}

public void setUnitId(int unitId) {
	this.unitId = unitId;
}

public String getUnitName() {
	return unitName;
}

public void setUnitName(String unitName) {
	this.unitName = unitName;
}

public int getLopr() {
	return lopr;
}

public void setLopr(int lopr) {
	this.lopr = lopr;
}

}

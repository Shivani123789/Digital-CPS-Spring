package dsm.model.tq;

public class ValueTypeTQModel {

	private int valueTypeId;
	private String valueTypeName;
	public int getValueTypeId() {
		return valueTypeId;
	}
	public void setValueTypeId(int valueTypeId) {
		this.valueTypeId = valueTypeId;
	}
	public String getValueTypeName() {
		return valueTypeName;
	}
	public void setValueTypeName(String valueTypeName) {
		this.valueTypeName = valueTypeName;
	}
}

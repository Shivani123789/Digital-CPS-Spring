package dsm.model.tq;

public class ConditionNameTQModel {

	private int condId;
	private String condName;
	public int getCondId() {
		return condId;
	}
	public void setCondId(int condId) {
		this.condId = condId;
	}
	public String getCondName() {
		return condName;
	}
	public void setCondName(String condName) {
		this.condName = condName;
	}
	
}

package dsm.model.tq;

public class SchemeComponenetTQModel {
	
	private int schemeCmpId;
	private String schemeCmpName;
	public int getSchemeCmpId() {
		return schemeCmpId;
	}
	public void setSchemeCmpId(int schemeCmpId) {
		this.schemeCmpId = schemeCmpId;
	}
	public String getSchemeCmpName() {
		return schemeCmpName;
	}
	public void setSchemeCmpName(String schemeCmpName) {
		this.schemeCmpName = schemeCmpName;
	}

}

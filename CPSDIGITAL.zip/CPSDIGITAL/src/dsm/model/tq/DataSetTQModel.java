package dsm.model.tq;

public class DataSetTQModel {

private int dataSetId;
private String dataSetName;
public int getDataSetId() {
	return dataSetId;
}
public void setDataSetId(int dataSetId) {
	this.dataSetId = dataSetId;
}
public String getDataSetName() {
	return dataSetName;
}
public void setDataSetName(String dataSetName) {
	this.dataSetName = dataSetName;
}
	
}

package dsm.model.tq;

public class P_ParamTQModel {
private int paramId;
private int univId;
private String dtaType;
private String paramName;
public String getParamName() {
	return paramName;
}
public void setParamName(String paramName) {
	this.paramName = paramName;
}
public int getParamId() {
	return paramId;
}
public void setParamId(int paramId) {
	this.paramId = paramId;
}
public int getUnivId() {
	return univId;
}
public void setUnivId(int univId) {
	this.univId = univId;
}
public String getDtaType() {
	return dtaType;
}
public void setDtaType(String dtaType) {
	this.dtaType = dtaType;
}
}

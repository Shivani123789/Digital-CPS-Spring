package dsm.model.user;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class User {
private String userName;
private String userPassword;
private Set<String> userRole;
private int roleId;
private String userCircleCode;
private String circleName;
private int circleId;
private String roleName;
private int verticalId;
private String lastLogin;
private String ssVersion;
private List<String> userPrivilege;
private Map<String,Set<String>> userPrivileges;


public String getUserCircleCode() {
	return userCircleCode;
}
public void setUserCircleCode(String userCircleCode) {
	this.userCircleCode = userCircleCode;
}
public List<String> getUserPrivilege() {
	return userPrivilege;
}
public void setUserPrivilege(List<String> userPrivilege) {
	this.userPrivilege = userPrivilege;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getUserPassword() {
	return userPassword;
}
public void setUserPassword(String userPassword) {
	this.userPassword = userPassword;
}
public Set<String> getUserRole() {
	return userRole;
}
public void setUserRole(Set<String> userRole) {
	this.userRole = userRole;
}

public int getCircleId() {
	return circleId;
}
public void setCircleId(int circleId) {
	this.circleId = circleId;
}
public String getCircleName() {
	return circleName;
}
public void setCircleName(String circleName) {
	this.circleName = circleName;
}
public Map<String,Set<String>> getUserPrivileges() {
	return userPrivileges;
}
public void setUserPrivileges(Map<String,Set<String>> userPrivileges) {
	this.userPrivileges = userPrivileges;
}
public int getRoleId() {
	return roleId;
}
public void setRoleId(int roleId) {
	this.roleId = roleId;
}
public String getRoleName() {
	return roleName;
}
public void setRoleName(String roleName) {
	this.roleName = roleName;
}
public String getLastLogin() {
	return lastLogin;
}
public void setLastLogin(String lastLogin) {
	this.lastLogin = lastLogin;
}
public int getVerticalId() {
	return verticalId;
}
public void setVerticalId(int verticalId) {
	this.verticalId = verticalId;
}
public String getSsVersion() {
	return ssVersion;
}
public void setSsVersion(String ssVersion) {
	this.ssVersion = ssVersion;
}

}

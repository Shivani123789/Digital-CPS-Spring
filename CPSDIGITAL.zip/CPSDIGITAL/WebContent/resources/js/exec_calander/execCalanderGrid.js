Ext.onReady(function () {

	function CreatesubmitSchemeFilterStore() {
	    var store = new Ext.data.SimpleStore({
	        fields: ['id', 'name'],
	        data: [['1', 'Unsubmitted'], ['2', 'Failed']]
	    });
	    return store;
	}
	
	
	var execCalsd = null;
	var execCaled = null;
	
	function updateCalander(calForm)
	{

		calForm.down('form').getForm().submit({
			
			 waitMsg : 'Loading...',
			 url : 'searchscheme/updateCalander.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
			 method : 'POST',
	        
			 success: function(form, action) {
	            Ext.Msg.alert('Calander updated Sucessfully');
	          calForm.close();
			  execCalGrid.load({params:
                           	{
                           	startDate:	execCalsd ,
                           	endDate: execCaled,
                           //	filterBy:combo.getValue(),
                           	isMaster:false,
                           	isStage:true,
                           	condParam:'A'
                           	}});
	        },
	        failure: function(form, action) {
	        	if(action.result != null)
	            Ext.Msg.alert('Warning', action.result.errorMessage);
	        	else
	        		{
	        		if(action.response.status=403)
	        			Ext.Msg.alert('Warning','Access Denied');
	        		else
	        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
	        		}
	        }
	    });
	}

	//Search Grid
	
	var execCalSearch = new Ext.Panel({     
        stripeRows  : true,
        frame       : false,
        border: false,
        style       : 'padding-bottom: 5px',
        layout:'column',
        anchor: '100%',
        items       : [{
                        xtype       : 'datefield',
                        id          : 'startDateCal',
                        allowBlank  : true,
                        emptyText   : 'From',
                        name        : 'startDate',
                        //width       : 140,
                        editable    : false,
                      },{
                        xtype       : 'datefield',
                        id          : 'endDateCal',
                        allowBlank  : true,
                        emptyText   : 'To',
                        name        : 'endDate',
                        editable    : false,
                      }
                      ,
                      {
	        		    	   xtype :'textfield',
	        		    	   fieldLabel: 'CsrfName',
						   hidden:true,
	        		    	   disabled : true,
	        		    	   name: 'csrfExec',
						   maxLength : 100,
	        		    	   allowBlank:false,
	        		    	   id:'testCsrfExec'
	        		    },
                      {
                    	  xtype       : 'button',
                    	  text        : 'Go',
                    	  width       : 40,
                    	  handler     : function () {
                    		  execCalsd = Ext.Date.format(Ext.getCmp("startDateCal").getValue(),'d-M-y');
                    		  execCaled = Ext.Date.format(Ext.getCmp("endDateCal").getValue(),'d-M-y');
                    		  var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateCal").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateCal").getValue(),'Y/m/d'));	
                    		  if(flag){
                    			  execCalGrid.load({params:
                    			  {
                    				  startDate:	execCalsd ,
                    				  endDate: execCaled,
                    				  //	filterBy:combo.getValue(),
                    				  isMaster:false,
                    				  isStage:true,
                    				  condParam:'A'
                    			  }});
                    		  }
                    	  },
                      }
               ]
    });
	
	
	
	
	
	
	
	
	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	         ]);
	
   Ext.define('Scheme.model.Book', {
    extend: 'Ext.data.Model',
    fields: [
      {name: 'schemeName', type: 'string'},
      {name: 'circleName',  type: 'string'}
   
    ]
  });
 
   
      
   
   
   
   
   
  Ext.define('Scheme.store.Books', {
    extend  : 'Ext.data.Store',
    model   : 'Scheme.model.Book',
    fields  : ['title', 'author','price', 'qty'],
    data    : [
      { title: 'JDBC, Servlet and JSP', 
        author: 'Santosh Kumar', price: 300, qty : 12000 },
      { title: 'Head First Java', 
        author: 'Kathy Sierra', price: 550, qty : 2500 },
      { title: 'Java SCJP Certification', 
        author: 'Khalid Mughal', price: 650, qty : 5500 },
      { title: 'Spring and Hinernate', 
        author: 'Santosh Kumar', price: 350, qty : 2500 },
      { title: 'Mastering C++', 
        author: 'K. R. Venugopal', price: 400, qty : 1200 }
    ]
  });
 
   Ext.define('Scheme.view.ExecCalList', {
    extend: 'Ext.grid.Panel',
    id:'execCalGrid',
    stripeRows: true,
    flex: 2,
    hidden: false,
    
	height: '100%',
	layout: 'fit',
	
    loadMask: true,
    plugins: 'bufferedrenderer',
    remoteSort:true, remoteFilter :true, remoteGroup :true, 
    //pageSize : 5,
    alias: 'widget.ExecCalList',
    title: 'Execution Calander',
    store: execCalGrid,
    //height:500,
    autoScroll: true,
    
    initComponent: function () {
    	 var me = this;
      this.tbar = [
					execCalSearch
                ];
      this.columns = [
        
        { header: 'Scheme Id', dataIndex: 'schemeINputId', flex: 1 },
        { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
        { header: 'Comp Id', dataIndex: 'compId', flex: 1 },
		{ header: 'Comp Name', dataIndex: 'compName', flex: 1 },
		{ header: 'Create Date', dataIndex: 'insertTime', flex: 1 },
		{ header: 'PayTo', dataIndex: 'payTo', flex: 1 },
		{ header: 'Start Date', dataIndex: 'startDate', flex: 1 },
		{ header: 'End Date', dataIndex: 'endDate', flex: 1 },
		{ header: 'Status', dataIndex: 'execFreq', flex: 1 },
        { header: 'Exec Start', dataIndex: 'execStartDate', flex: 1 },
		{ header: 'Exec End', dataIndex: 'execEndDate', flex: 1 },
		{ header: 'Payout_AVL_Date', dataIndex: 'payoutAppDate', flex: 1 },
		{ header: 'StmGen Date', dataIndex: 'stmGenDate', flex: 1 },
       
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : execCalGrid,
			dock : 'bottom',
			displayInfo : true
		}
		
      ];
      
      this.callParent(arguments);
    }
    
    
    
    
    
 
  });
 
    Ext.define('Scheme.view.ExecCalForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.ExecCalForm',
      title   : 'Edit Calander',
      width   : 500,
      //height:   500,
      autoscroll:true,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [	          
                 
				 {
                		xtype:'fieldset',
                		anchor: '100%',
                		title: 'Execution Calander',
                		collapsible: true,
                		layout: 'column',
                		defaults: {
                			anchor: '100%'
                				},
                				items :[
                				        	{
                				        		xtype: 'container',
                				        		columnWidth:.5,
                				        		layout: 'anchor',
                				        		items:[
                				        		       
													   
													    {
																xtype : 'hidden',  //should use the more standard hiddenfield
																name  : 'schemeINputId'
														},
														
														
													    {
																xtype : 'hidden',  //should use the more standard hiddenfield
																name  : 'compId'
														},
                				        		       
                				        		       {
                				        		    	   xtype :'datefield',
                				        		    	   fieldLabel: 'Exec Start Date',
                				        		    	   name: 'execStartDate',
                				        		    	   allowBlank:false,
                				        		    	   editable: false,
                				        		       },
													   {
                				        		    	   xtype :'datefield',
                				        		    	   fieldLabel: 'Exec End Date',
                				        		    	   name: 'execEndDate',
                				        		    	   allowBlank:false,
                				        		    	   editable: false,
                				        		       },
													   {
                				        		    	   xtype :'datefield',
                				        		    	   fieldLabel: 'Payout Approval Date',
                				        		    	   name: 'payoutAppDate',
                				        		    	   allowBlank:false,
                				        		    	   editable: false,
                				        		       },
													   {
                				        		    	   xtype :'datefield',
                				        		    	   fieldLabel: 'Stmt Gen Date',
                				        		    	   name: 'stmGenDate',
                				        		    	   allowBlank:false,
                				        		    	   editable: false,
                				        		       }
            		
                				        		       
                				        		       ]
                				        	}
                				        
                				        
                				        ]}
        ]
      }],
      buttons: [	
					{
                		text    : 'Update',
                		handler : function () { 
                			
                			//updateCalander(this.up('window').down('form').getForm());
							updateCalander(this.up('window'));
                		//this.up('window').down('form').getForm().reset(); 
                	}
                	},
					
					/*{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
                	*/
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.ExecCalCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    
    views   : ['ExecCalList', 'ExecCalForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'ExecCalForm',
      selector: 'ExecCalForm',
      autoCreate: true
    }],
	init: function () {
      this.control({
          
        'ExecCalList': {
          itemdblclick: this.onRowdblclick
        }
        
      });
    },
    
    onRowdblclick: function(me, record, item, index) {
    	
    //	alert("hiiii");
      var win = this.getFormWindow();
      win.setTitle('Edit Calander');
      win.setAction('edit');
      win.setRecordIndex(record.data.schemeINputId);
      win.down('form').getForm().setValues(record.getData());
     win.show();
      
    }
   
    
  });
 
   
  
});
Ext.onReady(function() {

	Ext.require([ 'Ext.grid.plugin.BufferedRenderer' ]);

	var stmtDownData="";
	var stmtCycleId=0;
	var countID=1;
	var cycleEndDt=null;
	var stmtsrvcType="";
	
	var stmReqSearch = new Ext.Panel({
		stripeRows : true,
		frame : false,
		border : false,
		//width:'120%',
		style : 'padding-bottom: 5px',
		layout : 'column',
		anchor : '100%',
		items : [
{
	xtype:'fieldset',
	title: 'View Statement Period',
	collapsible: false,
	layout: 'column',
	bodyStyle:'padding:4px 4px',

	defaults: {
		anchor: '100%',
		width:200,
		bodyStyle:'padding:10px 10px',

	},
	items :[
{
	xtype :'combo',
	editable: false,
	allowBlank: false,
	name:'serviceType',
	id:'serviceType',
	disabled:false,
	emptyText   : 'Service Type',
	displayField:'serviceType',	
	valueField:'serviceType',
	store: stmtServiceType,
	listeners: {
		'select': function(combo, value){
			stmtsrvcType = combo.getValue();
			Ext.getCmp("stmtPeriod2").enable();
			Ext.getCmp("stmtPeriod2").setValue("");
			stmtSchemePeriod.load({
				params: 
				{  
					"serviceType":combo.getValue(),
				}
			});
		}
	},
	triggerAction:'all'
},  

	        {
	        	xtype :'combo',
	        	editable: false,
	        	allowBlank: false,
	        	name:'schemePeriod',
	        	id:'stmtPeriod2',
	        	disabled:true,
	        	emptyText   : 'Scheme Period',
	        	displayField:'startEndDt',	
	        	valueField:'startEndDt',
	        	store: stmtSchemePeriod,
	        	listeners: {
	        		'select': function(combo, value){
	        			var data  = stmtSchemePeriod.findRecord('startEndDt',combo.getValue());
	        			stmtCycleId=data.data.stmtCycleId;
	        			Ext.getCmp('viewStmtDtSQ').setValue(data.data.stmtDt);
	        			countID=data.data.countId;
	        			cycleEndDt=data.data.cycleEndDt;
	        		}
	        	},
	        	triggerAction:'all'
	        },  
	        {
		    	   xtype :'textfield',
		    	   fieldLabel: 'CsrfName',
				   hidden:true,
		    	   disabled : true,
		    	   name: 'csrfStm',
				   maxLength : 100,
		    	   allowBlank:false,
		    	   id:'testCsrfStm'
		    }
]
},
		         
		        
				/*{
					xtype : 'datefield',
					id : 'startDateReq',
					allowBlank : false,
					emptyText : 'StartDate',
					name : 'startDateReq',
					//width       : 140,
					editable : false,
				},
				{
					xtype : 'datefield',
					id : 'endDatesReq',
					allowBlank : false,
					emptyText : 'EndDate',
					name : 'endDatesReq',
					editable : false,
				},*/
{
	xtype:'fieldset',
	title: 'Action',
	collapsible: false,
	layout: 'column',
	bodyStyle:'padding:4px 4px',

	defaults: {
		anchor: '100%',
		width:50,
		bodyStyle:'padding:10px 10px',

	},
	items :[
			{
		  		xtype       : 'button',
		  		text        : 'Go',
		  		handler     : function () {
		  			if(countID==1){
		  				StmtReqStore.load({
			  				params : {
								"startDate"   : Ext.getCmp("stmtPeriod2").getValue(),
								"serviceType" : stmtsrvcType,
								"stmtCycleId" : stmtCycleId,
							}
						});
			  			
			  			tempSchemeStore.load({
			  				params : {
			  					"startDate" : Ext.getCmp("stmtPeriod2").getValue(),
			  					"stmtCycleId" : stmtCycleId,
			  					//"startDate" : Ext.Date.format(Ext.getCmp("startDateReq").getValue(), 'd-M-y'),
								//"endDate" : Ext.Date.format(Ext.getCmp("endDatesReq").getValue(), 'd-M-y'),
							}
						});
			  				
		  			}else{
		  				//Ext.Msg.alert("Warning","<font color='red'>Please select previous date period. It is not closed.</font>");
		  				StmtReqStore.clearFilter();
		  				tempSchemeStore.clearFilter();
		  				Ext.Msg.alert("Warning","<font color='red'>You can not request statement generation for this period. <br>Reason - Statement cycle for previous month is still OPEN.</font>");
		  			}
		  			
		  		},
			}      
]
},
{
	xtype:'fieldset',
	title: 'Statement Date',
	collapsible: false,
	layout: 'column',
	bodyStyle:'padding:4px 4px',

	defaults: {
		anchor: '100%',
		width:200,
		bodyStyle:'padding:10px 10px',

	},
	items :[
{
	xtype       : 'textfield',
	id          : 'viewStmtDtSQ',
	allowBlank  : true,
	emptyText   : 'Statement Date',
	name        : 'stmtDt',
	editable    : false,
	readOnly    : true,
}     
]
}
]
	});

	
	var stmSubReqSearch = new Ext.Panel({
		stripeRows : true,
		frame : false,
		border : false,
		style : 'padding-bottom: 5px',
		layout : 'column',
		anchor : '100%',
		items : [ {
			xtype : 'image',
			id : 'downImage',
			src : 'resources/images/bottommost.jpg',
			listeners : {
				afterrender : function(me) {
					me.getEl().on('click', function() {
						var grid = Ext.ComponentQuery.query('StmReqList')[0];
						tempSchemeStore.loadData(grid, true);
						var sm = grid.getSelectionModel();
						var rs = sm.getSelection();
						
						var test = Ext.getCmp("viewStmtDtSQ").getValue();
						//alert("tset :: "+(test.length===0)+"  empty::"+(Ext.getCmp("viewStmtDtSQ").getValue()!='')+"null::"+(Ext.getCmp("viewStmtDtSQ").getValue()!=null));
						if(test.length===0){
							var stmtDownData1 ="";
							var z = null;
							for (z = 0; z < rs.length; z++) {
								if((z+1)!=rs.length)
									stmtDownData1 += rs[z].data.scmId+","+rs[z].data.compId+","+rs[z].data.startDt+","+rs[z].data.endDt+","+stmtCycleId+","+rs[z].data.paymentDt+":";
								else
									stmtDownData1 += rs[z].data.scmId+","+rs[z].data.compId+","+rs[z].data.startDt+","+rs[z].data.endDt+","+stmtCycleId+","+rs[z].data.paymentDt;
							}
							var result = false;
							Ext.Ajax.request({
								url : 'stmtGen/insertSchemeStatementMap.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
								method: 'POST',
								params: {
									"stmtDownData":stmtDownData1,
								},
								
								success: function (response) {
        							Ext.ux.mask.hide();
        							var jsonResp = Ext.JSON.decode(response.responseText);
        							console.log(jsonResp	);
        							result = jsonResp.errorMessage;
        							//alert("result-----"+result);
        							if(result){
        								var i = null;
        								//alert("result:::: "+result);
        								for (i = 0; i < rs.length; i++){
        									tempSchemeStore.add({
        										scmId: rs[i].data.scmId,
        										scmName:rs[i].data.scmName,
        										compId:rs[i].data.compId,
        										compName:rs[i].data.compName,
        										payTo:rs[i].data.payTo,
        										payoutStatus:rs[i].data.payoutStatus,
        										payoutApprovalDt:rs[i].data.payoutApprovalDt,
        										paymentStatus:rs[i].data.paymentStatus,
        										scmApproveDt:rs[i].data.scmApproveDt,
        										startDt:rs[i].data.startDt,
        										endDt:rs[i].data.endDt,
        										paymentDt:rs[i].data.paymentDt
        									});
        								}

        								var grid2 = Ext.ComponentQuery.query('StmReqList')[0];
        								StmtReqStore.loadData(grid2, true);

        								StmtReqStore.suspendAutoSync();
        								var j=null;
        								for (j = 0; j < rs.length; j++){
        									StmtReqStore.remove(rs[j]);
        								}
        								StmtReqStore.resumeAutoSync();

        							}else{
        								Ext.Msg.alert("Warning","<font color='red'>You can not add scheme(s) now.<br>Reason - Please select 5 at a time.</font>");
        							}
								}
        						
							});

						

							
						}else{
							//Ext.Msg.alert("Warning","<font color='red'>The statement cycle is already generated.</font>");
							Ext.Msg.alert("Warning","<font color='red'>You can not add scheme(s) now.<br>Reason - The statement cycle has already been generated for this month.</font>");
						}	
					});
				}
			}
		}, {
			style : 'padding-left: 10px',
		}, {
			xtype : 'image',
			id : 'upImage',
			src : 'resources/images/topmost.jpg',
			listeners : {
				afterrender : function(me) {
					me.getEl().on('click', function() {
						var grid = Ext.ComponentQuery.query('StmReqSubList')[0];
						StmtReqStore.loadData(grid, true);
						var sm = grid.getSelectionModel();
						var rs = sm.getSelection();
						
						var test = Ext.getCmp("viewStmtDtSQ").getValue();
						//alert("tset :: "+(test.length===0)+"  empty::"+(Ext.getCmp("viewStmtDtSQ").getValue()!='')+"null::"+(Ext.getCmp("viewStmtDtSQ").getValue()!=null));
						if(test.length===0){
						
						var result = false;
						var stmtDownData2="";
						var z = null;
    					for (z = 0; z < rs.length; z++) {
    						if((z+1)!=rs.length)
    							stmtDownData2 += rs[z].data.scmId+","+rs[z].data.compId+":";
    						else
    							stmtDownData2 += rs[z].data.scmId+","+rs[z].data.compId;
    					}
						Ext.Ajax.request({
    						url : 'stmtGen/deleteSchemeStatementMap.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    						method: 'POST',
    						params: {
    							"stmtDownData":stmtDownData2,
    						},
    						success: function (response) {
    							Ext.ux.mask.hide();
    							var jsonResp = Ext.JSON.decode(response.responseText);
    							console.log(jsonResp	);
    							result = jsonResp.errorMessage;
    							if(result){
    								var i = null;
    								for (i = 0; i < rs.length; i++){
    									StmtReqStore.add({
    										scmId: rs[i].data.scmId,
    										scmName:rs[i].data.scmName,
    										compId:rs[i].data.compId,
    										compName:rs[i].data.compName,
    										payTo:rs[i].data.payTo,
    										payoutStatus:rs[i].data.payoutStatus,
    										payoutApprovalDt:rs[i].data.payoutApprovalDt,
    										paymentStatus:rs[i].data.paymentStatus,
    										scmApproveDt:rs[i].data.scmApproveDt,
    										startDt:rs[i].data.startDt,
    										endDt:rs[i].data.endDt,
    										paymentDt:rs[i].data.paymentDt
    									});
    								}
    								//var j = null;
    								var grid2 = Ext.ComponentQuery.query('StmReqSubList')[0];
    								tempSchemeStore.loadData(grid2, true);
    								
    								tempSchemeStore.suspendAutoSync();
    								var j=null;
    								for (j = 0; j < rs.length; j++){
    									tempSchemeStore.remove(rs[j]);
    								}
    								tempSchemeStore.resumeAutoSync();
    							}else{
    								Ext.Msg.alert("Warning","<font color='red'>You can not add scheme(s) now.<br>Reason - Please select 5 at a time.</font>");
    							}
    						}
    					});
						}else{
							//Ext.Msg.alert("Warning","<font color='red'>The statement cycle is already generated.</font>");
							Ext.Msg.alert("Warning","<font color='red'>You can not remove scheme(s) now.<br>Reason - The statement cycle has already been generated for this month.</font>");
						}
					});
				}
			}
		}, {
			style : 'padding-left: 20px',
		}, /*{
			xtype : 'button',
			text : 'Save',
			hidden:'true',
			height : 41,
			handler     : function () {
				var grid = Ext.ComponentQuery.query('StmReqSubList')[0];
				var sm = grid.getSelectionModel();
				var rs = sm.getSelection();
				stmtDownData="";
				if(rs.length)
        		{	                	
        			Ext.Msg.confirm('Save for Statement Generation', 
        					'Are You Sure You Want To Save All Seclected Scheme(s)', 
        					function (button) {
        				if (button == 'yes') {
        					Ext.ux.mask.show();
        					var i = null;
        					for (i = 0; i < rs.length; i++) {
        						if((i+1)!=rs.length)
        							stmtDownData += rs[i].data.scmId+","+rs[i].data.compId+":";
        						else
        							stmtDownData += rs[i].data.scmId+","+rs[i].data.compId;
        					}

        					Ext.Ajax.request({
        						url : 'stmtGen/saveSchemeStatementMap.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
        						method: 'POST',
        						params: {
        							"stmtDownData":stmtDownData,
        						},
        						success: function (response) {
        							Ext.ux.mask.hide();

        							var jsonResp = Ext.JSON.decode(response.responseText);
        							console.log(jsonResp	);
        							if(jsonResp.success==false)	
        							{
        								Ext.Msg.alert("Error",jsonResp.errorMessage);
        							}
        							else
        								Ext.Msg.alert("Info",jsonResp.errorMessage);
        							},
        						failure: function (response) {
        							Ext.ux.mask.hide();
        						}
        					});
        				}
        				else
        				{
        					Ext.ux.mask.hide();
        				}
        			});
        		}else{
        			Ext.Msg.alert("Warning","<font color='red'>No CheckBox Is Selected. Please Select Atleast one.</font>");
        		}
	  			
	  		},
		}, {
			style : 'padding-left: 20px','font-weight':'bold',
		},*/{
			xtype : 'button',
			style :{'font-weight':'bold',},
			text : 'Request for Statement Generation',
			height : 41,
			handler     : function () {
				var grid = Ext.ComponentQuery.query('StmReqSubList')[0];
				var sm = grid.getSelectionModel();
				var rs = sm.getSelection();
				if(rs.length===0){

				}
				var test = Ext.getCmp("viewStmtDtSQ").getValue();
				var myDate = Ext.Date.parse(cycleEndDt, 'd-M-Y');
				myDate.setDate(myDate.getDate() + 5);
				var currentDt = new Date();
				if(countID==1){
					if(currentDt>myDate){
						if(test.length===0 ){	                	
						Ext.Msg.confirm('Request for Statement Generation', 
								'Are you sure to generate statement for all the scheme(s)', 
								function (button) {
							if (button == 'yes') {
								Ext.ux.mask.show();
								Ext.Ajax.request({
									url : 'stmtGen/reqForStmtGenerate.action',
									method: 'GET',
									params: {
										"stmtDownData":stmtCycleId,
									},
									success: function (response) {
										Ext.ux.mask.hide();
										var jsonResp = Ext.JSON.decode(response.responseText);
										if(jsonResp.message=="1")
										{
											var date = new Date();
											// add a day
											date.setDate(date.getDate() + 1);
											Ext.getCmp('viewStmtDtSQ').setValue(Ext.Date.format(date,'d-M-y'));
											stmtSchemePeriod.clearFilter();
											stmtSchemePeriod.load();
											Ext.Msg.alert('Info','Successfully saved the schemes for statement generation.');
										}

										if(jsonResp.message=="2")
											Ext.Msg.alert('Warning','No Schemes Avaliable For Statement Generation.'); 
										if(jsonResp.message=="3")
											Ext.Msg.alert('Error','Failed to save the schemes for statement generation.');
										Ext.ux.mask.hide();
									},
									failure: function (response) {
										var jsonResp = Ext.JSON.decode(response.responseText);
										if(jsonResp.message=="2")
											Ext.Msg.alert('Warning','No Schemes Avaliable For Statement Generation.'); 
										if(jsonResp.message=="3")
											Ext.Msg.alert('Error','Failed to save the schemes for statement generation.');
										Ext.ux.mask.hide();
									} 
								});
							}
							else
							{
								Ext.ux.mask.hide();
							}
						});
					}else{
						//Ext.Msg.alert("Warning","<font color='red'>The statement cycle is already generated.</font>");
						Ext.Msg.alert("Warning","<font color='red'>You can not request statement generation for this period. <br>Reason - The statement generation is IN PROGRESS for this month.</font>");
					}
				}
				else{
					Ext.Msg.alert("Warning","<font color='red'>You can not request statement generation for this period.<br> Reason - Statement for any month can not be requested till 5th day of next month.</font>");
				}
			}else{
				Ext.Msg.alert("Warning","<font color='red'>You can not request statement generation for this period. <br>Reason - Statement cycle for previous month is still OPEN.</font>");
				}
			},
		},
		]
	});

	Ext.define('Scheme.view.StmReqList', {
		extend : 'Ext.grid.Panel',
		id : 'reqStmtGend',
		stripeRows : true,
		pageSize : 10,
		flex : 2,
		width : '100%',
		height : 250,
		//bodyStyle:'padding:3px 0px',
		hidden : false,
		loadMask : true,
		selModel : Ext.create('Ext.selection.CheckboxModel'),
		plugins : 'bufferedrenderer',
		remoteSort : true,
		remoteFilter : true,
		remoteGroup : true,
		alias : 'widget.StmReqList',
		store : StmtReqStore,
		autoScroll : true,
		initComponent : function() {
			this.tbar = [ stmReqSearch ];
			this.columns = [ 
			   { header : 'Scheme Id', dataIndex :'scmId', flex : 1	}, 
			   { header : 'Scheme Name', dataIndex :'scmName', flex : 1 },
			   { header : 'Comp Id', dataIndex :'compId', flex : 1	}, 
			   { header : 'Component Name', dataIndex :'compName', flex : 1 },
			   { header : 'Pay To', dataIndex :'payTo', flex : 1	}, 
			   { header : 'Payout Status', dataIndex :'payoutStatus', flex : 1 },
			   { header : 'Payout Date', dataIndex :'payoutApprovalDt', flex : 1 },
			   { header : 'Payment Status', dataIndex :'paymentStatus', flex : 1 },
			   { header : 'Payment Date', dataIndex :'paymentDt', flex : 1 },
			   { header : 'Scheme Approve Date', dataIndex :'scmApproveDt', flex : 1 },
			  ];

			this.dockedItems = [ {
				//xtype : 'pagingtoolbar',
				store : StmtReqStore,
				dock : 'bottom',
			//pageSize:10,
			//displayInfo : true
			} ];
			this.callParent(arguments);
		},
	});

	Ext.define('Scheme.view.StmReqSubList', {
		extend : 'Ext.grid.Panel',
		id : 'reqSubStmtGend',
		stripeRows : true,
		pageSize : 10,
		flex : 2,
		width : '100%',
		height : 300,
		//bodyStyle:'padding:3px 0px',
		hidden : false,
		loadMask : true,
		selModel : Ext.create('Ext.selection.CheckboxModel'),
		plugins : 'bufferedrenderer',
		remoteSort : true,
		remoteFilter : true,
		remoteGroup : true,
		alias : 'widget.StmReqSubList',
		store : tempSchemeStore,
		autoScroll : true,
		initComponent : function() {
			this.tbar = [ stmSubReqSearch ];
			this.columns = [
{ header : 'Scheme Id', dataIndex :'scmId', flex : 1	}, 
{ header : 'Scheme Name', dataIndex :'scmName', flex : 1 },
{ header : 'Comp Id', dataIndex :'compId', flex : 1	}, 
{ header : 'Component Name', dataIndex :'compName', flex : 1 },
{ header : 'Pay To', dataIndex :'payTo', flex : 1	}, 
{ header : 'Payout Status', dataIndex :'payoutStatus', flex : 1 },
{ header : 'Payout Date', dataIndex :'payoutApprovalDt', flex : 1 },
{ header : 'Payment Status', dataIndex :'paymentStatus', flex : 1 },
{ header : 'Payment Date', dataIndex :'paymentDt', flex : 1 },
{ header : 'Scheme Approve Date', dataIndex :'scmApproveDt', flex : 1 },   
];
			this.dockedItems = [ {
				//xtype : 'pagingtoolbar',
				store : tempSchemeStore,
				dock : 'bottom',
				//	pageSize:10,
				//	displayInfo : true
			} ];

			this.callParent(arguments);
		},
	});

	Ext.define('Scheme.controller.ScmReqCon', {
		extend : 'Ext.app.Controller',
		stores : [ 'Books' ],
		views : [ 'StmReqList', 'StmReqSubList' ],
	});

});
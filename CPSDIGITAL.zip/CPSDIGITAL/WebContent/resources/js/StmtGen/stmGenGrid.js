Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);






	var stmGenSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border: false,
		style       : 'padding-bottom: 5px',
		layout:'column',
		anchor: '100%',
		items       : [    {
			xtype:'fieldset',
			title: 'Statement Period',
			collapsible: false,
			layout: 'column',
			bodyStyle:'padding:4px 4px',

			defaults: {
				anchor: '100%',
				width:200,
				bodyStyle:'padding:10px 10px',

			},
			items :[
			        {
			        	xtype :'combo',
			        	editable: false,
			        	allowBlank: false,
			        	//fieldLabel: 'Component Name*',
			        	name:'schemePeriod',
			        	id:'schemePeriod',
			        	disabled:false,
			        	emptyText   : 'Scheme Period',
			        	displayField:'startEndDt',	
			        	valueField:'startEndDt',
			        	store: schemePeriodStore,
			        	listeners: {
			        		'select': function(combo, value){
			        			var grid = Ext.ComponentQuery.query('StmGenList')[0];
			        			//alert("stDt :: "+combo.getValue());
		    					
			        			
			        			var data  = schemePeriodStore.findRecord('startEndDt',combo.getValue());
			        			
			        			//alert(data.data.stmtDt);
			        			Ext.getCmp('stmtDt').setValue(data.data.stmtDt);
			        			grid.store.load({params:
			    				{
			        				"startEndDt":combo.getValue(),
			        				"stmtCycleId":data.data.stmtCycleId,
			    				}});
			        		}
			        	},
			        	triggerAction:'all'
			        }]
		},{   xtype:'fieldset',
			title: 'Statement Date',
			collapsible: false,
			layout: 'column',

			defaults: {
				anchor: '100%',
				width:100,
				bodyStyle:'padding:5px 5px',


			},
			items :[
			        {
			        	xtype       : 'textfield',
			        	id          : 'stmtDt',
			        	allowBlank  : true,
			        	emptyText   : 'Statement Date',
			        	name        : 'stmtDt',
			        	editable    : false,
			        	readOnly    : true,
			        }]
		}/*,
		,
		{
			xtype:'fieldset',
			title: 'Actions',
			collapsible: false,
			layout: 'column',

			defaults: {
				anchor: '100%',
				width:100,
				bodyStyle:'padding:5px 5px',


			},
			items :[

			        {
			        	xtype       : 'button',
			        	text        : 'View Statement',
			        	handler     : function () {

			        		stmGenGrid.load({params:
			        		{

			        		}});

			        	}

			        }]
		}*/]
	});





	/*var stmGenSearch = new Ext.Panel({     
       stripeRows  : true,
       frame       : false,
       border: false,
       style       : 'padding-bottom: 5px',
       layout:'column',
       anchor: '100%',
       items       : [

	   {
		    	   xtype:'fieldset',
		    	   title: 'Statement Period',
		    	   collapsible: true,
		    	   layout: 'column',
				   bodyStyle:'padding:4px 4px',

		    	   defaults: {
		    		   anchor: '100%',
		    		   width:200,
					bodyStyle:'padding:10px 10px',

		    	   },
		    	   items :[
						{
			xtype :'combo',
			editable: false,
			allowBlank: false,
			//fieldLabel: 'Component Name*',
			name:'schemePeriod',
			id:'schemePeriod',
			disabled:false,
			emptyText   : 'Scheme Period',
			displayField:'startEndDt',	
			valueField:'cycleId',
			store: schemePeriodStore,
			listeners: {
				'select': function(combo, value){

				}
			},
			triggerAction:'all'
		}]
		},

		{
		    	   xtype:'fieldset',
		    	   title: 'Actions',
		    	   collapsible: true,
		    	   layout: 'column',

		    	   defaults: {
		    		bodyStyle:'padding:20px 20px',

		    	   },
		    	   items :[

							{
                           xtype       : 'button',
                           text        : 'View Stm',
                           handler     : function () {

                        	   stmgenloadsd = Ext.Date.format(Ext.getCmp("startDatestmGen").getValue(),'d-M-y');
                        	   stmgenloaded = Ext.Date.format(Ext.getCmp("endDatestmGen").getValue(),'d-M-y');

                        	   stmGenGrid.load({params:
                           	{
                           	startDate:	approveloadsd ,
                           	endDate: approveloaded,
                           	isMaster:false,
                           	isStage:true,
                           	condParam:'A'
                           	}});

                     }

                   }]
				},
	         ]
   });
	 */	

	Ext.define('Scheme.view.StmGenList', {
		extend: 'Ext.grid.Panel',
		id:'stmtGene',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:520,
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.StmGenList',
		//title: 'Statement Generation',
		store: stmGenGrid,
		//height:500,
		autoScroll: true,

		initComponent: function () {
			var me = this;
			this.tbar = [
			             stmGenSearch
			             ];
			this.columns = [
			                { header: 'Scheme Id', dataIndex: 'schemeId', width:80},
			                { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
			                { header: 'Comp Id', dataIndex: 'compId', width:80 },
			                { header: 'Comp Name', dataIndex: 'compName', flex: 1 },
			                //{ header: 'Create Date', dataIndex: 'insertTime', flex: 1 },
			                { header: 'Start Date', dataIndex: 'startDt', flex: 1 },
			                { header: 'End Date', dataIndex: 'endDt', flex: 1 },
			                { header: 'Payment Mode', dataIndex: 'paymentMode', width:80 },
			                { header: 'Payment Amt', dataIndex: 'paymentAmt', flex: 1 },
			                { header: 'Max Payment', dataIndex: 'maxPayment', flex: 1 },
			                { header: 'Min Payment', dataIndex: 'minPayment', flex: 1 },
			                { header: 'Head Count', dataIndex: 'totalEntity', flex: 1 },
			                { header: 'Pay Date', dataIndex: 'insertDt', flex: 1 }
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : stmGenGrid,
				dock : 'bottom',
				displayInfo : true
			}
			];

			this.callParent(arguments);
		},





	});


	Ext.define('Scheme.controller.ScmGenCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],

		views   : ['StmGenList'],


	});



});
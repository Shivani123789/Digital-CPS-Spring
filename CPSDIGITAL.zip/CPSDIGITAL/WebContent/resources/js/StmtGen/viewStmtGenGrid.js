Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);
	
	
var startEndDtParam=null;
var stmtCycleDt=null;
var stmtCycleId12=null;

	var viewStmGenSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border: false,
		style       : 'padding-bottom: 5px',
		layout:'column',
		anchor: '100%',
		items       : [    {
			xtype:'fieldset',
			title: 'View Statement Period',
			collapsible: false,
			layout: 'column',
			bodyStyle:'padding:4px 4px',

			defaults: {
				anchor: '100%',
				width:200,
				bodyStyle:'padding:10px 10px',

			},
			items :[
{
	xtype :'combo',
	editable: false,
	allowBlank: false,
	name:'serviceType',
	id:'serviceType3',
	disabled:false,
	emptyText   : 'Service Type',
	displayField:'serviceType',	
	valueField:'serviceType',
	store: stmtServiceType,
	listeners: {
		'select': function(combo, value){
			stmtsrvcType = combo.getValue();
			Ext.getCmp("stmtPeriod3").enable();
			Ext.getCmp("stmtPeriod3").setValue("");
			Ext.getCmp("viewStmtDt").setValue("");
			schemePeriodStore.load({
				params: 
				{  
					"serviceType3":combo.getValue(),
				}
			});
		}
	},
	triggerAction:'all'
},  

			        {
			        	xtype :'combo',
			        	editable: false,
			        	allowBlank: false,
			        	//fieldLabel: 'Component Name*',
			        	name:'schemePeriod',
			        	id:'stmtPeriod3',
			        	disabled:true,
			        	emptyText   : 'Scheme Period',
			        	displayField:'startEndDt',	
			        	valueField:'startEndDt',
			        	store: schemePeriodStore,
			        	listeners: {
			        		'select': function(combo, value){
			        			var data  = schemePeriodStore.findRecord('startEndDt',combo.getValue());
			        			startEndDtParam=combo.getValue();
			        			Ext.getCmp('viewStmtDt').setValue(data.data.stmtDt);
			        			stmtCycleDt=data.data.stmtDt;
			        			stmtCycleId12=data.data.stmtCycleId;
			        		}
			        	},
			        	triggerAction:'all'
			        }]
		},{   xtype:'fieldset',
			title: 'Statement Date',
			collapsible: false,
			layout: 'column',

			defaults: {
				anchor: '100%',
				width:100,
				bodyStyle:'padding:5px 5px',
			},
			items :[
			        {
			        	xtype       : 'textfield',
			        	id          : 'viewStmtDt',
			        	allowBlank  : true,
			        	emptyText   : 'Statement Date',
			        	name        : 'stmtDt',
			        	editable    : false,
			        	readOnly    : true,
			        }]
		},
		{   xtype:'fieldset',
			title: 'CP Name',
			collapsible: false,
			layout: 'column',

			defaults: {
				anchor: '100%',
				width:100,
				bodyStyle:'padding:5px 5px',
			},
			items :[
			        {
			        	xtype       : 'textfield',
			        	id          : 'distId',
			        	allowBlank  : true,
			        	emptyText   : 'CP Name.',
			        	name        : 'distId',
			        	editable    : false,
			        	maxLength : 250,
			        	enforceMaxLength:"true"	
			        }]
		},
		{   xtype:'fieldset',
			title: 'CP Mobile',
			collapsible: false,
			layout: 'column',

			defaults: {
				anchor: '100%',
				width:100,
				bodyStyle:'padding:5px 5px',
			},
			items :[
			        {
			        	xtype       : 'textfield',
			        	id          : 'msisdn',
			        	allowBlank  : true,
			        	emptyText   : 'Mobile No.',
			        	name        : 'msisdn',
			        	editable    : false,
			        	maxLength : 100,
			        	enforceMaxLength:"true"	
			        }]
		},
		{
			xtype:'fieldset',
			title: 'Actions',
			collapsible: false,
			layout: 'column',
			defaults: {
				anchor: '100%',
				width:100,
				bodyStyle:'padding:5px 5px',
			},
			items :[
			        {
			        	xtype       : 'button',
			        	text        : 'View Statement',
			        	handler     : function () {
			        		var grid = Ext.ComponentQuery.query('ViewStmtGenList')[0];
			        		grid.store.load(
			        				{
			        					params:
			        					{
			        						startEndDt: Ext.getCmp('stmtPeriod3').getValue(),
			        						startEndDtParam: Ext.getCmp('stmtPeriod3').getValue(),
			        						msisdn: Ext.getCmp('msisdn').getValue(),
			        						distId: Ext.getCmp('distId').getValue(),
			        						page:1,
			        						start :	0,
			        						stmtCycleId:stmtCycleId12,
			        					}
			        				});
			        	}
			        }]
		},
		{
			xtype:'fieldset',
			title: 'e-mail : Selected Partner(s)',
			collapsible: false,
			layout: 'column',

			defaults: {
				anchor: '80%',
				width:80,
				bodyStyle:'padding:5px 5px',
			},
			items :[

			        {
			        	xtype       : 'button',
			        	text        : 'Send Email',
			        	id			: 'sendEmailIndividual',
			        	handler     : function () {
			        		var grid = Ext.ComponentQuery.query('ViewStmtGenList')[0];
			        		var sm = grid.getSelectionModel();
			        		var rs = sm.getSelection();
			        		if(rs.length)
			        		{	                	
			        			Ext.Msg.confirm('Statement Email Confirmation', 
			        					'Are you sure you want to send e-mail to selected Channel Partner ?', 
			        					function (button) {
			        				if (button == 'yes') {
			        					Ext.ux.mask.show();
			        					var distId = "";
			        					var i = null;
			        					for (i = 0; i < rs.length; i++) {
			        						if((i+1)!=rs.length)
			        							distId += rs[i].data.scmListId+","+startEndDtParam+":";
			        						else
			        							distId += rs[i].data.scmListId+","+startEndDtParam;
			        					}

			        					Ext.Ajax.request({
			        						url : 'stmtGen/selectedStmtGenEmailConfig.action',
			        						method: 'GET',
			        						params: {
			        							"distId":distId,
			        						},
			        						success: function (response) {
			        							Ext.ux.mask.hide();

			        							var jsonResp = Ext.JSON.decode(response.responseText);
			        							console.log(jsonResp	);
			        							if(jsonResp.success==false)	
			        							{
			        								Ext.Msg.alert("Error",jsonResp.errorMessage);
			        							}
			        							else
			        								Ext.Msg.alert("Info",jsonResp.errorMessage);
			        							},
			        						failure: function (response) {
			        							Ext.ux.mask.hide();

			        						}
			        					});
			        				}
			        				else
			        				{
			        					Ext.ux.mask.hide();
			        				}
			        			});
			        		}else{
			        			Ext.Msg.alert("Warning","<font color='red'>No CheckBox Is Selected. Please Select Atleast one.</font>");
			        		}
			        		/*grid.store.load({params:
			        		{
			        			startEndDt: Ext.getCmp('stmtPeriod').getValue(),
			        			startEndDtParam: Ext.getCmp('stmtPeriod').getValue(),
			        			msisdn: Ext.getCmp('msisdn').getValue(),
			        			page: 1,
			        			//start: 0,
			        		},start: 0
			        		});*/
			        	}
			        }]
		},
		{
			xtype:'fieldset',
			title: 'e-mail : All Partner',
			collapsible: false,
			layout: 'column',

			defaults: {
				anchor: '80%',
				width:80,
				bodyStyle:'padding:5px 5px',
			},
			items :[

			        {
			        	xtype       : 'button',
			        	text        : 'Send Email To All',
			        	id			: 'sendEmailToAll',
			        	handler     : function () {
			        		var grid = Ext.ComponentQuery.query('ViewStmtGenList')[0];
			        		var sm = grid.getSelectionModel();
			        		var rs = sm.getSelection();
			        		if(true && !(rs.length))
			        		{	                	
			        			Ext.Msg.confirm('Statement Email Confirmation', 
			        					'Are you sure you want to send e-mail to all Channel Partner ?', 
			        					function (button) {
			        				if (button == 'yes') {
			        					Ext.ux.mask.show();
			        					Ext.Ajax.request({
			        						url : 'stmtGen/stmtGenEmailConfig.action',
			        						method: 'GET',
			        						params: {
			        							"distId":stmtCycleId12,
			        							"startEndDtParam":startEndDtParam
			        						},
			        						success: function (response) {
			        							Ext.ux.mask.hide();

			        							var jsonResp = Ext.JSON.decode(response.responseText);
			        							console.log(jsonResp	);
			        							if(jsonResp.success==false)	
			        							{
			        								Ext.Msg.alert("Error",jsonResp.errorMessage);
			        							}
			        							else
			        								Ext.Msg.alert("Info",jsonResp.errorMessage);
			        							},
			        						failure: function (response) {
			        							Ext.ux.mask.hide();

			        						}
			        					});
			        				}
			        				else
			        				{
			        					Ext.ux.mask.hide();
			        				}
			        			});
			        		}else{
			        			Ext.Msg.alert("Warning","<font color='red'>This action can not be executed because you have selected one or more Partners. \nPlease un-select all the selected Partners.</font>");
			        		}
			        		/*grid.store.load({params:
			        		{
			        			startEndDt: Ext.getCmp('stmtPeriod').getValue(),
			        			startEndDtParam: Ext.getCmp('stmtPeriod').getValue(),
			        			msisdn: Ext.getCmp('msisdn').getValue(),
			        			page: 1,
			        			//start: 0,
			        		},start: 0
			        		});*/
			        	}
			        }]
		}
		]
	});



	Ext.define('Scheme.view.ViewStmtGenList', {
		extend: 'Ext.grid.Panel',
		id:'viewStmtGend',
		stripeRows: true,
		pageSize:1000,
		flex: 2,
		width:'100%',
		height:520,
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		selModel : Ext.create('Ext.selection.CheckboxModel'),
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.ViewStmtGenList',
		store: viewStmtGenGrid,
		autoScroll: true,
		
		initComponent: function () {
			var me = this;
			this.tbar = [
			             viewStmGenSearch
			             ];
			this.columns = [
			                { header: 'CP ID', dataIndex: 'cpId', width:80},
			                { header: 'CP Name', dataIndex: 'cpName', width:80 },
			                { header: 'Partner Type', dataIndex: 'partnerType', width:90 },
			                { header: 'Email', dataIndex: 'email',  flex: 1 },
			                { header: 'Beneficiary', dataIndex: 'beneficiary', width:80},
			                { header: 'Application Name', dataIndex: 'applicationName', width:80},
			                { header: 'Gross', dataIndex: 'totGrossAmt', width:80},
			                { header: 'Net', dataIndex: 'totNetAmt', width:80 },
			                { header: 'Total', dataIndex: 'grandTotal', width:80 },
			                { header: 'View', width:80,
	    	                	renderer: function (v, m, r) {
	    	                		var id = Ext.id();
	    	                		//alert(rs[0].data.schemeINputId);
	    	                		//alert(id);
	    	                		//var max = 15;
	    	                		Ext.defer(function () {
	    	                			Ext.widget('image', {
	    	                				renderTo: id,
	    	                				name: 'download',
	    	                				src : 'resources/images/PDFView30.png',
	    	                				listeners : {
	    	                					afterrender: function (me) {
	    	                						me.getEl().on('click', function() {
	    	                							var grid = Ext.ComponentQuery.query('ViewStmtGenList')[0];
	    	                							if (grid) {
	    	                								var sm = grid.getSelectionModel();
	    	                								var rs = sm.getSelection();
	    	                								if (!rs.length) {
	    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
	    	                									return;
	    	                								}
	    	                								//alert("Test :: "+stmtCycleDt);
	    	                								Ext.Msg.confirm('Download Statement', 
	    	                										'Do You want to Download Statement?', 
	    	                										function (button) {
	    	                									if (button == 'yes') {
	    	                										var urlParam = './reports/downloadChannelPartnerViewStmtPDF.action?distDsm2Id='+rs[0].data.scmListId +'&startEndDtParam='+startEndDtParam+'&stmtCycleDt='+stmtCycleDt;
	    	                										window.open(urlParam,'_blank');
	    	                									}
	    	                								});
	    	                							}
	    	                						});
	    	                					}
	    	                				}
	    	                			});
	    	                		}, 700);
	    	                		return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                },
	    	                { header: 'SCM List ID', dataIndex: 'scmListId', width:80 },
	    	                { header: 'Circle Zip', width:80,
	    	                	renderer: function (v, m, r) {
	    	                		var id = Ext.id();
	    	                		//alert(rs[0].data.schemeINputId);
	    	                	//alert(id);
	    	                		//var max = 15;
	    	                		Ext.defer(function () {
	    	                			Ext.widget('image', {
	    	                				renderTo: id,
	    	                				name: 'download',
	    	                				src : 'resources/images/download30.png',
	    	                				listeners : {
	    	                					afterrender: function (me) {
	    	                						me.getEl().on('click', function() {
	    	                							var grid = Ext.ComponentQuery.query('ViewStmtGenList')[0];
	    	                							if (grid) {
	    	                								var sm = grid.getSelectionModel();
	    	                								var rs = sm.getSelection();
	    	                								if (!rs.length) {
	    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
	    	                									return;
	    	                								}
	    	                								//alert("Test :: "+startEndDtParam);
	    	                								Ext.Msg.confirm('Download circlewise pdf', 
	    	                										'You want to download circlewise pdf?', 
	    	                										function (button) {
	    	                									if (button == 'yes') {
	    	                									//	alert(""+rs[0].data.distDsm2Id+""+startEndDtParam);
	    	                										var urlParam = './stmtGen/generateCircleWiseStmtPDFZip.action?distDsm2Id='+rs[0].data.scmListId +'&startEndDtParam='+startEndDtParam;
	    	                										window.open(urlParam,'_blank');
	    	                									}
	    	                								});
	    	                							}
	    	                						});
	    	                					}
	    	                				}
	    	                			});
	    	                		}, 700);
	    	                		return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                },
	    	                { header: 'Csv Download', width:80,
	    	                	renderer: function (v, m, r) {
	    	                		var id = Ext.id();
	    	                		//alert(rs[0].data.schemeINputId);
	    	                	//alert(id);
	    	                		//var max = 15;
	    	                		Ext.defer(function () {
	    	                			Ext.widget('image', {
	    	                				renderTo: id,
	    	                				name: 'download',
	    	                				src : 'resources/images/csv_download.jpg',
	    	                				listeners : {
	    	                					afterrender: function (me) {
	    	                						me.getEl().on('click', function() {
	    	                							var grid = Ext.ComponentQuery.query('ViewStmtGenList')[0];
	    	                							if (grid) {
	    	                								var sm = grid.getSelectionModel();
	    	                								var rs = sm.getSelection();
	    	                								if (!rs.length) {
	    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
	    	                									return;
	    	                								}
	    	                								if(!(rs[0].data.applicationName=='IDEA Music'))
	    	                									{
	    	                									Ext.Msg.alert('Warning','Cannot Download '+rs[0].data.applicationName+' data');
	    	                									}
	    	                								//alert("Test :: "+startEndDtParam);
	    	                								else
	    	                									{
	    	                								Ext.Msg.confirm('Download Csv', 
	    	                										'You want to download Data Csv?', 
	    	                										function (button) {
	    	                									if (button == 'yes') {
	    	                									//	alert(""+rs[0].data.distDsm2Id+""+startEndDtParam);
	    	                										var urlParam = './stmtGen/generateCircleWiseCsv.action?cpName='+rs[0].data.cpName +'&startEndDtParam='+startEndDtParam;
	    	                										window.open(urlParam,'_blank');
	    	                									}
	    	                								});
	    	                									}
	    	                							}
	    	                						});
	    	                					}
	    	                				}
	    	                			});
	    	                		}, 700);
	    	                		return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                }
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : viewStmtGenGrid,
				dock : 'bottom',
				pageSize:10,
				displayInfo : true
			}];
			this.callParent(arguments);
		},
		listeners:
		{
		
		select :function()
		{
			
			var grid = Ext.ComponentQuery.query('ViewStmtGenList')[0];
				var sm = grid.getSelectionModel();
				var rs = sm.getSelection();

				Ext.getCmp('sendEmailIndividual').enable();
				Ext.getCmp('sendEmailToAll').disable();
		},
		
	   deselect: function()
	   {
		   var grid = Ext.ComponentQuery.query('ViewStmtGenList')[0];
			var sm = grid.getSelectionModel();
			var rs = sm.getSelection();
		   if(rs.length==0)
			   {
			   Ext.getCmp('sendEmailIndividual').disable();
				Ext.getCmp('sendEmailToAll').enable();
			   }
	   }
		}
		
	});


	Ext.define('Scheme.controller.ViewStmtGenCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['ViewStmtGenList'],
	});



});
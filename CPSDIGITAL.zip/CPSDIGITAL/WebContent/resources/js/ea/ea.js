var eaGridStatus = 0;
var seaGridStatus = 0;
var eaVariableName = null;
var compIdEa = null;
var condIdEa = null;

function saveEa(eaForm)
{

	eaForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 //url : addEaUrl,
		 url : 'payoutcondition/addEa.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
        
		 success: function(form, action) {
            Ext.Msg.alert('Performance Aggregate added sucessfully');
            poFilterStore.load();
            poFilterVariables.load();
            eaVariableStore.load();
            eaStore.load();
            eaForm.close();
			
			formPanel.items.each(function(c){
		    	
			c.items.items[6].setDisabled(false);
						c.setActiveTab(c.items.items[6]);
									c.items.items[7].setDisabled(false);
						

						})

        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        }
    });
}

function updateEa(eaForm)
{

	eaForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		//url : 'payoutcondition/updateEa.action',
		 url : 'payoutcondition/updateEa.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
		 
		 params: {
			  "compId" : compIdEa,
			  "condId":condIdEa
		    },
		
        
		 success: function(form, action) {
            Ext.Msg.alert('Performance Aggregate updated sucessfully');
            poFilterStore.load();
            poFilterVariables.load();
            eaStore.load();
            eaForm.close();
            //form.reset();
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        }
    });
	//alert("hii");
	
}



var eaList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	//height:600,
 	
   items:[{
	   
     		xtype:'fieldset',
     		//title: 'Edit Scheme',
     		//collapsible: true,
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     //			width:230
     		
     		},
     		items :[
     			{
             		html: "<div id='ealist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});


var seaList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	//height:600,
 	
   items:[{
	   
     		xtype:'fieldset',
     		//title: 'Edit Scheme',
     		//collapsible: true,
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     //			width:230
     		
     		},
     		items :[
     			{
             		html: "<div id='sealist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
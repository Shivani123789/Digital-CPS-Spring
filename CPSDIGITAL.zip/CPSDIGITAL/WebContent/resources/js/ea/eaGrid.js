Ext.onReady(function () {
	Ext.define('Scheme.model.Ea', {
		extend: 'Ext.data.Model',
		fields: [
		         {name: 'compId', type: 'int'},
		         {name: 'compName',  type: 'string'},
		         {name: 'condId', type: 'int'},
		         {name: 'variableName',  type: 'string'}

		         ]
	});

	var entityTypeEa = null;
	var condType = null;
	var compId = null;
	var dataSourceType = null;
	var functionId = null;
	var additionalFlag = null;
	var maxVal=null;
	//var stdateEa = null;
	//var enddateEa = null;

	Ext.define('Scheme.view.EaList', {
		extend: 'Ext.grid.Panel',
		name:'eaGrid',
		pageSize : 5,
		alias: 'widget.EaList',
		title: 'Ea List',
		store: eaStore,
		selModel : Ext.create('Ext.selection.CheckboxModel'),
		height:500,
		//layout:'fit',
		autoScroll: true,
		//  store : 'Companies',
		initComponent: function () {
			this.tbar = [
{
	xtype:'image',
	src:'resources/images/book_delete.png',
	listeners:
		{
		afterrender: function(me)
			{
			    me.getEl().on('click',function()	
			    		{
					var grid = Ext.ComponentQuery.query('EaList')[0];
					if (grid) {
						var sm = grid.getSelectionModel();
						var rs = sm.getSelection();
						if (!rs.length) {
							Ext.Msg.alert('Info', 'No Ea Selected');
							return;
						}
						Ext.Msg.confirm('Remove EA', 
								'Are you sure you want to delete EA?', 
								function (button) {
							if (button == 'yes') {
                         


								//ajax post to remove
                         
								
								var eaParamVal="";
	                        	  
	                        	  for(var i=0;i<rs.length;i++)
	                        		  {
	                        		  if((i+1)!=rs.length)
	                        			  eaParamVal +=rs[i].data.compId+","+rs[i].data.variableId+":";
	                        		  else
	                        			  eaParamVal +=rs[i].data.compId+","+rs[i].data.variableId;  
	                        		  }
								
								
								Ext.Ajax.request({
									url : 'payoutcondition/removeEa.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
									method: 'POST',
									params: {
										"parameter":eaParamVal
									},
									success: function (response) {
										Ext.Msg.alert("Info","EA deleted Sucessfully");
										schemeStore.load();
									},

									failure: function (response) {
									}
								});
								  for(var i=0;i<rs.length;i++)
									  grid.store.remove(rs[i]);
                        	  
							
								
								/*Ext.Ajax.request({
									url : 'payoutcondition/removeEa.action',
									method: 'POST',
									params: {
										"compId" : rs[i].data.compId,
										"variableId" :rs[i].data.variableId
									},
									success: function (response) {
										Ext.Msg.alert("Info","EA deleted Sucessfully");
										schemeStore.load();
									},
									failure: function (response) {
									}
								});
								grid.store.remove(rs[i]);
                        	 // }
*/							}
						});
					}
			    		});
			}
		}
},
			             {
				text    : 'Add',
				action  : 'add',
				iconCls : 'book-add'
			},
			
			{
           	 itemId: 'copyEA',
           	 text: 'Copy Variable',
           	 iconCls: 'employee-copy',
           	 //disabled: true,
           	 handler: function() {
           		 var grid = Ext.ComponentQuery.query('EaList')[0];
           		 if (grid) {
           			 var sm = grid.getSelectionModel();
           			 var rs = sm.getSelection();
           			 if (!rs.length) {
           				 Ext.Msg.alert('Info', 'No EA Selected');
           				 return;
           			 }
           			 Ext.Msg.confirm('Copy EA', 
           					 'Are you sure you want to copy EA variable?', 
           					 function (button) {
           				 if (button == 'yes') {

           					 var tqParamVal = true;

           					 for(var i=0; i<rs.length; i++)
           					 {
           						 if((i+1) != rs.length){
           							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.variableId != rs[0].data.variableId){
           								tqParamVal=false;
              							 Ext.Msg.alert("Warning","<font color='red'>Please select only one variable at a time. To copy variable.</font>");
           							 }
           								 
           						 }else{
           							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.variableId != rs[0].data.variableId){
           								tqParamVal=false;	  
              							 Ext.Msg.alert("Warning","<font color='red'>Please select only one variable at a time. To copy variable.</font>");
           							 }
           								 
           						 }
           					 }

           					 if(tqParamVal){ 
           						 /*Ext.Ajax.request({
           							 url : 'schemeinput_tq/copyCondition.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
           							 method: 'POST',
           							 params: {
           								 "compId" : rs[0].data.compId,
           								 "condId" : rs[0].data.variableId,
           								 "processType" : 'EA',
           							 },
           							 success: function (response) {
           								 var response1 = Ext.decode(response.responseText);
           								 Ext.Msg.alert("Info",response1.message);
           								schemeStore.load();
           								eaStore.load();
           							 },
           							 failure: function (response) {
           							 }
           						 });*/
           						 
            					 var myForm = new Ext.form.Panel({
            						 	width: 300,
            							height: 200,
            							//	    layout: 'anchor',
            							title: 'Copy Variable',
            							floating: true,
            							border: true,
            							frame : true,
            							closable : true,
            							bodyStyle: {
            								//  background: 'none',
            								padding: '10px',
            								border: '0',
            							},
            							items:[
            							       {
            							    	   xtype : 'hidden',  //should use the more standard hiddenfield
            							    	   name  : 'schemeId',
            							    	   value: rs[0].data.schemeINputId,
            							       },
            							       {
            							    	   xtype : 'hidden',  //should use the more standard hiddenfield
            							    	   name  : 'compId',
            							    	   value: rs[0].data.compId,
            							       },
            							       {
            							    	   xtype :'textfield',
            							    	   fieldLabel: 'New variable name',
            							    	   name: 'newVariableName',
            							    	   allowBlank:false,
            							    	   id:'newVariableName'
            							       }
            							       ],

            							       buttons: [	
            							                 {
            							                	 text: 'Ok',
            							                	 id:'newVariableCond',
            							                	 //action: 'add'
            							                	 handler: function () {
            							                		 Ext.getCmp("newVariableCond").disable();
            							                		 if(Ext.getCmp("newVariableName").getValue()!=null && Ext.getCmp("newVariableName").getValue()!="")
            							                			 {
            		    	            						 Ext.Ajax.request({
            		    	            							 url : 'schemeinput_tq/copyCondition.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
            		    	            							 method: 'POST',
            		    	            							 params: {
            		    	            								 "compId" : rs[0].data.compId,
            		    	            								 "condId" : rs[0].data.variableId,
            		    	            								 "processType" : 'EA',
            		    	            								 "newCondName":Ext.getCmp("newVariableName").getValue()
            		    	            							 },
            		    	            							 success: function (response) {
            		    	               								 var response1 = Ext.decode(response.responseText);
            		    	               								 Ext.Msg.alert("Info",response1.message);
            		    	               								schemeStore.load();
            		    	               								eaStore.load();
            		    	               								myForm.close();
            		    	               								},
            		    	            							 failure: function (response) {
            		    	            								// myForm.close();
            		    	            							 }
            		    	            						 });
            							                	 }
            							                	 }
            							                 },
            							                 {
            							                	 text   : 'Cancel',
            							                	 handler: function () { 
            							                		 myForm.close();
            							                	 }
            							                 }]

            						});
            					 myForm.show();
           					 }
           				 }
           			 });
           		 }
           	 }
            }
			];
			this.columns = [
			                { header: 'compId', dataIndex: 'compId', width: 60 },
			                { header: 'variableId', dataIndex: 'variableId', width: 60 },
			                //{ header: 'compName', dataIndex: 'compName', flex: 1 },
			                { header: 'variableName', dataIndex: 'variableName', flex: 1  },
			                { header: 'DataSet', dataIndex: 'dataSetName', flex: 1  },
			                { header: 'Entity', dataIndex: 'entityTypeName', width: 60 },
			                { header: 'DataSource', dataIndex: 'dataSourceName', width: 60 },
			                { header: 'Function', dataIndex: 'functionName', width: 60 },
			                { header: 'parameter', dataIndex: 'parameter', width: 60 },
			                { header: 'oprName', dataIndex: 'oprName', width: 60 },
			                { header: 'valueType', dataIndex: 'valueType', width: 60 },
			                { header: 'value', dataIndex: 'value', width: 60 },
			                { header: 'startDate', dataIndex: 'startDate', width: 60 },
			                { header: 'endDate', dataIndex: 'endDate', width: 60 },
			               // { header: 'Day Lvl Aggr', dataIndex: 'daylvlAggr', width: 60 },
/*			                { header: 'Action', width: 50,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		var max = 15;
			                		Ext.defer(function () {
			                			Ext.widget('image', {
			                				renderTo: id,
			                				name: 'delete',
			                				src : 'resources/images/book_delete.png',
			                				listeners : {
			                					afterrender: function (me) { 
			                						me.getEl().on('click', function() {
			                							var grid = Ext.ComponentQuery.query('EaList')[0];
			                							if (grid) {
			                								var sm = grid.getSelectionModel();
			                								var rs = sm.getSelection();
			                								if (!rs.length) {
			                									Ext.Msg.alert('Info', 'No Ea Selected');
			                									return;
			                								}
			                								Ext.Msg.confirm('Remove EA', 
			                										'Are you sure you want to delete EA?', 
			                										function (button) {
			                									if (button == 'yes') {

			                										//ajax post to remove

			                										Ext.Ajax.request({
			                											url : 'payoutcondition/removeEa.action',
			                											method: 'POST',
			                											params: {
			                												"compId" : rs[0].data.compId,
			                												"variableId" :rs[0].data.variableId
			                											},
			                											success: function (response) {
			                												Ext.Msg.alert("Info","EA deleted Sucessfully");
			                												schemeStore.load();
			                											},

			                											failure: function (response) {
			                											}
			                										});
			                										grid.store.remove(rs[0]);
			                									}
			                								});
			                							}
			                						});
			                					}
			                				}
			                			});
			                		}, 50);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                }*/
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : eaStore,
				dock : 'bottom',
				displayInfo : true
			} ];

			this.callParent(arguments);
		}
	});

	Ext.define('Scheme.view.EaForm', {
		extend  : 'Ext.window.Window',
		alias   : 'widget.EaForm',
		title   : 'Add EA',
		//width   : 350,
		layout  : 'fit',
		resizable: false,
		closeAction: 'hide',
		modal   : true,
		config  : {
			recordIndex : 0,
			action : ''
		},
		items   : [{
			xtype : 'form',
			layout: 'anchor',
			bodyStyle: {
				background: 'none',
				padding: '10px',
				border: '0'
			},
			defaults: {
				anchor: '100%'
			},
items : [
         {
        	 xtype: 'fieldset',
        	 anchor: '100%',
        	 title: 'Entity Details',
        	 collapsible: true,
        	 layout:'column',
        	 items:[
        	        {
        	        	xtype: 'container',
        	        	columnWidth:.2,
        	        	layout: 'anchor',
        	        	items: [
        	        	        {
        	        	        	xtype :'combo',
        	        	        	fieldLabel: 'Component',
        	        	        	name:'compId',
        	        	        	id: 'eaCompList',
        	        	        	displayField:'compName',
        	        	        	valueField:'compId',
        	        	        	editable: false,
        	        	        	store: componentListStore,
        	        	        	listeners: {
        	        	        		'select': function(combo, value){
        	        	        			compId = combo.getValue();
        	        	        			var obj=componentListStore.findRecord('compId',compId,0, false, true, true);
        	        	        			//var payToId=obj.data.payTo;
        	        	        			//entityStoreEa.clearFilter();
        	        	        			/*var sysId=obj.data.systemId;
        	        	        			
        	        	        			if(sysId==2){
        	        	        				
        	        	        			}else{
        	        	        				entityStoreEa.filter(function(r) {
            	        	        				var value = r.get('entityId');
            	        	        				return (value >= payToId);
            	        	        			});	
        	        	        			}*/
        	        	        			
        	        	        			this.up('window').down('form').getForm().findField("dataSourceName").reset();
        	        	        			this.up('window').down('form').getForm().findField("dataSet").reset();
        	        	        		}
        	        	        	},
        	        	        	triggerAction:'all'
        	        	        } ,
        	        	        {
        	        	        	xtype :'textfield',
        	        	        	fieldLabel: 'Variable Name',
        	        	        	allowBlank:false,
        	        	        	maxLength : 50,
        	        	        	enforceMaxLength:"true",
        	        	        	//maskRe:/[A-Za-z0-9_ ]/,
        	        	        	name:'variableName'
        	        	        },
        	        	        {
        	        	        	xtype :'combo',
        	        	        	allowBlank:false,
        	        	        	editable: false,
        	        	        	fieldLabel: 'Data Set',
        	        	        	name:'dataSet',
        	        	        	displayField:'dataSetName',
        	        	        	valueField:'dataSetId',
        	        	        	store: dataSetStoreEa,
        	        	        	listeners: {
        	        	        		'select': function(combo, value){
        	        	        			additionalFlag = false;
        	        	        			this.up('window').down('form').getForm().findField("function").enable();
        	        	        			this.up('window').down('form').getForm().findField("opr").enable();
        	        	        			this.up('window').down('form').getForm().findField("valueType").enable();
        	        	        			this.up('window').down('form').getForm().findField("value").enable();
        	        	        			this.up('window').down('form').getForm().findField("ValueListName").enable();
        	        	        			this.up('window').down('form').getForm().findField("startDate").allowBlank = true;
        	        	        			this.up('window').down('form').getForm().findField("endDate").allowBlank = true;
        	        	        			this.up('window').down('form').getForm().findField("dataSourceName").readOnly = false;
        	        	        			this.up('window').down('form').getForm().findField("dataSourceName").reset();
        	        	        			
        	        	        			this.up('window').down('form').getForm().findField("entityType").reset();
        	        	        			this.up('window').down('form').getForm().findField("function").reset();
        	        	        			this.up('window').down('form').getForm().findField("parameter").reset();
        	        	        			this.up('window').down('form').getForm().findField("opr").reset();
        	        	        			this.up('window').down('form').getForm().findField("valueType").reset();
        	        	        			this.up('window').down('form').getForm().findField("value").reset();
        	        	        			this.up('window').down('form').getForm().findField("ValueListName").reset();
        	        	        			this.up('window').down('form').getForm().findField("startDate").reset();
        	        	        			this.up('window').down('form').getForm().findField("endDate").reset();
        	        	        			this.up('window').down('form').getForm().findField("daylvlAggrId").reset();
        	        	        			this.up('window').down('form').getForm().findField("daylvlAggrId").disable();
        	        	        			condType = combo.getValue();
        	        	        			if(combo.getValue()==1)
        	        	        			{
        	        	        				this.up('window').down('form').getForm().findField("parameter").reset();
        	        	        				this.up('window').down('form').getForm().findField("parameter").readOnly = false;

        	        	        				parameterStoreEa.clearFilter();
        	        	        				parameterStoreEa.filter('valFlag','C');

        	        	        				if(compId==null)
        	        	        					compId=Ext.getCmp('eaCompList').getValue();

        	        	        				dataSourceStoreEa.clearFilter();
        	        	        				dataSourceStoreEa.filter('compId',compId);

        	        	        				dataSourceStoreEa.filter('valFlag','C');
        	        	        				this.up('window').down('form').getForm().findField("dataSourceName").enable();
        	        	        				//function
        	        	        				this.up('window').down('form').getForm().findField("function").allowBlank=false;
        	        	        				//parameter
        	        	        				valueTypeStoreEa.clearFilter();
        	        	        				valueTypeStoreEa.filter('valueTypeId',1);
        	        	        				functionStoreEa.clearFilter();
        	        	        				functionStoreEa.filter('functionType','A');
        	        	        				oprStoreEa.clearFilter();
        	        	        				oprStoreEa.filter('valFlagcon','Y');

        	        	        				oprStoreEa.filter(function(r) {
        	        	        					var value = r.get('oprType');
        	        	        					return (value == 'R');
        	        	        				});
        	        	        				
        	        	        				
        	        	        				this.up('window').down('form').getForm().findField("daylvlAggrId").enable();
        	        	        			}
        	        	        			if(combo.getValue()==2)
        	        	        			{
        	        	        				valueTypeStoreEa.clearFilter();
        	        	        				valueTypeStoreEa.filter('varFlag','Y');
        	        	        				this.up('window').down('form').getForm().findField("function").allowBlank=true;
        	        	        				parameterStoreEa.clearFilter();
        	        	        				if(compId==null)
        	        	        					compId=Ext.getCmp('eaCompList').getValue();
        	        	        				var payTo = componentListStore.findRecord('compId',compId);
        	        	        				payTo = payTo.data.payTo;
        	        	        				parameterStoreEa.filter(function(r) {
        	        	        					var value = r.get('paramId');
        	        	        					var value2 = r.get('valFlag');
        	        	        					return ((value >= payTo && value2=='E') || value2=='V');
        	        	        				});

        	        	        				dataSourceStoreEa.clearFilter();
        	        	        				dataSourceStoreEa.filter('compId',compId);

        	        	        				dataSourceStoreEa.filter('valFlag','V');

        	        	        				functionStoreEa.clearFilter();
        	        	        				functionStoreEa.filter(function(r) {
        	        	        					var value = r.get('functionType');
        	        	        					var value2 = r.get('functionId');
        	        	        					return (value == 'M');
        	        	        				});
        	        	        				oprStoreEa.clearFilter();
        	        	        				oprStoreEa.filter('valFlagvar','Y');

        	        	        				oprStoreEa.filter(function(r) {
        	        	        					var value = r.get('oprType');
        	        	        					return (value == 'A' || value == 'R' || value == 'V');
        	        	        				});
        	        	        				this.up('window').down('form').getForm().findField("dataSourceName").enable();
        	        	        				this.up('window').down('form').getForm().findField("startDate").disable();
        	        	        				this.up('window').down('form').getForm().findField("endDate").disable();
        	        	        			}

        	        	        			if(combo.getValue()==3)
        	        	        			{
        	        	        				additionalFlag = true;
        	        	        				dataSourceStoreEa.clearFilter();
        	        	        				dataSourceStoreEa.filter('valFlag','A');
        	        	        				this.up('window').down('form').getForm().findField("function").disable();
        	        	        				this.up('window').down('form').getForm().findField("opr").disable();
        	        	        				this.up('window').down('form').getForm().findField("valueType").disable();
        	        	        				this.up('window').down('form').getForm().findField("value").disable();
        	        	        				this.up('window').down('form').getForm().findField("ValueListName").disable();
        	        	        				this.up('window').down('form').getForm().findField("startDate").enable();
        	        	        				this.up('window').down('form').getForm().findField("endDate").enable();
        	        	        				this.up('window').down('form').getForm().findField("startDate").allowBlank = false;
        	        	        				this.up('window').down('form').getForm().findField("endDate").allowBlank = false;
        	        	        			}
        	        	        		}
        	        	        	},
        	        	        	triggerAction:'all'
        	        	        },
        	        	        {
        	        	        	xtype :'combo',
        	        	        	fieldLabel: 'Entity',
        	        	        	id:'entityVal',
        	        	        	allowBlank:false,
        	        	        	editable: false,
        	        	        	name:'entityType',
        	        	        	displayField:'entityName',
        	        	        	valueField:'entityId',
        	        	        	store: entityStoreEa,
        	        	        	multiSelect : true,
        	        	        	listeners: {
        	        	        		'select': function(combo, value){
        	        	        			entityAttrStoreEa.clearFilter();
        	        	        			this.up('window').down('form').getForm().findField("dataSourceName").reset();
        	        	        			entityTypeEa  = combo.getValue();
        	        	        			maxVal=Math.max.apply( Math, entityTypeEa);//checkMaxEntityVal(entityTypeEa);
        	        	        		}
        	        	        	},
        	        	        	triggerAction:'all'
        	        	        },
        	        	        {
        	        	        	xtype :'combo',
        	        	        	allowBlank:false,
        	        	        	editable: false,
        	        	        	fieldLabel: 'Data Source',
        	        	        	name:'dataSourceName',
        	        	        	displayField:'dataSourceName',
        	        	        	valueField:'dataSourceName',
        	        	        	store: dataSourceStoreEa,
        	        	        	listeners: {
        	        	        		'select': function(combo, value){
        	        	        			this.up('window').down('form').getForm().findField("parameter").reset();
        	        	        			this.up('window').down('form').getForm().findField("parameter").enable();
        	        	        			var temp = dataSourceStoreEa.findRecord('dataSourceName',combo.getValue());
        	        	        			//alert("test:: "+temp.data.dataSourceId+" comb:: "+combo.getValue());
        	        	        			if(temp.data.valFlag=='V')
        	        	        			{
        	        	        				var test = eaStore.findRecord('variableId',temp.data.dataSourceId);//dataSourceId
        	        	        				
        	        	        				this.up('window').down('form').getForm().findField("parameter").reset();
        	        	        				this.up('window').down('form').getForm().findField("parameter").setValue(parameterStoreEa.findRecord('paramName',temp.data.dataSourceName,0, false, true, true));
        	        	        			
        	        	        				var tqDataSet2 = tqStore.findRecord('condName',test.data.dataSourceName);
        	        	        				//alert("id:: "+tqDataSet2.data.dataSet);
        	        	        				if(tqDataSet2.data.dataSet){
        	        	        					
        	        	        					this.up('window').down('form').getForm().findField("daylvlAggrId").reset();
        	        	        					this.up('window').down('form').getForm().findField("daylvlAggrId").enable();
        	        	        					//dayLvlAggrStoreEa.clearFilter();
        	        	        					//dayLvlAggrStoreEa.filter('universeId',tqDataSet2.data.dataSet);
        	        	        					this.up('window').down('form').getForm().findField('daylvlAggrId').setValue(dayLvlAggrStoreEa.findRecord('dayLvlAggrDisplayName',test.data.daylvlAggr));
        	        	        					//alert("daylvlAggrID:: "+test.data.daylvlAggrId+" dlna::"+test.data.daylvlAggr);
            	        	        				
        	        	        				}
        	        	        				
        	        	        			}
        	        	        			if(temp.data.valFlag=='C')
        	        	        			{
        	        	        				this.up('window').down('form').getForm().findField("parameter").reset();
        	        	        				this.up('window').down('form').getForm().findField("parameter").readOnly = false;
        	        	        				var tqDataSet = tqStore.findRecord('condName',temp.data.dataSourceName);
        	        	        				//alert("id:: "+tqDataSet.data.dataSet);
        	        	        				if(tqDataSet.data.dataSet){
        	        	        					parameterStoreEa.filter('unverseId',tqDataSet.data.dataSet);
        	        	        					
        	        	        					this.up('window').down('form').getForm().findField("daylvlAggrId").reset();
        	        	        					dayLvlAggrStoreEa.clearFilter();
        	        	        					dayLvlAggrStoreEa.filter('universeId',tqDataSet.data.dataSet);
        	        	        					
        	        	        				}
        	        	        			}
        	        	        			if(temp.data.valFlag=='A')
        	        	        			{
        	        	        				var attCatg = null;
        	        	        				if(temp.data.dataSourceName=='Additional')
        	        	        				{	
        	        	        					attCatg = 8;
        	        	        					this.up('window').down('form').getForm().findField("startDate").allowBlank = false;
        	        	        					this.up('window').down('form').getForm().findField("endDate").allowBlank = false;
        	        	        				}
        	        	        				else
        	        	        				{
        	        	        					attCatg = 7;
        	        	        					this.up('window').down('form').getForm().findField("startDate").allowBlank = false;
        	        	        					this.up('window').down('form').getForm().findField("endDate").allowBlank =  false;
        	        	        				}
        	        	        				parameterStoreEa.clearFilter();
        	        	        				parameterStoreEa.filter('valFlag','AC');
        	        	        				parameterStoreEa.filter(function(r) {
        	        	        					var value = r.get('attrCatg');
        	        	        					var value2 = r.get('attrType');
        	        	        					return (value == attCatg && value2 == maxVal);
        	        	        				});
        	        	        			}
        	        	        			
        	        	        			
        	        	        			
        	        	        		}
        	        	        	},
        	        	        	triggerAction:'all'   //
        	        	        },
        	        	        {
        	        	        	xtype :'combo',
        	        	        	editable: false,
        	        	        	fieldLabel: 'Function',
        	        	        	name:'function',
        	        	        	displayField:'functionName',
        	        	        	valueField:'functionId',
        	        	        	store: functionStoreEa,
        	        	        	listeners: {
        	        	        		'select': function(combo, value){
        	        	        			if(combo.getValue()==1)
        	        	        			{
        	        	        				oprStoreEa.clearFilter();
        	        	        				oprStoreEa.filter('oprType','R');
        	        	        			}
        	        	        			else
        	        	        			{
        	        	        				// this.up('window').down('form').getForm().findField("entityParameter").disable();
        	        	        			}
        	        	        		}
        	        	        	},
        	        	        	triggerAction:'all'
        	        	        },
        	        	        {
        	        	        	xtype :'combo',
        	        	        	fieldLabel: 'Parameter',
        	        	        	editable: false,
        	        	        	name:'parameter',
        	        	        	disabled : true,
        	        	        	displayField:'paramName',
        	        	        	valueField:'paramName',
        	        	        	store: parameterStoreEa,
        	        	        	triggerAction:'all'
        	        	        	/*queryMode: 'local',
										forceSelection: true,
										triggerAction: 'all',
										enableKeyEvents: true,
										selectOnFocus:true,
										typeAhead: true,
										disableKeyFilter: true */
        	        	        }
        	        	        ]
 },

 {
	 xtype: 'container',
	 columnWidth:.3,
	 layout: 'anchor',
	 items: [
	         {
	        	 xtype :'combo',
	        	 fieldLabel: 'OPR',
	        	 editable: false,
	        	 name:'opr',
	        	 displayField:'oprName',
	        	 valueField:'oprId',
	        	 store: oprStoreEa,
	        	/* queryMode: 'local',
					forceSelection: true,
					triggerAction: 'all',
					enableKeyEvents: true,
					selectOnFocus:true,
					typeAhead: true,
					disableKeyFilter: true, */
	        	 listeners: {
	        		 'select': function(combo, value){
	        			 this.up('window').down('form').getForm().findField("startDate").enable();
	        			 this.up('window').down('form').getForm().findField("endDate").enable();
	        			 if(combo.getValue()==14)
	        			 {
	        				 this.up('window').down('form').getForm().findField("valueType").disable();
	        				 this.up('window').down('form').getForm().findField("value").disable();
	        				 this.up('window').down('form').getForm().findField("ValueListName").disable();
	        				 this.up('window').down('form').getForm().findField("startDate").allowBlank=false;
	        				 this.up('window').down('form').getForm().findField("endDate").allowBlank=false;
	        			 }
	        			 else
	        			 {
	        				 this.up('window').down('form').getForm().findField("valueType").enable();
	        				 this.up('window').down('form').getForm().findField("value").enable();
	        				 this.up('window').down('form').getForm().findField("ValueListName").enable();
	        				 this.up('window').down('form').getForm().findField("startDate").allowBlank=true;
	        				 this.up('window').down('form').getForm().findField("endDate").allowBlank=true;
	        			 }
	        		 }
	        	 },
	        	 triggerAction:'all',
	         },
	         {
	        	 xtype :'combo',
	        	 id:'valueType',
	        	 fieldLabel: 'Value Type',
	        	 editable: false,
	        	 name:'valueType',
	        	 displayField:'valueTypeName',
	        	 valueField:'valueTypeName',
	        	 store: valueTypeStoreEa,
	        	 listeners: {
	        		 'select': function(combo, value){
	        			 if(combo.getValue()==5)
	        			 {
	        				 this.up('window').down('form').getForm().findField("startDate").allowBlank=false;
	        				 this.up('window').down('form').getForm().findField("endDate").allowBlank=false;
	        			 }
	        			 if(combo.getValue()=='Free Text')
	        			 {
	        				 this.up('window').down('form').getForm().findField("value").enable();
	        				 this.up('window').down('form').getForm().findField("ValueListName").disable();
	        			 }
	        			 else if(combo.getValue()=='Variable')
	        			 {
	        				 this.up('window').down('form').getForm().findField("value").disable();
	        				 this.up('window').down('form').getForm().findField("ValueListName").enable();
	        				 this.up('window').down('form').getForm().findField("ValueListName").reset();
	        				 
	        				 entityAttrStoreEa.clearFilter();
	        				 entityAttrStoreEa.filter(function(r) {
	        					 var value = r.get('varFlag');
	        					 var value2 = r.get('compId');
	        					 //return (value2 == compId);
	        					 return (value == 'Y' && value2 == compId);
	        				 });
	        			 }
	        			 else 
	        			 {
	        				 this.up('window').down('form').getForm().findField("value").disable();
	        				 this.up('window').down('form').getForm().findField("ValueListName").enable();
	        				 this.up('window').down('form').getForm().findField("ValueListName").reset();

	        				 entityAttrStoreEa.clearFilter();
	        				 var valueTypeId =  valueTypeStoreEa.findRecord('valueTypeName',combo.getValue());
	        				 if(maxVal==null)
        					 {
	        				 var tempArrayEntities=Ext.getCmp('entityVal').getValue().toString();
	        				 var tempVarArray=tempArrayEntities.split(",");
	        				 var tempEntityIds="";
	        				 for(var i=0;i<tempVarArray.length;i++)
	        					 {
	        					 var tempId =  entityStoreEa.findRecord('entityName',tempVarArray[i]);
	        					    if(i!=tempVarArray.length-1)
	        					    	tempEntityIds+=tempId.get('entityId')+",";
	        					    else
	        					    	tempEntityIds+=tempId.get('entityId');
	        					 }
	        				// alert(tempEntityIds);
	        				 maxVal=Math.max.apply( Math, tempEntityIds);
        					 }
	        				 entityAttrStoreEa.filter(function(r) {
	        					 var value = r.get('attrCatg');
	        					 var value2 = r.get('attrType');
	        					 return (value == valueTypeId.data.valueTypeId && value2 == maxVal && value2);
	        				 });
	        				 this.up('window').down('form').getForm().findField("startDate").enable();
	        				 this.up('window').down('form').getForm().findField("endDate").enable();									
	        			 }
	        		 }
	        	 },
	        	 triggerAction:'all'
	         },
	         {
	        	 xtype :'textfield',
	        	 disabled : true,
	        	 fieldLabel: 'Value',
	        	 name:'value',
	        	 enforceMaxLength  : true,
	        	 maxLength:100,
	        	 //maskRe:/[A-Za-z0-9_, ]/,
	        	 listeners:{
	        		 'change': function(field, newValue, oldValue){
	        			 field.setValue(newValue.toUpperCase());
	        		 }
	        	 }
	         },
	         {
	        	 xtype :'combo',
	        	 editable: false,
	        	 fieldLabel: 'Value*',
	        	 name:'ValueListName',
	        	 displayField:'entityAttributeName',
	        	 valueField:'entityAttributeName',
	        	 store: entityAttrStoreEa,
	        /*	 queryMode: 'local',
					forceSelection: true,
					triggerAction: 'all',
					enableKeyEvents: true,
					selectOnFocus:true,
					typeAhead: true,
					disableKeyFilter: true, */
	        	 listeners:
                 {
	    	         afterrender: function (me) { 
	                     me.getEl().on('click', function() {
	                    	
	                    	if(Ext.getCmp('valueType').getValue()=='Variable')
	                    		{
	                    		entityAttrStoreEa.clearFilter();
		        				 entityAttrStoreEa.filter('compId',compId,0, false, true, true);
	                    		}
		        			
	                     });
          		},
	        	 triggerAction:'all',
               }
	         },
	         {
	        	 xtype :'datefield',
	        	 fieldLabel: 'Start Date',
	        	 editable: false,
	        	 name:'startDate'
	         },
	         {
	        	 xtype :'datefield',
	        	 fieldLabel: 'End Date',
	        	 editable: false,
	        	 name:'endDate'
	         },
	         {
	        	 xtype :'combo',
	        	 editable: false,
	        	 fieldLabel: 'Day Lvl Aggr',
	        	 name:'daylvlAggrId',
	        	 displayField:'dayLvlAggrDisplayName',
	        	 valueField:'dayLvlAggrId',
	        	 hidden:true,
	        	 store: dayLvlAggrStoreEa,
	        	 triggerAction:'all'
	         },
	         {
 		    	   xtype :'textfield',
 		    	   fieldLabel: 'CsrfName',
				   hidden:true,
 		    	   disabled : true,
 		    	   name: 'csrfEa',
				   maxLength : 100,
 		    	   allowBlank:false,
 		    	   id:'testCsrfEa'
 		    }
	
	]
 }
        	        ]
         }

			         ]
		}],
		buttons: [	
		          {
		        	  text: 'Save',
		        	  action: 'add'

		          },

		          /*	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},*/
		          {
		        	  text   : 'Cancel',
		        	  handler: function () { 
		        		  this.up('window').close();
		        	  }
		          }]
	});

	Ext.define('Scheme.controller.EaCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['EaList', 'EaForm'],
		refs    : [{
			ref   : 'formWindow',
			xtype : 'EaForm',
			selector: 'EaForm',
			autoCreate: true
		}],
		init: function () {
			this.control({
				'EaList > toolbar > button[action=add]': {
					click: this.showAddForm
				},
				'EaList': {
					itemdblclick: this.onRowdblclick
				},
				'EaForm button[action=add]': {
					click: this.doAddEa
				}
			});
		},
		onRowdblclick: function(me, record, item, index) {
			payToStore.load();
			console.log(record.data);
			var win = this.getFormWindow();
			win.down('form').getForm().reset();

			tqStore.load();
			var  filterFlag = null;
			win.down('form').getForm().applyToFields({disabled:true});

			compIdEa = record.data.compId;
			condIdEa = record.data.variableId;
			minDateEnd =record.data.endDate;
			minDateStart = record.data.startDate;
			//entityTypeEa = record.data.entityTypeId;
			entityTypeEa = Math.max.apply( Math, [record.data.entityTypeId]);
			// win.down('form').getForm().findField('endDate').minValue = new Date(record.data.endDate);
			//    win.down('form').getForm().findField('startDate').minValue = new Date(record.data.startDate);





			//0
			componentListStore.load({
				callback: function(records, operation, success) {
					if (success == true) {
						if(record.data.compId!=null)
						{
							win.down('form').getForm().findField('compId').enable();
							win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compId',record.data.compId));
							win.down('form').getForm().findField('compId').readOnly = true;
						}

						//1
						win.down('form').getForm().findField('variableName').enable();
						win.down('form').getForm().findField('variableName').editable = false;


						//2
						if(record.data.startDate!=null)
							win.down('form').getForm().findField('startDate').enable();


						//3
						if(record.data.endDate!=null)
							win.down('form').getForm().findField('endDate').enable();


						//4
						dataSetStoreEa.load({
							callback: function(records, operation, success) {
								if (success == true) {
									if(record.data.dataSetName!=null)
									{
										win.down('form').getForm().findField('dataSet').enable();
										win.down('form').getForm().findField('dataSet').setValue(dataSetStoreEa.findRecord('dataSetName',record.data.dataSetName));
									}


									//x
									entityStoreEa.load({
										callback: function(records, operation, success) {
											if (success == true) {
												if(record.data.entityTypeName!=null)
												{
													win.down('form').getForm().findField('entityType').enable();
													//win.down('form').getForm().findField('entityType').setValue(entityStoreEa.findRecord('entityName',record.data.entityTypeName));
													win.down('form').getForm().findField('entityType').setValue([record.data.entityTypeName]);
													//Ext.getCmp('entityType').setValue(record.data.entityTypeName);
													//entityTypeEa = entityStoreEa.findRecord('entityName',record.data.entityTypeName);
													//entityTypeEa = entityTypeEa.data.entityId;
													var obj=componentListStore.findRecord('compId',compIdEa);
		        	        /*	        			var payToId=obj.data.payTo;
		        	        	        			entityStoreEa.clearFilter();
		        	        	        			entityStoreEa.filter(function(r) {
		        	        	        				var value = r.get('entityId');
		        	        	        				return (value >= payToId);
		        	        	        			});
*/
												}



												//5   Load Data Source
												dataSourceStoreEa.load({
													callback: function(records, operation, success) {
														if (success == true) {
															//alert('data source val'+dataSourceStoreEa.findRecord('dataSourceName',record.data.dataSourceName));
															if(record.data.dataSourceName!=null)
															{
																win.down('form').getForm().findField('dataSourceName').readOnly = false;
																win.down('form').getForm().findField('dataSourceName').enable();
																win.down('form').getForm().findField('dataSourceName').setValue(dataSourceStoreEa.findRecord('dataSourceName',record.data.dataSourceName));
															}



															//6
															parameterStoreEa.load({
																callback: function(records, operation, success) {
																	if (success == true) {
																		if(record.data.parameter!=null)
																		{
																			win.down('form').getForm().findField('parameter').enable();
																			win.down('form').getForm().findField('parameter').setValue(parameterStoreEa.findRecord('paramName',record.data.parameter));
																		}

																		//7
																		functionStoreEa.load({
																			callback: function(records, operation, success) {
																				if (success == true) {
																					if(record.data.functionName!=null)
																					{
																						win.down('form').getForm().findField('function').enable();
																						win.down('form').getForm().findField('function').setValue(functionStoreEa.findRecord('functionName',record.data.functionName));
																					}

																					//8  OPr Load
																					oprStoreEa.load({
																						callback: function(records, operation, success) {
																							if (success == true) {
																								if(record.data.oprName!=null)
																								{
																									win.down('form').getForm().findField('opr').enable();
																									win.down('form').getForm().findField('opr').setValue(oprStoreEa.findRecord('oprName',record.data.oprName));
																								}

																								//9
																								valueTypeStoreEa.load({
																									callback: function(records, operation, success) {
																										if (success == true) {
																											if(record.data.valueType!=null)
																											{
																												win.down('form').getForm().findField('valueType').enable();
																												win.down('form').getForm().findField('valueType').setValue(valueTypeStoreEa.findRecord('valueTypeName',record.data.valueType));
																												if(record.data.valueType=='Free Text')
																												{
																													win.down('form').getForm().findField('value').enable();
																												}
																												else
																												{
																													entityAttrStoreEa.load({
																													callback: function(records, operation, success) {
																															if (success == true) {
																																if(record.data.value!=null)
																																{
																																	win.down('form').getForm().findField('ValueListName').enable();
																																	win.down('form').getForm().findField('ValueListName').setValue(entityAttrStoreEa.findRecord('entityAttributeName',record.data.value));
																																}
																															}
																														}
																													});
																												}
																											}
																											if(filterFlag==null)
																											{
																												var dataSetId = dataSetStoreEa.findRecord('dataSetName',record.data.dataSetName);
																												if(record.data.daylvlAggr!=null){
																													dayLvlAggrStoreEa.load({
																														callback: function(records, operation, success) {
																																if (success == true) {
																																	if(record.data.value!=null)
																																	{
																																		win.down('form').getForm().findField('daylvlAggrId').enable();
																																		win.down('form').getForm().findField('daylvlAggrId').setValue(dayLvlAggrStoreEa.findRecord('dayLvlAggrDisplayName',record.data.daylvlAggr));	
																																	}
																																}
																															}
																														});
																														
																												}else{
																													win.down('form').getForm().findField('daylvlAggrId').disable();	
																												}
																												
																												if(dataSetId!=null)
																												{
																													if(dataSetId.data.dataSetId==1)
																													{
																														//	alert('Condition');
																														dataSourceStoreEa.clearFilter();
																														dataSourceStoreEa.filter('valFlag','C');
																														dataSourceStoreEa.filter('compId',record.data.compId);

																														parameterStoreEa.clearFilter();
																														parameterStoreEa.filter('valFlag','C');
																														var tqDataSet = tqStore.findRecord('condName',record.data.dataSourceName);
																														parameterStoreEa.filter('unverseId',tqDataSet.data.dataSet);
																														
																														if(record.data.daylvlAggr!=null){
																															win.down('form').getForm().findField('daylvlAggrId').enable();
																															dayLvlAggrStoreEa.filter('universeId',tqDataSet.data.dataSet);
																														//	win.down('form').getForm().findField('daylvlAggrId').setValue(dayLvlAggrStoreEa.findRecord('dayLvlAggrDisplayName',record.data.daylvlAggr));
																														}
																															
																														
																														functionStoreEa.clearFilter();
																														functionStoreEa.filter('functionType','A');

																														oprStoreEa.clearFilter();
																														oprStoreEa.filter('valFlagcon','Y');

																														oprStoreEa.filter(function(r) {
																															var value = r.get('oprType');
																															return (value == 'R');
																														});


																														valueTypeStoreEa.clearFilter();
																														valueTypeStoreEa.filter('valueTypeId',1);
																													}
																													if(dataSetId.data.dataSetId==2)
																													{
																														//	alert('variable');
																														dataSourceStoreEa.clearFilter();
																														dataSourceStoreEa.filter('valFlag','V');							
																														dataSourceStoreEa.filter('compId',record.data.compId);
																														parameterStoreEa.clearFilter();
																														//parameterStoreEa.filter('valFlag','V');

																														var payTo = componentListStore.findRecord('compId',record.data.compId);
																														payTo = payTo.data.payTo;

																														parameterStoreEa.filter(function(r) {
																															//alert(payTo);	
																															var value = r.get('paramId');
																															var value2 = r.get('valFlag');
																															return ((value >= payTo && value2=='E') || value2=='V');
																														});


																														functionStoreEa.clearFilter();
																														functionStoreEa.filter(function(r) {
																															var value = r.get('functionType');
																															var value2 = r.get('functionId');
																															return (value == 'M');
																														});

																														oprStoreEa.clearFilter();
																														oprStoreEa.filter('valFlagvar','Y');

																														oprStoreEa.filter(function(r) {
																															var value = r.get('oprType');
																															//var value2 = r.get('valFlagvar');
																															return (value == 'A' || value == 'R' || value == 'V');
																														});


																														valueTypeStoreEa.clearFilter();
																														valueTypeStoreEa.filter('varFlag','Y');
																														
																														if(record.data.daylvlAggr!=null){
																															win.down('form').getForm().findField('daylvlAggrId').enable();
																														//	dayLvlAggrStoreEa.filter('universeId',tqDataSet.data.dataSet);
																														//	win.down('form').getForm().findField('daylvlAggrId').setValue(dayLvlAggrStoreEa.findRecord('dayLvlAggrDisplayName',record.data.daylvlAggr));
																														}
																													}

																													if(dataSetId.data.dataSetId==3)
																													{
																														dataSourceStoreEa.clearFilter();
																														dataSourceStoreEa.filter('valFlag','A');

																														parameterStoreEa.clearFilter();
																														parameterStoreEa.filter('valFlag','AC');

																														var attCatg = null;
																														if(record.data.dataSourceName=='Additional')
																														{	
																															attCatg = 8;
																															win.down('form').getForm().findField("startDate").enable();
																															win.down('form').getForm().findField("endDate").enable();

																															win.down('form').getForm().findField("startDate").allowBlank = false;
																															win.down('form').getForm().findField("endDate").allowBlank = false;
																														}
																														else
																														{
																															attCatg = 7;
																															win.down('form').getForm().findField("startDate").enable();
																															win.down('form').getForm().findField("endDate").enable();

																															win.down('form').getForm().findField("startDate").allowBlank = false;
																															win.down('form').getForm().findField("endDate").allowBlank = false;

																															//  win.down('form').getForm().findField("startDate").disable();
																															//	win.down('form').getForm().findField("endDate").disable();

																															// win.down('form').getForm().findField("startDate").allowBlank = true;
																															//win.down('form').getForm().findField("endDate").allowBlank = true;
																														}
																														if(isNaN(entityTypeEa)){
																															//alert("Test");
																														}	else{
																															//alert("else Test");
																															parameterStoreEa.filter(function(r) {
																																var value = r.get('attrCatg');
																																var value2 = r.get('attrType');
																																return (value == attCatg && value2 == entityTypeEa);
																															});
																														}
																														
																													}

																													functionId = functionStoreEa.findRecord('functionName',record.data.functionName);
																													if(functionId)
																													{
																														functionId =functionId.data.functionId;
																														if(functionId==1)
																														{
																															oprStoreEa.clearFilter();
																															oprStoreEa.filter('oprType','R');
																														}
																													}
																												}
																												win.down('form').getForm().findField('dataSourceName').setValue(dataSourceStoreEa.findRecord('dataSourceName',record.data.dataSourceName));		
																												win.down('form').getForm().findField('function').setValue(functionStoreEa.findRecord('functionName',record.data.functionName));
																												win.down('form').getForm().findField('parameter').setValue(parameterStoreEa.findRecord('paramName',record.data.parameter));
																												win.down('form').getForm().findField('opr').setValue(oprStoreEa.findRecord('oprName',record.data.oprName));
																												win.down('form').getForm().findField('valueType').setValue(valueTypeStoreEa.findRecord('valueTypeName',record.data.valueType));
																												filterFlag = 'Yes';
																											}
																										}
																									}
																								});
																							}
																						}
																					});
																				}
																			}
																		});	
																	}
																}
															});
														}
													}
												});
											}
										}
									});
								}
							}
						});
					}
				}
			});//0

			win.setTitle('Edit EA');
			win.setAction('edit');
			// win.setRecordIndex(record.data.schemeINputId);
			win.down('form').getForm().setValues(record.getData());
			win.show();
		},
		showAddForm: function () {

			//payToStore.load();
			dataSourceStoreEa.load();
			eaVariableStore.load();
			parameterStoreEa.load();
			tqStore.load();



			if(compName!=null)
			{
				var win = this.getFormWindow();
				win.setTitle(SchemeName);
				win.setAction('add');
				win.down('form').getForm().applyToFields({disabled:false});      
				win.down('form').getForm().reset();
				win.down('form').getForm().findField('compId').readOnly = false;
				win.down('form').getForm().findField('variableName').readOnly = false;
				win.show();
				// Ext.getCmp('eaCompList').setValue(componentListStore.findRecord('compId',componentListStore.data.items[0].data.compId));
				//compId = componentListStore.data.items[0].data.compId;


			}
			else{
				Ext.Msg.alert('Info', "Please create componenet for scheme first");	
			}	

		},
		doAddEa: function () {
			var win = this.getFormWindow();
			var action = win.getAction();
			Ext.getCmp("testCsrfEa").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
			if(action == 'edit') {
				if(win.down('form').isValid())
				{
					updateEa(win);
				}
				else
				{
					Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
				}  
			}
			else {
				if(win.down('form').isValid())
				{
					saveEa(win);
				}
				else
				{
					Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
				}

			}

		}
	});



});
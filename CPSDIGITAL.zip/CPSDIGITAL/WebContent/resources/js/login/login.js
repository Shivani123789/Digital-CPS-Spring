function loginUser(schemeForm)
{

	if(schemeForm.getForm().isValid())
	{
	schemeForm.getForm().submit({
		 waitMsg : 'Loading...',
		 url : 'j_spring_security_check',
		 //url : 'j_security_check',
		 
		 method : 'POST',
        
		 success: function(form, action) {
           // Ext.Msg.alert(action.result.errorMessage+' Scheme Created Sucessfully');
           // SchemeName = action.result.errorMessage;
            //form.reset();
           // componentStoreGrid.load();
           // regZoneStore.load();
        },
        failure: function(form, action) {
        	if(action.result != null)
        		Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	
        }
    });
	
	}
	
	else
		{
			Ext.Msg.alert('Warning', "Please Fill All Mandatory Fields");
		}
}


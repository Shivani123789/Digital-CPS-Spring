Ext.onReady(function () {

	function CreatesubmitSchemeFilterStore() {
	    var store = new Ext.data.SimpleStore({
	        fields: ['id', 'name'],
	        data: [['1', 'Unsubmitted'], ['2', 'Failed']]
	    });
	    return store;
	}
	//Search Grid
	
	submitSchemeloadsd = null;
	submitSchemeloaded = null;
	submitSchemeloadcond = null;
	var subPayToId = null;
	//var subScmName = null;
	//var subScmId = null;
	//var apprCompName = null;
	
	var submitschemeSearch = new Ext.Panel({     
        stripeRows  : true,
        frame       : false,
        border: false,
        style       : 'padding-bottom: 5px',
        layout:'column',
        anchor: '100%',
        items       : [{
                        xtype       : 'datefield',
                        id          : 'startDateSubmit',
                        allowBlank  : true,
                        emptyText   : 'From',
                        name        : 'startDate',
                        //width       : 140,
                        editable    : false,
                        itemId		:'startDateSubmitsub',
                        vtype		:'daterange',
                        endDateField: 'endDateSubmitsub',
						value : new Date(date.getFullYear(), date.getMonth(), 1)
                      },{
                        xtype       : 'datefield',
                        id          : 'endDateSubmit',
                        allowBlank  : true,
                        emptyText   : 'To',
                        name        : 'endDate',
                        itemId		:'endDateSubmitsub',
                        editable    : false,
                        vtype		:'daterange',
                        startDateField:'startDateSubmitsub',
						value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
                      },
                      {
                    	  xtype       : 'combo',
                    	  displayField:'name',
                    	  valueField:'id',
                    	  allowBlank  : true,
                    	  emptyText   : 'Scheme State',
                    	  name        : 'filterBy',
                    	  //width       : 140,
                    	  editable    : false,
                    	  store: CreatesubmitSchemeFilterStore(),
                    	  listeners: {
                    		  'select': function(combo, value){
                    			  submitSchemeloadcond = combo.getValue();
                    			  if(combo.getValue()==2)
                    			  {

                    				  submitSchemeloadcond = 'F';
                    			  }
                    			  else{
                    				  submitSchemeloadcond = 'W';
                    			  }
                    		  }

                    	  },
                    	  triggerAction:'all'
                      },
                      {
                  		xtype       : 'textfield',
                  		id          : 'schemeNameSub',
                  		allowBlank  : true,
                  		emptyText   : 'Scheme Name',
                  		//maskRe:/[A-Za-z0-9_- ]/,
                  		name        : 'schemeComp',
                  		//width       : 140,
                  		editable    : true,
                  		// format      : 'dd-MMM-yyyy'
                  	},
                  	{
                  		xtype       : 'numberfield',
                  		id          : 'schemeNameIdSub',
                  		allowBlank  : true,
                  		emptyText   : 'Scheme ID',
                  		name        : 'schemeId',
                  		allowNegative: false,
                  		//width       : 140,
                  		editable    : true,
                  		// format      : 'dd-MMM-yyyy'
                  	},
                  	{
                 		xtype       : 'textfield',
                 		id          : 'compNameSub',
                 		allowBlank  : true,
                 		emptyText   : 'Component Name',
                 		name        : 'componentName',
                 		//maskRe:/[A-Za-z0-9_- ]/,
                 		//width       : 140,
                 		editable    : true,
                 		// format      : 'dd-MMM-yyyy'
                 	},
                  	{
                  		xtype: 'combo',
                  		store:payToStore,
                  		emptyText   : 'Pay To',
                  		//fieldLabel: 'Table Field',
                  		displayField:'displayValue',
                  		editable: false,
                  		valueField:'entityTypeId',
                  		name: 'payTo',
                  		listeners: {
                  			'select': function(combo, value){
                  				subPayToId = combo.getValue();
                  			}
                  		}
                  	},
                  	{
        		    	   xtype :'textfield',
        		    	   fieldLabel: 'CsrfName',
						   hidden:true,
        		    	   disabled : true,
        		    	   name: 'csrfSubmit',
						   maxLength : 100,
        		    	   allowBlank:false,
        		    	   id:'testCsrfSubmit'
        		    },
                  	{
                  		xtype       : 'button',
                  		text        : 'Go',
                  		//width       : 40,
                  		handler     : function () {
                  			Ext.getCmp("testCsrfSubmit").setValue(document.cookie);
                  			var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateSubmit").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateSubmit").getValue(),'Y/m/d'));
                  			if(submitSchemeloadcond==null){
                  				//Ext.Msg.alert("Warning","<font color='red'>Please Ensure That To Select Aleast One Status (Ex. Unsubmitted or Failure).</font>");
                  				Ext.Msg.alert("Warning","<font color='blue'>Please enter 'From Date' , 'To Date' & 'Scheme State'.</font>");
                  				return false;
                  			}
                  			if(flag && submitSchemeloadcond!=null){
                  				submitSchemeloadsd =  Ext.Date.format(Ext.getCmp("startDateSubmit").getValue(),'d-M-Y');
                  				submitSchemeloaded = Ext.Date.format(Ext.getCmp("endDateSubmit").getValue(),'d-M-Y');
                  				var subScmName = Ext.getCmp("schemeNameSub").getValue()!='' ? Ext.getCmp("schemeNameSub").getValue() : 'ABCDEF';
                  				var subScmId = Ext.getCmp("schemeNameIdSub").getValue()!=null ? Ext.getCmp("schemeNameIdSub").getValue() : '-1';
                  				subPayToId = subPayToId != null ? subPayToId : '-1';
                  				var apprCompName = Ext.getCmp("compNameSub").getValue()!='' ? Ext.getCmp("compNameSub").getValue() : 'ABCDEF';
                  	  			
                  				submitschemeGrid.load({params:
                  				{
                  					startDate:submitSchemeloadsd ,
                  					endDate: submitSchemeloaded,
                  					schemeComp : subScmName,
                  					schemeId : subScmId,
                  					componentName : apprCompName,
                  					payTo : subPayToId,
                  					filterBy:1,
                  					isMaster:false,
                  					isStage:true,
                  					condParam:submitSchemeloadcond,
                  					page:1,
            						start :	0
                  				}});


                  			}
                  		},

                  	}
                ]
    });
	
	
	
	
	
	
	
	
	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	         ]);
	
   Ext.define('Scheme.model.Book', {
    extend: 'Ext.data.Model',
    fields: [
      {name: 'schemeName', type: 'string'},
      {name: 'circleName',  type: 'string'}
   
    ]
  });
 
   
      
   
   
   
   
   
  Ext.define('Scheme.store.Books', {
    extend  : 'Ext.data.Store',
    model   : 'Scheme.model.Book',
    fields  : ['title', 'author','price', 'qty'],
    data    : [
      { title: 'JDBC, Servlet and JSP', 
        author: 'Santosh Kumar', price: 300, qty : 12000 },
      { title: 'Head First Java', 
        author: 'Kathy Sierra', price: 550, qty : 2500 },
      { title: 'Java SCJP Certification', 
        author: 'Khalid Mughal', price: 650, qty : 5500 },
      { title: 'Spring and Hinernate', 
        author: 'Santosh Kumar', price: 350, qty : 2500 },
      { title: 'Mastering C++', 
        author: 'K. R. Venugopal', price: 400, qty : 1200 }
    ]
  });
 
   Ext.define('Scheme.view.SubmitSchemeList', {
    extend: 'Ext.grid.Panel',
    id:'submitschemeGrid',
    stripeRows: true,
	pageSize : 1000,
    flex: 2,
   // border:false,
    hidden: false,
  //  height:600,
	//	width:1120,
	layout: 'fit',
	height: '100%',
    
   // bodyStyle:'padding:0px',
    loadMask: true,
    //selModel : Ext.create('Ext.selection.CheckboxModel'),
    //loadMask: true,
    plugins: 'bufferedrenderer',
//	bodyStyle:'padding:3px 0px',
    //remoteSort:true, 
	remoteFilter :true, 
	//remoteGroup :true, 
    //pageSize : 5,
    alias: 'widget.SubmitSchemeList',
    title: 'Submit Scheme',
    store: submitschemeGrid,
    //height:500,
    autoScroll: true,
    
    initComponent: function () {
    	 var me = this;
      this.tbar = [
					submitschemeSearch
                ];
      this.columns = [
        //{ header: 'Submit?', dataIndex: 'submit',xtype: 'checkcolumn', width: 60 },
        { header: 'Scheme Id', dataIndex: 'schemeINputId', flex: 1 },
        { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
        //compId
		{ header: 'Comp Id', dataIndex: 'compId', flex: 1 },
		{ header: 'Comp Name', dataIndex: 'compName', flex: 1 },
		{ header: 'Create Date', dataIndex: 'insertTime', flex: 1 },
		{ header: 'PayTo', dataIndex: 'payTo', flex: 1 },
		{ header: 'Start Date', dataIndex: 'startDate', flex: 1 },
		{ header: 'End Date', dataIndex: 'endDate', flex: 1 },
		{ header: 'Status', dataIndex: 'schemeStatus', flex: 1 },
        { header: 'Err_Detail', flex: 1,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'resources/images/error.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('SubmitSchemeList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Scheme Selected');
                          return;
                        }
                        
                          		Ext.Ajax.request({
                            			  url : 'searchscheme/showError.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
                            			  method: 'POST',
                            			  params: {
                            				  "schemeINputId" : rs[0].data.schemeINputId,
                            				  "schemeName" :rs[0].data.schemeName,
											  "compId" :rs[0].data.compId
                            			    },
                            			    success: function (response) {
											var jsonResp = Ext.JSON.decode(response.responseText);
											//	console.log(jsonResp); 
													if(jsonResp.success==false)	
													{
													Ext.Msg.alert("Error",jsonResp.errorMessage);
													}
													else
													Ext.Msg.alert("Info",jsonResp.errorMessage);
											  
											  grid.store.load({params:
												{
												startDate:submitSchemeloadsd ,
												endDate: submitSchemeloaded,
												schemeComp : Ext.getCmp("schemeNameSub").getValue()!='' ? Ext.getCmp("schemeNameSub").getValue() : 'ABCDEF',
					                  			schemeId : Ext.getCmp("schemeNameIdSub").getValue()!=null ? Ext.getCmp("schemeNameIdSub").getValue() : '-1',
					                  			componentName : Ext.getCmp("compNameSub").getValue()!='' ? Ext.getCmp("compNameSub").getValue() : 'ABCDEF',
					                  			payTo : subPayToId != null ? subPayToId : '-1',
												filterBy:1,
												isMaster:false,
												isStage:true,
												condParam:submitSchemeloadcond
												}});							
										
                             			        //schemeStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
										  alert("Fail");
										  Ext.Msg.alert("Error","Fail");
										  //console.log(response);
                            			       }
                            			 });

						  
						  
						  
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        },
        
       // { header: 'Validity Flag', dataIndex: 'valFlag', width: 80 },
       // { header: 'Create Date', dataIndex: 'cDate', width: 80 },
        { header: 'Submit', flex: 1,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'resources/images/submit.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('SubmitSchemeList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Scheme Selected');
                          return;
                        }
                        
                          
                        Ext.Msg.confirm('Submit Scheme', 
                          'Are you sure you want to submit Scheme?', 
                          function (button) {
                            if (button == 'yes') {
                            	 Ext.ux.mask.show(); 
                            		Ext.Ajax.request({
                            			  url : 'searchscheme/submitScheme.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
                            			  method: 'POST',
                            			  params: {
                            				  "schemeINputId" : rs[0].data.schemeINputId,
                            				  "schemeName" :rs[0].data.schemeName,
											  "compId" :rs[0].data.compId

                            			    },
                            			    success: function (response) {
                            			    	 Ext.ux.mask.hide();
										//	alert("success");
										//	console.log(response);
											var jsonResp = Ext.JSON.decode(response.responseText);
											//	console.log(jsonResp); 
													if(jsonResp.success==false)	
													{
													Ext.Msg.alert("Error",jsonResp.errorMessage);
													}
													else
													Ext.Msg.alert("Info",jsonResp.errorMessage);
											  
											  grid.store.load({params:
												{
												startDate:submitSchemeloadsd ,
												endDate: submitSchemeloaded,
												schemeComp : Ext.getCmp("schemeNameSub").getValue()!='' ? Ext.getCmp("schemeNameSub").getValue() : 'ABCDEF',
					                  			schemeId : Ext.getCmp("schemeNameIdSub").getValue()!=null ? Ext.getCmp("schemeNameIdSub").getValue() : '-1',
					                  			componentName : Ext.getCmp("compNameSub").getValue()!='' ? Ext.getCmp("compNameSub").getValue() : 'ABCDEF',
					                  			payTo : subPayToId != null ? subPayToId : '-1',
												filterBy:1,
												isMaster:false,
												isStage:true,
												condParam:submitSchemeloadcond
												}});							
										
                             			        //schemeStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            				  Ext.ux.mask.hide();
                            				  Ext.Msg.alert("Error","Fail");
                            				 // alert("Fail");
										  //console.log(response);
                            			       }
                            			 });
                           //   grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : submitschemeGrid,
			dock : 'bottom',
			displayInfo : true
		}
		
      ];
      
      this.callParent(arguments);
    },
    
    afterRender: function() {
        var me = this;
        me.callParent(arguments);
        me.textField = me.down('textfield[name=searchField]');
        me.statusBar = me.down('statusbar[name=searchStatusBar]');
    },
    
    
    onTextFieldChange: function(field, newValue, oldValue, options){
        if(newValue==''){
        	schemeStoreGrid.clearFilter();
        }
        else {
        	schemeStoreGrid.clearFilter(true);
        	if(newValue.length>=4){
        		schemeStoreGrid.filter("schemeName",newValue);
        	}
       	
        //	this.view.refresh();
        //	schemeStoreGrid.load();
        //	schemeStoreGrid.load().filter(filters);            
        }
    }
    
    
//
//        // no results found
//        if (me.currentIndex === null) {
//            me.getSelectionModel().deselectAll();
//        }
//
//        // force textfield focus
//        me.textField.focus();
//    }
  });
 
    Ext.define('Scheme.view.SubmitSchemeForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.SubmitSchemeForm',
      title   : 'Submit Scheme',
      width   : 800,
      height:   500,
      autoscroll:true,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [	          
                 //	formPanel2
                 	{
                 xtype:'tabpanel',
                 id: 'searchtablist',
                 defaults:{
                 	bodyStyle:'padding:10px',
                 	preventBodyReset: true
                 	},
                 	items:[
								{
								    title:'Component',
								    id : '21',
								    items: [
								            	searchCompList
								           ]
									
								},
								
								{
								    title:'Region',
								    id : '22',
								    items: [
								            	sregList
								           ]
									
								},
								
								{
								    title:'Coverage',
								    id : '23',
								    items: [
								            	scovList
								           ]
									
								},
								
								{
								    title:'TQ',
								    id : '24',
								    items: [
								            	stqList
								           ]
									
								},
								
								{
								    title:'EA',
								    id : '25',
								    items: [
								            		seaList
								           ]
									
								},
								
								{
								    title:'EA_FILTER',
								    id : '26',
								    items: [
								            	seaFilterList
								           ]
									
								},
								{
								    title:'PO',
								    id : '27',
								    items: [
								            	spoList
								           ]
									
								},
								{
								    title:'PO_FILTER',
								    id : '28',
								    items: [
								            	spoFilterList
								           ]
									
								}
                 	       
                 	       ],
                 	       
                 	      listeners: {
                 	    	  
                 	    	 'tabchange': function (tabPanel, tab) {
                 	    		 
                 	    		 
                 	    		if(tab.title=='Component')
                               	{
                 	    			searchcomponentStoreGrid.load();
                 	    			if(searchCompGridStatus==0)
                 	           		{
                 			    	Ext.application({
                 	               	    name  : 'Scheme',
                 	               	    controllers: ['SearchCompCon'],
                 	              	      launch: function () {
                 	               	    	  Ext.widget('SearchCompList', {
                 	               	          renderTo: 'searchcomplist'
                 	               	        });
                 	               	      }
                 	               	    }
                 	               	  );
                 			    	searchCompGridStatus = 1;
                 	           		}
                 	    			
                               	}
                 	    		 
                 	    		 
                 	    		if(tab.title=='Region')
                               	{
                 	    			sregZoneStore.load();
                 	               	if(sregGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SregCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SregList', {
                 	           	          renderTo: 'sreglist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              sregGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		
                 	    		if(tab.title=='Coverage')
                               	{
                 	    			scoverageStore.load();
                 	               	if(scovGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['ScovCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('ScovList', {
                 	           	          renderTo: 'scovlist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              scovGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		
                 	    		if(tab.title=='TQ')
                               	{
                 	    			stqStore.load();
                 	               	if(stqGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['StqCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('StqList', {
                 	           	          renderTo: 'stqlist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              stqGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		
                 	    		if(tab.title=='EA')
                               	{
                 	    			seaStore.load();
                 	               	if(seaGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SeaCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SeaList', {
                 	           	          renderTo: 'sealist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              seaGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		if(tab.title=='EA_FILTER')
                               	{
                 	    			seaFilterStore.load();
                 	               	if(seaFilterGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SeaFilterCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SeaFilterList', {
                 	           	          renderTo: 'seafilterlist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              seaFilterGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		if(tab.title=='PO')
                               	{
                 	    			spoStore.load();
                 	               	if(spoGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SpoCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SpoList', {
                 	           	          renderTo: 'spolist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              spoGridStatus=1;
                 	               }
                 	    			
                               	}
                               	
                 	    		if(tab.title=='PO_FILTER')
                               	{
                 	    			spoFilterStore.load();
                 	               	if(spoFilterGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SpoFilterCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SpoFilterList', {
                 	           	          renderTo: 'spofilterlist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              spoFilterGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		 
                 	    	 }
                 	      }
                 			
					}
        ]
      }],
      buttons: [	
                	
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.SubmitSchemeCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['SubmitSchemeList'],
    /* views   : ['SubmitSchemeList', 'SubmitSchemeForm'],
   refs    : [{
      ref   : 'formWindow',
      xtype : 'SubmitSchemeForm',
      selector: 'SubmitSchemeForm',
      autoCreate: true
    }],*/
    init: function () {
      this.control({
        'SubmitSchemeList > toolbar > button[action=add]': {
         // click: this.showAddForm
        },
          
        'SubmitSchemeList': {
        //  itemdblclick: this.onRowdblclick
        },
        'SubmitSchemeForm button[action=add]': {
       //   click: this.doAddBook
        }
      });
    },
    /*onRowdblclick: function(me, record, item, index) {
    	
    	SchemeName = record.data.schemeName;
		compName = "yes";
	
      var win = this.getFormWindow();
      win.setTitle('Edit Scheme');
      win.setAction('edit');
      win.setRecordIndex(record.data.schemeINputId);
      win.down('form').getForm().setValues(record.getData());
     
      Ext.Ajax.request({
		  url : 'payoutcondition/resetScheme.action',
		  method: 'POST',
		  params: {
			  "schemeINputId" : record.data.schemeINputId,
			  "schemeName" :record.data.schemeName//record.data.schemeINputId
		    },
		    success: function (response) {
		    	searchcomponentStoreGrid.load();
		    	
		    	win.show();
		    	if(searchCompGridStatus==0)
           		{
		    	Ext.application({
               	    name  : 'Scheme',
               	    controllers: ['SearchCompCon'],
              	      launch: function () {
               	    	  Ext.widget('SearchCompList', {
               	          renderTo: 'searchcomplist'
               	        });
               	      }
               	    }
               	  );
		    	searchCompGridStatus = 1;
           		}		    	
		    	
		        //schemeStore.load();
		    },
		 
		  failure: function (response) {
		       }
		 });
	
     
      
      
    },*/
    showAddForm: function () {
      var win = this.getFormWindow();
      win.setTitle('Add Scheme');
      win.setAction('add');
      win.down('form').getForm().reset();
      win.show();
    },
    doAddBook: function () {
      var win = this.getFormWindow();
      var store = this.getBooksStore();
      var values = win.down('form').getValues();
      
      var action = win.getAction();
      var book = Ext.create('schemeModel', values);
      if(action == 'edit') {
    	  console.log(book);
    	  alert(book.data.schemeINputId);
    	  alert(win.getRecordIndex());
    	  
        store.removeAt(win.getRecordIndex());
        store.insert(win.getRecordIndex(), book);  
      }
      else {
    	  saveScheme(win.down('form'));
    	  win.close();
    	  schemeStore.load();
    	  schemeStore.add(book);
      }
      win.close();
    }
  });
 
   
  
});
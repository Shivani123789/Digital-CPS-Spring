Ext.onReady(function () {
	Ext.define('Scheme.model.Cov', {
	    extend: 'Ext.data.Model',
	    fields: [
	      {name: 'compId', type: 'int'},
	      {name: 'compName',  type: 'string'},
	      {name: 'condId', type: 'int'},
	      {name: 'valueField',  type: 'string'},
	      {name: 'Lopr',  type: 'string'},
	      {name: 'lValue',  type: 'string'},
	      {name: 'rOpr',  type: 'string'}
	      
	   
	    ]
	  });
 
	
   Ext.define('Scheme.view.ScovList', {
    extend: 'Ext.grid.Panel',
    name:'scovGrid',
    pageSize : 5,
    alias: 'widget.ScovList',
    title: 'Coverage List',
    store: scoverageStore,
    height:300,
    //layout:'fit',
    autoScroll: true,
  //  store : 'Companies',
    initComponent: function () {
      this.tbar = [{
        text    : 'Add Coverage',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
        { header: 'Id', dataIndex: 'condId', width: 40 },
        { header: 'compId', dataIndex: 'compId', width: 60 },
        { header: 'Entity', dataIndex: 'entityName', flex: 1 },
        { header: 'AttrType', dataIndex: 'attrTypeName', width: 60  },
        { header: 'AttrMap', dataIndex: 'attrMappingName', width: 60  },
        { header: 'Function', dataIndex: 'functionName', width: 60  },
        { header: 'Opr', dataIndex: 'oprName', width: 40  },
        { header: 'ValType', dataIndex: 'co_ValueTypeName', width: 60  },
        { header: 'Function', dataIndex: 'co_functionName', width: 60  },
        { header: 'value', dataIndex: 'value', width: 60  },
        { header: 'Sdate', dataIndex: 'startDate', width: 60  },
        { header: 'EDate', dataIndex: 'endDate', width: 60  },
        { header: 'Lopr', dataIndex: 'loprName', width: 40  },
        { header: 'L_Entity', dataIndex: 'lentityTypeName', width: 60  },
        { header: 'L_AttrType', dataIndex: 'lattrTypeName', width: 60  },
        { header: 'L_Function', dataIndex: 'lfunctionName', width: 60  },
        { header: 'L_AttrMap', dataIndex: 'lattNameString', width: 60  },
        { header: 'L_Opr', dataIndex: 'lloprName', width: 40  },
        { header: 'L_ValueType', dataIndex: 'lvalueTypeName', width: 60  },
        { header: 'L_Function', dataIndex: 'lvfunctionName', width: 60  },
        { header: 'L_Value', dataIndex: 'lvalueName', width: 60  },
        { header: 'L_Sdate', dataIndex: 'lStartDate', width: 60  },
        { header: 'L_Edate', dataIndex: 'lEndDate', width: 60  },
        { header: 'Ropr', dataIndex: 'roprName', width: 40  },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('CovList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Covearge Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove Coverage', 
                          'Are you sure you want to delete Coverage?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removeCov.action',
                            			  method: 'POST',
                            			  params: {
                            				  "compId" : rs[0].data.compId,
                            				  "condId" :rs[0].data.condId
                            			    },
                            			    success: function (resp) {
                            			    	var response = Ext.decode(resp.responseText);
                            			    	if(response.success)
                            			    		{
                             			         Ext.Msg.alert("Info","Coverage deleted Sucessfully");
                             			        grid.store.remove(rs[0]);
                             			        coverageStore.load();
                            			    		}
                            			    	else
                            			    		{
                            			    		Ext.Msg.alert("Warning",response.message);
                            			    		}
                            			    		},
                             			 
                            			  failure: function (resp) {
                            				 
                            				  
                            			       }
                            			 });
                              
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : scoverageStore,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.ScovForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.ScovForm',
      title   : 'Add Coverage',
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          anchor: '100%'
        },
        items : [
{
    xtype: 'fieldset',
    anchor: '100%',
    title: 'Coverage Details',
    collapsible: true,
    layout:'column',
    items:[
			{
		    xtype: 'container',
		    columnWidth:.2,
		    layout: 'anchor',
		    items: [
						{
							xtype :'combo',
							editable: false,
							allowBlank: false,
							fieldLabel: 'Component',
							name:'compId',
							displayField:'compName',
							valueField:'compId',
							store: componentListStore,
							triggerAction:'all'
						} 
		            
		           ]
			},
		                   
           {
        xtype: 'container',
        columnWidth:.3,
       // id:'addtome',
        layout: 'anchor',
        items: [
					{
						xtype :'combo',
						fieldLabel: 'Entity',
						editable: false,
						name:'entityId',
						displayField:'entityName',
						autoLoad:false,
						valueField:'entityId',
						store:entityStore,
						listeners: {
							  'select': function(combo, value){
								  this.up('window').down('form').getForm().findField("attrType").allowBlank=false;
								  this.up('window').down('form').getForm().findField("attrName").allowBlank=false;
								  this.up('window').down('form').getForm().findField("opr").allowBlank=false;
								  this.up('window').down('form').getForm().findField("co_ValueType").allowBlank=false;

								  entityAttrStore.clearFilter();
								  	//entityAttrStore.filter("attrCatg",combo.getValue());
								  	entityAttrStore.filter("attrType",combo.getValue());
									this.up('window').down('form').getForm().findField("attrName").reset();
									this.up('window').down('form').getForm().findField("attrType").reset();
								  
							  }
							 },
						triggerAction:'all'
					},
					{
						xtype :'combo',
						fieldLabel: 'Attribute Type',
						editable: false,
						name:'attrType',
						displayField:'attributeTypeName',
						valueField:'attributeTypeId',
						store: attributeTypeStore,
						listeners: {
							  'select': function(combo, value){
								  //	entityAttrStore.filter("attrType",combo.getValue());
								  	entityAttrStore.filter("attrCatg",combo.getValue());
									this.up('window').down('form').getForm().findField("attrName").reset();
								  
							  }
							 },
						triggerAction:'all'
					},
					{
						xtype :'combo',
						fieldLabel: 'Function',
						editable: false,
						name:'function',
						displayField:'functionName',
						valueField:'functioId',
						store: covFunctionStore,
						triggerAction:'all'
					},
					{
						xtype :'combo',
						editable: false,
						fieldLabel: 'Entity Attribute',
						name:'attrName',
						displayField:'entityAttributeName',
						valueField:'entityAttributeId',
						store: entityAttrStore,
						listeners: {
							  'select': function(combo, value){
								
								  entityAttrStore.findBy(function(record,id) {
								        if(record.get('entityAttributeId')==combo.getValue()) {
								        	covFreeTextType = record.data.freeTextType;
								        }
								    });
								
							  }
							 },
						triggerAction:'all'
					},
					
					{
						xtype :'combo',
						editable: false,
						fieldLabel: 'OPR',
						name:'opr',
						displayField:'oprName',
						valueField:'oprId',
						store: oprStore,
						listeners: {
							  'select': function(combo, value){
								
								 if(combo.getValue()==14)
									 {
									 this.up('window').down('form').getForm().findField("co_ValueType").disable();
									 this.up('window').down('form').getForm().findField("startDate").allowBlank=false;
									 this.up('window').down('form').getForm().findField("endDate").allowBlank=false;
									 }
								 else
								 {
								 this.up('window').down('form').getForm().findField("co_ValueType").enable();

								 }
							  }
							 },
						triggerAction:'all'
					},
					
					
					{
						xtype :'combo',
						editable: false,
						fieldLabel: 'Function',
						name:'co_vFunction',
						displayField:'functionName',
						valueField:'functioId',
						store: covFunctionStore,
						triggerAction:'all'
					},
					
					
					
					{
        		    	   xtype :'datefield',
        		    	   fieldLabel: 'Start Date',
        		    	   //minValue: new Date(),
        		    	   name:'startDate',
        		    	   editable : false
        		    	   
        		    	  
        		    },
        		    {
        		    	   xtype :'datefield',
        		    	  //minValue: new Date(),
        		    	   editable: false,
        		    	   fieldLabel: 'End Date',
        		    	   name:'endDate'
        		    	 
        		    },
        		    {
						xtype :'combo',
						editable: false,
						fieldLabel: 'Value Type',
						name:'co_ValueType',
						displayField:'valueTypeName',
						valueField:'valueTypeId',
						store: covValueTypeStore,
						listeners: {
							  'select': function(combo, value){
								  if(combo.getValue()==5)
									  {
									  this.up('window').down('form').getForm().findField("startDate").allowBlank=false;
									  this.up('window').down('form').getForm().findField("endDate").allowBlank=false;

									  }
								  
								  if(combo.getValue()==1)
								  {
									  
									  this.up('window').down('form').getForm().findField("value").enable();
									  this.up('window').down('form').getForm().findField("ValueListName").disable();

									  
//									  Ext.getCmp('addtome').remove(valueList);
//									  if(covFreeTextType=='S')
//										  Ext.getCmp('addtome').add(valueText);
//										  if(covFreeTextType=='N')
//											  Ext.getCmp('addtome').add(valueNumber);
//											  if(covFreeTextType=='D')
//												  Ext.getCmp('addtome').add(valueDate);
							  }
								  
								  if(combo.getValue()!=1)
								  {
									  this.up('window').down('form').getForm().findField("value").disable();
									  this.up('window').down('form').getForm().findField("ValueListName").enable();
									  win.down('form').getForm().findField("ValueListName").reset();

//									  if(covFreeTextType=='S')
//										  Ext.getCmp('addtome').remove(valueText);
//										  if(covFreeTextType=='N')
//											  Ext.getCmp('addtome').remove(valueNumber);
//											  if(covFreeTextType=='D')
//												  Ext.getCmp('addtome').remove(valueDate);
//									  
//									  Ext.getCmp('addtome').add(valueList);
//									
								  }
								
							  }
							 },
						triggerAction:'all'
					},
					
					{
						xtype :'textfield',
						editable: false,
						fieldLabel: 'Value*',
						name:'value',
						allowBlank: false
					},
					
					{
						xtype :'combo',
						editable: false,
						allowBlank: false,
						fieldLabel: 'Value*',
						name:'ValueListName',
						displayField:'entityAttributeName',
						valueField:'entityAttributeName',
						store: entityAttrStore,
						triggerAction:'all'
					}
					
					
               ]
    },
    
    
    
    {
        xtype: 'container',
        columnWidth:.2,
        layout: 'anchor',
        items: [
					{
						xtype :'combo',
						editable: false,
						fieldLabel: 'LOPR',
						name:'Lopr',
						displayField:'oprName',
						valueField:'oprId',
						store: CreateLoprStore(),//oprStore,
						listeners: {
							  'select': function(combo, value){
								
								  if(combo.getValue()==0){
									  this.up('window').down('form').getForm().findField("lEntityType").reset();
									  this.up('window').down('form').getForm().findField("lAttrType").reset();
									  this.up('window').down('form').getForm().findField("lOpr").reset();
									  this.up('window').down('form').getForm().findField("lFunction").reset();
									  this.up('window').down('form').getForm().findField("lAttName").reset();
									  this.up('window').down('form').getForm().findField("lValueType").reset();
									  this.up('window').down('form').getForm().findField("LvalueListName").reset();
									  this.up('window').down('form').getForm().findField("lVfunction").reset();
									  this.up('window').down('form').getForm().findField("lStartDate").reset();
									  this.up('window').down('form').getForm().findField("lEndDate").reset();
									  this.up('window').down('form').getForm().findField("rOpr").reset();
									  this.up('window').down('form').getForm().findField("lValue").reset();
									  
									  this.up('window').down('form').getForm().findField("lAttrType").allowBlank=true;
									  this.up('window').down('form').getForm().findField("lEntityType").allowBlank=true;
									  this.up('window').down('form').getForm().findField("lValueType").allowBlank=true;
									  this.up('window').down('form').getForm().findField("lOpr").allowBlank=true;
								  }
							  }
							 },
						triggerAction:'all'
					}
                ]
    },
    
    {
        xtype: 'container',
        columnWidth:.3,
        layout: 'anchor',
        id:'Slfieldlist',
        items: [
               
						{
							xtype :'combo',
							editable: false,
							fieldLabel: 'Entity',
							name:'lEntityType',
							displayField:'entityName',
							valueField:'entityId',
							store: entityStore,
							listeners: {
								  'select': function(combo, value){
									  this.up('window').down('form').getForm().findField("lAttrType").allowBlank=false;
									  this.up('window').down('form').getForm().findField("lAttName").allowBlank=false;
									  this.up('window').down('form').getForm().findField("lOpr").allowBlank=false;
									  this.up('window').down('form').getForm().findField("lValueType").allowBlank=false;

									  entityAttrStore.clearFilter();
									  	entityAttrStore.filter("attrCatg",combo.getValue());
										this.up('window').down('form').getForm().findField("lAttName").reset();
										this.up('window').down('form').getForm().findField("lAttrType").reset();
								  }
								 },
							triggerAction:'all'
						},
						{
							xtype :'combo',
							editable: false,
							fieldLabel: 'Attribute Type',
							name:'lAttrType',
							displayField:'attributeTypeName',
							valueField:'attributeTypeId',
							store: attributeTypeStore,
							listeners: {
								  'select': function(combo, value){
									  	entityAttrStore.filter("attrType",combo.getValue());
										this.up('window').down('form').getForm().findField("lAttName").reset();
									  
								  }
								 },
							triggerAction:'all'
						},
						{
							xtype :'combo',
							editable: false,
							fieldLabel: 'Function',
							name:'lFunction',
							displayField:'functionName',
							valueField:'functioId',
							store: covFunctionStore,
							triggerAction:'all'
						},
						{
							xtype :'combo',
							editable: false,
							fieldLabel: 'Entity Attribute',
							name:'lAttName',
							displayField:'entityAttributeName',
							valueField:'entityAttributeId',
							store: entityAttrStore,
							listeners: {
								  'select': function(combo, value){
									
									  entityAttrStore.findBy(function(record,id) {
									        if(record.get('entityAttributeId')==combo.getValue()) {
									        	covlFreeTextType = record.data.freeTextType;
									        }
									    });
									
								  }
								 },
							triggerAction:'all'
						},
						
						{
							xtype :'combo',
							editable: false,
							fieldLabel: 'OPR',
							name:'lOpr',
							displayField:'oprName',
							valueField:'oprId',
							store: oprStore,
							listeners: {
								  'select': function(combo, value){
									
									 if(combo.getValue()==14)
										 {
										 this.up('window').down('form').getForm().findField("lValueType").disable();
										 this.up('window').down('form').getForm().findField("lStartDate").allowBlank=false;
										 this.up('window').down('form').getForm().findField("lEndDate").allowBlank=false;
										 }
									 else
										 {
										 this.up('window').down('form').getForm().findField("lValueType").enable();

										 }
								  }
								 },
							triggerAction:'all'
						},
						
						{
							xtype :'combo',
							editable: false,
							fieldLabel: 'Value Type',
							name:'lValueType',
							displayField:'valueTypeName',
							valueField:'valueTypeId',
							store: covValueTypeStore,
							listeners: {
								  'select': function(combo, value){
									  if(combo.getValue()==5)
										  {
										  this.up('window').down('form').getForm().findField("lStartDate").allowBlank=false;
										  this.up('window').down('form').getForm().findField("lEndDate").allowBlank=false;

										  }
									  
									  if(combo.getValue()==1)
									  {
											this.up('window').down('form').getForm().findField("lValue").enable();
												this.up('window').down('form').getForm().findField("LvalueListName").disable();


//										  Ext.getCmp('Slfieldlist').remove(lvalueList);
//										  if(covFreeTextType=='S')
//											  Ext.getCmp('Slfieldlist').add(lvalueText);
//											  if(covFreeTextType=='N')
//												  Ext.getCmp('Slfieldlist').add(lvalueNumber);
//												  if(covFreeTextType=='D')
//													  Ext.getCmp('Slfieldlist').add(lvalueDate);
									  }
									  
									  if(combo.getValue()!=1)
									  {
										  this.up('window').down('form').getForm().findField("lValue").disable();
											this.up('window').down('form').getForm().findField("LvalueListName").enable();
											win.down('form').getForm().findField("LvalueListName").reset();

////										  if(covFreeTextType=='S')
////											  Ext.getCmp('Slfieldlist').remove(lvalueText);
////											  if(covFreeTextType=='N')
////												  Ext.getCmp('Slfieldlist').remove(lvalueNumber);
////												  if(covFreeTextType=='D')
////													  Ext.getCmp('Slfieldlist').remove(lvalueDate);
////										  
//										  Ext.getCmp('Slfieldlist').add(lvalueList);
//										
									  }
									
								  }
								 },
							triggerAction:'all'
						},
						
						{
							xtype :'textfield',
							editable: false,
							fieldLabel: 'Value',
						//	allowBlank: false,
							name:'lValue'
						},
						
						{
							xtype :'combo',
							editable: false,
						//	allowBlank: false,
							fieldLabel: 'Value',
							name:'LvalueListName',
							displayField:'entityAttributeName',
							valueField:'entityAttributeName',
							store: entityAttrStore,
							triggerAction:'all'
						},
						
						{
							xtype :'combo',
							editable: false,
							fieldLabel: 'Function',
							name:'lVfunction',
							displayField:'functionName',
							valueField:'functioId',
							store: covFunctionStore,
							triggerAction:'all'
						},
						
						
						{
							   xtype :'datefield',
							   editable: false,
							  //minValue: new Date(),
							   fieldLabel: 'Start Date',
							   name:'lStartDate'
							   
						},
						{
							   xtype :'datefield',
							   editable: false,
							   //minValue: new Date(),
							   fieldLabel: 'End Date',
							   name: 'lEndDate'
							   
						},
						{
							xtype :'combo',
							editable: false,
							fieldLabel: 'ROPR',
							name:'rOpr',
							displayField:'oprName',
							valueField:'oprId',
							store: RoprStore,
							triggerAction:'all'
						}
                
               ]
    }]
} 
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add'
    	  				
                	},
                	
                	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.ScovCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['ScovList', 'ScovForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'ScovForm',
      selector: 'ScovForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'ScovList > toolbar > button[action=add]': {
          click: this.showCovForm
        },
        'ScovList': {
          itemdblclick: this.onRowdblclick
        },
        'ScovForm button[action=add]': {
          click: this.doAddCov
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    
    	 var win = this.getFormWindow();
    	 win.down('form').getForm().reset();
    	win.down('form').getForm().findField("value").disable();
    	win.down('form').getForm().findField("ValueListName").disable();
    	win.down('form').getForm().findField("lValue").disable();
    	win.down('form').getForm().findField("LvalueListName").disable();


    	
    	console.log(record.data);
    //	alert(record.data.attrTypeName);
     
//    Ext.getCmp('addtome').remove(valueText);
//  	Ext.getCmp('addtome').remove(valueDate);
//  	Ext.getCmp('addtome').remove(valueNumber);
//  	Ext.getCmp('addtome').remove(valueList);
//  	Ext.getCmp('Slfieldlist').remove(lvalueText);
//  	Ext.getCmp('Slfieldlist').remove(lvalueDate);
//  	Ext.getCmp('Slfieldlist').remove(lvalueNumber);
//  	Ext.getCmp('Slfieldlist').remove(lvalueList);
//  	
      covCompId = record.data.compId;
      covCondId = record.data.condId;
      win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compName',record.data.compName));
      win.down('form').getForm().findField('entityId').setValue(entityStore.findRecord('entityName',record.data.entityName));
      win.down('form').getForm().findField('attrType').setValue(attributeTypeStore.findRecord('attributeTypeName',record.data.attrTypeName));
      win.down('form').getForm().findField('function').setValue(covFunctionStore.findRecord('functionName',record.data.functionName));
      win.down('form').getForm().findField('attrName').setValue(entityAttrStore.findRecord('entityAttributeName',record.data.attrMappingName));
      win.down('form').getForm().findField('opr').setValue(oprStore.findRecord('oprName',record.data.oprName));
      win.down('form').getForm().findField('co_vFunction').setValue(covFunctionStore.findRecord('functionName',record.data.co_functionName)); 
      win.down('form').getForm().findField('co_ValueType').setValue(covValueTypeStore.findRecord('valueTypeName',record.data.co_ValueTypeName));
      if(record.data.co_ValueTypeName=='Free Text')
    	  {
    	  
    	  win.down('form').getForm().findField("ValueListName").disable();
    	  win.down('form').getForm().findField("value").enable();
    	  win.down('form').getForm().findField("value").setValue(record.data.value);

    	  }
      else
    	  {
    	  win.down('form').getForm().findField("value").disable();
    	  win.down('form').getForm().findField("ValueListName").enable();
    	  win.down('form').getForm().findField("ValueListName").setValue(record.data.value);

    	  
    	  }
      
      if(record.data.lvalueTypeName=='Free Text')
	  {
	  
    	  win.down('form').getForm().findField("LvalueListName").disable();
    	  win.down('form').getForm().findField("lValue").enable();
    	  win.down('form').getForm().findField("lValue").setValue(record.data.lvalueName);

	  }
  else
	  {
	  win.down('form').getForm().findField("lValue").disable();
	  win.down('form').getForm().findField("LvalueListName").enable();
	  win.down('form').getForm().findField("LvalueListName").reset();
	  win.down('form').getForm().findField("LvalueListName").setValue(record.data.lvalueName);

	  
	  }

   //   Ext.getCmp('addtome').add(valueText);
      //      //win.down('form').getForm().findField('co_ValueType').setValue(payToStore.findRecord('displayValue',record.data.payToName));
      win.down('form').getForm().findField('Lopr').setValue(CreateLoprStore().findRecord('oprName',record.data.loprName));
      win.down('form').getForm().findField('lEntityType').setValue(entityStore.findRecord('entityName',record.data.lentityTypeName));
      win.down('form').getForm().findField('lAttrType').setValue(attributeTypeStore.findRecord('attributeTypeName',record.data.lattrTypeName));
      win.down('form').getForm().findField('lFunction').setValue(covFunctionStore.findRecord('functionName',record.data.lfunctionName));
      win.down('form').getForm().findField('lAttName').setValue(entityAttrStore.findRecord('entityAttributeName',record.data.lattNameString));
      win.down('form').getForm().findField('lOpr').setValue(oprStore.findRecord('oprName',record.data.lloprName));
      win.down('form').getForm().findField('lValueType').setValue(covValueTypeStore.findRecord('valueTypeName',record.data.lvalueTypeName));
   //   Ext.getCmp('Slfieldlist').add(lvalueText);
      win.down('form').getForm().findField('lValue').setValue(record.data.lvalueName);
      win.down('form').getForm().findField('lVfunction').setValue(covFunctionStore.findRecord('functionName',record.data.lvfunctionName));
      //win.down('form').getForm().findField('rOpr').setValue(payToStore.findRecord('displayValue',record.data.payToName));
      //win.down('form').getForm().findField('rOpr').setValue(covRoprStore.findRecord('oprName',record.data.roprName));
     win.setTitle('Edit Coverage');
      win.setAction('edit');
      win.setRecordIndex(record.data.schemeINputId);
      win.down('form').getForm().setValues(record.getData());
      win.show();
    },
    showCovForm: function () {
    	
    	if(compName!=null)
		{
    		 var win = this.getFormWindow();
    	      win.setTitle(SchemeName);
    	      win.setAction('add');
    	      win.down('form').getForm().reset();
    	      win.show();
		}
    	else{
    		Ext.Msg.alert('Info', "Please create componenet for scheme first");	
    	}
     
    },
    doAddCov: function () {
      var win = this.getFormWindow();
      var action = win.getAction();
      if(action == 'edit') {
    	  if(win.down('form').isValid())
		  	{
    		  updateCoverage(win);
  		  
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}  
      }
      else {
    	  if(win.down('form').isValid())
		  	{
    		  saveCoverage(win);
    		  
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
    	 
      }
    }
  });
 
  
   
});
Ext.onReady(function () {
	Ext.define('Scheme.model.PoFilter', {
	    extend: 'Ext.data.Model',
	    fields: [
	      {name: 'compId', type: 'int'},
	      {name: 'compName',  type: 'string'},
	      {name: 'condId', type: 'int'},
	      {name: 'inputParameter',  type: 'string'},
	      {name: 'variable',  type: 'string'}
	      
	    ]
	  });
  
	Ext.define('Scheme.view.SpoFilterList', {
    extend: 'Ext.grid.Panel',
    name:'spoFilterGrid',
    pageSize : 5,
    alias: 'widget.SpoFilterList',
    title: 'Po_Filter List',
    store: spoFilterStore,
    height:300,
    autoScroll: true,
    initComponent: function () {
      this.tbar = [{
        text    : 'Add PoFilter',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
        { header: 'compId', dataIndex: 'compId', width: 60 },
       // { header: 'compName', dataIndex: 'compName', flex: 1 },
        { header: 'condId', dataIndex: 'condId', width: 80  },
        { header: 'Value', dataIndex: 'value', flex: 1 },
        { header: 'grossNet', dataIndex: 'grossNet', width: 60  },
        { header: 'unitName', dataIndex: 'unitName', width: 60  },
        { header: 'amount', dataIndex: 'amount', width: 60  },
        { header: 'variableName', dataIndex: 'variableName', width: 80  },
        { header: 'overAch', dataIndex: 'overAch', width: 60  },
        { header: 'underAch', dataIndex: 'underAch', width: 60  },
        { header: 'updateDate', dataIndex: 'updateDate', width: 80  },
        { header: 'insertDate', dataIndex: 'insertDate', width: 80  },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('PoFilterList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No PoFilter Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove PoFilter', 
                          'Are you sure you want to delete PoFilter?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removePoFilter.action',
                            			  method: 'POST',
                            			  params: {
                            				  "compId" : rs[0].data.compId,
                            				  "condId" :rs[0].data.condId
                            			    },
                            			    success: function (response) {
                             			         Ext.Msg.alert("Info","PO Filter deleted Sucessfully");
                             			        poFilterStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : spoFilterStore,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.SpoFilterForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.SpoFilterForm',
      title   : 'Add PoFilter',
      //width   : 350,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [
										{
            xtype: 'fieldset',
            anchor: '100%',
            title: 'Payout Filter Details',
            collapsible: true,
            layout:'column',
            items:[
					{
				    xtype: 'container',
				    columnWidth:.2,
				    layout: 'anchor',
				    items: [
								{
									xtype :'combo',
									fieldLabel: 'Component',
									name:'compId',
									allowBlank:false,
			        		    	editable: false,
									displayField:'compName',
									valueField:'compId',
									store: componentListStore,
									triggerAction:'all'
								} ,
								
								{
									xtype :'combo',
									fieldLabel: 'Value',
									allowBlank:false,
			        		    	editable: false,
									name:'condId',
									displayField:'value',
									valueField:'condId',
									store: poFilterValues,
									triggerAction:'all'
								} 
				            
				           ]
					},
				                   
              
           
            
            {
                xtype: 'container',
                columnWidth:.3,
                layout: 'anchor',
                items: [
                       
								{
									xtype :'combo',
									fieldLabel: 'Gross/Net',
									name:'grossNet',
									allowBlank:false,
			        		    	editable: false,
									displayField:'name',
									valueField:'name',
									store: CreateGrossNetStore(),
									triggerAction:'all'
								},
								{
									xtype :'combo',
									fieldLabel: 'Unit',
									name:'unit',
									allowBlank:false,
			        		    	editable: false,
									displayField:'unitName',
									valueField:'unitId',
									store: unitStore,
									triggerAction:'all'
								},
								
								{
									xtype :'numberfield',
									fieldLabel: 'Amount',
									allowBlank:false,
			        		    	
									name:'amount'
									
								},
								{
									xtype :'combo',
									fieldLabel: 'Variable',
									name:'variable',
									allowBlank:false,
			        		    	editable: false,
									displayField:'displayValue',
									valueField:'entityTypeId',
									store: payToStore,
									triggerAction:'all'
								},
								{
									xtype :'numberfield',
									allowBlank:false,
			        		    	
									fieldLabel: 'OverAchivement Cap',
									name:'overAch'
									
								},
								{
									xtype :'numberfield',
									allowBlank:false,
			        		    	
									fieldLabel: 'UnderAchivement Cap',
									name:'underAch'
									
								}
                        
                       ]
            }]
        }
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add'
    	  				
                	},
                	
                	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.SpoFilterCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['SpoFilterList', 'SpoFilterForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'PoFilterForm',
      selector: 'PoFilterForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'SpoFilterList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'SpoFilterList': {
          itemdblclick: this.onRowdblclick
        },
        'SpoFilterForm button[action=add]': {
          click: this.doAddPoFilter
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	
    	console.log(record.data);
    	poCompId = record.data.compId;
    	poCondId = record.data.condId;
      var win = this.getFormWindow();
      win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compId',record.data.compId));
      win.down('form').getForm().findField('condId').setValue(poFilterValues.findRecord('value',record.data.inputType));
      win.down('form').getForm().findField('grossNet').setValue(CreateGrossNetStore().findRecord('name',record.data.inputParameter));
      win.down('form').getForm().findField('unit').setValue(unitStore.findRecord('unitName',record.data.unitName));
      win.down('form').getForm().findField('variable').setValue(payToStore.findRecord('displayValue',record.data.valueType));
      win.setTitle('Edit PoFilter');
      win.setAction('edit');
      win.down('form').getForm().setValues(record.getData());
      win.show();
    },
    showAddForm: function () {
    	
    	if(compName!=null)
		{
    		var win = this.getFormWindow();
    	      win.setTitle(SchemeName);
    	      win.setAction('add');
    	      win.down('form').getForm().reset();
    	      win.show();
		}
    	else{
    		Ext.Msg.alert('Info', "Please create payout condition for scheme first");	
    	}	
     
    },
    doAddPoFilter: function () {
      var win = this.getFormWindow();
      var store = this.getBooksStore();
      var values = win.down('form').getValues();
      
      var action = win.getAction();
      var book = Ext.create('schemeModel', values);
      if(action == 'edit') {
    	  if(win.down('form').isValid())
		  	{
    		  updatePoFilter(win);
		  win.close();
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
  	  
      }
      else {
    	  if(win.down('form').isValid())
		  	{
    		  savePoFilter(win);
		 
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
    	 
      }
    }
  });
 
  
   
});
Ext.onReady(function () {
	Ext.define('Scheme.model.Tq', {
	    extend: 'Ext.data.Model',
	    fields: [
	      {name: 'compId', type: 'int'},
	      {name: 'compName',  type: 'string'},
	      {name: 'condId', type: 'int'},
	      {name: 'value',  type: 'string'},
	      {name: 'condRowId', type: 'int'},
	      {name: 'loprName',  type: 'string'},
	      {name: 'lValue',  type: 'string'},
	      {name: 'roprName',  type: 'string'}
	      
	     
	    ]
	  });
 
	
	
   
 
   Ext.define('Scheme.view.StqList', {
    extend: 'Ext.grid.Panel',
    name:'stqGrid',
    pageSize : 5,
    alias: 'widget.StqList',
    title: 'Tq List',
    store: stqStore,
    height:300,
    //layout:'fit',
    autoScroll: true,
  //  store : 'Companies',
    initComponent: function () {
      this.tbar = [{
        text    : 'Add Tq',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
        { header: 'Id', dataIndex: 'condId', width: 40 },
       // { header: 'compName', dataIndex: 'compName', flex: 1 },
        { header: 'CompId', dataIndex: 'compId', width: 40  },
        { header: 'CondName', dataIndex: 'condName', flex: 1  },
        { header: 'DataSet', dataIndex: 'dataSetName', width: 60  },
        { header: 'P Param', dataIndex: 'perfParamName', width: 60  },
        { header: 'Opr', dataIndex: 'oprName', width: 40  },
        { header: 'valueType', dataIndex: 'valueTypeName', width: 60 },
        { header: 'value', dataIndex: 'value', width: 60 },
        { header: 'SDate', dataIndex: 'startDate', width: 60 },
        { header: 'EDate', dataIndex: 'endDate', width: 60 },
        { header: 'LOPR', dataIndex: 'loprName', width: 40 },
        { header: 'LP_Param', dataIndex: 'lperfParamName', width: 60 },
        { header: 'L_opr', dataIndex: 'l_loprName', width: 60 },
        { header: 'L_ValueType', dataIndex: 'lvalueTypeName', width: 60 },
        { header: 'LValue', dataIndex: 'lValue', width: 60 },
        { header: 'LSDate', dataIndex: 'lStartDate', width: 60 },
        { header: 'LEDate', dataIndex: 'lEndDate', width: 60 },
        { header: 'Ropr', dataIndex: 'roprName', width: 60 },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('TqList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Tq Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove Region', 
                          'Are you sure you want to delete Tq?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            	//ajax post to remove
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removeTq.action',
                            			  method: 'POST',
                            			  params: {
                            				  "compId" : rs[0].data.compId,
                            				  "condId" :rs[0].data.condId
                            			    },
                            			    success: function (response) {
                             			         Ext.Msg.alert("Info","TQ deleted Sucessfully");
                             			        tqStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : stqStore,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.StqForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.StqForm',
      title   : 'Add Tq',
      //width   : 350,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [
										{
            xtype: 'fieldset',
            anchor: '100%',
            title: 'Transaction Details',
            collapsible: true,
            layout:'column',
            items:[
					{
				    xtype: 'container',
				    columnWidth:.2,
				    layout: 'anchor',
				    items: [
								{
									xtype :'combo',
									editable: false,
									//allowBlank:false,
									fieldLabel: 'Component',
									name:'compId',
									displayField:'compName',
									valueField:'compId',
									store: componentListStore,
									triggerAction:'all'
								} 
				            
				           ]
					},
				                   
                   {
                xtype: 'container',
                columnWidth:.3,
                id:'StqLeft',
                layout: 'anchor',
                items: [
							{
								xtype :'textfield',
								
								allowBlank:false,
								fieldLabel: 'Condition Name',
								name:'condName'
							},
							{
								xtype :'combo',
								allowBlank:false,
								editable: false,
								fieldLabel: 'Data Set',
								name:'dataSet',
								displayField:'dataSetName',
								valueField:'dataSetId',
								store: dataSetStore,
								listeners: {
									  'select': function(combo, value){
										  tqValueListStore.clearFilter();
										  tqValueListStore.filter("univId",combo.getValue());
											
									  }
									 },
								triggerAction:'all'
							},
							{
								xtype :'combo',
								fieldLabel: 'Param',
								allowBlank:false,
								editable: false,
								name:'perfParmeter',
								displayField:'paramName',
								valueField:'paramId',
								store: paramStore,
								triggerAction:'all'
							},
							
							{
								xtype :'combo',
								fieldLabel: 'OPR',
								allowBlank:false,
								editable: false,
								name:'opr',
								displayField:'oprName',
								valueField:'oprId',
								store: oprStoreTq,
								listeners: {
									  'select': function(combo, value){
										
										 if(combo.getValue()==14)
											 {
											 this.up('window').down('form').getForm().findField("valueType").disable();
											 this.up('window').down('form').getForm().findField("startDate").allowBlank=false;
											 this.up('window').down('form').getForm().findField("endDate").allowBlank=false;
											 }
										 else
										 {
										 this.up('window').down('form').getForm().findField("valueType").enable();

										 }
									  }
									 },
								triggerAction:'all'
							},
							
							{
								xtype :'combo',
								allowBlank:false,
								editable: false,
								fieldLabel: 'Value Type',
								name:'valueType',
								displayField:'valueTypeName',
								valueField:'valueTypeId',
								store: tqValueTypeStore,
								listeners: {
									  'select': function(combo, value){
										  console.log(tqFreeTextType);
										  if(combo.getValue()==1)
										  {
											  Ext.getCmp('StqLeft').remove(TqValueList);
											  if(tqFreeTextType=='S')
												  Ext.getCmp('StqLeft').add(TqValueText);
												  if(tqFreeTextType=='N')
													  Ext.getCmp('StqLeft').add(TqValueDate);
													  if(tqFreeTextType=='D')
														  Ext.getCmp('StqLeft').add(TqValueNumber);
													  else	  
														  Ext.getCmp('StqLeft').add(TqValueText);
										  }
										  
										  else
											  {
											  if(covFreeTextType=='S')
												  Ext.getCmp('StqLeft').remove(TqValueList);
												  if(covFreeTextType=='N')
													  Ext.getCmp('StqLeft').remove(TqValueText);
													  if(covFreeTextType=='D')
														  Ext.getCmp('StqLeft').remove(TqValueDate);
											  
											  Ext.getCmp('StqLeft').add(TqValueList);
											  }
									  }
									 },
								triggerAction:'all'
							},
							
							
							{
		        		    	   xtype :'datefield',
		        		    	   fieldLabel: 'Start Date',
		        		    	   editable: false,
		        		    	   //minValue: new Date(),
		        		    	   name:'startDate',
		        		    	   value:new Date()
		        		    },
		        		    {
		        		    	   xtype :'datefield',
		        		    	   fieldLabel: 'End Date',
		        		    	   editable: false,
		        		    	  // minValue: new Date(),
		        		    	   name:'endDate',
		        		    	   value:new Date()
		        		    }
                       ]
            },
            
            {
                xtype: 'container',
                columnWidth:.2,
                layout: 'anchor',
                items: [
							{
								xtype :'combo',
								fieldLabel: 'LOPR',
								editable: false,
								name:'Lopr',
								displayField:'oprName',
								valueField:'oprId',
								store: TqLoprStore,
								triggerAction:'all'
							}
                        ]
            },
            
            {
                xtype: 'container',
                columnWidth:.3,
                id:'SLright',
                layout: 'anchor',
                items: [
                       
								{
								xtype :'combo',
								editable: false,
								fieldLabel: 'Param',
								name:'lPrefparameter',
								displayField:'paramName',
								valueField:'paramId',
								store: paramStore,
								triggerAction:'all'
							},

							{
								xtype :'combo',
								fieldLabel: 'OPR',
								editable: false,
								name:'lOpr',
								displayField:'oprName',
								valueField:'oprId',
								store: oprStoreTq,
								listeners: {
									  'select': function(combo, value){
										
										 if(combo.getValue()==14)
											 {
											 this.up('window').down('form').getForm().findField("lValueType").disable();
											 this.up('window').down('form').getForm().findField("lStartDate").allowBlank=false;
											 this.up('window').down('form').getForm().findField("lEndDate").allowBlank=false;
											 }
										 else
										 {
										 this.up('window').down('form').getForm().findField("lValueType").enable();

										 }
									  }
									 },
								triggerAction:'all'
							},
							
							{
								xtype :'combo',
								fieldLabel: 'Value Type',
								editable: false,
								name:'lValueType',
								displayField:'valueTypeName',
								valueField:'valueTypeId',
								store: tqValueTypeStore,
								listeners: {
									  'select': function(combo, value){
										
										  if(combo.getValue()==1)
										  {
											 // cosole.log(tqFreeTextType);
											  Ext.getCmp('SLright').remove(TqLValueList);
											  if(tqFreeTextType=='S')
												  Ext.getCmp('SLright').add(TqLValueText);
												  if(tqFreeTextType=='N')
													  Ext.getCmp('SLright').add(TqLValueDate);
													  if(tqFreeTextType=='D')
														  Ext.getCmp('SLright').add(TqLValueNumber);
													  else	  
														  Ext.getCmp('SLright').add(TqLValueText);
						
										  
										  }
										  
										  else
											  {
											  if(covFreeTextType=='S')
												  Ext.getCmp('SLright').remove(TqLValueList);
												  if(covFreeTextType=='N')
													  Ext.getCmp('SLright').remove(TqLValueText);
													  if(covFreeTextType=='D')
														  Ext.getCmp('SLright').remove(TqLValueDate);
											  
											  Ext.getCmp('SLright').add(TqLValueList);
											  }
									  }
									 },
								triggerAction:'all'
							},
								
								
								{
									   xtype :'datefield',
									   fieldLabel: 'Start Date',
									   name:'lStartDate',
									   value:new Date()
								},
								{
									   xtype :'datefield',
									   fieldLabel: 'End Date',
									   name: 'lEndDate',
									   value:new Date()
								},
								,
								{
									xtype :'combo',
									fieldLabel: 'ROPR',
									editable: false,
									name:'lRopr',
									displayField:'oprName',
									valueField:'oprId',
									store: RoprStore,
									triggerAction:'all'
								}
                        
                       ]
            }]
        }
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add',
    	  				
                	},
                	
                	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.StqCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['StqList', 'StqForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'StqForm',
      selector: 'StqForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'StqList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'StqList': {
          itemdblclick: this.onRowdblclick
        },
        'StqForm button[action=add]': {
          click: this.doAddTq
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	console.log(record.data);
    	tqCondId = record.data.condId;
    	tqCompId = record.data.compId;
      var win = this.getFormWindow();
      win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compName',record.data.compName));
      win.down('form').getForm().findField('dataSet').setValue(dataSetStore.findRecord('dataSetName',record.data.dataSetName));
      win.down('form').getForm().findField('perfParmeter').setValue(paramStore.findRecord('paramName',record.data.perfParamName));
      win.down('form').getForm().findField('opr').setValue(oprStoreTq.findRecord('oprName',record.data.oprName));
      win.down('form').getForm().findField('valueType').setValue(tqValueTypeStore.findRecord('valueTypeName',record.data.valueTypeName));
     // win.down('form').getForm().findField('value').setValue(oprStore.findRecord('oprName',record.data.value));
      win.down('form').getForm().findField('Lopr').setValue(TqLoprStore.findRecord('oprName',record.data.loprName)); 
      win.down('form').getForm().findField('lPrefparameter').setValue(paramStore.findRecord('paramName',record.data.lperfParamName));
      win.down('form').getForm().findField('lOpr').setValue(oprStoreTq.findRecord('oprName',record.data.l_loprName));
      win.down('form').getForm().findField('lValueType').setValue(tqValueTypeStore.findRecord('valueTypeName',record.data.lvalueTypeName));
    //  win.down('form').getForm().findField('lvalue').setValue(attributeTypeStore.findRecord('attributeTypeName',record.data.lValue));
      win.down('form').getForm().findField('lRopr').setValue(RoprStore.findRecord('oprName',record.data.roprName));

      win.setTitle('Edit TQ');
      win.setAction('edit');
      win.setRecordIndex(record.data.condId);
      win.down('form').getForm().setValues(record.getData());
      win.show();
    },
    showAddForm: function () {
    	
    	if(compName!=null)
		{
    		 var win = this.getFormWindow();
    	      win.setTitle(SchemeName);
    	      win.setAction('add');
    	      win.down('form').getForm().reset();
    	      win.show();
		}
    	else{
    		Ext.Msg.alert('Info', "Please create componenet for scheme first");	
    	}
     
    },
    doAddTq: function () {
      var win = this.getFormWindow();
      
      var action = win.getAction();
      if(action == 'edit') {
    	  
    	  if(win.down('form').isValid())
		  	{
  		  updateTq(win);
		  
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
      }
      else {
    	  if(win.down('form').isValid())
		  	{
    		  saveTq(win);
  		  
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
    	 
      }
    }
  });
 
  
   
});
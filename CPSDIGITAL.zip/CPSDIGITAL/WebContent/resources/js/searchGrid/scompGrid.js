Ext.onReady(function () {
	
	
	
	
   Ext.define('Scheme.view.SearchCompList', {
    extend: 'Ext.grid.Panel',
    name:'searchcompGrid',
    pageSize : 5,
    autoLoad:false,
    alias: 'widget.SearchCompList',
    title: 'Comp List',
    store: searchcomponentStoreGrid,
    height:300,
    autoScroll: true,
    initComponent: function () {
      this.tbar = [{
        text    : 'Add Comp',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
		{ header: 'Scheme Id', dataIndex: 'schemeId', width: 60 },
		{ header: 'Scheme Name', dataIndex: 'schemeName', width: 80 },
        { header: 'Comp Id', dataIndex: 'compId', width: 60 },
        { header: 'Comp Name', dataIndex: 'compName', flex: 1 },
        { header: 'Start Date', dataIndex: 'startDate', width: 80 },
        { header: 'End Date', dataIndex: 'endDate', width: 80 },
        { header: 'Freq Name', dataIndex: 'freqName', width: 80 },
        { header: 'Vertical Name', dataIndex: 'verticalName', width: 100 },
        { header: 'PayTo', dataIndex: 'payToName', width: 80 },
        { header: 'File Name', dataIndex: 'fileName', width: 80 },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('CompList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Comp Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove Comp', 
                          'Are you sure you want to delete '+rs[0].data.compName+' Componenet?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            	//ajax post to remove
                            	
                            		Ext.Ajax.request({
                            			  url : "payoutcondition/removeComp.action",
                            			  method: 'POST',
                            			  params: {
                            				  "schemeId" : rs[0].data.schemeId,
                            				  "compId" :rs[0].data.compId
                            			    },
                            			    success: function (response) {
                             			         Ext.Msg.alert("Info","Componenet deleted Sucessfully");
                             			        componentStoreGrid.load();
                             			       componentListStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			   
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : searchcomponentStoreGrid,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.SearchCompForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.SearchCompForm',
      title   : 'Add Comp',
      //width   : 350,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [
              	{
                		xtype:'fieldset',
 					anchor: '100%',
                		title: 'Componenet Details',
 				//	 bodyStyle:'padding:5px 5px 5px',
                		collapsible: true,
                		layout: 'column',
                		defaults: {
                			anchor: '100%'
                				},
                				items :[
                				        	{
                				        		xtype: 'container',
                				        		columnWidth:.5,
                				        		layout: 'anchor',
 										//	 bodyStyle:'padding:5px 5px 5px',
    
                				        		items:[
                				        		       
                				        		       {
                				        		    	   xtype :'textfield',
                				        		    	   fieldLabel: 'Comp Name*',
                				        		    	   name: 'compName',
                				        		    	   maxLength : 100,
                				   							enforceMaxLength:"true",
                				        		    	   allowBlank:false
                				        		       },
                				        		       {
                				        		    	   xtype :'datefield',
                				        		    	   fieldLabel: 'Start Date*',
                				        		    	   name: 'startDate',
                				        		    	   //minValue: new Date(),
                				        		    	   editable: false,
                				        		    	   allowBlank:false,
                				        		    	   value:new Date()
                				        		       },
                				        		       
                				        		       {
                				        		    	   xtype :'datefield',
                				        		    	   fieldLabel: 'End Date*',
                				        		    	   name: 'endDate',
                				        		    	  // minValue: new Date(),
                				        		    	   allowBlank:false,
                				        		    	   editable: false,
                				        		    	   value:new Date()
                				        		       },
            		
                				        		       {
 														xtype :'combo',
 														fieldLabel: 'Payout Freq*',
 														name:'freqId',
 														displayField:'description',
 														valueField:'freqId',
 														editable: false,
 														allowBlank:false,
 														store: freqStore,
 														triggerAction:'all'
 													}
                				        		       ]
                				        	},
                				        	{
                				                xtype: 'container',
                				                columnWidth:.5,
                				                layout: 'anchor',
                				                items: [
                				                       
 													
 													{
 														xtype :'combo',
 														fieldLabel: 'Vertical*',
 														name:'verticalId',
 														displayField:'verticalName',
 														valueField:'verticalId',
 														editable: false,
 														allowBlank:false,
 														store: verticalStore,
 														triggerAction:'all'
 													},
 													
 													{
 														xtype :'combo',
 														fieldLabel: 'Pay To*',
 														name:'payTo',
 														displayField:'displayValue',
 														valueField:'entityTypeId',
 														editable: false,
 														allowBlank:false,
 														store: payToStore,
 														triggerAction:'all'
 													},
 													
 													{
 														xtype :'combo',
 														fieldLabel: 'Upload List*',
 														name:'uploadId',
 														editable: false,
 														displayField:'uploadName',
 														allowBlank:false,
 														valueField:'uploadId',
 														store: CreateUploadList(),
 														listeners: {
 															'select': function(combo, value){
 															
 															if(combo.getValue()==1)
 																{
 																
 																this.up('window').down('form').getForm().findField("coverageFlag").enable();
 																this.up('window').down('form').getForm().findField("fileName").enable();
 																//this.up('window').down('form').getForm().findField("fileUpload").enable();
 																}
 															else
 																{
 																this.up('window').down('form').getForm().findField("coverageFlag").disable();
 																this.up('window').down('form').getForm().findField("fileName").disable();
 															//	this.up('window').down('form').getForm().findField("fileUpload").disable();
 																}
 															
 															}
 															},
 														triggerAction:'all'
 													},
 													
 													{
 														xtype :'combo',
 														fieldLabel: 'List Type',
 														name:'coverageFlag',
 														displayField:'covFlag',
 														valueField:'listId',
 														store: uploadStore,
 														triggerAction:'all'
 													},
 													
 													{
 	               				        		    	   xtype :'textfield',
 	               				        		    	   fieldLabel: 'File Name',
 	               				        		    	   name: 'fileName',
 	               				        		    	   allowBlank:false
 	               				        		    },
													{
 	               				                    xtype: 'fileuploadfield',
 	               				                    name: 'fileUpload',
 	               				                    hidden : true,
	               				                    disabled : true,
 	               				                    emptyText: 'Select a document to upload...',
 	               				                    fieldLabel: 'File',
 	               				                    buttonText: 'Upload'
													}
                				                        
                				                       ]
                				            }
                				        
                				        
                				        ]}
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add',
    	  				
                	},
                	
                	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.SearchCompCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['SearchCompList', 'SearchCompForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'SearchCompForm',
      selector: 'SearchCompForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'SearchCompList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'SearchCompList': {
          itemdblclick: this.onRowdblclick
        },
        'SearchCompForm button[action=add]': {
          click: this.doAddComp
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	
    	
    	  var win = this.getFormWindow();
          win.setTitle('Edit Component');
          compId = record.data.compId;
          schemeId  = record.data.schemeId;
          win.down('form').getForm().findField('freqId').setValue(freqStore.findRecord('description',record.data.freqName));
          win.down('form').getForm().findField('verticalId').setValue(verticalStore.findRecord('verticalName',record.data.verticalName));
          win.down('form').getForm().findField('payTo').setValue(payToStore.findRecord('displayValue',record.data.payToName));
         // win.down('form').getForm().findField('payTo').setValue(payToStore.findRecord('displayValue',record.data.payToName));

           if(record.data.fileName==null)
        {
        	      win.down('form').getForm().findField('uploadId').setValue(CreateUploadList().findRecord('uploadName','NO'));
        	      win.down('form').getForm().findField("coverageFlag").disable();
           	   win.down('form').getForm().findField("fileName").disable();
           	//win.down('form').getForm().findField("fileUpload").disable();
        }
           else
           	{
        	   win.down('form').getForm().findField("coverageFlag").enable();
        	   win.down('form').getForm().findField("fileName").enable();
        	//   win.down('form').getForm().findField("fileUpload").enable();
         	      win.down('form').getForm().findField('uploadId').setValue(CreateUploadList().findRecord('uploadName','YES'));
        	      win.down('form').getForm().findField('coverageFlag').setValue(uploadStore.findRecord('covFlag',record.data.coverageFlag));

         	      
           	}
        	   
          win.setAction('edit');
          win.setRecordIndex(record.data.compId);
          win.down('form').getForm().setValues(record.getData());
          win.show();
    },
    showAddForm: function () {
    	if(SchemeName!=null)
		{
      var win = this.getFormWindow();
      win.setTitle(SchemeName);
      win.setAction('add');
      win.down('form').getForm().reset();
      win.show();
		}
    	else{
    		Ext.Msg.alert('Info', "Please create scheme first");	
    	}
    },
    doAddComp: function () {
      var win = this.getFormWindow();
      var action = win.getAction();
      if(action == 'edit') {
    	 
    	  if(win.down('form').isValid())
		  	{
    		  updateComp(win);
		  	}
		  	else
		  	{
		  		Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
    	  
    	    
      }
      else {
    	  
    		  	if(win.down('form').isValid())
    		  	{
    		  		saveComp(win);
    		  	}
    		  	else
    		  	{
    		  		Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
    		  	}
    	 
  		}
  
    }
  });
   
});
Ext.onReady(function () {
	Ext.define('Scheme.model.Ea', {
	    extend: 'Ext.data.Model',
	    fields: [
	      {name: 'compId', type: 'int'},
	      {name: 'compName',  type: 'string'},
	      {name: 'condId', type: 'int'},
	      {name: 'variableName',  type: 'string'}
	      
	    ]
	  });
 
	
   
 
   Ext.define('Scheme.view.SeaList', {
    extend: 'Ext.grid.Panel',
    name:'seaGrid',
    pageSize : 5,
    alias: 'widget.SeaList',
    title: 'Ea List',
    store: seaStore,
    height:300,
    //layout:'fit',
    autoScroll: true,
  //  store : 'Companies',
    initComponent: function () {
      this.tbar = [{
        text    : 'Add EA',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
        { header: 'compId', dataIndex: 'compId', width: 60 },
        { header: 'variableId', dataIndex: 'variableId', width: 60 },
        //{ header: 'compName', dataIndex: 'compName', flex: 1 },
        { header: 'variableName', dataIndex: 'variableName', flex: 1  },
        { header: 'DataSet', dataIndex: 'dataSetName', flex: 1  },
        { header: 'Entity', dataIndex: 'entityTypeName', width: 60 },
        { header: 'DataSource', dataIndex: 'dataSourceName', width: 60 },
        { header: 'Function', dataIndex: 'functionName', width: 60 },
        { header: 'parameter', dataIndex: 'parameter', width: 60 },
        { header: 'oprName', dataIndex: 'oprName', width: 60 },
        { header: 'valueType', dataIndex: 'valueType', width: 60 },
        { header: 'value', dataIndex: 'value', width: 60 },
        { header: 'startDate', dataIndex: 'startDate', width: 60 },
        { header: 'endDate', dataIndex: 'endDate', width: 60 },
        { header: 'updateDate', dataIndex: 'updateDate', width: 60 },
        { header: 'insertDate', dataIndex: 'insertDate', width: 60 },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('EaList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Ea Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove EA', 
                          'Are you sure you want to delete EA?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            	//ajax post to remove
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removeEa.action',
                            			  method: 'POST',
                            			  params: {
                            				  "compId" : rs[0].data.compId,
                            				  "condId" :rs[0].data.variableId
                            			    },
                            			    success: function (response) {
                             			         Ext.Msg.alert("Info","EA deleted Sucessfully");
                             			        schemeStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : seaStore,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.SeaForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.SeaForm',
      title   : 'Add EA',
      //width   : 350,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [
										{
            xtype: 'fieldset',
            anchor: '100%',
            title: 'Entity Details',
            collapsible: true,
            layout:'column',
            items:[
					{
				    xtype: 'container',
				    columnWidth:.2,
				    layout: 'anchor',
				    items: [
								{
									xtype :'combo',
									fieldLabel: 'Component',
									name:'compId',
									displayField:'compName',
									valueField:'compId',
									store: componentListStore,
									triggerAction:'all'
								} ,
								{
									xtype :'textfield',
									fieldLabel: 'Variable Name',
									allowBlank:false,
									name:'variableName',
								},
								{
									xtype :'combo',
									allowBlank:false,
									editable: false,
									fieldLabel: 'Data Set',
									name:'dataSet',
									displayField:'dataSetName',
									valueField:'dataSetId',
									store: dataSetStoreEa,
									triggerAction:'all'
								},
								{
									xtype :'combo',
									fieldLabel: 'Entity',
									allowBlank:false,
									editable: false,
									name:'entityType',
									displayField:'entityName',
									valueField:'entityId',
									store: entityStoreEa,
									triggerAction:'all'
								},
								{
									xtype :'combo',
									allowBlank:false,
									editable: false,
									fieldLabel: 'Data Source',
									name:'dataSource',
									displayField:'dataSourceName',
									valueField:'dataSourceId',
									store: dataSourceStoreEa,
									triggerAction:'all'
								}
				            
				           ]
					},
				                   
                   {
                xtype: 'container',
                columnWidth:.3,
                layout: 'anchor',
                items: [
							
							
							{
								xtype :'combo',
								editable: false,
								fieldLabel: 'Function',
								name:'function',
								displayField:'functionName',
								valueField:'functionId',
								store: functionStoreEa,
								triggerAction:'all'
							},
							
							{
								xtype :'combo',
								fieldLabel: 'Parameter',
								editable: false,
								name:'parameter',
								displayField:'dataSetName',
								valueField:'dataSetName',
								store: dataSetStore,
								triggerAction:'all'
							},	
							
							{
								xtype :'combo',
								fieldLabel: 'OPR',
								editable: false,
								name:'opr',
								displayField:'oprName',
								valueField:'oprId',
								store: oprStoreEa,
								triggerAction:'all'
							},
							{
								xtype :'combo',
								fieldLabel: 'Value Type',
								editable: false,
								name:'valueType',
								displayField:'valueTypeName',
								valueField:'valueTypeName',
								store: valueTypeStoreEa,
								triggerAction:'all'
							},
							
							{
								xtype :'textfield',
								fieldLabel: 'Value',
								name:'value'
							},
							{
		        		    	   xtype :'datefield',
		        		    	   fieldLabel: 'Start Date',
		        		    	   //minValue: new Date(),
		        		    	   editable: false,
		        		    	   name:'startDate',
		        		    	   value:new Date()
		        		    },
		        		    {
		        		    	   xtype :'datefield',
		        		    	   fieldLabel: 'End Date',
		        		    	   //minValue: new Date(),
		        		    	   editable: false,
		        		    	   name:'endDate',
		        		    	   value:new Date()
		        		    }
                       ]
            }
            ]
        }
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add',
    	  				
                	},
                	
                	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.SeaCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['SeaList', 'SeaForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'SeaForm',
      selector: 'SeaForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'SeaList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'SeaList': {
          itemdblclick: this.onRowdblclick
        },
        'SeaForm button[action=add]': {
          click: this.doAddEa
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	
    	console.log(record.data);
    	var win = this.getFormWindow();
   	 compIdEa = record.data.compId;
   	 condIdEa = record.data.variableId;
   	 minDateEnd =record.data.endDate;
   		 minDateStart = record.data.startDate;
   	     // win.down('form').getForm().findField('endDate').minValue = new Date(record.data.endDate);
   	     // win.down('form').getForm().findField('startDate').minValue = new Date(record.data.startDate);


     
     win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compName',record.data.compName));
     win.down('form').getForm().findField('dataSet').setValue(dataSetStoreEa.findRecord('dataSetName',record.data.dataSetName));
     win.down('form').getForm().findField('entityType').setValue(entityStoreEa.findRecord('entityName',record.data.entityTypeName));
     win.down('form').getForm().findField('dataSource').setValue(dataSourceStoreEa.findRecord('dataSourceName',record.data.dataSourceName));
     win.down('form').getForm().findField('function').setValue(functionStoreEa.findRecord('functionName',record.data.functionName));
     win.down('form').getForm().findField('parameter').setValue(parameterStoreEa.findRecord('paramName',record.data.parameter));
     win.down('form').getForm().findField('opr').setValue(oprStoreEa.findRecord('oprName',record.data.oprName)); 
     win.down('form').getForm().findField('valueType').setValue(valueTypeStoreEa.findRecord('valueTypeName',record.data.valueType));
     
     win.setTitle('Edit EA');
     win.setAction('edit');
    // win.setRecordIndex(record.data.schemeINputId);
     win.down('form').getForm().setValues(record.getData());
     win.show();
    },
    showAddForm: function () {
    	
    	if(compName!=null)
		{
    		var win = this.getFormWindow();
    	      win.setTitle(SchemeName);
    	      win.setAction('add');
    	      win.down('form').getForm().reset();
    	      win.show();
		}
    	else{
    		Ext.Msg.alert('Info', "Please create componenet for scheme first");	
    	}	
      
    },
    doAddEa: function () {
      var win = this.getFormWindow();
      var action = win.getAction();
      if(action == 'edit') {
    	  if(win.down('form').isValid())
		  	{
    		  updateEa(win);
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}  
      }
      else {
    	  if(win.down('form').isValid())
		  	{
    		  saveEa(win);
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
    	 
      }
    
    }
  });
 
  
   
});
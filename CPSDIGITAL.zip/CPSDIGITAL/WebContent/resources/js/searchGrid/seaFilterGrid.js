Ext.onReady(function () {
	Ext.define('Scheme.model.EaFilter', {
	    extend: 'Ext.data.Model',
	    fields: [
	             {name: 'compId', type: 'int'},
	             {name: 'compName',  type: 'string'},
	             {name: 'condId', type: 'int'},
	             {name: 'variableName',  type: 'string'},
	             {name: 'variableRowId', type: 'int'},
	             {name: 'value',  type: 'string'}
	   
	    ]
	  });
 
	
   
	
   
 
   Ext.define('Scheme.view.SeaFilterList', {
    extend: 'Ext.grid.Panel',
    name:'seaFilterGrid',
    pageSize : 5,
    alias: 'widget.SeaFilterList',
    title: 'Ea_Filter List',
    store: seaFilterStore,
    height:300,
    //layout:'fit',
    autoScroll: true,
  //  store : 'Companies',
    initComponent: function () {
      this.tbar = [{
        text    : 'Add EA_Filter',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
        { header: 'compId', dataIndex: 'compId', width: 60 },
       // { header: 'compName', dataIndex: 'compName', flex: 1 },
        { header: 'compId', dataIndex: 'compId', width: 60 },
        { header: 'variableName', dataIndex: 'variableName', flex: 1  },
        { header: 'variableRowId', dataIndex: 'variableRowId', width: 60 },
        { header: 'dataSetName', dataIndex: 'dataSetName', width: 60 },
        { header: 'parameter', dataIndex: 'parameter', width: 60 },
        { header: 'oprName', dataIndex: 'oprName', width: 60 },
        { header: 'valueType', dataIndex: 'valueType', width: 60 },
        { header: 'value', dataIndex: 'value', width: 80  },
        { header: 'startDate', dataIndex: 'startDate', width: 60 },
        { header: 'endDate', dataIndex: 'endDate', width: 60 },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('EaFilterList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Region Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove EA Filter', 
                          'Are you sure you want to delete EA Filter?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            	//ajax post to remove
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removeEaFilter.action',
                            			  method: 'POST',
                            			  params: {
                            				  "compId" : rs[0].data.compId,
                            				  "variableId" :rs[0].data.variableId,
                            				  "variableRowId" :rs[0].data.variableRowId
                            			    },
                            			    success: function (response) {
                             			       // var jsonResp = Ext.util.JSON.decode(response.responseText);
                             			         Ext.Msg.alert("Info"," Ea Filter deleted Sucessfully");
                             			        schemeStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			   //   var jsonResp = Ext.util.JSON.decode(response.responseText);
                            			    //  Ext.Msg.alert("Error",jsonResp.error);
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : seaFilterStore,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.SeaFilterForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.SeaFilterForm',
      title   : 'Add EAFilter',
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          anchor: '100%'
        },
        items : [
										{
            xtype: 'fieldset',
            anchor: '100%',
            title: 'Entity Details',
            collapsible: true,
            layout:'column',
            items:[
					{
				    xtype: 'container',
				    columnWidth:.2,
				    layout: 'anchor',
				    items: [
								{
									xtype :'combo',
									fieldLabel: 'Component',
									name:'compId',
									displayField:'compName',
									valueField:'compId',
									store: componentListStore,
									triggerAction:'all'
								},
								
								{
									xtype :'combo',
									fieldLabel: 'Variable',
									name:'variableId',
									displayField:'variableName',
									valueField:'variableId',
									store: eaVariableStore,
									triggerAction:'all'
								} 
				           ]
					},
				
            
            
            {
                xtype: 'container',
                columnWidth:.3,
                layout: 'anchor',
                items: [
                       
								{
									xtype :'combo',
									fieldLabel: 'Data Set',
									name:'dataSet',
									displayField:'attributeTypeName',
									valueField:'attributeTypeId',
									store: attributeTypeStore,
									triggerAction:'all'
								},
								{
									xtype :'combo',
									fieldLabel: 'Parameter',
									name:'parameter',
									displayField:'entityAttributeName',
									valueField:'entityAttributeName',
									store: entityAttrStore,
									triggerAction:'all'
								},
								{
									xtype :'combo',
									fieldLabel: 'OPR',
									name:'opr',
									displayField:'oprName',
									valueField:'oprId',
									store: oprStore,
									triggerAction:'all'
								},
								{
									xtype :'combo',
									fieldLabel: 'Value Type',
									name:'valueType',
									displayField:'valueTypeName',
									valueField:'valueTypeName',
									store: valueTypeStoreEa,
									triggerAction:'all'
								},
								
								{
									xtype :'textfield',
									fieldLabel: 'Value',
									name:'value'
									
								},
								{
									   xtype :'datefield',
									   fieldLabel: 'Start Date',
									   name:'lStartDate',
									   //minValue: new Date(),
									   editable: false,
									   value:new Date()
								},
								{
									   xtype :'datefield',
									   fieldLabel: 'End Date',
									   //minValue: new Date(),
									   editable: false,
									   name: 'lEndDate',
									   value:new Date()
								}
                        
                       ]
            }]
        }
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add'
    	  				
                	},
                	
                	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.SeaFilterCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['SeaFilterList', 'SeaFilterForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'SeaFilterForm',
      selector: 'SeaFilterForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'SeaFilterList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'SeaFilterList': {
          itemdblclick: this.onRowdblclick
        },
        'SeaFilterForm button[action=add]': {
          click: this.doEaFilter
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	console.log(record.data);
    	compId = record.data.compId;
  	  condId = record.data.variableId;
  	  condRowId = record.data.variableRowId;

      var win = this.getFormWindow();
      win.setTitle('Edit EA Filter');
      
      win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compName',record.data.compName));
      win.down('form').getForm().findField('variableId').setValue(eaVariableStore.findRecord('entityName',record.data.entityName));
      win.down('form').getForm().findField('dataSet').setValue(attributeTypeStore.findRecord('attributeTypeName',record.data.dataSetName));
      win.down('form').getForm().findField('parameter').setValue(entityAttrStore.findRecord('entityAttributeName',record.data.parameter));
      win.down('form').getForm().findField('opr').setValue(oprStore.findRecord('oprName',record.data.oprName)); 
      win.down('form').getForm().findField('valueType').setValue(valueTypeStoreEa.findRecord('valueTypeName',record.data.valueType));
      win.down('form').getForm().setValues(record.getData());
      
      win.setAction('edit');
    win.show();
    },
    showAddForm: function () {
    	
    	if(compName!=null)
		{
    		var win = this.getFormWindow();
    	      win.setTitle(SchemeName);
    	      win.setAction('add');
    	      win.down('form').getForm().reset();
    	      win.show();
		}
    	else{
    		Ext.Msg.alert('Info', "Please create entity condition for componenet first");	
    	}	
      
    },
    doEaFilter: function () {
      var win = this.getFormWindow();
      
      var action = win.getAction();
      if(action == 'edit') {
    	  if(win.down('form').isValid())
		  	{
    		  updateEaFilter(win);
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	} 
      }
      else {
    	  if(win.down('form').isValid())
		  	{
    		  saveEaFilter(win);
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
      }
    }
  });
 
  
   
});
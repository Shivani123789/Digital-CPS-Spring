Ext.onReady(function () {
	Ext.define('Scheme.model.Po', {
	    extend: 'Ext.data.Model',
	    fields: [
	      {name: 'compId', type: 'int'},
	      {name: 'compName',  type: 'string'},
	      {name: 'condId', type: 'int'},
	      {name: 'inputParameter',  type: 'string'}
	      
	    ]
	  });
 
	
   
 
   Ext.define('Scheme.view.SpoList', {
    extend: 'Ext.grid.Panel',
    name:'spoGrid',
    pageSize : 5,
    alias: 'widget.SpoList',
    title: 'Po List',
    store: spoStore,
    height:300,
    //layout:'fit',
    autoScroll: true,
  //  store : 'Companies',
    initComponent: function () {
      this.tbar = [{
        text    : 'Add PO',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
        { header: 'compId', dataIndex: 'compId', width: 40 },
      //  { header: 'compName', dataIndex: 'compName', flex: 1 },
        { header: 'condId', dataIndex: 'condId', width: 40 },
        { header: 'value', dataIndex: 'value', flex: 1  },
        { header: 'inputType', dataIndex: 'inputType', width: 80  },
        { header: 'inputParameter', dataIndex: 'inputParameter', width: 80  },
        { header: 'oprName', dataIndex: 'oprName', width: 60  },
        { header: 'valueType', dataIndex: 'valueType', width: 80  },
        { header: 'startDate', dataIndex: 'startDate', width: 80  },
        { header: 'startDate', dataIndex: 'startDate', width: 80  },
        { header: 'endDate', dataIndex: 'endDate', width: 80  },
        { header: 'updateDate', dataIndex: 'updateDate', width: 80  },
        { header: 'insertDate', dataIndex: 'insertDate', width: 80  },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('PoList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Po Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove PO', 
                          'Are you sure you want to delete Po?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            	//ajax post to remove
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removePo.action',
                            			  method: 'POST',
                            			  params: {
                            				  "compId" : rs[0].data.compId,
                            				  "condId" :rs[0].data.condId
                            			    },
                            			    success: function (response) {
                             			         Ext.Msg.alert("Info","Po deleted Sucessfully");
                             			        poStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : spoStore,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.SpoForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.SpoForm',
      title   : 'Add PO',
      //width   : 350,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [
										{
            xtype: 'fieldset',
            anchor: '100%',
            title: 'Payout Details',
            collapsible: true,
            layout:'column',
            items:[
						        	        {
			        	        	xtype: 'container',
			        	        	columnWidth:.3,
			        	        	layout: 'anchor',
			        	        	items: [
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'Component*',
			        	        	        	name:'compId',
			        	        	        	allowBlank:false,
			        	        	        	editable: false,
			        	        	        	displayField:'compName',
			        	        	        	valueField:'compId',
			        	        	        	store: componentListStore,
			        	        	        	triggerAction:'all'
			        	        	        },
{
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'Input Type',
			        	        	        //	allowBlank:false,
			        	        	        	editable: false,
			        	        	        	name:'inputType',
			        	        	        	displayField:'inputType',
			        	        	        	valueField:'inputType',
			        	        	        	store:inputTypeStorePO,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			if(combo.getValue()==2)
			        	        	        			{
			        	        	        				freeTextDataType='N';
			        	        	        			}
			        	        	        			else
			        	        	        			{
			        	        	        				freeTextDataType='L';
			        	        	        			}
			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'Input Parameter',
			        	        	        	name:'inputParameter',
			        	        	        	editable: false,
			        	        	        	displayField:'description',
			        	        	        	valueField:'description',
			        	        	        	store: inputParameterStore,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			this.up('window').down('form').getForm().findField("opr").allowBlank=false;
			        	        	        		}
			        	        	        	},

			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'OPR',
			        	        	        	editable: false,
			        	        	        	name:'opr',
			        	        	        	displayField:'oprName',
			        	        	        	valueField:'oprId',
			        	        	        	store: Po_oprStore,
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'Value Type',
			        	        	        	editable: false,
			        	        	        	name:'valueType',
			        	        	        	displayField:'valueTypeName',
			        	        	        	valueField:'valueTypeName',
			        	        	        	store: valueTypeStorePO,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			if(combo.getValue()==5)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("startDate").allowBlank=false;
			        	        	        				this.up('window').down('form').getForm().findField("endDate").allowBlank=false;

			        	        	        			}
			        	        	        			else
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("value").allowBlank=false;
			        	        	        			}
			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },


			        	        	        {
			        	        	        	xtype :'textfield',
			        	        	        	fieldLabel: 'Value',
			        	        	        	name:'value',
			        	        	        	listeners:{
			        		                        'change': function(field, newValue, oldValue){
			        		                            field.setValue(newValue.toUpperCase());
			        		                        }
			        		                     }
			        	        	        },
			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'Start Date',
			        	        	        	editable: false,
			        	        	        	// minValue: new Date(),
			        	        	        	name:'startDate',
			        	        	        //	value:new Date()
			        	        	        },
			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'End Date',
			        	        	        	// minValue: new Date(),
			        	        	        	editable: false,
			        	        	        	name:'endDate',
			        	        	        //	value:new Date()
			        	        	        }											

			        	        	        ]
			        	        },

			        	        {
			        	        	xtype: 'container',
			        	        	columnWidth:.2,
			        	        	//id:'fieldList',
			        	        	layout: 'anchor',
			        	        	items: [
			        	        	        
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'LOPR',
			        	        	        	editable: false,
			        	        	        	name:'lopr',
			        	        	        	displayField:'oprName',
			        	        	        	valueField:'oprId',
			        	        	        	store: RoprStore,
												listeners: {
										'select': function(combo, value){
										
											if((combo.getValue()==1) || (combo.getValue()==2))
											 {
											 this.up('window').down('form').getForm().findField("grossNet").disable();
											 this.up('window').down('form').getForm().findField("unit").disable();
											  this.up('window').down('form').getForm().findField("amount").disable();
											  this.up('window').down('form').getForm().findField("variable").disable();
											 this.up('window').down('form').getForm().findField("overAch").disable();
											  this.up('window').down('form').getForm().findField("underAch").disable();
											 
											 }
										 else
										 {
										 this.up('window').down('form').getForm().findField("grossNet").enable();
											 this.up('window').down('form').getForm().findField("unit").enable();
											  this.up('window').down('form').getForm().findField("amount").enable();
											  this.up('window').down('form').getForm().findField("variable").enable();
											 this.up('window').down('form').getForm().findField("overAch").enable();
											  this.up('window').down('form').getForm().findField("underAch").enable();
											 

										 }
									  }
									 },
												
			        	        	        	triggerAction:'all'
			        	        	        }
			        	        	    
			        	        	        ]
			        	        },
								
								{
			        	        	xtype: 'container',
			        	        	columnWidth:.3,
			        	        	//id:'fieldList',
			        	        	layout: 'anchor',
			        	        	items: [
			        	        	        
			        	        	        {
									xtype :'combo',
									fieldLabel: 'Gross/Net',
									name:'grossNet',
									allowBlank:false,
			        		    	editable: false,
									displayField:'name',
									valueField:'name',
									store: CreateGrossNetStore(),
									triggerAction:'all'
								},
								{
									xtype :'combo',
									fieldLabel: 'Unit',
									name:'unit',
									allowBlank:false,
			        		    	editable: false,
									displayField:'unitName',
									valueField:'unitId',
									store: unitStore,
									triggerAction:'all'
								},
								
								{
									xtype :'numberfield',
									fieldLabel: 'Amount',
									allowBlank:false,
			        		    	
									name:'amount'
									
								},
								{
									xtype :'combo',
									fieldLabel: 'Variable',
									name:'variable',
									allowBlank:false,
			        		    	editable: false,
									displayField:'variableName',
									valueField:'variableName',
									store: poFilterVariables,
									triggerAction:'all'
								},
								{
									xtype :'numberfield',
									fieldLabel: 'OverAchivement Cap',
									name:'overAch'
									
								},
								{
									xtype :'numberfield',
									fieldLabel: 'UnderAchivement Cap',
									name:'underAch'
									
								}			        	        	    
			        	        	        ]
			        	        }


           
           ]
        }
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add'
    	  				
                	},
                	
                	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.SpoCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['SpoList', 'SpoForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'SpoForm',
      selector: 'SpoForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'SpoList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'SpoList': {
          itemdblclick: this.onRowdblclick
        },
        'SpoForm button[action=add]': {
          click: this.doAddPo
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	//console.log(record.data);
    	poCompId = record.data.compId;
    	poCondId = record.data.condId;
      var win = this.getFormWindow();
      win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compId',record.data.compId));
      win.down('form').getForm().findField('inputType').setValue(inputTypeStore.findRecord('attributeTypeName',record.data.inputType));
      win.down('form').getForm().findField('inputParameter').setValue(inputParameterStore.findRecord('description',record.data.inputParameter));
      win.down('form').getForm().findField('opr').setValue(oprStore.findRecord('oprName',record.data.oprName));
      win.down('form').getForm().findField('valueType').setValue(valueTypeStorePO.findRecord('valueTypeName',record.data.valueType));

      win.setTitle('Edit Po');
      win.setAction('edit');
      win.setRecordIndex(record.data.condId);
      win.down('form').getForm().setValues(record.getData());
      win.show();
    },
    showAddForm: function () {
    	
    	if(compName!=null)
		{
    		var win = this.getFormWindow();
    	      win.setTitle(SchemeName);
    	      win.setAction('add');
    	      win.down('form').getForm().reset();
    	      win.show();
		}
    	else{
    		Ext.Msg.alert('Info', "Please create componenet for scheme first");	
    	}	
    },
    doAddPo: function () {
      var win = this.getFormWindow();
      var action = win.getAction();
      if(action == 'edit') {
    	  if(win.down('form').isValid())
		  	{
  		  updatePo(win);
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	} 
      }
      else {
    	  if(win.down('form').isValid())
		  	{
    		  savePo(win);
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
    	 
      }
    
    }
  });
 
  
   
});
Ext.onReady(function () {

	var store=vtopUpOTFSubStore();	
	var vtopupstore=sentToVtopUpStore();
var payTo = null;
var paymentType = null;	
var startDateVtop = null;
endDateVtop = null;

	function download(csvType)
	{

		var grid = Ext.ComponentQuery.query('VtopList')[0];
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		Ext.Msg.confirm('Download Scheme', 
				'Download Payout Scheme CSV', 
				function (button) {
			if (button == 'yes') {
				var urlParam = './csv/payoutDownloadCSV.action?schemeId='+rs[0].data.schemeINputId +
				'&compId='+rs[0].data.compId+'&csvType='+csvType;
				window.open(urlParam,'_SELF'); 
			}
		});
	}

var vtopUpSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border: false,
		style       : 'padding-bottom: 5px',
		layout:'column',
		anchor: '100%',
		items       : [{
			xtype       : 'datefield',
			id          : 'startDateVtop',
			allowBlank  : true,
			emptyText   : 'From',
			name        : 'startDate',
			//width       : 140,
			editable    : false,
			value : new Date(date.getFullYear(), date.getMonth(), 1)
		},
		{
			xtype       : 'datefield',
			id          : 'endDateVtop',
			allowBlank  : true,
			emptyText   : 'To',
			name        : 'endDate',
			editable    : false,
			value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
		},
		
		
		{
			xtype :'combo',
			editable: false,
			allowBlank: false,
			//fieldLabel: 'Component Name*',
			name:'id',
			id:'id',
			disabled:false,
			emptyText   : 'Entity Type',
			displayField:'entityName',	
			valueField:'entityId',
			store: entityStore,
			listeners: {
				'select': function(combo, value){
					Ext.getCmp("submitButtton").disable();
					var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateVtop").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateVtop").getValue(),'Y/m/d'));
					if(flag){
						payTo = combo.getValue();
						var grid = Ext.ComponentQuery.query('VtopList')[0];
						startDateVtop = Ext.getCmp("startDateVtop").getValue();
						endDateVtop =  Ext.getCmp("endDateVtop").getValue();
						grid.store.load({params:
						{
							startDate : Ext.Date.format(startDateVtop,'d-M-y') ,
							endDate : Ext.Date.format(endDateVtop,'d-M-y'),
							filterBy : 1,
							isMaster: true,
							isStage: false,
							payTo:combo.getValue()		
						}});

						vtopupstore.clearFilter();
						vtopupstore.filter("type",2);

						if((combo.getValue()==10) ||((combo.getValue()==8)))
						{
							vtopupstore.clearFilter();
						}
						else if((combo.getValue()==9))
						{
						    vtopupstore.clearFilter();
   							vtopupstore.filter(function(rec)
						        {		
						            var val=rec.get('type');
						            return val!='1';
						        });
						}
						Ext.getCmp("vtopup").reset();
					}
				}
			},
			triggerAction:'all'
		},
		
		{
			xtype :'combo',
			
			name:'vtopup',
			id: 'vtopup',
			displayField:'name',
			valueField:'id',
			forceSelection: true,
			allowBlank: false,
			editable: false,
			store: vtopupstore,
			listeners: {
				'select': function(combo, value){
					Ext.getCmp("submitButtton").enable();
					if(combo.getValue()==1)
					paymentType = 'V';
					if(combo.getValue()==2)
					paymentType = 'T';
					if(combo.getValue()==3)
					paymentType = 'O';
					if(combo.getValue()==4)
						paymentType = 'I';
				}
				},
			triggerAction:'all'
		},
		{
	    	   xtype :'textfield',
	    	   fieldLabel: 'CsrfName',
			   hidden:true,
	    	   disabled : true,
	    	   name: 'csrfPayment',
			   maxLength : 100,
	    	   allowBlank:false,
	    	   id:'testCsrfPayment'
	    },

		
		/*{
			xtype       : 'button',
			text        : 'Download All',
			handler     : function () {
				startDate = Ext.Date.format(Ext.getCmp("startDateVtop").getValue(),'d-M-y');
				endDate = Ext.Date.format(Ext.getCmp("endDateVtop").getValue(),'d-M-y');
				var grid = Ext.ComponentQuery.query('VtopList')[0];
				var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
				if(rs.length)
				{
					var schemecomp = "";
					var i = null;
					for (i = 0; i < rs.length; i++) {
						if((i+1)!=rs.length)
							schemecomp += rs[i].data.schemeINputId+"-"+rs[i].data.compId+":";
						else
							schemecomp += rs[i].data.schemeINputId+"-"+rs[i].data.compId;

					}
				}
				
				
				
				
				Ext.Ajax.request({
					//url : 'csv/downloadCSV.action',
					method: 'POST',
					waitMsg : 'Loading...',
					params: {
						"schemeId":rs[0].data.schemeINputId,
						// "compId":rs[0].data.compId,
						"csvType":'Distributor',
						"fromDate":rs[0].data.startDate,
						"toDate":	rs[0].data.endDate,
						"success" : true
					},
					success: function (response) {
						Ext.ux.mask.hide();
						//Ext.Msg.alert('Info', 'Execution Sucessfully Completed.');
						//console.log(response);
						grid.store.load({params:
						{
							startDate:	approveloadsd ,
							endDate: approveloaded,
							//filterBy:combo.getValue(),
							isMaster:false,
							isStage:true,
							condParam:'A'
						}});
					},
					failure: function (response) {
						Ext.ux.mask.hide();
						grid.store.load({params:
						{
							startDate:	approveloadsd ,
							endDate: approveloaded,
							//	filterBy:combo.getValue(),
							isMaster:false,
							isStage:true,
							condParam:'A'
						}});
						console.log(response);
					}
				});
			},
		},
		
		*/
		
		
		{
			xtype       : 'button',
			id  : 'submitButtton',
			text        : 'Submit',
			disabled : true,
			handler     : function () {
				startDate = Ext.Date.format(Ext.getCmp("startDateVtop").getValue(),'d-M-y');
				endDate = Ext.Date.format(Ext.getCmp("endDateVtop").getValue(),'d-M-y');
				var grid = Ext.ComponentQuery.query('VtopList')[0];
				var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
     
	 if(rs.length)
	 {
	
	Ext.Msg.confirm('Payment Confirmation', 
                          'Are you sure you want to do payment for all seclected scheme(s)', 
                          function (button) {
                            if (button == 'yes') {
							
							
                        
	Ext.ux.mask.show();
	
	 var schemecomp = "";
	 var i = null;
	 for (i = 0; i < rs.length; i++) {
	 
	 if((i+1)!=rs.length)
    schemecomp += rs[i].data.schemeINputId+"-"+rs[i].data.compId+":";
	else
	schemecomp += rs[i].data.schemeINputId+"-"+rs[i].data.compId;
	}
	 				Ext.Ajax.request({
					url : 'searchscheme/submitSchemePayment.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
					method: 'POST',
					
					params: {
						 "schemeId":rs[0].data.schemeINputId,
						 "compId":rs[0].data.compId,
						 "schemeComp":schemecomp,
						 "paymentType":paymentType,
						 "paymentRemarks":'Test Payment Remarks',
						 "payTo":payTo		
					
					},
					success: function (response) {
						Ext.ux.mask.hide();
						//Ext.Msg.alert('Info', 'Payment submitted successfully');
						//console.log(response);
					var jsonResp = Ext.JSON.decode(response.responseText);
						console.log(jsonResp	);
						if(jsonResp.success==false)	
						{
							Ext.Msg.alert("Error",jsonResp.errorMessage);
						}
						else
						Ext.Msg.alert("Info",jsonResp.errorMessage);

					
					grid.store.load({params:
					{
						startDate : Ext.Date.format(startDateVtop,'d-M-y') ,
						endDate : Ext.Date.format(endDateVtop,'d-M-y'),
						filterBy : 1,
						isMaster: true,
						isStage: false,
						payTo:payTo		
					}});
					
					
					},
					failure: function (response) {
						Ext.ux.mask.hide();
						grid.store.load({params:
					{
						startDate : Ext.Date.format(startDateVtop,'d-M-y') ,
						endDate : Ext.Date.format(endDateVtop,'d-M-y'),
						filterBy : 1,
						isMaster: true,
						isStage: false,
						payTo:payTo		
					}});
					
						//console.log(response);
					}
				});
	 
	 
	 
	 }
	 
	 else
	 
	 {
	 Ext.ux.mask.hide();
	 
	 }
    });
	 
	 
	 
	 }
	 
	 
	 
	 else{
	 
	 Ext.Msg.alert("Info","No Scheme Selected");
	 }
				
			
				

			},
		}
		]
	});



	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);
	Ext.define('Scheme.model.Book', {
		extend: 'Ext.data.Model',
		fields: [
		         {name: 'schemeName', type: 'string'},
		         {name: 'circleName',  type: 'string'}
		         ]
	});



	Ext.define('Scheme.store.Books', {
		extend  : 'Ext.data.Store',
		model   : 'Scheme.model.Book',
		fields  : ['title', 'author','price', 'qty'],
		data    : [
		           { title: 'JDBC, Servlet and JSP', 
		        	   author: 'Santosh Kumar', price: 300, qty : 12000 },
		        	   { title: 'Head First Java', 
		        		   author: 'Kathy Sierra', price: 550, qty : 2500 },
		        		   { title: 'Java SCJP Certification', 
		        			   author: 'Khalid Mughal', price: 650, qty : 5500 },
		        			   { title: 'Spring and Hinernate', 
		        				   author: 'Santosh Kumar', price: 350, qty : 2500 },
		        				   { title: 'Mastering C++', 
		        					   author: 'K. R. Venugopal', price: 400, qty : 1200 }
		        				   ]
	});


	
	
	Ext.define('Scheme.view.VtopList', {
		extend: 'Ext.grid.Panel',
		id:'VtopGrid',
		stripeRows: true,
		flex: 2,
		// border:false,
		hidden: false,
		// width:1120,
		height: '100%',
			layout: 'fit',
		   
		//height:600,
		bodyStyle:'padding:0px',
		loadMask: true,
		selModel : Ext.create('Ext.selection.CheckboxModel'),
		//loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		//pageSize : 5,
		alias: 'widget.VtopList',
		title: 'Scheme Payment',
		store: sentToVtopStore,
		//height:500,
		autoScroll: true,

		initComponent: function () {
			var me = this;
			this.tbar = [
			             vtopUpSearch
			             ];
			this.columns = [

			                { header: 'Scheme Id', dataIndex: 'schemeINputId', flex: 1 },
			                { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
			                { header: 'Comp Id', dataIndex: 'compId', flex: 1 },
			                { header: 'Comp Name', dataIndex: 'compName', flex: 1 },
			                { header: 'Create Date', dataIndex: 'insertTime', flex: 1 },
			                { header: 'PayTo', dataIndex: 'payTo', flex: 1 },
			                { header: 'Start Date', dataIndex: 'startDate', flex: 1 },
			                { header: 'End Date', dataIndex: 'endDate', flex: 1 },
			                { header: 'Status', dataIndex: 'schemeStatus', flex: 1 },
			                {
			                	header: 'Data',dataIndex: 'payTo', flex: 1,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		if(v!=null)
			                		{
			                			Ext.defer(function() {
			                				Ext.widget('button', {
			                					renderTo: id,
			                					text: v,
			                					scale: 'small',
			                					handler: function() {
			                						download(v);
			                					}
			                				});
			                			}, 50);
			                		}else{
			                			Ext.defer(function() {
			                				Ext.widget('button', {
			                					renderTo: id,
			                					disabled : true,
			                					text: '',
			                					scale: 'small',
			                					handler: function() {
			                					}
			                				});
			                			}, 50);
			                		}
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                }
			              ];

			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : sentToVtopStore,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		}});

	
	
	
	Ext.define('Scheme.view.VtopUpForm', {
		extend  : 'Ext.window.Window',
		alias   : 'widget.VtopUpForm',
		title   : 'Edit VtopUp',
		width   : 500,
		//height:   500,
		autoscroll:true,
		layout  : 'fit',
		resizable: false,
		closeAction: 'hide',
		modal   : true,
		config  : {
			recordIndex : 0,
			action : ''
		},
		items   : [{
			xtype : 'form',
			layout: 'anchor',
			bodyStyle: {
				background: 'none',
				padding: '10px',
				border: '0'
			},
			defaults: {
				//xtype : 'textfield',
				anchor: '100%'
			},
			items : [	          
			         {
			        	 xtype:'fieldset',
			        	 anchor: '100%',
			        	 title: 'Sent TO VTopUP',
			        	 collapsible: true,
			        	 layout: 'column',
			        	 defaults: {
			        		 anchor: '100%'
			        	 },
			        	 items :[
			        	         {
			        	        	 xtype: 'container',
			        	        	 columnWidth:.5,
			        	        	 layout: 'anchor',
			        	        	 items:[
			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'Exec Start Date',
			        	        	        	name: 'execStartDate',
			        	        	        	allowBlank:false,
			        	        	        	editable: false,
			        	        	        },
			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'Exec End Date',
			        	        	        	name: 'execEndDate',
			        	        	        	allowBlank:false,
			        	        	        	editable: false,
			        	        	        },
			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'Payout Approval Date',
			        	        	        	name: 'payoutAppDate',
			        	        	        	allowBlank:false,
			        	        	        	editable: false,
			        	        	        },
			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'Stmt Gen Date',
			        	        	        	name: 'stmGenDate',
			        	        	        	allowBlank:false,
			        	        	        	editable: false,
			        	        	        }
			        	        	        ]
			        	         }
			        	         ]}
			         ]
		}],

		buttons: [	
		          {
		        	  text    : 'Update',
		        	  handler : function () { 
		        		  this.up('window').down('form').getForm().reset(); 
		        	  }
		          },
		          {
		        	  text    : 'Reset',
		        	  handler : function () { 
		        		  this.up('window').down('form').getForm().reset(); 
		        	  }
		          },
		          {
		        	  text   : 'Cancel',
		        	  handler: function () { 
		        		  this.up('window').close();
		        	  }
		          }]
	});


	
	
	Ext.define('Scheme.controller.VtopUpCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['VtopList', 'VtopUpForm'],
		refs    : [{
			ref   : 'formWindow',
			xtype : 'ExecCalForm',
			selector: 'ExecCalForm',
			autoCreate: true
		}],
		init: function () {
			this.control({
				'VtopList': {
					itemdblclick: this.onRowdblclick
				}
			});
		},

		/*onRowdblclick: function(me, record, item, index) {

    //	alert("hiiii");
      var win = this.getFormWindow();
      win.setTitle('Edit VtopUp');
      win.setAction('edit');
      win.setRecordIndex(record.data.schemeINputId);
      win.down('form').getForm().setValues(record.getData());
     win.show();

    }
		 */

	});
});
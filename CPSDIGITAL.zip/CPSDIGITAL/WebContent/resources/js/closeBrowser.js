Ext.EventManager.on(window, 'beforeunload', function() {
//alert('cross-exit tab click AND cross-exit browser click');
});

Ext.EventManager.on(window, 'unload', function() {
//alert('cross-exit tab click');
});


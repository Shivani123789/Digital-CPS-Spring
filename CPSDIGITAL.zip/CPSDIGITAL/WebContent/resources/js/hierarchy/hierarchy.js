Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);
	var circleCode=null;
	var hierloadsd = null;
	var hierloaded = null;
	
	
	function downloadHierarchy(qualify)
	{

		var grid = Ext.ComponentQuery.query('HierarchyList')[0];
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		var urlParam;
		Ext.Msg.confirm('Hierarchy Data', 
				'Download Hierarchy CSV', 
				function (button) {
			if (button == 'yes') {
				if(qualify==='HS'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId=0' +'&compId=0'+
					'&conditionId=0'+'&qualifyType=1'+'&transSubDataType=HS'+'&paymentId=0'+'&universeId='+rs[0].data.unid+'&circleCode='+circleCode;
					window.open(urlParam,'_BLANK');
				}
			}
		});
	}
	



	var hierSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		layout	   :'column',
		anchor	   : '100%',
		items       : [	
		{
			xtype       : 'datefield',
			id          : 'startDateHS',
			allowBlank  : false,
			emptyText   : 'StartDate',
			name        : 'startDateHier',
			//width       : 140,
			editable    : false,
		},{
			xtype       : 'datefield',
			id          : 'endDateHS',
			allowBlank  : false,
			emptyText   : 'EndDate',
			name        : 'endDateHier',
			editable    : false,
		},
		{
			xtype :'combo',
        	editable: false,
        	allowBlank: false,
        	//fieldLabel: 'Component Name*',
        	name:'circle',
        	id:'circleId12',
        	disabled:false,
        	emptyText   : 'Circle',
        	displayField:'circleName',	
        	valueField:'circleCode',
			store: circleStore,
			listeners: {
				'select': function(combo, value){
					circleCode = combo.getValue();
					}
			},
			triggerAction:'all'
		},
		{
	    	   xtype :'textfield',
	    	   fieldLabel: 'CsrfName',
			   hidden:true,
	    	   disabled : true,
	    	   name: 'csrfHier',
			   maxLength : 100,
	    	   allowBlank:false,
	    	   id:'testCsrfHier'
	    },
		{
			xtype       : 'button',
			text        : 'Go',
			width       : 40,
			handler     : function () {
				 hierloadsd = Ext.Date.format(Ext.getCmp("startDateHS").getValue(),'d-M-y');
				 hierloaded = Ext.Date.format(Ext.getCmp("endDateHS").getValue(),'d-M-y');
				var grid = Ext.ComponentQuery.query('HierarchyList')[0];
				grid.store.load({params:
				{
					startDate       :	hierloadsd ,
					endDate         : 	hierloaded,
					circleCodeParam : 	circleCode,
				}});
			},
		}]
	});
	

	Ext.define('Scheme.view.HierarchyList', {
		extend: 'Ext.grid.Panel',
		id:'hierar',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:525,
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.HierarchyList',
		//title: 'Statement Generation',
		store: hierarchyGrid,
		//height:500,
		autoScroll: true,

		initComponent: function () {
			var me = this;
			this.tbar = [
			             hierSearch
			             ];
			this.columns = [
			                { header: 'Uni ID', dataIndex: 'unid', width:50},
			                { header: 'SCM/Uni Name', dataIndex: 'scm', flex: 1},
			                { header: 'Retailer', dataIndex: 'retailer', flex: 1 },
			                { header: 'DSE', dataIndex: 'dse', flex: 1 },
			                { header: 'Dist', dataIndex: 'dist', flex: 1 },
			                { header: 'Internal Sales', dataIndex: 'internalSales', flex: 1 },
			               // { header: 'Extract', dataIndex: 'extra', width:60 },
			                { header: 'Extract', width: 60,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function () {
			                			Ext.widget('image', {
			                				renderTo: id,
			                				name: 'hierRun',
			                				src : 'resources/images/book_add.png',
			                				listeners : {
			                					afterrender: function (me) {
			                						me.getEl().on('click', function() {
			                							var grid = Ext.ComponentQuery.query('HierarchyList')[0];
			                							if (grid) {
			                								var sm = grid.getSelectionModel();
			                								var rs = sm.getSelection();
			                								if (!rs.length) {
			                									Ext.Msg.alert('Info', 'No Item Selected');
			                									return;
			                								}
			                								Ext.Msg.confirm('Extract ', 
			                										'Do You want to Extract Hierarchy?', 
			                										function (button) {

			                									if (button == 'yes') {
			                										Ext.ux.mask.show(); 
			                										Ext.Ajax.request({
			                											url : 'transData/getTransExecUniverseDataSearch.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
			                											method: 'POST',
			                											timeout:60000,
			                											waitMsg : 'Loading...',
			                											params: {
			                												"inputTypeId"   : rs[0].data.unid,
	    	                				                     			 "condiParam" : 'HS',
	    	                				                     			 "startDt"     : hierloadsd,
	    	                				                     			 "endDt"     : hierloaded,
	    	                				                 				  "success"   : true
			                											},

			                											success: function (response) {
			                												Ext.ux.mask.hide();
			                												var jsonResp = Ext.JSON.decode(response.responseText);
			                												//	console.log(jsonResp); 
			                												if(jsonResp.success==false)	
			                												{
			                													Ext.Msg.alert("Error",jsonResp.errorMessage);
			                												}
			                												else
			                													Ext.Msg.alert("Info",jsonResp.errorMessage);

			                												grid.store.load({params:
			                												{
			                													startDate       :	hierloadsd,
			                													endDate         : 	hierloaded,
			                													circleCodeParam : 	circleCode,
			                												}});
			                												//console.log(response);
			                											},
			                											failure: function (response) {
			                												Ext.ux.mask.hide();

			                												var jsonResp = Ext.JSON.decode(response.responseText);
			                												//	console.log(jsonResp); 
			                												if(jsonResp.success==false)	
			                												{
			                													Ext.Msg.alert("Error",jsonResp.errorMessage);
			                												}
			                												else
			                													Ext.Msg.alert("Info",jsonResp.errorMessage);
			                											}
			                										})	;
			                									}
			                								});
			                							}
			                						});
			                					}
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                { header: 'Download',dataIndex: 'download', width: 80,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function() {
			                			Ext.widget('button', {
			                				renderTo: id,
			                				//		disabled : true,
			                				text: 'Download',
			                				scale: 'small',
			                				handler: function() {
			                					downloadHierarchy("HS");
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                //{ header: 'Missing Stamp', dataIndex: 'clear', width:60 },
			                {  header: 'Missing Stamp', width: 60,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function () {
			                			Ext.widget('image', {
			                				renderTo: id,
			                				name: 'hierRun2',
			                				src : 'resources/images/book_delete.png',
			                				listeners : {
			                					afterrender: function (me) {
			                						me.getEl().on('click', function() {
			                							var grid = Ext.ComponentQuery.query('HierarchyList')[0];
			                							if (grid) {
			                								var sm = grid.getSelectionModel();
			                								var rs = sm.getSelection();
			                								if (!rs.length) {
			                									Ext.Msg.alert('Info', 'No Item Selected');
			                									return;
			                								}
			                								Ext.Msg.confirm('Execute ', 
			                										'Do You want to Execute Missing Stamp?', 
			                										function (button) {

			                									if (button == 'yes') {
			                										Ext.ux.mask.show(); 
			                										Ext.Ajax.request({
			                											url : 'admin/getExecHierarchyStamp.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
			                											method: 'POST',
			                											timeout:60000,
			                											waitMsg : 'Loading...',
			                											params: {
			                												"unid"   : rs[0].data.unid,
	    	                				                     			 "condiParam" : 'HS',
	    	                				                     			 "startDt"     : hierloadsd,
	    	                				                     			 "endDt"     : hierloaded,
	    	                				                     			 "qualifyType" : 1,
	    	                				                 				  "success"   : true
			                											},

			                											success: function (response) {
			                												Ext.ux.mask.hide();
			                												var jsonResp = Ext.JSON.decode(response.responseText);
			                												//	console.log(jsonResp); 
			                												if(jsonResp.success==false)	
			                												{
			                													Ext.Msg.alert("Error",jsonResp.errorMessage);
			                												}
			                												else
			                													Ext.Msg.alert("Info",jsonResp.errorMessage);

			                												grid.store.load({params:
			                												{
			                													startDate       :	hierloadsd,
			                													endDate         : 	hierloaded,
			                													circleCodeParam : 	circleCode,
			                												}});
			                												//console.log(response);
			                											},
			                											failure: function (response) {
			                												Ext.ux.mask.hide();

			                												var jsonResp = Ext.JSON.decode(response.responseText);
			                												//	console.log(jsonResp); 
			                												if(jsonResp.success==false)	
			                												{
			                													Ext.Msg.alert("Error",jsonResp.errorMessage);
			                												}
			                												else
			                													Ext.Msg.alert("Info",jsonResp.errorMessage);
			                											}
			                										})	;
			                									}
			                								});
			                							}
			                						});
			                					}
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                //{ header: 'Re-Stamp', dataIndex: 'reStamp', width:60 },
			                {  header: 'Re-Stamp', width: 60,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function () {
			                			Ext.widget('image', {
			                				renderTo: id,
			                				name: 'hierRun3',
			                				src : 'resources/images/book_edit.png',
			                				listeners : {
			                					afterrender: function (me) {
			                						me.getEl().on('click', function() {
			                							var grid = Ext.ComponentQuery.query('HierarchyList')[0];
			                							if (grid) {
			                								var sm = grid.getSelectionModel();
			                								var rs = sm.getSelection();
			                								if (!rs.length) {
			                									Ext.Msg.alert('Info', 'No Item Selected');
			                									return;
			                								}
			                								Ext.Msg.confirm('Execute ', 
			                										'Do You want to Execute Re-Stamp?', 
			                										function (button) {

			                									if (button == 'yes') {
			                										Ext.ux.mask.show(); 
			                										Ext.Ajax.request({
			                											url : 'admin/getExecHierarchyStamp.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
			                											method: 'POST',
			                											timeout:60000,
			                											waitMsg : 'Loading...',
			                											params: {
			                												"unid"   : rs[0].data.unid,
	    	                				                     			 "condiParam" : 'HS',
	    	                				                     			 "startDt"     : hierloadsd,
	    	                				                     			 "endDt"     : hierloaded,
	    	                				                     			 "qualifyType" : 2,
	    	                				                 				  "success"   : true
			                											},

			                											success: function (response) {
			                												Ext.ux.mask.hide();
			                												var jsonResp = Ext.JSON.decode(response.responseText);
			                												//	console.log(jsonResp); 
			                												if(jsonResp.success==false)	
			                												{
			                													Ext.Msg.alert("Error",jsonResp.errorMessage);
			                												}
			                												else
			                													Ext.Msg.alert("Info",jsonResp.errorMessage);

			                												/*grid.store.load({params:
			                												{
			                													startDate       :	hierloadsd,
			                													endDate         : 	hierloaded,
			                													circleCodeParam : 	circleCode,
			                												}});*/
			                												//console.log(response);
			                											},
			                											failure: function (response) {
			                												Ext.ux.mask.hide();

			                												var jsonResp = Ext.JSON.decode(response.responseText);
			                												//	console.log(jsonResp); 
			                												if(jsonResp.success==false)	
			                												{
			                													Ext.Msg.alert("Error",jsonResp.errorMessage);
			                												}
			                												else
			                													Ext.Msg.alert("Info",jsonResp.errorMessage);
			                											}
			                										})	;
			                									}
			                								});
			                							}
			                						});
			                					}
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : hierarchyGrid,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		},
	});


	Ext.define('Scheme.controller.HierarchyCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['HierarchyList'],
	});



});
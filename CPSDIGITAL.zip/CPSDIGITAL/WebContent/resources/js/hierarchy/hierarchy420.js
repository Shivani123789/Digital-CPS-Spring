Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);


	function downloadMismatch()
	{

		var grid = Ext.ComponentQuery.query('HierarchyList1')[0];
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		var urlParam;
		Ext.Msg.confirm('Hierarchy Mismatch', 
				'Download Hierarchy Mismatch CSV', 
				function (button) {
			if (button == 'yes') {
					urlParam = './csv/hierarchyMismatchDownloadCSV.action?csvType='+Ext.getCmp("sdsin").getValue() +'&toDate='+rs[0].data.hierarchyDate +
					'&circleCode='+Ext.getCmp("circleId122").getValue();
					window.open(urlParam,'_BLANK');
				//urlParam =  "dt::"+rs[0].data.hierarchyDate 
				//+"cir ::"+Ext.getCmp("circleId122").getValue()+"sdsin::"+ Ext.getCmp("sdsin").getValue();
				//alert("dt"+rs[0].data.hierarchyDate+urlParam);
			}
		});
	}

	var hierSearch1 = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		layout	   :'column',
		anchor	   : '100%',
		items       : [	
		{
			xtype       : 'datefield',
			id          : 'startDateHS2',
			allowBlank  : false,
			emptyText   : 'StartDate',
			name        : 'startDateHier',
			//width       : 140,
			editable    : false,
		},{
			xtype       : 'datefield',
			id          : 'endDateHS2',
			allowBlank  : false,
			emptyText   : 'EndDate',
			name        : 'endDateHier',
			editable    : false,
		},
		{
			xtype :'combo',
        	editable: false,
        	allowBlank: false,
        	//fieldLabel: 'Component Name*',
        	name:'circle',
        	id:'circleId122',
        	disabled:false,
        	emptyText   : 'Circle',
        	displayField:'circleName',	
        	valueField:'circleCode',
			store: circleStore,
			listeners: {
				'select': function(combo, value){
				//	circleCode = combo.getValue();
					}
			},
			triggerAction:'all'
		}, 
		{
			xtype       : 'combo',
		    id          : 'sdsin',
			displayField:'type',
			valueField:'id',
			allowBlank  : true,
			name        : 'filterBy2',
			emptyText   : 'Hierarchy Type',
			//width       : 140,
			editable    : false,
			store: hierarchyMismatchStore(),
			triggerAction:'all'
	       },
		{
			xtype       : 'button',
			text        : 'Go',
			width       : 40,
			handler     : function () {
				// hierloadsd = Ext.Date.format(Ext.getCmp("startDateHS").getValue(),'d-M-y');
				// hierloaded = Ext.Date.format(Ext.getCmp("endDateHS").getValue(),'d-M-y');
				//alert(Ext.Date.format(Ext.getCmp("startDateHS2").getValue(),'d-M-y') +"\t"+Ext.Date.format(Ext.getCmp("endDateHS2").getValue(),'d-M-y')+
				//		"\t"+Ext.getCmp("circleId122").getValue()+"\t"+Ext.getCmp("sdsin").getValue());
				
				var grid = Ext.ComponentQuery.query('HierarchyList1')[0];
				grid.store.load({params:
				{
					"startDate"       :	Ext.Date.format(Ext.getCmp("startDateHS2").getValue(),'d-M-y') ,
					"endDate"         : Ext.Date.format(Ext.getCmp("endDateHS2").getValue(),'d-M-y'),
					"circleCodeParam" : Ext.getCmp("circleId122").getValue(),
					"typeParam" 	  : Ext.getCmp("sdsin").getValue(),
					
				}});
			},
		}]
	});
	

	Ext.define('Scheme.view.HierarchyList1', {
		extend: 'Ext.grid.Panel',
		id:'hierar',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:525,
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.HierarchyList1',
		//title: 'Statement Generation',
		store: hierarchyGrid2,
		//height:500,
		autoScroll: true,
		// resizable: false,
	    // fixed: true,
		initComponent: function () {
			var me = this;
			this.tbar = [
			             hierSearch1
			             ];
			this.columns = [
			                { header: 'System Involved', dataIndex: 'systemsInvolved',  width: 90},
			                { header: 'Hier Date', dataIndex: 'hierarchyDate',  width: 70},
			                { header: 'RET Mgr Mis', dataIndex: 'retMgrMismatch', width: 70},
			                { header: 'Dse Mgr Mis', dataIndex: 'dseMgrMismatch', width: 70 },
			                { header: 'Dist Mgr Mis', dataIndex: 'distMgrMismatch', width: 70 },
			                { header: 'Tsm Mgr Mis', dataIndex: 'tsmMgrMismatch', width: 70 },
			                { header: 'Asm Mgr Mis', dataIndex: 'asmMgrMismatch', width: 70 },
			                { header: 'Zbm Mgr Mis', dataIndex: 'zbmMgrMismatch',  width: 70 },
			                { header: 'Sh Mgr Mis',dataIndex: 'shMgrMismatch',  width: 70},
			                { header: 'Total Mis', dataIndex: 'totalMismatch', width: 70 },
			                { header: 'Ret 1 Missing', dataIndex: 'retMissingFirstSys',  width: 85},
			                { header: 'Ret 2 Missing', dataIndex: 'retMissingSecondSys', width: 85},
			                { header: 'Dse 1 Missing', dataIndex: 'dseMissingFirstSys',  width: 85},
			                { header: 'Dse 2 Missing', dataIndex: 'dseMissingSecondSys',  width: 85},
			                { header: 'Dist 1 Missing', dataIndex: 'distMissingFirstSys',  width: 85},
			                { header: 'Dist 2 Missing', dataIndex: 'distMissingSecondSys',  width: 85},
			                { header: 'Tsm 1 Missing', dataIndex: 'tsmMissingFirstSys',  width: 85},
			                { header: 'Tsm 2 Missing', dataIndex: 'tsmMissingSecondSys',  width: 85},
			                { header: 'Asm 1 Missing', dataIndex: 'asmMissingFirstSys',  width: 85},
			                { header: 'Asm 2 Missing', dataIndex: 'asmMissingSecondSys',  width: 85},
			                { header: 'Zbm 1 Missing', dataIndex: 'zbmMissingFirstSys',  width: 85},
			                { header: 'Zbm 2 Missing', dataIndex: 'zbmMissingSecondSys',  width: 85},
			                { header: 'Sh 1 Missing', dataIndex: 'shMissingFirstSys',  width: 85},
			                { header: 'Sh 2 Missing', dataIndex: 'shMissingSecondSys',  width: 85},
			                { header: 'Ch 1 Missing', dataIndex: 'chMissingFirstSys',  width: 85},
			                { header: 'Ch 2 Missing', dataIndex: 'chMissingSecondSys',  width: 85},
			                { header: 'Total Missing', dataIndex: 'totalMissing',  width: 85},
			                {
			                	header: 'Download',dataIndex: 'mismatch', width: 90,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function() {
			                			Ext.widget('button', {
			                				renderTo: id,
			                				//disabled : false,
			                				text: 'Download',
			                				scale: 'small',
			                				handler: function() {
			                					downloadMismatch();
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : hierarchyGrid2,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		},
	});


	Ext.define('Scheme.controller.HierarchyCon1', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['HierarchyList1'],
	});



});
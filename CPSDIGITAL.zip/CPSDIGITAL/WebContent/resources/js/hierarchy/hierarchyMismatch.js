Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);


	
	
	Ext.define('Scheme.model.Book', {
		extend: 'Ext.data.Model',
		fields: [
		         {name: 'schemeName', type: 'string'},
		         {name: 'circleName',  type: 'string'}
		         ]
	});
	
	
	var hierMisSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		layout	   :'column',
		anchor	   : '100%',
		items       : [	
		               {
			xtype       : 'datefield',
			id          : 'startDateHM',
			allowBlank  : false,
			emptyText   : 'StartDate',
			//name        : 'startDateHierM',
			//width       : 140,
			editable    : false
		},{
			xtype       : 'datefield',
			id          : 'endDateHM',
			allowBlank  : false,
			emptyText   : 'EndDate',
		//	name        : 'endDateHierM',
			editable    : false
		},
		{
			xtype :'combo',
        	editable: false,
        	allowBlank: false,
        	//fieldLabel: 'Component Name*',
        	//name:'circleM',
        	id:'circleId132',
        	disabled:false,
        	emptyText   : 'Circle',
        	displayField:'circleName',	
        	valueField:'circleCode',
			store: circleStore,
			listeners: {
				'select': function(combo, value){
					//circleCode = combo.getValue();
					}
			},
			triggerAction:'all'
		},
		               {
		            	   xtype       : 'button',
		            	   text        : 'Go',
		            	   handler     : function () {
		            		   // hierloadsd = Ext.Date.format(Ext.getCmp("startDateHS").getValue(),'d-M-y');
		            		   // hierloaded = Ext.Date.format(Ext.getCmp("endDateHS").getValue(),'d-M-y');
		            		   var grid = Ext.ComponentQuery.query('HierarchyMisList')[0];
		            		   grid.store.load({params:
		            		   {
		            			   //	startDate       :	hierloadsd ,
		            			   //	endDate         : 	hierloaded,
		            			   //	circleCodeParam : 	circleCode,
		            		   }});
		            	   },
		               }]
	});


	Ext.define('Scheme.view.HierarchyMisList', {
		extend: 'Ext.grid.Panel',
		id:'hierarmis',
		stripeRows: true,
		flex: 2,
		width:1120,
		height:540,
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.HierarchyMisList',
		//title: 'Statement Generation',
		store: hierarchyMismatchStore,
		//height:500,
		autoScroll: true,

		initComponent: function () {
		//	var me = this;
			this.tbar = [
			             hierMisSearch
			             ];
			this.columns = [
			                { header: 'System Involved', dataIndex: 'systemsInvolved', width:80},
			                { header: 'RET Mgr', dataIndex: 'retMgrMismatch', width:80 },
			                { header: 'Dse Mgr', dataIndex: 'dseMgrMismatch',  flex: 1 },
			                { header: 'Dist Mgr', dataIndex: 'distMgrMismatch', width:80},
			                { header: 'Tsm Mgr', dataIndex: 'tsmMgrMismatch', width:80},
			                { header: 'Asm Mgr', dataIndex: 'asmMgrMismatch', width:80 },
			                { header: 'Zbm Mgr', dataIndex: 'zbmMgrMismatch', width:80 },
			                { header: 'Sh Mgr', dataIndex: 'shMgrMismatch', width:80 },
			                { header: 'Total', dataIndex: 'totalMismatch', width:80 }

			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : hierarchyMismatchStore,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		},
	});


	Ext.define('Scheme.controller.HierarchyMisCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['HierarchyMisList']
	});



});
Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);

	

var hierMismatchSearch =  new Ext.Panel({     
	stripeRows  : true,
	frame       : false,
	border	   : false,
	style       : 'padding-bottom: 5px',
	layout	   :'column',
	anchor	   : '100%',
	items:[
{
	xtype:'fieldset',
	title: 'Search Hierarchy Mismatch',
	layout: 'column',
	bodyStyle:'padding:3px 0px',
	height : 110,
	collapsible: true,
	items :[
{
	xtype: 'container',
	columnWidth:.3,
	layout: 'anchor',
	items:[
{
	xtype :'combo',
	fieldLabel: 'Circle',
	name:'circleId',
	disabled: false,
	allowBlank:false,
	editable: false,
	displayField:'circleName',
	valueField:'circleId',
	store: circleStore,
	triggerAction:'all'
},
{
	xtype       : 'datefield',
	fieldLabel  : 'From Date',
	allowBlank  : true,
	emptyText   : 'Start Date',
	name        : 'fromDate',
	editable    : false,
},
]
},{
	xtype: 'container',
	columnWidth:.3,
	layout: 'anchor',
	items:[
	       {
	    	   xtype :'combo',
	    	   fieldLabel: 'SDS In',
	    	   name:'sdsin',
	    	   disabled: false,
	    	   allowBlank:true,
	    	   editable: false,
	    	   displayField:'type',
	    	   valueField:'type',
	    	   store: hierarchyMismatchStore(),
	    	   triggerAction:'all'
	       },
	       {
	    		xtype       : 'datefield',
	    		fieldLabel  : 'To Date',
	    		allowBlank  : true,
	    		emptyText   : 'End Date',
	    		name        : 'toDate',
	    		editable    : false,
	    	},
	       {
	    	   xtype:'button',
	    	   text: 'Search',
	    	   handler: function() {
	    		   //  saveCircleSchedular(circleSchedular);
	    	   }
	       },
	       {
	    	   xtype:'button',
	    	   text: 'Reset',
	    	   handler: function() {
	    		//   hierMismatch.reset();
	    	   }
	       }
	       ]}]
}
]
});




	
Ext.define('Scheme.view.HirerMismatchList', {
	extend: 'Ext.grid.Panel',
	id:'hieraMismatch1',
	stripeRows: true,
	pageSize:10,
	flex: 2,
	width:1120,
	height:540,
	//bodyStyle:'padding:3px 0px',
	hidden: false,
	loadMask: true,
	plugins: 'bufferedrenderer',
	remoteSort:true, remoteFilter :true, remoteGroup :true, 
	alias: 'widget.HirerMismatchList',
	store: hierarchyMismatchStore,
	autoScroll: true,
	
	initComponent: function () {
		var me = this;
		this.tbar = [
		             	hierMismatchSearch
		             ];
		this.columns = [
		                { header: 'System Involved', dataIndex: 'systemsInvolved', width:80},
		                { header: 'RET Mgr', dataIndex: 'retMgrMismatch', width:80 },
		                { header: 'Dse Mgr', dataIndex: 'dseMgrMismatch',  flex: 1 },
		                { header: 'Dist Mgr', dataIndex: 'distMgrMismatch', width:80},
		                { header: 'Tsm Mgr', dataIndex: 'tsmMgrMismatch', width:80},
		                { header: 'Asm Mgr', dataIndex: 'asmMgrMismatch', width:80 },
		                { header: 'Zbm Mgr', dataIndex: 'zbmMgrMismatch', width:80 },
		                { header: 'Sh Mgr', dataIndex: 'shMgrMismatch', width:80 },
		                { header: 'Total', dataIndex: 'totalMismatch', width:80 }
		                ];
		this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : hierarchyMismatchStore,
			dock : 'bottom',
			pageSize:10,
			displayInfo : true
		}];
		this.callParent(arguments);
	},
});


Ext.define('Scheme.controller.HierarchyMisCon', {
	extend  : 'Ext.app.Controller',
	stores  : ['Books'],
	views   : ['HirerMismatchList'],
});

});
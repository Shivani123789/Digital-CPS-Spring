var compName = "Yes";
var SchemeName = null;
var minDateStart = new Date();
var minDateEnd = new Date();
var formPanel = null;
var sdGridStatus = 0;
var pdGridStatus = 0;
var udGridStatus = 0;
var payoutGridStatus = 0;
var stmtGridStatus = 0;
var vstmtGridStatus = 0;
var tempGridStatus = 0;
var hieraGridStatus = 0;
var hieraMisGridStatus = 0;
var scmDAGridStatus = 0;
var rstmtGridStatus = 0;
var holdGridStatus = 0;
var releGridStatus = 0;

var condRowIdCov = null;
var condRowIdTq = null;
var condRowIdPo = null;
var detailcond;
var detailcondcov;
var detailcondpo;
var condBody = '';
var condBodyPo = '';
var condBodyTq = '';
var date = new Date();
var updateFlagCov = 'Yes';
var updateFlagTq = 'Yes';

var schemePeriodStore = new Ext.data.JsonStore({
	idProperty : 'stmtCycleId',
	autoLoad : false,
	xtype : 'jsonstore',
	mode : 'local',
	totalProperty : 'stmtCycleId',
	fields : [ 'stmtCycleId', 'startEndDt', 'stmtDt' ],
	proxy : new Ext.data.HttpProxy({
		url : 'stmtGen/getStmtGenSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

// schemePeriodStore.load();

var sentToVtopStore = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'insertTime', 'compName',
			'compId', 'startDate', 'endDate', 'schemeStatus', 'payTo' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getFilterSchemePayment.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
		filterParam : 'schemeName',
		remoteSort : true,
		encodeFilters : function(filters) {
			return filters[0].value;
		}
	})
});

var execCalGrid = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'insertTime', 'compName',
			'execFreq', 'stmGenDate', 'payoutAppDate', 'execEndDate',
			'execStartDate', 'execFreq', 'compId', 'startDate', 'endDate',
			'schemeStatus', 'remarks', 'payTo', 'vtopUpFlag', 'execDate',
			'minPay', 'maxPay', 'payAmt' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getFilterSchemeCal.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
		filterParam : 'schemeName',
		remoteSort : true,
		encodeFilters : function(filters) {
			return filters[0].value;
		}
	})
});

/*
 * var stmGenGrid = new Ext.data.JsonStore({ idProperty: 'schemeId', xtype:
 * 'jsonstore', autoLoad:false, remoteFilter: true, //pageSize : 5, //autoLoad:
 * true, mode: 'local', totalProperty: 'schemeId', fields:
 * ['schemeId','schemeName','compId','compName',
 * 'startDt','endDt','paymentAmt','totalEntity','paymentMode','maxPayment','minPayment','insertDt'],
 * proxy: new Ext.data.HttpProxy({ url: 'stmtGen/getStmtGenViewSearch.action',
 * method: 'POST', reader:{ type:'json', root:'data' } filterParam:
 * 'schemeName', remoteSort:true, encodeFilters: function(filters) { return
 * filters[0].value; } }) });
 */

var payoutAppSchemeGrid = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'insertTime', 'compName',
			'compId', 'startDate', 'endDate', 'schemeStatus', 'remarks',
			'payTo', 'vtopUpFlag', 'execDate', 'minPayStr', 'maxPayStr',
			'payAmtStr', 'executionDate', 'region', 'zone' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getFilterSchemeApprove.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
		filterParam : 'schemeName',
		remoteSort : true,
		encodeFilters : function(filters) {
			return filters[0].value;
		}
	})
});

var viewschemeStoreGrid = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	pageSize : 1000,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'insertTime', 'compName',
			'startDate', 'endDate', 'fileName', 'schemeStatus', 'remarks',
			'payTo', 'compId' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getFilterSchemeView.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
		filterParam : 'schemeName',
		remoteSort : true,
		encodeFilters : function(filters) {
			return filters[0].value;
		}
	})
});

var submitschemeGrid = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	pageSize : 1000,
	// autoLoad: true,

	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'insertTime', 'compId',
			'compName', 'startDate', 'endDate', 'schemeStatus', 'remarks',
			'payTo' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getFilterSchemeSubmit.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
			totalProperty : 'totalCount',
			page : 'page'
		}
	})
});

var reportStoreGrid = new Ext.data.JsonStore(
		{
			idProperty : 'schemeINputId',
			xtype : 'jsonstore',

			autoLoad : false,
			autoSync : false,
			remoteFilter : true,
			pageSize : 10,
			fields : [ 'schemeINputId', 'schemeName', 'compId', 'compName',
					'startDate', 'endDate', 'payout', 'insertTime',
					'validityFlag', 'testRun', 'executionDate', 'remarks',
					'totalCount', 'categoryId' ],
			proxy : new Ext.data.HttpProxy({
				url : 'searchscheme/getFilterSchemeNFA.action',
				method : 'POST',
				reader : {
					type : 'json',
					root : 'data',
					totalProperty : 'totalCount'
				}
			}),
			listeners : {
				'load' : function(store, records, options) {
					// store.loadData(records.slice(0, 5));
					// store.loaded = true;
				}
			}
		});

var schemeStoreGrid = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'insertTime', 'compName',
			'startDate', 'endDate', 'schemeStatus', 'remarks', 'payTo' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getFilterSchemeView.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
		filterParam : 'schemeName',
		remoteSort : true,
		encodeFilters : function(filters) {
			return filters[0].value;
		}
	})
});

var schemeStore = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : true,
	remoteFilter : true,
	mode : 'local',
	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'insertTime', 'validityFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/loadScheme.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
		filterParam : 'schemeName',
		remoteSort : true,
		encodeFilters : function(filters) {
			return filters[0].value;
		}
	})
});

var schemeStoreEdit = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : false,
	// remoteFilter: true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'insertTime', 'validityFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/loadSchemeForEdit.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
	/*
	 * filterParam: 'schemeName', remoteSort:true, encodeFilters:
	 * function(filters) { return filters[0].value; }
	 */
	})
});

var componentEditStoreGrid = new Ext.data.JsonStore({
	idProperty : 'compId',
	autoLoad : true,
	xtype : 'jsonstore',
	autoLoad : {
		start : 0,
		limit : 5
	},
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'schemeId', 'compId', 'compName' ],
	proxy : new Ext.data.HttpProxy({
		method : 'POST',
		url : 'searchscheme/loadCompForEdit.action',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

// component stores

var searchcomponentStoreGrid = new Ext.data.JsonStore({
	idProperty : 'compId',
	autoLoad : false,
	xtype : 'jsonstore',
	autoLoad : {
		start : 0,
		limit : 5
	},
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'schemeId', 'schemeName', 'compId', 'compName', 'startDate',
			'endDate', 'freqName', 'verticalName', 'payToName', 'coverageFlag',
			'fileName', 'category' ],
	proxy : new Ext.data.HttpProxy({
		method : 'POST',
		url : 'payoutcondition/getCompMaster.action',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var categoryStore = new Ext.data.JsonStore({
	idProperty : 'category',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'categoryId',
	fields : [ 'categoryId', 'category', 'description' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getCategory.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var componentStoreGrid = new Ext.data.JsonStore({
	idProperty : 'compId',
	autoLoad : false,
	xtype : 'jsonstore',
	autoLoad : {
		start : 0,
		limit : 5
	},
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'schemeId', 'schemeName', 'compId', 'compName', 'startDate',
			'endDate', 'freqName', 'verticalName', 'payToName', 'coverageFlag',
			'fileName', 'category', 'csrf' ],
	proxy : new Ext.data.HttpProxy({
		method : 'POST',
		url : 'payoutcondition/getCompMaster.action',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var componentListStore = new Ext.data.JsonStore({
	idProperty : 'compId',
	autoLoad : false,
	xtype : 'jsonstore',
	autoLoad : {
		start : 0,
		limit : 5
	},
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'compId', 'compName', 'payTo', 'systemType', 'systemId' ],
	proxy : new Ext.data.HttpProxy({
		method : 'POST',
		url : 'payoutcondition/getCompMaster.action',

		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var componentListStoreReg = new Ext.data.JsonStore({
	idProperty : 'compId',
	autoLoad : false,
	xtype : 'jsonstore',
	autoLoad : {
		start : 0,
		limit : 5
	},
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'compId', 'compName', 'payTo' ],
	proxy : new Ext.data.HttpProxy({
		method : 'POST',
		url : 'payoutcondition/getCompMasterReg.action',

		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var componentListStoreCov = new Ext.data.JsonStore({
	idProperty : 'compId',
	autoLoad : false,
	xtype : 'jsonstore',
	autoLoad : {
		start : 0,
		limit : 5
	},
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'compId', 'compName', 'startDtStr', 'endDtStr' ],
	proxy : new Ext.data.HttpProxy({
		method : 'POST',
		url : 'payoutcondition/getCompForCov.action',

		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var componentListStoreTq = new Ext.data.JsonStore({
	idProperty : 'compId',
	autoLoad : false,
	xtype : 'jsonstore',
	autoLoad : {
		start : 0,
		limit : 5
	},
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'compId', 'compName' ],
	proxy : new Ext.data.HttpProxy({
		method : 'POST',
		url : 'schemeinput_tq/getCompListTq.action',

		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var componentListStorePo = new Ext.data.JsonStore({
	idProperty : 'compId',
	autoLoad : false,
	xtype : 'jsonstore',
	autoLoad : {
		start : 0,
		limit : 5
	},
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'compId', 'compName' ],
	proxy : new Ext.data.HttpProxy({
		method : 'POST',
		url : 'po/getCompListPo.action',

		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var freqStore = new Ext.data.JsonStore({
	idProperty : 'freqId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'freqId',
	fields : [ 'freqId', 'description' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getPayoutFreq.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var verticalStore = new Ext.data.JsonStore({
	idProperty : 'verticalId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'verticalId',
	fields : [ 'verticalId', 'verticalName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getVerticals.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var payToStore = new Ext.data.JsonStore({
	idProperty : 'payTo',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'payTo',
	fields : [ 'entityTypeId', 'displayValue' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getPayTo.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var uploadStore = new Ext.data.JsonStore({
	idProperty : 'listId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'listId',
	fields : [ 'listId', 'covFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getUploadList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

// region store
var regZoneStore = new Ext.data.JsonStore(
		{
			idProperty : 'covRegZoneId',
			xtype : 'jsonstore',
			autoLoad : false,
			// root: 'data',
			mode : 'local',
			totalProperty : 'covRegZoneId',
			fields : [ 'covRegZoneId', 'compId', 'compName', 'regionDesc',
					'zoneDesc' ],
			proxy : new Ext.data.HttpProxy({
				url : 'payoutcondition/getRegZone.action',
				method : 'POST',
				reader : {
					type : 'json',
					root : 'data'
				}
			})

		});

var sregZoneStore = new Ext.data.JsonStore(
		{
			idProperty : 'covRegZoneId',
			xtype : 'jsonstore',
			autoLoad : false,
			// root: 'data',
			mode : 'local',
			totalProperty : 'covRegZoneId',
			fields : [ 'covRegZoneId', 'compId', 'compName', 'regionDesc',
					'zoneDesc' ],
			proxy : new Ext.data.HttpProxy({
				url : 'payoutcondition/getRegZone.action',
				method : 'POST',
				reader : {
					type : 'json',
					root : 'data'
				}
			})

		});

var zoneStore = new Ext.data.JsonStore({
	idProperty : 'zoneId',
	xtype : 'jsonstore',
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'zoneId',
	fields : [ 'zoneId', 'regionId', 'zoneDesc' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getZones.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var regionStore = new Ext.data.JsonStore({
	idProperty : 'regionId',
	xtype : 'jsonstore',
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'regionId',
	fields : [ 'circleId', 'regionId', 'regionDesc' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getRegions.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

// Additional Coverage Stores

var coverageStore = new Ext.data.JsonStore({
	idProperty : 'condId',
	xtype : 'jsonstore',
	mode : 'local',
	sorters : {
		field : 'condId',
		direction : 'DESC'
	},
	sorters : [ 'condId', 'name' ],
	groupField : 'condId',
	totalProperty : 'condId',
	fields : [ 'condId', 'compId', 'condRowId', 'entityName', 'attrTypeName',
			'attrMappingName', 'functionName', 'oprName', 'co_ValueTypeName',
			'co_functionName', 'value', 'startDate', 'endDate', 'loprName',
			'lentityTypeName', 'lattrTypeName', 'lfunctionName',
			'lattNameString', 'lloprName', 'lvalueTypeName', 'lvfunctionName',
			'lvalueName', 'lStartDate', 'lEndDate', 'roprName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getCov.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var groupingFeatureCOV = Ext
		.create(
				'Ext.grid.feature.Grouping',
				{
					groupHeaderTpl : 'Condition Id: {name} ({rows.length} Row{[values.rows.length > 1 ? "s" : ""]})'
				});

var scoverageStore = new Ext.data.JsonStore({
	idProperty : 'condId',
	xtype : 'jsonstore',
	mode : 'local',
	sorters : {
		field : 'condId',
		direction : 'DESC'
	},
	totalProperty : 'condId',
	fields : [ 'condId', 'compId', 'entityName', 'attrTypeName',
			'attrMappingName', 'functionName', 'oprName', 'co_ValueTypeName',
			'co_functionName', 'value', 'startDate', 'endDate', 'loprName',
			'lentityTypeName', 'lattrTypeName', 'lfunctionName',
			'lattNameString', 'lloprName', 'lvalueTypeName', 'lvfunctionName',
			'lvalueName', 'lStartDate', 'lEndDate', 'roprName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getCov.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var entityStore = new Ext.data.JsonStore({
	idProperty : 'entityId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'entityId',
	fields : [ 'entityId', 'entityName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var entityStoreCovRight = new Ext.data.JsonStore({
	idProperty : 'entityId',
	id : 'entityStoreCovRight',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'entityId',
	fields : [ 'entityId', 'entityName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var attributeTypeStore = new Ext.data.JsonStore({
	idProperty : 'attrType',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'attrType',
	fields : [ 'attributeTypeId', 'attributeTypeName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getAttributeTypeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var attributeTypeStoreCovRight = new Ext.data.JsonStore({
	idProperty : 'attrType',
	id : 'attributeTypeStoreCovRight',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'attrType',
	fields : [ 'attributeTypeId', 'attributeTypeName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getAttributeTypeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var covFunctionStore = new Ext.data.JsonStore({
	idProperty : 'functioId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'functioId',
	fields : [ 'functioId', 'functionName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getFunctionList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var entityAttrStore = new Ext.data.JsonStore({
	idProperty : 'entityAttributeId',
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'entityAttributeId',
	fields : [ 'entityAttributeId', 'entityAttributeName', 'attrCatg',
			'attrType', 'freeTextType', 'operatorFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityAttributeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var rentityStorePo = new Ext.data.JsonStore({
	idProperty : 'entityAttributeId',
	id : 'rentityStorePo',
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'entityAttributeId',
	fields : [ 'entityAttributeId', 'entityAttributeName', 'attrCatg',
			'attrType', 'freeTextType', 'operatorFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityAttributeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var entityStorePo = new Ext.data.JsonStore({
	idProperty : 'entityAttributeId',
	id : 'entityStorePo',
	// autoLoad:false,
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'entityAttributeId',
	fields : [ 'entityAttributeId', 'entityAttributeName', 'attrCatg',
			'attrType', 'freeTextType', 'operatorFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityAttributeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var ValueListNameStore = new Ext.data.JsonStore({
	idProperty : 'entityAttributeId',
	id : 'ValueListNameStore',
	// autoLoad:false,
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'entityAttributeId',
	fields : [ 'entityAttributeId', 'entityAttributeName', 'attrCatg',
			'attrType', 'freeTextType', 'operatorFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityAttributeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var LentityAttrStore = new Ext.data.JsonStore({
	idProperty : 'entityAttributeId',
	id : 'LentityAttrStore',
	autoLoad : true,
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'entityAttributeId',
	fields : [ 'entityAttributeId', 'entityAttributeName', 'attrCatg',
			'attrType', 'freeTextType', 'operatorFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityAttributeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var LvalueListNameStore = new Ext.data.JsonStore({
	idProperty : 'entityAttributeId',
	id : 'LvalueListNameStore',
	// autoLoad:false,
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'entityAttributeId',
	fields : [ 'entityAttributeId', 'entityAttributeName', 'attrCatg',
			'attrType', 'freeTextType', 'operatorFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityAttributeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var oprStore = new Ext.data.JsonStore({
	idProperty : 'oprId',
	autoLoad : true,
	xtype : 'jsonstore',
	// autoLoad:false,
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprType', 'oprName', 'numberFlag', 'dateFlag',
			'stringFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getOprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var oprStoreCovRight = new Ext.data.JsonStore({
	idProperty : 'oprId',
	autoLoad : true,
	xtype : 'jsonstore',
	// autoLoad:false,
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprType', 'oprName', 'numberFlag', 'dateFlag',
			'stringFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getOprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

// oprStore.filter('oprType','L');

var covValueTypeStore = new Ext.data.JsonStore({
	idProperty : 'valueTypeId',
	xtype : 'jsonstore',
	autoLoad : true,
	autoLoad : false,
	mode : 'local',
	totalProperty : 'valueTypeId',
	fields : [ 'valueTypeId', 'valueTypeName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getValueTypeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var RoprStore = new Ext.data.JsonStore({
	idProperty : 'oprId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName', 'coFlag', 'tqFlag', 'poFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getRopr.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var loprStore = oprStore.findRecord('oprType', 'L');

// Tq Stores

var tqStore = new Ext.data.JsonStore({
	idProperty : 'condId',
	autoLoad : false,
	xtype : 'jsonstore',
	remoteFilter : true,
	mode : 'local',
	sorters : [ 'condId', 'name' ],
	groupField : 'condId',
	totalProperty : 'condId',
	fields : [ 'compId', 'condId', 'condRowId', 'condName', 'dataSet',
			'dataSetName', 'perfParamName', 'oprName', 'valueTypeName',
			'value', 'startDate', 'endDate', 'loprName', 'lperfParamName',
			'l_loprName', 'lvalueTypeName', 'lValue', 'lStartDate', 'lEndDate',
			'roprName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getTq.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var groupingFeatureTQ = Ext
		.create(
				'Ext.grid.feature.Grouping',
				{
					groupHeaderTpl : 'Condition Id: {name} ({rows.length} Row{[values.rows.length > 1 ? "s" : ""]})'
				});

var stqStore = new Ext.data.JsonStore({
	idProperty : 'condId',
	autoLoad : false,
	xtype : 'jsonstore',
	mode : 'local',
	totalProperty : 'condId',
	fields : [ 'compId', 'condId', 'condName', 'dataSetName', 'perfParamName',
			'oprName', 'valueTypeName', 'value', 'startDate', 'endDate',
			'loprName', 'lperfParamName', 'l_loprName', 'lvalueTypeName',
			'lValue', 'lStartDate', 'lEndDate', 'roprName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getTq.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var TqLoprStore = new Ext.data.JsonStore({
	idProperty : 'oprId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getTqOprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var dataSetStore = new Ext.data.JsonStore({
	idProperty : 'dataSetId',
	xtype : 'jsonstore',
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'dataSetId',
	fields : [ 'dataSetId', 'dataSetName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_tq/getdataSetList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var paramStore = new Ext.data.JsonStore({
	idProperty : 'paramId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'paramId',
	fields : [ 'paramId', 'paramName', 'univId', 'dtaType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_tq/getParamList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var paramStoreTqRight = new Ext.data.JsonStore({
	idProperty : 'paramId',
	id : 'paramStoreTqRight',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'paramId',
	fields : [ 'paramId', 'paramName', 'univId', 'dtaType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_tq/getParamList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var oprStoreTq = new Ext.data.JsonStore({
	idProperty : 'oprId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName', 'numberFlag', 'dateFlag', 'stringFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_tq/getOprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var oprStoreTqRight = new Ext.data.JsonStore({
	idProperty : 'oprId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName', 'numberFlag', 'dateFlag', 'stringFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_tq/getOprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var tqValueTypeStore = new Ext.data.JsonStore({
	idProperty : 'valueTypeId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'valueTypeId',
	fields : [ 'valueTypeId', 'valueTypeName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_tq/getValueTypeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var tqValueTypeStoreR = new Ext.data.JsonStore({
	idProperty : 'valueTypeId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'valueTypeId',
	fields : [ 'valueTypeId', 'valueTypeName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_tq/getValueTypeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var tqValueListStore = new Ext.data.JsonStore({
	idProperty : 'univId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'univId',
	fields : [ 'univId', 'univName', 'dataType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_tq/getTqValueList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

// ea

var eaStore = new Ext.data.JsonStore({
	idProperty : 'condId',
	autoLoad : false,
	xtype : 'jsonstore',
	// root: 'data',
	mode : 'local',
	totalProperty : 'condId',
	fields : [ 'compId', 'variableName', 'variableId', 'valueType', 'oprName',
			'parameter', 'functionName', 'dataSourceName', 'entityTypeName',
			'dataSetName', 'value', 'updateDate', 'insertDate', 'startDate',
			'endDate', 'entityTypeId', 'daylvlAggrId', 'daylvlAggr' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEa.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var seaStore = new Ext.data.JsonStore({
	idProperty : 'condId',
	autoLoad : false,
	xtype : 'jsonstore',
	// root: 'data',
	mode : 'local',
	totalProperty : 'condId',
	fields : [ 'compId', 'variableName', 'variableId', 'valueType', 'oprName',
			'parameter', 'functionName', 'dataSourceName', 'entityTypeName',
			'dataSetName', 'value', 'updateDate', 'insertDate', 'startDate',
			'endDate' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEa.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var dataSetStoreEa = new Ext.data.JsonStore({
	idProperty : 'dataSetId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'dataSetId',
	fields : [ 'dataSetId', 'dataSetName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getDataSetList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var entityStoreEa = new Ext.data.JsonStore({
	idProperty : 'entityId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'entityId',
	fields : [ 'entityId', 'entityName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getEntityList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var entityStoreEaReport = new Ext.data.JsonStore({
	idProperty : 'entityId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'entityId',
	fields : [ 'entityId', 'entityName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getEntityList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var dataSourceStoreEa = new Ext.data.JsonStore({
	idProperty : 'dataSourceId',
	xtype : 'jsonstore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'dataSourceId',
	fields : [ 'compId', 'dataSourceId', 'dataSourceName', 'valFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getDataSourceList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var functionStoreEa = new Ext.data.JsonStore({
	idProperty : 'functionId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'functionId',
	fields : [ 'functionId', 'functionName', 'functionType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getFunctionList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var parameterStoreEa = new Ext.data.JsonStore({
	idProperty : 'paramId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'paramId',
	fields : [ 'paramId', 'paramName', 'valFlag', 'oprDataType', 'unverseId',
			'attrType', 'attrCatg' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getParameterList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var dayLvlAggrStoreEa = new Ext.data.JsonStore({
	idProperty : 'dayLvlAggrId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'dayLvlAggrId',
	fields : [ 'dayLvlAggrId', 'dayLvlAggrDisplayName', 'universeId' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getDayLvlAggrList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var oprStoreEa = new Ext.data.JsonStore({
	idProperty : 'oprId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName', 'oprType', 'valFlagvar', 'valFlagcon',
			'numberFlag', 'stringFlag', 'dataFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getOprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var valueTypeStoreEa = new Ext.data.JsonStore({
	idProperty : 'attributeTypeId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'valueTypeId',
	fields : [ 'valueTypeId', 'valueTypeName', 'varFlag', 'conFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getValueTypeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var entityAttrStoreEa = new Ext.data.JsonStore(
		{
			idProperty : 'entityAttributeId',
			id : 'entityAttrStoreEa',
			// autoLoad:false,
			xtype : 'jsonstore',
			autoLoad : true,
			mode : 'local',
			totalProperty : 'entityAttributeId',
			fields : [ 'entityAttributeId', 'entityAttributeName', 'compId',
					'attrCatg', 'attrType', 'freeTextType', 'operatorFlag',
					'varFlag' ],
			proxy : new Ext.data.HttpProxy({
				url : 'payoutcondition/getEaValueList.action',
				method : 'POST',
				reader : {
					type : 'json',
					root : 'data'
				}
			})
		});

// eaFilter

var eaFilterStore = new Ext.data.JsonStore({
	idProperty : 'variableId',
	autoLoad : false,
	xtype : 'jsonstore',
	// root: 'data',
	mode : 'local',
	totalProperty : 'variableId',
	fields : [ 'compId', 'compName', 'variableId', 'variableName',
			'variableRowId', 'dataSetName', 'parameter', 'oprName',
			'valueType', 'value', 'startDate', 'endDate' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEaFilter.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var eaFilterDataSetStore = new Ext.data.JsonStore({
	idProperty : 'attrType',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'attrType',
	fields : [ 'attributeTypeId', 'attributeTypeName', 'eaFilterConFlag',
			'eaFilterVarFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getEaFilterDataSet.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var eaVariableStore = new Ext.data.JsonStore({
	idProperty : 'variableId',
	autoLoad : false,
	xtype : 'jsonstore',
	// root: 'data',
	mode : 'local',
	totalProperty : 'variableId',
	fields : [ 'variableId', 'variableName', 'dataSet' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEaVariables.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var seaFilterStore = new Ext.data.JsonStore({
	idProperty : 'variableId',
	autoLoad : false,
	xtype : 'jsonstore',
	// root: 'data',
	mode : 'local',
	totalProperty : 'variableId',
	fields : [ 'compId', 'compName', 'variableId', 'variableName',
			'variableRowId', 'dataSetName', 'parameter', 'oprName',
			'valueType', 'value', 'startDate', 'endDate' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEaFilter.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

// po stores
var poStore = new Ext.data.JsonStore({
	idProperty : 'condId',
	autoLoad : false,
	xtype : 'jsonstore',
	// root: 'data',
	mode : 'local',
	sorters : [ 'condId', 'name' ],
	groupField : 'condId',
	totalProperty : 'condId',
	fields : [ 'compId', 'compName', 'condId', 'condRowId', 'value',
			'inputType', 'inputParameter', 'oprName', 'valueType', 'loprName',
			'grossNet', 'unitName', 'paymentVariable', 'amount', 'overAch',
			'underAch', 'startDate', 'endDate', 'updateDate', 'insertDate' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getPo.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var groupingFeaturePO = Ext
		.create(
				'Ext.grid.feature.Grouping',
				{
					groupHeaderTpl : 'Condition Id: {name} ({rows.length} Row{[values.rows.length > 1 ? "s" : ""]})'
				});

var spoStore = new Ext.data.JsonStore({
	idProperty : 'condId',
	autoLoad : false,
	xtype : 'jsonstore',
	// root: 'data',
	mode : 'local',
	totalProperty : 'condId',
	fields : [ 'compId', 'compName', 'condId', 'value', 'inputType',
			'inputParameter', 'oprName', 'valueType', 'startDate', 'endDate',
			'updateDate', 'insertDate' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getPo.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var inputTypeStorePO = new Ext.data.JsonStore({
	idProperty : 'inputTypeId',
	xtype : 'jsonstore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'inputTypeId',
	fields : [ 'inputTypeId', 'inputType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getInputType.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var rinputTypeStorePO = new Ext.data.JsonStore({
	idProperty : 'inputTypeId',
	id : 'rinputTypeStorePO',
	xtype : 'jsonstore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'inputTypeId',
	fields : [ 'inputTypeId', 'inputType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getInputType.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var inputParameterStore = new Ext.data.JsonStore({
	idProperty : 'entityAttributeId',
	xtype : 'jsonstore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'entityAttributeId',
	fields : [ 'entityAttributeId', 'entityAttributeName', 'attrCatg',
			'attrType', 'freeTextType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityAttributeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var rinputParameterStore = new Ext.data.JsonStore({
	idProperty : 'entityAttributeId',
	xtype : 'jsonstore',
	id : 'rinputParameterStore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'entityAttributeId',
	fields : [ 'entityAttributeId', 'entityAttributeName', 'attrCatg',
			'attrType', 'freeTextType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getEntityAttributeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var Po_oprStore = new Ext.data.JsonStore({
	idProperty : 'oprId',
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName', 'oprType', 'numberFlag', 'stringFlag',
			'dataFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getOpr.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var rPo_oprStore = new Ext.data.JsonStore({
	idProperty : 'oprId',
	id : 'rPo_oprStore',
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName', 'oprType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'schemeinput_ea/getOprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var PoloprStore = new Ext.data.JsonStore({
	idProperty : 'oprId',
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getLoprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var rPoloprStore = new Ext.data.JsonStore({
	idProperty : 'oprId',
	id : 'rPoloprStore',
	xtype : 'jsonstore',
	autoLoad : true,
	mode : 'local',
	totalProperty : 'oprId',
	fields : [ 'oprId', 'oprName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getLoprList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var valueTypeStorePO = new Ext.data.JsonStore({
	idProperty : 'valueTypeId',
	xtype : 'jsonstore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'valueTypeId',
	fields : [ 'valueTypeId', 'valueTypeName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getValueType.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var rvalueTypeStorePO = new Ext.data.JsonStore({
	idProperty : 'valueTypeId',
	id : 'rvalueTypeStorePO',
	xtype : 'jsonstore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'valueTypeId',
	fields : [ 'valueTypeId', 'valueTypeName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getValueType.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var unitStore = new Ext.data.JsonStore({
	idProperty : 'unitId',
	xtype : 'jsonstore',
	// autoLoad: true,
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'unitId',
	fields : [ 'unitId', 'unitName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getUnitList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

// poFilter
var poFilterStore = new Ext.data.JsonStore({
	idProperty : 'compId',
	xtype : 'jsonstore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'compId', 'compName', 'condId', 'value', 'variable', 'grossNet',
			'unitName', 'amount', 'variableName', 'overAch', 'underAch',
			'updateDate', 'insertDate' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getPoFilter.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var spoFilterStore = new Ext.data.JsonStore({
	idProperty : 'compId',
	xtype : 'jsonstore',
	autoLoad : false,
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'compId', 'compName', 'condId', 'value', 'variable', 'grossNet',
			'unitName', 'amount', 'variableName', 'overAch', 'underAch',
			'updateDate', 'insertDate' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getPoFilter.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var poFilterValues = new Ext.data.JsonStore({
	idProperty : 'condId',
	autoLoad : false,
	xtype : 'jsonstore',
	mode : 'local',
	totalProperty : 'condId',
	fields : [ 'condId', 'value' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getPoValues.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var rpoFilterValues = new Ext.data.JsonStore({
	idProperty : 'condId',
	id : 'rpoFilterValues',
	autoLoad : false,
	xtype : 'jsonstore',
	mode : 'local',
	totalProperty : 'condId',
	fields : [ 'condId', 'value' ],
	proxy : new Ext.data.HttpProxy({
		url : 'payoutcondition/getPoValues.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var poFilterVariables = new Ext.data.JsonStore({
	idProperty : 'variableId',
	autoLoad : false,
	xtype : 'jsonstore',
	mode : 'local',
	totalProperty : 'variableId',
	fields : [ 'compId', 'variableId', 'variableName', 'poVarFlag',
			'poAttrType', 'poAttrCatg', 'oprType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getEaVariabes.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var poFilterVariablesPO = new Ext.data.JsonStore({
	idProperty : 'variableId',
	autoLoad : false,
	xtype : 'jsonstore',
	mode : 'local',
	totalProperty : 'variableId',
	fields : [ 'compId', 'variableId', 'variableName', 'poVarFlag',
			'poAttrType', 'poAttrCatg', 'oprType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getPOVariabes.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var rpoFilterVariables = new Ext.data.JsonStore({
	idProperty : 'variableId',
	id : 'rpoFilterVariables',
	autoLoad : false,
	xtype : 'jsonstore',
	mode : 'local',
	totalProperty : 'variableId',
	fields : [ 'compId', 'variableId', 'variableName', 'poVarFlag',
			'poAttrType', 'poAttrCatg' ],
	proxy : new Ext.data.HttpProxy({
		url : 'po/getEaVariabes.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var bulkSchemeStore = new Ext.data.JsonStore({
	idProperty : 'schemeId',
	xtype : 'jsonstore',
	// autoLoad: false,
	// root: 'data',
	autoSync : true,
	remoteFilter : true,
	mode : 'local',
	totalProperty : 'schemeId',
	fields : [ 'schemeId', 'schemeName' ],
	proxy : {
		type : 'ajax',
		url : 'bulkUpload/getBulkSchemeList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	}
});

var bulkComponentStore = new Ext.data.JsonStore({
	idProperty : 'componentId',
	xtype : 'jsonstore',
	autoLoad : false,
	// root: 'data',
	// autoSync:true,
	// remoteFilter: true,
	mode : 'local',
	totalProperty : 'componentId',
	fields : [ 'schemeId', 'componentId', 'componentName' ],
	proxy : {
		type : 'ajax',
		url : 'bulkUpload/getBulkComponentList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	}
});

var transDataGrid = new Ext.data.JsonStore({
	// idProperty: 'schemeId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeId',
	fields : [ 'schemeId', 'schemeName', 'compName', 'compId', 'startDtStr',
			'endDtStr', 'payToName', 'scmStatus', 'payoutStatus',
			'paymentStatus' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getTransDataSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
	// filterParam: 'schemeName',
	// remoteSort:true,
	/*
	 * encodeFilters: function(filters) { return filters[0].value; }
	 */
	})
});

var transSubDataGrid = new Ext.data.JsonStore({
	// idProperty: 'schemeId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeId',
	fields : [ 'schemeId', 'compId', 'condName', 'condition', 'qualify',
			'notQualify', 'condId', 'grossnet', 'maxAmt', 'minAmt', 'avgAmt',
			'headCount' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getTransSubDataSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
	// filterParam: 'schemeName',
	// remoteSort:true,
	/*
	 * encodeFilters: function(filters) { return filters[0].value; }
	 */
	})
});

var transPaymentDataGrid = new Ext.data.JsonStore({
	idProperty : 'paymentId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	pageSize : 10,
	// autoLoad: true,
	mode : 'local',
	// totalProperty: 'paymentId',
	fields : [ 'paymentId', 'displayValue', 'paymentDt', 'paymentAmt',
			'paymentType', 'paidBy', 'paymentremarks', 'totalCount' ],
	proxy : new Ext.data.HttpProxy({
		url : 'transData/getTransPaymentDataSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
			totalProperty : 'totalCount'
		}

	// filterParam: 'schemeName',
	// remoteSort:true,
	/*
	 * encodeFilters: function(filters) { return filters[0].value; }
	 */
	}),
	listeners : {
		'load' : function(store, records, options) {

		}
	}
});

var transPaySubDataGrid = new Ext.data.JsonStore({
	// idProperty: 'schemeId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeId',
	fields : [ 'schemeId', 'compId', 'schemeName', 'compName', 'paymentAmt',
			'totalEntity', 'maxPayment', 'minPayment', 'avgPayment', 'startDt',
			'endDt' ],
	proxy : new Ext.data.HttpProxy({
		url : 'transData/getTransSubPaymentDataSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
	// filterParam: 'schemeName',
	// remoteSort:true,
	/*
	 * encodeFilters: function(filters) { return filters[0].value; }
	 */
	})
});

var transUniverseDataGrid = new Ext.data.JsonStore({
	idProperty : 'inputTypeId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'inputTypeId',
	fields : [ 'inputTypeId', 'inputTypeDesc', 'displayValue' ],
	proxy : new Ext.data.HttpProxy({
		url : 'transData/getTransUniverseDataSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
	// filterParam: 'schemeName',
	// remoteSort:true,
	/*
	 * encodeFilters: function(filters) {viewStmtGenGrid return
	 * filters[0].value; }
	 */
	})
});

var transUniverseSubDataGrid = new Ext.data.JsonStore({
	idProperty : 'universeId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'universeId',
	fields : [ 'minDt', 'maxDt', 'headCount' ],
	proxy : new Ext.data.HttpProxy({
		url : 'transData/getTransSubUniverseDataSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
	// filterParam: 'schemeName',
	// remoteSort:true,
	/*
	 * encodeFilters: function(filters) { return filters[0].value; }
	 */
	})
});

var transPayoutDataGrid = new Ext.data.JsonStore({
	idProperty : 'schId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	mode : 'local',
	totalProperty : 'schemeId',
	fields : [ 'schemeId', 'schemeName', 'compName', 'compId', 'startDtStr',
			'endDtStr', 'payToName', 'scmStatus', 'payoutStatus',
			'paymentStatus' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getTransDataSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
	/*
	 * filterParam: 'schemeName', remoteSort:true, encodeFilters:
	 * function(filters) { return filters[0].value; }
	 */
	})
});

var transPayoutSubDataGrid = new Ext.data.JsonStore(
		{
			// idProperty: 'schemeId',
			xtype : 'jsonstore',
			autoLoad : false,
			remoteFilter : true,
			// pageSize : 5,
			// autoLoad: true,
			mode : 'local',
			totalProperty : 'schemeId',
			fields : [ 'qualify', 'grossnet', 'maxAmt', 'minAmt', 'avgAmt',
					'headCount' ],
			proxy : new Ext.data.HttpProxy({
				url : 'searchscheme/getTransSubDataSearch.action',
				method : 'POST',
				reader : {
					type : 'json',
					root : 'data'
				},
			/*
			 * filterParam: 'schemeName', remoteSort:true, encodeFilters:
			 * function(filters) { return filters[0].value; }
			 */
			})
		});

var viewStmtGenGrid = new Ext.data.JsonStore({
	idProperty : 'distDsm2Id',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	pageSize : 1000,
	// autoLoad: true,
	mode : 'local',
	// totalProperty: 'distDsm2Id',
	fields : [ 'cpId', 'mobileNo', 'email', 'partnerType', 'cpName',
			'grandTotal', 'beneficiary', 'totGrossAmt', 'totNetAmt',
			'applicationName', 'scmListId', 'contractEndDt', 'totalCount',
			'stmtCycleId' ],
	proxy : new Ext.data.HttpProxy({
		url : 'stmtGen/getViewStmtSearch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
			totalProperty : 'totalCount'
		},
	}),
/*
 * listeners: { 'load' : function(store,records,options) { } }
 */
});

var templateGrid = new Ext.data.JsonStore({
	idProperty : 'sno',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize:10,
	// autoLoad: true,
	mode : 'local',
	// totalProperty: 'sno',
	fields : [ 'sno', 'fileType', 'fileName', 'example' ],
	proxy : new Ext.data.HttpProxy({
		url : 'resources/images/template-data.json',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
		// totalProperty : 'totalCount'
		},
	}),
	listeners : {
		'load' : function(store, records, options) {

		}
	}
});

var hierarchyGrid = new Ext.data.JsonStore({
	idProperty : 'sno',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	// pageSize:10,
	// autoLoad: true,
	mode : 'local',
	// totalProperty: 'sno',
	fields : [ 'unid', 'scm', 'retailer', 'dse', 'dist', 'internalSales' ],
	proxy : new Ext.data.HttpProxy({
		url : 'admin/getHierarchySuspense.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
		// totalProperty : 'totalCount'
		},
	}),
	listeners : {
		'load' : function(store, records, options) {
		}
	}
});

var hierarchyGrid2 = new Ext.data.JsonStore({
	idProperty : 'sno2',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	autoScroll : true,
	// pageSize:10,
	// autoLoad: true,
	mode : 'local',
	// totalProperty: 'sno',
	fields : [ 'systemsInvolved', 'hierarchyDate', 'retMgrMismatch',
			'dseMgrMismatch', 'distMgrMismatch', 'tsmMgrMismatch',
			'asmMgrMismatch', 'zbmMgrMismatch', 'shMgrMismatch',
			'totalMismatch', 'retMissingFirstSys', 'retMissingSecondSys',
			'dseMissingFirstSys', 'dseMissingSecondSys', 'distMissingFirstSys',
			'distMissingSecondSys', 'tsmMissingFirstSys',
			'tsmMissingSecondSys', 'asmMissingFirstSys', 'asmMissingSecondSys',
			'zbmMissingFirstSys', 'zbmMissingSecondSys', 'shMissingFirstSys',
			'shMissingSecondSys', 'chMissingFirstSys', 'chMissingSecondSys',
			'totalMissing' ],
	proxy : new Ext.data.HttpProxy({
		url : 'admin/getHierarchyMismatch.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
		// totalProperty : 'totalCount'
		},
	}),
/*
 * listeners: { 'load' : function(store,records,options) { } }
 */
});

/*
 * var hierarchyMismatchStore = new Ext.data.JsonStore({ idProperty:
 * 'systemsInvolved', xtype: 'jsonstore', autoLoad:false, remoteFilter: true,
 * //pageSize:10, //autoLoad: true, mode: 'local', //totalProperty:
 * 'systemsInvolved', fields:
 * ['systemsInvolved','retMgrMismatch','dseMgrMismatch','distMgrMismatch','tsmMgrMismatch','asmMgrMismatch','zbmMgrMismatch','shMgrMismatch','totalMismatch'],
 * proxy: new Ext.data.HttpProxy({ url: 'admin/getHierarchyMismatch.action',
 * method: 'POST', reader:{ type:'json', root:'data' } }), listeners: { 'load' :
 * function(store,records,options) { } } });
 */

/*
 * var hierarchyMismatchStore = new Ext.data.JsonStore({ idProperty: 'hirId',
 * xtype: 'jsonstore', autoLoad:false, //root: 'data', mode: 'local',
 * //totalProperty: 'circleId', fields:
 * ['systemsInvolved','retMgrMismatch','dseMgrMismatch','distMgrMismatch','tsmMgrMismatch','asmMgrMismatch','zbmMgrMismatch','shMgrMismatch','totalMismatch'],
 * proxy: new Ext.data.HttpProxy({ url: 'admin/getHierarchyMismatch.action',
 * method: 'POST', reader:{ type:'json', root:'data' } })
 * 
 * });
 */

var circleStore = new Ext.data.JsonStore({
	idProperty : 'circleId',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	autoScroll : true,
	mode : 'local',
	totalProperty : 'circleId',
	fields : [ 'circleId', 'circleCode', 'circleName' ],
	proxy : new Ext.data.HttpProxy({
		url : 'master/getCircleMaster.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});
// circleStore.load();

var schemaMasterStore = new Ext.data.JsonStore({
	idProperty : 'schemaId',
	xtype : 'jsonstore',
	autoLoad : false,
	// root: 'data',
	// remoteFilter: true,
	// autoScroll: true,
	mode : 'local',
	totalProperty : 'schemaId',
	fields : [ 'schemaId', 'schemaName', 'circleId' ],
	proxy : new Ext.data.HttpProxy({
		url : 'master/getSchemeMasterList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
		filterParam : 'schemaName',
		remoteSort : true,
		encodeFilters : function(filters) {
			return filters[0].value;
		}
	}),
/*
 * listeners: { 'load' : function(store,records,options) { } }
 */
});
// schemaMasterStore.load();

var componentMasterStore = new Ext.data.JsonStore({
	idProperty : 'compId',
	xtype : 'jsonstore',
	autoLoad : false,
	// remoteFilter: true,
	autoScroll : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'compId',
	fields : [ 'compId', 'compName', 'schemaId' ],
	proxy : new Ext.data.HttpProxy({
		url : 'master/getComponentMasterList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	/*
	 * , filterParam: 'schemaId', remoteSort:true, encodeFilters:
	 * function(filters) { return filters[0].value; }
	 */

	})

});
// componentMasterStore.load();

var paramCatMasterStore = new Ext.data.JsonStore({
	idProperty : 'categoryId',
	xtype : 'jsonstore',
	// autoLoad:false,
	// remoteFilter: true,
	autoScroll : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'categoryId',
	fields : [ 'categoryId', 'categoryName', 'circleId' ],
	proxy : new Ext.data.HttpProxy({
		url : 'master/getParamCatMasterList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});
// paramCatMasterStore.load();

var scmDataAnalysis = new Ext.data.JsonStore({
	idProperty : 'scmData',
	xtype : 'jsonstore',
	autoLoad : false,
	remoteFilter : true,
	autoScroll : true,
	// pageSize:10,
	// autoLoad: true,
	mode : 'local',
	// totalProperty: 'sno',
	fields : [ 'schemeId', 'compId', 'schemeName', 'compName', 'paramCat',
			'paramName', 'rowCount', 'valueCount', 'missingValueCount',
			'fullHierStampCount', 'partialHierStampCount',
			'missingHierStampCount', 'startDt', 'endDt', 'remarks' ],
	proxy : new Ext.data.HttpProxy({
		url : 'admin/getScmDataAnalysis.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
		// totalProperty : 'totalCount'
		},
	}),
/*
 * listeners: { 'load' : function(store,records,options) { } }
 */
});

var AttrMappingConfigStore = new Ext.data.JsonStore({
	idProperty : 'id',
	xtype : 'jsonstore',
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'id',
	fields : [ 'id', 'attrCatg', 'attrType', 'displayName', 'srcTblField',
			'freeTxtType', 'srcTblName', 'covFlag', 'tqFlag', 'entAggFlag',
			'payCondFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'admin/getAttrConfigStore.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

var AttrMappingFieldSetStore = new Ext.data.JsonStore({
	idProperty : 'fieldId',
	xtype : 'jsonstore',
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'fieldId',
	fields : [ 'fieldId', 'fieldName', 'fieldType' ],
	proxy : new Ext.data.HttpProxy({
		url : 'admin/getAttrMappingFieldSet.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

function AttrCatgStore() {
	var store = new Ext.data.SimpleStore({
		fields : [ 'id', 'displayName' ],
		data : [ [ '7', 'Additional' ] ]
	// , ['8', 'Core']
	});
	return store;
}

function EntAttrTableNameStore() {
	var store = new Ext.data.SimpleStore({
		fields : [ 'id', 'displayName' ],
		data : [ [ '1', 'DL_ENTITY_HIERARCHY_STAG' ],
				[ '8', 'DLP_TBL_ENTITY_ADD_ATT_PRESTAG' ] ]
	});
	return store;
}

function EntAttrDataTypeStore() {
	var store = new Ext.data.SimpleStore({
		fields : [ 'id', 'displayName' ],
		data : [ [ '1', 'String' ], [ '2', 'Date' ], [ '3', 'Number' ] ]
	});
	return store;
}

var holdDataGridStore = new Ext.data.JsonStore(
		{
			idProperty : 'scmId',
			xtype : 'jsonstore',
			autoLoad : false,
			remoteFilter : true,
			// pageSize : 5,
			// autoLoad: true,
			mode : 'local',
			totalProperty : 'scmId',
			fields : [ 'scmId', 'scmName', 'compId', 'compName', 'startDt',
					'endDt', 'payoutStatus', 'paymentStatus', 'amount',
					'payTo', 'ftaNumber', 'vtopupNumber', 'totalAmt',
					'producerId', 'payToId', 'netHoldAmt' ],
			proxy : new Ext.data.HttpProxy({
				url : 'searchscheme/getHoldDataSearch.action',
				method : 'POST',
				reader : {
					type : 'json',
					root : 'data',
				// totalAmtProperty :'totalAmt',

				}
			})
		});

var StmtReqStore = new Ext.data.JsonStore({
	idProperty : 'scmId',
	xtype : 'jsonstore',
	autoLoad : false,
	// root: 'data',
	mode : 'local',
	totalProperty : 'scmId',
	pageSize : 10,
	fields : [ 'scmId', 'scmName', 'compId', 'compName', 'payTo',
			'payoutApprovalDt', 'payToId', 'payoutStatus', 'paymentStatus',
			'scmApproveDt', 'startDt', 'endDt', 'paymentDt' ],
	proxy : new Ext.data.HttpProxy({
		url : 'admin/getStmtReqStore.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
		// totalProperty : 'totalCount'
		}
	})

});

var tempSchemeStore = new Ext.data.JsonStore({
	idProperty : 'scmId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'scmId',
	pageSize : 10,
	fields : [ 'scmId', 'scmName', 'compId', 'compName', 'payTo',
			'payoutApprovalDt', 'payToId', 'payoutStatus', 'paymentStatus',
			'scmApproveDt', 'startDt', 'endDt', 'paymentDt' ],
	proxy : new Ext.data.HttpProxy({
		url : 'stmtGen/getTempReqStore.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
		// totalProperty : 'totalCount'
		}
	})

});

var stmtSchemePeriod = new Ext.data.JsonStore(
		{
			idProperty : 'stmtCycleId',
			xtype : 'jsonstore',
			autoLoad : false,
			// root: 'data',
			mode : 'local',
			totalProperty : 'stmtCycleId',
			fields : [ 'stmtCycleId', 'startEndDt', 'stmtDt', 'countId',
					'cycleEndDt' ],
			proxy : new Ext.data.HttpProxy({
				url : 'stmtGen/searchStmtPeriod.action',
				method : 'POST',
				reader : {
					type : 'json',
					root : 'data'
				}
			})
		});

var stmtServiceType = new Ext.data.JsonStore({
	idProperty : 'serviceId',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'serviceId',
	fields : [ 'serviceId', 'serviceType', 'serviceDesc' ],
	proxy : new Ext.data.HttpProxy({
		url : 'stmtGen/serviceType.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

/*
 * var holdDataProducers = new Ext.data.JsonStore({ idProperty: 'producerId',
 * xtype: 'jsonstore', autoLoad:false, root: 'data', mode: 'local',
 * totalProperty: 'producerId', fields: ['producerId'], proxy: new
 * Ext.data.HttpProxy({ url: 'searchscheme/holdDataProducers.action', method:
 * 'GET', reader:{ type:'json', root:'data' } }) });
 */

var releaseDataGridStore = new Ext.data.JsonStore({
	xtype : 'jsonstore',
	idProperty : 'producerId',
	autoLoad : false,
	remoteFilter : true,
	// pageSize : 5,
	// autoLoad: true,
	sorters : [ 'producerId', 'name' ],
	groupField : 'producerId',
	mode : 'local',
	totalProperty : 'transactionDate',
	fields : [ 'transactionDate', 'producerId', 'holdAmt', 'releaseStatus',
			'releaseReqDate', 'releaseDate', 'totalAmt', 'remarks',
			'holdReleaseRequest', 'holdStatus' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/getTotalReleaseAmount.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data',
		// totalAmtProperty :'totalAmt',
		}
	})
});

var groupingFeature = Ext
		.create(
				'Ext.grid.feature.Grouping',
				{
					groupHeaderTpl : 'ProducerId: {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})'
				});

var schemeStoreCreate = new Ext.data.JsonStore({
	idProperty : 'schemeINputId',
	xtype : 'jsonstore',
	autoLoad : false,
	// remoteFilter: true,
	mode : 'local',
	totalProperty : 'schemeINputId',
	fields : [ 'schemeINputId', 'schemeName', 'autoCopyFlag',
			'aggrementEndDate', 'autoApprovalFlag' ],
	proxy : new Ext.data.HttpProxy({
		url : 'searchscheme/loadSchemeCreate.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		},
	})
});

var payToStoreCreate = new Ext.data.JsonStore({
	idProperty : 'payTo',
	xtype : 'jsonstore',
	autoLoad : true,
	// root: 'data',
	mode : 'local',
	totalProperty : 'payTo',
	fields : [ 'entityTypeId', 'displayValue' ],
	proxy : new Ext.data.HttpProxy({
		url : 'master/getPayToCreate.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

/*
 * var bulkUploadFileList=new Ext.data.JsonStore({ idProperty:'fileId',
 * xtype:'jsonstore', autoLoad:true, model:'local', totalProperty:'displayName',
 * fields:['fileId','fileName','displayName'], proxy:new Ext.data.HttpProxy( {
 * type: 'ajax', url:'bulkUpload/getBulkUploadFileList.action', method:'POST',
 * reader: { type:'json', root:'data' } } ) });
 */

var docTypeList = new Ext.data.JsonStore({
	idProperty : 'docFileType',
	xtype : 'jsonstore',
	autoLoad : true,
	model : 'local',
	totalProperty : 'docFileType',
	fields : [ 'docFileType', 'typeId' ],
	proxy : new Ext.data.HttpProxy({
		type : 'ajax',
		url : 'bulkUpload/getDocListType.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var uploadDataStore = new Ext.data.JsonStore({
	idProperty : 'uploadFileName',
	xtype : 'jsonstore',
	autoLoad : false,
	totalProperty : 'uploadFileName',
	fields : [ 'insertedDate', 'dataFileName', 'seqNo', 'userId' ]
});

var mailDataStore = new Ext.data.JsonStore(
		{
			idProperty : 'dataFileName',
			xtype : 'jsonstore',
			autoLoad : false,
			totalProperty : 'dataFileName',
			fields : [ 'dataFileName', 'dsm2RefCode', 'mailInsertDate',
					'sendDate', 'email', 'errorMsg', 'mailSendStatus',
					'mailStatus', 'mailSendDate' ]
		});

var reportCategoryStore = new Ext.data.JsonStore({
	idProperty : 'categoryId',
	xtype : 'jsonstore',
	autoLoad : true,
	model : 'local',
	totalProperty : 'categoryId',
	fields : [ 'categoryId', 'categoryName' ],
	proxy : new Ext.data.HttpProxy({
		type : 'ajax',
		url : 'reports/getReportCategory.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var reportNameStore = new Ext.data.JsonStore({
	ifProperty : 'reportId',
	xtype : 'jsonstore',
	autoLoad : true,
	model : 'local',
	totalProperty : 'reportId',
	fields : [ 'reportId', 'reportName', 'reportInputCategory',
			'reportGenType', 'reportLastGenDateTime', 'duration' ],
	proxy : new Ext.data.HttpProxy({
		type : 'ajax',
		url : 'reports/getReportName.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var scmCategoryStore = new Ext.data.JsonStore({
	idProperty : 'scmCategoryId',
	xtype : 'jsonstore',
	autoLoad : true,
	model : 'local',
	totalProperty : 'scmCategoryId',
	fields : [ 'scmCategoryId', 'scmCategoryName' ],
	proxy : new Ext.data.HttpProxy({
		type : 'ajax',
		url : 'reports/getScmReportCategory.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})
});

var bulkInvalidRecords = new Ext.data.JsonStore({
	idProperty : 'bulkUploadedFileName',
	xtype : 'jsonstore',
	autoLoad : false,
	fields : [ 'seqNoIndex', 'fileName', 'loadDateTime', 'unquieFileName',
			'downloadFile', 'circleCode', 'userName', 'errorDesc' ],
	proxy : new Ext.data.HttpProxy({
		url : 'bulkUpload/getRejectedFileList.action',
		method : 'POST',
		reader : {
			type : 'json',
			root : 'data'
		}
	})

});

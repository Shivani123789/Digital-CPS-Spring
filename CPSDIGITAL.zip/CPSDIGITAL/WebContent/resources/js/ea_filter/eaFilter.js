 var eaFilterGridStatus = 0;
 var seaFilterGridStatus = 0;
 
 var compId = null;
 var condId = null;
 var condRowId = null;

   
 
 function saveEaFilter(eaForm)
{

	 eaForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/addEaFilter.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
        
		 success: function(form, action) {
            Ext.Msg.alert('Entity  Filter Condition Created Sucessfully');
            eaFilterStore.load();
            eaForm.close();
			formPanel.items.each(function(c){
		    	
			c.items.items[7].setDisabled(false);
						c.setActiveTab(c.items.items[7]);
						})

            //form.reset();
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        	
        }
    });
	
	
}

 
 function updateEaFilter(eaForm)
 {

 	 eaForm.down('form').getForm().submit({
 		
 		 waitMsg : 'Loading...',
 		 url : 'payoutcondition/updateEaFilter.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
 		 method : 'POST',
 		 
 		params: {
			  "compId" : compId,
			  "variableId":condId,
			  "variableRowId":condRowId
		    },
     
         
 		 success: function(form, action) {
             Ext.Msg.alert('Filter Aggregate updated successfully');
             eaFilterStore.load();
             eaForm.close();
         },
         failure: function(form, action) {
         	if(action.result != null)
             Ext.Msg.alert('Warning', action.result.errorMessage);
         	else
         	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
         	
         }
     });
 	
 	
 }



var eaFilterList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	//height:600,
 	
   items:[{
	   
     		xtype:'fieldset',
     		//title: 'Edit Scheme',
     		//collapsible: true,
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%',
     //			width:230
     		
     		},
     		items :[
     			{
             		html: "<div id='eafilterlist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});


var seaFilterList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	//height:600,
 	
   items:[{
	   
     		xtype:'fieldset',
     		//title: 'Edit Scheme',
     		//collapsible: true,
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%',
     //			width:230
     		
     		},
     		items :[
     			{
             		html: "<div id='seafilterlist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
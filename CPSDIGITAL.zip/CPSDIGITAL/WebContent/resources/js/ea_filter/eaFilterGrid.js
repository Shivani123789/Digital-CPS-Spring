Ext.onReady(function () {
	Ext.define('Scheme.model.EaFilter', {
	    extend: 'Ext.data.Model',
	    fields: [
	             {name: 'compId', type: 'int'},
	             {name: 'compName',  type: 'string'},
	             {name: 'condId', type: 'int'},
	             {name: 'variableName',  type: 'string'},
	             {name: 'variableRowId', type: 'int'},
	             {name: 'value',  type: 'string'}
	   
	    ]
	  });
 
	
   
	var compId = null;
	var entity = null;
   
 
   Ext.define('Scheme.view.EaFilterList', {
    extend: 'Ext.grid.Panel',
    name:'eaFilterGrid',
    pageSize : 5,
    alias: 'widget.EaFilterList',
    title: 'Ea_Filter List',
    store: eaFilterStore,
    height:500,
    //layout:'fit',
    autoScroll: true,
  //  store : 'Companies',
    initComponent: function () {
      this.tbar = [{
        text    : 'Add',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
        { header: 'compId', dataIndex: 'compId', width: 60 },
       // { header: 'compName', dataIndex: 'compName', flex: 1 },
        { header: 'variableId', dataIndex: 'variableId', width: 60 },
        { header: 'variableName', dataIndex: 'variableName', flex: 1  },
        
        { header: 'dataSetName', dataIndex: 'dataSetName', width: 60 },
        { header: 'parameter', dataIndex: 'parameter', width: 60 },
        { header: 'oprName', dataIndex: 'oprName', width: 60 },
        { header: 'valueType', dataIndex: 'valueType', width: 60 },
        { header: 'value', dataIndex: 'value', width: 80  },
        { header: 'startDate', dataIndex: 'startDate', width: 60 },
        { header: 'endDate', dataIndex: 'endDate', width: 60 },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'resources/images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('EaFilterList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Region Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove EA Filter', 
                          'Are you sure you want to delete EA Filter?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            	//ajax post to remove
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removeEaFilter.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
                            			  method: 'POST',
                            			  params: {
                            				  "compId" : rs[0].data.compId,
                            				  "variableId" :rs[0].data.variableId,
                            				  "variableRowId" :rs[0].data.variableRowId
                            			    },
                            			    success: function (response) {
                             			       // var jsonResp = Ext.util.JSON.decode(response.responseText);
                             			         Ext.Msg.alert("Info"," Ea Filter deleted Sucessfully");
                             			     //   schemeStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			   //   var jsonResp = Ext.util.JSON.decode(response.responseText);
                            			    //  Ext.Msg.alert("Error",jsonResp.error);
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : eaFilterStore,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.EaFilterForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.EaFilterForm',
      title   : 'Add EAFilter',
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          anchor: '100%'
        },
        items : [
										{
            xtype: 'fieldset',
            anchor: '100%',
            title: 'Entity Details',
            collapsible: true,
            layout:'column',
            items:[
					{
				    xtype: 'container',
				    columnWidth:.2,
				    layout: 'anchor',
				    items: [
								{
									xtype :'combo',
									fieldLabel: 'Component',
									name:'compId',
									id:'eaFilterCompList',
									displayField:'compName',
									editable: false,
									valueField:'compId',
									store: componentListStore,
									listeners: {
													'select': function(combo, value){
													
													oprStoreEa.clearFilter();
													
													 compId = combo.getValue();

															oprStoreEa.filter(function(r) {
																var value = r.get('oprType');
																return (value == 'R' || value == 'S');
															});

													}
													},
									triggerAction:'all'
								},
								
								{
									xtype :'combo',
									fieldLabel: 'Variable',
									name:'variableId',
									displayField:'variableName',
									valueField:'variableId',
									store: eaVariableStore,
									listeners: {
									'select': function(combo, value){
								
								
										var temp  = eaVariableStore.findRecord('variableId',combo.getValue());
										
										temp = temp.data.dataSet;
								
										//alert(compId);
										 
										 entity = eaStore.findRecord('compId',compId);
										
										console.log(entity);
										
										
										entity = entity.data.entityTypeName;
										entity	= entityStoreEa.findRecord('entityName',entity);
										entity = entity.data.entityId;
										if(temp==1)
										{
										//parameterStoreEa.clearFilter();
										parameterStoreEa.clearFilter();
										parameterStoreEa.filter('valFlag','C');
													
										eaFilterDataSetStore.clearFilter();
										eaFilterDataSetStore.filter('eaFilterConFlag','Y');
										this.up('window').down('form').getForm().findField("parameter").readOnly = false;
										}
										else
										{
										//parameterStoreEa.clearFilter();
										//parameterStoreEa.filter('valFlag','V');
										
										//var varName = eaVariableStore.findRecord('variableId',combo.getValue());
										//this.up('window').down('form').getForm().findField("parameter").setValue(parameterStoreEa.findRecord('paramName',varName.data.variableName));
										//this.up('window').down('form').getForm().findField("parameter").readOnly = true;
										parameterStoreEa.clearFilter();
										parameterStoreEa.filter('valFlag','V');
										
										eaFilterDataSetStore.clearFilter();
										eaFilterDataSetStore.filter('eaFilterVarFlag','Y');
										
										}
								
								}
								},
									triggerAction:'all'
								} 
				           ]
					},
				
            
            
            {
                xtype: 'container',
                columnWidth:.3,
                layout: 'anchor',
                items: [
                       
								{
									xtype :'combo',
									fieldLabel: 'Data Set',
									name:'dataSet',
									displayField:'attributeTypeName',
									valueField:'attributeTypeId',
									store: eaFilterDataSetStore,
									triggerAction:'all',
									listeners: {
									'select': function(combo, value){
									
									this.up('window').down('form').getForm().findField("parameter").reset();
					
										if(combo.getValue()==7 || combo.getValue()==8)
										{
										
										//alert(entity);
										//alert(combo.getValue());
									parameterStoreEa.clearFilter();
									
									//parameterStoreEa.filter('valFlag','AC');
									
									
									parameterStoreEa.filter(function(r) {
																var value = r.get('attrCatg');
																var value2 = r.get('attrType');
																return (value == combo.getValue() && value2 == entity);
															});
									
									}
									
									if(combo.getValue()==11)
									{
									parameterStoreEa.clearFilter();
									parameterStoreEa.filter('valFlag','C');
									
									}
									
									if(combo.getValue()==6)
									{
									parameterStoreEa.clearFilter();
									parameterStoreEa.filter('valFlag','V');
									
									
									}
									
									
									}
									
									}
									
								},
								{
									xtype :'combo',
									fieldLabel: 'Parameter',
									name:'parameter',
									displayField:'paramName',
									valueField:'paramName',
									store: parameterStoreEa,
									listeners: {
									'select': function(combo, value){
										var temp = 	parameterStoreEa.findRecord('paramName',combo.getValue());
									
									
									
									if(temp)
									{
									if(temp.data.valFlag=='C')
									{
								//	temp = temp.data.oprDataType;
									
									oprStoreEa.clearFilter();
											
											if(temp.data.oprDataType=='D')
											{
											oprStoreEa.filter('dataFlag','Y');
											}
											if(temp.data.oprDataType=='N')
											{
											oprStoreEa.filter('numberFlag','Y');
											}
											if(temp.data.oprDataType=='S')
											{
											oprStoreEa.filter('stringFlag','Y');
											}
									
									
									}
									if(temp.data.valFlag=='V')
									{
									oprStoreEa.clearFilter();
									oprStoreEa.filter('oprType','R');
									}
									}
									}
									},
									triggerAction:'all',
									
								},
								{
									xtype :'combo',
									fieldLabel: 'OPR',
									name:'opr',
									displayField:'oprName',
									valueField:'oprId',
									store: oprStoreEa,
									listeners: {
							  'select': function(combo, value){
								
								 if(combo.getValue()==14)
									 {
									 this.up('window').down('form').getForm().findField("valueType").disable();
									 this.up('window').down('form').getForm().findField("value").disable();
									 this.up('window').down('form').getForm().findField("ValueListName").disable();
									 this.up('window').down('form').getForm().findField("lStartDate").allowBlank=false;
									 this.up('window').down('form').getForm().findField("lEndDate").allowBlank=false;
									 }
								 else
								 {
								 this.up('window').down('form').getForm().findField("valueType").enable();
								 this.up('window').down('form').getForm().findField("value").enable();
								 this.up('window').down('form').getForm().findField("ValueListName").enable();
								 this.up('window').down('form').getForm().findField("lStartDate").allowBlank=true;
								this.up('window').down('form').getForm().findField("lEndDate").allowBlank=true;

								 }
							  }
							 },
									triggerAction:'all'
								},
								{
									xtype :'combo',
									fieldLabel: 'Value Type',
									name:'valueType',
									displayField:'valueTypeName',
									valueField:'valueTypeName',
									store: valueTypeStoreEa,
									listeners: {
							  'select': function(combo, value){
								  if(combo.getValue()==5)
									  {
									  this.up('window').down('form').getForm().findField("lStartDate").allowBlank=false;
									  this.up('window').down('form').getForm().findField("lEndDate").allowBlank=false;

									  }
								  
								  if(combo.getValue()=='Free Text')
								  {
									  
									  this.up('window').down('form').getForm().findField("value").enable();
									  this.up('window').down('form').getForm().findField("ValueListName").disable();

								  }
								  
								  if(combo.getValue()=='Variable')
								  {
									  
									  this.up('window').down('form').getForm().findField("value").disable();
									  entityAttrStoreEa.clearFilter();
									  entityAttrStoreEa.filter('varFlag','Y');
									  entityAttrStoreEa.filter('compId',compId);
									  this.up('window').down('form').getForm().findField("ValueListName").enable();
									  this.up('window').down('form').getForm().findField("ValueListName").reset();

									  
								  }
								  
								  
								  if(combo.getValue()=='Core' || combo.getValue()=='Additional')
								  {
									  this.up('window').down('form').getForm().findField("value").disable();
									  entityAttrStoreEa.clearFilter();
									 
									  
									  var filterValue = valueTypeStoreEa.findRecord('valueTypeName',combo.getValue());
									
									
									entityAttrStoreEa.filter(function(r) {
																var value = r.get('attrCatg');
																var value2 = r.get('attrType');
																return (value == filterValue.data.valueTypeId && value2 == entity);
															});
									
									
									  this.up('window').down('form').getForm().findField("ValueListName").enable();
									  this.up('window').down('form').getForm().findField("ValueListName").reset();

								  }
								
							  }
							 },
									triggerAction:'all'
								},
								
								{
									xtype :'textfield',
									fieldLabel: 'Value',
									name:'value',
									enforceMaxLength  : true,
									maxLength:100,
									listeners:{
										'change': function(field, newValue, oldValue){
											field.setValue(newValue.toUpperCase());
										}
									}
								},
								{
						xtype :'combo',
						editable: false,
						allowBlank: false,
						disabled : true,
						fieldLabel: 'Value*',
						name:'ValueListName',
						displayField:'entityAttributeName',
						valueField:'entityAttributeName',
						store: entityAttrStoreEa,
						triggerAction:'all'
					},
								{
									   xtype :'datefield',
									   fieldLabel: 'Start Date',
									   name:'lStartDate',
									   editable : false,
									   itemId:'lStartDateeaF',
									   vtype:'daterange',
									   endDateField:'lEndDateeaf',
									   //minValue: new Date(),
								},
								{
									   xtype :'datefield',
									   fieldLabel: 'End Date',
									   name: 'lEndDate',
									   editable: false,
									   itemId:'lEndDateeaf',
									   vtype:'daterange',
									   startDateField:'lStartDateeaF',

									   //minValue: new Date(),
									  
								},
								{
			        		    	   xtype :'textfield',
			        		    	   fieldLabel: 'CsrfName',
									   hidden:true,
			        		    	   disabled : true,
			        		    	   name: 'csrfEaF',
									   maxLength : 100,
			        		    	   allowBlank:false,
			        		    	   id:'testCsrfEaF'
			        		    }
								
                        
                       ]
            }]
        }
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add',
    	  				
                	},
                	
/*                	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
*/                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.EaFilterCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['EaFilterList', 'EaFilterForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'EaFilterForm',
      selector: 'EaFilterForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'EaFilterList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'EaFilterList': {
          itemdblclick: this.onRowdblclick
        },
        'EaFilterForm button[action=add]': {
          click: this.doEaFilter
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	//console.log(record.data);
    	 compId = record.data.compId;
    	  condId = record.data.variableId;
    	  condRowId = record.data.variableRowId;
eaStore.load();
entityStoreEa.load();
		  
		   var  eaFilterFlag = null;
		  
		  
		  
        var win = this.getFormWindow();
		
		win.down('form').getForm().reset();
	  
	  win.down('form').getForm().applyToFields({disabled:true});
      
        win.setTitle('Edit EA Filter');
        
      

	  
	  //0
	  componentListStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					
					if(record.data.compId!=null)
					{
					win.down('form').getForm().findField('compId').enable();
					win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compId',record.data.compId));
					win.down('form').getForm().findField('compId').readOnly = true;				

				}
			
			//1

			eaVariableStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					
					if(record.data.variableName!=null)
					{
					win.down('form').getForm().findField('variableId').enable();
					win.down('form').getForm().findField('variableId').readOnly = true;
					win.down('form').getForm().findField('variableId').setValue(eaVariableStore.findRecord('variableName',record.data.variableName));
					}
			
			
			
			//2
			
			
			eaFilterDataSetStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					
					if(record.data.dataSetName!=null)
					{
					win.down('form').getForm().findField('dataSet').enable();
					win.down('form').getForm().findField('dataSet').setValue(eaFilterDataSetStore.findRecord('attributeTypeName',record.data.dataSetName));
					}
			
			
			
			
			
			
			
			//3
			
					parameterStoreEa.load({
					callback: function(records, operation, success) {
					if (success == true) {
					
					if(record.data.parameter!=null)
					{
					win.down('form').getForm().findField('parameter').enable();
					win.down('form').getForm().findField('parameter').setValue(parameterStoreEa.findRecord('paramName',record.data.parameter));
					}
					
				

					//4

					oprStoreEa.load({
					callback: function(records, operation, success) {
					if (success == true) {
					
					if(record.data.oprName!=null)
					{
					win.down('form').getForm().findField('opr').enable();
					win.down('form').getForm().findField('opr').setValue(oprStore.findRecord('oprName',record.data.oprName));
					
					}
			
			
			
					valueTypeStoreEa.load({
					callback: function(records, operation, success) {
					if (success == true) {
					
					if(record.data.valueType!=null)
					{
					win.down('form').getForm().findField('valueType').enable();
					win.down('form').getForm().findField('valueType').setValue(valueTypeStoreEa.findRecord('valueTypeName',record.data.valueType));
					
					if(record.data.valueType=='Free Text')
					{
					win.down('form').getForm().findField('value').enable();
					
					}
					else
					{
							
					entityAttrStoreEa.load({
					callback: function(records, operation, success) {
					if (success == true) {
					
					if(record.data.value!=null)
					{
					
					
								  
								  if(record.data.valueType=='Variable')
								  {
									  
									  win.down('form').getForm().findField("value").disable();
									  entityAttrStoreEa.clearFilter();
									  entityAttrStoreEa.filter('varFlag','Y');
									  entityAttrStoreEa.filter('compId',record.data.compId);
									  win.down('form').getForm().findField("ValueListName").enable();
									  win.down('form').getForm().findField("ValueListName").reset();

									  
								  }
								  
								  
								  if(combo.getValue()=='Core' || combo.getValue()=='Additional')
								  {
									  win.down('form').getForm().findField("value").disable();
									  entityAttrStoreEa.clearFilter();
									 
									  
									  var filterValue = valueTypeStoreEa.findRecord('valueTypeName',record.data.valueType);
									
									
									entityAttrStoreEa.filter(function(r) {
																var value = r.get('attrCatg');
																var value2 = r.get('attrType');
																return (value == filterValue.data.valueTypeId && value2 == entity);
															});
									
									
									  win.down('form').getForm().findField("ValueListName").enable();
									  win.down('form').getForm().findField("ValueListName").reset();

								  }

						
					
					
					}
			}
			}
			});
	  
							
							
							
					
					}
					
					}
					
					
				if(record.data.startDate!=null)
				win.down('form').getForm().findField('startDate').enable();
	 
				if(record.data.endDate!=null)
				win.down('form').getForm().findField('endDate').enable();
	 	
					
					
					if(eaFilterFlag==null)
					
					{
					
						var temp = 	parameterStoreEa.findRecord('paramName',record.data.parameter);
						
									if(temp)
									{
									
									oprStoreEa.clearFilter();
									if(temp.data.valFlag=='C')
									{
											
											if(temp.data.oprDataType=='D')
											{
											oprStoreEa.filter('dataFlag','Y');
											}
											if(temp.data.oprDataType=='N')
											{
											oprStoreEa.filter('numberFlag','Y');
											}
											if(temp.data.oprDataType=='S')
											{
											oprStoreEa.filter('stringFlag','Y');
											}
									
									
									}
									if(temp.data.valFlag=='V')
									{
									oprStoreEa.clearFilter();
									oprStoreEa.filter('oprType','R');
									}
				
				
									if(temp.data.valFlag=='AC')
									{
									if(record.data.dataSetName=='Additional' || record.data.dataSetName=='Core')
										{
										
										var entity = eaStore.findRecord('compId',compId);
										
										entity = entity.data.entityTypeName;
										
										entity = entityStoreEa.findRecord('entityName',entity);
										entity = entity.data.entityId;
									parameterStoreEa.clearFilter();
									
									parameterStoreEa.filter('valFlag','AC');
									
									
									parameterStoreEa.filter(function(r) {
																var value = r.get('attrCatg');
																var value2 = r.get('attrType');
																return (value == combo.getValue() && value2 == entity);
															});
									
									}

									}
									
									if(temp.data.valFlag=='C')
									{
									parameterStoreEa.clearFilter();
									parameterStoreEa.filter('valFlag','C');
									
									}
									
									if(temp.data.valFlag=='V')
									{
									parameterStoreEa.clearFilter();
									parameterStoreEa.filter('valFlag','V');
									
									
									}
									
				
													
				
									
					
					
					}
					
				}	
			}
			}
			});
			
			
			
			
			
			
			
			
			}
			}
			});
	  

					
			}
			}
			});
			
			
			
			}
			}
			});
	  
			
			
			
			
			}
			}
			});
				
				
				
			}
			}
			});
	  
	  
	  

			
	  

		
		
			

	  


		
		
		win.down('form').getForm().setValues(record.getData());
        
        win.setAction('edit');
      win.show();
    },
    showAddForm: function () {
    	
    	if(compName!=null)
		{
		eaStore.load();
		entityStoreEa.load();
    		var win = this.getFormWindow();
    	      win.setTitle(SchemeName);
    	      win.setAction('add');
    	      win.down('form').getForm().reset();
    	      win.show();
			  win.down('form').getForm().findField('compId').readOnly = false;
			  win.down('form').getForm().findField('variableId').readOnly = false;
			  			//  Ext.getCmp('eaFilterCompList').setValue(componentListStore.findRecord('compId',componentListStore.data.items[0].data.compId));

		}
    	else{
    		Ext.Msg.alert('Info', "Please create entity condition for componenet first");	
    	}	
      
    },
    doEaFilter: function () {
	  eaStore.load();
	  var win = this.getFormWindow();
      
      var action = win.getAction();
      if(action == 'edit') {
    	  if(win.down('form').isValid())
		  	{
    		  updateEaFilter(win);
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	} 
      }
      else {
    	  if(win.down('form').isValid())
		  	{
    		  saveEaFilter(win);
		  	}
		  	else
		  	{
		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
		  	}
      }
    }
  });
 
  
   
});
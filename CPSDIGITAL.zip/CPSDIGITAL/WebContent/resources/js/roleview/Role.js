var createUser = Ext.create('Ext.data.TreeStore', {
        root: {
            expanded: true
        },
        proxy: {
            type: 'ajax',
            url: 'resources/images/createUser.json'
        }
    });


var createPanel = Ext.create('Ext.tree.Panel', {
    id: 'tree-panel',
	
    //title: 'Navigation',
	rootVisible: false,
    border:false,
    region:'west',
	margins: '5 0 0 0',
	cmargins: '5 5 0 0',
	width: 175,
	minSize: 100,
	maxSize: 250,
    autoScroll: true,
    store: createUser,
	
});
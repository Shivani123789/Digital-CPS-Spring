Ext.onReady(function () {
	//window.open('http://localhost:8080/DSM25FEB/SpringByExample.pdf', 'Download');
   Ext.define('Scheme.view.CompList', {
    extend: 'Ext.grid.Panel',
    name:'CompGrid',
	id:'CompGrid',
    pageSize : 5,
    autoLoad:false,
	//layout: 'fit',
    alias: 'widget.CompList',
    title: 'Comp List',
    store: componentStoreGrid,
    height:500,
    autoScroll: true,
    initComponent: function () {
    	this.tbar = [{
        text    : 'Add',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
		{ header: 'Scheme Id', dataIndex: 'schemeId', width: 60 },
		{ header: 'Scheme Name', dataIndex: 'schemeName', width: 80 },
        { header: 'Comp Id', dataIndex: 'compId', width: 60 },
        { header: 'Comp Name', dataIndex: 'compName', flex: 1 },
        { header: 'Start Date', dataIndex: 'startDate', width: 80 },
        { header: 'End Date', dataIndex: 'endDate', width: 80 },
        { header: 'Freq Name', dataIndex: 'freqName', width: 80 },
        { header: 'Vertical Name', dataIndex: 'verticalName', width: 100 },
        { header: 'PayTo', dataIndex: 'payToName', width: 80 },
        { header: 'Category', dataIndex: 'category', width:80},
        { header: 'Coverage', dataIndex: 'coverageFlag', width: 60 },
        { header: 'File Name', dataIndex: 'fileName', width: 80 },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'resources/images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('CompList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Component is selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove Comp', 
                          'Are you sure you want to deleted '+rs[0].data.compName+' Component?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            	//ajax post to remove
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removeComp.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
                            			  method: 'POST',
                            			  params: {
                            				  "schemeId" : rs[0].data.schemeId,
                            				  "compId" :rs[0].data.compId
                            			    },
                            			    success: function (response) {
                             			         Ext.Msg.alert("Info","Component deleted sucessfully");
                             			        componentStoreGrid.load();
                             			       componentListStore.load();
											   componentListStoreCov.load();
											   componentListStoreTq.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			   
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : componentStoreGrid,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.CompForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.CompForm',
      title   : 'Add Comp',
      //enctype : 'multipart/form-data', 
      //headers: {'Content-Type':'multipart/form-data;'},
     // encoding :'multipart/form-data',
      //width   : 350,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [
              	{
                		xtype:'fieldset',
                		anchor: '100%',
                		title: 'Componenet Details',
                		collapsible: true,
                		layout: 'column',
                		defaults: {
                			anchor: '100%'
                				},
                				items :[
                				        	{
                				        		xtype: 'container',
                				        		columnWidth:.5,
                				        		layout: 'anchor',
                				        		items:[
                				        		       
                				        		       {
                				        		    	   xtype :'textfield',
                				        		    	   fieldLabel: 'Comp Name*',
                				        		    	   name: 'compName',
                				        		    	   maxLength : 50,
                				        		    	   id:'compName420420',
														   enforceMaxLength:"true",
														   //maskRe:/[A-Za-z0-9_- ]/,
                				        		    	   allowBlank:false
                				        		       },
                				        		       {
                				        		    	   xtype :'datefield',
                				        		    	   fieldLabel: 'Start Date*',
                				        		    	   name: 'startDate',
														   itemId: 'startDatecomp',
                				        		    	   editable: false,
                				        		    	   allowBlank:false,
														   vtype: 'daterange',
														   endDateField: 'endDatecomp'
														  // value : new Date(date.getFullYear(), date.getMonth(), 1)
                				        		       },
                				        		       
                				        		       {
                				        		    	   xtype :'datefield',
                				        		    	   fieldLabel: 'End Date*',
                				        		    	   name: 'endDate',
														   itemId: 'endDatecomp',
														   vtype: 'daterange',
														   startDateField: 'startDatecomp',
                				        		    	   allowBlank:false,
                				        		    	   editable: false
														//   value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
                				        		       },
            		
                				        		       {
 														xtype :'combo',
 														fieldLabel: 'Payout Type*',
 														name:'freqId',
 														displayField:'description',
 														valueField:'freqId',
 														editable: false,
 														allowBlank:false,
 														store: freqStore,
 														triggerAction:'all'
 													}
                				        		       ]
                				        	},
                				        	{
                				                xtype: 'container',
                				                columnWidth:.5,
                				                layout: 'anchor',
                				                items: [
                				                       
 													
 													{
 														xtype :'combo',
 														fieldLabel: 'Vertical*',
 														name:'verticalId',
 														displayField:'verticalName',
 														valueField:'verticalId',
 														editable: false,
 														allowBlank:false,
 														store: verticalStore,
 														triggerAction:'all'
 														/*queryMode: 'local',
 														forceSelection: true,
 														triggerAction: 'all',
 														enableKeyEvents: true,
 														selectOnFocus:true,
 														typeAhead: true,
 														disableKeyFilter: true*/
 													},
 													
 													{
 														xtype :'combo',
 														fieldLabel: 'Pay To*',
 														name:'payTo',
														id:'payTo',
 														displayField:'displayValue',
 														valueField:'entityTypeId',
 														editable: false,
 														allowBlank:false,
 														store: payToStore,
 														triggerAction:'all'
 														/*queryMode: 'local',
 														forceSelection: true,
 														triggerAction: 'all',
 														enableKeyEvents: true,
 														selectOnFocus:true,
 														typeAhead: true,
 														disableKeyFilter: true*/
 													},
 													
 													{
 														xtype:'combo',
 														fieldLabel: 'Category*',
 														name:'category',
 														displayField:'category',
 														valueField:'categoryId',
 														editable:false,
 														allowBlank:false,
 														store:categoryStore,
 														triggerAction:'all'
 													/*	queryMode: 'local',
 														forceSelection: true,
 														triggerAction: 'all',
 														enableKeyEvents: true,
 														selectOnFocus:true,
 														typeAhead: true,
 														disableKeyFilter: true*/
 													},

 													{
 														xtype :'combo',
 														fieldLabel: 'Upload List*',
 														name:'uploadId',
 														editable: false,
 														displayField:'uploadName',
 														allowBlank:false,
 														valueField:'uploadId',
 														store: CreateUploadList(),
 														listeners: {
 															'select': function(combo, value){
 															
 															if(combo.getValue()==1)
 																{
																
																formPanel.items.each(function(c){
																
																//c.items.items[3].setDisabled(true);
            
																})//form.reset();
																
 																this.up('window').down('form').getForm().findField("coverageFlag").enable();
 																this.up('window').down('form').getForm().findField("fileName").enable();
 															//	this.up('window').down('form').getForm().findField("fileUpload").enable();

 																}
 															else
 																{
																
																
																formPanel.items.each(function(c){
																
																c.items.items[3].setDisabled(false);
            
																});//
 																this.up('window').down('form').getForm().findField("coverageFlag").disable();
 																this.up('window').down('form').getForm().findField("fileName").disable();
 																//this.up('window').down('form').getForm().findField("fileUpload").disable();

 																}
 															
 															}
 															},
 														triggerAction:'all'
 													},
 													
 													{
 														xtype :'combo',
 														fieldLabel: 'List Type',
 														name:'coverageFlag',
														editable: false,
														disabled : true,
 														displayField:'covFlag',
 														valueField:'covFlag',
 														store: uploadStore,
 														triggerAction:'all'
 													},
 												
 													{
 	               				        		    	   xtype :'textfield',
 	               				        		    	   fieldLabel: 'File Name',
														   disabled : true,
 	               				        		    	   name: 'fileName',
														   maxLength : 100,
 	               				        		    	   allowBlank:false
 	               				        		    },
 	               				        		    
 	               				        		{
	               				        		    	   xtype :'textfield',
	               				        		    	   fieldLabel: 'CsrfNameSc',
														   hidden:true,
	               				        		    	   disabled : true,
	               				        		    	   name: 'csrfName',
														   maxLength : 100,
	               				        		    	   allowBlank:false,
	               				        		    	   id:'testCsrfComp'
	               				        		    }
 	               				        		/*{
 	               				                    xtype: 'fileuploadfield',
 	               				                    name: 'fileUpload',
													hidden : true,
 	               				                    disabled : true,
 	               				                    emptyText: 'Select a document to upload...',
 	               				                    fieldLabel: 'File',
 	               				                    buttonText: 'Upload'
 	               				                }
                				                       */ 
                				                       ]
                				            }
                				        
                				        
                				        ]}
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add'
                	},
                	
                	/*{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},*/
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.CompCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['CompList', 'CompForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'CompForm',
      selector: 'CompForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'CompList > toolbar > button[action=add]': {
        	
        	
          click: this.showAddForm
        },
        'CompList': {
          itemdblclick: this.onRowdblclick
        },
        'CompForm button[action=add]': {
          click: this.doAddComp
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    //	console.log(record.data);
      var win = this.getFormWindow();
      win.setTitle('Edit Component');
      compId = record.data.compId;
      schemeId  = record.data.schemeId;
	  
	  win.down('form').getForm().applyToFields({disabled:true});
	  
	  win.down('form').getForm().findField('compName').enable();
	  //	win.down('form').getForm().findField('compName').readOnly=true;
	  //	Ext.getCmp('compName420420').setReadOnly(true);
	  //	win.down('form').getForm().findField('compName').setReadOnly(true);
	//	win.down('form').getForm().findField('compName').value = 'readonly';
	  
	  
	  
	  if(record.data.startDate!=null)
	  win.down('form').getForm().findField('startDate').enable();
	 
	if(record.data.endDate!=null)
	  win.down('form').getForm().findField('endDate').enable();
	 
	  freqStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					win.down('form').getForm().findField('freqId').enable();
					win.down('form').getForm().findField('freqId').setValue(freqStore.findRecord('description',record.data.freqName));
			
			}
			}
			});
			
			verticalStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					win.down('form').getForm().findField('verticalId').enable();
				win.down('form').getForm().findField('verticalId').setValue(verticalStore.findRecord('verticalName',record.data.verticalName));
			
			}
			}
			});

			
			payToStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					win.down('form').getForm().findField('payTo').enable();
				      win.down('form').getForm().findField('payTo').setValue(payToStore.findRecord('displayValue',record.data.payToName));

			
			}
			}
			});
			
			categoryStore.load({
				callback: function(records, operation, success) {
				if (success == true) {
				win.down('form').getForm().findField('category').enable();
			      win.down('form').getForm().findField('category').setValue(categoryStore.findRecord('category',record.data.category));

		
		}
		}
		});

       if(record.data.fileName==null)
    {
			win.down('form').getForm().findField('uploadId').enable();
    	      win.down('form').getForm().findField('uploadId').setValue(CreateUploadList().findRecord('uploadName','NO'));
    	      win.down('form').getForm().findField("coverageFlag").disable();
       	   win.down('form').getForm().findField("fileName").disable();
		  // win.down('form').getForm().findField("fileUpload").disable();

    }
       else
       	{
		
		
				win.down('form').getForm().findField('uploadId').enable();
				uploadStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					win.down('form').getForm().findField("coverageFlag").enable();
				 win.down('form').getForm().findField('coverageFlag').setValue(uploadStore.findRecord('covFlag',record.data.coverageFlag));

				win.down('form').getForm().findField("fileName").enable();
				// win.down('form').getForm().findField("fileUpload").enable();

     	      //win.down('form').getForm().findField('uploadId').setValue(CreateUploadList().findRecord('uploadName','YES'));
    	   

			
			}
			}
			});


     	      
       	}
    	   
      win.setAction('edit');
      win.setRecordIndex(record.data.compId);
      win.down('form').getForm().setValues(record.getData());
      win.show();
	 // payToStore.load();
	  
//	  Ext.getCmp('payTo').setValue(payToStore.findRecord('entityTypeId',payToStore.data.items[0].data.entityTypeId));

    },
    showAddForm: function () {
      var win = this.getFormWindow();
      win.setTitle(SchemeName);
      win.setAction('add');
      win.show();
	  win.down('form').getForm().reset();
	  //win.down('form').getForm().findField('compName').enable();
	  //win.down('form').getForm().findField('compName').readOnly = false;
	  //Ext.getCmp('compName420420').setReadOnly(false);
	  //	win.down('form').getForm().findField('compName').setReadOnly(false);
	  win.down('form').getForm().findField('freqId').setValue(freqStore.findRecord('freqId',5));
    },
    doAddComp: function () {
      var win = this.getFormWindow();
      var action = win.getAction();
      //alert(document.cookie);
      Ext.getCmp("testCsrfComp").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
      if(action == 'edit') {
    	 
    	  if(win.down('form').isValid())
		  	{
    		  updateComp(win);
		  	}
		  	else
		  	{
		  		Ext.Msg.alert('Info', "Please fill all mandatory fields");
		  	}
    	  
    	    
      }
      else {
    	  
    		  	if(win.down('form').isValid())
    		  	{
    		  		saveComp(win);
    		  	}
    		  	else
    		  	{
    		  		Ext.Msg.alert('Info', "Please fill all mandatory fields");
    		  	}
    	 
  		}
  
    }
  });
   
});


var compGridStatus = 0;
var searchCompGridStatus = 0;
var compId = null;
var schemeId = null;








function updateComp(compForm)
{

	//alert("Update Comp ..............."+compForm.down('form').getForm().findField("csrfName").getValue());
	compForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/updateComp.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
		// headers: {'Content-Type':'multipart/form-data;'},
		 params: {
			  "compId" : compId,
			  "schemeId":schemeId
		    },
		 success: function(form, action) {
			// alert("update success ..........");
			// if(action.result != null)
		            Ext.Msg.alert('Warning', action.result.errorMessage);
			// alert("action.result.errorMessage :::: "+action.result.errorMessage);
           // Ext.Msg.alert('Component Updated Sucessfully');
            searchcomponentStoreGrid.load();
            componentStoreGrid.load();
            componentListStore.load();
            compForm.close();
            
        },
        failure: function(form, action) {
        	//alert("update error ..........");
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        	
        }
    });
	
}



function saveComp(compForm)
{
	//alert("Save Comp .......................");
	//alert("Update Comp d..............."+compForm.down('form').getForm().findField("csrfName").getValue());
	compForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/addComp.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 //enctype : 'multipart/form-data',
		// headers: {'Content-Type':'multipart/form-data;'},
		 method : 'POST',
		 /*params: {
			  //"compId" : compId,
			  "schemeId":compForm.down('form').getForm().findField("schemeId").getValue(),
		    },*/
		 success: function(form, action) {
			// if(action.result != null)
		            Ext.Msg.alert('Warning', action.result.errorMessage);
		//	 alert("'Warning'"+action.result.errorMessage);
            //Ext.Msg.alert('Component Created Sucessfully');
            compName = 'yes';
            componentStoreGrid.load();
            componentListStore.load();
			componentListStoreCov.load();
			componentListStoreTq.load();
			componentListStorePo.load();
            compForm.close();
			formPanel.items.each(function(c){
		    	
			c.items.items[2].setDisabled(false);
						c.setActiveTab(c.items.items[2]);
						c.items.items[3].setDisabled(false);
						c.items.items[4].setDisabled(false);
            
			});//form.reset();
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		console.log(action);
        		//if(action.response.status=403)
        		//	Ext.Msg.alert('Warning','Access Denied' );
        		//else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        }
    });
	//alert("hii");
	
}



function CreateUploadList() {
    var store = new Ext.data.SimpleStore({
        fields: ['uploadId', 'uploadName'],
        data: [['1', 'Yes'], ['2', 'No']]
    });
    return store;
}
	 
	
var schemeStore = new Ext.data.JsonStore({
		idProperty: 'schemeINputId',
		xtype: 'jsonstore',
		//autoLoad: true,
		autoLoad:false,
		//root: 'data',
		mode: 'local',
		totalProperty: 'schemeINputId',
		fields: ['schemeINputId','schemeName'],
        proxy: new Ext.data.HttpProxy({
                    url: 'payoutcondition/getScheme.action',
                    method: 'POST',
                    reader:{
                    	type:'json',
                    	root:'data'
                    	} 
                })
    });

	
	var compList = Ext.create('Ext.form.Panel', {
	 	url: addSchemeUrl,
	 	border: false,
		//minSize: 75,
	 	//height:600,
		//layout: 'fit',
	 	
	   items:[{
		   
	     		xtype:'fieldset',
	     		//title: 'Edit Scheme',
	     		//collapsible: true,
	     		//layout: 'anchor',
				//layout: 'fit',
	     		border:false,
	     		height:500,
	     		
	     		defaults: {
	     //		anchor: '100%'
	     //			width:230
	     		
	     		},
	     		items :[
	     			{
	             		html: "<div id='complistForm'></div>",
	             		xtype: "fieldset",
					//	layout: 'fit',
	             		border:false,
	             		
	             		
	     			}
	             	
	     		]}
	     	
	   ]});
	
	
	var searchCompList = Ext.create('Ext.form.Panel', {
	 	url: addSchemeUrl,
	 	border: false,
	 	//height:600,
	 	
	   items:[{
		   
	     		xtype:'fieldset',
	     		//title: 'Edit Scheme',
	     		//collapsible: true,
	     		layout: 'anchor',
	     		border:false,
	     		height:500,
	     		autoscroll:true,
	     		defaults: {
	     		anchor: '100%'
	     //			width:230
	     		
	     		},
	     		items :[
	     			{
	             		html: "<div id='searchcomplist'></div>",
	             		xtype: "fieldset",
	             		border:false,
	             		autoscroll:true
	             		
	     			}
	             	
	     		]}
	     	
	   ]});


	//Main Panels
	
	

	

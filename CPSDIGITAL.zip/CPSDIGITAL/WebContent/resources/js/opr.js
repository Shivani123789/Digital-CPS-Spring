
function CreateLoprStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['oprId', 'oprName'],
        data: [['0', '_BLANK'],['1', 'AND'], ['2', 'OR']]
    });
    return store;
}

function CreateInsertRowStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'displayName'],
        data: [['0', 'Last Row'],['1', 'Next Row'], ['2', 'Previous Row']]
    });
    return store;
}

function fileEmailListStore() {
    var store = new Ext.data.SimpleStore({
		mode: 'local',
    	remoteFilter: true,
        fields: ['typeId','docFileType'],
        data: [['2','NFA DOC'], ['9', 'Mail List']]
    });
    return store;
}

function CreateGrossNetStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['1', 'Gross'], ['2', 'Net']]
    });
    return store;
}

function CreatesubmitSchemeFilterStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['1', 'Unsubmitted'], ['2', 'Failed']]
    });
    return store;
}

function dumpSchemeFilterStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['1', 'Approved'], ['2', 'Draft'],['3', 'Rejected']]
    });
    return store;
}

function dataReportStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['idReport', 'nameReport'],
        data: [['1', 'A'], ['2', 'D'],['3', 'R']]
    });
    return store;
}

/*function viewSchemeFilterStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['1', 'Intial'], ['2', 'Ready For Submit'],['3', 'Draft'],['4', 'Rejected'],['5', 'Approved'],['6', 'Closed']]
    });
    return store;
}
*/
function viewSchemeFilterStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['I', 'Intial'], ['W', 'Ready For Submit'],['D', 'Draft'],['R', 'Rejected'],['A', 'Approved'],['C', 'Closed']]
    });
    return store;
}

function viewSchemeFileNameFilterStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['1', 'All(Y & N)'], ['2', 'Yes'],['3', 'No']]
    });
    return store;
}


function editSchemeFilterStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['1', 'Intial'], ['2', 'Ready For Submit'],['3', 'Draft']]
    });
    return store;
}


function postExecSchemeCsvStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['1', 'Distributor'], ['2', 'Retailer'],['3', 'Payout']]
    });
    return store;
}

function eaDataSetStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['dataSetId', 'dataSetName'],
        data: [['1', 'Condition'],['2', 'Variable']]
    });
    return store;
}

function bulkUploadFileStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['fileTypeId', 'fileName'],
        data: [['1', 'SCHEME_CONF'], ['2', 'ADD_ENTITY_ATTRIBUTE'],['3', 'ADD_PERF_PARAM_ACT'],['6', 'ADD_PERF_PARAM_DIST'],['7', 'ADD_PERF_PARAM_RET'],['8', 'ADD_PERF_PARAM_DSE'],['4', 'EXCLUSION_INCLUSION'],['5', 'MANUAL_PAYOUT']]
    });
    return store;
}

function schemeRejectTypeStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['id', 'name'],
        data: [['1', 'Reject'], ['2', 'Return for Revision']]
    });
    return store;
}


function sentToVtopUpStore() {
    var store = new Ext.data.SimpleStore({
		mode: 'local',
    	remoteFilter: true,
        fields: ['id', 'type','name'],
        data: [['1', '1','vTopUp Payment'], ['4', '3', 'Idea Money Payment'], ['2', '2', 'OTF Payment'],['3', '2' , 'OFFLINE Payment']]
    });
    return store;
}


function vtopUpOTFSubStore() {
    var store = new Ext.data.SimpleStore({
    	idProperty: 'id',
    	mode: 'local',
    	remoteFilter: true,
    	totalProperty: 'id',
        fields: ['id', 'type','name'],
        data: [['1', '1','Download Distributor File'], ['2', '1','Download Retailer File'],['3', '2','Download Distributor File'], ['4', '2','Download Retailer File'],['5', '3','Download Distributor File'], ['6', '3','Download Retailer File'],['7', '3','Download TSE/TSM File'], ['8', '3','Download ASM File'],['9','3', 'Download ZBM File']]
    });
    return store;
}


function transDataStore() {
    var store = new Ext.data.SimpleStore({
    	 autoLoad: true,
         autoSync: true,
         remoteFilter: true,
     	totalProperty: 'id',
        fields: ['id', 'name'],
        data: [['1', 'Scheme Data'], ['2', 'Payment Data'],['3', 'Universe Data'], ['4', 'Statement Data']]
    });
    return store;
}

function transSubDataStore() {
    var store = new Ext.data.SimpleStore({
    	 autoLoad: true,
         autoSync: true,
         remoteFilter: true,
     	totalProperty: 'id',
        fields: ['id', 'name'],
        data: [['1', 'Transaction'], ['2', 'Aggregation'],['3', 'Coverage List'], ['4', 'Payout Condition'], ['8', 'Target']]
    });
    return store;
}

function circleSchedularMonthStore() {
    var store = new Ext.data.SimpleStore({
    	idProperty: 'id',
    	mode: 'local',
    	remoteFilter: true,
    	totalProperty: 'id',
        fields: ['id', 'type','name'],
        data: [['01', 'JAN','JANUARY'], ['02', 'FEB','FEBRUARY'],['03', 'MAR','MARCH'], ['04', 'APR','APRIL'],['05', 'MAY','MAY'], ['06', 'JUN','JUNE'],['07', 'JUL','JULY'], ['08', 'AUG','AUGUST'],['09','SEP', 'SEPTEMBER'],['10', 'OCT','OCTOBER'], ['11', 'NOV','NOVEMBER'],['12','DEC', 'DECEMBER']]
    });
    return store;
}

function circleSchedularYearStore() {
    var store = new Ext.data.SimpleStore({
    	idProperty: 'id',
    	mode: 'local',
    	remoteFilter: true,
    	totalProperty: 'id',
        fields: ['id', 'type'],
        data: [['2015', '2015'], ['2016', '2016'],['2017', '2017'], ['2018', '2018'],['2019', '2019'], ['2020', '2020']]
    });
    return store;
}

function hierarchyMismatchStore() {
    var store = new Ext.data.SimpleStore({
    	idProperty: 'id',
    	mode: 'local',
    	remoteFilter: true,
    	totalProperty: 'id',
        fields: ['id', 'type'],
        data: [['DSM1 AND FTA', 'DSM Vs FTA'], ['DSM1 AND VTOPUP', 'DSM Vs VTOPUP'],['FTA AND VTOPUP', 'FTA Vs VTOPUP']]
    });
    return store;
}

function holdPayStore() {
    var store = new Ext.data.SimpleStore({
    	idProperty: 'id',
    	mode: 'local',
    	remoteFilter: true,
    	totalProperty: 'id',
        fields: ['id', 'type'],
        data: [['1', 'Payee Id'], ['2', 'vTopUp Number'],['3', 'FTA Number']]
    });
    return store;
}

function relPayStore() {
    var store = new Ext.data.SimpleStore({
       	mode: 'local',
    	remoteFilter: true,
    	totalProperty: 'id',
        fields: ['id', 'type','filter'],
        data: [['1','All','1'],['2', 'Payee Id','2'], ['3', 'vTOPUP Number','2'],['4', 'FTA Number','2']]
    });
    return store;
}

function holdAmtVtopUpStore() {
    var store = new Ext.data.SimpleStore({
		mode: 'local',
    	remoteFilter: true,
        fields: ['id', 'type','name'],
        data: [['1', '1','vTopUp Payment'], ['4', '3', 'Idea Money Payment']]
    });
    return store;
}





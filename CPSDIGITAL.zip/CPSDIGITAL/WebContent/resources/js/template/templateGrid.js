Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);

	function templateDownload()
	{

		var grid = Ext.ComponentQuery.query('TemplateList')[0];
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		Ext.Msg.confirm('Scheme Template', 
				'Download Scheme Template', 
				function (button) {
			if (button == 'yes') {
				var urlParam = './csv/downloadSchemeTemplates.action?sno='+rs[0].data.sno +'&fileType='+rs[0].data.fileType;
				window.open(urlParam,'_SELF');

			}
		});
	}




	Ext.define('Scheme.view.TemplateList', {
		extend: 'Ext.grid.Panel',
		id:'tempGrid',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:525,
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TemplateList',
		//title: 'Statement Generation',
		store: templateGrid,
		//height:500,
		autoScroll: true,

		initComponent: function () {
			var me = this;
			this.tbar = [
			         //    stmGenSearch
			             ];
			this.columns = [
			                { header: 'S.No', dataIndex: 'sno', width:50 },
			                { header: 'File Type', dataIndex: 'fileType', flex: 1},
			                { header: 'File Naming Convention', dataIndex: 'fileName', flex: 1 },
			                { header: 'Example', dataIndex: 'example', flex: 1 },
			               // { header: 'Download Template', dataIndex: 'downloadTempl', flex: 1 },
			                {
	    	                	header: 'Download Template',dataIndex: 'downloadTempl', width: 100,
	    	                	renderer: function (v, m, r) {
	    	                		var id = Ext.id();
	    	                		Ext.defer(function() {
	    	                			Ext.widget('button', {
	    	                				renderTo: id,
	    	                				//		disabled : true,
	    	                				text: 'Download',
	    	                				scale: 'small',
	    	                				handler: function() {
	    	                					templateDownload();;
	    	                				}
	    	                			});
	    	                		}, 700);
	    	                		return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                }
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : templateGrid,
				dock : 'bottom',
				displayInfo : true
			}
			];

			this.callParent(arguments);
		},





	});


	Ext.define('Scheme.controller.TemplateCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],

		views   : ['TemplateList'],


	});



});
var poGridStatus = 0;
var spoGridStatus = 0;
var freeTextDataType = null; 
var poCompId = null;
var poCondId = null;










	
	function updatePOCondPanel(compIdUpdt)
	
	{
	
		var temp = null;
 	
	
			poStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
    
				condBodyPo  += '<p><b>Po Condition</b></p>';
				condBodyPo  += '<hr>';
			var temp = 0;
			var tempRow = 1;	
			for (i = 0; i < poStore.data.items.length; i++) {
	
			var string = poStore.data.items[i].data;
			
			if(string.compId==compIdUpdt)
			{
			if(temp!=string.condId)
			{
			
			if(string.condId!=1)
			condBodyPo += '<hr>';
					condBodyPo  += '<p><b>Cond No: &nbsp;'+string.condId+'</b></p>';
					
					
			//alert(string.value);
			temp = string.condId;
			}
			
			
			if(string.endDate)
			condBodyPo  += '<p><b>'+string.inputType+'&nbsp;'+string.inputParameter+'&nbsp;'+string.oprName+'&nbsp;'+string.valueType+'&nbsp;'+string.value+'&nbsp; Between&nbsp;'+string.startDate+'&nbsp'+string.endDate+'&nbsp;'+string.loprName+'';
			else
			condBodyPo  += '<p><b>'+string.inputType+'&nbsp;'+string.inputParameter+'&nbsp;'+string.oprName+'&nbsp;'+string.valueType+'&nbsp;&nbsp'+string.value+'&nbsp;'+string.loprName+'';
			
			
			
			
			
			if((string.lopr==26)||(string.lopr==23))
			{
			
			condBodyPo  += '<p><b>&nbsp;'+string.grossNet+'&nbsp;('+string.unitName+'&nbsp;'+string.amount+'&nbsp;'+string.paymentVariable+'&nbsp;'+string.overAch+'&nbsp;'+string.underAch+'&nbsp</p></b>';
			

			}
			
			
	}
				 	
	}
	
			detailcondpo.hide().update(condBodyPo).slideIn('l', {stopAnimation:true,duration: 200});
               

				  } else {
            // the store didn't load, deal with it
        }
    }
    // scope: this,
});
	
	
	
	
	
	
	}






function savePo(coverageForm)
{

	coverageForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/addPo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
        
		 success: function(form, action) {
            Ext.Msg.alert('Payout Condition Created Sucessfully');
            
			
			componentListStorePo.load();
			poStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					condBodyPo  = '<p><b>Payout Condition</b></p>';
					condBodyPo  += '<hr>';
                  
			if((action.result.poData.rlopr==1)||(action.result.poData.lopr==2))
			{
			
			componentStoreGrid.load({
			callback: function(records, operation, success)
			{
			if(success==true)
			{
			
			var compName = componentStoreGrid.findRecord('compId',action.result.poData.compId);
			condBodyPo  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
			updatePOCondPanel(action.result.poData.compId);
			
			}
			}
			});
			
			coverageForm.down('form').getForm().reset();
			
			Ext.getCmp('poCompList').setValue(componentListStore.findRecord('compId',action.result.poData.compId));
			coverageForm.down('form').getForm().findField('compId').readOnly = true;
			
			}
			
			else
			{
			coverageForm.close();
			
			
			
			}
			
			   
			  
			
			}
			}
			});
            
			
        },
        failure: function(form, action) {
        	if(action.result != null)
				Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        	//	if(action.response.status=403)
        	//		Ext.Msg.alert('Warning','Access Denied' );
        	//	else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        }
    });
	
}


function updatePo(coverageForm)
{

	coverageForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/updatePo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
        
		 params: {
			  "compId" : poCompId,
			  "condId":	poCondId,
			  "condRowId" : condRowIdPo
		    },
		 success: function(form, action) {
            Ext.Msg.alert('Payout condition updated successfully');
            poFilterValues.load();
           	componentListStorePo.load();
			poStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					condBodyPo  = '<p><b>Payout Condition</b></p>';
					condBodyPo  += '<hr>';
                  
			if((action.result.poData.rlopr==1)||(action.result.poData.lopr==2))
			{
			
			componentStoreGrid.load({
			callback: function(records, operation, success)
			{
			if(success==true)
			{
			
			var compName = componentStoreGrid.findRecord('compId',action.result.poData.compId);
			condBodyPo  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
			updatePOCondPanel(action.result.poData.compId);
			
			}
			}
			});
			
			coverageForm.down('form').getForm().reset();
			
			Ext.getCmp('poCompList').setValue(componentListStore.findRecord('compId',action.result.poData.compId));
			coverageForm.down('form').getForm().findField('compId').readOnly = true;
			
			}
			
			else
			{
			coverageForm.close();
			
			
			
			}
			
			   
			  
			
			}
			}
			});
            
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribute Mapping Error");
        	}
        }
    });
	
}



var poList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	
   items:[{
	   
     		xtype:'fieldset',
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     		
     		},
     		items :[
     			{
             		html: "<div id='polist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});


var spoList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	
   items:[{
	   
     		xtype:'fieldset',
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     		
     		},
     		items :[
     			{
             		html: "<div id='spolist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);

	var hdfilter=null;
	var paymentTypeHP = null;
	var ftaNumber = null;
	var vtopupNumber = null;
	var producerId = null;
	var payToId=null;
	var totalHoldAmount=0;
	
	function submitHoldAmount(totAmt,holdAmt,amt)
	{
		if(totAmt <= holdAmt + amt){
			return true;
		} else{
			return false;
		}
	}
	
	
	
	
	var holdSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border: false,
		style       : 'padding-bottom: 5px',
		layout:'column',
		anchor: '100%',
		items       : [   
{
	   xtype:'fieldset',
	   layout:'column',
	   title: 'Search Criteria',
	   height : 70,
	   width  :'100%',
	   bodyStyle:'padding:3px 0px',
	   collapsible: true,	
	   items :[               
		               
{   xtype:'fieldset',
	title: 'Payment Start Date',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:100,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'datefield',
	        	id          : 'startDtHp',
	        	allowBlank  : false,
	        	emptyText   : 'Start Date',
	        	name        : 'startDate',
	        	editable    : false,
	        }]
},
{   xtype:'fieldset',
	title: 'Payment End Date',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:100,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'datefield',
	        	id          : 'endDtHp',
	        	allowBlank  : false,
	        	emptyText   : 'End Date',
	        	name        : 'endDate',
	        	editable    : false,
	        }]
},

{
	xtype:'fieldset',
	title: 'Payment Type',
	collapsible: false,
	layout: 'column',
	bodyStyle:'padding:4px 4px',
	defaults: {
		anchor: '100%',
		width:200,
		bodyStyle:'padding:10px 10px',
	},
	items :[
{
	xtype :'combo',
	editable: false,
	allowBlank: false,
	name:'paymentType',
	//id:'paymentIdHP1',
	disabled:false,
	emptyText   : 'Payment Type',
	displayField:'name',	
	valueField:'id',
	store: holdAmtVtopUpStore(),
	listeners: {
		'select': function(combo, value){
			Ext.getCmp("submitButtton").enable();
			if(combo.getValue()==1)
				paymentTypeHP = 'V';
			if(combo.getValue()==2)
				paymentTypeHP = 'T';
			if(combo.getValue()==3)
				paymentTypeHP = 'O';
			if(combo.getValue()==4)
				paymentTypeHP = 'I';
		}
	},
	triggerAction:'all'
}]
},

{
	xtype:'fieldset',
	title: 'Search Type',
	collapsible: false,
	layout: 'column',
	bodyStyle:'padding:4px 4px',
	defaults: {
		anchor: '100%',
		width:200,
		bodyStyle:'padding:10px 10px',
	},
	items :[
{
	xtype :'combo',
	editable: false,
	allowBlank: false,
	name:'payTo',
	id:'searchId',
	disabled:false,
	emptyText   : 'Search Type',
	displayField:'type',	
	valueField:'id',
	store: holdPayStore(),
	listeners: {
		'select': function(combo, value){
			hdfilter=combo.getValue();
		}
	},
	triggerAction:'all'
}]
},
{   xtype:'fieldset',
	title: 'Search Value',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:190,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'combo',
	        	id          : 'condParamVal',
	        	allowBlank  : true,
	        	emptyText   : 'Search Value',
	        	name        : 'condParam',
	        /*	displayField: 'producerId',
	        	valueField:'producerId',
	        	typeAhead: false,
	        	//hideLabel: true,
	        	hideTrigger:true,
	        	selectOnFocus:true,
                applyTo: 'search',
	        	anchor: '100%',
	        	store:holdDataProducers,
	        	triggerAction:'all',
	        	listeners:{
	        		 'change': function(field, newValue, oldValue){
	        			 field.setValue(newValue.toUpperCase());
	        			 holdDataProducers.load({
				  				params : {
				  					startDate:Ext.Date.format(Ext.getCmp("startDtHp").getValue(),'d-M-y') ,
			        				endDate: Ext.Date.format(Ext.getCmp("endDtHp").getValue(),'d-M-y'),
			        				payTo : hdfilter,
			        				paymentType:paymentTypeHP,
			        				condParam:newValue.toUpperCase(),
								}
							});
	        			 this.store.load({params:
		        			{
		        				startDate:Ext.Date.format(Ext.getCmp("startDtHp").getValue(),'d-M-y') ,
		        				endDate: Ext.Date.format(Ext.getCmp("endDtHp").getValue(),'d-M-y'),
		        				payTo : hdfilter,
		        				paymentType:paymentTypeHP,
		        				condParam:newValue.toUpperCase(),
		        			}});
		        		//	alert('test');
	        		 }
	        	 }*/
	        },
	        {
		    	   xtype :'textfield',
		    	   fieldLabel: 'CsrfName',
				   hidden:true,
		    	   disabled : true,
		    	   name: 'csrfHold',
				   maxLength : 100,
		    	   allowBlank:false,
		    	   id:'testCsrfHold'
		    }]
},
{
	xtype:'fieldset',
	title: 'Actions',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:'100%',
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'button',
	        	text        : 'GO',
	        	handler     : function () {
	        		Ext.getCmp("testCsrfHold").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
	        		var grid = Ext.ComponentQuery.query('HoldPayList')[0];
	        		var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDtHp").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDtHp").getValue(),'Y/m/d'));
	      			
	      			if(hdfilter == null || !(Ext.getCmp("startDtHp").getValue()) || !(Ext.getCmp("endDtHp").getValue()) || paymentTypeHP==null){
	      				Ext.Msg.alert("Warning","<font color='blue'>Please enter 'Payment Start & End Date', 'Payment Type', 'Search Type' & 'Search Value'</font>");
	      				return false;
	      			}
	      			
	      			if(flag && hdfilter != null){

	      				Ext.Ajax.request({
	      					dataType : 'json',
	      					contentType : 'application/json',
	      					url : 'searchscheme/getTotalHoldAmount.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
	      					method: 'POST',
	      					params: {
	      						startDate:Ext.Date.format(Ext.getCmp("startDtHp").getValue(),'d-M-y') ,
	      						endDate: Ext.Date.format(Ext.getCmp("endDtHp").getValue(),'d-M-y'),
	      						payTo : hdfilter,
	      						paymentType:paymentTypeHP,
	      						isMaster:true,
	      						isStage:false,
	      						condParam:Ext.getCmp("condParamVal").getValue(),
	      						page:1,
	      						start :	0
	      					},
	      					success: function (response) {
	      						var jsonResp = Ext.JSON.decode(response.responseText);
	      						
	      						//Ext.Msg.alert("Info",jsonResp.holdAmt);
	      						Ext.getCmp('totalAmtID').setValue(jsonResp.totalAmount);
	      						Ext.getCmp('holdAmtId').setValue(jsonResp.holdAmt);
	      						producerId = jsonResp.producerId;
	      						ftaNumber = jsonResp.ftaNumber;
	      						vtopupNumber = jsonResp.vtopupNumber;
	      						payToId = jsonResp.payToId;
	      						totalHoldAmount=jsonResp.netHoldAmt;
	      						grid.store.load({params:
	      						{
	      							startDate:Ext.Date.format(Ext.getCmp("startDtHp").getValue(),'d-M-y') ,
	      							endDate: Ext.Date.format(Ext.getCmp("endDtHp").getValue(),'d-M-y'),
	      							payTo : hdfilter,
	      							paymentType:paymentTypeHP,
	      							isMaster:true,
	      							isStage:false,
	      							condParam:Ext.getCmp("condParamVal").getValue(),
	      							page:1,
	      							start :	0
	      						}});
	      						Ext.getCmp('holdToAmtID').setValue("");
	      					}
	      				});
	      			}
	        	}				
	        }]
}


]
},

{
	xtype:'fieldset',
	layout:'column',
	title: 'Submit Hold Amount & Download',
	height : 70,
	width  :'100%',
	bodyStyle:'padding:3px 0px',
	collapsible: true,	
	items :[    
{   xtype:'fieldset',
	title: 'Total Payment',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:100,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'textfield',
	        	id          : 'totalAmtID',
	        	allowBlank  : true,
	        	emptyText   : 'Total Payment',
	        	name        : 'totalAmt',
	        	editable    : false,
	        	readOnly    : true,
	        }]
},
{   xtype:'fieldset',
	title: 'Hold Amount',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:100,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'textfield',
	        	id          : 'holdAmtId',
	        	allowBlank  : true,
	        	emptyText   : 'Hold Amount',
	        	name        : 'holdAmt',
	        	editable    : false,
	        	readOnly    : true,
	        }]
},
{   xtype:'fieldset',
	title: 'Amount to Hold',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:100,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'numberfield',
	        	id          : 'holdToAmtID',
	        	allowBlank  : true,
	        	emptyText   : 'Enter Amount',
	        	name        : 'holdToAmt',
	        	allowNegative: false,
		    	minValue: 0,
		    	decimalPrecision:0
	        }]
},
{
	xtype:'fieldset',
	title: 'Submit',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '10%',
		width:50,
		height:40,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'image',
	        	id : 'upImageVar',
	        	//text        : '',
	        	src : 'resources/images/hold_amount.jpg',
	        	listeners     :
	        		{
	        		afterrender : function (me) {
	        			me.getEl().on('click', function() {	
	        				
	        		var amt =parseInt(Ext.getCmp("holdToAmtID").getValue());
	        		//var hamt=parseInt(Ext.getCmp("holdAmtId").getValue());
	        		var hamt=parseInt(totalHoldAmount);
	        		var totamt = parseInt(Ext.getCmp("totalAmtID").getValue());
	        		if(totamt >= (amt+hamt) && amt!=0){
	        		Ext.Msg.confirm('Hold Amount Confirmation', 
	        		                          //'Are you sure you want to do hold Amount', 
	        				 'Are you sure to proceed with this request (Hold amount) ?',
	        		                          function (button) {
	        			if (button == 'yes') {
	        				Ext.ux.mask.show();
	        				Ext.Ajax.request({
	        					url : 'searchscheme/saveHoldDataAmt.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
	        					method: 'POST',
	        					params: {
	        						holdAmt: Ext.getCmp("holdToAmtID").getValue(),
	        						ftaNumber:ftaNumber ,
	        						vtopupNumber: vtopupNumber,
	        						producerId:	producerId,
	        						paymentType: paymentTypeHP,
	        						payToId:payToId,
	        					},
	        					success: function (response) {
	        						Ext.ux.mask.hide();
	        						var jsonResp = Ext.JSON.decode(response.responseText);
	        						console.log(jsonResp	);
	        						if(jsonResp.success==false)	
	        						{
	        							Ext.Msg.alert("Error",jsonResp.errorMessage);
	        						}
	        						else{
	        							Ext.Msg.alert("Info",jsonResp.errorMessage);
	        							//var subtot=parseInt(Ext.getCmp("holdAmtId").getValue());;//totalHoldAmount
	        							var subtot=parseInt(totalHoldAmount);;//
	        							subtot+= parseInt(Ext.getCmp("holdToAmtID").getValue());
	        							Ext.getCmp('holdAmtId').setValue(subtot);
	        							totalHoldAmount=parseInt(subtot);
	        						}
	        						Ext.getCmp('holdToAmtID').setValue("");
	        					},
	        					failure: function (response) {
	        						Ext.ux.mask.hide();
	        					}
	        				});
	        			}
	        			else
	        			{
	        				Ext.ux.mask.hide();
	        			}
	        		});
	        		}else{
	        			//Ext.Msg.alert("Warning","<font color='blue'>Hold amount should not be greater than total payment or Zero Hold amount is not allowed.</font>");
	        			if( amt==0 ){
	        				Ext.Msg.alert("Warning","<font color='red'>'Amount to Hold' is 0</font> <br><font color='blue'>Please enter a valid 'Hold amount'</font>");
	        			}else
	        			if(totamt<=(amt+hamt)){
	        				Ext.Msg.alert("Warning","<font color='red'>You can not hold an amount which is more than 'Total Payment'</font>");
	        			}else{
	        				Ext.Msg.alert("Warning","<font color='red'>'Amount to Hold' is blank</font> <br><font color='blue'>Please enter a valid 'Hold amount'</font>");	
	        			}
	        		}
	        	});
	        		}
	        		}
	        }]
},
{
	xtype:'fieldset',
	title: 'Download File',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:50,
		height:40,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'image',
	        	//text        : 'Download',
	        	src         : 'resources/images/csv_download.jpg' ,
	        	listeners   :  
	        		{
	        		afterrender : function (me) {
		        		
	        			me.getEl().on('click', 	function () {
	        				
	        		   var urlParam1;
 	        		   Ext.Msg.confirm('Hold Data', 
 	       					'Download Hold Data CSV', 
 	       					function (button) {
 	       				if (button == 'yes') {
 	       					waitMsg : 'Loading...',
 	       					urlParam1 = './csv/holdDataDownloadCSV.action?startDate='+Ext.Date.format(Ext.getCmp("startDtHp").getValue(),'d-M-y')+'&endDate='+Ext.Date.format(Ext.getCmp("endDtHp").getValue(),'d-M-y')+
 	       					'&payTo='+hdfilter+'&paymentType='+paymentTypeHP+'&condParam='+Ext.getCmp("condParamVal").getValue();
 	       					window.open(urlParam1,'_BLANK');
 	       				}
 	       			});
	        	});
	        		}
	        		}
	        }]
}

]
}
]
	});

	
	Ext.define('Scheme.view.HoldPayList', {
		extend: 'Ext.grid.Panel',
		id:'holdpay3',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:520,
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.HoldPayList',
		store: holdDataGridStore,
		autoScroll: true,
		initComponent: function () {
			var me = this;
			this.tbar = [
			             holdSearch
			             ];
			this.columns = [
			                { header: 'Scheme Id', dataIndex: 'scmId', width:80},
			                { header: 'Scheme Name', dataIndex: 'scmName', flex: 1 },
			                { header: 'Comp Id', dataIndex: 'compId', width:80 },
			                { header: 'Comp Name', dataIndex: 'compName', flex: 1 },
			                { header: 'Pay To', dataIndex: 'payTo', flex: 1 },
			                { header: 'Start Date', dataIndex: 'startDt', flex: 1 },
			                { header: 'End Date', dataIndex: 'endDt', flex: 1 },
			                { header: 'Payout Status', dataIndex: 'payoutStatus', width:80 },
			                { header: 'Payment Status', dataIndex: 'paymentStatus', flex: 1 },
			                { header: 'Payment Amount', dataIndex: 'amount', flex: 1 },
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : holdDataGridStore,
				dock : 'bottom',
				displayInfo : true
			}
			];
			this.callParent(arguments);
		},
	});


	Ext.define('Scheme.controller.HoldPayCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['HoldPayList'],
	});

});
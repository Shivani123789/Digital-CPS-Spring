Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);

var radioCheckRel=null;
var relPayStore1=relPayStore();
var rdfilter = null;	

var releSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border: false,
		style       : 'padding-bottom: 5px',
		layout:'column',
		anchor: '100%',
		items       : [   
{
	   xtype:'fieldset',
	   layout:'column',
	   title: 'Search Criteria',
	   height : 70,
	   width  :'100%',
	   bodyStyle:'padding:3px 0px',
	   collapsible: true,	
	   items :[               
		               
{   xtype:'fieldset',
	title: 'Hold Start Date',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:100,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'datefield',
	        	id          : 'startDtRp',
	        	allowBlank  : true,
	        	emptyText   : 'Start Date',
	        	name        : 'startDateHp',
	        	editable    : false,
	        }]
},
{   xtype:'fieldset',
	title: 'Hold End Date',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:100,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'datefield',
	        	id          : 'endDtRp',
	        	allowBlank  : true,
	        	emptyText   : 'End Date',
	        	name        : 'endDateHp',
	        	editable    : false,
	        }]
},

{   xtype:'fieldset',
	title: 'View Option',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:'190%',
		bodyStyle:'padding:5px 5px',
	},
	items :[
{
	xtype: 'radiogroup',
	width:'190%',
	id: 'releaseRadioGroup',
	//  fieldLabel: 'Auto Layout',
	// cls: 'x-check-group-alt',
	items: [
	        {boxLabel: 'Release Request', name: 'relRadio', inputValue: 1},
	        {boxLabel: 'Release History', name: 'relRadio', inputValue: 2}
	        ],
	        listeners:
	        {
	        	change : function(obj, value)
	        	{
	        		releaseDataGridStore.loadData([],false);
	        		radioCheckRel=value.relRadio;
	        		if(radioCheckRel==2)
	        		{
	        			relPayStore1.clearFilter();
	        			Ext.getCmp("ReleaseReq").disable();
	        			Ext.getCmp("ReqRemarks").disable();
	        		}
	        		else
	        		{
	        			relPayStore1.filter('filter',2);
	        			Ext.getCmp('releaseSearchId').setValue("");
	        			Ext.getCmp("ReleaseReq").enable();
	        			Ext.getCmp("ReqRemarks").enable();
	        		}
	        	}
	        }
},
]},
{
	   xtype :'textfield',
	   fieldLabel: 'CsrfName',
	   hidden:true,
	   disabled : true,
	   name: 'csrfRel',
	   maxLength : 100,
	   allowBlank:false,
	   id:'testCsrfRel'
},

{
	xtype:'fieldset',
	title: 'Search Type',
	collapsible: false,
	layout: 'column',
	//bodyStyle:'padding:4px 4px',
	defaults: {
		anchor: '100%',
		width:'100%',
		bodyStyle:'padding:5px 5px',
	},
	items :[
{
	xtype :'combo',
	editable: false,
	allowBlank: false,
	name:'searchId',
	id:'releaseSearchId',
	disabled:false,
	emptyText   : 'Search Type',
	displayField:'type',	
	valueField:'id',
	store: relPayStore1,
	listeners: {
		'select': function(combo, value){
			//Ext.getCmp("submitButtton").enable();
			if(combo.getValue()==1)
				Ext.getCmp('searchReqVal').setValue("");
			rdfilter=combo.getValue();
		}
	},
	triggerAction:'all'
}]
},
{   xtype:'fieldset',
	title: 'Search Value',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:'100%',
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'textfield',
	        	id          : 'searchReqVal',
	        	allowBlank  : true,
	        	emptyText   : 'Search Value',
	        	name        : 'searchValue',
	        	editable    : false,
	        }]
},
{
	xtype:'fieldset',
	title: 'Actions',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:'100%',
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'button',
	        	text        : 'GO',
	        	handler     : function () {
	        		var grid = Ext.ComponentQuery.query('RelePayList')[0];

	        		var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDtRp").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDtRp").getValue(),'Y/m/d'));

	        		if(rdfilter == null || !(Ext.getCmp("startDtRp").getValue()) || !(Ext.getCmp("endDtRp").getValue())  ){
	        			Ext.Msg.alert("Warning","<font color='blue'>Please enter 'Hold Start & End Date', 'View Option', 'Search Type' & 'Search Value'</font>");
	        			return false;
	        		}

	        		if(flag && rdfilter != null){
	        			grid.store.load(
	        					{
	        						params:
	        						{
	        							startDate:Ext.Date.format(Ext.getCmp("startDtRp").getValue(),'d-M-y') ,
	        							endDate: Ext.Date.format(Ext.getCmp("endDtRp").getValue(),'d-M-y'),
	        							releaseType:radioCheckRel,
	        							payTo:Ext.getCmp("releaseSearchId").getValue(),
	        							changeDesc:Ext.getCmp("searchReqVal").getValue()
	        						}
	        					});
	        		}
	        		Ext.getCmp('ReqRemarks').setValue("");
	        		Ext.getCmp('ReqTotalAmtID').setValue("");
	        		//Ext.getCmp('ReqTotalAmtID').setValue(releaseDataGridStore.data.items[0].data.totalAmt);
	        	}
	        }]
}

]
},

{
	xtype:'fieldset',
	layout:'column',
	title: 'Release Data Save & Download ',
	height : 70,
	width  :'100%',
	bodyStyle:'padding:3px 0px',
	collapsible: true,	
	items :[    
{   xtype:'fieldset',
	title: 'Total Hold Amount',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '100%',
		width:100,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'textfield',
	        	id          : 'ReqTotalAmtID',
	        	allowBlank  : true,
	        	emptyText   : 'Total Amount',
	        	name        : 'totalAmt',
	        	editable    : false,
	        	readOnly    : true,
	        }]
},
{
	   xtype:'fieldset',
		title: 'Remarks',
		collapsible: false,
		// maskRe:/[A-Za-z0-9_,- ]/,
		layout: 'column',
		defaults: {
			anchor: '100%',
			width:300,
			bodyStyle:'padding:5px 5px',
		},
		items :[
		        {
		        	xtype       : 'textfield',
		        	//id          : 'stmtDt',
		        	allowBlank  : true,
		        	emptyText   : 'Remarks',
		        	id          : 'ReqRemarks',
		        	name        : 'ReqRemarks',
		        	enforceMaxLength  : true,
		        	 maxLength:100,
		        }]
},
{
	xtype:'fieldset',
	title: 'Release Request',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '10%',
		width:50,
		height:35,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'image',
	        	src : 'resources/images/release_amount.jpg',
	        	//text        : 'Release Request',
	        	id          : 'ReleaseReq',
	        	listeners     : 
	        	{
	        		afterrender : function (me) {
	        			me.getEl().on('click', function () {
	        				var grid = Ext.ComponentQuery.query('RelePayList')[0];
	        				var sm = grid.getSelectionModel();
	        				var rs = sm.getSelection();
	        				var rem = Ext.getCmp("ReqRemarks").getValue();
	        			//	alert(" rem:: "+rem+"  !:"+(!rem)+" len:: "+rem.length);
	        				if(radioCheckRel==1 )
	        				if(rs.length)
	        				{
	        					if(rem && rem.length!=0){
	        					var z = null;
	        					var statementReqData="";
	        					for(z=0;z<rs.length;z++)
	        					{
	        						if((z+1)!=rs.length)
	        						{
	        							statementReqData+=rs[z].data.transactionDate+",";
	        							if(rs[z].data.holdReleaseRequest=='Y'){
	        								Ext.Msg.alert("Warning","<font color='blue'>Either some or all of the selected transaction(s) has already been requested to be released.</font>");
	        								return false;
	        							}
	        							if(rs[z].data.holdStatus!='S'){
	        								Ext.Msg.alert("Warning","<font color='red'>You can not release the amount unless 'Hold' is successful. <br> Please select only those records whose 'Hold Status' = 'S'</font>");
	        								return false;
	        							}
	        						}
	        						else
	        						{
	        							statementReqData+=rs[z].data.transactionDate;
	        							if(rs[z].data.holdReleaseRequest=='Y'){
	        								Ext.Msg.alert("Warning","<font color='blue'>Either some or all of the selected transaction(s) has already been requested to be released.</font>");
	        								return false;
	        							}
	        							if(rs[z].data.holdStatus!='S'){
	        								Ext.Msg.alert("Warning","<font color='red'>You can not release the amount unless 'Hold' is successful. <br> Please select only those records whose 'Hold Status' = 'S'</font>");
	        								return false;
	        							}
	        						}
	        					}
	        					Ext.Ajax.request(
	        							{
	        								dataType : 'json',
	        								contentType : 'application/json',
	        								url:'searchscheme/updateRelReq.action',
	        								method: 'GET',
	        								params:
	        								{
	        									"relReqData": statementReqData,
	        									"remarksVal": Ext.getCmp("ReqRemarks").getValue(),
	        								},
	        								success: function(response)
	        								{
	        									Ext.ux.mask.hide();
	        									var jsonResp = Ext.JSON.decode(response.responseText);
	        									console.log(jsonResp	);
	        									if(jsonResp.success==false)	
	        									{
	        										Ext.Msg.alert("Error",jsonResp.errorMessage);
	        									}
	        									else{
	        										Ext.Msg.alert("Info",jsonResp.errorMessage);
	        										var grid = Ext.ComponentQuery.query('RelePayList')[0];
	        										grid.store.load({params:
	        										{
	        											startDate:Ext.Date.format(Ext.getCmp("startDtRp").getValue(),'d-M-y') ,
	        											endDate: Ext.Date.format(Ext.getCmp("endDtRp").getValue(),'d-M-y'),
	        											releaseType:radioCheckRel,
	        											payTo:Ext.getCmp("releaseSearchId").getValue(),
	        											changeDesc:Ext.getCmp("searchReqVal").getValue()
	        										}
	        										});	
	        										Ext.getCmp('ReqRemarks').setValue("");
	        										Ext.getCmp('ReqTotalAmtID').setValue("");
	        									}
	        								}
	        							});
	        					}else{
	        						Ext.Msg.alert("Warning","<font color='red'>Remarks is mandatory.</font>");
	        					}
	        				}else{
	        					Ext.Msg.alert("Warning","<font color='red'>Please select atleast one transactional row from below to proceed with this request.</font>");
	        				}
	        			});
	        		}
	        	}
	        }]
},
{   
	xtype:'fieldset',
	title: 'Download File',
	collapsible: false,
	layout: 'column',
	defaults: {
		anchor: '10%',
		width:50,
		height:40,
		bodyStyle:'padding:5px 5px',
	},
	items :[
	        {
	        	xtype       : 'image',
	        	// text : 'Download',
	        	src         : 'resources/images/csv_download.jpg' ,
	        	listeners   :  
	        	{
	        		afterrender : function (me) {
	        			me.getEl().on('click', 	function () {
	        				var urlParam1;
	        				Ext.Msg.confirm('Release Data', 
	        						'Download Release Data CSV', 
	        						function (button) {
	        					if (button == 'yes') {
	        						waitMsg : 'Loading...',
	        						urlParam1 = './csv/relDataDownloadCSV.action?startDate='+Ext.Date.format(Ext.getCmp("startDtRp").getValue(),'d-M-y')+'&endDate='+Ext.Date.format(Ext.getCmp("endDtRp").getValue(),'d-M-y')+
	        						'&radioType='+radioCheckRel+'&payType='+Ext.getCmp("releaseSearchId").getValue()+'&searchVal='+Ext.getCmp("searchReqVal").getValue();
	        					window.open(urlParam1,'_BLANK');
	        					}
	        				});
	        			});
	        		}
	        	}
	        }]
}]
}]
});

	
	Ext.define('Scheme.view.RelePayList', {
		extend: 'Ext.grid.Panel',
		id:'relepay3',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:520,
		hidden: false,
		loadMask: true,
		//iconCls: 'icon-grid',
		plugins: 'bufferedrenderer',
		selModel : Ext.create('Ext.selection.CheckboxModel'),
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.RelePayList',
		store: releaseDataGridStore,
		autoScroll: true,
		features: [groupingFeature],
		initComponent: function () {
			//var me = this;
			this.tbar = [
			             releSearch
			             ];
			this.columns = [
			                { header: 'Transaction Date', dataIndex: 'transactionDate', flex: 1 },
			                { header: 'Producer Id', dataIndex: 'producerId', flex: 1 },
			                { header: 'Hold Amount', dataIndex: 'holdAmt', width:80 },
			                { header: 'Hold Release Status', dataIndex: 'releaseStatus', flex: 1 },
			                { header: 'Hold Status', dataIndex: 'holdStatus', flex: 1 },
			                { header: 'Hold Release Request', dataIndex: 'holdReleaseRequest', flex: 1 },
			                { header: 'Release Req Date', dataIndex: 'releaseReqDate', flex: 1 },
			                { header: 'Release Date', dataIndex: 'releaseDate', flex: 1 },
			                { header: 'Remarks', dataIndex: 'remarks', flex: 1 }
			                ];
			                /*this.fbar  = ['->', {
			                    text:'Clear Grouping',
			                    iconCls: 'icon-clear-group',
			                    handler : function(){
			                        groupingFeature.disable();
			                    }
			                }];*/
			this.dockedItems = [{
				xtype : 'pagingtoolbar',
				store : releaseDataGridStore,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		},
		listeners: {
			'select': function(combo, value){
				var grid = Ext.ComponentQuery.query('RelePayList')[0];
        		var sm = grid.getSelectionModel();
				var rs = sm.getSelection();
				var tot=0;
				for(var z=0;z<rs.length;z++)
				{
				tot +=rs[z].data.holdAmt;
				}
				Ext.getCmp('ReqTotalAmtID').setValue(tot);
			},
		'deselect': function(combo, value){
			var grid = Ext.ComponentQuery.query('RelePayList')[0];
    		var sm = grid.getSelectionModel();
			var rs = sm.getSelection();
			var tot=0;
			for(var z=0;z<rs.length;z++)
			{
			tot +=rs[z].data.holdAmt;
			}
			Ext.getCmp('ReqTotalAmtID').setValue(tot);
		}
		},
	});


	Ext.define('Scheme.controller.RelePayCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['RelePayList'],
	});

});
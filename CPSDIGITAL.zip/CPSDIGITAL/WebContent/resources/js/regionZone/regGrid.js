Ext.onReady(function () {
	Ext.define('Scheme.model.Reg', {
	    extend: 'Ext.data.Model',
	    fields: [
	             
	             {name: 'CompId', type: 'int'},
	             {name: 'regionId', type: 'int'},
	             {name: 'zoneId', type: 'int'},
	             {name: 'regionDesc',  type: 'string'}
	   
	    ]
	  });
 
	Ext.define('regModel', {
	    extend: 'Ext.data.Model',
	    fields: [
	             {name: 'regionId', type: 'string'},
	             {name: 'regionDesc',  type: 'int'}
	            
	           ]
	  });
   
	
   
 
   Ext.define('Scheme.view.RegList', {
    extend: 'Ext.grid.Panel',
    name:'regGrid',
    pageSize : 5,
	//layout: 'fit',
    alias: 'widget.RegList',
    title: 'Region List',
    store: regZoneStore,
    height:500,
    //layout:'fit',
    autoScroll: true,
  //  store : 'Companies',
    initComponent: function () {
      this.tbar = [{
        text    : 'Add Region',
        action  : 'add',
        iconCls : 'book-add'
      }];
      this.columns = [
        { header: 'Id', dataIndex: 'covRegZoneId', width: 60 },
        { header: 'Comp Id', dataIndex: 'compId', width: 60 },
        { header: 'Comp Name', dataIndex: 'compName', width: 80 },
        { header: 'Region', dataIndex: 'regionDesc', flex: 1 },
        { header: 'Zone', dataIndex: 'zoneDesc', width: 80  },
        { header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'resources/images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('RegList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Region Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove Region', 
                          'Are you sure you want to delete Region?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            	//ajax post to remove
                            	
                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removeRegZone.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
                            			  method: 'POST',
                            			  params: {
                            				  "covRegZoneId" : rs[0].data.covRegZoneId
                            			    },
                            			    success: function (response) {
                             			         Ext.Msg.alert("Info","Region deleted Sucessfully");
                             			        regZoneStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			      
                            			  }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : regZoneStore,
			dock : 'bottom',
			displayInfo : true
		} ];
      
      this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.RegForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.RegForm',
      title   : 'Add Region',
      //width   : 350,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [
										{
											xtype:'fieldset',
											title: 'Region & Zone',
											collapsible: true,
											layout: 'anchor',
											defaults: {
											anchor: '100%'
											},
											items :[componentName,region,zone,{
        				        		    	   xtype :'textfield',
           				        		    	   fieldLabel: 'CsrfName',
												   hidden:true,
           				        		    	   disabled : true,
           				        		    	   name: 'csrfReg',
												   maxLength : 100,
           				        		    	   allowBlank:false,
           				        		    	   id:'testCsrfReg'
           				        		    }]
										}
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add'
    	  				
                	},
                	
                	/*{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},*/
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.RegCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['RegList', 'RegForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'RegForm',
      selector: 'RegForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'RegList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'RegList': {
          itemdblclick: this.onRowdblclick
        },
        'RegForm button[action=add]': {
          click: this.doAddRegion
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	
		var win = this.getFormWindow();
		
		 win.down('form').getForm().applyToFields({disabled:true});
		
		win.down('form').getForm().findField('compId').enable();
		win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compName',record.data.compName));
		win.down('form').getForm().findField('compId').enable();
	  win.down('form').getForm().findField('compId').readOnly = true;
	  
		
		regionStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					win.down('form').getForm().findField('regionId').enable();
					win.down('form').getForm().findField('regionId').setValue(regionStore.findRecord('regionDesc',record.data.regionDesc));
			
			}
			}
			});
		zoneStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					win.down('form').getForm().findField('zoneId').enable();
			win.down('form').getForm().findField('zoneId').setValue(zoneStore.findRecord('zoneDesc',record.data.zoneDesc));
			}
			}
			});
      
      
      
      
      
      win.setTitle('Edit Region');
      win.setAction('edit');
      covRegZoneId = record.data.covRegZoneId;
      win.setRecordIndex(record.data.covRegZoneId);
      win.down('form').getForm().setValues(record.getData());
      win.show();
    },
    showAddForm: function () {
    	
    	if(compName!=null)
    	{
      var win = this.getFormWindow();
      win.setTitle(SchemeName);
      win.setAction('add');
      win.down('form').getForm().reset();
      win.show();
      componentName.setValue(componentListStore.findRecord('compId',componentListStore.data.items[0].data.compId));
    	}
    	else
    		{
    		Ext.Msg.alert('Info', "Please create componenet first");
    		}
    },
    doAddRegion: function () {
      var win = this.getFormWindow();
      var action = win.getAction();
      if(action == 'edit') {
    	  if(win.down('form').isValid() && !isRegEligible)
    	  {
    		  updateRegionZone(win);
    	  }
    	  else if(isRegEligible){
    		  Ext.Msg.alert('Info', "Unable to add region zone for this component.");
    	  }else
    	  {
    		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
    	  }

      }
      else {
    	  if(win.down('form').isValid() && !isRegEligible)
    	  {
    		  saveRegionZone(win);
    	  }else if(isRegEligible){
    		  Ext.Msg.alert('Info', "Unable to add region zone for this component.");
    	  }
    	  else
    	  {
    		  Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
    	  }
      }
    
    }
  });
 
  
   
});
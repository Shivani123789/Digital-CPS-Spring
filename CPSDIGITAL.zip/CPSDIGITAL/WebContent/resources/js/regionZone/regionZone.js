var regGridStatus = 0;
var sregGridStatus = 0;
var covRegZoneId = null;
var isRegEligible = false;

function saveRegionZone(regionZoneForm)
{
	regionZoneForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		// url : addregionZoneUrl,
		 url : 'payoutcondition/saveRegionZone.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
		 success: function(form, action) {
            Ext.Msg.alert('Region added Sucessfully');
            regZoneStore.load();
            form.reset();
            regionZoneForm.close();
			formPanel.items.each(function(c){
		    	
			c.items.items[3].setDisabled(false);
						c.setActiveTab(c.items.items[3]);
						c.items.items[4].setDisabled(false);
						})

           
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        }
    });
}
	
function updateRegionZone(regionZoneForm)
{

	regionZoneForm.down('form').getForm().submit({
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/updateRegZone.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
		 params: {
			  "covRegZoneId" : covRegZoneId
		    },
		 success: function(form, action) {
            Ext.Msg.alert('Region updated Sucessfully');
            regZoneStore.load();
            form.reset();
            regionZoneForm.close();
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        }
    });
}
	

var componentName = new Ext.form.ComboBox({
		name:'compId',
		fieldLabel:'Component*',
		displayField:'compName',
		valueField:'compId',
		allowBlank: false,
		editable: false,
		store: componentListStore,
	   
	   listeners: {
			  'select': function(combo, value){
				  
				  Ext.Ajax.request({
               		  url : 'payoutcondition/isFileUpload.action',
               		  method: 'POST',
               		params: {
      				  "compId" : combo.getValue()
      			    },
      			     
               		    success: function (response) {
               		    	if(response.responseText=='Yes')
               		    		{
               		    		region.disable();
               		    		zone.disable();
               		    		isRegEligible = true;
               		    		//this.up('window').down('form').getForm().findField("regionId").disable();
               		    		//this.up('window').down('form').getForm().findField("zoneId").disable();
               		    		}
               		    	else
               		    		{
               		    		region.enable();
               		    		zone.enable();
               		    		isRegEligible = false;
               		    		//this.up('window').down('form').getForm().findField("regionId").enable();
               		    		//this.up('window').down('form').getForm().findField("zoneId").enable();
               		    		
               		    		
               		    		}
               		    },
               		 
               		  failure: function (response) {
               		       }
               		 });
               	
				 // circleid = combo.getValue();
				//	zoneStore.clearFilter();
				//	zoneStore.filter("regionId",combo.getValue());
				//	this.up('window').down('form').getForm().findField("zoneId").reset();
				  
			  }
			 },
			 triggerAction:'all'

		   });
	

/*var componentNameReg = new Ext.form.ComboBox({
	name:'compId',
	fieldLabel:'Component*',
	displayField:'compName',
	valueField:'compId',
	allowBlank: false,
	editable: false,
	store: componentListStoreReg,
   
   listeners: {
		  'select': function(combo, value){
			  
			  Ext.Ajax.request({
           		  url : 'payoutcondition/isFileUpload.action',
           		  method: 'POST',
           		params: {
  				  "compId" : combo.getValue()
  			    },
  			     
           		    success: function (response) {
           		    	if(response.responseText=='Yes')
           		    		{
           		    		region.disable();
           		    		zone.disable();
           		    		//this.up('window').down('form').getForm().findField("regionId").disable();
           		    		//this.up('window').down('form').getForm().findField("zoneId").disable();
           		    		}
           		    	else
           		    		{
           		    		region.enable();
           		    		zone.enable();
           		    		//this.up('window').down('form').getForm().findField("regionId").enable();
           		    		//this.up('window').down('form').getForm().findField("zoneId").enable();
           		    		
           		    		
           		    		}
           		    },
           		 
           		  failure: function (response) {
           		       }
           		 });
           	
			 // circleid = combo.getValue();
			//	zoneStore.clearFilter();
			//	zoneStore.filter("regionId",combo.getValue());
			//	this.up('window').down('form').getForm().findField("zoneId").reset();
			  
		  }
		 },
		 triggerAction:'all'

	   });

*/
var region = new Ext.form.ComboBox({
		name:'regionId',
		//hiddenName:'circleId',
		fieldLabel:'Region*',
		allowBlank: false,
		editable: false,
		autoLoad:false,
		displayField:'regionDesc',
		valueField:'regionId',
		store: regionStore,
		id:'regionId',
		listeners: {
			  'select': function(combo, value){
				 // circleid = combo.getValue();
					zoneStore.clearFilter();
					zoneStore.filter("regionId",combo.getValue(),0, false, true, true);
					this.up('window').down('form').getForm().findField("zoneId").reset();
				  
				  if(combo.getValue()==0)
				  this.up('window').down('form').getForm().findField("zoneId").disable();
				  else
				  this.up('window').down('form').getForm().findField("zoneId").enable();
				  
			  }
			 },
	   triggerAction:'all'
		   });
	
var zone = new Ext.form.ComboBox({
	name:'zoneId',
	//hiddenName:'circleId',
	fieldLabel:'Zone*',
	allowBlank: false,
	editable: false,
	displayField:'zoneDesc',
	valueField:'zoneId',
	store: zoneStore,
	//triggerAction:'all',
	listeners:
    {
        afterrender: function (me) { 
            me.getEl().on('click', function() {

            	zoneStore.clearFilter();
            	zoneStore.filter('regionId',Ext.getCmp("regionId").getValue(),0, false, true, true);
            });
		},
	 triggerAction:'all',
  }
	   });


    var regList = Ext.create('Ext.form.Panel', {
	 	url: addSchemeUrl,
	 	border: false,
	 	//height:600,
	 	
	   items:[{
		   
	     		xtype:'fieldset',
	     		//title: 'Edit Scheme',
	     		//collapsible: true,
	     		layout: 'anchor',
	     		border:false,
	     		height:500,
	     		autoscroll:true,
	     		defaults: {
	     		anchor: '100%'
	     //			width:230
	     		
	     		},
	     		items :[
	     			{
	             		html: "<div id='reglist'></div>",
	             		xtype: "fieldset",
	             		border:false,
	             		autoscroll:true
	             		
	     			}
	             	
	     		]}
	     	
	   ]});
    
    var sregList = Ext.create('Ext.form.Panel', {
	 	url: addSchemeUrl,
	 	border: false,
		layout: 'fit',
	 	//height:600,
	 	
	   items:[{
		   
	     		xtype:'panel',
	     		//title: 'Edit Scheme',
	     		//collapsible: true,
				layout: 'fit', 		
	     		border:false,
	     		//height:500,
	     		autoscroll:true,
	     		
	     		items :[
	     			{
	             		html: "<div id='sreglist'></div>",
	             		xtype: "panel",
						layout: 'fit', 
	             		border:false,
	             		autoscroll:true
	             		
	     			}
	             	
	     		]}
	     	
	   ]});


    
    

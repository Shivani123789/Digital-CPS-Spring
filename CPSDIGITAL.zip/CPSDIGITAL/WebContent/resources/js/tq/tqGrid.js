Ext.onReady(function () {
	Ext.define('Scheme.model.Tq', {
	    extend: 'Ext.data.Model',
	    fields: [
	      {name: 'compId', type: 'int'},
	      {name: 'compName',  type: 'string'},
	      {name: 'condId', type: 'int'},
	      {name: 'value',  type: 'string'},
	      {name: 'condRowId', type: 'int'},
	      {name: 'loprName',  type: 'string'},
	      {name: 'lValue',  type: 'string'},
	      {name: 'roprName',  type: 'string'}
	      
	     
	    ]
	  });
 
	
	
   var oprFilter  = null;
   
   var detailsPanel = {
        id: 'details-panel',
        title: 'Cond Details',
      //  region:'west',
		collapsible: true,
		height : 200,
		width: 1100,
      //  bodyStyle: 'padding-bottom:15px;background:#eee;',
        autoScroll: true,
        html: '<p class="details-info">Cond Detail Will appear here...................................</p>'
    };
	
	
	
	
	
	
	
	
 
   Ext.define('Scheme.view.TqList', {
    extend: 'Ext.grid.Panel',
    name:'tqGrid',
    pageSize : 5,
    alias: 'widget.TqList',
    title: 'Tq List',
    store: tqStore,
    selModel : Ext.create('Ext.selection.CheckboxModel'),
    height:500,
    //layout:'fit',
    autoScroll: true,
  //  store : 'Companies',
    features: [groupingFeatureTQ],
    initComponent: function () {
    	this.tbar = [
    	             {
    	            	 xtype:'image',
    	            	 src :'resources/images/book_delete.png',
    	            	 listeners:
    	            	 {
    	            		 afterrender: function(me)
    	            		 {
    	            			 me.getEl().on('click', function() {
    	            				 var grid = Ext.ComponentQuery.query('TqList')[0];
    	            				 if (grid) {
    	            					 var sm = grid.getSelectionModel();
    	            					 var rs = sm.getSelection();
    	            					 if (!rs.length) {
    	            						 Ext.Msg.alert('Info', 'No Tq Selected');
    	            						 return;
    	            					 }
    	            					 Ext.Msg.confirm('Remove Region', 
    	            							 'Are you sure you want to delete Tq?', 
    	            							 function (button) {
    	            						 if (button == 'yes') {
    	            							
    	            							 var tqParamVal="";
    	                                   	  
    	                                   	  for(var i=0;i<rs.length;i++)
    	                                   		  {
    	                                   		  if((i+1)!=rs.length)
    	                                   		      tqParamVal +=rs[i].data.compId+","+rs[i].data.condId+","+rs[i].data.condRowId+":";
    	                                   		  else
    	                                   			  tqParamVal +=rs[i].data.compId+","+rs[i].data.condId+","+rs[i].data.condRowId;  
    	                                   		  
    	                                   		  }
    	                                   	  
    	                                     
    	                                   	  Ext.Ajax.request({
    	                                 			  url : 'payoutcondition/removeTq.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    	                                 			  method: 'POST',
    	                                 			  params: {
    	                                 				"perfParamName":tqParamVal
    	                                 			    },
    	                                 			    success: function (response) {
    	                                  			         var response1 = Ext.decode(response.responseText);
    	           											 if(response1.success)
    	                                 			    		{
    	           												Ext.Msg.alert("Info","Tq deleted successfully");
    	           												grid.store.remove(rs[0]);
    	                                  			        tqStore.load();
    	           											componentListStoreTq.load();
    	           											
    	           											}
    	           											
    	           											else
    	           											{
    	           											Ext.Msg.alert("Warning",response.message);
    	           											
    	           											}
    	                                 			    },
    	                                  			 
    	                                 			  failure: function (response) {
    	                                 			       }
    	                                   	  
    	                                 			 });
    	            							 
    	            								 /*Ext.Ajax.request({
    	            									 url : 'payoutcondition/removeTq.action',
    	            									 method: 'POST',
    	            									 params: {
    	            										 "compId" : rs[i].data.compId,
    	            										 "condId" :rs[i].data.condId,
    	            										 "condRowId" :rs[i].data.condRowId
    	            									 },
    	            									 success: function (response) {
    	            										 var response = Ext.decode(response.responseText);
    	            										 if(response.success)
    	            										 {
    	            											 Ext.Msg.alert("Info","Tq deleted successfully");
    	            											 grid.store.remove(rs[i]);
    	            											 tqStore.load();
    	            											 componentListStoreTq.load();
    	            										 }
    	            										 else
    	            										 {
    	            											 Ext.Msg.alert("Warning",response.message);
    	            										 }
    	            									 },
    	            									 failure: function (response) {
    	            									 }
    	            								 });*/
    	            						 }
    	            					 });
    	            				 }
    	            			 });
    	            		 }
    	            	 }
    	             },           
    	             {
    	            	 text    : 'Add',
    	            	 action  : 'add',
    	            	 iconCls : 'book-add'
    	             },
    	             
    	             {
    	            	 itemId: 'copyTQ',
    	            	 text: 'Copy Condition',
    	            	 iconCls: 'employee-copy',
    	            	 //disabled: true,
    	            	 handler: function() {
    	            		 var grid = Ext.ComponentQuery.query('TqList')[0];
    	            		 if (grid) {
    	            			 var sm = grid.getSelectionModel();
    	            			 var rs = sm.getSelection();
    	            			 if (!rs.length) {
    	            				 Ext.Msg.alert('Info', 'No Tq Selected');
    	            				 return;
    	            			 }
    	            			 Ext.Msg.confirm('Copy TQ', 
    	            					 'Are you sure you want to copy TQ condition?', 
    	            					 function (button) {
    	            				 if (button == 'yes') {

    	            					 var tqParamVal = true;

    	            					 for(var i=0; i<rs.length; i++)
    	            					 {
    	            						 if((i+1) != rs.length){
    	            							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
    	            								 tqParamVal=false;
        	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To copy condition.</font>");
    	            							 }
    	            						 }else{
    	            							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
    	            								 tqParamVal=false;	  
        	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To copy condition.</font>");
    	            							 }
    	            						 }
    	            					 }

    	            					 if(tqParamVal){ 
    	            						 Ext.Ajax.request({
    	            							 url : 'schemeinput_tq/copyCondition.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    	            							 method: 'POST',
    	            							 params: {
    	            								 "compId" : rs[0].data.compId,
    	            								 "condId" : rs[0].data.condId,
    	            								 "processType" : 'TQ',
    	            							 },
    	            							 success: function (response) {
    	            								 var response1 = Ext.decode(response.responseText);
    	            								 Ext.Msg.alert("Info",response1.message);
    	            								 tqStore.load();
    	            								 componentListStoreTq.load();
    	            							 },
    	            							 failure: function (response) {
    	            							 }
    	            						 });
    	            					 }
    	            				 }
    	            			 });
    	            		 }
    	            	 }
    	             },
    	             ];
    	this.columns = [

    	                { header: 'CompId', dataIndex: 'compId', flex: 1  },
    	                { header: 'Cond_Id', dataIndex: 'condId', flex: 1 },
    	                { header: 'Cond_Row_Id', dataIndex: 'condRowId', flex: 1 },
    	                // { header: 'compName', dataIndex: 'compName', flex: 1 },
    	                { header: 'CondName', dataIndex: 'condName', flex: 2  },
    	                { header: 'DataSet', dataIndex: 'dataSetName', flex: 1  },
    	                { header: 'P Param', dataIndex: 'perfParamName', flex: 1 },
    	                { header: 'Opr', dataIndex: 'oprName', flex: 1  },
    	                { header: 'valueType', dataIndex: 'valueTypeName', flex: 1 },
    	                { header: 'value', dataIndex: 'value', flex: 1 },
    	                { header: 'SDate', dataIndex: 'startDate', flex: 1 },
    	                { header: 'EDate', dataIndex: 'endDate', flex: 1 },
    	                { header: 'LOPR', dataIndex: 'loprName', flex: 1 },
    	                { header: 'LP_Param', dataIndex: 'lperfParamName', flex: 1 },
    	                { header: 'L_opr', dataIndex: 'l_loprName', flex: 1 },
    	                { header: 'L_ValueType', dataIndex: 'lvalueTypeName', flex: 1 },
    	                { header: 'LValue', dataIndex: 'lValue', width: 60 },
    	                { header: 'LSDate', dataIndex: 'lStartDate', width: 60 },
    	                { header: 'LEDate', dataIndex: 'lEndDate', width: 60 },
    	                { header: 'Ropr', dataIndex: 'roprName', width: 60 },
    	                /*{ header: 'Action', width: 50,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'resources/images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('TqList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Tq Selected');
                          return;
                        }
                        Ext.Msg.confirm('Remove Region', 
                          'Are you sure you want to delete Tq?', 
                          function (button) {
                            if (button == 'yes') {

                            	//ajax post to remove

                            		Ext.Ajax.request({
                            			  url : 'payoutcondition/removeTq.action',
                            			  method: 'POST',
                            			  params: {
                            				  "compId" : rs[0].data.compId,
                            				  "condId" :rs[0].data.condId,
											  "condRowId" :rs[0].data.condRowId
                            			    },
                            			    success: function (response) {
                             			         var response = Ext.decode(response.responseText);
												 if(response.success)
                            			    		{
													Ext.Msg.alert("Info","Tq deleted successfully");
													grid.store.remove(rs[0]);
                             			        tqStore.load();
												componentListStoreTq.load();

												}

												else
												{
												Ext.Msg.alert("Warning",response.message);
												}
                            			    },

                            			  failure: function (response) {
                            			       }
                            			 });

                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }*/
    	                ];
    	this.dockedItems = [ {
    		xtype : 'pagingtoolbar',
    		store : tqStore,
    		dock : 'bottom',
    		displayInfo : true
    	} ];

    	this.callParent(arguments);
    }
  });
 
    Ext.define('Scheme.view.TqForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.TqForm',
      title   : 'Add Tq',
      //width   : 350,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [
		
		
		detailsPanel,
		{
            xtype: 'fieldset',
            anchor: '100%',
            title: 'Transaction Details',
            collapsible: true,
            layout:'column',
            items:[
					{
				    xtype: 'container',
				    columnWidth:.2,
				    layout: 'anchor',
				    items: [
								{
									xtype :'combo',
									editable: false,
									id: 'tqCompList',
									allowBlank:false,
									fieldLabel: 'Component',
									name:'compId',
									displayField:'compName',
									valueField:'compId',
									store: componentListStoreTq,
									
									listeners: {
									  'select': function(combo, value){
								
								
								 var compName = componentListStoreTq.findRecord('compId',combo.getValue(),0, false, true, true);
									  condBodyTq  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
									  
									  updateTQCondPanel(combo.getValue());
								
								}
								
								},
									triggerAction:'all'
								//	value : componentListStore.data.items[componentListStore.data.items.length].data
								} 
				            
				           ]
					},
				                   
                   {
                xtype: 'container',
                columnWidth:.3,
                id:'tqLeft',
                layout: 'anchor',
                items: [
							{
								xtype :'textfield',
								maxLength : 50,
								id: 'tqCondName',
								allowBlank:false,
								fieldLabel: 'Condition Name',
								//maskRe:/[A-Za-z0-9_ ]/,
								name:'condName'
							},
							{
								xtype :'combo',
								allowBlank:false,
								editable: false,
								fieldLabel: 'Data Set',
								name:'dataSet',
								displayField:'dataSetName',
								valueField:'dataSetId',
								store: dataSetStore,
								listeners: {
									'select': function(combo, value){
										Ext.Msg.alert("Verifying Data Set:"+combo.getValue());
										paramStore.clearFilter();
										paramStoreTqRight.clearFilter();
										this.up('window').down('form').getForm().findField("perfParmeter").reset();
										this.up('window').down('form').getForm().findField("lPrefparameter").reset();
										this.up('window').down('form').getForm().findField("opr").reset();
										if(combo.getValue()==1)
										{
											paramStore.filter(function(r) {
												var value = r.get('univId');
												return (value == 1 || value == 2);
											});
											paramStoreTqRight.filter(function(r) {
												var value = r.get('univId');
												return (value == 1 || value == 2);
											});
										}
										else
										{
											paramStore.filter("univId",combo.getValue());
											paramStoreTqRight.filter("univId",combo.getValue());
										}
										tqValueListStore.clearFilter();
										tqValueListStore.filter("univId",combo.getValue());

									}
									 },
								triggerAction:'all'
							},
							{
								xtype :'combo',
								fieldLabel: 'Param',
								allowBlank:false,
								editable: false,
								name:'perfParmeter',
								displayField:'paramName',
								valueField:'paramId',
								store: paramStore,
							/*	queryMode: 'local',
									forceSelection: true,
									triggerAction: 'all',
									enableKeyEvents: true,
									selectOnFocus:true,
									typeAhead: true,
									disableKeyFilter: true,*/
								listeners: {
									  'select': function(combo, value){
											
											var  oprFilter =   paramStore.findRecord('paramId',combo.getValue(),0, false, true, true);
											//alert("paramId :: "+oprFilter.data.paramId+"  paramName :: "+oprFilter.data.paramName);
										    oprFilter = oprFilter.data.dtaType;
											if(combo.getValue()==2)
											oprFilter= 'S';
											//alert(oprFilter);
											oprStoreTq.clearFilter();
											
											if(oprFilter=='D')
											{
											this.up('window').down('form').getForm().findField("startDate").enable();
											 this.up('window').down('form').getForm().findField("endDate").enable();
											 
											oprStoreTq.filter('dateFlag','Y');
											}
											if(oprFilter=='N')
											{
											this.up('window').down('form').getForm().findField("startDate").disable();
											 this.up('window').down('form').getForm().findField("endDate").disable();
											
											oprStoreTq.filter('numberFlag','Y');
											}
											if(oprFilter=='S')
											{
											this.up('window').down('form').getForm().findField("startDate").disable();
											this.up('window').down('form').getForm().findField("endDate").disable();
											
											oprStoreTq.filter('stringFlag','Y');
											}

								}
								},
								triggerAction:'all'
							},
							
							{
								xtype :'combo',
								fieldLabel: 'OPR',
								editable: false,
								name:'opr',
								displayField:'oprName',
								valueField:'oprId',
								store: oprStoreTq,
							/*	queryMode: 'local',
									forceSelection: true,
									triggerAction: 'all',
									enableKeyEvents: true,
									selectOnFocus:true,
									typeAhead: true,
									disableKeyFilter: true, */
								listeners: {
									  'select': function(combo, value){
										
										this.up('window').down('form').getForm().findField("valueType").reset();
										this.up('window').down('form').getForm().findField("value").reset();
										this.up('window').down('form').getForm().findField("value").disable();
										this.up('window').down('form').getForm().findField("ValueListName").reset();
										this.up('window').down('form').getForm().findField("ValueListName").disable();
										 if(combo.getValue()==14 || combo.getValue()==30)
											 {
											 this.up('window').down('form').getForm().findField("valueType").disable();
											 this.up('window').down('form').getForm().findField("value").disable();
											  this.up('window').down('form').getForm().findField("ValueListName").disable();
											 this.up('window').down('form').getForm().findField("startDate").enable();
											 this.up('window').down('form').getForm().findField("endDate").enable();
											 
											 
											 this.up('window').down('form').getForm().findField("startDate").allowBlank=false;
											 this.up('window').down('form').getForm().findField("endDate").allowBlank=false;
											 }
										 else
										 {
										 this.up('window').down('form').getForm().findField("startDate").reset();
										 this.up('window').down('form').getForm().findField("endDate").reset();
										 this.up('window').down('form').getForm().findField("valueType").enable();
										 this.up('window').down('form').getForm().findField("startDate").allowBlank=true;
										this.up('window').down('form').getForm().findField("endDate").allowBlank=true;


										 }
									  }
									 },
								triggerAction:'all'
							},
							
							{
								xtype :'combo',
								editable: false,
								fieldLabel: 'Value Type',
								name:'valueType',
								displayField:'valueTypeName',
								valueField:'valueTypeId',
								store: tqValueTypeStore,
								listeners: {
									  'select': function(combo, value){
										  console.log(tqFreeTextType);
										  if(combo.getValue()==1)
										  {
											  this.up('window').down('form').getForm().findField("value").enable();
											  this.up('window').down('form').getForm().findField("ValueListName").disable();

										  } else
											  {
											  this.up('window').down('form').getForm().findField("value").disable();
											  this.up('window').down('form').getForm().findField("ValueListName").enable();
											  this.up('window').down('form').getForm().findField("ValueListName").reset();
											  }
									  }
									 },
								triggerAction:'all'
							},
							{
								xtype :'textfield',
								editable: false,
								fieldLabel: 'Value*',
								name:'value',
								disabled : true,
								enforceMaxLength  : true,
								maxLength:500,
								//maskRe:/[A-Za-z0-9_, ]/,
								listeners:{
			                        'change': function(field, newValue, oldValue){
			                            field.setValue(newValue.toUpperCase());
			                        }
			                     }
							},
							
							{
								xtype :'combo',
								editable: false,
								allowBlank: false,
								fieldLabel: 'Value*',
								disabled : true,
								name:'ValueListName',
								displayField:'univName',
								valueField:'univName',
								store: tqValueListStore,
								triggerAction:'all'
							},
							
							{
		        		    	   xtype :'datefield',
		        		    	   fieldLabel: 'Start Date',
		        		    	   editable: false,
		        		    	   name:'startDate',
		        		    	   itemId:'startDatetq',
		        		    	   vtype:'daterange',
		        		    	   endDateField:'endDatetq'
		        		    },
		        		    {
		        		    	   xtype :'datefield',
		        		    	   fieldLabel: 'End Date',
		        		    	   editable: false,
		        		    	   name:'endDate',
		        		    	   itemId:'endDatetq',
		        		    	   vtype:'daterange',
		        		    	   startDateField:'startDatetq'
		        		    }
                       ]
            },
            
            {
                xtype: 'container',
                columnWidth:.2,
                layout: 'anchor',
                items: [
							{
								xtype :'combo',
								fieldLabel: 'LOPR',
								editable: false,
								name:'Lopr',
								displayField:'oprName',
								valueField:'oprId',
								store: CreateLoprStore(),
								listeners: {
									  'select': function(combo, value){
										  if(combo.getValue()==0){
											  this.up('window').down('form').getForm().findField("lPrefparameter").reset();
											  this.up('window').down('form').getForm().findField("lOpr").reset();
											  this.up('window').down('form').getForm().findField("lValueType").reset();
											  this.up('window').down('form').getForm().findField("lValue").reset();
											  this.up('window').down('form').getForm().findField("LvalueListName").reset();
											  this.up('window').down('form').getForm().findField("lStartDate").reset();
											  this.up('window').down('form').getForm().findField("lEndDate").reset();
											  //this.up('window').down('form').getForm().findField("lRopr").reset();
											  
											  this.up('window').down('form').getForm().findField("lPrefparameter").disable();
											  this.up('window').down('form').getForm().findField("lOpr").disable();
											  this.up('window').down('form').getForm().findField("lValueType").disable();
											  this.up('window').down('form').getForm().findField("lValue").disable();
											  this.up('window').down('form').getForm().findField("LvalueListName").disable();
											  this.up('window').down('form').getForm().findField("lStartDate").disable();
											  this.up('window').down('form').getForm().findField("lEndDate").disable();
											//  this.up('window').down('form').getForm().findField("lRopr").disable();
											  
											   }
										  else
											  {
											  this.up('window').down('form').getForm().findField("lPrefparameter").enable();
											  this.up('window').down('form').getForm().findField("lOpr").enable();
											  this.up('window').down('form').getForm().findField("lValueType").enable();
											  this.up('window').down('form').getForm().findField("lValue").enable();
											  this.up('window').down('form').getForm().findField("LvalueListName").enable();
											  this.up('window').down('form').getForm().findField("lStartDate").enable();
											  this.up('window').down('form').getForm().findField("lEndDate").enable();
											 // this.up('window').down('form').getForm().findField("lRopr").enable();
											 // alert(this.up('window').down('form').getForm().findField("dataSet").getValue());
											  if(this.up('window').down('form').getForm().findField("dataSet").getValue()==1)
												{
														paramStoreTqRight.filter(function(r) {
														var value = r.get('univId');
														return (value == 1 || value == 2);
													});
												}
												else
												{
													paramStoreTqRight.filter("univId",this.up('window').down('form').getForm().findField("dataSet").getValue());
												}
											  }
									  }
									 },
								
								triggerAction:'all'
							}
                        ]
            },
            
            {
                xtype: 'container',
                columnWidth:.3,
                id:'Lright',
                layout: 'anchor',
                items: [
                       
								{
								xtype :'combo',
								editable: false,
								allowBlank: false,
								fieldLabel: 'Param',
								name:'lPrefparameter',
								displayField:'paramName',
								valueField:'paramId',
								store: paramStoreTqRight,
							/*	queryMode: 'local',
									forceSelection: true,
									triggerAction: 'all',
									enableKeyEvents: true,
									selectOnFocus:true,
									typeAhead: true,
									disableKeyFilter: true, */
								listeners: {
									  'select': function(combo, value){
									  
									      oprFilter =   paramStoreTqRight.findRecord('paramId',combo.getValue(),0, false, true, true);
											
										
										  oprFilter = oprFilter.data.dtaType;
							
											if(combo.getValue()==2)
											oprFilter= 'S';
											
											
											
											oprStoreTqRight.clearFilter();
											
											if(oprFilter=='D')
											{
											this.up('window').down('form').getForm().findField("lStartDate").enable();
											 this.up('window').down('form').getForm().findField("lEndDate").enable();
											
											oprStoreTqRight.filter('dateFlag','Y');
											}
											if(oprFilter=='N')
											{
											this.up('window').down('form').getForm().findField("lStartDate").disable();
											this.up('window').down('form').getForm().findField("lEndDate").disable();
											
											oprStoreTqRight.filter('numberFlag','Y');
											}
											if(oprFilter=='S')
											{
											this.up('window').down('form').getForm().findField("lStartDate").disable();
											this.up('window').down('form').getForm().findField("lEndDate").disable();
											
											oprStoreTqRight.filter('stringFlag','Y');
											}

								}
								},
								triggerAction:'all'
							},

							{
								xtype :'combo',
								fieldLabel: 'OPR',
								editable: false,
								name:'lOpr',
								allowBlank: false,
								displayField:'oprName',
								valueField:'oprId',
								store: oprStoreTqRight,
							/*	queryMode: 'local',
									forceSelection: true,
									triggerAction: 'all',
									enableKeyEvents: true,
									selectOnFocus:true,
									typeAhead: true,
									disableKeyFilter: true, */
								listeners: {
									  'select': function(combo, value){
										
										this.up('window').down('form').getForm().findField("lValueType").reset();
										this.up('window').down('form').getForm().findField("lValue").reset();
										this.up('window').down('form').getForm().findField("lValue").disable();
										this.up('window').down('form').getForm().findField("LvalueListName").reset();
										this.up('window').down('form').getForm().findField("LvalueListName").disable();
										 if(combo.getValue()==14 || combo.getValue()==30)
											 {
											 this.up('window').down('form').getForm().findField("lValueType").disable();
											 this.up('window').down('form').getForm().findField("lValue").disable();
											 this.up('window').down('form').getForm().findField("LvalueListName").disable();
											  this.up('window').down('form').getForm().findField("lStartDate").enable();
											 this.up('window').down('form').getForm().findField("lEndDate").enable();
											
											 this.up('window').down('form').getForm().findField("lStartDate").allowBlank=false;
											 this.up('window').down('form').getForm().findField("lEndDate").allowBlank=false;
											 }
										 	else
										 	{
											this.up('window').down('form').getForm().findField("lStartDate").reset();
											this.up('window').down('form').getForm().findField("lEndDate").reset();
											this.up('window').down('form').getForm().findField("lValueType").enable();
											this.up('window').down('form').getForm().findField("lStartDate").allowBlank=true;
											this.up('window').down('form').getForm().findField("lEndDate").allowBlank=true;	 										 	}
									  }
									 },
								triggerAction:'all'
							},
							
							{
								xtype :'combo',
								fieldLabel: 'Value Type',
								editable: false,
								allowBlank: false,
								name:'lValueType',
								displayField:'valueTypeName',
								valueField:'valueTypeId',
								store: tqValueTypeStoreR,
								listeners: {
									  'select': function(combo, value){
										
										  if(combo.getValue()==1)
										  {
											  this.up('window').down('form').getForm().findField("lValue").enable();
											  this.up('window').down('form').getForm().findField("LvalueListName").disable();

										  }
										  
										  else
											  {
											  this.up('window').down('form').getForm().findField("lValue").disable();
											  this.up('window').down('form').getForm().findField("LvalueListName").enable();
											  this.up('window').down('form').getForm().findField("LvalueListName").reset();

											  }
									  }
									 },
								triggerAction:'all'
							},
							{
								xtype :'textfield',
								editable: false,
								fieldLabel: 'Value*',
								disabled : true,
								name:'lValue',
							//	allowBlank: false,
								enforceMaxLength  : true,
								maxLength:200,
								//maskRe:/[A-Za-z0-9_, ]/,
								listeners:{
			                        'change': function(field, newValue, oldValue){
			                            field.setValue(newValue.toUpperCase());
			                        }
			                     }
							},
							
							{
								xtype :'combo',
								editable: false,
								allowBlank: false,
								fieldLabel: 'Value*',
								disabled : true,
								name:'LvalueListName',
								displayField:'univName',
								valueField:'univName',
								store: tqValueListStore,
								triggerAction:'all'
							}
							,
								
							{
								xtype :'datefield',
								fieldLabel: 'Start Date',
								name:'lStartDate',
								editable: false,
								vtype:'daterange',
								itemId:'lStartDatetq',
								// endDateField:'lEndDatetq'
								listeners: {
									'select': function(datefield,value){

										if((this.up('window').down('form').getForm().findField("lEndDate").getValue()!=null) && 
												(this.up('window').down('form').getForm().findField("lStartDate").getValue()>this.up('window').down('form').getForm().findField("lEndDate").getValue()))
										{
											Ext.Msg.alert('info','Start date should not be greater than End date');
											this.up('window').down('form').getForm().findField("lStartDate").setValue();
										}
									}
								}
							},
								{
									xtype :'datefield',
									fieldLabel: 'End Date',
									editable: false,
									name: 'lEndDate',
									itemId:'lEndDatetq',
									vtype:'daterange',
									//startDateField:'lStartDatetq'
									listeners: {
										'select': function(datefield,value){
											if((this.up('window').down('form').getForm().findField("lStartDate").getValue()!=null) && 
													(this.up('window').down('form').getForm().findField("lEndDate").getValue()<this.up('window').down('form').getForm().findField("lStartDate").getValue()))
											{
												Ext.Msg.alert('info','End date should not be less than Start date');
												this.up('window').down('form').getForm().findField("lEndDate").setValue();
											}
										}
									}
								},
								,
								{
									xtype :'combo',
									fieldLabel: 'ROPR',
									editable: false,
									allowBlank: false,
									name:'lRopr',
									displayField:'oprName',
									valueField:'oprId',
									store: RoprStore,
									listeners: {
								  'select': function(combo, value){
							
								if((combo.getValue()==1)||(combo.getValue()==2)||(combo.getValue()==24))
								{
								
								//	updateFlagTq = 'No';
								
								}
							
							}
							},
									
									triggerAction:'all'
									
								},
								{
			        		    	   xtype :'textfield',
			        		    	   fieldLabel: 'CsrfName',
									   hidden:true,
			        		    	   disabled : true,
			        		    	   name: 'csrfTq',
									   maxLength : 100,
			        		    	   allowBlank:false,
			        		    	   id:'testCsrfTq'
			        		    }
                        
                       ]
            }]
        }
                  
                 ]
      }],
      buttons: [	
                	{
    	  				text: 'Save',
    	  				action: 'add'	  				
                	},
                	
   /*             	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
   */             	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.TqCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    views   : ['TqList', 'TqForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'TqForm',
      selector: 'TqForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'TqList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
        'TqList': {
          itemdblclick: this.onRowdblclick
        },
        'TqForm button[action=add]': {
          click: this.doAddTq
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	console.log(record.data);
    	tqCondId = record.data.condId;
    	tqCompId = record.data.compId;
		condRowIdTq = record.data.condRowId;
	  updateFlagTq = 'Yes';
	  
	  var win = this.getFormWindow();
	  
	  win.down('form').getForm().reset();
	  
	  //win.down('form').getForm().applyToFields({disabled:true});
      
	  //win.down('form').getForm().findField('compId').enable();
      
	  componentListStore.load({
		  callback: function(records, operation, success) {
			  if (success == true) {
				  if(record.data.compId!=null)
				  {
					  win.down('form').getForm().findField('compId').enable();
					  win.down('form').getForm().findField('compId').readOnly = true;
					  win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compId',record.data.compId,0, false, true, true));	
				  }
				  win.down('form').getForm().findField('condName').enable();
				  
				  dataSetStore.load({
						callback: function(records, operation, success) {
						if (success == true) {
						if(record.data.dataSetName!=null)
						{
						win.down('form').getForm().findField('dataSet').enable();
						win.down('form').getForm().findField('dataSet').setValue(dataSetStore.findRecord('dataSetName',record.data.dataSetName,0, false, true, true));
						}
				
				//Load Param
				
					  paramStore.load({
						callback: function(records, operation, success) {
						if (success == true) {
						if(record.data.perfParamName!=null)
						{
							win.down('form').getForm().findField('perfParmeter').enable();
							//win.down('form').getForm().findField('perfParmeter').setValue(paramStore.findRecord('paramName',record.data.perfParamName));
							paramStore.clearFilter();
							var dataSetId = dataSetStore.findRecord('dataSetName',record.data.dataSetName,0, false, true, true);
							dataSetId = dataSetId.data.dataSetId;

							if(dataSetId==1){
								paramStore.filter(function(r) {
									var value = r.get('univId');
									return (value == 1 || value == 2);
								});

							}else
							{
								paramStore.filter("univId",dataSetId);
							}
							win.down('form').getForm().findField('perfParmeter').setValue(paramStore.findRecord('paramName',record.data.perfParamName,0, false, true, true));
						}
				
				//Operator Load
						oprStoreTq.load({
							callback: function(records, operation, success) {
								if (success == true) {
									if(record.data.oprName!=null)
									{
										oprStoreTq.clearFilter();
										win.down('form').getForm().findField('opr').enable();
										win.down('form').getForm().findField('opr').setValue(oprStoreTq.findRecord('oprName',record.data.oprName));
										var  oprFilter =   paramStore.findRecord('paramName',record.data.perfParamName);
										oprFilter = oprFilter.data.dtaType;
										//oprStoreTq.clearFilter();

										if(oprFilter=='D')
										{
											oprStoreTq.filter('dateFlag','Y');
										}
										if(oprFilter=='N')
										{
											oprStoreTq.filter('numberFlag','Y');
										}
										if(oprFilter=='S')
										{
											oprStoreTq.filter('stringFlag','Y');
										}
									}
								}
							}
						});
				
				//ValueType
						tqValueTypeStore.load({
							callback: function(records, operation, success) {
								if (success == true) {
									if(record.data.valueTypeName!=null)
									{
										win.down('form').getForm().findField('valueType').enable();
										win.down('form').getForm().findField('valueType').setValue(tqValueTypeStore.findRecord('valueTypeName',record.data.valueTypeName,0, false, true, true));
										var dataSetId = dataSetStore.findRecord('dataSetName',record.data.dataSetName,0, false, true, true);
										dataSetId = dataSetId.data.dataSetId;
										tqValueListStore.clearFilter();
										tqValueListStore.filter("univId",dataSetId);
										if(record.data.valueTypeName=='Free Text')
										{
											win.down('form').getForm().findField("ValueListName").disable();
											win.down('form').getForm().findField("value").enable();
											win.down('form').getForm().findField("value").setValue(record.data.value);
										}
										if(record.data.valueTypeName=='Parameter')
										{
											win.down('form').getForm().findField("value").disable();
											win.down('form').getForm().findField("ValueListName").enable();
											tqValueListStore.load({
												callback: function(records, operation, success) {
													if (success == true) {
														if(record.data.value!=null)
														{
															win.down('form').getForm().findField('ValueListName').enable();
															win.down('form').getForm().findField('ValueListName').setValue(tqValueListStore.findRecord('univName',record.data.value,0, false, true, true));
														}
													}
												}
											});
										}
									}
									if(record.data.startDate!=null){
										win.down('form').getForm().findField('startDate').enable();	
									}else{
										win.down('form').getForm().findField('startDate').disable();
									}
									 	
									  
									  if(record.data.endDate!=null){
										  win.down('form').getForm().findField('endDate').enable();	  
									  }else{
										  win.down('form').getForm().findField('endDate').disable();
									  }
									 
									      // win.down('form').getForm().findField('value').setValue(oprStore.findRecord('oprName',record.data.value));
										  if(record.data.loprName){    
											win.down('form').getForm().findField('Lopr').enable();
											win.down('form').getForm().findField('Lopr').setValue(CreateLoprStore().findRecord('oprName',record.data.loprName));
											}else{
											win.down('form').getForm().findField('Lopr').enable();
											win.down('form').getForm().findField('Lopr').setValue(CreateLoprStore().findRecord('oprName','_BLANK'));
											}

											 paramStoreTqRight.load({
															callback: function(records, operation, success) {
															if (success == true) {
															if(record.data.lperfParamName!=null)
															{
																win.down('form').getForm().findField('lPrefparameter').enable();
																//win.down('form').getForm().findField('lPrefparameter').setValue(paramStoreTqRight.findRecord('paramName',record.data.lperfParamName,0, false, true, true));
																paramStoreTqRight.clearFilter();
																var dataSetId = dataSetStore.findRecord('dataSetName',record.data.dataSetName,0, false, true, true);
																dataSetId = dataSetId.data.dataSetId;
																if(dataSetId==1)
																{
																	paramStoreTqRight.filter(function(r) {
																		var value = r.get('univId');
																		return (value == 1 || value == 2);
																	});
																}
																else
																{
																	paramStoreTqRight.filter("univId",dataSetId,0, false, true, true);
																}
																win.down('form').getForm().findField('lPrefparameter').setValue(paramStoreTqRight.findRecord('paramName',record.data.lperfParamName,0, false, true, true));
															}
															else
															{
															win.down('form').getForm().findField('lPrefparameter').disable();
															}
													
													//Right OPr TQ
															oprStoreTqRight.load({
																callback: function(records, operation, success) {
																	if (success == true) {
																		if(record.data.l_loprName!=null)
																		{
																			win.down('form').getForm().findField('lOpr').enable();
																			win.down('form').getForm().findField('lOpr').setValue(oprStoreTqRight.findRecord('oprName',record.data.l_loprName));
																			oprFilter =   paramStoreTqRight.findRecord('paramName',record.data.lperfParamName,0, false, true, true);
																			oprFilter = oprFilter.data.dtaType;
																			oprStoreTqRight.clearFilter();
																			if(oprFilter=='D')
																			{
																				oprStoreTqRight.filter('dateFlag','Y');
																			}
																			if(oprFilter=='N')
																			{
																				oprStoreTqRight.filter('numberFlag','Y');
																			}
																			if(oprFilter=='S')
																			{
																				oprStoreTqRight.filter('stringFlag','Y');
																			}
																		}
																		else
																		{
																			win.down('form').getForm().findField('lOpr').disable();
																		}
																	}
																}
															});
														}
													}
												});

											 tqValueTypeStoreR.load({
												 callback: function(records, operation, success) {
													 if (success == true) {
														 if(record.data.lvalueTypeName!=null)
														 {
															 win.down('form').getForm().findField('lValueType').enable();
															 win.down('form').getForm().findField('lValueType').setValue(tqValueTypeStore.findRecord('valueTypeName',record.data.lvalueTypeName));
															 if(record.data.lvalueTypeName=='Free Text')
															 {
																 win.down('form').getForm().findField("LvalueListName").disable();
																 win.down('form').getForm().findField("lValue").enable();
																 win.down('form').getForm().findField("lValue").setValue(record.data.lValue);
															 }
															 if(record.data.lvalueTypeName=='Parameter')
															 {
																 win.down('form').getForm().findField("lValue").disable();
																 win.down('form').getForm().findField("LvalueListName").enable();
																 tqValueListStore.load({
																	 callback: function(records, operation, success) {
																		 if (success == true) {
																			 if(record.data.lValue!=null)
																			 {
																				 win.down('form').getForm().findField('LvalueListName').enable();
																				 win.down('form').getForm().findField('LvalueListName').setValue(tqValueListStore.findRecord('univName',record.data.lValue,0, false, true, true));
																			 }
																		 }
																	 }
																 });
															 }
														 }else{
															 win.down('form').getForm().findField('lValueType').disable();
															 win.down('form').getForm().findField("lValue").disable();
														 }
														 if(record.data.lStartDate!=null){
															  win.down('form').getForm().findField('lStartDate').enable();	  
														  }else{
															  win.down('form').getForm().findField('lStartDate').disable();
														  }
														 	
														  
														  if(record.data.lEndDate!=null){
															  win.down('form').getForm().findField('lEndDate').enable();  
														  }else{
															  win.down('form').getForm().findField('lEndDate').disable();
														  }
														  RoprStore.load({
															  callback: function(records, operation, success) {
																  if (success == true) {
																	  if(record.data.roprName!=null)
																	  {
																		  win.down('form').getForm().findField('lRopr').enable();
																		  win.down('form').getForm().findField('lRopr').readOnly = true;
																		  win.down('form').getForm().findField('lRopr').setValue(RoprStore.findRecord('oprName',record.data.roprName,0, false, true, true));
																		  RoprStore.clearFilter();
																		  RoprStore.filter("tqFlag",'Y');
																	  }
																  }
															  }
														  });
														  
													 }
												 }
											 });	
								}
							}
						});
					}
				}
			});
		}
	}
	});
			  }
		  }
	  });
	  
	 
	  //win.down('form').getForm().findField('condName').readOnly = true;
	
	
  
  

	    
 
    //  win.down('form').getForm().findField('lvalue').setValue(attributeTypeStore.findRecord('attributeTypeName',record.data.lValue));
     
  
	
      win.setTitle('Edit TQ');
      win.setAction('edit');
      win.setRecordIndex(record.data.condId);
      win.down('form').getForm().setValues(record.getData());
      win.show();
	   
	   //Ext.getCmp('tqCompList').setValue(componentListStore.findRecord('compId',componentListStore.data.items[0].data.compId));
			  if(!detailcond)
			  {
				  var bd = Ext.getCmp('details-panel').body;
				  bd.update('').setStyle('background','#fff');
				  detailcond = bd.createChild();
			  }
	  
			  componentStoreGrid.load({
				  callback: function(records, operation, success)
				  {
					  if(success==true)
					  {
						  var compName = componentStoreGrid.findRecord('compId',record.data.compId);
						  condBodyTq  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
						  updateTQCondPanel(record.data.compId);
					  }
				  }
			  });
    },

    copyCondition: function(){
    	
    },
    
    showAddForm: function () {
		RoprStore.clearFilter();
		RoprStore.filter("tqFlag",'Y');
    	if(compName!=null)
    	{
    		var win = this.getFormWindow();
    		win.down('form').getForm().findField('tqCompList').readOnly = false;
    		win.down('form').getForm().findField('dataSet').readOnly = false;
    		win.down('form').getForm().findField('condName').readOnly = false;			
    		win.down('form').getForm().findField('lRopr').readOnly = false;
    		console.log(win);
    		win.setTitle(SchemeName);
    		win.setAction('add');
    		win.down('form').getForm().reset();
    		win.down('form').getForm().findField('compId').enable();
    		win.down('form').getForm().findField('compId').readOnly = false;
    		win.down('form').getForm().findField('dataSet').enable();
    		win.down('form').getForm().findField('dataSet').readOnly = false;
    		win.down('form').getForm().findField('condName').enable();
    		win.down('form').getForm().findField('condName').readOnly = false;			
    		win.show();
    		if(!detailcond)
    		{
    			var bd = Ext.getCmp('details-panel').body;
    			bd.update('').setStyle('background','#fff');
    			detailcond = bd.createChild();
    		}
    		condBodyTq = '';
    		detailcond.hide().update(condBodyTq).slideIn('l', {stopAnimation:true,duration: 200});
    	}
    	else{
    		Ext.Msg.alert('Info', "Please create componenet for scheme first");	
    	}
    },

    doAddTq: function () {
    	var win = this.getFormWindow();
    	var action = win.getAction();
    	Ext.getCmp("testCsrfTq").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
    	if(action == 'edit') {
    		if(win.down('form').isValid())
    		{
    			if(updateFlagTq == 'Yes'){
    				updateTq(win);	
    			}else{
    				updateFlagTq = 'Yes';
    				saveTq(win);
    			}
    		}
    		else
    		{
    			Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
    		}
    	}else {
    		if(win.down('form').isValid()){
    			saveTq(win);
    		}else{
    			Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
    		}
    	}
    }
  });
});
var tqGridStatus = 0;
var stqGridStatus = 0;
var tqFreeTextType = null;
var tqCompId = null;
var tqCondId = null;
	function updateTQCondPanel(compIdUpdt)
	{
		var temp = null;
			tqStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
    

			condBodyTq  += '<p><b>TQ Cond...............................</b></p>';
			var temp = 0;
			for (i = 0; i < tqStore.data.items.length; i++) {
			
			var string = tqStore.data.items[i].data;
	
				if(string.compId==compIdUpdt)

				{
			if(temp!=string.condId)
			{
			condBodyTq += '<hr>';
			condBodyTq  += '<p><b>Cond No: &nbsp;'+string.condId+'&nbsp;&nbsp; Cond Name:&nbsp;'+string.condName+'</b></p>';
			//condBodyTq += '<hr>';
			temp = string.condId;
			}
			if(!string.startDate)
			condBodyTq  += '<p><b>('+string.perfParamName+'&nbsp;'+string.oprName+'&nbsp;'+string.value+')';
			else
			condBodyTq  += '<p><b>('+string.perfParamName+'&nbsp;'+string.oprName+'&nbsp;'+string.value+'&nbsp; Between &nbsp;'+string.startDate+'&nbsp; AND &nbsp;'+string.endDate+')';
			
			if(string.loprName)
			{
			if(!string.lStartDate)
			condBodyTq  += '&nbsp;'+string.loprName+'&nbsp;('+string.lperfParamName+'&nbsp;'+string.l_loprName+'&nbsp;'+string.lValue+')&nbsp;'+string.roprName+'</b></p>';
			else
			condBodyTq  += '&nbsp;'+string.loprName+'&nbsp;('+string.lperfParamName+'&nbsp;'+string.l_loprName+'&nbsp;'+string.lValue+'&nbsp; Between &nbsp;'+string.lStartDate+'&nbsp; AND &nbsp;'+string.lEndDate+')&nbsp;'+string.roprName+'</b></p>';
			
			}
			else
			{
			condBodyTq  += '&nbsp;'+string.roprName+'</b></p>';
			}
			
			if(string.roprName=='New Group')
			condBodyTq  += '<p><b>OR</b></p>';
			
			
		}	
				 	
	}				
			

			detailcond.hide().update(condBodyTq).slideIn('l', {stopAnimation:true,duration: 200});	

			
				  } else {
            // the store didn't load, deal with it
        }
    }
    // scope: this,
});
	
	
	
	
	
	
	}
	
 
 
function saveTq(tqForm)
{

	tqForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 //url : addTqUrl,
		 url : 'payoutcondition/addTq.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
		 success: function(form, action) {
            
            Ext.Msg.alert('Transaction Qualifier Created Sucessfully');
			
							formPanel.items.each(function(c){
		    	
						c.items.items[5].setDisabled(false);
					//	c.setActiveTab(c.items.items[5]);
						
						})

			
			
			
			
			tqStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
			if((action.result.tqData.lRopr==1)||(action.result.tqData.lRopr==2)||(action.result.tqData.lRopr==24)||(action.result.tqData.lRopr==23))
			{
			
			updateFlagTq = 'No';
			componentStoreGrid.load({
			callback: function(records, operation, success)
			{
			if(success==true)
			{
			
			var compName = componentStoreGrid.findRecord('compId',action.result.tqData.compId);
			condBodyTq  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
			updateTQCondPanel(action.result.tqData.compId);
			
			}
			}
			});
			
			
			tqForm.down('form').getForm().reset();
			
		//	tqForm.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compId',action.result.tqData.compId));
			tqForm.down('form').getForm().findField('compId').setValue(componentStoreGrid.findRecord('compId',action.result.tqData.compId));
			tqForm.down('form').getForm().findField('compId').readOnly = true;
			tqForm.down('form').getForm().findField('dataSet').setValue(dataSetStore.findRecord('dataSetId',action.result.tqData.dataSet));
			tqForm.down('form').getForm().findField('dataSet').readOnly = true;
			tqForm.down('form').getForm().findField('condName').setValue(action.result.tqData.condName);
			tqForm.down('form').getForm().findField('condName').readOnly = true;			
			
				if(action.result.tqData.lRopr==23)
				{
				//alert("Add New Condition");
				tqForm.down('form').getForm().findField('condName').disable();
				tqForm.down('form').getForm().findField('condName').enable();
				tqForm.down('form').getForm().findField('condName').reset();
				tqForm.down('form').getForm().findField('condName').readOnly = false;
				Ext.getCmp('tqCondName').readOnly = false;
				tqForm.down('form').getForm().findField('dataSet').reset();
				tqForm.down('form').getForm().findField('dataSet').readOnly = false;
				}

			
			
			
			}
			else
			{
			updateFlagTq = 'Yes';
			tqStore.load();
			tqForm.close();
			}
			
			}
			}
});
			
			
			
	
			 
			
			
			
			
			dataSourceStoreEa.load();
           
			parameterStoreEa.load();
                  
                    },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		Ext.Msg.alert('Warning', "Attribute Mapping Error");
        	
        }
    });
	
}


function updateTq(tqForm)
{

	tqForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/updateTq.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
		 
		 params: {
			  "compId" : tqCompId,
			  "condId":tqCondId,
			  "condRowId":condRowIdTq
		    
			
			},
        
		 success: function(form, action) {
            Ext.Msg.alert('Transaction Qualifier updated successfully');
            		tqStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
			if((action.result.tqData.lRopr==1)||(action.result.tqData.lRopr==2)||(action.result.tqData.lRopr==24)||(action.result.tqData.lRopr==23))
			{
			updateFlagTq = 'No';
			//alert(updateFlagTq);
			componentStoreGrid.load({
			callback: function(records, operation, success)
			{
			if(success==true)
			{
			
			var compName = componentStoreGrid.findRecord('compId',action.result.tqData.compId);
			condBodyTq  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
			updateTQCondPanel(action.result.tqData.compId);
			
			}
			}
			});
			
			
			tqForm.down('form').getForm().reset();
			
			tqForm.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compId',action.result.tqData.compId));
			tqForm.down('form').getForm().findField('compId').readOnly = true;
			
			tqForm.down('form').getForm().findField('dataSet').setValue(dataSetStore.findRecord('dataSetId',action.result.tqData.dataSet));
			tqForm.down('form').getForm().findField('dataSet').readOnly = true;
			tqForm.down('form').getForm().findField('condName').setValue(action.result.tqData.condName);
			tqForm.down('form').getForm().findField('condName').readOnly = true;			
			

				if(action.result.tqData.lRopr==23)
				{
				//alert("Add New Condition");
				tqForm.down('form').getForm().findField('condName').disable();
				tqForm.down('form').getForm().findField('condName').enable();
				tqForm.down('form').getForm().findField('condName').reset();
				tqForm.down('form').getForm().findField('condName').readOnly = false;
				Ext.getCmp('tqCondName').readOnly = false;
				tqForm.down('form').getForm().findField('dataSet').reset();
				tqForm.down('form').getForm().findField('dataSet').readOnly = false;
				}
			}
			else
			{
			updateFlagTq = 'Yes';
			
			tqStore.load();
			tqForm.close();
			}
			
			}
			}
});
	
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	
        }
    });
	
}



var TqValueList = new Ext.form.ComboBox({
	name:'value',
	fieldLabel:'Value*',
	displayField:'univName',
	valueField:'univName',
	allowBlank: false,
	autoLoad:false,
	editable: false,
	store: tqValueListStore,
   triggerAction:'all'
});

var TqValueText = new Ext.form.TextField({
	fieldLabel:'Value*',
	name:'value'
	   });
var TqValueDate = new Ext.form.DateField({
	fieldLabel:'Value*',
	name:'value'
	   });

var TqValueNumber = new Ext.form.NumberField({
	fieldLabel:'Value*',
	name:'value'
	
   
	   });


//L Part



var TqLValueList = new Ext.form.ComboBox({
	name:'lValue',
	fieldLabel:'Value*',
	displayField:'univName',
	valueField:'univName',
	allowBlank: false,
	autoLoad:false,
	editable: false,
	store: tqValueListStore,
   triggerAction:'all'
});

var TqLValueText = new Ext.form.TextField({
	fieldLabel:'Value*',
	name:'lValue'
	   });
var TqLValueDate = new Ext.form.DateField({
	fieldLabel:'Value*',
	name:'lValue'
	   });

var TqLValueNumber = new Ext.form.NumberField({
	fieldLabel:'Value*',
	name:'lValue'
	
   
	   });


var tqList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	
   items:[{
	   
     		xtype:'fieldset',
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     		
     		},
     		items :[
     			{
             		html: "<div id='tqlist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});

var stqList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	
   items:[{
	   
     		xtype:'fieldset',
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     		
     		},
     		items :[
     			{
             		html: "<div id='stqlist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
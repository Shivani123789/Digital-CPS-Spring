Ext.onReady(function () {
	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);
	function downloadPayment(qualify)
	{
		var grid = Ext.ComponentQuery.query('TransPaymentDataList')[0];
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		var urlParam;
		Ext.Msg.confirm('Trans Data', 
				'Download Scheme CSV', 
				function (button) {
			if (button == 'yes') {
				if(qualify==='PM'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId=0' +'&compId=0'+
					'&conditionId=0'+'&qualifyType=1'+'&transSubDataType=PM'+'&paymentId='+rs[0].data.paymentId+'&universeId=0';
					window.open(urlParam,'_BLANK');
				}
			}
		});
	}
	
	var transDataSearch1 = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		layout	   :'column',
		anchor	   : '100%',
		items       : [	
		{
			xtype       : 'datefield',
			id          : 'startDatepdTrans',
			allowBlank  : false,
			emptyText   : 'StartDate',
			name        : 'startDateTrans',
			//width       : 140,
			editable    : false
		},{
			xtype       : 'datefield',
			id          : 'endDatepdTrans',
			allowBlank  : false,
			emptyText   : 'EndDate',
			name        : 'endDateTrans',
			editable    : false
		},
		{
			   xtype :'textfield',
			   fieldLabel: 'CsrfName',
			   hidden:true,
			   disabled : true,
			   name: 'csrfPayment',
			   maxLength : 100,
			   allowBlank:false,
			   id:'testCsrfPayment'
		},

		{
			xtype       : 'button',
			text        : 'Go',
			width       : 40,
			handler     : function () {
				var transDatasd = Ext.Date.format(Ext.getCmp("startDatepdTrans").getValue(),'d-M-y');
				var transDataed = Ext.Date.format(Ext.getCmp("endDatepdTrans").getValue(),'d-M-y');

				var grid = Ext.ComponentQuery.query('TransPaymentDataList')[0];
				var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDatepdTrans").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDatepdTrans").getValue(),'Y/m/d'));
				if(flag){
					grid.store.load({params:
					{
						startDate  :	transDatasd,
						endDate    : 	transDataed
						//condParam : 	2,
					}});
				}
			}
		}]
	});

	
	
	Ext.define('Scheme.view.TransPaymentDataList', {
		extend: 'Ext.grid.Panel',
		id:'transPaymentDataGrid',
		stripeRows: true,
		pageSize : 10,
		flex: 2,
		width:'100%',
		height:300,
		layout : 'fit',
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TransPaymentDataList',
		//title: 'Transaction Payment Data',
		store: transPaymentDataGrid,
		//height:500,
		autoScroll: true,
		listeners: {
		    select: function(selModel, record, index, options){
		    	transPaySubDataGrid.load({params:
				{
		    		paymentId  :	record.data.paymentId ,
		    		//startDate : record.data.startDtStr,
		    		endDate : record.data.endDtStr
		    	}});
		    }
		},

		initComponent: function () {
			var me = this;
			this.tbar = [
			             		transDataSearch1
			             ];
			this.columns = [
			                { header: 'Payment Id', dataIndex: 'paymentId', flex: 1 },
			                { header: 'Pay To', dataIndex: 'displayValue', flex: 1 },
			                { header: 'Payment Date', dataIndex: 'paymentDt', flex: 1 },
			                { header: 'Payment Amount', dataIndex: 'paymentAmt', flex: 1 },
			                { header: 'Type', dataIndex: 'paymentType', flex: 1 },
			               // { header: 'Payment File', dataIndex: 'paymentFile', flex: 1 },
			               
			                { header: 'Extract', width: 80,
	    	                	renderer: function (v, m, r) {
									var id = Ext.id();
	    	                		Ext.defer(function () {
	    	                			Ext.widget('image', {
	    	                				renderTo: id,
	    	                				name: 'testRun22',
	    	                				src : 'resources/images/book_add.png',
	    	                				listeners : {
	    	                					afterrender: function (me) {
	    	                						me.getEl().on('click', function() {
	    	                							var grid = Ext.ComponentQuery.query('TransPaymentDataList')[0];
	    	                							var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDatepdTrans").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDatepdTrans").getValue(),'Y/m/d'));
	    	                							if (grid && flag) {
	    	                								var sm = grid.getSelectionModel();
	    	                								var rs = sm.getSelection();
	    	                								if (!rs.length) {
	    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
	    	                									return;
	    	                								}
	    	                								Ext.Msg.confirm('Extract Data', 
	    	                										'Do You want to Extract Data?', 
	    	                										function (button) {
	    	                									
	    	                									if (button == 'yes') {
	    	                										 Ext.ux.mask.show(); 
	    	                									Ext.Ajax.request({
	    	                				                     		  url : 'transData/getTransExecUniverseDataSearch.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
	    	                				                     		  method: 'POST',
	    	                				                     	//	 timeout:100000,
	    	                				                     		 waitMsg : 'Loading...',
	    	                				                     		 params: {
	    	                				                     			"paymentId"   : rs[0].data.paymentId,
			                												"compId"     : 0,
			                												"condId"     : 0,
			                												"condiParam" : 'PM',
			                												"success"    : true
	    	                				                 			    },
	    	                				                 			    
	    	                				                     		    success: function (response) {
	    	                				                     		    	 Ext.ux.mask.hide();
	    	                				                     		    	var jsonResp = Ext.JSON.decode(response.responseText);
	    	                				                    						if(jsonResp.success==false)	
	    	                				                    						{
	    	                				                    						Ext.Msg.alert(jsonResp.errorMessage);
	    	                				                    						}
	    	                				                    						else
	    	                				                    						Ext.Msg.alert("Info",jsonResp.errorMessage);
	    	                				                    				 
																		  grid.store.load({params:
																				{
																			 startDate : Ext.Date.format(Ext.getCmp("startDatepdTrans").getValue(),'d-M-y'),
																			 endDate : Ext.Date.format(Ext.getCmp("endDatepdTrans").getValue(),'d-M-y'),
																			 
																				}});
			                											    },
	    	                				                     		  failure: function (response) {
	    	                				                     			 Ext.ux.mask.hide();

	    	                				                     			var jsonResp = Ext.JSON.decode(response.responseText);
	    	                				                						if(jsonResp.success==false)	
	    	                				                						{
	    	                				                						Ext.Msg.alert(jsonResp.errorMessage);
	    	                				                						}
	    	                				                						else
	    	                				                						Ext.Msg.alert("Info",jsonResp.errorMessage);
	    	                				                			  }
	    	                				                     		 })	;
	    	                									}
	    	                								});
	    	                							}
	    	                						});
	    	                					}
	    	                				}
	    	                			});
	    	                		}, 700);
									return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                },

			                {
	    	                	header: 'Download',dataIndex: 'download', width: 80,
	    	                	renderer: function (v, m, r) {
	    	                		var id = Ext.id();
	    	                		Ext.defer(function() {
	    	                			Ext.widget('button', {
	    	                				renderTo: id,
	    	                				//		disabled : true,
	    	                				text: 'Download',
	    	                				scale: 'small',
	    	                				handler: function() {
	    	                					downloadPayment('PM');;
	    	                				}
	    	                			});
	    	                		}, 700);
	    	                		return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                },
			                { header: 'Paid By', dataIndex: 'paidBy', flex: 1 },
			                { header: 'Remarks', dataIndex: 'paymentremarks', flex: 1 },

			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : transPaymentDataGrid,
				dock : 'bottom',
				pageSize:10, 
				displayInfo : true
			}];
			this.callParent(arguments);
		},
	});

   Ext.define('Scheme.view.TransPaymentSubDataList', {
		extend: 'Ext.grid.Panel',
		id:'transPaymentSubDataGrid',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:190,
		layout : 'fit',
		
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TransPaymentSubDataList',
		title: 'Transaction Payment Sub Data',
		store: transPaySubDataGrid,
		//height:500,
		autoScroll: true,

		initComponent: function () {
			var me = this;
			this.tbar = [
			             //transSubDataSearch
			             ];
			this.columns = [
			                { header: 'Scheme Id', dataIndex: 'schemeId', flex: 1 },
			                { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
			                { header: 'Comp Id', dataIndex: 'compId', flex: 1 },
			                { header: 'Component Name', dataIndex: 'compName', flex: 1 },
			                { header: 'Start Date', dataIndex: 'startDt', flex: 1 },
			                { header: 'End Date', dataIndex: 'endDt', flex: 1 },
			                { header: 'Payment Amount', dataIndex: 'paymentAmt', flex: 1 },
			                { header: 'Head Count', dataIndex: 'totalEntity', flex: 1 },
			                { header: 'Max Pay', dataIndex: 'maxPayment', flex: 1 },
			                { header: 'Min Pay', dataIndex: 'minPayment', flex: 1 },
			                { header: 'Avg Pay', dataIndex: 'avgPayment', flex: 1 },
			                ];
			this.dockedItems = [];
			this.callParent(arguments);
		},
	});
	
	Ext.define('Scheme.controller.TransPayDataCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['TransPaymentDataList','TransPaymentSubDataList']
	});
  
   
});
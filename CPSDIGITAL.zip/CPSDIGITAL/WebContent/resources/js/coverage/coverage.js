
var covGridStatus = 0;
var scovGridStatus = 0;
var covFreeTextType = null;
var covlFreeTextType = null;
var covCompId = null;
var covCondId = null;








	function updateCovCondPanel(compIdUpdt)
	
	{
	
		var temp = null;
 	
	
			coverageStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
    
				condBody  += '<p><b>Coverage Condition</b></p>';
				condBody  += '<hr>';
			for (var i = 0; i < coverageStore.data.items.length; i++) {
			
			var string = coverageStore.data.items[i].data;
			
			if(string.compId==compIdUpdt)
			
			{
			
			if(temp!=string.condId)
			{
			condBody  += '<hr>';
					condBody  += '<p><b>Cond No: &nbsp;'+string.condId+'</b></p>';
					
			
			temp = string.condId;
			}
			
			
			if(string.loprName)
			{
			if(string.endDate)
			condBody  += '<p><b>(('+string.entityName+'&nbsp;'+string.attrTypeName+'&nbsp;'+string.functionName+'&nbsp;'+string.attrMappingName+'&nbsp;'+string.oprName+'&nbsp;'+string.startDate+'&nbsp'+string.endDate+')';
			else
			condBody  += '<p><b>(('+string.entityName+'&nbsp;'+string.attrTypeName+'&nbsp;'+string.functionName+'&nbsp;'+string.attrMappingName+'&nbsp;'+string.oprName+'&nbsp;&nbsp'+string.value+')';
			}
			
			else
			{
			if(string.endDate)
			condBody  += '<p><b>('+string.entityName+'&nbsp;'+string.attrTypeName+'&nbsp;'+string.functionName+'&nbsp;'+string.attrMappingName+'&nbsp;'+string.oprName+'&nbsp;'+string.startDate+'&nbsp'+string.endDate+')';
			else
			condBody  += '<p><b>('+string.entityName+'&nbsp;'+string.attrTypeName+'&nbsp;'+string.functionName+'&nbsp;'+string.attrMappingName+'&nbsp;'+string.oprName+'&nbsp;&nbsp'+string.value+')';
			}
			if(string.loprName)
			{
			condBody  += '&nbsp;'+string.loprName+'&nbsp;('+string.lentityTypeName+'&nbsp;'+string.attrTypeName+'&nbsp;'+string.lfunctionName+'&nbsp;'+string.lattNameString+'&nbsp;'+string.lloprName+'&nbsp;'+string.lStartDate+'&nbsp'+string.lEndDate+'&nbsp'+string.lvalueName+'))'+string.roprName+'';
			
			}
			else
			{
			condBody  += '&nbsp;'+string.roprName+'</b></p>';
			}
			
			
		}	
				 	
	}
	
			detailcondcov.hide().update(condBody).slideIn('l', {stopAnimation:true,duration: 200});
               

				  } else {
            // the store didn't load, deal with it
        }
    }
    // scope: this,
});
	
	
	
	
	
	
	}
	








function saveCoverage(coverageForm)
{

	coverageForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		// url : addCoverageUrl,
		 url : 'payoutcondition/addCoverage.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
		 
		 success: function(form, action) {
            Ext.Msg.alert('Coverage Created Sucessfully');
            
            
			componentListStoreCov.load();
			
			coverageStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					condBody  = '<p><b>Coverage Condition</b></p>';
					condBody  += '<hr>';
                  
               

			if((action.result.covData.rOpr==1)||(action.result.covData.rOpr==2))
			{
			
			updateFlagCov = 'No';
			
	componentStoreGrid.load({
			callback: function(records, operation, success)
			{
			if(success==true)
			{
			
			var compName = componentStoreGrid.findRecord('compId',action.result.covData.compId);
			condBody  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
			updateCovCondPanel(action.result.covData.compId);
			
			}
			}
			});
			
	
			
			coverageForm.down('form').getForm().reset();
			
			Ext.getCmp('compId').setValue(componentListStore.findRecord('compId',action.result.covData.compId));
			coverageForm.down('form').getForm().findField('compId').readOnly = true;
			//alert("test entity ::: "+action.result.covData.entityId);
			Ext.getCmp('entityId').setValue(entityStore.findRecord('entityId',action.result.covData.entityId));
			coverageForm.down('form').getForm().findField('entityId').readOnly = true;
			
			coverageForm.down('form').getForm().findField("lEntityType").disable();
									  coverageForm.down('form').getForm().findField("lAttrType").disable();
									  coverageForm.down('form').getForm().findField("lOpr").disable();
									  coverageForm.down('form').getForm().findField("lFunction").disable();
									  coverageForm.down('form').getForm().findField("lAttName").disable();
									  coverageForm.down('form').getForm().findField("lValueType").disable();
									  coverageForm.down('form').getForm().findField("LvalueListName").disable();
									  coverageForm.down('form').getForm().findField("lVfunction").disable();
									  coverageForm.down('form').getForm().findField("lStartDate").disable();
									  coverageForm.down('form').getForm().findField("lEndDate").disable();
									//  this.up('window').down('form').getForm().findField("rOpr").disable();
									  coverageForm.down('form').getForm().findField("lValue").disable();
										Ext.getCmp('Lopr').setValue(CreateLoprStore().findRecord('oprId',0));
										Ext.getCmp('rOpr').setValue(RoprStore.findRecord('oprId',26));
			
			}
			
			else
			{
			updateFlagCov = 'Yes';
			coverageForm.close();
			
			formPanel.items.each(function(c){
		    	
			c.items.items[4].setDisabled(false);
						c.setActiveTab(c.items.items[4]);
						
						});
			}
			
			   
			   detailcondcov.hide().update(condBody).slideIn('l', {stopAnimation:true,duration: 200});
			   
			   
			   
				  } else {
            // the store didn't load, deal with it
        }
    }
    // scope: this,
});
			        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		{
            	//	if(action.response.status=403)
            	//		Ext.Msg.alert('Warning','Access Denied' );
            //		else
            		Ext.Msg.alert('Warning', "Attribite Mapping Error");
            	}

        	
        }
    });
	
}

function updateCoverage(coverageForm)
{

	coverageForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/updateCov.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
        
		 params: {
			  "compId" : covCompId,
			  "condId":covCondId,
			  "condRowId": condRowIdCov
		    },
  
		 success: function(form, action) {
            Ext.Msg.alert('Coverage updated Sucessfully');
                    coverageStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
					condBody  = '<p><b>Coverage Condition</b></p>';
					condBody  += '<hr>';
                  if(coverageStore.getCount()>0)
					{
			  Ext.getCmp('addCoverage').setText('Add Coverage');
			   }
			   
			   else
			   Ext.getCmp('addCoverage').enable();
               

			if((action.result.covData.rOpr==1)||(action.result.covData.rOpr==2))
			{
			
			updateFlagCov = 'No';
		
				componentStoreGrid.load({
			callback: function(records, operation, success)
			{
			if(success==true)
			{
			
			var compName = componentStoreGrid.findRecord('compId',action.result.covData.compId);
			condBody  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
			updateCovCondPanel(action.result.covData.compId);
			
			}
			}
			});
			coverageForm.down('form').getForm().reset();
			Ext.getCmp('compId').setValue(componentListStore.findRecord('compId',action.result.covData.compId));
			coverageForm.down('form').getForm().findField('compId').readOnly = true;
		
			Ext.getCmp('entityId').setValue(entityStore.findRecord('entityId',action.result.covData.entityId));
			coverageForm.down('form').getForm().findField('entityId').readOnly = true;
			
			}
			
			else
			{
				updateFlagCov = 'Yes';
			coverageForm.close();
			
			formPanel.items.each(function(c){
		    	
			c.items.items[4].setDisabled(false);
						c.setActiveTab(c.items.items[4]);
						c.items.items[3].setDisabled(false);
						c.setActiveTab(c.items.items[3]);
			
						});

			
			}
			
			   
			 detailcondcov.hide().update(condBody).slideIn('l', {stopAnimation:true,duration: 200});
			   
			   
			   
				  } else {
            // the store didn't load, deal with it
        }
    }
    // scope: this,
});
			
			
			
	
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied');
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        		}
        }
    });
}


var valueList = new Ext.form.ComboBox({
	name:'value',
	fieldLabel:'Value*',
	displayField:'entityAttributeName',
	valueField:'entityAttributeName',
	allowBlank: false,
	editable: false,
	store: entityAttrStore,
   triggerAction:'all'
	   });

var valueText = new Ext.form.TextField({
	fieldLabel:'Value*',
	name:'value'
	   });
var valueDate = new Ext.form.DateField({
	fieldLabel:'Value*',
	name:'value'
	   });

var valueNumber = new Ext.form.NumberField({
	fieldLabel:'Value*',
	name:'value'
	
   
	   });



//Lvalue Fields
var lvalueList = new Ext.form.ComboBox({
	name:'lValue',
	fieldLabel:'Value*',
	displayField:'entityAttributeName',
	valueField:'entityAttributeName',
	allowBlank: false,
	editable: false,
	store: entityAttrStore,
   triggerAction:'all'
	   });
var lvalueText = new Ext.form.TextField({
	fieldLabel:'Value*',
	name:'lValue'
	   });
var lvalueDate = new Ext.form.DateField({
	fieldLabel:'Value*',
	name:'lValue'
	   });

var lvalueNumber = new Ext.form.NumberField({
	fieldLabel:'Value*',
	name:'lValue'
	
   
	   });

	   
	   
	 /*  var covList = {
          id: 'covlist',
            //title: 'Cov List',
            layout: 'fit',
            bodyStyle: 'padding:25px',
            html: "<div id='covlist'></div>"  // pull existing content from the page
    };
	   */

var covList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
	
	
 	
   items:[{
	   
     		xtype:'fieldset',
     		//layout: 'anchor',
     		border:false,
     		height:'500',
			layout:'fit',
     		//autoscroll:true,
			html: "<div id='covlist'></div>",
     		defaults: {
     		//anchor: '100%'
     		}
     		/*items :[
     			{
             		html: "<div id='covlist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]*/
			
			}
     	
   ]
   
   });


var scovList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	
   items:[{
	   
     		xtype:'fieldset',
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     		},
     		items :[
     			{
             		html: "<div id='scovlist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
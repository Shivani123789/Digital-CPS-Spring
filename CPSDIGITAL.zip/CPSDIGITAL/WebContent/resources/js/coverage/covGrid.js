Ext.onReady(function () {
	Ext.define('Scheme.model.Cov', {
		extend: 'Ext.data.Model',
		fields: [
		         {name: 'compId', type: 'int'},
		         {name: 'compName',  type: 'string'},
		         {name: 'condId', type: 'int'},
		         {name: 'valueField',  type: 'string'},
		         {name: 'Lopr',  type: 'string'},
		         {name: 'lValue',  type: 'string'},
		         {name: 'rOpr',  type: 'string'}


		         ]
	});

	var entityType = null;
	var oprFilterCov1 = null;
	var oprFilterCov2 = null;
	var oprFilterCov3 = null;
//	var entityAttrVar=null;
//	var entityTypeVar=null;
	//var stdateCov = null;
	//var enddateCov = null;

	var detailsPanelCov = {
			id: 'covDetailPanel',
			title: 'Cond Details',
			//  region:'west',
			collapsible: true,
			height : 200,
			width: 1100,
			//  bodyStyle: 'padding-bottom:15px;background:#eee;',
			autoScroll: true,
			html: '<p class="details-info"> Cov Cond Detail Will appear here...................................</p>'
	};


	Ext.define('Scheme.view.CovList', {
		extend: 'Ext.grid.Panel',
		name:'covGrid',
		id:'covGrid',
		pageSize : 5,
		alias: 'widget.CovList',
		title: 'Coverage List',
		store: coverageStore,
		selModel : Ext.create('Ext.selection.CheckboxModel'),
		height:500,
		// layout:'fit',
		autoScroll: true,
		 features: [groupingFeatureCOV],
		//  store : 'Companies',
		initComponent: function () {
			this.tbar = [
			             {
			            	 xtype       : 'image',
			            	 src : 'resources/images/book_delete.png',
			            	 listeners:
			            	 {
			            		 afterrender: function(me)
			            		 {
			            			 me.getEl().on('click', function () {

			            				 var grid=Ext.ComponentQuery.query('CovList')[0];
			            				 var sm=grid.getSelectionModel();
			            				 var rs=sm.getSelection();
			            				 var delReqCov="";
			            				 if(rs.length)
			            				 {
			            					 for(var z=0;z<rs.length;z++)
			            					 {
			            						 if((z+1)!=rs.length)
			            						 {
			            							 delReqCov=delReqCov+rs[z].data.compId+":"+rs[z].data.condId+":"+rs[z].data.condRowId+",";
			            						 }
			            						 else
			            						 {
			            							 delReqCov=delReqCov+rs[z].data.compId+":"+rs[z].data.condId+":"+rs[z].data.condRowId;
			            						 }
			            					 }
			            				 }
			            				 if(!rs.length)
			            				 {
			            					 Ext.Msg.alert('Info', 'No Covearge Selected');
			            					 return;
			            				 }
			            				 Ext.Msg.confirm('Remove Coverage', 
			            						 'Are you sure you want to delete Coverage?',
			            						 function(button)
			            						 {
			            					 if(button=='yes')
			            					 {
			            						 Ext.Ajax.request(
			            								 {
			            									 url : 'payoutcondition/removeCov.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
			            									 method: 'POST',
			            									 params: {
			            										 "co_ValueTypeName":delReqCov
			            									 },
			            									 success: function(resp)
			            									 {
			            										 var response = Ext.decode(resp.responseText);
			            										 if(response.success)
			            										 {
			            											 Ext.Msg.alert("Info","Coverage deleted successfully");

			            											 coverageStore.load();
			            											 componentListStoreCov.load();
			            											 grid.store.remove(rs[0]);

			            										 }
			            										 else
			            										 {
			            											 Ext.Msg.alert("Warning",response.message);
			            										 }
			            									 }
			            								 });
			            					 }
			            						 });
			            			 });
			            		 }
			            	 }
			             },
			{
				text    : 'Add',
				id :'addCoverage',
				action  : 'add',
				iconCls : 'book-add'
			}
            /*{
           	 itemId: 'copyCOV',
           	 text: 'Copy Condition',
           	 iconCls: 'employee-copy',
           	 //disabled: true,
           	 handler: function() {
           		 var grid = Ext.ComponentQuery.query('CovList')[0];
           		 if (grid) {
           			 var sm = grid.getSelectionModel();
           			 var rs = sm.getSelection();
           			 if (!rs.length) {
           				 Ext.Msg.alert('Info', 'No Coverage Selected');
           				 return;
           			 }
           			 Ext.Msg.confirm('Copy TQ', 
           					 'Are you sure you want to copy Coverage condition?', 
           					 function (button) {
           				 if (button == 'yes') {

           					 var tqParamVal = true;

           					 for(var i=0; i<rs.length; i++)
           					 {
           						 if((i+1) != rs.length){
           							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
           								 tqParamVal=false;
	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To copy condition.</font>");
           							 }
           						 }else{
           							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
           								 tqParamVal=false;	  
	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To copy condition.</font>");
           							 }
           						 }
           					 }

           					 if(tqParamVal){ 
           						 Ext.Ajax.request({
           							 url : 'schemeinput_tq/copyCondition.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
           							 method: 'POST',
           							 params: {
           								 "compId" : rs[0].data.compId,
           								 "condId" : rs[0].data.condId,
           								 "processType" : 'CO',        
           							 },
           							 success: function (response) {
           								 var response1 = Ext.decode(response.responseText);
           								 Ext.Msg.alert("Info",response1.message);
           								 coverageStore.load();
										 componentListStoreCov.load();
           							 },
           							 failure: function (response) {
           							 }
           						 });
           					 }
           				 }
           			 });
           		 }
           	 }
            }
*/			
			];
			this.columns = [

			                { header: 'compId', dataIndex: 'compId', flex: 1 },
			                { header: 'Cond_Id', dataIndex: 'condId', flex: 1 },
			                { header: 'Cond_Row', dataIndex: 'condRowId', flex: 1 },
			                { header: 'Entity', dataIndex: 'entityName', flex: 1 },
			                { header: 'AttrType', dataIndex: 'attrTypeName', flex: 1  },
			                { header: 'AttrMap', dataIndex: 'attrMappingName', flex: 1  },
			                { header: 'Function', dataIndex: 'functionName', flex: 1  },
			                { header: 'Opr', dataIndex: 'oprName', flex: 1  },
			                { header: 'ValType', dataIndex: 'co_ValueTypeName', flex: 1  },
			                { header: 'Function', dataIndex: 'co_functionName', flex: 1  },
			                { header: 'value', dataIndex: 'value', flex: 1  },
			                { header: 'Sdate', dataIndex: 'startDate', flex: 1  },
			                { header: 'EDate', dataIndex: 'endDate', flex: 1  },
			                { header: 'Lopr', dataIndex: 'loprName', flex: 1  },
			                { header: 'L_Entity', dataIndex: 'lentityTypeName', flex: 1  },
			                { header: 'L_AttrType', dataIndex: 'lattrTypeName', flex: 1  },
			                { header: 'L_Function', dataIndex: 'lfunctionName', flex: 1  },
			                { header: 'L_AttrMap', dataIndex: 'lattNameString', flex: 1  },
			                { header: 'L_Opr', dataIndex: 'lloprName', flex: 1  },
			                { header: 'L_ValueType', dataIndex: 'lvalueTypeName', flex: 1  },
			                { header: 'L_Function', dataIndex: 'lvfunctionName', flex: 1  },
			                { header: 'L_Value', dataIndex: 'lvalueName', flex: 1  },
			                { header: 'L_Sdate', dataIndex: 'lStartDate', flex: 1  },
			                { header: 'L_Edate', dataIndex: 'lEndDate', flex: 1  },
			                { header: 'Ropr', dataIndex: 'roprName', flex: 1 },
			                /*{ header: 'Action', flex: 1,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		var max = 15;
			                		Ext.defer(function () {
			                			Ext.widget('image', {
			                				renderTo: id,
			                				name: 'delete',
			                				src : 'resources/images/book_delete.png',
			                				listeners : {
			                					afterrender: function (me) { 
			                						me.getEl().on('click', function() {
			                							var grid = Ext.ComponentQuery.query('CovList')[0];
			                							if (grid) {
			                								var sm = grid.getSelectionModel();
			                								var rs = sm.getSelection();
			                								if (!rs.length) {
			                									Ext.Msg.alert('Info', 'No Covearge Selected');
			                									return;
			                								}
			                								Ext.Msg.confirm('Remove Coverage', 
			                										'Are you sure you want to delete Coverage?', 
			                										function (button) {
			                									if (button == 'yes') {

			                										Ext.Ajax.request({
			                											url : 'payoutcondition/removeCov.action',
			                											method: 'POST',
			                											params: {
			                												"compId" : rs[0].data.compId,
			                												"condId" :rs[0].data.condId,
			                												"condRowId" :rs[0].data.condRowId
			                											},
			                											success: function (resp) {
			                												var response = Ext.decode(resp.responseText);
			                												if(response.success)
			                												{
			                													Ext.Msg.alert("Info","Coverage deleted successfully");
			                													componentListStoreCov.load();

			                													grid.store.remove(rs[0]);

			                												}
			                												else
			                												{
			                													Ext.Msg.alert("Warning",response.message);
			                												}
			                											},

			                											failure: function (resp) {


			                											}
			                										});

			                									}
			                								});
			                							}
			                						});
			                					}
			                				}
			                			});
			                		}, 50);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                }*/
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : coverageStore,
				dock : 'bottom',
				displayInfo : true
			} ];

			this.callParent(arguments);
		}
	});

	Ext.define('Scheme.view.CovForm', {
		extend  : 'Ext.window.Window',
		alias   : 'widget.CovForm',
		title   : 'Add Coverage',
		layout  : 'fit',
		resizable: false,
		closeAction: 'hide',
		modal   : true,
		config  : {
			recordIndex : 0,
			action : ''
		},
		items   : [{
			xtype : 'form',
			layout: 'anchor',
			bodyStyle: {
				background: 'none',
				padding: '10px',
				border: '0'
			},
			defaults: {
				anchor: '100%'
			},
			items : [
			         detailsPanelCov,
			         {
			        	 xtype: 'fieldset',
			        	 anchor: '100%',
			        	 title: 'Coverage Details',
			        	 collapsible: true,
			        	 layout:'column',
			        	 items:[
			        	        {
			        	        	xtype: 'container',
			        	        	columnWidth:.2,
			        	        	layout: 'anchor',
			        	        	items: [
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	allowBlank: false,
			        	        	        	id: 'compId',
			        	        	        	fieldLabel: 'Component',
			        	        	        	name:'compId',
			        	        	        	displayField:'compName',
			        	        	        	valueField:'compId',
			        	        	        	store: componentListStoreCov,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			var compName = componentListStoreCov.findRecord('compId',combo.getValue());
			        	        	        			condBody  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
			        	        	        			updateCovCondPanel(combo.getValue());
			        	        	        			this.up('window').down('form').getForm().findField("attrType").allowBlank=false;
			        	        	        			this.up('window').down('form').getForm().findField("attrName").allowBlank=false;
			        	        	        			this.up('window').down('form').getForm().findField("opr").allowBlank=false;
			        	        	        			this.up('window').down('form').getForm().findField("co_ValueType").allowBlank=false;
			        	        	        			/*var compNameTest = componentStoreGrid.findRecord('compId',combo.getValue());
			        	        	        			stdateCov = compNameTest.data.startDate;
			        	        	        			enddateCov = compNameTest.data.endDate;
			        	        	        			*///  alert("startDtStr::: "+compNameTest.data.startDate);
			        	        	        		}
			        	        	        	},

			        	        	        	triggerAction:'all'
			        	        	        } 

			        	        	        ]
			        	        },

			        	        {
			        	        	xtype: 'container',
			        	        	columnWidth:.3,
			        	        	// id:'addtome',
			        	        	layout: 'anchor',
			        	        	items: [
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'Entity',
			        	        	        	editable: false,
			        	        	        	name:'entityId',
			        	        	        	id:'entityId',
			        	        	        	// multiSelect: true,
			        	        	        	displayField:'entityName',
			        	        	        	autoLoad:false,
			        	        	        	valueField:'entityId',
			        	        	        	store:entityStore,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			
			        	        	        			entityType  = combo.getValue();	
			        	        	        			if(Ext.getCmp("Lopr").getValue()!=0)
			        	        	        			Ext.getCmp('lEntityType').setValue(entityStore.findRecord('entityId',entityType,0, false, true, true));
			        	        	        			entityStoreCovRight.filter('entityId',entityType);
			        	        	        			this.up('window').down('form').getForm().findField("attrName").reset();
			        	        	        			this.up('window').down('form').getForm().findField("attrType").reset();

			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'Attribute Type',
			        	        	        	editable: false,
			        	        	        	name:'attrType',
			        	        	        	displayField:'attributeTypeName',
			        	        	        	valueField:'attributeTypeId',
			        	        	        	store: attributeTypeStore,
			        	        	        	id:'attrType',
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			entityAttrStore.clearFilter();
			        	        	        			//entityTypeVar=combo.getValue();
			        	        	        			entityAttrStore.filter(function(r) {
			        	        	        				var value = r.get('attrCatg');
			        	        	        				var value2 = r.get('attrType');
			        	        	        				return (value == combo.getValue() && value2 == entityType);
			        	        	        			});
			        	        	        			if(Ext.getCmp("Lopr").getValue()!=0)
			        	        	        			//Ext.getCmp('lAttrType').setValue(attributeTypeStore.findRecord('attributeTypeId',combo.getValue(),0, false, true, true));
			        	        	        			//attributeTypeStoreCovRight.filter('attributeTypeId',combo.getValue());	
			        	        	        			this.up('window').down('form').getForm().findField("attrName").reset();

			        	        	        			if(combo.getValue()==8)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("startDatecov").enable();
			        	        	        				this.up('window').down('form').getForm().findField("endDatecov").enable();

			        	        	        				//this.up('window').down('form').getForm().findField("startDate").setValue(stdateCov);
			        	        	        				//this.up('window').down('form').getForm().findField("endDate").setValue(enddateCov);

			        	        	        				// this.up('window').down('form').getForm().findField("function").enable();

			        	        	        				//this.up('window').down('form').getForm().findField("co_vFunction").enable();

			        	        	        			}									

			        	        	        			else
			        	        	        			{
			        	        	        				//this.up('window').down('form').getForm().findField("startDate").disable();
			        	        	        				//this.up('window').down('form').getForm().findField("endDate").disable();

			        	        	        				this.up('window').down('form').getForm().findField("function").disable();
			        	        	        				this.up('window').down('form').getForm().findField("co_vFunction").disable();

			        	        	        			}

			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	fieldLabel: 'Function',
			        	        	        	editable: false,
			        	        	        	name:'function',
			        	        	        	disabled: true,
			        	        	        	displayField:'functionName',
			        	        	        	valueField:'functioId',
			        	        	        	store: covFunctionStore,
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: true,
			        	        	        	fieldLabel: 'Entity Attribute',
			        	        	        	name:'attrName',
			        	        	        	displayField:'entityAttributeName',
			        	        	        	valueField:'entityAttributeId',
			        	        	        	store: entityAttrStore,
			        	        	        	id:'attrName',
			        	        	        	//emptyText:'Select a entity  attribute...',
			        	        	        	//forceSelection: true,
			        	        	        	//triggerAction: 'all',
			        	        	        	//enableKeyEvents: true,
			        	        	        	//selectOnFocus:true,
			        	        	        	//typeAhead: true,
			        	        	        	//disableKeyFilter: true,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){

			        	        	        			entityAttrStore.findBy(function(record,id) {
			        	        	        				if(record.get('entityAttributeId')==combo.getValue()) {
			        	        	        					covFreeTextType = record.data.freeTextType;
			        	        	        				}
			        	        	        			});

			        	        	        			if(Ext.getCmp("Lopr").getValue()!=0)
			        	        	        			//Ext.getCmp('lAttName').setValue(entityAttrStore.findRecord('entityAttributeId',combo.getValue(),0, false, true, true));
			        	        	        			//LentityAttrStore.filter('entityAttributeId',combo.getValue());
			        	        	        			
			        	        	        			this.up('window').down('form').getForm().findField("opr").reset();

			        	        	        		//	alert("conbo ::"+combo.getValue());
			        	        	        			oprFilterCov1 =   entityAttrStore.findRecord('entityAttributeId',combo.getValue());

			        	        	        			//entityAttrVar=combo.getValue();
			        	        	        			oprFilterCov1 = oprFilterCov1.data.operatorFlag;

			        	        	        			oprStore.clearFilter();

			        	        	        			if(oprFilterCov1=='D')
			        	        	        			{
			        	        	        				//this.up('window').down('form').getForm().findField("startDate").enable();
			        	        	        				//this.up('window').down('form').getForm().findField("endDate").enable();
			        	        	        				this.up('window').down('form').getForm().findField("startDatecov").allowBlank=false;
			        	        	        				this.up('window').down('form').getForm().findField("endDatecov").allowBlank=false;
			        	        	        				//this.up('window').down('form').getForm().findField("startDate").setValue(stdateCov);
			        	        	        				//this.up('window').down('form').getForm().findField("endDate").setValue(enddateCov);

			        	        	        				oprStore.filter('dateFlag','Y');
			        	        	        			}
			        	        	        			if(oprFilterCov1=='N')
			        	        	        			{
			        	        	        				//this.up('window').down('form').getForm().findField("startDate").disable();
			        	        	        				//this.up('window').down('form').getForm().findField("endDate").disable();

			        	        	        				oprStore.filter('numberFlag','Y');
			        	        	        			}
			        	        	        			if(oprFilterCov1=='S')
			        	        	        			{
			        	        	        				//this.up('window').down('form').getForm().findField("startDate").disable();
			        	        	        				//this.up('window').down('form').getForm().findField("endDate").disable();

			        	        	        				oprStore.filter('stringFlag','Y');
			        	        	        			}


			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },

			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	fieldLabel: 'OPR',
			        	        	        	name:'opr',
			        	        	        	displayField:'oprName',
			        	        	        	valueField:'oprId',
			        	        	        	store: oprStore,
			        	        	        /*	queryMode: 'local',
												forceSelection: true,
												triggerAction: 'all',
												enableKeyEvents: true,
												selectOnFocus:true,
												typeAhead: true,
												disableKeyFilter: true,*/
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			this.up('window').down('form').getForm().findField("co_ValueType").reset();
			        	        	        			this.up('window').down('form').getForm().findField("value").reset();
			        	        	        			this.up('window').down('form').getForm().findField("value").disable();
			        	        	        			this.up('window').down('form').getForm().findField("ValueListName").reset();
			        	        	        			this.up('window').down('form').getForm().findField("ValueListName").disable();
			        	        	        			if(combo.getValue()==14)
			        	        	        			{

			        	        	        				this.up('window').down('form').getForm().findField("co_ValueType").disable();
			        	        	        				this.up('window').down('form').getForm().findField("value").disable();
			        	        	        				this.up('window').down('form').getForm().findField("ValueListName").disable();
			        	        	        				this.up('window').down('form').getForm().findField("startDatecov").enable();
			        	        	        				this.up('window').down('form').getForm().findField("endDatecov").enable();
			        	        	        				this.up('window').down('form').getForm().findField("startDatecov").allowBlank=false;
			        	        	        				this.up('window').down('form').getForm().findField("endDatecov").allowBlank=false;
			        	        	        				//this.up('window').down('form').getForm().findField("startDate").setValue(stdateCov);
			        	        	        				//this.up('window').down('form').getForm().findField("endDate").setValue(enddateCov);
			        	        	        			}
			        	        	        			else
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("co_ValueType").enable();
			        	        	        				this.up('window').down('form').getForm().findField("startDatecov").reset();
			        	        	        				this.up('window').down('form').getForm().findField("endDatecov").reset();
			        	        	        				this.up('window').down('form').getForm().findField("startDatecov").allowBlank=true;
			        	        	        				this.up('window').down('form').getForm().findField("endDatecov").allowBlank=true;
			        	        	        			}
			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },

			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	fieldLabel: 'Value Type',
			        	        	        	name:'co_ValueType',
			        	        	        	displayField:'valueTypeName',
			        	        	        	valueField:'valueTypeId',
			        	        	        	store: covValueTypeStore,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			if(combo.getValue()==5)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("startDatecov").allowBlank=false;
			        	        	        				this.up('window').down('form').getForm().findField("endDatecov").allowBlank=false;
			        	        	        			}
			        	        	        			if(combo.getValue()==1)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("value").enable();
			        	        	        				this.up('window').down('form').getForm().findField("ValueListName").disable();
			        	        	        			}
			        	        	        			if(combo.getValue()!=1)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("value").disable();
			        	        	        				ValueListNameStore.clearFilter();
			        	        	        				ValueListNameStore.filter("attrCatg",combo.getValue());
			        	        	        				ValueListNameStore.filter("attrType",entityType);
			        	        	        				this.up('window').down('form').getForm().findField("ValueListName").enable();
			        	        	        				this.up('window').down('form').getForm().findField("ValueListName").reset();
			        	        	        			}
			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	disabled : true,
			        	        	        	fieldLabel: 'Function',
			        	        	        	name:'co_vFunction',
			        	        	        	displayField:'functionName',
			        	        	        	valueField:'functioId',
			        	        	        	store: covFunctionStore,
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'textfield',
			        	        	        	editable: false,
			        	        	        	disabled : true,
			        	        	        	fieldLabel: 'Value*',
			        	        	        	name:'value',
			        	        	        	allowBlank: false,
			        	        	        	enforceMaxLength  : true,
			        	        	        	// maskRe:/[A-Za-z0-9_, ]/,
			        	        	        	maxLength:100,
			        	        	        	listeners:{
			        	        	        		'change': function(field, newValue, oldValue){
			        	        	        			field.setValue(newValue.toUpperCase());
			        	        	        		}
			        	        	        	} 
			        	        	        },

			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	allowBlank: false,
			        	        	        	disabled : true,
			        	        	        	fieldLabel: 'Value*',
			        	        	        	name:'ValueListName',
			        	        	        	displayField:'entityAttributeName',
			        	        	        	valueField:'entityAttributeName',
			        	        	        	store: ValueListNameStore,
			        	        	        	triggerAction:'all'
			        	        	        },



			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'Start Date*',
			        	        	        	name: 'startDate',
			        	        	        	itemId: 'startDatecov',
			        	        	        	editable: false,
			        	        	        	// allowBlank:false,
			        	        	        	vtype: 'daterange',
			        	        	        	endDateField: 'endDatecov',
			        	        	        	id:'startDatecov'
			        	        	        		// value : new Date(date.getFullYear(), date.getMonth(), 1)
			        	        	        },

			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'End Date*',
			        	        	        	name: 'endDate',
			        	        	        	itemId: 'endDatecov',
			        	        	        	vtype: 'daterange',
			        	        	        	startDateField: 'startDatecov',
			        	        	        	//   allowBlank:false,
			        	        	        	editable: false,
			        	        	        	id:'endDatecov'
			        	        	        	//   value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
			        	        	        }





			        	        	        ]
			        	        },



			        	        {
			        	        	xtype: 'container',
			        	        	columnWidth:.2,
			        	        	layout: 'anchor',
			        	        	items: [
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	fieldLabel: 'LOPR',
			        	        	        	name:'Lopr',
			        	        	        	id:'Lopr',
			        	        	        	displayField:'oprName',
			        	        	        	valueField:'oprId',
			        	        	        	store: CreateLoprStore(),//oprStore,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			if(combo.getValue()==0){
			        	        	        				Ext.getCmp('rOpr').setValue(RoprStore.findRecord('oprId',26));
			        	        	        				this.up('window').down('form').getForm().findField("lEntityType").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lAttrType").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lOpr").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lFunction").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lAttName").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lValueType").reset();
			        	        	        				this.up('window').down('form').getForm().findField("LvalueListName").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lVfunction").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").reset();
			        	        	        				//this.up('window').down('form').getForm().findField("rOpr").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lValue").reset();

			        	        	        				this.up('window').down('form').getForm().findField("lEntityType").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lAttrType").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lOpr").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lFunction").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lAttName").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lValueType").disable();
			        	        	        				this.up('window').down('form').getForm().findField("LvalueListName").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lVfunction").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").disable();
			        	        	        				//  this.up('window').down('form').getForm().findField("rOpr").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lValue").disable();
			        	        	        				// this.up('window').down('form').getForm().findField("rOpr").readOnly = true;
			        	        	        				this.up('window').down('form').getForm().findField("lAttrType").allowBlank=true;
			        	        	        				this.up('window').down('form').getForm().findField("lEntityType").allowBlank=true;
			        	        	        				this.up('window').down('form').getForm().findField("lValueType").allowBlank=true;
			        	        	        				this.up('window').down('form').getForm().findField("lOpr").allowBlank=true;
			        	        	        				this.up('window').down('form').getForm().findField("lAttName").allowBlank=true;
			        	        	        			}else
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("lEntityType").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lAttrType").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lOpr").enable();
			        	        	        				//this.up('window').down('form').getForm().findField("lFunction").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lAttName").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lValueType").enable();
			        	        	        				this.up('window').down('form').getForm().findField("LvalueListName").enable();
			        	        	        				//this.up('window').down('form').getForm().findField("lVfunction").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").enable();
			        	        	        				this.up('window').down('form').getForm().findField("rOpr").enable();
			        	        	        				Ext.getCmp('rOpr').setValue(RoprStore.findRecord('oprId',26));
			        	        	        				// this.up('window').down('form').getForm().findField("rOpr").readOnly = false;
			        	        	        				this.up('window').down('form').getForm().findField("lValue").enable();
			        	        	        				//Ext.getCmp('lEntityType').setValue(entityStoreCovRight.findRecord('entityId',entityStoreCovRight.data.items[0].data.entityId));
                                                            
			        	        	        				Ext.getCmp('lEntityType').setValue(entityStore.findRecord('entityId',entityType,0, false, true, true));
			        	        	        			//	Ext.getCmp('lAttName').setValue(entityAttrStore.findRecord('entityAttributeId',entityAttrVar,0, false, true, true));
			        	        	        				//Ext.getCmp('lAttrType').setValue(attributeTypeStore.findRecord('attributeTypeId',entityTypeVar,0, false, true, true));
			        	        	        				if(Ext.getCmp("lValueType").getValue()==1)
                                                            	Ext.getCmp("LvalueListName").disable();
                                                            else
                                                            	Ext.getCmp("LvalueListName").enable();
 
			        	        	        			}

			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        }
			        	        	        ]
			        	        },

			        	        {
			        	        	xtype: 'container',
			        	        	columnWidth:.3,
			        	        	layout: 'anchor',
			        	        	id:'lfieldlist',
			        	        	items: [

			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	fieldLabel: 'Entity',
			        	        	        	name:'lEntityType',
			        	        	        	disabled: true,
			        	        	        	id:'lEntityType',
			        	        	        	displayField:'entityName',
			        	        	        	valueField:'entityId',
			        	        	        	store: entityStoreCovRight,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			this.up('window').down('form').getForm().findField("lAttrType").allowBlank=false;
			        	        	        			this.up('window').down('form').getForm().findField("lAttName").allowBlank=false;
			        	        	        			this.up('window').down('form').getForm().findField("lOpr").allowBlank=false;
			        	        	        			this.up('window').down('form').getForm().findField("lValueType").allowBlank=false;
			        	        	        			entityType = combo.getValue();
			        	        	        			// entityAttrStore.clearFilter();
			        	        	        			// 	entityAttrStore.filter("attrCatg",combo.getValue());
			        	        	        			this.up('window').down('form').getForm().findField("lAttName").reset();
			        	        	        			this.up('window').down('form').getForm().findField("lAttrType").reset();
			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	disabled: true,
			        	        	        	fieldLabel: 'Attribute Type',
			        	        	        	name:'lAttrType',
			        	        	        	displayField:'attributeTypeName',
			        	        	        	valueField:'attributeTypeId',
			        	        	        	store: attributeTypeStoreCovRight,
			        	        	        	id:'lAttrType',
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			LentityAttrStore.clearFilter();

			        	        	        			LentityAttrStore.filter(function(r) {
			        	        	        				var value = r.get('attrCatg');
			        	        	        				var value2 = r.get('attrType');
			        	        	        				return (value == combo.getValue() && value2 == entityType);
			        	        	        			});


			        	        	        			this.up('window').down('form').getForm().findField("lAttName").reset();
			        	        	        			if(combo.getValue()==8)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").enable();
			        	        	        				//this.up('window').down('form').getForm().findField("lStartDate").setValue(stdateCov);
			        	        	        				//this.up('window').down('form').getForm().findField("lEndDate").setValue(enddateCov);

			        	        	        				//this.up('window').down('form').getForm().findField("lStartDate").enable();
			        	        	        				// this.up('window').down('form').getForm().findField("lFunction").enable();
			        	        	        				//lVfunction setValue
			        	        	        				//this.up('window').down('form').getForm().findField("lVfunction").enable();

			        	        	        			}
			        	        	        			else
			        	        	        			{
			        	        	        			//	this.up('window').down('form').getForm().findField("lStartDatecov").disable();
			        	        	        			//	this.up('window').down('form').getForm().findField("lEndDatecov").disable();

			        	        	        				this.up('window').down('form').getForm().findField("lFunction").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lVfunction").disable();

			        	        	        			}

			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	allowBlank: false,

			        	        	        	disabled : true,
			        	        	        	fieldLabel: 'Function',
			        	        	        	name:'lFunction',
			        	        	        	displayField:'functionName',
			        	        	        	valueField:'functioId',
			        	        	        	store: covFunctionStore,
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	disabled: true,
			        	        	        	fieldLabel: 'Entity Attribute',
			        	        	        	name:'lAttName',
			        	        	        	displayField:'entityAttributeName',
			        	        	        	valueField:'entityAttributeId',
			        	        	        	store: LentityAttrStore,
			        	        	        	id:'lAttName',
			        	        	        	/*queryMode: 'local',
													forceSelection: true,
													triggerAction: 'all',
													enableKeyEvents: true,
													selectOnFocus:true,
													typeAhead: true,
													disableKeyFilter: true,	*/
			        	        	        	//emptyText:'Select a entity  attribute...',
			        	        	        	//forceSelection: true,
			        	        	        	//triggerAction: 'all',
			        	        	        	//queryMode: 'local',
			        	        	        	//enableKeyEvents: true,
			        	        	        	//triggerAction: 'all',
			        	        	        	//selectOnFocus:true,
			        	        	        	//typeAhead: true,
			        	        	        	//disableKeyFilter: true,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){

			        	        	        			LentityAttrStore.findBy(function(record,id) {
			        	        	        				if(record.get('entityAttributeId')==combo.getValue()) {
			        	        	        					covlFreeTextType = record.data.freeTextType;
			        	        	        				}
			        	        	        			});

			        	        	        			oprFilterCov2 =   LentityAttrStore.findRecord('entityAttributeId',combo.getValue(),0, false, true, true);


			        	        	        			oprFilterCov2 = oprFilterCov2.data.operatorFlag;

			        	        	        			oprStoreCovRight.clearFilter();

			        	        	        			if(oprFilterCov2=='D')
			        	        	        			{
			        	        	        				oprStoreCovRight.filter('dateFlag','Y');
			        	        	        			}
			        	        	        			if(oprFilterCov2=='N')
			        	        	        			{
			        	        	        				oprStoreCovRight.filter('numberFlag','Y');
			        	        	        			}
			        	        	        			if(oprFilterCov2=='S')
			        	        	        			{
			        	        	        				oprStoreCovRight.filter('stringFlag','Y');
			        	        	        			}

			        	        	        			this.up('window').down('form').getForm().findField("lOpr").reset();

			        	        	        		},
			        	        	        		/*afterrender: function (me) { 
			        	        	        			alert("testing AttrType::: "+Ext.getCmp("lAttrType").getValue());
			        	        	                    me.getEl().on('click', function() {
			        	        	                    	LentityAttrStore.clearFilter();
			        	        	                    	LentityAttrStore.filter('attrType',Ext.getCmp("lAttrType").getValue(),0, false, true, true);
			        	        	                    });
			        	        	        		},*/
			        	        	        		
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },

			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	disabled: true,
			        	        	        	fieldLabel: 'OPR',
			        	        	        	name:'lOpr',
			        	        	        	displayField:'oprName',
			        	        	        	valueField:'oprId',
			        	        	        	store: oprStoreCovRight,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){

			        	        	        			this.up('window').down('form').getForm().findField("lValueType").reset();
			        	        	        			this.up('window').down('form').getForm().findField("lValue").reset();
			        	        	        			this.up('window').down('form').getForm().findField("lValue").disable();
			        	        	        			this.up('window').down('form').getForm().findField("LvalueListName").reset();
			        	        	        			this.up('window').down('form').getForm().findField("LvalueListName").disable();

			        	        	        			if(combo.getValue()==14)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("lValueType").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lValue").disable();
			        	        	        				this.up('window').down('form').getForm().findField("LvalueListName").disable();
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").allowBlank=false;
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").allowBlank=false;
			        	        	        			}
			        	        	        			else
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").reset();
			        	        	        				this.up('window').down('form').getForm().findField("lValueType").enable();
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").allowBlank=true;
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").allowBlank=true;

			        	        	        			}
			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },

			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	disabled: true,
			        	        	        	fieldLabel: 'Value Type',
			        	        	        	name:'lValueType',
			        	        	        	displayField:'valueTypeName',
			        	        	        	valueField:'valueTypeId',
			        	        	        	store: covValueTypeStore,
			        	        	        	id:'lValueType',
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){
			        	        	        			if(combo.getValue()==5)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("lStartDatecov").allowBlank=false;
			        	        	        				this.up('window').down('form').getForm().findField("lEndDatecov").allowBlank=false;

			        	        	        			}

			        	        	        			if(combo.getValue()==1)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("lValue").enable();
			        	        	        				this.up('window').down('form').getForm().findField("LvalueListName").disable();

			        	        	        			}

			        	        	        			if(combo.getValue()!=1)
			        	        	        			{
			        	        	        				this.up('window').down('form').getForm().findField("lValue").disable();
			        	        	        				this.up('window').down('form').getForm().findField("LvalueListName").enable();
			        	        	        				LvalueListNameStore.clearFilter();

			        	        	        				LvalueListNameStore.filter("attrCatg",combo.getValue());
			        	        	        				LvalueListNameStore.filter("attrType",entityType);


			        	        	        				this.up('window').down('form').getForm().findField("LvalueListName").reset();

			        	        	        			}

			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },

			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	disabled: true,
			        	        	        	fieldLabel: 'Function',
			        	        	        	name:'lVfunction',
			        	        	        	displayField:'functionName',
			        	        	        	valueField:'functioId',
			        	        	        	store: covFunctionStore,
			        	        	        	triggerAction:'all'
			        	        	        },

			        	        	        {
			        	        	        	xtype :'textfield',
			        	        	        	editable: false,
			        	        	        	allowBlank : false,
			        	        	        	disabled : true,
			        	        	        	fieldLabel: 'Value',
			        	        	        	name:'lValue',
			        	        	        	enforceMaxLength  : true,
			        	        	        	maxLength:100,
			        	        	        	//maskRe:/[A-Za-z0-9_, ]/,
			        	        	        	listeners:{
			        	        	        		'change': function(field, newValue, oldValue){
			        	        	        			field.setValue(newValue.toUpperCase());
			        	        	        		}
			        	        	        	}
			        	        	        },

			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	fieldLabel: 'Value',
			        	        	        	disabled : true,
			        	        	        	allowBlank : false,
			        	        	        	name:'LvalueListName',
			        	        	        	displayField:'entityAttributeName',
			        	        	        	valueField:'entityAttributeName',
			        	        	        	store: LvalueListNameStore,
			        	        	        	triggerAction:'all',
			        	        	        	id:'LvalueListName'
			        	        	        /*	queryMode: 'local',
													forceSelection: true,
													triggerAction: 'all',
													enableKeyEvents: true,
													selectOnFocus:true,
													typeAhead: true,
													disableKeyFilter: true */
			        	        	        },




			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'Start Date*',
			        	        	        	name: 'lStartDate',
			        	        	        	itemId: 'lStartDatecov',
			        	        	        	editable: false,
			        	        	        	// allowBlank:false,
			        	        	        	vtype: 'daterange',
			        	        	        	//endDateField: 'lEndDatecov',
			        	        	        	id:'lStartDatecov',
			        	        	        	listeners: {
			    									'select': function(datefield,value){

			    										if((this.up('window').down('form').getForm().findField("lEndDate").getValue()!=null) && 
			    												(this.up('window').down('form').getForm().findField("lStartDate").getValue()>this.up('window').down('form').getForm().findField("lEndDate").getValue()))
			    										{
			    											Ext.Msg.alert('info','Start date should not be greater than End date');
			    											this.up('window').down('form').getForm().findField("lStartDate").setValue();
			    										}
			    									}
			    								}
			        	        	        		// value : new Date(date.getFullYear(), date.getMonth(), 1)
			        	        	        },

			        	        	        {
			        	        	        	xtype :'datefield',
			        	        	        	fieldLabel: 'End Date*',
			        	        	        	name: 'lEndDate',
			        	        	        	itemId: 'lEndDatecov',
			        	        	        	vtype: 'daterange',
			        	        	        	//startDateField: 'lStartDatecov',
			        	        	        	//   allowBlank:false,
			        	        	        	editable: false,
			        	        	        	id:'lEndDatecov',
			        	        	        	listeners: {
													'select': function(datefield,value){
														if((this.up('window').down('form').getForm().findField("lStartDate").getValue()!=null) && 
																(this.up('window').down('form').getForm().findField("lEndDate").getValue()<this.up('window').down('form').getForm().findField("lStartDate").getValue()))
														{
															Ext.Msg.alert('info','End date should not be less than Start date');
															this.up('window').down('form').getForm().findField("lEndDate").setValue();
														}
													}
												}
			        	        	        	//   value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
			        	        	        },



			        	        	        {
			        	        	        	xtype :'combo',
			        	        	        	editable: false,
			        	        	        	allowBlank: false,
			        	        	        	fieldLabel: 'ROPR',
			        	        	        	name:'rOpr',
			        	        	        	id:'rOpr',
			        	        	        	displayField:'oprName',
			        	        	        	valueField:'oprId',
			        	        	        	store: RoprStore,
			        	        	        	listeners: {
			        	        	        		'select': function(combo, value){

			        	        	        			if((combo.getValue()==1)||(combo.getValue()==2))
			        	        	        			{

			        	        	        				//updateFlagCov = 'Yes';

			        	        	        			}

			        	        	        		}
			        	        	        	},
			        	        	        	triggerAction:'all'
			        	        	        },
			        	        	        {
        				        		    	   xtype :'textfield',
        				        		    	   fieldLabel: 'CsrfName',
												   hidden:true,
        				        		    	   disabled : true,
        				        		    	   name: 'csrfCov',
												   maxLength : 100,
        				        		    	   allowBlank:false,
        				        		    	   id:'testCsrfCov'
        				        		    }

			        	        	        ]
			        	        }]
			         } 
			         ]
		}],
		buttons: [	
		          {
		        	  text: 'Save',
		        	  action: 'add'

		          },

		          /*       	{
                		text    : 'Reset',
                		handler : function () { 
                		this.up('window').down('form').getForm().reset(); 
                	}
                	},
		           */       	{
		        	  text   : 'Cancel',
		        	  handler: function () { 
		        		  this.up('window').close();
		        	  }
		          }]
	});

	Ext.define('Scheme.controller.CovCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['CovList', 'CovForm'],
		refs    : [{
			ref   : 'formWindow',
			xtype : 'CovForm',
			selector: 'CovForm',
			autoCreate: true
		}],
		init: function () {
			this.control({
				'CovList > toolbar > button[action=add]': {
					click: this.showCovForm
				},
				'CovList': {
					itemdblclick: this.onRowdblclick
				},
				'CovForm button[action=add]': {
					click: this.doAddCov
				}
			});
		},
		onRowdblclick: function(me, record, item, index) {

			var win = this.getFormWindow();
			win.down('form').getForm().reset();
			updateFlagCov = 'Yes';
			win.down('form').getForm().applyToFields({disabled:true});
			covCompId = record.data.compId;
			covCondId = record.data.condId;
			condRowIdCov = record.data.condRowId;

			//componenet Load
			componentListStore.load({
				callback: function(records, operation, success) {
					if (success == true) {

						if(record.data.attrTypeName!=null)
						{
							win.down('form').getForm().findField('compId').enable();
							win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compId',record.data.compId));
							win.down('form').getForm().findField('compId').readOnly = true;

						}

						//Entity Load

						entityStore.load({
							callback: function(records, operation, success) {
								if (success == true) {

									if(record.data.entityName!=null)
									{
										entityType = entityStore.findRecord('entityName',record.data.entityName);
										entityType = entityType.data.entityId;
										win.down('form').getForm().findField('entityId').enable();
										win.down('form').getForm().findField('entityId').setValue(entityStore.findRecord('entityName',record.data.entityName));
									}

									//Attribute Load

									attributeTypeStore.load({
										callback: function(records, operation, success) {
											if (success == true) {

												if(record.data.attrTypeName!=null)
												{
													win.down('form').getForm().findField('attrType').enable();
													win.down('form').getForm().findField('attrType').setValue(attributeTypeStore.findRecord('attributeTypeName',record.data.attrTypeName));



												}

												//First Function Load

												covFunctionStore.load({
													callback: function(records, operation, success) {
														if (success == true) {

															if(record.data.functionName!=null)
															{
																win.down('form').getForm().findField('function').enable();
																win.down('form').getForm().findField('function').setValue(covFunctionStore.findRecord('functionName',record.data.functionName));
															}


															//AttributeTitle Load
															entityAttrStore.load({
																callback: function(records, operation, success) {
																	if (success == true) {

																		if(record.data.attrMappingName!=null)
																		{
																			win.down('form').getForm().findField('attrName').enable();
																			win.down('form').getForm().findField('attrName').setValue(entityAttrStore.findRecord('entityAttributeName',record.data.attrMappingName));
																			entityAttrStore.clearFilter();

																			var attrId =  attributeTypeStore.findRecord('attributeTypeName',record.data.attrTypeName);

																			entityAttrStore.filter(function(r) {
																				var value = r.get('attrCatg');
																				var value2 = r.get('attrType');
																				return (value == attrId.data.attributeTypeId && value2 == entityType);
																			});



																			oprFilterCov3 =   entityAttrStore.findRecord('entityAttributeName',record.data.attrMappingName);


																		}


																		// Operator Load

																		oprStore.load({
																			callback: function(records, operation, success) {
																				if (success == true) {
																					
																					oprStore.clearFilter();
																					
																					if(record.data.oprName!=null)
																					{
																						win.down('form').getForm().findField('opr').enable();
																						win.down('form').getForm().findField('opr').setValue(oprStore.findRecord('oprName',record.data.oprName));

																						oprFilterCov3 =   entityAttrStore.findRecord('entityAttributeName',record.data.attrMappingName);



																						oprFilterCov3 = oprFilterCov3.data.operatorFlag;

																						//oprStore.clearFilter();

																						if(oprFilterCov3=='D')
																						{
																							oprStore.filter('dateFlag','Y');
																						}
																						if(oprFilterCov3=='N')
																						{

																							oprStore.filter('numberFlag','Y');
																						}
																						if(oprFilterCov3=='S')
																						{

																							oprStore.filter('stringFlag','Y');
																						}


																					}

																					covFunctionStore.load({
																						callback: function(records, operation, success) {
																							if (success == true) {

																								if(record.data.co_functionName!=null)
																								{
																									win.down('form').getForm().findField('co_vFunction').enable();
																									win.down('form').getForm().findField('co_vFunction').setValue(covFunctionStore.findRecord('functionName',record.data.co_functionName));
																								}
																							}
																						}
																					});

																				}
																			}
																		});








																	}
																}
															});







														}
													}
												});





											}
										}
									});



								}
							}
						});






					}
				}
			}); //Component Load Close








			covValueTypeStore.load({
				callback: function(records, operation, success) {
					if (success == true) {

						if(record.data.co_ValueTypeName!=null)
						{
							win.down('form').getForm().findField('co_ValueType').enable();
							win.down('form').getForm().findField('co_ValueType').setValue(covValueTypeStore.findRecord('valueTypeName',record.data.co_ValueTypeName));


							if(record.data.co_ValueTypeName=='Free Text')
							{

								win.down('form').getForm().findField("ValueListName").disable();
								win.down('form').getForm().findField("value").enable();
								win.down('form').getForm().findField("value").setValue(record.data.value);
							}
							else
							{
								win.down('form').getForm().findField("value").disable();
								win.down('form').getForm().findField("ValueListName").enable();
								//ValueListNameStore	

								ValueListNameStore.load({
									callback: function(records, operation, success) {
										if (success == true) {

											if(record.data.value!=null)
											{
												win.down('form').getForm().findField('ValueListName').enable();
												win.down('form').getForm().findField('ValueListName').setValue(ValueListNameStore.findRecord('entityAttributeName',record.data.value));
											}
										}
									}
								});




							}



						}
					}
				}
			});

			win.down('form').getForm().findField('startDatecov').enable();
			win.down('form').getForm().findField('endDatecov').enable();
			win.down('form').getForm().findField('lStartDatecov').enable();
			win.down('form').getForm().findField('lEndDatecov').enable();

			/*

						if(record.data.startDate!=null){
							win.down('form').getForm().findField('startDatecov').enable();
						}/*else{
							win.down('form').getForm().findField('startDatecov').disable();
						}*/
						
						if(record.data.endDate!=null){
							win.down('form').getForm().findField('endDatecov').enable();
						}/*else{
							win.down('form').getForm().findField('endDatecov').disable();
						}*/
						
						if(record.data.lStartDate!=null){
							win.down('form').getForm().findField('lStartDatecov').enable();
						}/*else{
							win.down('form').getForm().findField('lStartDatecov').disable();
						}*/
						
						if(record.data.lEndDate!=null){
							win.down('form').getForm().findField('lEndDatecov').enable();
						}/*else{
							win.down('form').getForm().findField('lEndDatecov').disable();
						}
			*/
			if(record.data.loprName!=null)
			{
				win.down('form').getForm().findField('Lopr').enable();
				win.down('form').getForm().findField('Lopr').setValue(CreateLoprStore().findRecord('oprName',record.data.loprName));

			} 
			else
			{

				win.down('form').getForm().findField('Lopr').enable();
				win.down('form').getForm().findField('Lopr').setValue(CreateLoprStore().findRecord('oprName','_BLANK'));

			}

var entityTypeRIdTest = null;

			entityStoreCovRight.load({
				callback: function(records, operation, success) {
					if (success == true) {

						var entityTypeR = null;
						if(record.data.lentityTypeName!=null)
						{

							//alert("Test lenety ====>> "+record.data.lentityTypeName);
							entityTypeR = entityStoreCovRight.findRecord('entityName',record.data.lentityTypeName);
							entityTypeRIdTest = entityTypeR.data.entityId;
							//alert("Test lenety ====>> "+entityTypeRIdTest);
							entityTypeR = entityTypeR.data.lentityTypeName;
							//entityTypeRIdTest = entityTypeR;entityId
							
							win.down('form').getForm().findField('lEntityType').enable();
							win.down('form').getForm().findField('lEntityType').setValue(entityStoreCovRight.findRecord('entityName',record.data.lentityTypeName));
						}




						attributeTypeStoreCovRight.load({
							callback: function(records, operation, success) {
								if (success == true) {

									if(record.data.lattrTypeName!=null)
									{
										win.down('form').getForm().findField('lAttrType').enable();
										win.down('form').getForm().findField('lAttrType').setValue(attributeTypeStoreCovRight.findRecord('attributeTypeName',record.data.lattrTypeName));
									}


									LentityAttrStore.load({
										callback: function(records, operation, success) {
											if (success == true) {
												//var oprFilterCovR = null;
												if(record.data.lattNameString!=null)
												{

													oprFilterCovR =   LentityAttrStore.findRecord('entityAttributeName',record.data.lattNameString);
													win.down('form').getForm().findField('lAttName').enable();
													win.down('form').getForm().findField('lAttName').setValue(LentityAttrStore.findRecord('entityAttributeName',record.data.lattNameString));


													LentityAttrStore.clearFilter();

													var attrIdR =  attributeTypeStoreCovRight.findRecord('attributeTypeName',record.data.lattrTypeName);
													//alert("testing ====>> "+attrIdR.data.attributeTypeId+" entity ====>> "+entityTypeRIdTest);
														LentityAttrStore.filter(function(r) {
																var value = r.get('attrCatg');
																var value2 = r.get('attrType');
																return (value == attrIdR.data.attributeTypeId && value2 == entityTypeRIdTest);
															});
													 


													//	oprFilterCovR =   LentityAttrStore.findRecord('entityAttributeName',record.data.lattNameString);




												}


												oprStoreCovRight.load({
													callback: function(records, operation, success) {
														if (success == true) {

															if(record.data.lloprName!=null)
															{
																win.down('form').getForm().findField('lOpr').enable();
																win.down('form').getForm().findField('lOpr').setValue(oprStoreCovRight.findRecord('oprName',record.data.lloprName));

																var oprFilterCovR =   LentityAttrStore.findRecord('entityAttributeName',record.data.lattNameString);

																oprFilterCovR = oprFilterCovR.data.operatorFlag;

																oprStoreCovRight.clearFilter();

																if(oprFilterCovR=='D')
																{
																	oprStoreCovRight.filter('dateFlag','Y');
																}
																if(oprFilterCovR=='N')
																{

																	oprStoreCovRight.filter('numberFlag','Y');
																}
																if(oprFilterCovR=='S')
																{

																	oprStoreCovRight.filter('stringFlag','Y');
																}




															}
														}
													}
												});



											}
										}
									});










								}
							}
						});






					}
				}
			});




			covFunctionStore.load({
				callback: function(records, operation, success) {
					if (success == true) {

						if(record.data.lfunctionName!=null)
						{
							win.down('form').getForm().findField('lFunction').enable();
							win.down('form').getForm().findField('lFunction').setValue(covFunctionStore.findRecord('functionName',record.data.lfunctionName));
						}
					}
				}
			});







			covValueTypeStore.load({
				callback: function(records, operation, success) {
					if (success == true) {

						if(record.data.lvalueTypeName!=null)
						{
							win.down('form').getForm().findField('lValueType').enable();
							win.down('form').getForm().findField('lValueType').setValue(covValueTypeStore.findRecord('valueTypeName',record.data.lvalueTypeName));
							if(record.data.lvalueTypeName=='Free Text')
							{

								win.down('form').getForm().findField("LvalueListName").disable();
								win.down('form').getForm().findField("lValue").enable();
								win.down('form').getForm().findField("lValue").setValue(record.data.lvalueName);

							}
							else
							{
								win.down('form').getForm().findField("lValue").disable();
								win.down('form').getForm().findField("LvalueListName").enable();
								win.down('form').getForm().findField("LvalueListName").reset();

								ValueListNameStore.load({
									callback: function(records, operation, success) {
										if (success == true) {

											if(record.data.lvalueName!=null)
											{
												win.down('form').getForm().findField('LvalueListName').enable();
												win.down('form').getForm().findField('LvalueListName').setValue(ValueListNameStore.findRecord('entityAttributeName',record.data.lvalueName));
											}
										}
									}
								});


							}




						}
					}
				}
			});





			covFunctionStore.load({
				callback: function(records, operation, success) {
					if (success == true) {

						if(record.data.lvfunctionName!=null)
						{
							win.down('form').getForm().findField('lVfunction').enable();
							win.down('form').getForm().findField('lVfunction').setValue(ValueListNameStore.findRecord('functionName',record.data.lvfunctionName));
						}
					}
				}
			});


			RoprStore.load({
				callback: function(records, operation, success) {
					if (success == true) {
						win.down('form').getForm().findField('rOpr').enable();

						if(record.data.roprName!=null)
						{
							win.down('form').getForm().findField('rOpr').setValue(RoprStore.findRecord('oprName',record.data.roprName));
							RoprStore.clearFilter();
							RoprStore.filter("coFlag",'Y');


						}
					}
				}
			});



			win.setTitle('Edit Coverage');
			win.setAction('edit');
			win.setRecordIndex(record.data.schemeINputId);





			win.down('form').getForm().setValues(record.getData());





			win.show();

			//win.down('form').getForm().findField('compId').setValue(componentListStore.findRecord('compName',record.data.compName));


			Ext.getCmp('compId').readOnly = false; 
			//win.down('form').getForm().reset();	 
			if(!detailcondcov)
			{

				var bd = Ext.getCmp('covDetailPanel').body;
				bd.update('').setStyle('background','#fff');
				detailcondcov = bd.createChild();
			}
			//coverageStore.load();





			componentStoreGrid.load({
				callback: function(records, operation, success)
				{
					if(success==true)
					{
						var compName = componentStoreGrid.findRecord('compId',record.data.compId);
						condBody  = '<p><b>Comp Name: '+compName.data.compName+'</b></p>';
						//stdateTest = compName.data.startDate;
						//alert("Test ::::: "+stdateTest);
						updateCovCondPanel(record.data.compId);
					}
				}
			});



		},
		showCovForm: function () {
			RoprStore.clearFilter();
			RoprStore.filter("coFlag",'Y');

			if(compName!=null)
			{
				var win = this.getFormWindow();
				win.setTitle(SchemeName);
				win.setAction('add');
				win.down('form').getForm().reset();
				win.show();
				win.down('form').getForm().findField('compId').readOnly = false;
				win.down('form').getForm().findField('entityId').readOnly = false;
				//LvalueListName
				win.down('form').getForm().findField('LvalueListName').disable();
				var compNotClosed = coverageStore.findRecord('roprName','Close Condition');
				//componentListStore.filter('',compNotClosed.data.)
				// Ext.getCmp('compId').setValue(componentListStore.findRecord('compId',componentListStore.data.items[0].data.compId));
				//	Ext.getCmp('compId').readOnly = false;
				//Cond Detail

				if(!detailcondcov)
				{

					var bd = Ext.getCmp('covDetailPanel').body;
					bd.update('').setStyle('background','#fff');
					detailcondcov = bd.createChild();
				}	 

				entityStore.load();

				//Ext.getCmp('entityId').setValue(entityStore.findRecord('entityId',entityStore.data.items[0].data.entityId));

				entityType = 10;
				var lopr = CreateLoprStore();
				Ext.getCmp('Lopr').setValue(lopr.findRecord('oprId',0));
				Ext.getCmp('rOpr').setValue(RoprStore.findRecord('oprId',26));		
			}
			else{
				Ext.Msg.alert('Info', "Please create componenet for scheme first");	
			}

		},
		doAddCov: function () {
			var win = this.getFormWindow();
			var action = win.getAction();
			var validity=true;
			Ext.getCmp("testCsrfCov").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
			if(oprFilterCov1=='D')
				{
				   if(Ext.getCmp("startDatecov").getValue()==null || Ext.getCmp("endDatecov").getValue()==null)
					   {
				     Ext.Msg.alert('Info',"Please provide Start Date(L) and End Date(L)");
				     validity=false;
					   }
				}
			if(oprFilterCov2=='D')  
			{
			   if(Ext.getCmp("lStartDatecov").getValue()==null || Ext.getCmp("lEndDatecov").getValue()==null)
				   {
			     Ext.Msg.alert('Info',"Please provide Start Date(R) and End Date(R)");
			     validity=false;
				   }
			}
			if(validity)
				{
			if(action == 'edit') {
				if(win.down('form').isValid())
				{

					if(updateFlagCov=='Yes')
						updateCoverage(win);
					else
					{

						updateFlagCov = 'Yes';
						saveCoverage(win);

					}			

				}
				else
				{
					Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
				}  
			}
			else {
				if(win.down('form').isValid())
				{
					saveCoverage(win);

				}
				else
				{
					Ext.Msg.alert('Info', "Please Fill All Mandatory Fields");
				}

			}
				}
		}
	});



});
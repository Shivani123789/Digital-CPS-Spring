Ext.require([
    'Ext.panel.*',
    'Ext.toolbar.*',
    'Ext.button.*',
    'Ext.container.ButtonGroup',
    'Ext.layout.container.Table',
    'Ext.tip.QuickTipManager'
]);

function saveBulkFile(bulkForm)
{
	bulkForm.submit({
		
		 waitMsg : 'Loading...',
		 url: bulkUploadUrl,
		 enctype : 'multipart/form-data',
		 headers: {'Content-Type':'multipart/form-data;'},
		 method : 'POST',
        
		 success: function(form, action) {
            //Ext.Msg.alert('Bulk File Sucessfully');
            Ext.Msg.alert('Info', action.result.errorMessage);
            //form.reset();
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        }
    });	
}

Ext.onReady(function() {

/*	Ext.Ajax.on('requestexception', function(conn, response, options, e) {
  location.reload(); 
});
*/

	var searchGrid = 0;
	var viewschemeGrid = 0;
	var submitchemeGrid = 0;
	var reportGrid = 0;
	var payoutApprovalGrid = 0;
	var executeSchemeGrid = 0;
	var sentToVtopGrid = 0;
	var stmGenGrid = 0;
	
	
   
	
	var bulkPanel = Ext.create('Ext.form.Panel', {
		waitMsg : 'Loading...',
		enctype : 'multipart/form-data', 
		headers: {'Content-Type':'multipart/form-data;'},
		title : 'Bulk Upload File',
		border: false,
		bodyStyle:'padding:3px 0px',
	//	width:1120,
		items:[

		       {
		    	   xtype:'fieldset',
		    	   title: 'Bulk Upload File',
		    	   collapsible: true,
		    	   layout: 'anchor',
		    	//   width:230,
				   width:1120,
    //height:570,
	
		    	   defaults: {
		    		   //anchor: '100%',
		    		   width:200

		    	   },
		    	   items :[{
		    		   xtype: 'fileuploadfield',
		    		   name: 'fileUpload',
		    		   emptyText: 'Select a document to upload...',
		    		   fieldLabel: 'File',
		    		   buttonText: 'Browse File'
		    	   },
		    	   {
		    		   xtype :'combo',
		    		   fieldLabel: 'File Type*',
		    		   name:'fileTypeId',
		    		   displayField:'fileName',
		    		   valueField:'fileTypeId',
		    		   forceSelection: true,
		    		   allowBlank: false,
		    		   editable: false,
		    		   store: bulkUploadFileStore(),
		    		   listeners: {
		    			   'select': function(combo, value){
		    				
		    				   if(combo.getValue()==4)
							  {
		    					   //bulkPanel.
		    					  // bulkPanel.findField("schemeId").enable();
								 //this.up('window').down('form').getForm().findField("schemeId").disable();
								 Ext.getCmp("schemeId").enable();
								 Ext.getCmp("componentId").enable();

						  }else{
							  //bulkPanel.findField("schemeId").disable();
								//  this.up('window').down('form').getForm().findField("schemeId").enable();
								  //win.down('form').getForm().findField("ValueListName").reset();
									
							  Ext.getCmp("schemeId").disable();
							  Ext.getCmp("componentId").disable();
							  }
		    				   
		    			   }
		    		   },
		    		   triggerAction:'all'
		    	   },
		    	   
		    	   {
						xtype :'combo',
						editable: false,
						allowBlank: false,
						fieldLabel: 'Scheme Name*',
						name:'schemeId',
						id : 'schemeId',
						disabled:true,
						displayField:'schemeName',
						valueField:'schemeId',
						store: bulkSchemeStore,
						listeners: {
							  'select': function(combo, value){
								  
								//  entityAttrStore.clearFilter();
								  bulkComponentStore.clearFilter();
								  bulkComponentStore.filter("schemeId",combo.getValue());
								  Ext.getCmp("componentId").reset();
								//	this.up('window').down('form').getForm().findField("attrName").reset();
								  
							  }
							 },
						
						triggerAction:'all'
					},
					{
						xtype :'combo',
						editable: false,
						allowBlank: false,
						fieldLabel: 'Component Name*',
						name:'componentId',
						id:'componentId',
						disabled:true,
						displayField:'componentName',
						valueField:'componentName',
						store: bulkComponentStore,
						triggerAction:'all'
					},
					
				//	buttons: [
				
				{
		    	   xtype:'fieldset',
		    	   //title: 'Bulk Upload File',
		    	   //collapsible: true,
		    	   layout: 'column',
				   border : false,
				   bodyStyle:'padding:3px 2px',
		    	  // width:200,
				//   width:1120,
    //height:570,
	
		    	   defaults: {
		    		   //anchor: '100%',
		    		//   width:200
					bodyStyle:'padding:3px 2px',

		    	   },
		    	   items :[
		    	
						{
			    	   xtype :'button',
					   text: 'Upload',
			    	   handler : function () { 
			    		   saveBulkFile(bulkPanel);
			    	   }
			       },
			       {
			    	   xtype :'button',
					   text    : 'Reset',
			    	   handler : function () { 
			    		   //this.up('window').down('form').getForm().reset(); 
			    	   }
			       }
				
				]}
				
						
			    //   ]
		    	   
		    	   ]
			       
		    	   
		       }]

		      

	});
	
	
	
	
	 formPanel = Ext.create('Ext.form.Panel', {
	 	url: addSchemeUrl,
	 	border: false,
	//	bodyStyle:'padding:3px 0px',
	 	id: 'my-panel',
	 
	 	
	   items:[
	          
	       {
           xtype:'tabpanel',
           id: 'tablist',
       		width:1120,
			height : 500,
           defaults:{
         //  	preventBodyReset: true
           	},
           items:[
               {
               title:'Scheme',
               items: [
                       	schemeForm
                       ]
               	
               },
               {
               title:'Component',
               id:'Component',
               
               items: [
                     compList
                      ]
               
           	
               },
           {
               title:'Region&Zone',
               items: [
                       regList
                      ]
           },

           {
               title:'Coverage',
               items: [
                  			covList
                       
                       ]
               
           	
           },
           {
               title:'TQ',
               items: [
                       tqList
                       ]
               
           	
           },
           {
               title:'EA',
               items: [
                       	 eaList
                       ]
           },
           
           {
               title:'EA_FILTER CONDITION',
               items: [
                       eaFilterList
                       ]
           },

           
           {
               title:'PO',
               items: [
                       poList
                       ]
               
           	
           }
           /*,
           {
               title:'PO_FILTER CONDITION',
               items: [
                       poFilterList
                       ]
               
          }*/
           ],
           listeners: {
               'tabchange': function (tabPanel, tab) {
                   
                   
                   if(tab.title=='Component')
                   	{
                   	componentStoreGrid.load();
                   	if(compGridStatus==0)
                   		{
                   		
                   Ext.application({
               	    name  : 'Scheme',
               	    controllers: ['CompCon'],
              	      launch: function () {
               	    	  Ext.widget('CompList', {
               	          renderTo: 'complist'
               	        });
               	      }
               	    }
               	  );
                   compGridStatus=1;
              }
                   
             }
                   
                   if(tab.title=='Region&Zone')
               	{
                   	regZoneStore.load();
               	if(regGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['RegCon'],
          	      launch: function () {
           	    	  Ext.widget('RegList', {
           	          renderTo: 'reglist'
           	        });
           	      }
           	    }
           	  );
               regGridStatus=1;
               }
               
               	}
                   
                   if(tab.title=='Coverage')
               	{
                	   //coverageStore.load();
               	if(covGridStatus==0)
               		{
              
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['CovCon'],
          	      launch: function () {
           	    	  Ext.widget('CovList', {
           	          renderTo: 'covlist'
           	        });
           	      }
           	    }
           	  );
               covGridStatus=1;
               }
			   coverageStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
                  if(coverageStore.getCount()>0)
			   {
			  
			   Ext.getCmp('addCoverage').disable();
			   }
			   
			   else
			   Ext.getCmp('addCoverage').enable();
               

				  } else {
            // the store didn't load, deal with it
        }
    }
    // scope: this,
});

}
                   
                   if(tab.title=='TQ')
               	{
                	   tqStore.load();
               	if(tqGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['TqCon'],
          	      launch: function () {
           	    	  Ext.widget('TqList', {
           	          renderTo: 'tqlist'
           	        });
           	      }
           	    }
           	  );
               tqGridStatus=1;
               }
               
               	}
                   
                   if(tab.title=='EA')
               	{
                	   eaStore.load();
               	if(eaGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['EaCon'],
          	      launch: function () {
           	    	  Ext.widget('EaList', {
           	          renderTo: 'ealist'
           	        });
           	      }
           	    }
           	  );
               eaGridStatus=1;
               }
               
               	}
                   
                   if(tab.title=='EA_FILTER CONDITION')
               	{
                	   eaFilterStore.load();
               	if(eaFilterGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['EaFilterCon'],
          	      launch: function () {
           	    	  Ext.widget('EaFilterList', {
           	          renderTo: 'eafilterlist'
           	        });
           	      }
           	    }
           	  );
               eaFilterGridStatus=1;
               }
               
               	}
                   
                   if(tab.title=='PO')
               	{
                	   poStore.load();
               	if(poGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['PoCon'],
          	      launch: function () {
           	    	  Ext.widget('PoList', {
           	          renderTo: 'polist'
           	        });
           	      }
           	    }
           	  );
               poGridStatus=1;
               }
               
               	}
                   
                   if(tab.title=='PO_FILTER CONDITION')
               	{
                	   poFilterStore.load();
               	if(poFilterGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['PoFilterCon'],
          	      launch: function () {
           	    	  Ext.widget('PoFilterList', {
           	          renderTo: 'pofilterlist'
           	        });
           	      }
           	    }
           	  );
               poFilterGridStatus=1;
               }
               
               	}
               }
           }
           	
           	
       }
	   
	  /* {
           xtype:'panel',
		   title : 'Summary',
           id: 'summary',
       		width:1120,
			border : true,
			frame : true,
			height : 300,
			 autoScroll: true,
        html: '<p class="details-info">See Your Scheme details here </p>'

		}*/
	   
	   
	   ]});

	
    Ext.QuickTips.init();


	var userInfo = null;
	
	
var	tab2 = Ext.create('Ext.form.Panel', {
         width: "100%",
		 height   : "100%",
        id: 'tab',
        layout: 'card',
        activeItem: 0,
        border: false,
        bodyStyle:'padding:0px 0px',
        fieldDefaults: {
            labelAlign: 'top',
            msgTarget: 'side'
        },
        defaults: {
        },

        items: [formPanel,schemeList,viewschemeList,SubmitschemeList,reportList,payoutAppList,bulkPanel,execCalList,sentToVtopList,stmGenList,holdPayList]
});

	
	Ext.Ajax.request({
		  url : 'getUserDetails.action',
		  method: 'GET',
		  type:'json',
		  waitMsg : 'Loading...',
		  headers: { 'Content-Type': 'application/json' },
		 
		    
		    success: function (response) {
				regionStore.load();
		    	poFilterVariables.load();
				componentListStore.load();
				
				
				
		    	 Ext.ux.mask.hide();
		    	userInfo = response.responseText;
		    	userInfo = Ext.JSON.decode(userInfo);

		    	
		    	
		    	var SamplePanel = Ext.extend(Ext.Panel, {
		            height   : "100%",
					 width: "100%",
		            //width: 1000,
		            bodyStyle:'padding:0px 0px',
		            id:'test',
		            //bodyStyle: 'padding:2px',
		            renderTo : Ext.getBody()
		        });

		    	formPanel.items.each(function(c){
		    		//c.down('Component').disable();
		    			//c.disable('Component');
		    			//c.getId('Component').disable = true;
//						c.items.items[1].setDisabled(true);
//						c.items.items[2].setDisabled(true);
//						c.items.items[3].setDisabled(true);
//						c.items.items[4].setDisabled(true);
//						c.items.items[5].setDisabled(true);
//						c.items.items[6].setDisabled(true);
//						c.items.items[7].setDisabled(true);
//						c.items.items[8].setDisabled(true);
						
		    		//c.down('Component').setDisabled(true);
		    		
		    		//c.disable();
		    		})		    	
		    	//	Ext.getCmp('tablist').down('2').setDisabled(true);
		    	
		    	if(userInfo.data.userRole[0]=='ROLE_CREATE')
		    		{
		    	
		    	new SamplePanel({
		            title: 'Scheme Configurations [ User: '+userInfo.data.userName+' | Circle: '+userInfo.data.userCircleCode+' ]',
		           
		            activeItem: 0,
		            lbar: [
		                   
		                {
		                    xtype:'splitbutton',
		                    text: 'Create',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	
		                    	Ext.Ajax.request({
		                   		  url : 'payoutcondition/clearScheme.action',
		                   		  method: 'POST',
		                   		    success: function (response) {
		                   		    	
		                   		    },
		                   		 
		                   		  failure: function (response) {
		                   		       }
		                   		 });
		                  	
		                    	componentListStore.load();
		                    	
		                    	 Ext.Ajax.request({
		                   		  url : 'payoutcondition/resetUpdateFlag.action',
		                   		  method: 'POST',
		                   		params: {
		          				  "success" : false
		          			    },
		          			     
		                   		    success: function (response) {
		                   		    	
		                   		    },
		                   		 
		                   		  failure: function (response) {
		                   		       }
		                   		 });
		                   	
		                    	
		                    	Ext.getCmp('tab').getLayout().setActiveItem(0);
		                    }
		                },
		                
		                {
		                    xtype:'splitbutton',
		                    text: 'View',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	
		                    	Ext.Ajax.request({
		                     		  url : 'payoutcondition/resetUpdateFlag.action',
		                     		  method: 'POST',
		                     		  
		                     		 params: {
		                 				  "success" : true
		                 			    },
		                 			    
		                     		    success: function (response) {
		                     		  
											console.log(response);
									  
		                     		    },
		                     		 
		                     		  failure: function (response) {

									  console.log(response);
									  
									  }
		                     		 });
		                    	
		                    	if(viewschemeGrid==0)
		                    	{
		                    	Ext.application({
		                    	    name  : 'Scheme',
		                    	    controllers: ['ViewSchemeCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('ViewSchemeList', {
		                    	    		  renderTo: 'viewscheme'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
		                    	
		                    			                    	
		                    	viewschemeGrid = 1;
								viewschemeStoreGrid.load(
									{
									params:
									{
								'isMaster':'YES',
								'isStage':'NO',
								'condParam':'D'
                           	}});
		                    }
									
									
		                    	Ext.getCmp('tab').getLayout().setActiveItem(2);
		                    	
		                    }
		                },
		                
		                {
		                    xtype:'splitbutton',
		                    text: 'Edit',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	
		                    	Ext.Ajax.request({
		                     		  url : 'payoutcondition/resetUpdateFlag.action',
		                     		  method: 'POST',
		                     		  
		                     		 params: {
		                 				  "success" : true
		                 			    },
		                 			    
		                     		    success: function (response) {
		                     		    	
		                     		    },
		                     		 
		                     		  failure: function (response) {
		                     		       }
		                     		 });
		                    	
		                    	if(searchGrid==0)
		                    	{
		                    	Ext.application({
		                    	    name  : 'Scheme',
		                    	    controllers: ['SchemeCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('SchemeList', {
		                    	    		  renderTo: 'scheme'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
								  searchGrid = 1;
		                    schemeStoreGrid.load();
							}
		                    	
		                    	
		                    	Ext.getCmp('tab').getLayout().setActiveItem(1);
		                    	
		                 }
		                },

		                
		    //scheme submission
		                
		                {
		                    xtype:'splitbutton',
		                    text: 'Submission',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	
		                    	        	
		                    	if(submitchemeGrid==0)
		                    	{
		                    	Ext.application({
		                    	    name  : 'Scheme',
		                    	    controllers: ['SubmitSchemeCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('SubmitSchemeList', {
		                    	    		  renderTo: 'submitscheme'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
		                    		
									submitchemeGrid = 1;
									submitschemeGrid.load();
									}

		                    	
		                    	
		                    	Ext.getCmp('tab').getLayout().setActiveItem(3);
		                    	
		                    }
		                },

		                {
		                    xtype:'splitbutton',
		                    text: 'Scheme Approval',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	
		                    	
		                    	if(reportGrid==0)
		                    	{
		                    		Ext.application({
		                    	    name  : 'Scheme',
		                    	   // autoCreateViewport: true,
		                    	    controllers: ['ReportCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('ReportList', {
		                    	    		  renderTo: 'report'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
		                    	
		                    	
		                    	reportGrid = 1;
		                    //	reportStoreGrid.load();
		                    	// compGridStatus=1;
		                    }
		                    	Ext.getCmp('tab').getLayout().setActiveItem(4);
		                    	
		                    	
		                    }
		                },
		                
		                {
		                    xtype:'splitbutton',
		                    text: 'Payout Approval',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	
		                    	if(payoutApprovalGrid==0)
		                    	{
		                    		Ext.application({
		                    	    name  : 'Scheme',
		                    	   // autoCreateViewport: true,
		                    	    controllers: ['ApproveSchemeCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('PayoutAppSchemeList', {
		                    	    		  renderTo: 'payoutApp'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
		                    	
		                    	
		                    		payoutApprovalGrid = 1;
		                    	
		                    }
		                    	
		                    	
		                    	Ext.getCmp('tab').getLayout().setActiveItem(5);
		                    	
		                    	
		                    }
		                },
		                
		                {
		                    xtype:'splitbutton',
		                    text: 'Bulk Upload File',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	
		                    	
		                    	Ext.getCmp('tab').getLayout().setActiveItem(6);
		                    	
		                    }
		                },
						
						{
		                    xtype:'splitbutton',
		                    text: 'Execution Calander',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	if(executeSchemeGrid==0)
		                    	{
		                    		Ext.application({
		                    	    name  : 'Scheme',
		                    	   // autoCreateViewport: true,
		                    	    controllers: ['ExecCalCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('ExecCalList', {
		                    	    		  renderTo: 'execList'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
		                    	
		                    	
		                    		executeSchemeGrid = 1;
		                    	
		                    }
		                    	
		                    	Ext.getCmp('tab').getLayout().setActiveItem(7);
		                    	
		                    }
		                },
						
						{
		                    xtype:'splitbutton',
		                    text: 'Payment',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	if(sentToVtopGrid==0)
		                    	{
		                    		Ext.application({
		                    	    name  : 'Scheme',
		                    	   // autoCreateViewport: true,
		                    	    controllers: ['VtopUpCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('VtopList', {
		                    	    		  renderTo: 'sentToVtop'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
		                    	
		                    	
		                    		sentToVtopGrid = 1;
		                    	
		                    }
		                    	
		                    	Ext.getCmp('tab').getLayout().setActiveItem(8);
		                    	
		                    }
		                },
						
				//Stm_GEn
				
				{
		                    xtype:'splitbutton',
		                    text: 'StmtGen',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	if(stmGenGrid==0)
		                    	{
		                    		Ext.application({
		                    	    name  : 'Scheme',
		                    	   // autoCreateViewport: true,
		                    	    controllers: ['ScmGenCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('StmGenList', {
		                    	    		  renderTo: 'stmGen'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
		                    	
		                    	
		                    		stmGenGrid = 1;
		                    	
		                    }
		                    	
		                    	Ext.getCmp('tab').getLayout().setActiveItem(9);
		                    	
		                    }
		                },

		                
		                {
		                    xtype:'splitbutton',
		                    text: 'HoldPay',
		                    iconCls: 'add16',
		                    handler: function(){
		                    	if(holdGridStatus==0)
		                    	{
		                    		Ext.application({
		                    	    name  : 'Scheme',
		                    	   // autoCreateViewport: true,
		                    	    controllers: ['HoldPayCon'],
		                    	      launch: function () {
		                    	    	  Ext.widget('HoldPayList', {
		                    	    		  renderTo: 'holdPay'
		                    	        });
		                    	      }
		                    	    }
		                    	  );
		                    		holdGridStatus = 1;
		                    }
		                    	Ext.getCmp('tab').getLayout().setActiveItem(10);
		                    }
		                },

				
		//sentToVtopGrid				
		                {
		                    xtype:'button',
		                    text:'Logout',
		                    iconCls:'logout-icon',
		                    href:'j_spring_security_logout',
		                    hrefTarget:'_self'
		                }
		    				            
		            ],
		            items:[tab2]
		           
		           
		            
		        });
		    		}
		    	
		    	
		   //Non Admin 	
		    	else
		    		{
			    	new SamplePanel({
			            title: 'Scheme Configurations [ UserName: '+userInfo.data.userName+' ]',
			           
			            activeItem: 0,
			            lbar: [
			                   
			                
			                {
			                    xtype:'splitbutton',
			                    text: 'View',
			                    iconCls: 'add16',
			                    handler: function(){
			                    	
			                    	
			                    	if(viewschemeGrid==0)
			                    	{
//			                    		
			                    	Ext.application({
			                    	    name  : 'Scheme',
			                    	   
			                    	    controllers: ['ViewSchemeCon'],
			                    	      launch: function () {
			                    	    	  Ext.widget('ViewSchemeList', {
			                    	    		  renderTo: 'viewscheme'
			                    	        });
			                    	      }
			                    	    }
			                    	  );
			                    	
			                    	
			                    	viewschemeGrid = 1;
			                    		}
			                    	Ext.getCmp('tab').getLayout().setActiveItem(2);
			                    	
			                    }
			                },
			                

			                
			                
			                {
			                    xtype:'button',
			                    text:'Logout',
			                    iconCls:'logout-icon',
			                    href:'j_spring_security_logout',
			                    hrefTarget:'_self'
			                }
			    				            
			            ],
			            items:[tab2]
			           
			           
			            
			        });
		    		
		    		if(viewschemeGrid==0)
			    	{
			    	Ext.application({
                	    name  : 'Scheme',
                	   // autoCreateViewport: true,
                	    controllers: ['ViewSchemeCon'],
                	      launch: function () {
                	    	  Ext.widget('ViewSchemeList', {
                	    		  renderTo: 'viewscheme'
                	        });
                	      }
                	    }
                	  );
                	
			    	viewschemeGrid = 1;
		    		}
		    
					}
		    
		    
		    
		    }, //sucess body close
		 
		  failure: function (response) {
		       }
		 });
	
   
});

Ext.require([
    'Ext.panel.*',
    'Ext.toolbar.*',
    'Ext.button.*',
    'Ext.container.ButtonGroup',
    'Ext.layout.container.Table', 
    'Ext.tip.QuickTipManager'
]); 
function saveBulkFile(bulkForm)
{
	bulkForm.submit({
		
		 waitMsg : 'Loading...',
		 url: 'bulkUpload/bulkFileUpload.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		// enctype : 'multipart/form-data',
		 //headers: {'Content-Type':'multipart/form-data;'},
		 method : 'POST',
        
		 success: function(form, action) {
            //Ext.Msg.alert('Bulk File Sucessfully');
            Ext.Msg.alert('Info', action.result.errorMessage);
            //form.reset();
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        }
    });	
}

Ext.onReady(function() {

	Ext.define('Ext.grid.override.RowEditor', {
	    override: 'Ext.grid.RowEditor',
	    
	    initComponent: function() {
	        var me = this;
	            
	        me.callParent(arguments);
	        
	        me.getForm().on('validitychange', me.onValidityChange, me);
	    },    
	    
	    onValidityChange: function() {
	        var me = this,
	            form = me.getForm(),
	            valid = form.isValid();
	        
	        if (me.errorSummary && me.isVisible()) {
	            me[valid ? 'hideToolTip' : 'showToolTip']();
	        }
	        me.updateButton(valid);
	        me.isValid = valid;
	    }
	    
	});

	

	 	 Ext.Ajax.on('requestexception', function(conn, response, options, e) {
	  location.reload(); 
	}); 
	 
//Start Date End Data Validation

/*Ext.apply(Ext.form.VTypes, {
    daterange : function(val, field) {
        var date = field.parseDate(val);
 
        if(!date){
            return;
        }
        if (field.startDateField && (!this.dateRangeMax || (date.getTime() != this.dateRangeMax.getTime()))) {
            var start = Ext.getCmp(field.startDateField);
            start.setMaxValue(date);
            start.validate();
            this.dateRangeMax = date;
        }
        else if (field.endDateField && (!this.dateRangeMin || (date.getTime() != this.dateRangeMin.getTime()))) {
            var end = Ext.getCmp(field.endDateField);
            end.setMinValue(date);
            end.validate();
            this.dateRangeMin = date;
        }
        return true;
    }
});
*/








//Po Grid

var compIdPo = 0;
var inputType = null;
//var stdatePo = null;
//var enddatePo = null;


    Ext.define('Po', {
        extend: 'Ext.data.Model',
        fields: [
			{name:'compId',type: 'int'},
			{name:'condId',type: 'int'},
			{name:'condRowId',type: 'int'},
			{name:'value'},
			{name:'inputType'},
			{name:'inputParameter'},
			{name:'oprName'},
			{name:'valueType'},
			{name:'Lopr'},
			{name:'GrossNet',type: 'int'},
			{name:'Amount',type: 'int'},
			{name:'Unit'},
			{name:'Pay'},
			{name:'OverAch',type: 'int'},
			{name:'UnderAch',type: 'int'}
            ]
    });


    var rowEditing = Ext.create('Ext.grid.plugin.RowEditing', {
        clicksToMoveEditor: 1,
        autoCancel: false,
		listeners: {
		
		 rowdblclick: function(dv, record, item, index, e) {
				alert('working');
			
			},
			
			 itemdblclick: function(dv, record, item, index, e) {
				alert('working');
			
			},
			
			startEditByClick: function() {
				alert('working');
			
			
			
			},
		
		
		
        edit: function(editor, context, eOpts) {
				
		var overAchtest =  editor.editor.form.findField('overAch').getValue();
		var underAchtest =  editor.editor.form.findField('underAch').getValue();
		if(underAchtest != 0){
			if(overAchtest <= underAchtest){
					Ext.Msg.alert("Warning","<font color='blue'>'Over Achievement' should be greater than 'Under Achievement'.</font>");
				return false;
			}
		}
				
		var  oprName = Po_oprStore.findRecord('oprName',editor.editor.form.findField('oprName').getValue());
		var  loprName = RoprStore.findRecord('oprName',editor.editor.form.findField('loprName').getValue());
		var unitName = unitStore.findRecord('unitName',editor.editor.form.findField('unitName').getValue());
		var inputType = inputTypeStorePO.findRecord('inputType',editor.editor.form.findField('inputType').getValue());
		var valueType = valueTypeStorePO.findRecord('valueTypeName',editor.editor.form.findField('valueType').getValue());

		//console.log(valueType);
		
		//alert(editor.editor.form.findField('valueType').getValue());
		if(oprName!=null)
		editor.editor.form.findField('oprName').setValue(oprName.data.oprId);
		
		
		editor.editor.form.findField('loprName').setValue(loprName.data.oprId);
		
		if(unitName!=null)
		editor.editor.form.findField('unitName').setValue(unitName.data.unitId);
		
		if(inputType!=null)
		editor.editor.form.findField('inputType').setValue(inputType.data.inputTypeId);
		
		if(valueType!=null)
		{
		//alert(valueType.data.valueTypeId);
		console.log(valueType.data.valueTypeId);
		editor.editor.form.findField('valueType').setValue(valueType.data.valueTypeId);
		}
		
		editor.editor.form.submit({
		
			
		 waitMsg : 'Loading...',
		// url : 'payoutcondition/updatePo.action',
			url : 'payoutcondition/updatePo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
        
		/* params: {
			  "oprName" : oprName.data.oprId,
			  "loprName":	loprName.data.oprId,
		    },
		*/	
			
		 success: function(form, action) {
            Ext.Msg.alert('Payout condition updated successfully');
            poFilterValues.load();
           	componentListStorePo.load();
			poStore.load();
            
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribute Mapping Error");
        	}
        }
    });
			
			
        }
    }
		
    });

    // create the grid and specify what field you want
    // to use for the editor at each column.
    var gridPo = Ext.create('Ext.grid.Panel', {
    	store: poStore,
    	selModel : Ext.create('Ext.selection.CheckboxModel'),
    	autoScroll : true,
    	features: [groupingFeaturePO],
    	layout : 'fit',
    	height  : '100%',
    	columns: [
    	          { 
    	        	  //xtype: 'numbercolumn',
    	        	  header: 'compId', 
    	        	  dataIndex: 'compId', 
    	        	  width: 30,
    	        	  editor: {
    	        		  xtype :'numberfield',
    	        		  editable: false,
    	        		  readOnly : true,
    	        		  name:'compId'
    	        	  }
    	          },
    	          { 
    	        	  //xtype: 'numbercolumn',
    	        	  header: 'condId', 
    	        	  dataIndex: 'condId',
    	        	  editor: {
    	        		  xtype :'numberfield',
    	        		  readOnly : true,
    	        		  editable: false,
    	        		  name:'condId'
    	        	  },
    	        	  width: 30 
    	          },
    	          {
    	        	  //xtype: 'numbercolumn',
    	        	  header: 'condRowId', 
    	        	  dataIndex: 'condRowId', 
    	        	  editor: {
    	        		  xtype :'numberfield',
    	        		  readOnly : true,
    	        		  editable: false,
    	        		  name:'condRowId'
    	        	  },
    	        	  width: 30 
    	          },
    	          {
    	        	  header: 'Input Type',
    	        	  dataIndex: 'inputType',
    	        	  flex: 1,
    	        	  editor: {
    	        		  xtype :'combo',
    	        		  editable: false,
    	        		  name:'inputType',
    	        		  displayField:'inputType',
    	        		  valueField:'inputTypeId',
    	        		  store:inputTypeStorePO,
    	        		  listeners: {
    	        			  'select': function(combo, value){
    	        				  inputType = "Yes";
    	        				  rowEditing.editor.form.findField('inputParameter').allowBlank = false;
    	        				  rowEditing.editor.form.findField('oprName').enable();
    	        				  rowEditing.editor.form.findField('valueType').enable();
    	        				  if(combo.getValue()==2)
    	        				  {
    	        					  freeTextDataType='N';
    	        				  }
    	        				  else
    	        				  {
    	        					  freeTextDataType='L';
    	        				  }
    	        				  if(combo.getValue()==6)
    	        				  {
    	        					  rowEditing.editor.form.findField('inputParameter').enable();
    	        					  rowEditing.editor.form.findField('inputParameter').reset();

    	        					  poFilterVariables.clearFilter();
    	        					  poFilterVariables.filter('poVarFlag','Y');
    	        					  //compId
    	        					  poFilterVariablesPO.clearFilter();
    	        					  if(compIdPo!=null){
    	        						  poFilterVariables.filter('compId',compIdPo);
    	        						  poFilterVariablesPO.filter('compId',compIdPo);
    	        					  }
    	        						  
    	        				  }
    	        				  else
    	        				  {
    	        					  poFilterVariablesPO.clearFilter();
    	        					  if(compIdPo!=null){
    	        						  poFilterVariablesPO.filter('compId',compIdPo);
    	        					  }
    	        					  rowEditing.editor.form.findField('inputParameter').reset();
    	        					  var inputTypeId = inputTypeStorePO.findRecord('inputTypeId',combo.getValue(),0, false, true, true);
    	        					  inputParameterStore.clearFilter();
    	        					  inputParameterStore.filter("attrType",inputTypeId.data.inputTypeId);
    	        					  poFilterVariables.clearFilter();
    	        					  poFilterVariables.filter('poVarFlag','N');

    	        					  poFilterVariables.filter('poAttrCatg',inputTypeId.data.inputTypeId);
    	        					  if(compIdPo!=null)
    	        					  {
    	        						  var payTo = componentListStore.findRecord('compId',compIdPo);
    	        						  poFilterVariables.filter('poAttrType',payTo.data.payTo);
    	        					  }
    	        					  rowEditing.editor.form.findField('inputParameter').enable();
    	        					  rowEditing.editor.form.findField('inputParameter').reset();
    	        					  rowEditing.editor.form.findField('inputParameter').setValue('','');
    	        				  }
    	        			  }
    	        		  },
    	        		  triggerAction:'all'
    	        	  }
    	          }, 
    	          {
    	        	  itemId: 'inputParameter',
    	        	  header: 'Input Parameter',
    	        	  dataIndex: 'inputParameter',
    	        	  flex: 1,
    	        	  editor: {
    	        		  xtype :'combo',
    	        		  itemId: 'inputParameter',        	        	
    	        		  name:'inputParameter',
    	        		  editable: false,
    	        		  disabled: true,
    	        		  displayField:'variableName',
    	        		  valueField:'variableName',
    	        		  store: poFilterVariables,
    	        		  listeners: {
    	        			  'select': function(combo, value){
    	        				  var temp =  poFilterVariables.findRecord('variableName', combo.getValue(),0, false, true, true);
    	        				  if(temp.data.poVarFlag=='Y')
    	        				  {
    	        					  Po_oprStore.clearFilter();
    	        					  Po_oprStore.filter(function(r) {
    	        						  var value = r.get('oprType');
    	        						  return (value == 'R' || value == 'S');
    	        					  });
    	        				  }
    	        				  else
    	        				  {
    	        					  Po_oprStore.clearFilter();
    	        					  var	oprFilterPo =   poFilterVariables.findRecord('variableName',combo.getValue(),0, false, true, true);
    	        					  oprFilterPo = oprFilterPo.data.oprType;
    	        					  Po_oprStore.clearFilter();
    	        					  if(oprFilterPo=='D')
    	        					  {
    	        						  Po_oprStore.filter('dataFlag','Y');
    	        					  }
    	        					  if(oprFilterPo=='N')
    	        					  {
    	        						  Po_oprStore.filter('numberFlag','Y');
    	        					  }
    	        					  if(oprFilterPo=='S')
    	        					  {
    	        						  Po_oprStore.filter('stringFlag','Y');
    	        					  }
    	        				  }
    	        			  }
    	        		  },
    	        		  triggerAction:'all'
    	        	  }
    	          }, 
    	          {
    	        	  itemId: 'opr',
    	        	  header: 'OPR',
    	        	  name:'opr',
    	        	  dataIndex: 'oprName',
    	        	  flex: 1,
    	        	  editor: {
    	        		  xtype :'combo',
    	        		  editable: false,
    	        		  name:'opr',
    	        		  disabled : true,
    	        		  allowBlank: false,
    	        		  displayField:'oprName',
    	        		  valueField:'oprName',
    	        		  store: Po_oprStore,
    	        		  listeners: {
    	        			  'select': function(combo, value){
    	        				  rowEditing.editor.form.findField("startDate").enable();
    	        				  rowEditing.editor.form.findField("endDate").enable();
    	        				  rowEditing.editor.form.findField('valueType').allowBlank = false;
    	        				  if(combo.getValue()=='Date Range')
    	        				  {
    	        					  rowEditing.editor.form.findField("valueType").disable();
    	        					  rowEditing.editor.form.findField('value').disable();
    	        					  rowEditing.editor.form.findField('ValueListName').disable();
    	        					  rowEditing.editor.form.findField('startDate').allowBlank=false;
    	        					  rowEditing.editor.form.findField('endDate').allowBlank=false;
    	        				  
    	        					  //rowEditing.editor.form.findField('startDate').setValue(stdatePo);
    	        					  //rowEditing.editor.form.findField('endDate').setValue(enddatePo);
    	        					  
    	        				  }
    	        				  else
    	        				  {
    	        					  rowEditing.editor.form.findField('valueType').enable();
    	        					  rowEditing.editor.form.findField('startDate').allowBlank=true;
    	        					  rowEditing.editor.form.findField('endDate').allowBlank=true;
    	        					  
    	        					//  rowEditing.editor.form.findField('startDate').setValue(stdatePo);
    	        					//  rowEditing.editor.form.findField('endDate').setValue(enddatePo);
    	        					  
    	        				  }
    	        			  }
    	        		  },
    	        		  triggerAction:'all'
    	        	  }
    	          },
    	          {
    	        	  itemId: 'valueType',
    	        	  header: 'Value Type',
    	        	  dataIndex: 'valueType',
    	        	  flex: 1,
    	        	  editor: {
    	        		  xtype :'combo',
    	        		  disabled : true,
    	        		  editable: false,
    	        		  allowBlank: false,
    	        		  name:'valueType',
    	        		  displayField:'valueTypeName',
    	        		  valueField:'valueTypeId',
    	        		  store: valueTypeStorePO,
    	        		  listeners: {
    	        			  'select': function(combo, value){
    	        				  if(combo.getValue()==5)
    	        				  {
    	        					  rowEditing.editor.form.findField('value').allowBlank=true;
    	        					  rowEditing.editor.form.findField('startDate').allowBlank=false;
    	        					  rowEditing.editor.form.findField('endDate').allowBlank=false;
    	        					  
    	        					 // rowEditing.editor.form.findField('startDate').setValue(stdatePo);
    	        					 // rowEditing.editor.form.findField('endDate').setValue(enddatePo);
    	        					  
    	        				  }
    	        				  else
    	        				  {
    	        					  rowEditing.editor.form.findField('value').allowBlank=false;
    	        				  }
    	        				  if(combo.getValue()==1)
    	        				  {

    	        					  rowEditing.editor.form.findField('value').enable();
    	        					  rowEditing.editor.form.findField('value').reset();
    	        					  rowEditing.editor.form.findField('value').allowBlank = false;
    	        					  rowEditing.editor.form.findField('startDate').allowBlank=true;
    	        					  rowEditing.editor.form.findField('endDate').allowBlank=true;
    	        					  //  rowEditing.editor.form.findField('ValueListName').disable();
    	        				  }

    	        				  else
    	        				  {
    	        					  /* rowEditing.editor.form.findField('value').disable();
																		  entityStorePo.clearFilter();
																		  //var filterValue = valueTypeStorePO.findRecord('valueTypeName',combo.getValue());

																			entityStorePo.filter('attrCatg',filterValue.data.valueTypeId);

																		  rowEditing.editor.form.findField('ValueListName').enable();
																		  rowEditing.editor.form.findField('ValueListName').reset();
    	        					   */
    	        				  }
    	        			  }
    	        		  },
    	        		  triggerAction:'all'
    	        	  }
    	          },
    	          {
    	        	  itemId: 'value',
    	        	  header: 'Value',
    	        	  dataIndex: 'value',
    	        	  flex: 1,
    	        	 //maskRe:/[A-Za-z0-9_, ]/,
    	        	  editor: {
    	        		  xtype :'textfield',
    	        		  disabled : true,
    	        		  name:'value',
    	        		  enforceMaxLength  : true,
    	        		  maxLength:100,
    	        		  listeners:{
    	        			  'change': function(field, newValue, oldValue){
    	        				  field.setValue(newValue.toUpperCase());
    	        			  }
    	        		  }
    	        	  }
    	          },
    	          {
    	        	  itemId: 'startDate',
    	        	  xtype: 'datecolumn',
    	        	  header: 'Start Date',
    	        	  dataIndex: 'startDate',
    	        	  editor: {
    	        		  xtype: 'datefield',
    	        		  format: 'm/d/Y',
    	        		  minValue: '01/01/2006',
    	        		  minText: 'Cannot have a start date before today!',
    	        		  //  maxValue: Ext.Date.format(new Date(), 'm/d/Y')
    	        	  }
    	          },
    	          {
    	        	  itemId: 'endDate',	
    	        	  xtype: 'datecolumn',
    	        	  header: 'End Date',
    	        	  dataIndex: 'endDate',
    	        	  editor: {
    	        		  xtype: 'datefield',
    	        		  format: 'm/d/Y',
    	        		  minValue: '01/01/2006',
    	        		  minText: 'Cannot have a start date before today!',
    	        		  // maxValue: Ext.Date.format(new Date(), 'm/d/Y')
    	        	  }
    	          },
    	          {

    	        	  header: 'LOPR',
    	        	  dataIndex: 'loprName',
    	        	  flex : 1,
    	        	  editor: {
    	        		  xtype :'combo',
    	        		  editable: false,
    	        		  name:'lopr',
    	        		  allowBlank : false,
    	        		  displayField:'oprName',
    	        		  valueField:'oprName',
    	        		  store: RoprStore,
    	        		  listeners: {
    	        			  'select': function(combo, value){
    	        				  if((combo.getValue()=='And') || (combo.getValue()=='OR'))
    	        				  {
    	        					  rowEditing.editor.form.findField('grossNet').disable();
    	        					  rowEditing.editor.form.findField('unitName').disable();
    	        					  rowEditing.editor.form.findField('amount').disable();
    	        					  rowEditing.editor.form.findField('paymentVariable').disable();
    	        					  rowEditing.editor.form.findField('overAch').disable();
    	        					  rowEditing.editor.form.findField('underAch').disable();
    	        				  }
    	        				  else if(((combo.getValue()=='Add New Condition') || (combo.getValue()=='Close Condition')) && (rowEditing.editor.form.findField('unitName').getValue()== 'Flat' || rowEditing.editor.form.findField('unitName').getValue() == 'Points'))
    	        				  {
    	        					  rowEditing.editor.form.findField('grossNet').enable();
    	        					  rowEditing.editor.form.findField('unitName').enable();
    	        					  rowEditing.editor.form.findField('amount').enable();
    	        					  rowEditing.editor.form.findField('overAch').enable();
    	        					  rowEditing.editor.form.findField('underAch').enable();
    	        				  }
    	        				  else
    	        				  {
    	        					  rowEditing.editor.form.findField('grossNet').enable();
    	        					  rowEditing.editor.form.findField('unitName').enable();
    	        					  rowEditing.editor.form.findField('amount').enable();
    	        					  rowEditing.editor.form.findField('paymentVariable').enable();
    	        					  rowEditing.editor.form.findField('overAch').enable();
    	        					  rowEditing.editor.form.findField('underAch').enable();
    	        				  }
    	        			  }
    	        		  },
    	        		  triggerAction:'all'            }
    	          },
    	          {
    	        	  itemId: 'grossNet',	
    	        	  header: 'GrossNet',
    	        	  dataIndex: 'grossNet',
    	        	  flex: 1,
    	        	  editor: {
    	        		  xtype :'combo',
    	        		  name:'grossNet',
    	        		  disabled: true,
    	        		  allowBlank:false,
    	        		  editable: false,
    	        		  displayField:'name',
    	        		  valueField:'name',
    	        		  store: CreateGrossNetStore(),
    	        		  triggerAction:'all'
    	        	  }
    	          },
    	          {
    	        	  itemId: 'unitName',	
    	        	  header: 'Unit',
    	        	  dataIndex: 'unitName',
    	        	  flex: 1,
    	        	  editor: {
    	        		  xtype :'combo',
    	        		  name:'unitName',
    	        		  disabled: true,
    	        		  allowBlank:false,
    	        		  editable: false,
    	        		  displayField:'unitName',
    	        		  valueField:'unitName',
    	        		  store: unitStore,
    	        		  listeners: {
    	        			  'select': function(combo, value){
    	        				  if((combo.getValue()=='Per Event')||(combo.getValue()=='Percentage'))
    	        				  {
    	        					  //poFilterVariables.clearFilter();
    	        					  //poFilterVariables.filter('poVarFlag','Y');
    	        					  rowEditing.editor.form.findField("paymentVariable").enable();
    	        					  rowEditing.editor.form.findField("paymentVariable").allowBlank = false;
    	        				  }
    	        				  else
    	        				  {
    	        					  if(inputType =='Yes')
    	        						  rowEditing.editor.form.findField("paymentVariable").disable();
    	        					  else
    	        					  {
    	        						  //poFilterVariables.clearFilter();
    	        						  //	poFilterVariables.filter('poVarFlag','Y');
    	        						  rowEditing.editor.form.findField("paymentVariable").enable();
    	        						  rowEditing.editor.form.findField("paymentVariable").allowBlank = true;
    	        					  }
    	        				  }
    	        				  poFilterVariables.clearFilter();
    	        				  poFilterVariables.filter('poVarFlag','Y');
    	        				  if(compIdPo!=null)
    	        					  poFilterVariables.filter('compId',compIdPo);
    	        			  }
    	        		  },
    	        		  triggerAction:'all'
    	        	  }
    	          },
    	          {
    	        	  itemId: 'amount',	
    	        	  xtype: 'numbercolumn',
    	        	  header: 'Amount',
    	        	  dataIndex: 'amount',
    	        	  flex: 1,
    	        	  editor: {
    	        		  name : 'amount',
    	        		  xtype: 'numberfield',
    	        	  }
    	          },
    	          {
    	        	  itemId: 'paymentVariable',	
    	        	  header: 'Variable',
    	        	  dataIndex: 'paymentVariable',
    	        	  flex: 1,
    	        	  editor: {
    	        		  xtype :'combo',
    	        		  name:'variable',
    	        		  disabled: true,
    	        		  allowBlank:false,
    	        		  editable: false,
    	        		  displayField:'variableName',
    	        		  valueField:'variableName',
    	        		  store: poFilterVariablesPO,
    	        		  triggerAction:'all'
    	        	  }
    	          },
    	          {

    	        	  itemId: 'overAch',		
    	        	  xtype: 'numbercolumn',
    	        	  header: 'OverAchievement Cap',
    	        	  dataIndex: 'overAch',
    	        	  flex : 1,
    	        	  editor: {
    	        		  xtype: 'numberfield',
    	        		  allowBlank: false,
    	        		  name : 'overAch'
    	        	  }
    	          },
    	          {
    	        	  itemId: 'underAch',
    	        	  xtype: 'numbercolumn',
    	        	  header: 'UnderAchievement Cap',
    	        	  dataIndex: 'underAch',
    	        	  flex : 1,
    	        	  editor: {
    	        		  xtype: 'numberfield',
    	        		  allowBlank: false,
    	        		  name : 'underAch'
    	        	  }
    	          },
    	          {
      		    	   xtype :'textfield',
      		    	   fieldLabel: 'CsrfName',
					   hidden:true,
      		    	   disabled : true,
      		    	   name: 'csrfPo',
					   maxLength : 100,
      		    	   allowBlank:false,
      		    	   id:'testCsrfPo'
      		    }
    	          ],
    	          tbar: [
    	                 {
    	                	 itemId: 'AddPo',
    	                	 disabled : true,
    	                	 text: 'Add',
    	                	 iconCls: 'employee-add',
    	                	 handler : function() {
    	                		 rowEditing.cancelEdit();
    	                		 componentListStore.load();
    	                		 inputType = null;
    	                		 Po_oprStore.load();
    	                		 RoprStore.load();
    	                		 Po_oprStore.clearFilter();
    	                		 Po_oprStore.filter(function(r) {
    	                			 var value = r.get('oprType');
    	                			 return (value == 'R' || value == 'S');
    	                		 });
    	                		 RoprStore.clearFilter();
    	                		 RoprStore.filter("poFlag",'Y');
    	                		 // Create a model instance

    	                		 Ext.Ajax.request({
    	                			 url : 'payoutcondition/addPo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    	                			 method: 'POST',
    	                			 params: {
    	                				 "compId" : compIdPo,

    	                			 },
    	                			 success: function (response) {
    	                				 var r = null;
    	                				 //	Ext.Msg.alert("Info","Update PO");
    	                				 poStore.load({
    	                					 callback: function(records, operation, success) {
    	                						 if (success == true) {
    	                							 if(poStore.data.items[0])
    	                							 {
    	                								 r = Ext.create('Po', {
    	                									 compId: poStore.data.items[0].data.compId,
    	                									 condId: poStore.data.items[0].data.condId,
    	                									 condRowId: poStore.data.items[0].data.condRowId,
    	                									 value: poStore.data.items[0].data.value,
    	                									 inputType:poStore.data.items[0].data.inputType,
    	                									 inputParameter:poStore.data.items[0].data.inputParameter,
    	                									 oprName:poStore.data.items[0].data.oprName,
    	                									 valueType: poStore.data.items[0].data.valueType,
    	                									 Lopr: poStore.data.items[0].data.loprName,
    	                									 GrossNet : poStore.data.items[0].data.grossNet,
    	                									 Amount:poStore.data.items[0].data.amount,
    	                									 Unit:poStore.data.items[0].data.unitName,
    	                									 Pay:poStore.data.items[0].data.paymentVariable,
    	                									 OverAch:poStore.data.items[0].data.overAch,
    	                									 UnderAch:poStore.data.items[0].data.underAch,
    	                									 active: true
    	                								 });
    	                							 }

    	                							 /* else

				{

				r = Ext.create('Po', {

					compId: ,
					condId: poStore.data.items[0].data.condId,
					condRowId: poStore.data.items[0].data.condRowId,
					value: poStore.data.items[0].data.value,
					inputType:poStore.data.items[0].data.inputType,
					inputParameter:poStore.data.items[0].data.inputParameter,
					oprName:poStore.data.items[0].data.oprName,
					valueType: poStore.data.items[0].data.valueType,
					Lopr: poStore.data.items[0].data.loprName,
					GrossNet : poStore.data.items[0].data.grossNet,
					Amount:poStore.data.items[0].data.amount,
					Unit:poStore.data.items[0].data.unitName,
					Pay:poStore.data.items[0].data.paymentVariable,
					OverAch:poStore.data.items[0].data.overAch,
					UnderAch:poStore.data.items[0].data.underAch,
                    active: true
                });



				} */

    	                							 if(r==null)
    	                							 {
    	                								 poStore.insert(0, r);
    	                								 rowEditing.startEdit(0, 0);
    	                							 }



    	                						 }

    	                					 }
    	                				 });
    	                				 componentListStorePo.load();
    	                			 },

    	                			 failure: function (response) {
    	                			 }
    	                		 });








    	                	 }
    	                 }, {
    	                	 itemId: 'removePo',
    	                	 text: 'Remove',
    	                	 iconCls: 'employee-remove',
    	                	 handler: function() {
    	                		 var sm = gridPo.getSelectionModel();
    	                		 rowEditing.cancelEdit();

    	                		 var rs = sm.getSelection();													
                                
    	                		 var poParamVal="";
                              	  
                              	  for(var i=0;i<rs.length;i++)
                              		  {
                              		  if((i+1)!=rs.length)
                              			poParamVal +=rs[i].data.compId+","+rs[i].data.condId+","+rs[i].data.condRowId+":";
                              		  else
                              			poParamVal +=rs[i].data.compId+","+rs[i].data.condId+","+rs[i].data.condRowId;  
                              		  
                              		  }
    	                		 
    	                		 Ext.Ajax.request({
    	                			 url : 'payoutcondition/removePo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    	                			 method: 'POST',
    	                			 params: {
    	                				 "ValueListName":poParamVal
    	                			 },
    	                			 success: function (response) {
    	                				 var response1 = Ext.decode(response.responseText);
    	                				 Ext.Msg.alert("Info",response1.message);
    	                				 poStore.load();
    	                				 componentListStorePo.load();
    	                			 },

    	                			 failure: function (response) {
    	                			 }
    	                		 });
    	                		 poStore.remove(sm.getSelection());
    	                		 if (poStore.getCount() > 0) {
    	                			 sm.select(0);
    	                		 }
    	                	 
    	                		 /*
    	                		 var sm = gridPo.getSelectionModel();
    	                		 rowEditing.cancelEdit();

    	                		 var rs = sm.getSelection();													

    	                		 Ext.Ajax.request({
    	                			 url : 'payoutcondition/removePo.action',
    	                			 method: 'POST',
    	                			 params: {
    	                				 "compId" : rs[0].data.compId,
    	                				 "condId" :rs[0].data.condId,
    	                				 "condRowId": rs[0].data.condRowId
    	                			 },
    	                			 success: function (response) {
    	                				 var response = Ext.decode(response.responseText);
    	                				 Ext.Msg.alert("Info",response.message);
    	                				 poStore.load();
    	                				 componentListStorePo.load();
    	                			 },

    	                			 failure: function (response) {
    	                			 }
    	                		 });
                                //	}
    	                		 Ext.Ajax.request({
    	                			 url : 'payoutcondition/removePo.action',
    	                			 method: 'POST',
    	                			 params: {
    	                				 "compId" : rs[0].data.compId,
    	                				 "condId" :rs[0].data.condId,
    	                				 "condRowId": rs[0].data.condRowId
    	                			 },
    	                			 success: function (response) {
    	                				 var response = Ext.decode(response.responseText);
    	                				 Ext.Msg.alert("Info",response.message);
    	                				 poStore.load();
    	                				 componentListStorePo.load();
    	                			 },

    	                			 failure: function (response) {
    	                			 }
    	                		 });


    	                		 poStore.remove(sm.getSelection());
    	                		 if (poStore.getCount() > 0) {
    	                			 sm.select(0);
    	                		 }
    	                	 */},
    	                	 disabled: true
    	                 },

    	                 {
    	                	 xtype :'combo',
    	                	 fieldLabel: 'Component*',
    	                	 name:'compId',
    	                	 id: 'poCompList',
    	                	 allowBlank:false,
    	                	 editable: false,
    	                	 displayField:'compName',
    	                	 valueField:'compId',
    	                	 store: componentListStorePo,
    	                	 listeners: {
    	                		 'select': function(combo, value){
    	                			 poStore.load();
    	                			 compIdPo = combo.getValue();
    	                			 poStore.clearFilter();
    	                			 poStore.filter('compId',combo.getValue());
    	                			 gridPo.down('#AddPo').setDisabled(false);
    	                		 }
    	                	 },
    	                	 triggerAction:'all'
    	                 },

    	                 {
    	                	 itemId: 'copyPo',
    	                	 text: 'Copy Condition',
    	                	 iconCls: 'employee-remove',
    	                	 handler: function() {
    	                		 var sm = gridPo.getSelectionModel();
    	                		 rowEditing.cancelEdit();
    	                		 var rs = sm.getSelection();													
    	                		 if (!rs.length) {
    	            				 Ext.Msg.alert('Info', 'No PO is Selected');
    	            				 return;
    	            			 }
    	                		 
    	                		 var tqParamVal = true;

               					 for(var i=0; i<rs.length; i++)
               					 {
               						 if((i+1) != rs.length){
               							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
               								 tqParamVal=false;
    	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To copy condition.</font>");
               							 }
               						 }else{
               							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
               								 tqParamVal=false;	  
    	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To copy condition.</font>");
               							 }
               						 }
               					 }

               					 if(tqParamVal){ 
               						 Ext.Ajax.request({
               							 url : 'schemeinput_tq/copyCondition.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
               							 method: 'POST',
               							 params: {
               								 "compId" : rs[0].data.compId,
               								 "condId" : rs[0].data.condId,
               								 "processType" : 'PO',
               							 },
               							 success: function (response) {
               								 var response1 = Ext.decode(response.responseText);
               								 Ext.Msg.alert("Info",response1.message);
               								 poStore.load();
               							 },
               							 failure: function (response) {
               							 }
               						 });
               					 }
    	                	 }
    	                 },

    	                 {
    	                	 itemId: 'copyMultiRowsPo',
    	                	 text: 'CopyMultiRows',
    	                	 iconCls: 'employee-remove',
    	                	 handler: function() {
    	                		 var sm = gridPo.getSelectionModel();
    	                		 rowEditing.cancelEdit();

    	                		 var rs = sm.getSelection();													
                                
    	                		 var poParamVal="";
                              	  if(compIdPo==0){
                              		Ext.Msg.alert('Info', 'Please select component*.');
                              		  return;
                              	  }
                              	  for(var i=0;i<rs.length;i++)
                              		  {
                              		  if((i+1)!=rs.length)
                              			poParamVal +=compIdPo+","+rs[i].data.compId+","+rs[i].data.condId+","+rs[i].data.condRowId+":";
                              		  else
                              			poParamVal +=compIdPo+","+rs[i].data.compId+","+rs[i].data.condId+","+rs[i].data.condRowId;  
                              		  
                              		  }
                              	if(poParamVal){ 
              						 Ext.Ajax.request({
              							 url : 'payoutcondition/insertMultiRowPo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
              							 method: 'POST',
              							 params: {
              								"ValueListName":poParamVal,
              							 },
              							 success: function (response) {
              								 var response1 = Ext.decode(response.responseText);
              								 Ext.Msg.alert("Info",response1.message);
              								 poStore.load();
              							 },
              							 failure: function (response) {
              								//var response1 = Ext.decode(response.responseText);
             								 //Ext.Msg.alert("Info",response1.message);
             								 //poStore.load();
              							 }
              						 });
              					 }
    	                	 	},
    	                	 disabled: true
    	                 },

    	                 /*{
    	                	 xtype :'combo',
    	                	 fieldLabel: 'Insert Empty Row',
    	                	 name:'InsertRow',
    	                	 id: 'InsertRowID',
    	                	 allowBlank:false,
    	                	 editable: false,
    	                	 displayField:'displayName',
    	                	 valueField:'id',
    	                	 store: CreateInsertRowStore(),
    	                	 listeners: {
    	                		 'select': function(combo, value){
    	                	
    	                			 var sm = gridPo.getSelectionModel();
        	                		 rowEditing.cancelEdit();
        	                		 
        	                		 var rs = sm.getSelection();													
        	                		 if (!rs.length) {
        	            				 Ext.Msg.alert('Info', 'No PO is Selected');
        	            				 return;
        	            			 }
        	                		 
        	                		 var tqParamVal = true;

                   					 for(var i=0; i<rs.length; i++)
                   					 {
                   						 if((i+1) != rs.length){
                   							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
                   								 tqParamVal=false;
        	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To insert new row condition.</font>");
                   							 }
                   						 }else{
                   							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
                   								 tqParamVal=false;	  
        	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To insert new row condition.</font>");
                   							 }
                   						 }
                   					 }

                   					 if(tqParamVal){ 
     
        	                		 
        	                		 //rowEditing.cancelEdit();
        	                		 componentListStore.load();
        	                		 inputType = null;
        	                		 Po_oprStore.load();
        	                		 RoprStore.load();
        	                		 Po_oprStore.clearFilter();
        	                		 Po_oprStore.filter(function(r) {
        	                			 var value = r.get('oprType');
        	                			 return (value == 'R' || value == 'S');
        	                		 });
        	                		 RoprStore.clearFilter();
        	                		 RoprStore.filter("poFlag",'Y');
        	                		 // Create a model instance
        	                		        	                			
        	                		 Ext.Ajax.request({
        	                			 url : 'payoutcondition/insertNewEmptyRowPo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
        	                			 method: 'POST',
        	                			 params: {
        	                				 "compId" : rs[0].data.compId,
               								 "condId" : rs[0].data.condId,
               								 "condRowId" : rs[0].data.condRowId,
               								 "insertEmptyRowType" : combo.getValue(),
        	                			 },
        	                			 success: function (response) {
        	                				 var r = null;
        	                				 //	Ext.Msg.alert("Info","Update PO");
        	                				 poStore.load({
        	                					 callback: function(records, operation, success) {
        	                						 if (success == true) {
        	                							 if(poStore.data.items[0])
        	                							 {
        	                								 r = Ext.create('Po', {
        	                									 compId: poStore.data.items[0].data.compId,
        	                									 condId: poStore.data.items[0].data.condId,
        	                									 condRowId: poStore.data.items[0].data.condRowId,
        	                									 value: poStore.data.items[0].data.value,
        	                									 inputType:poStore.data.items[0].data.inputType,
        	                									 inputParameter:poStore.data.items[0].data.inputParameter,
        	                									 oprName:poStore.data.items[0].data.oprName,
        	                									 valueType: poStore.data.items[0].data.valueType,
        	                									 Lopr: poStore.data.items[0].data.loprName,
        	                									 GrossNet : poStore.data.items[0].data.grossNet,
        	                									 Amount:poStore.data.items[0].data.amount,
        	                									 Unit:poStore.data.items[0].data.unitName,
        	                									 Pay:poStore.data.items[0].data.paymentVariable,
        	                									 OverAch:poStore.data.items[0].data.overAch,
        	                									 UnderAch:poStore.data.items[0].data.underAch,
        	                									 active: true
        	                								 });
        	                							 }
        	                							 if(r==null)
        	                							 {
        	                								 poStore.insert(0, r);
        	                								 rowEditing.startEdit(0, 0);
        	                							 }
        	                						 }

        	                					 }
        	                				 });
        	                				 componentListStorePo.load();
        	                			 },

        	                			 failure: function (response) {
        	                			 }
        	                		 });
        	                	 }
        	                	 
    	                			 
    	                		 }
    	                	 },
    	                	 triggerAction:'all'
    	                 },
*/
    	                 {
    	                	 itemId: 'InsertRowPo',
    	                	 text: 'InsertLastRow',
    	                	 iconCls: 'employee-add',
    	                	 handler : function() {

    	                		 var sm = gridPo.getSelectionModel();
    	                		 rowEditing.cancelEdit();

    	                		 
    	                		 var rs = sm.getSelection();													
    	                		 if (!rs.length) {
    	            				 Ext.Msg.alert('Info', 'No PO is Selected');
    	            				 return;
    	            			 }
    	                		 
    	                		 var tqParamVal = true;

               					 for(var i=0; i<rs.length; i++)
               					 {
               						 if((i+1) != rs.length){
               							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
               								 tqParamVal=false;
    	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To insert new row condition.</font>");
               							 }
               						 }else{
               							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
               								 tqParamVal=false;	  
    	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To insert new row condition.</font>");
               							 }
               						 }
               					 }

               					 if(tqParamVal){ 
    	                		 //rowEditing.cancelEdit();
    	                		 componentListStore.load();
    	                		 inputType = null;
    	                		 Po_oprStore.load();
    	                		 RoprStore.load();
    	                		 Po_oprStore.clearFilter();
    	                		 Po_oprStore.filter(function(r) {
    	                			 var value = r.get('oprType');
    	                			 return (value == 'R' || value == 'S');
    	                		 });
    	                		 RoprStore.clearFilter();
    	                		 RoprStore.filter("poFlag",'Y');
    	                		 // Create a model instance

    	                		 
    	                		 Ext.Ajax.request({
    	                			 url : 'payoutcondition/insertNewEmptyRowPo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    	                			 method: 'POST',
    	                			 params: {
    	                				 "compId" : rs[0].data.compId,
           								 "condId" : rs[0].data.condId,
           								"insertEmptyRowType" : 0 ,
    	                			 },
    	                			 success: function (response) {
    	                				 var r = null;
    	                				 //	Ext.Msg.alert("Info","Update PO");
    	                				 poStore.load({
    	                					 callback: function(records, operation, success) {
    	                						 if (success == true) {
    	                							 if(poStore.data.items[0])
    	                							 {
    	                								 r = Ext.create('Po', {
    	                									 compId: poStore.data.items[0].data.compId,
    	                									 condId: poStore.data.items[0].data.condId,
    	                									 condRowId: poStore.data.items[0].data.condRowId,
    	                									 value: poStore.data.items[0].data.value,
    	                									 inputType:poStore.data.items[0].data.inputType,
    	                									 inputParameter:poStore.data.items[0].data.inputParameter,
    	                									 oprName:poStore.data.items[0].data.oprName,
    	                									 valueType: poStore.data.items[0].data.valueType,
    	                									 Lopr: poStore.data.items[0].data.loprName,
    	                									 GrossNet : poStore.data.items[0].data.grossNet,
    	                									 Amount:poStore.data.items[0].data.amount,
    	                									 Unit:poStore.data.items[0].data.unitName,
    	                									 Pay:poStore.data.items[0].data.paymentVariable,
    	                									 OverAch:poStore.data.items[0].data.overAch,
    	                									 UnderAch:poStore.data.items[0].data.underAch,
    	                									 active: true
    	                								 });
    	                							 }
    	                							 if(r==null)
    	                							 {
    	                								 poStore.insert(0, r);
    	                								 rowEditing.startEdit(0, 0);
    	                							 }
    	                						 }

    	                					 }
    	                				 });
    	                				 componentListStorePo.load();
    	                			 },

    	                			 failure: function (response) {
    	                			 }
    	                		 });
    	                	 }
    	                	 }
    	                 },
    	                 
    	                 {
    	                	 itemId: 'InsertNextRowPo',
    	                	 text: 'InsertNextRow',
    	                	 iconCls: 'employee-add',
    	                	 handler : function() {

    	                		 var sm = gridPo.getSelectionModel();
    	                		 rowEditing.cancelEdit();

    	                		 
    	                		 var rs = sm.getSelection();													
    	                		 if (!rs.length) {
    	            				 Ext.Msg.alert('Info', 'No PO is Selected');
    	            				 return;
    	            			 }
    	                		 
    	                		 var tqParamVal = true;

               					 for(var i=0; i<rs.length; i++)
               					 {
               						 if((i+1) != rs.length){
               							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
               								 tqParamVal=false;
    	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To insert new row condition.</font>");
               							 }
               						 }else{
               							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
               								 tqParamVal=false;	  
    	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To insert new row condition.</font>");
               							 }
               						 }
               					 }

               					 if(tqParamVal){ 
 
    	                		 
    	                		 //rowEditing.cancelEdit();
    	                		 componentListStore.load();
    	                		 inputType = null;
    	                		 Po_oprStore.load();
    	                		 RoprStore.load();
    	                		 Po_oprStore.clearFilter();
    	                		 Po_oprStore.filter(function(r) {
    	                			 var value = r.get('oprType');
    	                			 return (value == 'R' || value == 'S');
    	                		 });
    	                		 RoprStore.clearFilter();
    	                		 RoprStore.filter("poFlag",'Y');
    	                		 // Create a model instance

    	                		 
    	                		 Ext.Ajax.request({
    	                			 url : 'payoutcondition/insertNewEmptyRowPo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    	                			 method: 'POST',
    	                			 params: {
    	                				 "compId" : rs[0].data.compId,
           								 "condId" : rs[0].data.condId,
           								 "condRowId" : rs[0].data.condRowId,
           								"insertEmptyRowType" : 1,
    	                			 },
    	                			 success: function (response) {
    	                				 var r = null;
    	                				 //	Ext.Msg.alert("Info","Update PO");
    	                				 poStore.load({
    	                					 callback: function(records, operation, success) {
    	                						 if (success == true) {
    	                							 if(poStore.data.items[0])
    	                							 {
    	                								 r = Ext.create('Po', {
    	                									 compId: poStore.data.items[0].data.compId,
    	                									 condId: poStore.data.items[0].data.condId,
    	                									 condRowId: poStore.data.items[0].data.condRowId,
    	                									 value: poStore.data.items[0].data.value,
    	                									 inputType:poStore.data.items[0].data.inputType,
    	                									 inputParameter:poStore.data.items[0].data.inputParameter,
    	                									 oprName:poStore.data.items[0].data.oprName,
    	                									 valueType: poStore.data.items[0].data.valueType,
    	                									 Lopr: poStore.data.items[0].data.loprName,
    	                									 GrossNet : poStore.data.items[0].data.grossNet,
    	                									 Amount:poStore.data.items[0].data.amount,
    	                									 Unit:poStore.data.items[0].data.unitName,
    	                									 Pay:poStore.data.items[0].data.paymentVariable,
    	                									 OverAch:poStore.data.items[0].data.overAch,
    	                									 UnderAch:poStore.data.items[0].data.underAch,
    	                									 active: true
    	                								 });
    	                							 }
    	                							 if(r==null)
    	                							 {
    	                								 poStore.insert(0, r);
    	                								 rowEditing.startEdit(0, 0);
    	                							 }
    	                						 }

    	                					 }
    	                				 });
    	                				 componentListStorePo.load();
    	                			 },

    	                			 failure: function (response) {
    	                			 }
    	                		 });
    	                	 }
    	                	 }
    	                 },
    	                 {
    	                	 itemId: 'InsertPreviousRowPo',
    	                	 text: 'InsertPrevRow',
    	                	 iconCls: 'employee-add',
    	                	 handler : function() {

    	                		 var sm = gridPo.getSelectionModel();
    	                		 rowEditing.cancelEdit();

    	                		 
    	                		 var rs = sm.getSelection();													
    	                		 if (!rs.length) {
    	            				 Ext.Msg.alert('Info', 'No PO is Selected');
    	            				 return;
    	            			 }
    	                		 
    	                		 var tqParamVal = true;

               					 for(var i=0; i<rs.length; i++)
               					 {
               						 if((i+1) != rs.length){
               							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
               								 tqParamVal=false;
    	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To insert new row condition.</font>");
               							 }
               						 }else{
               							 if(rs[i].data.compId != rs[0].data.compId || rs[i].data.condId != rs[0].data.condId){
               								 tqParamVal=false;	  
    	            							 Ext.Msg.alert("Warning","<font color='red'>Please select only one condition at a time. To insert new row condition.</font>");
               							 }
               						 }
               					 }

               					 if(tqParamVal){ 
 
    	                		 
    	                		 //rowEditing.cancelEdit();
    	                		 componentListStore.load();
    	                		 inputType = null;
    	                		 Po_oprStore.load();
    	                		 RoprStore.load();
    	                		 Po_oprStore.clearFilter();
    	                		 Po_oprStore.filter(function(r) {
    	                			 var value = r.get('oprType');
    	                			 return (value == 'R' || value == 'S');
    	                		 });
    	                		 RoprStore.clearFilter();
    	                		 RoprStore.filter("poFlag",'Y');
    	                		 // Create a model instance

    	                		 
    	                		 Ext.Ajax.request({
    	                			 url : 'payoutcondition/insertNewEmptyRowPo.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    	                			 method: 'POST',
    	                			 params: {
    	                				 "compId" : rs[0].data.compId,
           								 "condId" : rs[0].data.condId,
           								 "condRowId" : rs[0].data.condRowId,
           								"insertEmptyRowType" : 2,
    	                			 },
    	                			 success: function (response) {
    	                				 var r = null;
    	                				 //	Ext.Msg.alert("Info","Update PO");
    	                				 poStore.load({
    	                					 callback: function(records, operation, success) {
    	                						 if (success == true) {
    	                							 if(poStore.data.items[0])
    	                							 {
    	                								 r = Ext.create('Po', {
    	                									 compId: poStore.data.items[0].data.compId,
    	                									 condId: poStore.data.items[0].data.condId,
    	                									 condRowId: poStore.data.items[0].data.condRowId,
    	                									 value: poStore.data.items[0].data.value,
    	                									 inputType:poStore.data.items[0].data.inputType,
    	                									 inputParameter:poStore.data.items[0].data.inputParameter,
    	                									 oprName:poStore.data.items[0].data.oprName,
    	                									 valueType: poStore.data.items[0].data.valueType,
    	                									 Lopr: poStore.data.items[0].data.loprName,
    	                									 GrossNet : poStore.data.items[0].data.grossNet,
    	                									 Amount:poStore.data.items[0].data.amount,
    	                									 Unit:poStore.data.items[0].data.unitName,
    	                									 Pay:poStore.data.items[0].data.paymentVariable,
    	                									 OverAch:poStore.data.items[0].data.overAch,
    	                									 UnderAch:poStore.data.items[0].data.underAch,
    	                									 active: true
    	                								 });
    	                							 }
    	                							 if(r==null)
    	                							 {
    	                								 poStore.insert(0, r);
    	                								 rowEditing.startEdit(0, 0);
    	                							 }
    	                						 }

    	                					 }
    	                				 });
    	                				 componentListStorePo.load();
    	                			 },

    	                			 failure: function (response) {
    	                			 }
    	                		 });
    	                	 }
    	                	 }
    	                 },
    	                 
    	                 ],

    	                 plugins: [rowEditing],
    	                 listeners: {
    	                	 'selectionchange': function(view, records) {
    	                		 gridPo.down('#removePo').setDisabled(!records.length);
    	                		 gridPo.down('#copyPo').setDisabled(!records.length);
	                			 gridPo.down('#InsertRowPo').setDisabled(!records.length);
	                			 gridPo.down('#copyMultiRowsPo').setDisabled(!records.length);
	                			 gridPo.down('#InsertNextRowPo').setDisabled(!records.length);
	                			 gridPo.down('#InsertPreviousRowPo').setDisabled(!records.length);
    	                	 },


    	                	 itemdblclick: function(dv, record, item, index, e) {
    	                		 //console.log(record);
    	                		 compIdPo = record.data.compId;
    	                		 var oprFilter = null;

    	                		 componentListStore.load();
    	                		 inputTypeStorePO.load();
    	                		 RoprStore.load();
    	                		 unitStore.load();
    	                		 RoprStore.clearFilter();
    	                		 RoprStore.filter("poFlag",'Y');

    	                		 rowEditing.editor.form.findField("startDate").enable();
    	                		 rowEditing.editor.form.findField("endDate").enable();

    	                		 if(record.data.endDate!=null)
    	                			 rowEditing.editor.form.findField("endDate").enable();
    	                		 if(record.data.grossNet!=null)
    	                			 rowEditing.editor.form.findField("grossNet").enable();


    	                		 poFilterVariables.load({
    	                			 callback: function(records, operation, success) {
    	                				 if (success == true) {

    	                					 if(record.data.inputParameter!=null)
    	                					 {
    	                						 rowEditing.editor.form.findField('inputParameter').enable();
    	                						 //rowEditing.editor.form.findField('inputParameter').setValue(poFilterVariables.findRecord('variableName',record.data.inputParameter));

    	                						 if(record.data.inputType=='Variable')
    	                						 {
    	                							 //alert('Varaiable');
    	                							 poFilterVariables.clearFilter();
    	                							 poFilterVariables.filter('poVarFlag','Y');
    	                							 poFilterVariables.filter('compId',record.data.compId);

    	                						 }
    	                						 else
    	                						 {
    	                							 //alert('Varaiable_Cond');
    	                							 var inputTypeId = inputTypeStorePO.findRecord('inputType',record.data.inputType);
    	                							 poFilterVariables.clearFilter();
    	                							 poFilterVariables.filter('poVarFlag','N');

    	                							 if(inputTypeId!=null)
    	                								 poFilterVariables.filter('poAttrCatg',inputTypeId.data.inputTypeId);

    	                							 var payTo = componentListStore.findRecord('compId',record.data.compId);

    	                							 if(payTo!=null)
    	                								 poFilterVariables.filter('poAttrType',payTo.data.payTo);
    	                						 }
    	                					 }


    	                					 Po_oprStore.load({
    	                						 callback: function(records, operation, success) {
    	                							 if (success == true) {

    	                								 if(record.data.oprName!=null)
    	                								 {
    	                									 rowEditing.editor.form.findField('oprName').enable();
    	                									 rowEditing.editor.form.findField('oprName').setValue(Po_oprStore.findRecord('oprName',record.data.oprName));
    	                									 var temp =  poFilterVariables.findRecord('variableName', record.data.inputParameter);

    	                									 if(temp!=null && oprFilter == null)
    	                									 {
    	                										 if(temp.data.poVarFlag=='Y')
    	                										 {
    	                											 Po_oprStore.clearFilter();
    	                											 Po_oprStore.filter(function(r) {
    	                												 var value = r.get('oprType');
    	                												 return (value == 'R' || value == 'S');
    	                											 });

    	                										 }
    	                										 else
    	                										 {

    	                											 var	oprFilterPo =   poFilterVariables.findRecord('variableName',record.data.inputParameter);

    	                											 oprFilterPo = oprFilterPo.data.oprType;

    	                											 Po_oprStore.clearFilter();

    	                											 if(oprFilterPo=='D')
    	                											 {
    	                												 Po_oprStore.filter('dataFlag','Y');
    	                											 }
    	                											 if(oprFilterPo=='N')
    	                											 {
    	                												 Po_oprStore.filter('numberFlag','Y');
    	                											 }
    	                											 if(oprFilterPo=='S')
    	                											 {
    	                												 Po_oprStore.filter('stringFlag','Y');
    	                											 }
    	                										 }
    	                										 oprFilter = 'Yes';
    	                									 }
    	                								 }
    	                							 }
    	                						 }
    	                					 });
    	                				 }
    	                			 }
    	                		 });


    	                		 /* if(record.data.inputParameter!=null)
				rowEditing.editor.form.findField("inputParameter").enable();
    	                		  */

    	                		 if(record.data.inputType!=null)
    	                		 {
    	                			 inputType = 'Yes';
    	                			 rowEditing.editor.form.findField("inputType").enable();

    	                		 }
    	                		 if(record.data.loprName!=null)
    	                			 rowEditing.editor.form.findField("loprName").enable();

    	                		 if(record.data.loprName=='And' || record.data.loprName=='OR')
    	                		 {
    	                			 rowEditing.editor.form.findField('grossNet').disable();
    	                			 rowEditing.editor.form.findField('unitName').disable();
    	                			 rowEditing.editor.form.findField('amount').disable();
    	                			 rowEditing.editor.form.findField('paymentVariable').disable();
    	                			 rowEditing.editor.form.findField('overAch').disable();
    	                			 rowEditing.editor.form.findField('underAch').disable();
    	                		 }
    	                		 else
    	                		 {							  	
    	                			 rowEditing.editor.form.findField('grossNet').enable();
    	                			 rowEditing.editor.form.findField('unitName').enable();
    	                			 rowEditing.editor.form.findField('amount').enable();
    	                			 rowEditing.editor.form.findField('paymentVariable').enable();
    	                			 rowEditing.editor.form.findField('overAch').enable();
    	                			 rowEditing.editor.form.findField('underAch').enable();
    	                		 }

    	                		 /* if(record.data.oprName!=null)
				rowEditing.editor.form.findField("oprName").enable();
    	                		  */
    	                		 if(record.data.overAch!=0)
    	                			 rowEditing.editor.form.findField("overAch").enable();
    	                		 if(record.data.startDate!=null)
    	                			 rowEditing.editor.form.findField("startDate").enable();
    	                		 if(record.data.underAch!=0)
    	                			 rowEditing.editor.form.findField("underAch").enable();
    	                		 if(record.data.amount!=0)
    	                			 rowEditing.editor.form.findField("amount").enable();


    	                		 poFilterVariablesPO.load({
    	                			 callback: function(records, operation, success) {
    	                				 if (success == true) {
    	                					 if(record.data.variableName != null){
    	                						 poFilterVariablesPO.clearFilter();
	        	                				 poFilterVariablesPO.filter('poVarFlag','Y');
	        	                				 if(compIdPo!=null)
	        	                					 poFilterVariablesPO.filter('compId',compIdPo);
    	                					 }
    	                				 }
    	                			 }
                				 });

    	                		 //unitName
    	                		 if(record.data.unitName!=null)
    	                		 {
    	                			 rowEditing.editor.form.findField("unitName").enable();

    	                			 if((record.data.unitName=='Per Event')||(record.data.unitName=='Percentage'))
    	                			 {
    	                				 poFilterVariables.clearFilter();
    	                				 poFilterVariables.filter('poVarFlag','Y');
    	                				 if(compIdPo!=null)
    	                					 poFilterVariables.filter('compId',compIdPo);

    	                				 rowEditing.editor.form.findField("paymentVariable").enable();
    	                				 rowEditing.editor.form.findField("paymentVariable").allowBlank = false;
    	                			 }
    	                			 else
    	                			 {
    	                				 if(inputType =='Yes')
    	                					 rowEditing.editor.form.findField("paymentVariable").disable();
    	                				 else
    	                				 {
    	                					 poFilterVariables.clearFilter();
    	                					 poFilterVariables.filter('poVarFlag','Y');
    	                					 if(compIdPo!=null)
    	                						 poFilterVariables.filter('compId',compIdPo);

    	                					 rowEditing.editor.form.findField("paymentVariable").enable();
    	                					 rowEditing.editor.form.findField("paymentVariable").allowBlank = true;
    	                				 }
    	                			 }
    	                		 }

    	                		 if(record.data.paymentVariable!=null)
    	                			 rowEditing.editor.form.findField("paymentVariable").enable();

    	                		 if(record.data.value!=null)
    	                			 rowEditing.editor.form.findField("value").enable();
    	                		 if(record.data.valueType!=null)
    	                			 rowEditing.editor.form.findField("valueType").enable();
    	                	 }		
    	                 }
    });


	var searchGrid = 0;
	var viewschemeGrid = 0;
	var submitchemeGrid = 0;
	var reportGrid = 0;
	var payoutApprovalGrid = 0;
	var executeSchemeGrid = 0;
	var sentToVtopGrid = 0;
	//var stmGenGrid = 0;
	
	var payDataList = Ext.create('Ext.form.Panel', {
		 	border: false,	
		   items:[{
			 		xtype:'fieldset',
		     		layout: 'anchor',
		     		border:false,
		     		height:500,
		     		autoscroll:true,
		     		defaults: {
		     		anchor: '100%'
		     		},
		     		items :[
		     			{
		             		html: "<div id='transPayoutData'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			},{
		             		html: "<div id='transPayoutSubData'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			}
		             	
		     		]}
		     	
		   ]});
	
	
	var universeDataList = Ext.create('Ext.form.Panel', {
		 	//url: 'transData/getTransSubUniverseDataSearch.action',
		 	border: false,	
		   items:[{
			   
		     		xtype:'fieldset',
		     		layout: 'anchor',
		     		border:false,
		     		height:500,
		     		autoscroll:true,
		     		defaults: {
		     		anchor: '100%'
		     		},
		     		items :[
		     			{
		             		html: "<div id='universelist'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			},{
		             		html: "<div id='universeSublist'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			}
		             	
		     		]}
		     	
		   ]});
	

	var paymentDataList = Ext.create('Ext.form.Panel', {
		 //	url: addSchemeUrl,
		 	border: false,	
		   items:[{
			   
		     		xtype:'fieldset',
		     		layout: 'anchor',
		     		border:false,
		     		height:500,
		     		autoscroll:true,
		     		defaults: {
		     		anchor: '100%'
		     		},
		     		items :[
		     			{
		             		html: "<div id='paylist'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			},{
		             		html: "<div id='paylist2'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			}
		             	
		     		]}
		     	
		   ]});

	var schemeDataList = Ext.create('Ext.form.Panel', {
		 //	url: addSchemeUrl,
		 	border: false,	
		   items:[{
			   
		     		xtype:'fieldset',
		     		layout: 'anchor',
		     		border:false,
		     		height:500,
		     		autoscroll:true,
		     		defaults: {
		     		anchor: '100%'
		     		},
		     		items :[
		     			{
		             		html: "<div id='transData'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			},{
		             		html: "<div id='transSubData'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			}
		             	
		     		]}
		     	
		   ]});

	

	
/*	var stmGenList = Ext.create('Ext.form.Panel', {
		 	border: false,
		   items:[{
			   xtype:'fieldset',
	     		layout: 'anchor',
	     		border:false,
	     		height:600,
	     		autoscroll:true,
	     		defaults: {
	     		anchor: '100%'
	     		},
		     		items :[
		     		    {
		             		html: "<div id='stmGen'></div>",
		             		xtype: "fieldset",
							//layout: 'fit',
		             		border:false,
		             		autoscroll:true
		     			}
		     		]}
		   ]});
*/
		   
		   
	var viewStmtList = Ext.create('Ext.form.Panel', {
		 	border: false,	
		   items:[{
			 		xtype:'fieldset',
		     		layout: 'anchor',
		     		border:false,
		     		height:600,
		     		autoscroll:true,
		     		defaults: {
		     		anchor: '100%'
		     		},
		     		items :[
		     			{
		             		html: "<div id='viewStmtgen'></div>",
		             		xtype: "fieldset",
		             		border:false,
		             		autoscroll:true             		
		     			}
		     		]}
		   ]});
		

	var ReqStmtList = Ext.create('Ext.form.Panel', {
	 	border: false,	
	   items:[{
		 		xtype:'fieldset',
	     		layout: 'anchor',
	     		border:false,
	     		height:600,
	     		autoscroll:true,
	     		defaults: {
	     		anchor: '100%'
	     		},
	     		items :[
	     			{
	             		html: "<div id='StmtgenReq'></div>",
	             		xtype: "fieldset",
	             		border:false,
	             		autoscroll:true             		
	     			},
	        	        
	     			{
	             		html: "<div id='StmtgenSubReq'></div>",
	             		xtype: "fieldset",
	             		border:false,
	             		autoscroll:true             		
	     			}	
	     				
	     				
	     			
	     		]}
	   ]});
	
	var tempList = Ext.create('Ext.form.Panel', {
		border: false,
		items:[{
			xtype:'fieldset',
			layout: 'anchor',
			border:false,
			height:600,
			autoscroll:true,
			defaults: {
				anchor: '100%'
			},
			items :[
			        {
			        	html: "<div id='templ'></div>",
			        	xtype: "fieldset",
			        	border:false,
			        	autoscroll:true
			        }
			        ]}
		]});

	var hieraList = Ext.create('Ext.form.Panel', {
		border: false,
		items:[{
			xtype:'fieldset',
			layout: 'anchor',
			border:false,
			height:600,
			autoscroll:true,
			defaults: {
				anchor: '100%'
			},
			items :[
			        {
			        	html: "<div id='hiera'></div>",
			        	xtype: "fieldset",
			        	border:false,
			        	autoscroll:true
			        }
			        ]}
		]});
	
	
	var hieraList1 = Ext.create('Ext.form.Panel', {
		border: false,
		items:[{
			xtype:'fieldset',
			layout: 'anchor',
			border:false,
			height:600,
			autoscroll:true,
			defaults: {
				anchor: '100%'
			},
			items :[
			        {
			        	html: "<div id='hieraz'></div>",
			        	xtype: "fieldset",
			        	border:false,
			        	autoscroll:true
			        }
			        ]}
		]});

	var scmDataAnalysisList = Ext.create('Ext.form.Panel', {
		border: false,
		items:[{
			xtype:'fieldset',
			layout: 'anchor',
			border:false,
			height:600,
			autoscroll:true,
			defaults: {
				anchor: '100%'
			},
			items :[
			        {
			        	html: "<div id='scmDataAnaly'></div>",
			        	xtype: "fieldset",
			        	border:false,
			        	autoscroll:true
			        }
			        ]}
		]});
	
	var holdPayList = Ext.create('Ext.form.Panel', {
	 	border: false,
	   items:[{
		   xtype:'fieldset',
     		layout: 'anchor',
     		border:false,
     		height:600,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     		},
	     		items :[
	     		    {
	             		html: "<div id='holdPay'></div>",
	             		xtype: "fieldset",
						//layout: 'fit',
	             		border:false,
	             		autoscroll:true
	     			}
	     		]}
	   ]});

	var relePayList = Ext.create('Ext.form.Panel', {
	 	border: false,
	   items:[{
		   xtype:'fieldset',
     		layout: 'anchor',
     		border:false,
     		height:600,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%'
     		},
	     		items :[
	     		    {
	             		html: "<div id='relePay'></div>",
	             		xtype: "fieldset",
	             		border:false,
	             		autoscroll:true
	     			}
	     		]}
	   ]});
	
	function getBulkRejRecordsList(bulkForm)
	{
			bulkForm.submit({
				waitMsg : 'Loading...',
				url: 'bulkUpload/getRejectedFileList.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
				//enctype : 'multipart/form-data',
				//headers: {'Content-Type':'multipart/form-data;'},
				method : 'POST',
				success: function(form,action) {
					Ext.Msg.alert('Info', action.result.outputMsg);
				},
				failure:function(form,action)
				{
					Ext.Msg.alert('Warning', '<font color="red">'+action.result.outputMsg+'</font>');
				}
			});	
		//}
		/*else
		{
			Ext.Msg.alert('Error','Please provide valid input file');
		}*/
	}
	
	
/*	var bulkFailList=Ext.create('Ext.grid.Panel', {
		//renderTo: document.body,
		store: bulkInvalidRecords,
		width: 580,
		height:380,
		title: 'File Upload Details',
		//id:'uploadDataGrid',
		columns: [
		         
		          {
		        	  text: 'No.',
		        	  dataIndex: 'seqNoIndex',
		        	  width:30
		          },
		          {
		        	  text: 'Uploaded File Name',
		        	  dataIndex: 'fileName',
		        	  width:300
		          },
		          {
		        	  text: 'Uploaded on',
		        	  dataIndex: 'loadDateTime',
		        	  width:180
		          },
		          {
		        	  header:'Download',
		        	  dataIndeex:'downloadFile',
		        	  name:'downloadFile',
		        	  width:70,
		        	  flex: 1,
	                renderer: function (v, m, r) {
	                		var id = Ext.id();
	                		Ext.defer(function () {
	                			Ext.widget('image', {
	                				renderTo: id,
	                				name: 'download',
	                				src : 'resources/images/downloadRejFile.JPG',
	                				listeners : {
	                					afterrender: function (me) {
	                						me.getEl().on('click', function() {
	                							///alert('say hai');
	                						});
	                						}
	                				}
	                			});},700);
	                		return Ext.String.format('<div id="{0}"></div>', id);
	                	}
		          }		          ]
	});
*/
	
	
	var bulkFailList=Ext.create('Ext.grid.Panel', {
		//renderTo: document.body,
		store: bulkInvalidRecords,
		width: 1150,
		height:500,
		//title: 'File Upload Details',
		alias: 'widget.bulkFailList',
		stripeRows: true,
		autoScroll: true,
		autoWidth:true,
		forceFit: true,
		viewConfig:{forceFit:true},
		//autoExpandColumn: 'Scheme Name',
		//  height:550,
		//bodyStyle:'padding:2px 0px',
		// bodyStyle:'padding:0px 0px',
		hidden: false,
		loadMask: true,
		resizable: true,
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		//id:'uploadDataGrid',
		columns: [
		          {
		        	  header: 'Uploaded File Name',
		        	  dataIndex: 'fileName',
		        	  name:'fileName',
		        	  width:300,
		        	  itemId:'fileName',
		        	  displayField:'fileName',
	        		  valueField:'fileName',
		        	 // id:'fileNameRejListId'
		          },
		          {
		        	  header: 'Uploaded on',
		        	  dataIndex: 'loadDateTime',
		        	  name:'loadDateTime',
		        	  width:150,
		        	  itemId:'loadDateTime',
		          },
		          {
		        	  header:'Uploaded By',
		        	  dataIndex:'userName',
		        	  name:'userName',
		        	  width:250
		          },
		          {
		        	  header:'Circle',
		        	  dataIndex:'circleCode',
		        	  name:'circleCode',
		        	  width:50
		          },
		          {
		        	  header:'Error Description',
		        	  dataIndex:'errorDesc',
		        	  name:'errorDesc',
		        	  width:300
		        	  
		          },
		          {
		        	  header:'Download',
		        	  dataIndeex:'downloadFile',
		        	  name:'downloadFile',
		        	  width:70,
		        	  flex: 1,
	                  renderer: function (v,m,r) {
	                	  	var unqFileName = null;
	                	  	var orgiFileName = null; 
	        				//  alert(temp);
	                		var id = Ext.id();
	                		Ext.defer(function () {
	                			Ext.widget('image', {
	                				renderTo: id,
	                				name: 'download',
	                				src : 'resources/images/downloadRejFile.JPG',
	                				listeners : {
	                					afterrender: function (me) {
	                						me.getEl().on('click', function() {
	                						var temp=bulkInvalidRecords.findRecord('fileName',r.data.fileName);
	                						orgiFileName = temp.data.fileName;
	                						unqFileName =  temp.data.unquieFileName;
	                							Ext.Msg.confirm('Download Records', 
                										'You want to download records?', 
                										function (button) {
                									if (button == 'yes') {
                										var urlParam = './csv/downloadRejRecords.action?'+'fileName='+orgiFileName+'&uniqueFileName='+unqFileName;
                										window.open(urlParam,'_blank');
                									}
                								});
	                							
	                							///alert('say hai');
	                						});
	                						}
	                				}
	                			});},700);
	                		return Ext.String.format('<div id="{0}"></div>', id);
	                	}
		          }
		          
		          ]
	});


	
	

	var bulkPanel = Ext.create('Ext.form.Panel', {
		waitMsg : 'Loading...',
		enctype : 'multipart/form-data', 
		headers: {'Content-Type':'multipart/form-data;'},
		//title : 'Bulk Upload File',
		// id:'Bulk-Upload-File',
		border: false,
		width: '98%',
		bodyStyle:'padding:3px 0px',
	//	width:1120,
		items:[
		       {
		    	   xtype:'fieldset',
		    	   title: 'Bulk Upload File',
		    	   collapsible: true,
		    	   layout: 'anchor',
				   width: '100%',
		    	   items :[{
		    		   xtype: 'fileuploadfield',
		    		   id: 'fileUploadID',
		    		   name: 'fileUpload',
		    		   width:700,
		    		   emptyText: 'Select a document to upload...',
		    		   fieldLabel: 'File*',
		    		   allowBlank:false,
		    		   buttonText: 'Browse File',
		    		   listeners: {
		    			   'change':function(val){
		    				   var fileComp1 = val.getValue();
		    				   var fileCompare = fileComp1.match(/ENTITY-LIST/gi);
		    				   if(fileCompare != null){
		    					   var test = Ext.getCmp("schemeId");
		    					   test.setValue(null);
		    					   bulkSchemeStore.load({params:
		    					   {
		    						   fileUpload: Ext.getCmp("fileUploadID").getValue(),
		    					   }});
		    					   Ext.getCmp("schemeId").reset();
		    					   bulkComponentStore.load({params:
		    					   {
		    						   fileUpload: Ext.getCmp("fileUploadID").getValue(),
		    					   }});
		    					   Ext.getCmp("componentId").reset();
		    				   }else{
		    					   var test = Ext.getCmp("schemeId");
		    					   test.setValue(null);
		    					   Ext.getCmp("schemeId").reset();
		    					   Ext.getCmp("componentId").reset();
		    				   }
		    			   }
		    		   }
		    	   },
		    	   {
		    		   xtype :'combo',
		    		   fieldLabel: 'File Type*',
		    		   name:'fileTypeId',
		    		   displayField:'fileName',
		    		   valueField:'fileTypeId',
		    		   forceSelection: true,
		    		   allowBlank: false,
		    		   width:400,
		    		   editable: false,
		    		   store: bulkUploadFileStore(),
		    		   listeners: {
		    			   'select': function(combo, value){
		    				  // alert("file ::::: "+Ext.getCmp("fileUploadID").getValue());
		    				   if(combo.getValue()==4)
		    				   {
		    					   Ext.getCmp("schemeId").enable();
		    					   Ext.getCmp("componentId").enable();
		    				   }else{
		    					   Ext.getCmp("schemeId").disable();
		    					   Ext.getCmp("componentId").disable();
		    				   }
		    				   if(combo.getValue()==3)
	    					   {
	    					   Ext.getCmp("dateFieldPerfParam").enable();
	    					   }
	    				   else
	    					   {
	    					   Ext.getCmp("dateFieldPerfParam").disable();
	    					   }
		    			   }
		    		   },
		    		   triggerAction:'all'
		    	   },
		    	   {
						xtype :'combo',
						editable: false,
						width:400,
						allowBlank: false,
						fieldLabel: 'Scheme Name*',
						name:'schemeId',
						id : 'schemeId',
						disabled:true,
						autoLoad:false,
						reload:false,
						remoteFilter: true,
						displayField:'schemeName',
						valueField:'schemeId',
						store: bulkSchemeStore,
						listeners: {
							  'select': function(combo, value){
								  bulkComponentStore.clearFilter();
								  bulkComponentStore.filter("schemeId",combo.getValue());
								  Ext.getCmp("componentId").reset();
							  }
							 },
						//triggerAction:'all'
					},
					{
						xtype :'combo',
						editable: false,
						width:400,
						allowBlank: false,
						fieldLabel: 'Component Name*',
						name:'componentId',
						id:'componentId',
						disabled:true,
						displayField:'componentName',
						valueField:'componentId',
						store: bulkComponentStore,
						triggerAction:'all'
					},
					{
						xtype:'fieldset',
						layout:'column',
						border:false,
						//disabled:true, 
						id:'dateFieldPerfParam',
						items:[
						       {
						        	html: 'Update MSISDN whose HLR Unbar is between:',
						        	border:false,
						        	//disabled: true,
						        	name: 'idwe'
						        	//readOnly : true
						        },
						       {
						      xtype:'datefield',
						     // fieldLabel: 'Update MSISDN whose HLR Unbar is between:',
						      name: 'startDate',
						      allowBlank:false,
						      //name:'startDate'
						      emptyText:'StartDate',
						      id:'dateFieldPerfParamStartDate',
						      itemId:'dateFieldPerfParamStartDate',
						      vtype: 'daterange',
						      endDateField:'dateFieldPerfParamEndDate'
						},
						{ 
							  xtype:'datefield',
						      name: 'endDate',
						      allowBlank:false,
						      //name:'endDate'
						      emptyText:'EndDate',
						      id:'dateFieldPerfParamEndDate',
						      itemId:'dateFieldPerfParamEndDate',
						      vtype: 'daterange',
						      startDateField: 'dateFieldPerfParamStartDate'
						     
						}]
					
},
					
				{
		    	   xtype:'fieldset',
		    	   layout: 'column',
				   border : false,
				   bodyStyle:'padding:3px 2px',
		    	   defaults: {
					bodyStyle:'padding:3px 2px',
		    	   },
		    	   items :[
						{
			    	   xtype :'button',
					   text: 'Upload',
			    	   handler : function () { 
			    		   saveBulkFile(bulkPanel);
			    	   }
			       }
				]}
		    	   ]
		       }]
	});
	
	var bulkFormRecList = Ext.create('Ext.form.Panel', {
		waitMsg : 'Loading...',
		enctype : 'multipart/form-data', 
		headers: {'Content-Type':'multipart/form-data;'},
		//title : 'Bulk Upload File',
		// id:'Bulk-Upload-File',
		border: false,
		width: '98%',
		height:'70%',
		bodyStyle:'padding:3px 0px',
		items:[
		       {
		       	xtype:'fieldset',
		        items:
		        	[
{
	xtype:'fieldset',
	layout:'column',
	border:false,
	//disabled:true,
	//id:'dateFieldPerfParam',
	items:[{
	html:'File uploaded between*:',
	border:false
	},{
	      xtype:'datefield',
	      name: 'startDt',
	      allowBlank:false,
	      emptyText:'StartDate',
	      id:'startDtRej'
	},
	{ 
		  xtype:'datefield',
	      name: 'endDt',
	      allowBlank:false,
	      id:'endDtRej',
	      emptyText:'EndDate'
	},
	{
		xtype:'button',
		text:'Go',
		handler: function()
		{
			//getBulkRejRecordsList(bulkFormRecList);
			bulkInvalidRecords.removeAll();
			//getBulkRejRecordsList(bulkFormRecList);
			if(!(Ext.getCmp("startDtRej").getValue()) || !(Ext.getCmp("endDtRej").getValue()))
			{
			Ext.Msg.alert("Warning","<font color='red'>Please enter 'Start Date & End Date'</font>");
			return false;
			}
			//alert(Ext.Date.format(Ext.getCmp("startDtRej").getValue(),'d-M-y')+":"+Ext.Date.format(Ext.getCmp("endDtRej").getValue(),'d-M-y')+":"+Ext.getCmp("uploadTypeGroup").getValue());
			Ext.Ajax.request({
				dataType : 'json',
				contentType : 'application/json',
				url : 'bulkUpload/getRejectedFileList.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
				method: 'POST',
				params:{
					startDt:Ext.Date.format(Ext.getCmp("startDtRej").getValue(),'d-M-y'),
					endDt:Ext.Date.format(Ext.getCmp("endDtRej").getValue(),'d-M-y'),
					//uploadBulkFileType:Ext.getCmp("uploadTypeGroup").getValue(),
				},
				success: function(response,opts)
				{
					
					var jsonResp = Ext.decode(response.responseText).data;

					bulkInvalidRecords.loadRawData(jsonResp,true);
					
				}
			});
		}
		}]
},
/*{
	
xtype:'radiogroup',
fieldLabel:'Select \'Upload Type\'*:',
layout:'column',
id:'uploadTypeGroup',
items:
	[{boxLabel:'Performance Parameter',name:'uploadBulkFileType',inputValue:1,checked:true},{boxLabel:'Additional Attribute & Target',inputValue:2,name:'uploadBulkFileType'},{boxLabel:'Coverage List',inputValue:3,name:'uploadBulkFileType'},{boxLabel:'Manual Payout',inputValue:4,name:'uploadBulkFileType'}]

},
*/
{
layout:'column',
items:
	[bulkFailList]
}
 ]
		       }]});
	
	
	
	
	
	
	
	
	 bulkFormPanel=Ext.create('Ext.form.Panel', {layout: 'fit',
		id:'Create',
	 	border: false,
	 	enctype : 'multipart/form-data', 
		headers: {'Content-Type':'multipart/form-data;'},
		//title : 'Bulk Upload File',
		 id:'Bulk-Upload-File',
		border: false,
		width: '98%',
		bodyStyle:'padding:3px 0px',
	//	bodyStyle: 'padding:15px',
	//	bodyStyle:'padding:3px 0px',
	 	//id: 'my-panel',
	   items:[
	          
	       {
           xtype:'tabpanel',
		   layout:'fit',
		   collapsible: true,
			split: true,
		//	bodyStyle: 'padding:15px',
		   defaults:{
         //  	preventBodyReset: true
				layout:'fit',
           	},
           items:[
                  {
                  title:'Bulk Upload',
                  items:
                  [
                	  bulkPanel
                  ]
                  },
                  {
                  title:'Identify invalid records',
                  items:
                  [
                     bulkFormRecList
                   ] 	  
                  }
	             ]
	       }]
	});
	
	
	
	 formPanel = Ext.create('Ext.form.Panel', {
	 	url: addSchemeUrl,
		layout: 'fit',
		id:'Create',
	 	border: false,
	//	bodyStyle: 'padding:15px',
	//	bodyStyle:'padding:3px 0px',
	 	//id: 'my-panel',
		
	 
	 	
	   items:[
	          
	       {
           xtype:'tabpanel',
		   layout:'fit',
		   collapsible: true,
			split: true,
		//	bodyStyle: 'padding:15px',
           id: 'tablist',
		   defaults:{
         //  	preventBodyReset: true
				layout:'fit',
           	},
           items:[
               {
               title:'Scheme',
               items: [
                       	schemeForm
                       ]
               	
               },
               {
               title:'Component',
               id:'Component',
               
               items: [
                     compList
                      ]
               
           	
               },
           {
               title:'Region&Zone',
               items: [
                       regList
                      ]
           },

           {
               title:'Coverage',
               items: [
                  			covList
                       
                       ]
               
           	
           },
           {
               title:'Transaction Qualifications',
               items: [
                       tqList
                       ]
               
           	
           },
           {
               title:'Performance Aggregates',
               items: [
                       	 eaList
                       ]
           },
           
           {
               title:'Filter Aggregates',
               items: [
                       eaFilterList
                       ]
           },

           
           {
               title:'Payout Rules',
               items: [
                       gridPo
                       ]
               
           	
           }
           ],
           listeners: {
               'tabchange': function (tabPanel, tab) {
                   
                   
                   if(tab.title=='Component')
                   	{
                   	componentStoreGrid.load();
                   	if(compGridStatus==0)
                   		{
                   		
                   Ext.application({
               	    name  : 'Scheme',
               	    controllers: ['CompCon'],
              	      launch: function () {
               	    	  Ext.widget('CompList', {
               	          renderTo: 'complistForm'
               	        });
               	      }
               	    }
               	  );
                   compGridStatus=1;
              }
                   
             }
                   
                   if(tab.title=='Region&Zone')
               	{
                   	regZoneStore.load();
               	if(regGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['RegCon'],
          	      launch: function () {
           	    	  Ext.widget('RegList', {
           	          renderTo: 'reglist'
           	        });
           	      }
           	    }
           	  );
               regGridStatus=1;
               }
               
               	}
                   
                   if(tab.title=='Coverage')
               	{
                	   //coverageStore.load();
               	if(covGridStatus==0)
               		{
              
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['CovCon'],
          	      launch: function () {
           	    	  Ext.widget('CovList', {
           	          renderTo: 'covlist'
           	        });
           	      }
           	    }
           	  );
               covGridStatus=1;
               }
			   coverageStore.load({
					callback: function(records, operation, success) {
					if (success == true) {
				//	Ext.getCmp('addCoverage').setText('Add More');
					//console.log(Ext.getCmp('addCoverage'));
                  if(coverageStore.getCount()>0)
			   {
			  Ext.getCmp('addCoverage').setText('Add Coverage');
			//   Ext.getCmp('addCoverage').disable();
			   }
			   
			   else
			   {Ext.getCmp('addCoverage').enable();
			   Ext.getCmp('addCoverage').setText('Add Coverage');
			   //Ext.getCmp('addCoverage').enable();
               }

				  } else {
            // the store didn't load, deal with it
        }
    }
    // scope: this,
});

}
                   
                   if(tab.title=='Transaction Qualifications')
               	{
                	   tqStore.load();
               	if(tqGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['TqCon'],
          	      launch: function () {
           	    	  Ext.widget('TqList', {
           	          renderTo: 'tqlist'
           	        });
           	      }
           	    }
           	  );
               tqGridStatus=1;
               }
               
               	}
                   
                   if(tab.title=='Performance Aggregates')
               	{
                	   eaStore.load();
               	if(eaGridStatus==0)
               	{
               		console.log(tabPanel+ ' ' + tab.title);
               		Ext.application({
               			name  : 'Scheme',
               			controllers: ['EaCon'],
               			launch: function () {
               				Ext.widget('EaList', {
               					renderTo: 'ealist'
               				});
               			}
               		}
               		);
               		eaGridStatus=1;
               	}
               
               	}
                   
                   if(tab.title=='Filter Aggregates')
               	{
                	   eaFilterStore.load();
               	if(eaFilterGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['EaFilterCon'],
          	      launch: function () {
           	    	  Ext.widget('EaFilterList', {
           	          renderTo: 'eafilterlist'
           	        });
           	      }
           	    }
           	  );
               eaFilterGridStatus=1;
               }
               
               	}
                   
                   if(tab.title=='Payout Rules')
               	{
						valueTypeStorePO.load();
						componentListStorePo.load();
                	   poStore.load();
               	/*if(poGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['PoCon'],
          	      launch: function () {
           	    	  Ext.widget('PoList', {
           	          renderTo: 'polist'
           	        });
           	      }
           	    }
           	  );
               poGridStatus=1;
               }
               */
               	}
                   
                   if(tab.title=='PO_FILTER CONDITION')
               	{
                	   poFilterStore.load();
               	if(poFilterGridStatus==0)
               		{
               	console.log(tabPanel+ ' ' + tab.title);
               Ext.application({
           	    name  : 'Scheme',
           	    controllers: ['PoFilterCon'],
          	      launch: function () {
           	    	  Ext.widget('PoFilterList', {
           	          renderTo: 'pofilterlist'
           	        });
           	      }
           	    }
           	  );
               poFilterGridStatus=1;
               }
               
               	}
               }
           }
           	
           	
       }
	   
	   
	   
	   ]});

	   
	   	var transFormPanel = Ext.create('Ext.form.Panel', {
	 	//url: addSchemeUrl,
	//	id: 'transDataPanel',
	   		layout:'fit',
	 //	title: 'Tranaction Data',
	 	border: true,
	//	bodyStyle:'padding:3px 0px',
	 	id: 'Transaction-Data',
	 
	 	items:[
	          
	       {
           xtype:'tabpanel',
           id: 'tdTablist',
       		//width:1150,
			layout:'fit',
           defaults:{
         //  	preventBodyReset: true
           	},
           items:[
               {
               title:'Scheme Data',
               id:'schemeData',
               items: [
                       		schemeDataList
                       ]
               	
               },
               {
                   title:'Payout Data',
                   id:'payoutData',
                   items: [
                           payDataList
                           ]
               },
               {
               title:'Payment Data',
               id:'paymentData',
               
               items: [
                     paymentDataList
                      ]
               
           	
               },
           {
               title:'Transaction Data',
               id:'universeData',
               items: [
                       universeDataList
                      ]
           },

           
           ],
           listeners: {
        	   'tabchange': function (tabPanel, tab) {
        		   if(tab.title=='Scheme Data')
        		   {
        			   if(sdGridStatus==0)
        			   {
        				   Ext.application({
        					   name  : 'Scheme',
        					   controllers: ['TransDataCon'],
        					   launch: function () {
        						   Ext.widget('TransDataList', {
        							   renderTo: 'transData'
        						   });
        						   Ext.widget('TransSubDataList', {
        							   renderTo: 'transSubData'
        						   });
        					   }
        				   });
        				   sdGridStatus=1;
        			   }
        		   }

        		   if(tab.title=='Payment Data')
        		   {
        			  
        			   if(pdGridStatus==0)
        			   {
        				   Ext.application({
        					   name  : 'Scheme',
        					   controllers: ['TransPayDataCon'],
        					   launch: function () {
        						   Ext.widget('TransPaymentDataList', {
        							   renderTo: 'paylist'
        						   });
        						   Ext.widget('TransPaymentSubDataList', {
        							   renderTo: 'paylist2'
        						   });
        					   }
        				   });
        				   pdGridStatus=1;
        			   }

        		   }

        		   if(tab.title=='Transaction Data')
        		   {
        			   transUniverseDataGrid.load();
        			   if(udGridStatus==0)
        			   {
        				   Ext.application({
        					   name  : 'Scheme',
        					   controllers: ['TransUniverseDataCon'],
        					   launch: function () {
        						   Ext.widget('TransUniverseDataList', {
        							   renderTo: 'universelist'
        						   });
        						   Ext.widget('TransUniverseSubDataList', {
        							   renderTo: 'universeSublist'
        						   });
        					   }
        				   });
        				   udGridStatus=1;
        			   }

        		   }

        		   if(tab.title=='Payout Data')
        		   {
        			   transUniverseDataGrid.load();
        			   if(payoutGridStatus==0)
        			   {
        				   Ext.application({
        					   name  : 'Scheme',
        					   controllers: ['TransPayoutDataCon'],
        					   launch: function () {
        						   Ext.widget('TransPayoutDataList', {
        							   renderTo: 'transPayoutData'
        						   });
        						   Ext.widget('TransPayoutSubDataList', {
        							   renderTo: 'transPayoutSubData'
        						   });
        					   }
        				   });
        				   payoutGridStatus=1;
        			   }
        		   }
        	   }
           }
       }
   ]});

	
	var stmtGenFormPanel = Ext.create('Ext.form.Panel', {
		   		layout:'fit',
		 	border: true,
		 	id: 'Statement',
		 
		 	items:[
		          
		       {
	           xtype:'tabpanel',
	           id: 'stmtGenTablist',
	       		//width:1150,
				layout:'fit',
	           defaults:{
	         //  	preventBodyReset: true
	           	},
	           items:[
	                  {
	                	  title: 'Statement Request',
	                	  id:'stmtReqData',
	                	  items:
	                		  [ReqStmtList]
	                  },
	               /*{
	               title:'Scheme Statement View',
	               id:'stmtData',
	               items: [
	                       	stmGenList
	                       ]
	               	
	               },*/
	               {
	                   title:'View Statement',
	                   id:'viewStmtData',
	                   items: [
	                           	viewStmtList
	                           ]
	               },
	               
	               
	           ],
	           listeners: {
	        	   'tabchange': function (tabPanel, tab) {
	        		   /*if(tab.title=='Scheme Statement View')
	        		   {
	        			   if(stmtGridStatus==0)
	        			   {
	        				   Ext.application({
	        					   name  : 'Scheme',
	        					   controllers: ['ScmGenCon'],
	        					   launch: function () {
	        						   Ext.widget('StmGenList', {
	        							   renderTo: 'stmGen'
	        						   });
	        					   }
	        				   });
	        				   stmtGridStatus=1;
	        			   }
	        		   }
	        			*/
	        		   
	        		   if(tab.title=='View Statement')
	        		   {
	        			   viewStmtGenGrid.load();
	        			   if(vstmtGridStatus==0)
	        			   {
	        				   Ext.application({
	        					   name  : 'Scheme',
	        					   controllers: ['ViewStmtGenCon'],
	        					   launch: function () {
	        						   Ext.widget('ViewStmtGenList', {
	        							   renderTo: 'viewStmtgen'
	        						   });
	        					   }
	        				   });
	        				   vstmtGridStatus=1;
	        			   }

	        		   }
	        		   if(tab.title=='Statement Request')
	        		   {
	        			  
	        			   StmtReqStore.load();
	        			   tempSchemeStore.load();
	        			   if(rstmtGridStatus==0)
	        			   {
	        				   Ext.application({
	        					   name  : 'Scheme',
	        					   controllers: ['ScmReqCon'],
	        					   launch: function () {
	        						   Ext.widget('StmReqList', {
	        							   renderTo: 'StmtgenReq'
	        						   });
	        						   Ext.widget('StmReqSubList', {
	        							   renderTo: 'StmtgenSubReq'
	        						   });
	        					   }
	        				   });
	        				   rstmtGridStatus=1;
	        			   }
	        			   
	        		   }  
	        	   }
	           }
	       }
	   ]});

	

	
	var vtopUpFormPanel = Ext.create('Ext.form.Panel', {
		layout:'fit',
		border: true,
		id: 'Hold/Release-Payment',
		items:[
		       {
		    	   xtype:'tabpanel',
		    	   id: 'vtopUpTablist',
		    	   //width:1150,
		    	   layout:'fit',
		    	   defaults:{
		    		   //  	preventBodyReset: true
		    	   },
		    	   items:[
		    	          {
		    	        	  title:'Hold Payment',
		    	        	  id:'holdPay2',
		    	        	  items: [
		    	        	          holdPayList
		    	        	          ]
		    	          },
		    	          {
		    	        	  title:'Release Payment',
		    	        	  id:'relePay2',
		    	        	  items: [
		    	        	          relePayList
		    	        	          ]
		    	          },
		    	          ],
		    	          listeners: {
		    	        	  'tabchange': function (tabPanel, tab) {
		    	        		  if(tab.title=='Hold Payment')
		    	        		  {
		    	        			  if(holdGridStatus==0)
		    	        			  {
		    	        				  Ext.application({
		    	        					  name  : 'Scheme',
		    	        					  controllers: ['HoldPayCon'],
		    	        					  launch: function () {
		    	        						  Ext.widget('HoldPayList', {
		    	        							  renderTo: 'holdPay'
		    	        						  });
		    	        					  }
		    	        				  });
		    	        				  holdGridStatus=1;
		    	        			  }
		    	        		  }

		    	        		  if(tab.title=='Release Payment')
		    	        		  {
		    	        			  if(releGridStatus==0)
		    	        			  {
		    	        				  Ext.application({
		    	        					  name  : 'Scheme',
		    	        					  controllers: ['RelePayCon'],
		    	        					  launch: function () {
		    	        						  Ext.widget('RelePayList', {
		    	        							  renderTo: 'relePay'
		    	        						  });
		    	        					  }
		    	        				  });
		    	        				  releGridStatus=1;
		    	        			  }

		    	        		  }
		    	        	  }
		    	          }
		       }
		       ]});

	
	var templateFormPanel = Ext.create('Ext.form.Panel', {
		layout:'fit',
		border: true,
		id: 'Template',
		items:[
		       {
		    	   xtype:'tabpanel',
		    	   id: 'tempTablist',
		    	   layout:'fit',
		    	   defaults:{

		    	   },
		    	   items:[
		    	          {
		    	        	  title:'Template',
		    	        	  id:'tempData',
		    	        	  items: [
		    	        	          tempList
		    	        	          ]
		    	          },
		    	          ],
		    	          listeners: {
		    	        	  'tabchange': function (tabPanel, tab) {/*
		    	        		  templateGrid.load();
		    	        		  if(tab.title=='Template')
		    	        		  {
		    	        			  
		    	        			  if(tempGridStatus==0)
		    	        			  {
		    	        				  Ext.application({
		    	        					  name  : 'Scheme',
		    	        					  controllers: ['TemplateCon'],
		    	        					  launch: function () {
		    	        						  Ext.widget('TemplateList', {
		    	        							  renderTo: 'templ'
		    	        						  });
		    	        					  }
		    	        				  });
		    	        				  tempGridStatus=1;
		    	        			  }
		    	        		  }

		    	        	  */}
		    	          }
		       }
		       ]});

	var hierarcyFormPanel = Ext.create('Ext.form.Panel', {
		layout:'fit',
		border: true,
		id: 'Hierarchy-Suspense',
		items:[
		       {
		    	   xtype:'tabpanel',
		    	   id: 'hierTablist',
		    	   layout:'fit',
		    	   defaults:{

		    	   },
		    	   items:[
		    	          
		    	          {
		    	        	  title:'Hierarchy Suspense',
		    	        	  id:'hieraData',
		    	        	  items: [
		    	        	             hieraList
		    	        	          ]
		    	          },
		    	           {
	    	        	  title:'Hierarchy Mismatch',
	    	        	  id:'hierMisData',
	    	        	  items: [
	    	        	          		hieraList1
	    	        	          ]
	    	          },
	    	          ],
		    	          listeners: {
		    	        	  'tabchange': function (tabPanel, tab) {
		    	        		  
		    	        		  
		    	        		  if(tab.title=='Hierarchy Suspense')
		    						{
		    							if(hieraGridStatus==0)
		    							{
		    								Ext.application({
		    									name  : 'Scheme',
		    									controllers: ['HierarchyCon'],
		    									launch: function () {
		    										Ext.widget('HierarchyList', {
		    											renderTo: 'hiera'
		    										});
		    									}
		    								}
		    								);
		    								hieraGridStatus = 1;
		    							}
		    						}
		    	        		  if(tab.title=='Hierarchy Mismatch')
		    	        		  {
		    	        			  if(hieraMisGridStatus==0)
		    	        			  {
		    	        				  Ext.application({
		    	        					  name  : 'Scheme',
		    	        					  controllers: ['HierarchyCon1'],
		    	        					  launch: function () {
		    	        						  Ext.widget('HierarchyList1', {
		    	        							  renderTo: 'hieraz'
		    	        						  });
		    	        					  }
		    	        				  });
		    	        				  hieraMisGridStatus = 1;
		    	        			  }
		    	        		  }
		    	        		  
		    	        	  }
		    	          }
		       }
		       ]});
	

	

	var circleSchedFormPanel = Ext.create('Ext.form.Panel', {
		layout:'fit',
		border: true,
		id: 'Circle-Scheduler',
		items:[
		       {
		    	   xtype:'tabpanel',
		    	   id: 'circleSchedTablist',
		    	   layout:'fit',
		    	   defaults:{

		    	   },
		    	   items:[
		    	          {
		    	        	  title:'Circle Scheduler',
		    	        	  id:'circleSchData',
		    	        	  items: [
		    	        	            circleSchedular
		    	        	          ]
		    	          },
		    	          ],
		    	          listeners: {
		    	        	  'tabchange': function (tabPanel, tab) {/*
		    	        		  templateGrid.load();
		    	        		  if(tab.title=='Template')
		    	        		  {
		    	        			  
		    	        			  if(tempGridStatus==0)
		    	        			  {
		    	        				  Ext.application({
		    	        					  name  : 'Scheme',
		    	        					  controllers: ['TemplateCon'],
		    	        					  launch: function () {
		    	        						  Ext.widget('TemplateList', {
		    	        							  renderTo: 'templ'
		    	        						  });
		    	        					  }
		    	        				  });
		    	        				  tempGridStatus=1;
		    	        			  }
		    	        		  }

		    	        	  */}
		    	          }
		       }
		       ]});

	var dataAnalysisFormPanel = Ext.create('Ext.form.Panel', {
		layout:'fit',
		border: true,
		id: 'Data-Analysis',
		items:[
		       {
		    	   xtype:'tabpanel',
		    	   id: 'dataAnlysTablist',
		    	   layout:'fit',
		    	   defaults:{

		    	   },
		    	   items:[
		    	          
		    	          {
		    	        	  title:'SCM Data Analysis',
		    	        	  id:'scmDataAnalysis',
		    	        	  items: [
		    	        	          	 scmDataAnalysisList
		    	        	          ]
		    	          },
		    	          
	    	          ],
		    	          listeners: {
		    	        	  'tabchange': function (tabPanel, tab) {
		    	        	  }
		    	          }
		       		}
		       ]});

	
	Ext.QuickTips.init();


	var userInfo = null;
	
	
	var startPanel = {
          id: 'start-panel',
            title: 'Start Page',
            layout: 'fit',
            bodyStyle: 'padding:25px',
            contentEl: 'start-div'  // pull existing content from the page
    };
	
	
	
	var contentPanel = {
         id: 'content-panel',
         region: 'center', // this is what makes this panel into a region within the containing layout
         layout: 'card',
		 collapsible: false,
         margins: '2 5 5 0',
         activeItem: 0,
         border: false,
         items: [startPanel,formPanel,schemeList,viewschemeList,SubmitschemeList,reportList,payoutAppList,bulkFormPanel,execCalList,sentToVtopList,stmtGenFormPanel,transFormPanel,templateFormPanel,circleSchedFormPanel,circleSchedularList,hierarcyFormPanel,dataAnalysisFormPanel,vtopUpFormPanel,gridForm,EmailDocList,dataReportGen]
    };
	
		
	
	
	
	Ext.Ajax.request({
		  url : 'getUserDetails.action',
		  method: 'GET',
		  type:'json',
		  waitMsg : 'Loading...',
		  headers: { 'Content-Type': 'application/json' },
		    success: function (response) {
				regionStore.load();
		    	poFilterVariables.load();
				componentListStore.load();
				AttrMappingConfigStore.load();
				AttrMappingFieldSetStore.load();
				//StmtReqStore.load();
				//tempSchemeStore.load();
		    	 Ext.ux.mask.hide();
				Ext.Ajax.request({
	  url : "payoutcondition/getCurrentScheme.action",
	  method: 'GET',
	  
	    success: function (response) {
	    	
	    	//alert(response.responseText);
	    		SchemeName = response.responseText;
	    		compName = "yes";
	    		
	    },
	 
	  failure: function (response) {
	       }
	 });

				
				
				userInfo = response.responseText;
		    	userInfo = Ext.JSON.decode(userInfo);
		    	if(userInfo.data==undefined || userInfo.data==null){
		    		//alert("Test :::: "+userInfo.data);
		    		 Ext.Msg.alert('Status', 'Unable to Login or You are Unauthorize Person.', function(btn, text){
		    		       if (btn == 'ok'){
		    		                          var redirect = 'unauthorize.jsp'; //here need to redirect to another url on the controller side 
		    		                          window.location = redirect;
		    		                                   }
		    		           });
		    		
		    	}
				
				
		    	formPanel.items.each(function(c){
		    		//c.down('Component').disable();
		    			//c.disable('Component');
		    			//c.getId('Component').disable = true;
//						c.items.items[1].setDisabled(true);
//						c.items.items[2].setDisabled(true);
//						c.items.items[3].setDisabled(true);
//						c.items.items[4].setDisabled(true);
//						c.items.items[5].setDisabled(true);
//						c.items.items[6].setDisabled(true);
//						c.items.items[7].setDisabled(true);
//						c.items.items[8].setDisabled(true);
						
		    		//c.down('Component').setDisabled(true);
		    		
		    		//c.disable();ROLE_CONFIGURE
		    		});		    	
		    	
		    		
		    		var Menus = Ext.create('Ext.data.TreeStore', {
		    	        root: {
		    	            expanded: true
		    	        },
		    	        proxy: {
		    	            type: 'ajax',
		    	            url: 'menu/getUserMenuDetails.action'
		    	        }
		    	    });

		    	
		    	
		    	
		    	var menuPanel = Ext.create('Ext.tree.Panel', {
	    	        id: 'tree-panel',
	    			
	    	        //title: 'Navigation',
	    			rootVisible: false,
	    	        border:false,
	    	        region:'west',
	    			margins: '5 0 0 0',
	    			cmargins: '5 5 0 0',
	    			width: 175,
	    			minSize: 100,
	    			maxSize: 250,
	    	        autoScroll: true,
	    	        store: Menus,
	    			
	    	    });
		    	
		    	
		    	
				menuPanel.getSelectionModel().on('select', function(selModel, record) {
	    	        if (record.get('leaf')) {
	    			if(record.getId()=='View')
	    			{
	    				if(viewschemeGrid==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						controllers: ['ViewSchemeCon'],
	    						launch: function () {
	    							Ext.widget('ViewSchemeList', {
	    								renderTo: 'viewscheme'
	    							});
	    						}
	    					}
	    					);

	    					viewschemeGrid = 1;
	    					viewschemeStoreGrid.load(
	    							{
	    								params:
	    								{
	    									'isMaster':'YES',
	    									'isStage':'NO',
	    									'condParam':'D'
	    								}});
	    				}
	    			}
	    			
	    			if(record.getId()=='Edit')
	    			{
	    				if(searchGrid==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						controllers: ['SchemeCon'],
	    						launch: function () {
	    							Ext.widget('SchemeList', {
	    								renderTo: 'scheme'
	    							});
	    						}
	    					}
	    					);
	    					searchGrid = 1;
	    					schemeStoreGrid.load();
	    				}
	    			}
	    			if(record.getId()=='Submission')
	    			{
	    				if(submitchemeGrid==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						controllers: ['SubmitSchemeCon'],
	    						launch: function () {
	    							Ext.widget('SubmitSchemeList', {
	    								renderTo: 'submitscheme'
	    							});
	    						}
	    					}
	    					);
	    					submitchemeGrid = 1;
	    					submitschemeGrid.load();
	    				}
	    			}
	    			if(record.getId()=='Scheme-Approval')
	    			{
	    				if(reportGrid==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						controllers: ['ReportCon'],
	    						launch: function () {
	    							Ext.widget('ReportList', {
	    								renderTo: 'report'
	    							});
	    						}
	    					}
	    					);
	    					reportGrid = 1;
	    				}

	    			}
	    			if(record.getId()=='Payout-Approval')
	    			{
	    				if(payoutApprovalGrid==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						controllers: ['ApproveSchemeCon'],
	    						launch: function () {
	    							Ext.widget('PayoutAppSchemeList', {
	    								renderTo: 'payoutApp'
	    							});
	    						}
	    					}
	    					);
	    					payoutApprovalGrid = 1;
	    				}
	    			}

	    			if(record.getId()=='Bulk-Upload-File')
	    			{
	    			
	    			}
	    			if(record.getId()=='Execution-Calendar')
	    			{
	    				if(executeSchemeGrid==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						// autoCreateViewport: true,
	    						controllers: ['ExecCalCon'],
	    						launch: function () {
	    							Ext.widget('ExecCalList', {
	    								renderTo: 'execList'
	    							});
	    						}
	    					}
	    					);
	    					executeSchemeGrid = 1;
	    				}
	    			}
	    			
	    			if(record.getId()=='Payment')
	    			{
	    				if(sentToVtopGrid==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						// autoCreateViewport: true,
	    						controllers: ['VtopUpCon'],
	    						launch: function () {
	    							Ext.widget('VtopList', {
	    								renderTo: 'sentToVtop'
	    							});
	    						}
	    					}
	    					);
	    					sentToVtopGrid = 1;
	    				}
	    			}
	    			
	    			if(record.getId()=='Statement')
	    			{
	    				/*if(stmtGridStatus==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						controllers: ['ScmGenCon'],
	    						launch: function () {
	    							Ext.widget('StmGenList', {
	    								renderTo: 'stmGen'
	    							});
	    						}
	    					}
	    					);
	    					stmtGridStatus = 1;
	    				}*/
	    				if(rstmtGridStatus==0)
	        			   {
	        				   Ext.application({
	        					   name  : 'Scheme',
	        					   controllers: ['ScmReqCon'],
	        					   launch: function () {
	        						   Ext.widget('StmReqList', {
	        							   renderTo: 'StmtgenReq'
	        						   });
	        						   Ext.widget('StmReqSubList', {
	        							   renderTo: 'StmtgenSubReq'
	        						   });
	        					   }
	        				   });
	        				   rstmtGridStatus=1;
	        			   }
	    			}
	    			if(record.getId()=='Transaction-Data')
	    			{
	    				if(sdGridStatus==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						controllers: ['TransDataCon'],
	    						launch: function () {
	    							Ext.widget('TransDataList', {
	    								renderTo: 'transData'
	    							});
	    							Ext.widget('TransSubDataList', {
	    								renderTo: 'transSubData'
	    							});
	    						}
	    					});
	    					sdGridStatus=1;
	    				}						
	    			}		
	    			
	    			if(record.getId()=='Template')
					{
						templateGrid.load();
						if(tempGridStatus==0)
						{
							Ext.application({
								name  : 'Scheme',
								controllers: ['TemplateCon'],
								launch: function () {
									Ext.widget('TemplateList', {
										renderTo: 'templ'
									});
								}
							}
							);
							tempGridStatus = 1;
						}
					}
	    			
	    			if(record.getId()=='Hierarchy-Suspense')
					{
						if(hieraGridStatus==0)
						{
							Ext.application({
								name  : 'Scheme',
								controllers: ['HierarchyCon'],
								launch: function () {
									Ext.widget('HierarchyList', {
										renderTo: 'hiera'
									});
								}
							}
							);
							hieraGridStatus = 1;
						}
					}

	    			if(record.getId()=='Hold/Release-Payment')
	    			{
	    				if(holdGridStatus==0)
	    				{
	    					Ext.application({
	    						name  : 'Scheme',
	    						controllers: ['HoldPayCon'],
	    						launch: function () {
	    							Ext.widget('HoldPayList', {
	    								renderTo: 'holdPay'
	    							});
	    						}
	    					});
	    					holdGridStatus=1;
	    				}
	    			}
	    			
	    			if(record.getId()=='Data-Analysis')
					{
						if(scmDAGridStatus==0)
						{
							Ext.application({
								name  : 'Scheme',
								controllers: ['ScmDataAnalysisCon'],
								launch: function () {
									Ext.widget('ScmDataAnalysisList', {
										renderTo: 'scmDataAnaly'
									});
								}
							}
							);
							scmDAGridStatus = 1;
						}
					}
	    			
	    	           Ext.getCmp('content-panel').layout.setActiveItem(record.getId());    	
	    				
	    	            
	    			}
	    	    });
		    		
		    	
				Ext.create('Ext.Viewport', {
		            layout: 'border',
		            title: 'Ext Layout Browser',
		    		defaults: {
		    				collapsible: true,
		    		},
		            items: [{
		                xtype: 'box',
		                id: 'header',
		                region: 'north',
		               // html : '<div style="float:left; padding: 5px;" ><img id="logo" src="resources/images/SSIdeaLogo.jpg"><h1>Scheme Studio &nbsp;&nbsp;&nbsp;<sub><font size="1">CPS.2018.10.23.V1</font></sub> </h1></div><div id="userprofile"><h3>Welcome! '+userInfo.data.userName+'</h3><h4>Role : '+userInfo.data.roleName+'&nbsp;&nbsp;<a  href="j_spring_security_logout"  target="_self"><img id="logout" src="resources/images/logout.png" border="0"></a><br>Circle: '+userInfo.data.circleName+'</h4></div>',
		                html : '<div style="float:left; padding: 5px;" ><img id="logo" src="resources/images/SSIdeaLogo.jpg"><h1>Scheme Studio &nbsp;&nbsp;&nbsp;<sub><font size="1">'+userInfo.data.ssVersion+'</font></sub>   &nbsp;&nbsp;&nbsp;<sub><font size="1">Last Login : '+userInfo.data.lastLogin+'</font></sub> </h1></div><div id="userprofile"><h3>Welcome! '+userInfo.data.userName+'</h3><h4>Role : '+userInfo.data.roleName+'&nbsp;&nbsp;<a  href="j_spring_security_logout"  target="_self"><img id="logout" src="resources/images/logout.png" border="0"></a>&nbsp;&nbsp;&nbsp;&nbsp;Circle: '+userInfo.data.circleName+'&nbsp;&nbsp;&nbsp;</h4></div>',
		                height: 70
		            },{
		                layout: 'border',
		    			title: 'Navigation',
		                id: 'layout-browser',
		                region:'west',
		                border: false,
		                split:true,
		                margins: '2 0 5 5',
		                width: 175,
		                minSize: 100,
		                maxSize: 500,
		                items: [
		                        	menuPanel
		    			//detailsPanel
		    			]
		            }, 
		                contentPanel
		            ],
		            renderTo: Ext.getBody()
		        });
				
				
				
		  /*  	Menus.load({
					callback: function(records, operation, success) {
					if (success == true) {
					
						
					
					
					
					
					}
				
		    	

					}
		    	
		    	});
		    	
		    	
		    */		
		    		
		    		
		    		
		    		
		    		

			//	 treePanel.reconfigure(createUser,undefined);
	
		 
		    
		    }, //sucess body close
		 
		  failure: function (response) {
			  userInfo = response.responseText;
		    	userInfo = Ext.JSON.decode(userInfo);

				alert("in failure :::: "+userInfo.data.userName);
			  alert("test ------ fail...");
		       }
		 });
	
   
});

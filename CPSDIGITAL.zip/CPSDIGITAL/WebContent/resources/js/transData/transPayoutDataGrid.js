Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);
	
	var transPaysd = null;
	var transPayed = null;
	var pdPayToId = null;
	
	function downloadPayout(qualify)
	{

		var grid = Ext.ComponentQuery.query('TransPayoutDataList')[0];
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		var urlParam;
		Ext.Msg.confirm('Trans Data', 
				'Download Scheme CSV', 
				function (button) {
			if (button == 'yes') {
				if(qualify==='Payout Data'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId='+rs[0].data.schemeId +'&compId='+rs[0].data.compId+
					'&conditionId=0'+'&qualifyType=1'+'&transSubDataType=PD'+'&paymentId=0'+'&universeId=0';
					window.open(urlParam,'_BLANK');
				}
			}
		});
	}


	
	var transPayDataSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		layout	   :'column',
		anchor	   : '100%',
		items       : [	
		{
			xtype       : 'datefield',
			id          : 'startDatepSD',
			allowBlank  : false,
			emptyText   : 'StartDate',
			name        : 'startDateTrans',
			//width       : 140,
			editable    : false,
		},{
			xtype       : 'datefield',
			id          : 'endDatepSD',
			allowBlank  : false,
			emptyText   : 'EndDate',
			name        : 'endDateTrans',
			editable    : false,
		},
		{
     		xtype       : 'textfield',
     		id          : 'schemeNamePD',
     		allowBlank  : true,
     		emptyText   : 'Scheme Name',
     		name        : 'schemeComp',
     		//width       : 140,
     		editable    : true,
     		 //maskRe:/[A-Za-z0-9_- ]/,
     		maxLength : 100,
        	enforceMaxLength:"true"
     		// format      : 'dd-MMM-yyyy'
     	},
     	{
     		xtype       : 'numberfield',
     		id          : 'schemeNameIdPD',
     		allowBlank  : true,
     		emptyText   : 'Scheme ID',
     		name        : 'schemeId',
     		allowNegative: false,
     		//width       : 140,
     		editable    : true,
     		maxLength : 38,
        	enforceMaxLength:"true"
     		// format      : 'dd-MMM-yyyy'
     	},
     	 {
     		xtype       : 'textfield',
     		id          : 'compNamePD',
     		allowBlank  : true,
     		emptyText   : 'Component Name',
     		name        : 'componentName',
     		//width       : 140,
     		editable    : true,
     		maxLength : 100,
     		// maskRe:/[A-Za-z0-9_- ]/,
        	enforceMaxLength:"true"
     		// format      : 'dd-MMM-yyyy'
     	},
     	{
      		xtype: 'combo',
      		store:payToStore,
      		emptyText   : 'Pay To',
      		//fieldLabel: 'Table Field',
      		displayField:'displayValue',
      		editable: false,
      		valueField:'entityTypeId',
      		name: 'payTo',   
      		listeners: {
      			'select': function(combo, value){
      				pdPayToId = combo.getValue();
      				//alert("payto ::: "+combo.getValue());
      			}
      		}
      	},
      	{
			   xtype :'textfield',
			   fieldLabel: 'CsrfName',
			   hidden:true,
			   disabled : true,
			   name: 'csrfPayoutTr',
			   maxLength : 100,
			   allowBlank:false,
			   id:'testCsrfPayoutTr'
		},
		{
			xtype       : 'button',
			text        : 'Go',
			width       : 40,
			handler     : function () {
				Ext.getCmp("testCsrfPayoutTr").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
				transPaysd = Ext.Date.format(Ext.getCmp("startDatepSD").getValue(),'d-M-y');
				transPayed = Ext.Date.format(Ext.getCmp("endDatepSD").getValue(),'d-M-y');
				var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDatepSD").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDatepSD").getValue(),'Y/m/d'));
				if(flag){
					var grid = Ext.ComponentQuery.query('TransPayoutDataList')[0];
					var pdScmName = Ext.getCmp("schemeNamePD").getValue()!='' ? Ext.getCmp("schemeNamePD").getValue() : 'ABCDEF';
					var pdScmId = Ext.getCmp("schemeNameIdPD").getValue()!=null ? Ext.getCmp("schemeNameIdPD").getValue() : '-1';
					var pdCompName = Ext.getCmp("compNamePD").getValue()!='' ? Ext.getCmp("compNamePD").getValue() : 'ABCDEF';	
					pdPayToId = pdPayToId != null ? pdPayToId : '-1';
					
					grid.store.load({params:
					{
						startDate  :	transPaysd ,
						endDate    : 	transPayed,
						condParam : 	1,
						schemeComp : pdScmName,
						schemeId : pdScmId,
						componentName : pdCompName,
						payTo : pdPayToId,
						page:1,
						start :	0
					}});

				}
			},
		}]
	});
	
	
	
	Ext.define('Scheme.view.TransPayoutDataList', {
		extend: 'Ext.grid.Panel',
		id:'transPayoutDataGrid',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:300,
		bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TransPayoutDataList',
		//title: 'Transaction Data',
		store: transPayoutDataGrid,
		//height:500,
		autoScroll: true,
		listeners: {
		    select: function(selModel, record, index, options){
		    	var gridSub = Ext.ComponentQuery.query('TransPayoutSubDataList')[0];//transSubDataGrid
		    	gridSub.store.load({params:
				{
		    		schemeId  :	record.data.schemeId ,
		    		compId    :	record.data.compId,
		    		startDate : record.data.startDtStr,
		    		endDate : record.data.endDtStr,
		    		paymentRemarks	:'PD'
		    	}});
		    }
		},

		initComponent: function () {
			var me = this;
			this.tbar = [
			             transPayDataSearch
			             ];
			this.columns = [
			                { header: 'Scheme Id', dataIndex: 'schemeId', flex: 1 },
			                { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
			                { header: 'Comp Id', dataIndex: 'compId', flex: 1 },
			                { header: 'Comp Name', dataIndex: 'compName', flex: 1 },
			                { header: 'Start Date', dataIndex: 'startDtStr', flex: 1 },
			                { header: 'End Date', dataIndex: 'endDtStr', flex: 1 },
			                { header: 'Status', dataIndex: 'scmStatus', flex: 1 },
			                { header: 'Pay To', dataIndex: 'payToName', flex: 1 },
			                { header: 'Payout Status', dataIndex: 'payoutStatus', flex: 1 },
			                { header: 'Payment Status', dataIndex: 'paymentStatus', flex: 1 },
			                ];
			
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : transPayoutDataGrid,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		},
	});


	Ext.define('Scheme.view.TransPayoutSubDataList', {
		extend: 'Ext.grid.Panel',
		id:'transPayoutSubDataGrid',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:190,
		bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TransPayoutSubDataList',
		title: 'Transaction Payout Sub Data',
		store: transPayoutSubDataGrid,
		//height:500,
		autoScroll: true,

		initComponent: function () {
			var me = this;
			this.tbar = [
			            // transSubDataSearch
			             ];
			this.columns = [
			                { header: 'Gross/Net', dataIndex: 'grossnet', flex: 1 },
			                { header: 'Max Amount', dataIndex: 'maxAmt',  flex: 1 },
			                { header: 'Min Amount', dataIndex: 'minAmt',  flex: 1 },
			                { header: 'Avg Amount', dataIndex: 'avgAmt',  flex: 1 },
			                { header: 'Head Count', dataIndex: 'headCount', flex: 1 },
			                { header: 'Extract', flex: 1,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function () {
			                			Ext.widget('image', {
			                				renderTo: id,
			                				name: 'testRun',
			                				src : 'resources/images/book_add.png',
			                				listeners : {
			                					afterrender: function (me) {
			                						me.getEl().on('click', function() {
			                							var gridSub = Ext.ComponentQuery.query('TransPayoutSubDataList')[0];
			                							var grid = Ext.ComponentQuery.query('TransPayoutDataList')[0];
			                							
			                							if (grid) {
			                								var sm = grid.getSelectionModel();
			                								var rs = sm.getSelection();
			                								if (!rs.length) {
			                									Ext.Msg.alert('Info', 'No Scheme Selected');
			                									return;
			                								}
			                								Ext.Msg.confirm('Extract Data', 
	    	                										'Do You want to Extract Data?', 
			                										function (button) {

			                									if (button == 'yes') {
			                										Ext.ux.mask.show(); 
			                										Ext.Ajax.request({
			                											url : 'transData/getTransExecUniverseDataSearch.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
			                											method: 'POST',
			                											//timeout:120000,
			                											waitMsg : 'Loading...',
			                											params: {
			                												"schemeId": rs[0].data.schemeId,
			                												"compId"  : rs[0].data.compId,
			                												"condId"  : 0,
			                												"condiParam":'PD',
			                												"success" : true
			                											},

			                											success: function (response) {
			                												Ext.ux.mask.hide();
			                												var jsonResp = Ext.JSON.decode(response.responseText);
			                												if(jsonResp.success==false)	
			                												{
			                													Ext.Msg.alert(jsonResp.errorMessage);
			                												}
			                												else
			                													Ext.Msg.alert("Info",jsonResp.errorMessage);

			                												gridSub.store.load({params:
			                												{
			                													"schemeId": rs[0].data.schemeId,
				                												"compId"  : rs[0].data.compId,
				                												"paymentRemarks":'PD',
			                												}});
			                											},
			                											failure: function (response) {
			                												Ext.ux.mask.hide();
			                												var jsonResp = Ext.JSON.decode(response.responseText);
			                												if(jsonResp.success==false)	
			                												{
			                													Ext.Msg.alert("Error",jsonResp.errorMessage);
			                												}
			                												else
			                													Ext.Msg.alert("Info",jsonResp.errorMessage);
			                											}
			                										});
			                									}
			                								});
			                							}
			                						});
			                					}
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                {
			                	header: 'Qualified',dataIndex: 'qualify', flex: 1,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function() {
			                			Ext.widget('button', {
			                				renderTo: id,
			                				//disabled : false,
			                				text: 'Payout Data',
			                				scale: 'small',
			                				handler: function() {
			                					downloadPayout('Payout Data');
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                ];
			this.dockedItems = [];
			this.callParent(arguments);
		},
	});
	
	
	Ext.define('Scheme.controller.TransPayoutDataCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['TransPayoutDataList','TransPayoutSubDataList']
	});
	
	
});
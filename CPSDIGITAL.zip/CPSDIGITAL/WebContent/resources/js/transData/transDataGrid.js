Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);
	var transDataloadsd = null;
	var transDataloaded = null;
	var nqd=null;
	var disValFlag = false;
	var qad=null;
	var subCombo = null;
	 var sdPayToId = null;
/*	var mycolumns = [
{ header: 'Cond Id', dataIndex: 'condId', width: 80 },
{ header: 'Cond Name', dataIndex: 'condName', width: 80 },
{ header: 'Condition', dataIndex: 'condition', flex: 1 },
{
	header: 'Qualified',dataIndex: 'qualify', width: 80,
	renderer: function (v, m, r) {
		var id = Ext.id();
		if(reportloadfilter=='D')
		{
		Ext.defer(function() {
			Ext.widget('button', {
				renderTo: id,
				//		disabled : true,
				text: qad,
				scale: 'small',
				handler: function() {
					download(qad);;
				}
			});
		}, 700);
		
	//	}
		return Ext.String.format('<div id="{0}"></div>', id);
	}
},
{
	header: 'Not Qualified',dataIndex: 'notQualify', width: 80,
	renderer: function (v, m, r) {
		var id = Ext.id();
		if(reportloadfilter=='D')
		{
		Ext.defer(function() {
			Ext.widget('button', {
				renderTo: id,
				disabled : disValFlag,
				text: nqd,
				scale: 'small',
				handler: function() {
					download(nqd);
				}
			});
		}, 700);
		
	//	}
		return Ext.String.format('<div id="{0}"></div>', id);
	}
},
];
	
	var mycolumns2 = [
{ header: 'Gross/Net', dataIndex: 'grossnet', width: 80 },
{ header: 'Max Amount', dataIndex: 'maxAmt', width: 80 },
{ header: 'Min Amount', dataIndex: 'minAmt', flex: 1 },
{ header: 'Avg Amount', dataIndex: 'avgAmt', width: 80 },
{ header: 'Head Count', dataIndex: 'headCount', width: 80 },
{
	header: 'Qualified',dataIndex: 'qualify', width: 80,
	renderer: function (v, m, r) {
		var id = Ext.id();
		Ext.defer(function() {
			Ext.widget('button', {
				renderTo: id,
				//		disabled : true,
				text: qad,
				scale: 'small',
				handler: function() {
					download(qad);;
				}
			});
		}, 700);
		
		return Ext.String.format('<div id="{0}"></div>', id);
	}
},
{
	header: 'Not Qualified',dataIndex: 'notQualify', width: 80,
	renderer: function (v, m, r) {
		var id = Ext.id();
		Ext.defer(function() {
			Ext.widget('button', {
				renderTo: id,
				disabled : disValFlag,
				text: nqd,
				scale: 'small',
				handler: function() {
					download(nqd);
				}
			});
		}, 700);		
		return Ext.String.format('<div id="{0}"></div>', id);
	}
},

];
*/	
	function download(qualify)
	{

		var grid = Ext.ComponentQuery.query('TransDataList')[0];
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		
		var gridSub = Ext.ComponentQuery.query('TransSubDataList')[0];
		var subm = gridSub.getSelectionModel();
		var rsub = subm.getSelection();
		
		
		var urlParam;
		Ext.Msg.confirm('Trans Data', 
				'Download Scheme CSV', 
				function (button) {
			if (button == 'yes') {
				if(qualify==='Qualify Data'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId='+rs[0].data.schemeId +'&compId='+rs[0].data.compId+
					'&conditionId='+rsub[0].data.condId+'&qualifyType=1'+'&transSubDataType=TQ';
					window.open(urlParam,'_BLANK');
				}else if(qualify==='EA Data'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId='+rs[0].data.schemeId +'&compId='+rs[0].data.compId+
					'&conditionId='+rsub[0].data.condId+'&qualifyType=1'+'&transSubDataType=EA';
					window.open(urlParam,'_BLANK');
				}else if(qualify==='PO Data'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId='+rs[0].data.schemeId +'&compId='+rs[0].data.compId+
					'&conditionId='+rsub[0].data.condId+'&qualifyType=1'+'&transSubDataType=PO';
					window.open(urlParam,'_BLANK');
				}else if(qualify==='COV Data'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId='+rs[0].data.schemeId +'&compId='+rs[0].data.compId+
					'&conditionId='+rsub[0].data.condId+'&qualifyType=1'+'&transSubDataType=COV';
					window.open(urlParam,'_BLANK');
				}else if(qualify==='TG Data'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId='+rs[0].data.schemeId +'&compId='+rs[0].data.compId+
					'&conditionId=0'+'&qualifyType=1'+'&transSubDataType=AA';
					window.open(urlParam,'_BLANK');
				}
				if(qualify==='Not Qualify Data'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId='+rs[0].data.schemeId +'&compId='+rs[0].data.compId+
					'&conditionId='+rsub[0].data.condId+'&qualifyType=2'+'&transSubDataType=TQ';
					window.open(urlParam,'_BLANK');
				}

			}
		});
	}


	
	var transDataSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		layout	   :'column',
		anchor	   : '100%',
		items       : [	
		{
			xtype       : 'datefield',
			id          : 'startDateSD',
			allowBlank  : false,
			emptyText   : 'StartDate',
			name        : 'startDateTrans',
			//width       : 140,
			editable    : false,
		},{
			xtype       : 'datefield',
			id          : 'endDateSD',
			allowBlank  : false,
			emptyText   : 'EndDate',
			name        : 'endDateTrans',
			editable    : false,
		},
		{
     		xtype       : 'textfield',
     		id          : 'schemeNameSD',
     		allowBlank  : true,
     		emptyText   : 'Scheme Name',
     		name        : 'schemeComp',
     		//width       : 140,
     		editable    : true,
     		//maskRe:/[A-Za-z0-9_- ]/,
     		maxLength : 100,
        	enforceMaxLength:"true"
     		// format      : 'dd-MMM-yyyy'
     	},
     	{
     		xtype       : 'numberfield',
     		id          : 'schemeNameIdSD',
     		allowBlank  : true,
     		emptyText   : 'Scheme ID',
     		name        : 'schemeId',
     		allowNegative: false,
     		//width       : 140,
     		editable    : true,
     		maxLength : 38,
        	enforceMaxLength:"true"
     		// format      : 'dd-MMM-yyyy'
     	},
     	 {
     		xtype       : 'textfield',
     		id          : 'compNameSD',
     		allowBlank  : true,
     		emptyText   : 'Component Name',
     		name        : 'componentName',
     		//width       : 140,
     		editable    : true,
     		maxLength : 100,
     		// maskRe:/[A-Za-z0-9_- ]/,
        	enforceMaxLength:"true"
     		// format      : 'dd-MMM-yyyy'
     	},
     	{
      		xtype: 'combo',
      		store:payToStore,
      		emptyText   : 'Pay To',
      		//fieldLabel: 'Table Field',
      		displayField:'displayValue',
      		editable: false,
      		valueField:'entityTypeId',
      		name: 'payTo',
      		listeners: {
      			'select': function(combo, value){
      				sdPayToId = combo.getValue();
      				//alert("payto ::: "+combo.getValue());
      			}
      		}
      	},
      	{
	    	   xtype :'textfield',
	    	   fieldLabel: 'CsrfName',
			   hidden:true,
	    	   disabled : true,
	    	   name: 'csrfTrans',
			   maxLength : 100,
	    	   allowBlank:false,
	    	   id:'testCsrfTrans'
	    },
		{ 
			xtype       : 'button',
			text        : 'Go',
			width       : 40,
			handler     : function () {
				 Ext.getCmp("testCsrfTrans").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
				transDataloadsd = Ext.Date.format(Ext.getCmp("startDateSD").getValue(),'d-M-y');
				transDataloaded = Ext.Date.format(Ext.getCmp("endDateSD").getValue(),'d-M-y');

				var grid = Ext.ComponentQuery.query('TransDataList')[0];
				var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateSD").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateSD").getValue(),'Y/m/d'));
				if(flag){
					var sdScmName = Ext.getCmp("schemeNameSD").getValue()!='' ? Ext.getCmp("schemeNameSD").getValue() : 'ABCDEF';
					var sdScmId = Ext.getCmp("schemeNameIdSD").getValue()!=null ? Ext.getCmp("schemeNameIdSD").getValue() : '-1';
					var sdCompName = Ext.getCmp("compNameSD").getValue()!='' ? Ext.getCmp("compNameSD").getValue() : 'ABCDEF';	
					sdPayToId = sdPayToId != null ? sdPayToId : '-1';
					grid.store.load({params:
					{
						startDate  :	transDataloadsd ,
						endDate    : 	transDataloaded,
						condParam : 	1,
						schemeComp : sdScmName,
						schemeId : sdScmId,
						componentName : sdCompName,
						payTo : sdPayToId,
						page:1,
						start :	0
					}});
				}
			},
		}]
	});
	
	
	var transSubDataSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		layout	   :'column',
		anchor	   : '100%',
		items       : [	{
			xtype      : 'combo',
			id          : 'transSubID',
			displayField:'name',
			valueField:'id',
			allowBlank  : true,
			name        : 'filterBy',
			//width       : 140,
			editable    : false,
			store: transSubDataStore(),
			listeners: {
				'select': function(combo, value){
					var grid = Ext.ComponentQuery.query('TransDataList')[0];
					var gridSub = Ext.ComponentQuery.query('TransSubDataList')[0];
					if (grid) {
						var sm = grid.getSelectionModel();
						var rs = sm.getSelection();
						if(combo.getValue()==5)
						{
							nqd='NA';
							qad='PD Data';
							disValFlag=true;
							gridSub.store.load({params:
							{
								schemeId 	: rs[0].data.schemeId ,
								compId   	: rs[0].data.compId,
								paymentRemarks	: 'PD',
							}});
						}
						
						if(combo.getValue()==8)
						{
							nqd='NA';
							qad='TG Data';
							disValFlag=true;
							subCombo = 'AA';
							gridSub.store.load({params:
							{
								schemeId 	: rs[0].data.schemeId ,
								compId   	: rs[0].data.compId,
								paymentRemarks	: 'AA',
							}});
						}
						
						if(combo.getValue()==4)
						{
							nqd='NA';
							qad='PO Data';
							disValFlag=true;
							subCombo = 'PO';
						//	gridSub.reconfigure(undefined,mycolumns);
							gridSub.store.load({params:
							{
								schemeId 	: rs[0].data.schemeId ,
								compId   	: rs[0].data.compId,
								paymentRemarks	: 'PO',
							}});
						}						

						if(combo.getValue()==3)
						{
							nqd='NA';
							qad='COV Data';
							disValFlag=true;
							subCombo = 'COV';
							//gridSub.reconfigure(undefined,mycolumns);
							gridSub.store.load({params:
							{
								schemeId 	: rs[0].data.schemeId ,
								compId   	: rs[0].data.compId,
								paymentRemarks	: 'COV',
							}});
						}						

						if(combo.getValue()==2)
						{
							nqd='NA';
							qad='EA Data';
							disValFlag=true;
							subCombo = 'EA';
							//gridSub.reconfigure(undefined,mycolumns);
							gridSub.store.load({params:
							{
								schemeId 	: rs[0].data.schemeId ,
								compId   	: rs[0].data.compId,
								paymentRemarks	: 'EA',
							}});
						}						

						if(combo.getValue()==1)
						{
							nqd='Not Qualify Data';
							qad='Qualify Data';
							disValFlag=false;
							subCombo = 'TQ';
							//gridSub.reconfigure(undefined,mycolumns);
							gridSub.store.load({params:
							{
								schemeId  	:	rs[0].data.schemeId ,
								compId    	:	rs[0].data.compId,
								paymentRemarks	:'TQ'
							}});
						}
					}
				}
			},
			triggerAction:'all'
		}
		]
	});

	
	
	
	Ext.define('Scheme.view.TransDataList', {
		extend: 'Ext.grid.Panel',
		id:'transDataGrid',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:300,
		bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TransDataList',
		//title: 'Transaction Data',
		store: transDataGrid,
		//height:500,
		autoScroll: true,
		listeners: {
		    select: function(selModel, record, index, options){
		    	
		    /*	var trans = transSubDataStore();
		    	nqd='Not Qualify Data';
		    	qad='Qualify Data';
		    	disValFlag=false;
		    	subCombo = 'TQ';
		    	Ext.getCmp('transSubID').setValue(trans.findRecord('id',1));
		    	var gridSub = Ext.ComponentQuery.query('TransSubDataList')[0];//transSubDataGrid
		    	//gridSub.reconfigure(undefined,mycolumns);
		    	//gridSub.setDisabled(false);
		    	gridSub.store.load({params:
				{
		    		schemeId  :	record.data.schemeId ,
		    		compId    :	record.data.compId,
		    		startDate : record.data.startDtStr,
		    		endDate : record.data.endDtStr
		    		//scmStatus : record.data.scmStatus
		    	}});*/
		    }
		},

		initComponent: function () {
			var me = this;
			this.tbar = [
			             transDataSearch
			             ];
			this.columns = [
			                { header: 'Scheme Id', dataIndex: 'schemeId', flex: 1 },
			                { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
			                { header: 'Comp Id', dataIndex: 'compId', flex: 1 },
			                { header: 'Comp Name', dataIndex: 'compName', flex: 1 },
			                { header: 'Start Date', dataIndex: 'startDtStr', flex: 1 },
			                { header: 'End Date', dataIndex: 'endDtStr', flex: 1 },
			                { header: 'Pay To', dataIndex: 'payToName', flex: 1 },
			                { header: 'Status', dataIndex: 'scmStatus', flex: 1 },
			                { header: 'Payout Status', dataIndex: 'payoutStatus', flex: 1 },
			                { header: 'Payment Status', dataIndex: 'paymentStatus', flex: 1 },

			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : transDataGrid,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		},
	});


	Ext.define('Scheme.view.TransSubDataList', {
		extend: 'Ext.grid.Panel',
		id:'transSubDataGrid',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:190,
		bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TransSubDataList',
		title: 'Transaction Sub Data',
		store: transSubDataGrid,
		//height:500,
		autoScroll: true,
		initComponent: function () {
			var me = this;
			this.tbar = [
			             transSubDataSearch
			             ];
			this.columns = [
			                { header: 'Cond Id', dataIndex: 'condId', width: 80 },
			                { header: 'Cond Name', dataIndex: 'condName', width: 80 },
			                { header: 'Condition', dataIndex: 'condition', flex: 1 },
			                { header: 'Extract', width: 80,
	    	                	renderer: function (v, m, r) {
									var id = Ext.id();
	    	                		Ext.defer(function () {
	    	                			Ext.widget('image', {
	    	                				renderTo: id,
	    	                				name: 'testRun',
	    	                				src : 'resources/images/book_add.png',
	    	                				listeners : {
	    	                					afterrender: function (me) {
	    	                						me.getEl().on('click', function() {
	    	                							var grid = Ext.ComponentQuery.query('TransDataList')[0];
	    	                							var gridSub = Ext.ComponentQuery.query('TransSubDataList')[0];
	    	                							if (grid) {
	    	                								var sm = grid.getSelectionModel();
	    	                								var rs = sm.getSelection();
	    	                								
	    	                								var subm = gridSub.getSelectionModel();
	    	                								var rsub = subm.getSelection();
	    	                								
	    	                								//alert("schmId : "+rs[0].data.schemeId+" compId : "+rs[0].data.compId+" condId : "+rsub[0].data.condId+" comb : "+subCombo);
	    	                								if (!rs.length) {
	    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
	    	                									return;
	    	                								}
	    	                								Ext.Msg.confirm('Extract Data', 
	    	                										'Do You want to Extract Data?', 
	    	                										function (button) {
	    	                									
	    	                									if (button == 'yes') {
	    	                										 Ext.ux.mask.show(); 
	    	                									Ext.Ajax.request({
	    	                				                     		  url : 'transData/getTransExecUniverseDataSearch.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
	    	                				                     		  method: 'POST',
	    	                				                     		 //timeout:120000,
	    	                				                     		 waitMsg : 'Loading...',
	    	                				                     		 params: {
	    	                				                     			"schemeId"   : rs[0].data.schemeId,
			                												"compId"     : rs[0].data.compId,
			                												"condId"     : rsub[0].data.condId,
			                												"condiParam" : subCombo,
			                												"success"    : true
	    	                				                 			    },
	    	                				                 			    
	    	                				                     		    success: function (response) {
	    	                				                     		    	 Ext.ux.mask.hide();
	    	                				                     		    	var jsonResp = Ext.JSON.decode(response.responseText);
	    	                				                    						if(jsonResp.success==false)	
	    	                				                    						{
	    	                				                    						Ext.Msg.alert(jsonResp.errorMessage);
	    	                				                    						}
	    	                				                    						else
	    	                				                    						Ext.Msg.alert("Info",jsonResp.errorMessage);
	    	                				                    				 
																		  gridSub.store.load({params:
																				{
																			    "schemeId"     : rs[0].data.schemeId,
				                												"compId"       : rs[0].data.compId,
				                												"paymentRemarks" : subCombo,
																				}});
			                											    },
	    	                				                     		  failure: function (response) {
	    	                				                     			 Ext.ux.mask.hide();

	    	                				                     			var jsonResp = Ext.JSON.decode(response.responseText);
	    	                				                						if(jsonResp.success==false)	
	    	                				                						{
	    	                				                						Ext.Msg.alert(jsonResp.errorMessage);
	    	                				                						}
	    	                				                						else
	    	                				                						Ext.Msg.alert("Info",jsonResp.errorMessage);
	    	                				                						
	    	                				                						gridSub.store.load({params:
																					{
																				    "schemeId"     : rs[0].data.schemeId,
					                												"compId"       : rs[0].data.compId,
					                												"paymentRemarks" : subCombo,
																					}});
				                											    
	    	                				                			  }
	    	                				                     		 })	;
	    	                									}
	    	                								});
	    	                							}
	    	                						});
	    	                					}
	    	                				}
	    	                			});
	    	                		}, 700);
									return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                },

			                {
			                	header: 'Qualified',dataIndex: 'qualify', width: 80,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function() {
			                			Ext.widget('button', {
			                				renderTo: id,
			                				//		disabled : true,
			                				text: qad,
			                				scale: 'small',
			                				handler: function() {
			                					download(qad);;
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                {
			                	header: 'Not Qualified',dataIndex: 'notQualify', width: 80,
			                	renderer: function (v, m, r) {
			                		var id = Ext.id();
			                		Ext.defer(function() {
			                			Ext.widget('button', {
			                				renderTo: id,
			                				disabled : disValFlag,
			                				text: nqd,
			                				scale: 'small',
			                				handler: function() {
			                					download(nqd);
			                				}
			                			});
			                		}, 700);
			                		return Ext.String.format('<div id="{0}"></div>', id);
			                	}
			                },
			                ];
			this.dockedItems = [];
			this.callParent(arguments);
		},
	});
	
	
	Ext.define('Scheme.controller.TransDataCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['TransDataList','TransSubDataList'],
		init: function () {
		      this.control({
		          
		        'TransDataList': {
		          itemdblclick: this.onRowdblclick
		        }
		        
		      });
		    },
		    
		    onRowdblclick: function(me, record, item, index) {
		    	
		    	//alert("HII");
		    	
		    	var trans = transSubDataStore();
		    	nqd='Not Qualify Data';
		    	qad='Qualify Data';
		    	disValFlag=false;
		    	subCombo = 'TQ';
		    	Ext.getCmp('transSubID').setValue(trans.findRecord('id',1));
		    	var gridSub = Ext.ComponentQuery.query('TransSubDataList')[0];//transSubDataGrid
		    	//gridSub.reconfigure(undefined,mycolumns);
		    	//gridSub.setDisabled(false);
		    	gridSub.store.load({params:
				{
		    		schemeId  :	record.data.schemeId ,
		    		compId    :	record.data.compId,
		    		startDate : record.data.startDtStr,
		    		endDate : record.data.endDtStr
		    		//scmStatus : record.data.scmStatus
		    	}});
		        }
		
	});
	
	
});
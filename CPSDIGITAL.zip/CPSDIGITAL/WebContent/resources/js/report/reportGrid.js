/*Ext.require([
    'Ext.grid.*',
    'Ext.data.*',
    'Ext.util.*',
    'Ext.state.*',
    'Ext.form.*'
]);
*/ 
Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	         ]);
	
var reportloadsd = null;   
var reportloaded = null;
var reportloadfilter = null;
var repPayToId = null;
var reportNameVal=null;
var reportTempId=null;
var validityDays=null;
var genType=null;


function rejectFunction(rejectForm)
{

	rejectForm	.submit({

		waitMsg : 'Loading...',
		url : 'nfa/rejectScheme.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		method : 'POST',

		success: function(form, action) {
			Ext.Msg.alert("Info",action.result.errorMessage);
			rejectForm.close();
			var grid = Ext.ComponentQuery.query('ReportList')[0];	

			grid.store.load({params:
			{
				startDate: reportloadsd,
				endDate: reportloaded,
				schemeComp : Ext.getCmp("schemeNameReport").getValue()!='' ? Ext.getCmp("schemeNameReport").getValue() : 'ABCDEF',
						schemeId : Ext.getCmp("schemeNameIdReport").getValue()!=null ? Ext.getCmp("schemeNameIdReport").getValue() : '-1',
								payTo : repPayToId != null ? repPayToId : '-1',
										componentName : Ext.getCmp("compNameReport").getValue()!='' ? Ext.getCmp("compNameReport").getValue() : 'ABCDEF',
												//filterBy:reportloadfilter,
												isMaster:true,
												isStage:false,
												condParam:reportloadfilter
			}});

		},
		failure: function(form, action) {
			if(action.result != null)
				Ext.Msg.alert('Warning', action.result.errorMessage);
			else
				if(action.response.status=403)
					Ext.Msg.alert('Warning','Access Denied' );
				else
				{
					Ext.Msg.alert('Warning', "Attribite Mapping Error");
				}
		}
	});

}

function download()
{

	var grid = Ext.ComponentQuery.query('ReportList')[0];
	var sm = grid.getSelectionModel();
	var rs = sm.getSelection();
	Ext.Msg.confirm('View Scheme', 
			'Download Scheme CSV', 
			function (button) {
		if (button == 'yes') {
			var urlParam = './csv/downloadValidPayoutReportCSV.action?schemeId='+rs[0].data.schemeINputId +'&compId='+rs[0].data.compId+
			'&toDate='+rs[0].data.endDate+'&fromDate='+rs[0].data.startDate+'&csvType=Payout'+'&compStatus='+rs[0].data.validityFlag;
			window.open(urlParam,'_SELF');

		}
	});
}


function rejectScheme()
{
	var grid = Ext.ComponentQuery.query('ReportList')[0];
	if (grid) {
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		var myForm = new Ext.form.Panel({
			width: 300,
			height: 200,
			//	    layout: 'anchor',
			title: 'Reject Scheme',
			floating: true,
			border: true,
			frame : true,
			closable : true,
			bodyStyle: {
				//  background: 'none',
				padding: '10px',
				border: '0'
			},
			items:[
			       {
			    	   xtype : 'hidden',  //should use the more standard hiddenfield
			    	   name  : 'schemeId',
			    	   value: rs[0].data.schemeINputId
			       },
			       {
			    	   xtype : 'hidden',  //should use the more standard hiddenfield
			    	   name  : 'compId',
			    	   value: rs[0].data.compId
			       },
			       {
			    	   xtype : 'hidden',  //should use the more standard hiddenfield
			    	   name  : 'componentName',
			    	   value: rs[0].data.compName
			       },
			       {
			    	   xtype       : 'combo',
			    	   displayField:'name',
			    	   fieldLabel: 'Reject Type',
			    	   valueField:'id',
			    	   allowBlank  : true,
			    	   name        : 'rejectType',
			    	   editable    : false,
			    	   store: schemeRejectTypeStore(),
			    	   triggerAction:'all'
			       },
			       {
			    	   xtype :'textfield',
			    	   fieldLabel: 'Reject Comment',
			    	   name: 'rejectReason',
			    	   allowBlank:false
			       }
			       ],

			       buttons: [	
			                 {
			                	 text: 'Ok',
			                	 //action: 'add'
			                	 handler: function () { 
			                		 rejectFunction(myForm);
			                		 //myForm.close();
			                	 }
			                 },
			                 {
			                	 text   : 'Cancel',
			                	 handler: function () { 
			                		 myForm.close();
			                	 }
			                 }]

		});
		myForm.show();

	}
}

function approveScheme()
{
	var grid = Ext.ComponentQuery.query('ReportList')[0];
	if (grid) {
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		
		//categoryId
		if(rs[0].data.categoryId == 1){
			Ext.Msg.alert("Warning","<font color='red'>Schemes having 'DEMO' category can not be approved.</font>");
			return false;
		}else{
			Ext.Msg.confirm('Approve Scheme', 
					'If not executed, kindly execute the scheme', 
					function (button) { 
				if (button == 'yes') {	
					Ext.Ajax.request({
						dataType : 'json',
						contentType : 'application/json',
						url : 'nfa/approveScheme.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
						method: 'POST',
						params: {
							"schemeINputId" : rs[0].data.schemeINputId,
							"compId": rs[0].data.compId
						},
						success: function (response) {
							//	Ext.Msg.alert("Info"," Scheme Approved Sucessfully");
							var jsonResp = Ext.JSON.decode(response.responseText);
							//	console.log(jsonResp); 
							if(jsonResp.success==false)	
							{
								Ext.Msg.alert("Error",jsonResp.errorMessage);
							}
							else
								Ext.Msg.alert("Info",jsonResp.errorMessage);

							grid.store.load({params:
							{
								startDate: reportloadsd,
								endDate: reportloaded,
								schemeComp : Ext.getCmp("schemeNameReport").getValue()!='' ? Ext.getCmp("schemeNameReport").getValue() : 'ABCDEF',
										schemeId : Ext.getCmp("schemeNameIdReport").getValue()!=null ? Ext.getCmp("schemeNameIdReport").getValue() : '-1',
												payTo : repPayToId != null ? repPayToId : '-1',
														componentName : Ext.getCmp("compNameReport").getValue()!='' ? Ext.getCmp("compNameReport").getValue() : 'ABCDEF',
																//	filterBy:reportloadfilter,
																isMaster:true,
																isStage:false,
																condParam:reportloadfilter
							}});
						},
						failure: function (response) {
							var jsonResp = Ext.JSON.decode(response.responseText);
							//	console.log(jsonResp); 
							if(jsonResp.success==false)	
							{
								Ext.Msg.alert("Error",jsonResp.errorMessage);
							}
							else
								Ext.Msg.alert("Info",jsonResp.errorMessage);

						}
					});	
				}
			});
		}
	}
}

//Ext.require([ 'Ext.grid.plugin.BufferedRenderer']);
	
	
Ext.define('Scheme.model.Book', {
	extend: 'Ext.data.Model',
	fields: [
	         {name: 'schemeName', type: 'string'},
	         {name: 'circleName',  type: 'string'}
	         ]
});
	
	
	 
var reportschemeSearch = new Ext.Panel({     
	stripeRows  : true,
	frame       : false,
	border		: false,
	style       : 'padding-bottom: 5px',
	layout		:'column',
	anchor		: '100%',
	items       : [{
		xtype       : 'datefield',
		id          : 'startDateReport',
		allowBlank  : true,
		emptyText   : 'From',
		name        : 'startDate',
		//width       : 140,
		editable    : false,
		value : new Date(date.getFullYear(), date.getMonth(), 1)
		// format      : 'dd-MMM-yyyy'
	},
	{
		xtype       : 'datefield',
		id          : 'endDateReport',
		allowBlank  : true,
		emptyText   : 'To',
		name        : 'endDate',
		//width       : 140,
		editable    : false,
		value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
		// format      : 'dd-MMM-yyyy'
	},
	{
		xtype       : 'combo',
		displayField:'name',
		valueField:'id',
		allowBlank  : true,
		name        : 'filterBy',
		editable    : false,
		emptyText   : 'Scheme State',
		store: dumpSchemeFilterStore(),
		listeners: {
			'select': function(combo, value){
					if(combo.getValue()==1)
					{
						reportloadfilter ='A';
					}
					else if(combo.getValue()==2)
					{
						reportloadfilter ='D';
					}
					else if(combo.getValue()==3)
					{
						reportloadfilter ='R';
					}
			}
		},
		triggerAction:'all'
	},
	{
		xtype       : 'textfield',
		id          : 'schemeNameReport',
		allowBlank  : true,
		emptyText   : 'Scheme Name',
		name        : 'schemeComp',
		//width       : 140,
		editable    : true,
		maxLength : 100,
		 //maskRe:/[A-Za-z0-9_- ]/,
    	enforceMaxLength:"true"
		// format      : 'dd-MMM-yyyy'
	},
	{
		xtype       : 'numberfield',
		id          : 'schemeNameIdReport',
		allowBlank  : true,
		emptyText   : 'Scheme ID',
		name        : 'schemeId',
		allowNegative: false,
		//width       : 140,
		editable    : true,
		maxLength : 38,
    	enforceMaxLength:"true"
		// format      : 'dd-MMM-yyyy'
	},
	{
 		xtype       : 'textfield',
 		id          : 'compNameReport',
 		allowBlank  : true,
 		emptyText   : 'Component Name',
 		name        : 'componentName',
 		// maskRe:/[A-Za-z0-9_- ]/,
 		//width       : 140,
 		editable    : true,
 		maxLength : 100,
    	enforceMaxLength:"true"
 		// format      : 'dd-MMM-yyyy'
 	},
	{
  		xtype: 'combo',
  		store:payToStore,
  		emptyText   : 'Pay To',
  		//fieldLabel: 'Table Field',
  		displayField:'displayValue',
  		editable: false,
  		valueField:'entityTypeId',
  		name: 'payTo',
  		//width       : 140,
  		listeners: {
  			'select': function(combo, value){
  				repPayToId = combo.getValue();
  			}
  		}
  	},
  	{
    	   xtype :'textfield',
    	  // fieldLabel: 'CsrfName',
		   hidden:true,
    	   disabled : true,
    	   name: 'csrfAppr',
		   maxLength : 100,
    	   allowBlank:false,
    	   id:'testCsrfAppr'
    }
	,
  	{
  		xtype       : 'button',
  		text        : 'Go',
  		//width       : 40,
  		handler     : function () {
  			var reportNFAscmName = Ext.getCmp("schemeNameReport").getValue()!='' ? Ext.getCmp("schemeNameReport").getValue() : 'ABCDEF';
  			var reportNFAscmId = Ext.getCmp("schemeNameIdReport").getValue()!=null ? Ext.getCmp("schemeNameIdReport").getValue() : '-1';
  			repPayToId = repPayToId != null ? repPayToId : '-1';
  			var grid = Ext.ComponentQuery.query('ReportList')[0];
  			reportloadsd = Ext.Date.format(Ext.getCmp("startDateReport").getValue(),'d-M-Y');
  			reportloaded = Ext.Date.format(Ext.getCmp("endDateReport").getValue(),'d-M-Y');
  			var apprCompName = Ext.getCmp("compNameReport").getValue()!='' ? Ext.getCmp("compNameReport").getValue() : 'ABCDEF';
  			
  			var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateReport").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateReport").getValue(),'Y/m/d'));
  			if(reportloadfilter == null){
  				//Ext.Msg.alert("Warning","<font color='red'>Please Ensure That To Select Aleast One Mode (Ex. Approve Or Draft Or Reject).</font>");
  				Ext.Msg.alert("Warning","<font color='blue'>Please enter 'From Date' , 'To Date' & 'Scheme State'.</font>");
  				return false;
  			}
  			if(flag && reportloadfilter != null){
  				grid.store.load({params:
  				{
  					startDate:Ext.Date.format(Ext.getCmp("startDateReport").getValue(),'d-M-Y') ,
  					endDate: Ext.Date.format(Ext.getCmp("endDateReport").getValue(),'d-M-Y'),
  					schemeComp : reportNFAscmName,
  					schemeId : reportNFAscmId,
  					payTo : repPayToId,
  					componentName : apprCompName,
  					//filterBy:combo.getValue(),
  					isMaster:true,
  					isStage:false,
  					condParam:reportloadfilter,
  					page:1,
					start :	0
  				}});
  			}
  		},
}
	]
});
	

	




	
	
	
 Ext.define('Scheme.view.ReportList', {
    extend: 'Ext.grid.Panel',
    id:'Scheme-Approval',
    stripeRows: true,
    pageSize : 5,
    flex: 2,
   // selModel : Ext.create('Ext.selection.CheckboxModel'),
    hidden: false,
    loadMask: true,
	//bodyStyle:'padding:3px 0px',
//		width:1120,
	layout: 'fit',
		height:'100%',
		loadMask: true,
    alias: 'widget.ReportList',
    title: 'Scheme Approval',
    store: reportStoreGrid,
    autoScroll: true,
    
    initComponent: function () {
    	var me = this;
    	this.tbar = [
    	             reportschemeSearch
    	             ];

    	this.columns = [
    	                
    	                { header: 'Schem Id', dataIndex: 'schemeINputId', flex: 1 },
    	                { header: 'Scheme Name', dataIndex: 'schemeName',autoSizeColumn : true },
    	                { header: 'Comp Id', dataIndex: 'compId', flex: 1 },
    	                { header: 'Component Name', dataIndex: 'compName', flex: 1 },
    	                { header: 'Start Date', dataIndex: 'startDate', flex: 1 },
    	                { header: 'End Date', dataIndex: 'endDate', flex: 1 },
    	                { header: 'Pay To', dataIndex: 'payout', flex: 1 },
    	                { header: 'Create Date', dataIndex: 'insertTime', flex: 1  },
    	                { header: 'Status', dataIndex: 'validityFlag', flex: 1 },//remarks
    	                { header: 'View', flex: 1,
    	                	renderer: function (v, m, r) {
    	                		var id = Ext.id();
    	                		//alert(rs[0].data.schemeINputId);
    	                	//alert(id);
    	                		//var max = 15;
    	                		Ext.defer(function () {
    	                			Ext.widget('image', {
    	                				renderTo: id,
    	                				name: 'download',
    	                				src : 'resources/images/PDFView30.png',
    	                				listeners : {
    	                					afterrender: function (me) {
    	                						me.getEl().on('click', function() {
    	                							var grid = Ext.ComponentQuery.query('ReportList')[0];
    	                							if (grid) {
    	                								var sm = grid.getSelectionModel();
    	                								var rs = sm.getSelection();
    	                								if (!rs.length) {
    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
    	                									return;
    	                								}
    	                								Ext.Msg.confirm('Download Scheme', 
    	                										'You want to download Scheme?', 
    	                										function (button) {
    	                									if (button == 'yes') {
    	                										var urlParam = './reports/downloadPDF.action?'+Ext.getCmp("testCsrfAppr").getValue()+'&output='+rs[0].data.schemeINputId+'&compId='+rs[0].data.compId+'&csvType='+reportloadfilter;
    	                										window.open(urlParam,'_blank');
    	                									}
    	                								});
    	                							}
    	                						});
    	                					}
    	                				}
    	                			});
    	                		}, 700);
    	                		return Ext.String.format('<div id="{0}"></div>', id);
    	                	}
    	                },
						{ header: 'Remarks', dataIndex: 'remarks', flex: 1 },//remarks
    	             //   { header: 'Test Run', dataIndex: 'testRun', width: 100 },
    	                
    	                { header: 'Execute', width: 80,
    	                	renderer: function (v, m, r) {
							//alert('Test');
							if(reportloadfilter=='D')
							{
    	                		var id = Ext.id();
    	                		Ext.defer(function () {
    	                			Ext.widget('image', {
    	                				renderTo: id,
    	                				name: 'testRun',
    	                				src : 'resources/images/book_add.png',
    	                				listeners : {
    	                					afterrender: function (me) {
    	                						me.getEl().on('click', function() {
    	                							var grid = Ext.ComponentQuery.query('ReportList')[0];
    	                							if (grid) {
    	                								var sm = grid.getSelectionModel();
    	                								var rs = sm.getSelection();
    	                								if (!rs.length) {
    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
    	                									return;
    	                								}
    	                								Ext.Msg.confirm('Execute Scheme', 
    	                										'Do You want to Execute Scheme?', 
    	                										function (button) {
    	                									
    	                									if (button == 'yes') {
    	                										 Ext.ux.mask.show(); 
    	                									Ext.Ajax.request({
    	                				                     		  url : 'nfa/testValidateScheme.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
    	                				                     		  method: 'POST',
																	  timeout:150000,
    	                				                     		 waitMsg : 'Loading...',
    	                				                     		 params: {
    	                				                     			 "output":rs[0].data.schemeINputId,
    	                				                     			 "compId":rs[0].data.compId,
    	                				                     			 "condiType":'D',
    	                				                 				  "success" : true
    	                				                 			    },
    	                				                 			    
    	                				                     		    success: function (response) {
    	                				                     		    	 Ext.ux.mask.hide();
    	                				                     		    	var jsonResp = Ext.JSON.decode(response.responseText);
    	                				                    				//	console.log(jsonResp); 
    	                				                    						if(jsonResp.success==false)	
    	                				                    						{
    	                				                    						Ext.Msg.alert(jsonResp.errorMessage);
    	                				                    						}
    	                				                    						else
    	                				                    						Ext.Msg.alert("Info",jsonResp.errorMessage);
    	                				                    				 
																	  grid.store.load({params:
																			{
																				startDate: reportloadsd,
																				endDate: reportloaded,
																				schemeComp : Ext.getCmp("schemeNameReport").getValue()!='' ? Ext.getCmp("schemeNameReport").getValue() : 'ABCDEF',
																	  			schemeId : Ext.getCmp("schemeNameIdReport").getValue()!=null ? Ext.getCmp("schemeNameIdReport").getValue() : '-1',
																	  			payTo : repPayToId != null ? repPayToId : '-1',
																	  			componentName : Ext.getCmp("compNameReport").getValue()!='' ? Ext.getCmp("compNameReport").getValue() : 'ABCDEF',
																			//	filterBy:reportloadfilter,
																				isMaster:true,
																				isStage:false,
																				condParam:reportloadfilter
																				}});
		                													//console.log(response);
    	                				                     		    },
    	                				                     		  failure: function (response) {
    	                				                     			 Ext.ux.mask.hide();

    	                				                     			var jsonResp = Ext.JSON.decode(response.responseText);
    	                				                				//	console.log(jsonResp); 
    	                				                						if(jsonResp.success==false)	
    	                				                						{
    	                				                						Ext.Msg.alert(jsonResp.errorMessage);
    	                				                						}
    	                				                						else
    	                				                						Ext.Msg.alert("Info",jsonResp.errorMessage);
    	                				                				

    	  																	  grid.store.load({params:
    	  																			{
    	  																				startDate: reportloadsd,
    	  																				endDate: reportloaded,
    	  																				schemeComp : Ext.getCmp("schemeNameReport").getValue()!='' ? Ext.getCmp("schemeNameReport").getValue() : 'ABCDEF',
    	  																	  			schemeId : Ext.getCmp("schemeNameIdReport").getValue()!=null ? Ext.getCmp("schemeNameIdReport").getValue() : '-1',
    	  																	  			payTo : repPayToId != null ? repPayToId : '-1',
    	  																	  			componentName : Ext.getCmp("compNameReport").getValue()!='' ? Ext.getCmp("compNameReport").getValue() : 'ABCDEF',
    	  																			//	filterBy:reportloadfilter,
    	  																				isMaster:true,
    	  																				isStage:false,
    	  																				condParam:reportloadfilter
    	  																				}});	
    	                											  }
    	                				                     		 })	;
    	                									}
    	                								}
    	                										
    	                				                     		 
    	                				                     		 );
    	                							}
    	                						});
    	                					}
    	                				}
    	                			});
    	                		}, 700);
    	                		return Ext.String.format('<div id="{0}"></div>', id);
								}
    	                	}
    	                },
    	                {
    	                	header: 'Last Execution',dataIndex: 'executionDate', flex: 1,
    	                	renderer: function (v, m, r) {
    	                		var id = Ext.id();
    	                		if(v!=null)
    	                		{
    	                			Ext.defer(function() {
    	                				Ext.widget('button', {
    	                					renderTo: id,
    	                					text: v,
    	                					scale: 'small',
    	                					handler: function() {
    	                						download();
    	                					}
    	                				});
    	                			}, 700);
    	                		}
    	                		else
    	                		{
    	                			Ext.defer(function() {
    	                				Ext.widget('button', {
    	                					renderTo: id,
    	                					disabled : true,
    	                					text: 'Not Executed',
    	                					scale: 'small',
    	                					handler: function() {
    	                					}
    	                				});
    	                			}, 700);
    	                		}
    	                		return Ext.String.format('<div id="{0}"></div>', id);
    	                	}
    	                },
    	                {
    	                	header: 'Approve',dataIndex: 'executionDate', flex: 1,
    	                	renderer: function (v, m, r) {
    	                		var id = Ext.id();
    	                		if(reportloadfilter=='D')
    							{
    	                		Ext.defer(function() {
    	                			Ext.widget('button', {
    	                				renderTo: id,
    	                				//		disabled : true,
    	                				text: 'Approve',
										//src : 'resources/images/approve.png',
    	                				scale: 'small',
    	                				handler: function() {
    	                					approveScheme();
    	                				}
    	                			});
    	                		}, 700);
    	                		
    							}
    	                		return Ext.String.format('<div id="{0}"></div>', id);
    	                	}
    	                },
    	                {
    	                	header: 'Reject',dataIndex: 'executionDate', flex: 1,
    	                	renderer: function (v, m, r) {
    	                		var id = Ext.id();
    	                		if(reportloadfilter=='D')
    							{
    	                		Ext.defer(function() {
    	                			Ext.widget('button', {
    	                				renderTo: id,
    	                				//	disabled : true,
    	                				//src : 'resources/images/reject.png',
										text : 'Reject',
    	                				scale: 'small',
    	                				handler: function() {
    	                					rejectScheme();
    	                				}
    	                			});
    	                		}, 700);
    	                		
    							}
    	                		return Ext.String.format('<div id="{0}"></div>', id);
    	                	}
    	                }
    	                ];
    	this.dockedItems = [ {
    		xtype : 'pagingtoolbar',
    		store : reportStoreGrid,
    		dock : 'bottom',
    		pageSize:10, 
    		displayInfo : true
    	}
    	];
    	this.callParent(arguments);
    },
    onTextFieldChange: function(field, newValue, oldValue, options){
       // var grid = Ext.getCmp('schemeGrid');
        if(newValue==''){
        	reportStoreGrid.clearFilter();
        }
        else {
        	reportStoreGrid.clearFilter(true);
   
			if(newValue.length>=4){
        		reportStoreGrid.filter("schemeName",newValue);
        	}
        }
    }
    
  });


Ext.define('Scheme.controller.ReportCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    
    views   : ['ReportList'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'ReportList',
      selector: 'ReportList',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'ReportList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
          
        'ReportList': {
         // itemdblclick: this.onRowdblclick
        }
      });
    }
    
  });
});

function scmStatusStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['idReport', 'nameReport'],
        data: [['1', 'Approved'], ['2', 'Draft'],['3', 'Rejected']]
    });
    return store;
}

function payoutStatusStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['idPayout', 'namePayout'],
        data: [['1', 'A'], ['2', 'N']]
    });
    return store;
}

function paymentStatusStore() {
    var store = new Ext.data.SimpleStore({
        fields: ['idPayment', 'namePayment'],
        data: [['1', 'U'], ['2', 'P']]
    });
    return store;
}


var dateReportGeneration=new Ext.Panel({
	stripeRows  : true,
	frame       : false,
	border		: false,
	style       : 'padding-bottom: 5px',
	layout		:'column',
	anchor		: '100%',
	items:[
	       {
	    	   xtype:'fieldset',
	    	   layout:'column',
	    	   title:'Report Category',
	    	   items:
	    		   [
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Report Category',
	    		    	items:
	    		    		[{
	    		    			xtype:'combo',
	    		    			store:reportCategoryStore,
	    		    			name:'categoryName',
	    		    			valueField:'categoryId',
	    		    			displayField:'categoryName',
	    		    			triggerAction:'all',
	    		    			allowBlank:false,
	    		    			editable:false,
	    		    			id:'categoryId',
	    		    			emptyText:'Category',
	    		    			listeners:
	    		    			{
	    		    				'select': function(combo,value)
	    		    				{
	    		    					var value=combo.getValue();
	    		    					reportNameStore.clearFilter();
	    		    					Ext.getCmp("reportNameId").setValue("");
	    		    					reportNameStore.filter("reportInputCategory",combo.getValue());
	    		    				
	    		    					if(value==3)
	    		    						Ext.getCmp("reportCatDownload").enable();
	    		    					else
	    		    						Ext.getCmp("reportCatDownload").disable();

	    		    					if(value==1)
	    		    						Ext.getCmp("schemeBasedReportGen").enable();
	    		    					else
	    		    						Ext.getCmp("schemeBasedReportGen").disable();

	    		    					if(value==2)
	    		    						Ext.getCmp("monthBasedReportGen").enable();
	    		    					else
	    		    						Ext.getCmp("monthBasedReportGen").disable();
	    		    				
	    		    				}  
	    		    			}
	    		    		}]				 
	    		    },
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Report Name',
	    		    	items:
	    		    		[{
	    		    			xtype:'combo',
	    		    			store:reportNameStore,
	    		    			name:'reportName',
	    		    			valueField:'reportName',
	    		    			displayField:'reportName',
	    		    			triggerAction:'all',
	    		    			allowBlank:false,
	    		    			editable:false,
	    		    			emptyText:'Report Name',
	    		    			id:'reportNameId',
	    		    			width:'400',
	    		    			listeners:
	    		    			{
	    		    				'select': function(combo,value)
	    		    				{
	    		    					reportNameVal=combo.getValue();
	    		    					var tempRecord=reportNameStore.findRecord('reportName',reportNameVal);
	    		    					Ext.getCmp("lastGenDateTime").setValue(tempRecord.data.reportLastGenDateTime); 
	    		    					reportTempId=tempRecord.data.reportId;
	    		    					validityDays=tempRecord.data.duration;
	    		    					genType=tempRecord.data.reportGenType;
	    		    					
	    		    					if(((tempRecord.data.reportLastGenDateTime==null || tempRecord.data.reportLastGenDateTime=="") && Ext.getCmp("categoryId").getValue()!=3))
	    		    						Ext.getCmp("reportCatDownload").disable();
	    		    					else
	    		    						Ext.getCmp("reportCatDownload").enable();
	    		    					
	    		    					if(tempRecord.data.reportGenType==3)
	    		    						Ext.getCmp("reportExtractId").enable();
	    		    					else
	    		    						Ext.getCmp("reportExtractId").disable();
	    		    				}
	    		    			}
	    		    		}]	

	    		    },
	    		    { xtype:'fieldset',
	    		    	title:'Last Gen Date Time',
	    		    	items:
	    		    		[{
	    		    			xtype:'textfield',
	    		    			id:'lastGenDateTime',
	    		    			editable:false,
	    		    			emptyText:'Last Gen Date'
	    		    		}]	
	    		    },
	    		    { xtype:'fieldset',
	    		    	title:'Download',
	    		    	items:
	    		    		[{
	    		    			xtype:'button',
	    		    			text:'Download',
	    		    			id:'reportCatDownload',
	    		    			disabled:true,
	    		    			name:'downloadFile',	
	    		    			handler:function()
	    		    			{
	    		    				Ext.Msg.confirm('Report', 
	    		    						'Do You want to Download Report', 
	    		    						function (button) {
	    		    					if (button == 'yes') {
	    		    						var urlParam = './reports/downloadReport.action?reportId='+reportTempId;
	    		    						window.open(urlParam,'_SELF');

	    		    					}
	    		    				});
	    		    			}
	    		    		}]	
	    		    },
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Extract',
	    		    	items:
	    		    		[{
	    		    			xtype:'button',
	    		    			text:'Extract',
	    		    			id:'reportExtractId',
	    		    			disabled:'true',
	    		    			handler:function()
	    		    			{
	    		    				Ext.Msg.alert('Info','Request taken - Report will be available within couple of hours');
	    		    			}
	    		    		}]	
	    		    }
	    		    ]




	       },
	       {
	    	   xtype:'fieldset',
	    	   layout:'column',
	    	   title:'Scheme Based',
	    	   id:'schemeBasedReportGen',
	    	   disabled:true,
	    	   items:
	    		   [
	    		    {

	    		    	xtype:'fieldset',
	    		    	title:'Scheme Id',
	    		    	items:
	    		    		[{
	    		    			xtype:'numberfield',
	    		    			emptyText:'Scheme Id',
	    		    			id:'reportSchemeId',
	    		    			maxLength : 38,
	    		    			enforceMaxLength:"true",
	    		    			listeners: 
	    		    			{
	    		    				'change':function(field,newValue,oldValue)
	    		    				{
	    		    					if(newValue!=null && newValue!="")
	    		    					{
	    		    						Ext.getCmp("reportSchemeStartDate").disable();
	    		    						Ext.getCmp("reportSchemeEndDate").disable();
	    		    						Ext.getCmp("reportSchemeStatus").disable();
	    		    						Ext.getCmp("reportPaymentStatus").disable();
	    		    						Ext.getCmp("reportPayoutStatus").disable();
	    		    						Ext.getCmp("reportEntityType").disable();
	    		    						Ext.getCmp("reportScmCategory").disable();
	    		    						Ext.getCmp("reportSchemeStartDate").setValue("");
	    		    						Ext.getCmp("reportSchemeEndDate").setValue("");
	    		    						Ext.getCmp("reportSchemeStatus").setValue("");
	    		    						Ext.getCmp("reportPaymentStatus").setValue("");
	    		    						Ext.getCmp("reportPayoutStatus").setValue("");
	    		    						Ext.getCmp("reportEntityType").setValue("");
	    		    						Ext.getCmp("reportScmCategory").setValue("");
	    		    					}
	    		    					else
	    		    					{
	    		    						Ext.getCmp("reportSchemeStartDate").enable();
	    		    						Ext.getCmp("reportSchemeEndDate").enable();
	    		    						Ext.getCmp("reportSchemeStatus").enable();
	    		    						Ext.getCmp("reportPaymentStatus").enable();
	    		    						Ext.getCmp("reportPayoutStatus").enable();
	    		    						Ext.getCmp("reportEntityType").enable();
	    		    						Ext.getCmp("reportScmCategory").enable();
	    		    					}
	    		    				}
	    		    			}
	    		    		}]				 
	    		    },
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Component Id',
	    		    	items:
	    		    		[{
	    		    			xtype:'numberfield',
	    		    			id:'reportCompId',
	    		    			emptyText:'Comp Id',
	    		    			maxLength : 38,
	    		    			enforceMaxLength:"true"
	    		    		}]	

	    		    },
	    		    { xtype:'fieldset',
	    		    	title:'Scheme Start Date',
	    		    	items:
	    		    		[{
	    		    			xtype:'datefield',
	    		    			id:'reportSchemeStartDate',
	    		    			emptyText:'Start Date',
	    		    			listeners:
	    		    			{
	    		    				'select': function(combo,value)
	    		    				{
	    		    					var d=new Date(combo.getValue().getFullYear(),combo.getValue().getMonth()+1,0);
	    		    					Ext.getCmp("reportSchemeEndDate").setValue(d);
	    		    					Ext.getCmp("reportSchemeStatus").setValue("All");
	    		    					Ext.getCmp("reportPaymentStatus").setValue("All");
	    		    					Ext.getCmp("reportPayoutStatus").setValue("All");
	    		    					Ext.getCmp("reportEntityType").setValue("All");
	    		    					Ext.getCmp("reportScmCategory").setValue("All");
	    		    					Ext.getCmp("reportSchemeId").disable();
	    		    					Ext.getCmp("reportCompId").disable();
	    		    					Ext.getCmp("reportSchemeId").setValue("");
	    		    					Ext.getCmp("reportCompId").setValue("");
	    		    				}
	    		    			}
	    		    		}]	
	    		    },
	    		    { xtype:'fieldset',
	    		    	title:'Scheme End Date',
	    		    	items:
	    		    		[{
	    		    			xtype:'datefield',
	    		    			id:'reportSchemeEndDate',
	    		    			emptyText:'End Date'
	    		    		}]	
	    		    },
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Scheme Status',
	    		    	items:
	    		    		[{
	    		    			xtype       : 'combo',
	    		    			displayField:'nameReport',
	    		    			id:'reportSchemeStatus',
	    		    			valueField:'nameReport',
	    		    			allowBlank  : true,
	    		    			name        : 'nameReport',
	    		    			editable    : false,
	    		    			emptyText   : 'Scheme Status',
	    		    			store: scmStatusStore(),
	    		    			triggerAction:'all',
	    		    			value:'All'
	    		    		}]	 

	    		    },
	    		    { xtype:'fieldset',
	    		    	title:'Payout Status',
	    		    	items:
	    		    		[{
	    		    			xtype:'combo',
	    		    			id:'reportPayoutStatus',
	    		    			valueField:'namePayout',
	    		    			displayField:'namePayout',
	    		    			store: payoutStatusStore(),
	    		    			emptyText:'Payout Status',
	    		    			value:'All'
	    		    		}]	
	    		    },
	    		    { xtype:'fieldset',
	    		    	title:'Payment Status',
	    		    	items:
	    		    		[{
	    		    			xtype:'combo',
	    		    			id:'reportPaymentStatus',
	    		    			valueField:'namePayment',
	    		    			displayField:'namePayment',
	    		    			store: paymentStatusStore(),
	    		    			emptyText:'Payment Status',
	    		    			value:'All'
	    		    		}]	
	    		    },
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Entity Type',
	    		    	items:
	    		    		[{
	    		    			xtype:'combo',
	    		    			id:'reportEntityType',
	    		    			displayField:'entityName',
	    		    			valueField:'entityName',
	    		    			store:entityStoreEa,
	    		    			emptyText:'Entity',
	    		    			value:'All'
	    		    		}]	
	    		    },
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Scm Category',
	    		    	items:
	    		    		[{
	    		    			xtype:'combo',
	    		    			id:'reportScmCategory',
	    		    			emptyText:'Category',
	    		    			value:'All',
	    		    			store:scmCategoryStore,
	    		    			valueField:'scmCategoryName',
	    		    			displayField:'scmCategoryName'
	    		    		}]	

	    		    }, 
	    		    {xtype:'fieldset',
	    		    	title:'Submit',
	    		    	items:
	    		    		[{
	    		    			xtype:'button',
	    		    			text:'Submit',
	    		    			handler: function()
	    		    			{
	    		    				var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("reportSchemeStartDate").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("reportSchemeEndDate").getValue(),'Y/m/d'));

	    		    				if(flag)
	    		    				{
	    		    					var delta=Date.parse(Ext.getCmp("reportSchemeEndDate").getValue())-Date.parse(Ext.getCmp("reportSchemeStartDate").getValue());
	    		    					var days=parseInt(delta/86400000).toString();
	    		    					if(Ext.getCmp("reportSchemeId").getValue()==null && Ext.getCmp("reportSchemeStartDate").getValue()==null)
	    		    					{
	    		    						Ext.Msg.alert('Alert','Please provide scheme id/scheme start date');
	    		    						return;
	    		    					}
	    		    					if(days>validityDays)
	    		    					{
	    		    						Ext.Msg.alert('Alert','Difference between start date and end date should be below:'+validityDays);
	    		    						return;
	    		    					}
	    		    					if(Ext.getCmp("reportNameId").getValue()==null)	
	    		    					{
	    		    						Ext.Msg.alert('Alert','Please provide Report Name');
	    		    						return;

	    		    					} 
	    		    					else
	    		    					{
	    		    						if(genType==1)
	    		    						{

	    		    							Ext.Msg.confirm('Report', 
	    		    									'Do You want to Download Report', 
	    		    									function (button) {
	    		    								if (button == 'yes') {
	    		    									var urlParam = './reports/downloadSchemeReport.action?schemeId='+Ext.getCmp("reportSchemeId").getValue()+'&compId='+Ext.getCmp("reportCompId").getValue()+'&scmStartDate='+Ext.Date.format(Ext.getCmp("reportSchemeStartDate").getValue(),'d-M-y')+'&scmEndDate='+Ext.Date.format(Ext.getCmp("reportSchemeEndDate").getValue(),'d-M-y')+
	    		    									'&scmStatus='+Ext.getCmp('reportSchemeStatus').getValue()+'&payoutStatus='+Ext.getCmp('reportPayoutStatus').getValue()+'&paymentStatus='+
	    		    									+Ext.getCmp('reportPaymentStatus').getValue()+'&entityType='+Ext.getCmp('reportEntityType').getValue()+'&scmCategory='+
	    		    									+Ext.getCmp('reportScmCategory').getValue()+'&genType='+genType+'&reportName='+Ext.getCmp("reportNameId").getValue();
	    		    									window.open(urlParam,'_SELF');
	    		    								}
	    		    							});

	    		    						}
	    		    						else
	    		    							Ext.Ajax.request({
	    		    								dataType : 'json',
	    		    								contentType : 'application/json',
	    		    								url : 'reports/callProcReportScheme.action',
	    		    								params: {
	    		    									"schemeId" : Ext.getCmp("reportSchemeId").getValue(),
	    		    									"compId": Ext.getCmp("reportCompId").getValue(),
	    		    									"scmStartDate":Ext.Date.format(Ext.getCmp("reportSchemeStartDate").getValue(),'d-M-y'),
	    		    									"scmEndDate": Ext.Date.format(Ext.getCmp("reportSchemeEndDate").getValue(),'d-M-y'),
	    		    									"scmStatus":Ext.getCmp("reportSchemeStatus").getValue(),
	    		    									"payoutStatus":Ext.getCmp("reportPayoutStatus").getValue(),
	    		    									"paymentStatus":Ext.getCmp("reportPaymentStatus").getValue(),
	    		    									"entityType":Ext.getCmp("reportEntityType").getValue(),
	    		    									"scmCategory":Ext.getCmp("reportScmCategory").getValue(),
	    		    									"reportName":Ext.getCmp("reportNameId").getValue(),
	    		    									"genType":genType
	    		    								},
	    		    								success: function (response) {
	    		    									var jsonResp = Ext.JSON.decode(response.responseText);
	    		    									Ext.Msg.alert('Info',jsonResp.resMessage);

	    		    								},
	    		    								failure: function (response) {}
	    		    							});	
	    		    					}

	    		    				}
	    		    			}
	    		    		}]	

	    		    }
	    		    ] 
	       },
	       {
	    	   xtype:'fieldset',
	    	   layout:'column',
	    	   title:'Month Based',
	    	   id:'monthBasedReportGen',
	    	   disabled:true,
	    	   items:
	    		   [
	    		    { xtype:'fieldset',
	    		    	title:'Start Date',
	    		    	items:
	    		    		[{
	    		    			xtype:'datefield',
	    		    			allowBlank:false,
	    		    			id:'monthBasedstartDate',
	    		    			editable: false,
	    		    			listeners:
	    		    			{
	    		    				'select': function(combo,value)
	    		    				{
	    		    					var d=new Date(combo.getValue().getFullYear(),combo.getValue().getMonth()+1,0);
	    		    					Ext.getCmp("monthBasedEndDate").setValue(d);
	    		    				}
	    		    			}
	    		    		}]	
	    		    },
	    		    { xtype:'fieldset',
	    		    	title:'End Date',
	    		    	items:
	    		    		[{
	    		    			xtype:'datefield',
	    		    			id:'monthBasedEndDate',
	    		    			editable: false
	    		    		}]	
	    		    },
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Entity Id',
	    		    	items:
	    		    		[{
	    		    			xtype:'textfield',
	    		    			displayField:'entityName',
	    		    			valueField:'entityName',
	    		    			store:entityStoreEaReport,
	    		    			id:'monthBasedEntityId',
	    		    			maxLength : 50,
	    		    			enforceMaxLength:"true",
	    		    			listeners:
	    		    			{
	    		    				'change':function(field,newValue,oldValue)
	    		    				{
	    		    					if(newValue!=null && newValue!="")
	    		    					{
	    		    						Ext.getCmp("monthBasedConNo").disable();
	    		    						Ext.getCmp("monthBasedConNo").setValue("");
	    		    					}
	    		    					else
	    		    					{
	    		    						Ext.getCmp("monthBasedConNo").enable(); 
	    		    					}
	    		    				}

	    		    			}
	    		    		}]	 

	    		    },
	    		    { xtype:'fieldset',
	    		    	title:'Contact No.',
	    		    	items:
	    		    		[{
	    		    			xtype:'numberfield',
	    		    			id:'monthBasedConNo',
	    		    			maxLength : 38,
	    		    			enforceMaxLength:"true",
	    		    			listeners:
	    		    			{
	    		    				'change':function(field,newValue,oldValue)
	    		    				{

	    		    					if(newValue!=null && newValue!="")
	    		    					{
	    		    						Ext.getCmp("monthBasedEntityId").setValue("");
	    		    						Ext.getCmp("monthBasedEntityId").disable();
	    		    					}

	    		    					else
	    		    						Ext.getCmp("monthBasedEntityId").enable(); 
	    		    				}

	    		    			}
	    		    		}]	
	    		    },
	    		    {
	    		    	xtype:'fieldset',
	    		    	title:'Entity Type',
	    		    	items:
	    		    		[{
	    		    			xtype:'combo',
	    		    			displayField:'entityName',
	    		    			valueField:'entityName',
	    		    			store:entityStoreEaReport,
	    		    			emptyText:'Entity',
	    		    			value:'All',
	    		    			id:'monthEntityType'
	    		    		}]	
	    		    },
	    		    {xtype:'fieldset',
	    		    	title:'Submit',
	    		    	items:
	    		    		[{
	    		    			xtype:'button',
	    		    			text:'Submit',
	    		    			handler: function()
	    		    			{
	    		    				if(Ext.getCmp("monthBasedstartDate").getValue()==null || Ext.getCmp("monthBasedstartDate").getValue()=="")
	    		    				{
	    		    					Ext.Msg.alert('Alert','Please provide Start Date');
	    		    					return;
	    		    				}
	    		    				var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("monthBasedstartDate").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("monthBasedEndDate").getValue(),'Y/m/d'));
	    		    				if(flag)
	    		    				{
	    		    					if(Ext.getCmp("reportNameId").getValue()==null)	
	    		    						Ext.Msg.alert('Alert','Please provide Report Name');

	    		    					else
	    		    					{
	    		    						if(genType==1)
	    		    						{

	    		    							Ext.Msg.confirm('Report', 
	    		    									'Do You want to Download Report', 
	    		    									function (button) {
	    		    								if (button == 'yes') {
	    		    									var urlParam = './reports/downloadMonthReport.action?monthBasedstartDate='+Ext.Date.format(Ext.getCmp("monthBasedstartDate").getValue(),'d-M-y')+'&monthBasedEndDate='+Ext.Date.format(Ext.getCmp("monthBasedEndDate").getValue(),'d-M-y')+'&monthBasedEntityId='+Ext.getCmp("monthBasedEntityId").getValue()+'&monthBasedConNo='+Ext.getCmp("monthBasedConNo").getValue()+
	    		    									'&monthEntityType='+Ext.getCmp('monthEntityType').getValue()+'&reportName='+Ext.getCmp('reportNameId').getValue()+'&genType='+genType;
	    		    									window.open(urlParam,'_SELF');
	    		    								}
	    		    							});

	    		    						}
	    		    						else
	    		    							Ext.Ajax.request({
	    		    								dataType : 'json',
	    		    								contentType : 'application/json',
	    		    								url : 'reports/callProcMonthScheme.action',
	    		    								params: {
	    		    									"monthBasedstartDate" : Ext.Date.format(Ext.getCmp("monthBasedstartDate").getValue(),'d-M-y'),
	    		    									"monthBasedEndDate": Ext.Date.format(Ext.getCmp("monthBasedEndDate").getValue(),'d-M-y'),
	    		    									"monthBasedEntityId":Ext.getCmp("monthBasedEntityId").getValue(),
	    		    									"monthBasedConNo": Ext.getCmp("monthBasedConNo").getValue(),
	    		    									"monthEntityType":Ext.getCmp("monthEntityType").getValue(),
	    		    									"reportName":Ext.getCmp("reportNameId").getValue(),
	    		    									"genType":genType
	    		    								},
	    		    								success: function (response) {
	    		    									var jsonResp = Ext.JSON.decode(response.responseText);
	    		    									Ext.Msg.alert('Info',jsonResp.resMessage);

	    		    								},
	    		    								failure: function (response) {}
	    		    							});	
	    		    					}

	    		    				}

	    		    			}
	    		    		}]	

	    		    }
	    		    ]
	       }
	       ]





});


var dataReportGen=Ext.create('Ext.form.Panel',
		{
			border:true,
			id: 'Report',
			layout:'fit',
			items:
				[
				 {
					 xtype:'tabpanel',
					 id:'dataReportGenId',
					 layout:'fit',
					 items:
						 [
						  {
							  title :'Report',
							  id: 'reportCatId',
							  items:
								  [dateReportGeneration]
						  }
						  ]
				 }
				 ]
		}		
		);




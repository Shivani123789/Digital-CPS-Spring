Ext.require([
    'Ext.panel.*',
    'Ext.toolbar.*',
    'Ext.button.*',
    'Ext.container.ButtonGroup',
    'Ext.layout.container.Table',
    'Ext.tip.QuickTipManager'
]);

var radioVariable=1;

function saveUploadFile(bulkForm)
{
	//var fileExt=Ext.getCmp("uploadDocFile").getValue().split(".");
	//if((Ext.getCmp("docFileType").getValue()=='Mail List' && fileExt[1]=='csv') || Ext.getCmp("docFileType").getValue()=='NFA DOC')
	//{
		bulkForm.submit({
			waitMsg : 'Loading...',
			url: 'bulkUpload/docFileUpload.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
			enctype : 'multipart/form-data',
			headers: {'Content-Type':'multipart/form-data;'},
			method : 'POST',
			success: function(form,action) {
				Ext.Msg.alert('Info', action.result.outputMsg);
				//form.reset();
			},
			failure:function(form,action)
			{
				Ext.Msg.alert('Warning', '<font color="red">'+action.result.outputMsg+'</font>');
			}
		});	
	//}
	/*else
	{
		Ext.Msg.alert('Error','Please provide valid input file');
	}*/
}
var	uploadEmailDocument=Ext.create('Ext.form.Panel', {
	waitMsg : 'Loading...',
	enctype : 'multipart/form-data', 
	headers: {'Content-Type':'multipart/form-data;'},
	border: false,
	width: '98%',
	bodyStyle:'padding:3px 0px',
	items:[
	       {
	    	   xtype:'fieldset',
	    	   title: 'Upload Document',
	    	   collapsible: true,
	    	   layout: 'anchor',
	    	   width: '100%',
	    	   items:
	    		   [
	    		    {
	    		    	border:false,
	    		    	layout:'column',
	    		   items:[
	    		    {
	    		    	xtype: 'fileuploadfield',
	    		    	width:700,
	    		    	fieldLabel:'File*',
	    		    	displayField:'uploadDocFile',
	    		    	buttonText: 'Browse...',
	    		    	name:'uploadDocFile',
	    		    	emptyText: 'Select a document to upload...',
	    		    	allowBlank:false,
	    		    	id:'uploadDocFile'
	    		    },
	    			 {
	    					xtype:'fieldset',
	    					html:'Note: File size should not exceed 5 MB.',
	    					border:false
	    			}
	    		    ]},
	    		    {
	    		    	xtype:'combo',
	    		    	displayField:'docFileType',
	    		    	allowBlank:'false',
	    		    	fieldLabel:'File Type*',
	    		    	name:'docFileType',
	    		    	valueField:'typeId',
	    		    	store:docTypeList,
	    		    	allowBlank:false,
	    		    	emptyText:'File Type',
	    		    	id:'docFileType'
	    		    },
	    		    {
	    		    	xtype:'button',
	    		    	text:'Upload',
	    		    	handler: function()
	    		    	{
	    		    		saveUploadFile(uploadEmailDocument);
	    		    	}
	    		    }
	    		    ]
	       }]
});
var val1=Ext.create('Ext.grid.Panel', {
	renderTo: document.body,
	store: uploadDataStore,
	width: 800,
	height:380,
	title: 'Upload Details',
	id:'uploadDataGrid',
	columns: [
	         
	          {
	        	  text: 'File Name',
	        	  dataIndex: 'dataFileName',
	        	  width:400
	          },
	          {
	        	  text: 'Date',
	        	  dataIndex: 'insertedDate'
	          },
	          {
	        	  text: 'User',
	        	  dataIndex: 'userId'
	          }
	          ]
});

var val2=Ext.create('Ext.grid.Panel', {
	renderTo: document.body,
	store: mailDataStore,
	height:380,
	width:1150,
	title: 'Mail Details',
	id:'mailDataGrid',
	hidden:true,
	columns: [
	          {
	        	  text: 'File name',
	        	  dataIndex: 'dataFileName',
	        	  width:300
	          },
	          {
	        	  text: 'DSM Ref Code',
	        	  dataIndex: 'dsm2RefCode',
	          },
	          {
	        	  text: 'Date',
	        	  dataIndex: 'mailInsertDate'
	          },
	          {
	        	  text: 'E-Mail',
	        	  dataIndex: 'email',
	        	  width:250
	          },
	          {
	        	  text: 'Send status (Scheme Studio)',
	        	  dataIndex: 'mailSendStatus'
	          },
	          {
	        	  text: 'Mail status',
	        	  dataIndex: 'mailStatus' 
	          },
	          {
	        	  text: 'Send date (Scheme Studio)',
	        	  dataIndex: 'sendDate'
	          },
	          {
	        	  text: 'Error message',
	        	  dataIndex: 'errorMsg'
	          }
	          ]
});
var viewUploadEmailStatus = new Ext.Panel({
	//stripeRows : true,
	//frame : false,
	border : false,
	// style : 'padding-bottom: 5px',
	//layout : 'column',
	anchor : '100%',
	items : [ {
		xtype : 'fieldset',
		layout : 'column',
		title : 'Search Criteria',
		height : 70,
		width : '100%',
		bodyStyle : 'padding:3px 0px',
		collapsible : true,
		items : [ {
			xtype : 'fieldset',
			title : 'Upload / Mail',
			layout : 'column',
			items : [ {
				xtype : 'radiogroup',
				id:'uploadTypeStatus',
				items : [ {
					boxLabel : 'Upload',
					width : 100,
				//	padding : '0px 50px ',
					inputValue:1,
					name:'uploadTypeStatus',
					checked:true
				}, {
					boxLabel : 'Mail',
					width : 50,
					padding : '0px 40px ',
					inputValue:2,
					name:'uploadTypeStatus'
				}],
				listeners:
				{
					change: function(obj,value){
						if(value.uploadTypeStatus==1)
						{
							radioVariable=1;
							mailDataStore.removeAll();
							Ext.getCmp("mailDataGrid").hide();
							Ext.getCmp("uploadDataGrid").show();
							Ext.getCmp("entityFieldSet").hide();
							Ext.getCmp("sendStatusFieldSet").hide();
							Ext.getCmp("mailStatusFieldSet").hide();
						}
						else
						{
							radioVariable=2;
							uploadDataStore.removeAll();
							Ext.getCmp("mailDataGrid").show();
							Ext.getCmp("uploadDataGrid").hide();
							Ext.getCmp("entityFieldSet").show();
							Ext.getCmp("sendStatusFieldSet").show();
							Ext.getCmp("mailStatusFieldSet").show();
						}
					}
				}
			},
			]
		}, {
			xtype : 'fieldset',
			title : 'Start date',
			collapsable : false,
			layout : 'column',
			height : 45,
			items : [ {
				xtype : 'datefield',
				emptyText : 'Start date',
				name:'startDateStatus',
				id:'startDateStatus',
				allowBlank  : false
			}
			]
		}, {
			xtype : 'fieldset',
			title : 'End date',
			collapsable : false,
			layout : 'column',
			height : 45,
			items : [ {
				xtype : 'datefield',
				emptyText : 'End date',
				name:'endDateStatus',
				id:'endDateStatus',
				allowBlank  : false
			}
			]
		}, {
			xtype : 'fieldset',
			title : 'File name',
			collapsable : false,
			layout : 'column',
			height : 45,
			items : [ {
				xtype : 'textfield',
				emptyText : 'File name',
				name:'dataFileName',
				width : 200,
				id:'dataFileName',
				//maskRe:/[A-Za-z0-9_,-. ]/,
			}
			]
		}
		]
	}, {
		xtype : 'fieldset',
		layout : 'column',
		collapsable : true,
		height : 70,
		width : '100%',
		bodyStyle : 'padding:3px 0px',
		items : [ {
			xtype : 'fieldset',
			title : 'Entity',
			collapsable : 'false',
			layout : 'column',
			height : 45,
			id:'entityFieldSet',
			hidden:true,
			items : [ {
				xtype : 'textfield',
				emptyText : 'DSM Ref Code',
				width : 150,
				name:'dsm2RefCode',
				id:'dsm2RefCode'
			}
			] 
		}, {
			xtype : 'fieldset',
			title : 'Send status',
			collpasable : 'false',
			layout : 'column',
			height : 45,
			id:'sendStatusFieldSet',
			hidden:true,
			items : [ {
				xtype : 'textfield',
				emptyText : 'Send status',
				width : 150,
				name:'mailSendStatus',
				id:'sendDocStatus'
			}
			]
		}, {
			xtype : 'fieldset',
			title : 'Mail status',
			collpasable : 'false',
			layout : 'column',
			height : 45,
			id:'mailStatusFieldSet',
			hidden:true,
			items : [ {
				xtype : 'textfield',
				emptyText : 'Mail status',
				width : 150,
				name:'mailStatus',
				id:'mailDocStatus'
			}
			]
		},
		{
	    	   xtype :'textfield',
	    	   fieldLabel: 'CsrfName',
			   hidden:true,
	    	   disabled : true,
	    	   name: 'csrfUpl',
			   maxLength : 100,
	    	   allowBlank:false,
	    	   id:'testCsrfUpl'
	    },{
			xtype : 'fieldset',
			title : 'Action',
			collapsable : 'false',
			layout : 'column',
			id:'viewDocStatus',
			height : 45,
			items : [ {
				xtype : 'button',
				text : 'View',
				handler: function()
				{
					if(!(Ext.getCmp("startDateStatus").getValue()) || !(Ext.getCmp("endDateStatus").getValue()))
						{
						Ext.Msg.alert("Warning","<font color='red'>Please enter 'Start Date & End Date'</font>");
						return false;
						}
					var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateStatus").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateStatus").getValue(),'Y/m/d'));
					if(flag)
						{
					if(radioVariable==1)
					{
						uploadDataStore.removeAll();
						mailDataStore.removeAll();
						Ext.Ajax.request({
							dataType : 'json',
							contentType : 'application/json',
							url : 'bulkUpload/getUploadData.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
							method: 'POST',
							params:{
								startDateStatus:Ext.Date.format(Ext.getCmp("startDateStatus").getValue(),'d-M-y'),
								endDateStatus:Ext.Date.format(Ext.getCmp("endDateStatus").getValue(),'d-M-y'),
								dataFileName:Ext.getCmp("dataFileName").getValue(),
							},
							success: function(response,opts)
							{
								
								var jsonResp = Ext.decode(response.responseText).data;

								uploadDataStore.loadRawData(jsonResp,true); 
							}
						});
					}
					if(radioVariable==2)
					{
						mailDataStore.removeAll();
						uploadDataStore.removeAll();
						Ext.Ajax.request({
							dataType : 'json',
							contentType : 'application/json',
							url : 'bulkUpload/getMailData.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
							method: 'POST',
							params:{
								startDateStatus:Ext.Date.format(Ext.getCmp("startDateStatus").getValue(),'d-M-y'),
								endDateStatus:Ext.Date.format(Ext.getCmp("endDateStatus").getValue(),'d-M-y'),
								dataFileName:Ext.getCmp("dataFileName").getValue(),
								dsm2RefCode:Ext.getCmp("dsm2RefCode").getValue(),
		  					    mailSendStatus:Ext.getCmp("sendDocStatus").getValue(),
		  					    mailStatus:Ext.getCmp("mailDocStatus").getValue()
								 				},
								 success: function(response,opts)
								 {
									 uploadDataStore.removeAll();
									 var jsonResp = Ext.decode(response.responseText).data;
									 mailDataStore.loadRawData(jsonResp,true); 
								 }
						});
					}
				}
			}
			}
			],
		}
		]
	},
	{
		id:'viewUploadEmailStatusId',
		layout:'column',
		items:[val1,val2]
	}
	]
}
);
	var EmailDocList=Ext.create('Ext.form.Panel',
			{
				border:true,
				id: 'Email-Document-Lists',
				layout:'fit',
				items:
					[
					 {
						 xtype:'tabpanel',
						 id:'uploadViewDoc',
						 layout:'fit',
						 items:
							 [
							  {
								  title :'Upload Document',
								  id: 'uploadEmailDocument',
								  items:
									  [uploadEmailDocument ]
							  },
							  {
								  title :'View Status',
								  id:'viewUploadEmailStatus',
								  items:
									  [viewUploadEmailStatus]
							  }
							  ]
					 }
					 ]
			}		
			);
	
Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer',
	             ]);

	Ext.define('Scheme.model.Book', {
		extend: 'Ext.data.Model',
		fields: [
		         {name: 'schemeName', type: 'string'},
		         {name: 'circleName',  type: 'string'}

		         ]
	});

	
var viewPayToId = null;
var viewloadfilter = null;
var viewFileNameComb = null;


var viewschemeSearch = new Ext.Panel({     
	stripeRows  : true,
	border: false,
	border	   : false,
	style       : 'padding-bottom: 5px',
	//bodyStyle:'padding:3px 5px',
	defaults: {
		//bodyStyle:'padding:3px 5px'
	},
	items       : [
{
	xtype:'fieldset',
	title: 'View Search',
	layout: 'column',
	//bodyStyle:'padding:3px 0px',
	height : 80,
	width : '100%',
	collapsible: true,
	items :[
{
	xtype: 'container',//1
	//columnWidth:.3,
	layout: 'anchor',
	items:[
	       {
	    	   xtype       : 'datefield',
	    	   id          : 'startDateView',
	    	   allowBlank  : true,
	    	   emptyText   : 'StartDate',
	    	   name        : 'startDate',
	    	   //width       : 140,
	    	   editable    : false,
	    	   value : new Date(date.getFullYear(), date.getMonth(), 1)
	       },
	       
	       {
	    		xtype       : 'textfield',
	    		id          : 'schemeNameView',
	    		allowBlank  : true,
	    		emptyText   : 'Scheme Name',
	    		name        : 'schemeComp',
	    		//maskRe:/[A-Za-z0-9_- ]/,
	    		//width       : 140,
	    		editable    : true,
	    		maxLength : 100,
				enforceMaxLength:"true"	
	    	},
	       ]
},
{
	xtype: 'container',//2
	//columnWidth:.3,
	layout: 'anchor',
	items:[
{
	xtype       : 'datefield',
	id          : 'endDateView',
	allowBlank  : true,
	emptyText   : 'EndDate',
	name        : 'endDate',
	//width       : 140,
	editable    : false,
	value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
},
{
	xtype       : 'numberfield',
	id          : 'schemeNameIdView',
	allowBlank  : true,
	emptyText   : 'Scheme ID',
	name        : 'schemeId',
	allowNegative: false,
	//width       : 140,
	editable    : true,
	maxLength : 38,
	enforceMaxLength:"true"	
},
]
},
{
	xtype: 'container',//3
	//columnWidth:.3,
	layout: 'anchor',
	items:[
{
	xtype       : 'combo',
	displayField:'name',
	valueField:'id',
	allowBlank  : true,
	name        : 'filterBy',
	emptyText   : 'Scheme State',
	//width       : 140,
	editable    : false,
	store: viewSchemeFilterStore(),
	listeners: {
		'select': function(combo, value){

			var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateView").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateView").getValue(),'Y/m/d'));
			if(flag){
				viewschemeStoreGrid.clearFilter(true);
				viewloadfilter = combo.getValue();
			}
		}
	},
	triggerAction:'all'
},
{
	   xtype       : 'textfield',
	   id          : 'compNameView',
	   allowBlank  : true,
	   emptyText   : 'Component Name',
	   name        : 'componentName',
	  // maskRe:/[A-Za-z0-9_- ]/,
	   editable    : true,
	   maxLength : 100,
	   enforceMaxLength:"true"	
},
]
}, 
{
	xtype: 'container',//4
	//columnWidth:.3,
	layout: 'anchor',
	items:[
{
	 xtype: 'hidden',
	 height:22,
},
{
	xtype: 'combo',
	store:payToStore,
	emptyText   : 'Pay To',
	//fieldLabel: 'Table Field',
	displayField:'displayValue',
	editable: false,
	valueField:'entityTypeId',
	name: 'payTo',
	listeners: {
		'select': function(combo, value){
			viewPayToId = combo.getValue();
		}
	}
},

]
},
{
	xtype: 'container',//5
	//columnWidth:.3,
	layout: 'anchor',
	items:[
{
	 xtype: 'hidden',
	 height:22,
},
{
	xtype       : 'combo',
	// id          : 'filterBy',
	displayField:'name',
	emptyText   : 'Coverage File (Y/N)',
	valueField:'id',
	allowBlank  : true,
	name        : 'fileNameSel',
	//width       : 140,
	editable    : false,
	store: viewSchemeFileNameFilterStore(),
	listeners: {
		'select': function(combo, value){
			viewFileNameComb = combo.getValue();
			
		}
	}
},
]
},

{
	xtype: 'container',//6
	//columnWidth:.3,
	layout: 'anchor',
	items:[
{
	 xtype: 'hidden',
	 height:22,
},
{
	xtype       : 'textfield',
	id          : 'fileNameView',
	allowBlank  : true,
	emptyText   : 'Coverage File Name',
	name        : 'fileName',
	//width       : 140,
	editable    : true,
	maxLength : 60,
	enforceMaxLength:"true"	

	// format      : 'dd-MMM-yyyy'
},

]
},

/*{
	xtype: 'container',//6
	//columnWidth:.3,
	layout: 'anchor',
	items:[
{
	 xtype: 'hidden',
	 height:20,
},

       
	
]
},*/
{
	xtype: 'container',
	//columnWidth:.3,//7
	layout: 'anchor',
	items:[
{
	 xtype: 'hidden',
	 height:22,
},
{
	   xtype :'textfield',
	   fieldLabel: 'CsrfName',
	   hidden:true,
	   disabled : true,
	   name: 'csrfView',
	   maxLength : 100,
	   allowBlank:false,
	   id:'testCsrfView'
},


{
	xtype       : 'button',
	text        : 'Go',
	width       : 40,
	handler     : function () {
		Ext.getCmp("testCsrfView").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
		var viewScmName = Ext.getCmp("schemeNameView").getValue()!='' ? Ext.getCmp("schemeNameView").getValue() : 'ABCDEF';
		var viewScmId = Ext.getCmp("schemeNameIdView").getValue()!=null ? Ext.getCmp("schemeNameIdView").getValue() : '-1';
		viewPayToId = viewPayToId != null ? viewPayToId : '-1';
		viewFileNameComb = viewFileNameComb != null ? viewFileNameComb : '-1';
		var viewCompName = Ext.getCmp("compNameView").getValue()!='' ? Ext.getCmp("compNameView").getValue() : 'ABCDEF';
		var viewFileName = Ext.getCmp("fileNameView").getValue()!='' ? Ext.getCmp("fileNameView").getValue() : 'ABCDEF';
		var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateView").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateView").getValue(),'Y/m/d'));

		if(viewloadfilter == null){
			Ext.Msg.alert("Warning","<font color='blue'>Please enter 'From Date', 'To Date' & 'Scheme State'.</font>");
			return false;
		}
		if(flag && viewloadfilter != null){
			viewschemeStoreGrid.clearFilter(true);
			viewschemeStoreGrid.load({params:
			{
				startDate:Ext.Date.format(Ext.getCmp("startDateView").getValue(),'d-M-Y') ,
				endDate: Ext.Date.format(Ext.getCmp("endDateView").getValue(),'d-M-Y'),
				schemeComp : viewScmName,
				schemeId : viewScmId,
				payTo : viewPayToId,
				componentName : viewCompName,
				fileName : viewFileName,
				isMaster : true,
				isStage : false,
				filterBy : viewFileNameComb,
				condParam : viewloadfilter,
				page:1,
				start :	0
			}});
		}
	},
}
]}
]
}
]
});




	Ext.define('Scheme.view.ViewSchemeList', {
		extend: 'Ext.grid.Panel',
		id:'viewschemeGrid',
		stripeRows: true,
		layout: 'fit',
		flex: 2,
		//width:'98%',
		height: '100%',
		pageSize : 1000,
		autoWidth:true,
		forceFit: true,
		viewConfig:{forceFit:true},
		autoExpandColumn: 'Scheme Name',
		//  height:550,
		//bodyStyle:'padding:2px 0px',
		// bodyStyle:'padding:0px 0px',
		hidden: false,
		loadMask: true,
		resizable: true,
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.ViewSchemeList',
		title: 'View Scheme',
		store: viewschemeStoreGrid,
		//plugins: [new Ext.ux.FitToParent("viewscheme")],
		//height:500,
		autoScroll: true,

		initComponent: function () {
			this.tbar = [
			             viewschemeSearch
			             ];
			this.columns = [
			                { header: 'Scheme Id', dataIndex: 'schemeINputId', width: 40 },
			                { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
			                { header: 'Comp Id', dataIndex: 'compId', flex: 1 },
			                { header: 'Comp Name', dataIndex: 'compName', flex: 1 },
			                { header: 'Create Date', dataIndex: 'insertTime', flex: 1 },
			                { header: 'PayTo', dataIndex: 'payTo', flex: 1 },
			                { header: 'Start Date', dataIndex: 'startDate', flex: 1 },
			                { header: 'End Date', dataIndex: 'endDate', flex: 1 },
			                { header: 'File Name', dataIndex: 'fileName', flex: 1 },
			                { header: 'Status', dataIndex: 'schemeStatus', flex: 1 },
			                { header: 'View', flex: 1,
	    	                	renderer: function (v, m, r) {
	    	                		var id = Ext.id();
	    	                		if(viewloadfilter=='D' || viewloadfilter=='A' || viewloadfilter=='R' || viewloadfilter=='C'){
	    	                		Ext.defer(function () {
	    	                			Ext.widget('image', {
	    	                				renderTo: id,
	    	                				name: 'download',
	    	                				src : 'resources/images/PDFView30.png',
	    	                				listeners : {
	    	                					afterrender: function (me) {
	    	                						me.getEl().on('click', function() {
	    	                							var grid = Ext.ComponentQuery.query('ViewSchemeList')[0];
	    	                							if (grid) {
	    	                								var sm = grid.getSelectionModel();
	    	                								var rs = sm.getSelection();
	    	                								if (!rs.length) {
	    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
	    	                									return;
	    	                								}
	    	                								Ext.Msg.confirm('Download Scheme', 
	    	                										'You want to download Scheme?', 
	    	                										function (button) {
	    	                									if (button == 'yes') {
	    	                										var urlParam = './reports/downloadPDF.action?output='+rs[0].data.schemeINputId+'&compId='+rs[0].data.compId+'&csvType='+viewloadfilter;
	    	                										window.open(urlParam,'_blank');
	    	                									}
	    	                								});
	    	                							}
	    	                						});
	    	                					}
	    	                				}
	    	                			});
	    	                		}, 700);
	    	                	}
	    	                		return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                },
			                { header: 'Remarks', dataIndex: 'remarks', flex: 1 },

			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : viewschemeStoreGrid,
				dock : 'bottom',
				displayInfo : true
			}
			];

			this.callParent(arguments);
		},

	});


	Ext.define('Scheme.controller.ViewSchemeCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],

		views   : ['ViewSchemeList'],

	});

});
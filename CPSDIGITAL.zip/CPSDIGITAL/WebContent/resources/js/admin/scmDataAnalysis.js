Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);

	function validateSchData(type)
	{
		if(type=='SCM'){
			var startDt = Ext.getCmp("startDatesds").getValue();
			var endDt = Ext.getCmp("endDatesds").getValue();
			var cid = Ext.getCmp("circleIdsds").getValue();
			var schId =  Ext.getCmp("schemeIdsds").getValue();
			var compId = Ext.getCmp("compIdsds").getValue();
			var type = Ext.getCmp("paramCatsds").getValue();
			var result="";
			//alert(schId+compId);
			if(startDt==null || startDt==undefined || startDt==""){
				result="Start Date Field is Mandatory.\n <br>";
			}
			if(endDt==null || endDt==undefined || endDt==""){
				result=result+"End Date Field is Mandatory.\n <br>";
			}
			if(cid==null || cid==undefined || cid=="" ){
				result=result+"Circle Field is Mandatory.\n <br>";
			}
			if(schId==null || schId==undefined || schId==""){
				result=result+"Scheme Name Field is Mandatory.\n <br>";
			}
			if(compId==null || compId==undefined || compId==""){
				result=result+"Component Name Field is Mandatory.\n <br>";
			}
			if(type==null || type==undefined || type==""){
				result=result+"Param Category Field is Mandatory.\n <br>";
			}
			return result;
		}
	}

	var scmDataSearch = new Ext.Panel({     
		border: false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		bodyStyle:'padding:3px 5px',
		defaults: {
			bodyStyle:'padding:3px 5px'
		},
		items       : [	
		               {
		            	   xtype:'fieldset',
		            	   layout:'column',
		            	   title: 'Scheme Data Search ',
		            	   height : 50,
		            	   width  :'100%',
		            	   bodyStyle:'padding:3px 0px',
		            	   collapsible: true,	
		            	   items :[
		            	           {
		            	        	   xtype       : 'datefield',
		            	        	   id          : 'startDatesds',
		            	        	   allowBlank  : false,
		            	        	   emptyText   : 'StartDate',
		            	        	   name        : 'startDateHier',
		            	        	   //width       : 140,
		            	        	   editable    : false,
		            	           },{
		            	        	   xtype       : 'datefield',
		            	        	   id          : 'endDatesds',
		            	        	   allowBlank  : false,
		            	        	   emptyText   : 'EndDate',
		            	        	   name        : 'endDateHier',
		            	        	   editable    : false,
		            	        	   listeners: {
		            	        		   'select': function(combo, value){
		            	        			   Ext.getCmp("compIdsds").reset();
		            	        			   Ext.getCmp("schemeIdsds").reset();
		            	        			   schemaMasterStore.load({params:
		            	        			   {
		            	        				   //"circleId" : 0,
		            	        				   "startDate"       :	Ext.Date.format(Ext.getCmp("startDatesds").getValue(),'d-M-y') ,
			            	        			   "endDate"         : Ext.Date.format(Ext.getCmp("endDatesds").getValue(),'d-M-y'),
			            	        		   }});
		            	        			   Ext.getCmp("schemeIdsds").reset();
		            	        			}
		            	        	   },

		            	           },
		            	           {
		            	        	   xtype :'combo',
		            	        	   editable: false,
		            	        	   allowBlank: false,
		            	        	   //fieldLabel: 'Component Name*',
		            	        	   name:'circle',
		            	        	   id:'circleIdsds',
		            	        	   disabled:false,
		            	        	   emptyText   : 'Circle',
		            	        	   displayField:'circleName',	
		            	        	   valueField:'circleId',
		            	        	   store: circleStore,
		            	        	   listeners: {
		            	        		   'select': function(combo, value){
		            	        			   Ext.getCmp("compIdsds").reset();
		            	        			   schemaMasterStore.load({params:
		            	        			   {
		            	        				   "circleId" : combo.getValue(),
		            	        				   "startDate"       :	Ext.Date.format(Ext.getCmp("startDatesds").getValue(),'d-M-y') ,
			            	        			   "endDate"         : Ext.Date.format(Ext.getCmp("endDatesds").getValue(),'d-M-y'),
			            	        		   }});
		            	        			   Ext.getCmp("schemeIdsds").reset();
		            	        			   Ext.getCmp("paramCatsds").reset();
		            	        			   paramCatMasterStore.load({params:
		            	        			   {
		            	        				   "circleId" : combo.getValue() 		
		            	        			   }});
		            	        			   Ext.getCmp("paramCatsds").reset();

		            	        			   componentMasterStore.load({params:
		            	        			   {
		            	        				   //	"schemaId" : combo.getValue() 		
		            	        			   }});

		            	        		   }
		            	        	   },
		            	        	   triggerAction:'all'
		            	           }, 
		            	           {
		            	        	   xtype :'combo',
		            	        	   editable: false,
		            	        	   allowBlank: false,
		            	        	   width:230,
		            	        	   name:'scheme',
		            	        	   id:'schemeIdsds',
		            	        	   disabled:false,
		            	        	   emptyText   : 'Scheme Name',
		            	        	   displayField:'schemaName',	
		            	        	   valueField:'schemaId',
		            	        	   store: schemaMasterStore,
		            	        	   listeners: {
		            	        		   'select': function(combo, value){
		            	        			   Ext.getCmp("compIdsds").reset();
		            	        			   componentMasterStore.load({params:
		            	        			   {
		            	        				   "schemaId" : combo.getValue() 		
		            	        			   }});
		            	        			   Ext.getCmp("compIdsds").reset();
		            	        		   }
		            	        	   },
		            	        	   triggerAction:'all'
		            	           },
		            	           {
		            	        	   xtype :'combo',
		            	        	   editable: false,
		            	        	   allowBlank: false,
		            	        	   width:220,
		            	        	   name:'comp',
		            	        	   id:'compIdsds',
		            	        	   disabled:false,
		            	        	   emptyText   : 'Component Name',
		            	        	   displayField:'compName',	
		            	        	   valueField:'compId',
		            	        	   store: componentMasterStore,
		            	        	   //triggerAction:'all'
		            	           }, 
		            	           {
		            	        	   xtype :'combo',
		            	        	   editable: false,
		            	        	   allowBlank: false,
		            	        	   //width:250,
		            	        	   name:'parm',
		            	        	   id:'paramCatsds',
		            	        	   disabled:false,
		            	        	   emptyText   : 'Param Category',
		            	        	   displayField:'categoryName',	
		            	        	   valueField:'categoryName',
		            	        	   store: paramCatMasterStore,
		            	        	   //triggerAction:'all'
		            	           },
		            	           {
		            	        	   xtype       : 'button',
		            	        	   text        : 'Go',
		            	        	   width	   :40,
		            	        	   handler     : function () {
		            	        		   var result= validateSchData('SCM');
		            	        		   if(result==""){
		            	        			   var grid = Ext.ComponentQuery.query('ScmDataAnalysisList')[0];
			            	        		   grid.store.load({params:
			            	        		   {
			            	        			   "startDate"       :	Ext.Date.format(Ext.getCmp("startDatesds").getValue(),'d-M-y') ,
			            	        			   "endDate"         : Ext.Date.format(Ext.getCmp("endDatesds").getValue(),'d-M-y'),
			            	        			   "circleId"		  : Ext.getCmp("circleIdsds").getValue(),
			            	        			   "schemeId"		  : Ext.getCmp("schemeIdsds").getValue(),
			            	        			   "compId"		  : Ext.getCmp("compIdsds").getValue(),
			            	        			   "typeParam" 	  : Ext.getCmp("paramCatsds").getValue()
			            	        		   }});
	   
		            	        		   }else{
		            	        			   Ext.Msg.alert('Warning', "<font color='red'>Please Fill All Mandatory Fields.<br>"+result+"</font>");
		            	        		   }
		            	        	   },
		            	           }]
		               },
		               {   xtype:'fieldset',
		            	   title: 'Download CSV',
		            	   collapsible: false,
		            	   layout:'column',
		            	   height : 50,
		            	   width  :'100%',
		            	   defaults: {
		            		   anchor: '100%',
		            		   width:'100%',
		            		   bodyStyle:'padding:5px 5px',
		            	   },
		            	   items :[
		            	           {
		            	        	   xtype       : 'button',
		            	        	   text        : 'Download',
		            	        	   handler     : function () {
		            	        		   var result= validateSchData('SCM');
		            	        		   if(result==""){
			            	        		   var urlParam1;
			            	        		   Ext.Msg.confirm('Scm Data Analysis', 
			            	       					'Download Scm Data Analysis CSV', 
			            	       					function (button) {
			            	       				if (button == 'yes') {
			            	       					waitMsg : 'Loading...',
			            	       					urlParam1 = './csv/scmDataAnalysisDownloadCSV.action?startDate='+Ext.Date.format(Ext.getCmp("startDatesds").getValue(),'d-M-y')+'&endDate='+Ext.Date.format(Ext.getCmp("endDatesds").getValue(),'d-M-y')+
			            	       					'&circleId='+Ext.getCmp("circleIdsds").getValue()+'&typeParam='+Ext.getCmp("paramCatsds").getValue()+'&schemeId='+Ext.getCmp("schemeIdsds").getValue()+'&compId='+Ext.getCmp("compIdsds").getValue();
			            	       				window.open(urlParam1,'_BLANK');

			            	       				}
			            	       			});
		            	        		   }else{
		            	        			   Ext.Msg.alert('Warning', "<font color='red'>Please Fill All Mandatory Fields.<br>"+result+"</font>");
		            	        		   }
		            	        	   },
		            	           }]
		               }]
	});
	

	Ext.define('Scheme.view.ScmDataAnalysisList', {
		extend: 'Ext.grid.Panel',
		id:'scmDA',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:520,
		//bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		//remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.ScmDataAnalysisList',
		//title: 'Statement Generation',
		store: scmDataAnalysis,
		//height:500,
		autoScroll: true,
		// resizable: false,
	    // fixed: true,
		initComponent: function () {
			var me = this;
			this.tbar = [
			             	scmDataSearch
			             ];
			this.columns = [
			                { header: 'Scm Id', dataIndex: 'schemeId',  width: 90},
			                { header: 'Scm Name', dataIndex: 'schemeName',  width: 140},
			                { header: 'comp Id', dataIndex: 'compId',  width: 90},
			                { header: 'Comp Name', dataIndex: 'compName',  width: 140},
			                { header: 'Start Date', dataIndex: 'startDt', width: 90},
			                { header: 'End Date', dataIndex: 'endDt', width: 90},
			                { header: 'Category', dataIndex: 'paramCat', width: 90},
			                { header: 'Parameter', dataIndex: 'paramName', width: 120 },
			                { header: 'Total', dataIndex: 'rowCount', width: 70 },
			                { header: 'Null Cnt', dataIndex: 'missingValueCount', width: 70 },
			                { header: 'Value Cnt', dataIndex: 'valueCount',  width: 70 },
			                { header: 'Remarks', dataIndex: 'remarks',  width: 160 }
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : scmDataAnalysis,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		},
	});


	Ext.define('Scheme.controller.ScmDataAnalysisCon', {
		extend  : 'Ext.app.Controller',
		stores  : ['Books'],
		views   : ['ScmDataAnalysisList'],
	});
	
});
Ext.require([
    'Ext.form.*',
    'Ext.data.*',
    'Ext.grid.Panel',
    'Ext.layout.container.Column'
]);


//Ext.onReady(function(){

   

var attrType = null;
var attrCatg = null;   
    

var gridForm = Ext.create('Ext.form.Panel', {
	id: 'Attribute-Config',
	frame: true,
	title: 'Attribute Config',
	bodyPadding: 5,
	width: 750,
	layout: 'column',    // Specifies that the items will now be arranged in columns
	fieldDefaults: {
		labelAlign: 'left',
		msgTarget: 'side'
	},

	items: [{
		columnWidth: 0.60,
		xtype: 'gridpanel',
		store: AttrMappingConfigStore,
		height: 500,
		tbar :[
		       {
		    	   xtype: 'combo',
		    	   store: AttrCatgStore(),
		    	   fieldLabel: 'Attr Type',
		    	   displayField:'displayName',
		    	   valueField:'displayName',
		    	   name: 'attrCatgFilter',
		    	   listeners: {
		    		   'select': function(combo, value){
		    			   attrCatg = combo.getValue();
		    			   gridForm.child('gridpanel').store.clearFilter();
		    			   gridForm.child('gridpanel').store.filter('attrCatg',combo.getValue());													
		    			   if(attrType!=null)
		    			   {
		    				   /*entityAttrStore.filter(function(r) {
																var value = r.get('attrCatg');
																var value2 = r.get('attrType');
																return (value == combo.getValue() && value2 == entityType);
															});
		    				    */
		    				   gridForm.child('gridpanel').store.filter('attrType',attrType);
		    			   }
		    		   }
		    	   }
		       },

		       {
		    	   xtype: 'combo',
		    	   store:payToStore,
		    	   fieldLabel: 'Entity Type',
		    	   displayField:'displayValue',
		    	   valueField:'displayValue',
		    	   name: 'attrTypeFilter',
		    	   listeners: {
		    		   'select': function(combo, value){
		    			   attrType = combo.getValue();
		    			   gridForm.child('gridpanel').store.clearFilter();
		    			   gridForm.child('gridpanel').store.filter('attrType',combo.getValue());	
		    			   if(attrCatg!=null)
		    			   {
		    				   gridForm.child('gridpanel').store.filter('attrCatg',attrCatg);
		    			   }
		    		   }
		    	   }
		       }],

		       columns: [
		                 {
		                	 id       :'id_SEQ',
		                	 text   : 'SEQ_Id',
		                	 width: 40,
		                	 sortable : true,
		                	 dataIndex: 'id'
		                		 // renderer : id
		                 },

		                 {
		                	 text   : 'Attr Type',
		                	 width    : 50,
		                	 sortable : true,
		                	 dataIndex: 'attrCatg',
		                	 // renderer : attrType	
		                 },
		                 {
		                	 text   : 'Entity Type',
		                	 width    : 50,
		                	 sortable : true,
		                	 dataIndex: 'attrType',
		                	 // renderer : attrType	
		                 },
		                 {
		                	 text   : 'Display Name',
		                	 flex: 1,
		                	 sortable : true,
		                	 // renderer : displayName,
		                	 dataIndex: 'displayName'
		                 },
		                 {
		                	 text   : 'Table Field',
		                	 flex: 1,
		                	 sortable : true,
		                	 // renderer : displayName,
		                	 dataIndex: 'srcTblField'
		                 },

		                 {
		                	 text   : 'Table Name',
		                	 flex: 1,
		                	 sortable : true,
		                	 // renderer : displayName,
		                	 dataIndex: 'srcTblName'
		                 },

		                 {
		                	 text   : 'Data Type',
		                	 width    : 50,
		                	 sortable : true,
		                	 // renderer : displayName,
		                	 dataIndex: 'freeTxtType'
		                 }
		                 ],
		                 listeners: {
		                	 selectionchange: function(model, records) {
		                		 if (records[0]) {
		                			 this.up('form').getForm().findField('id').enable();
		                			 this.up('form').getForm().findField('id').readOnly = true;
		                			 //console.log(records[0]);
		                			// alert("PO :: "+records[0].data.payCondFlag);
		                			 //alert("EA :: "+records[0].data.entAggFlag);
		                			 //alert("COV :: "+records[0].data.covFlag);
		                			 //alert("TQ :: "+records[0].data.tqFlag);
		                			 
		                			 if(records[0].data.attrCatg=='Additional')
		                			 {
		                				 AttrMappingFieldSetStore.clearFilter();
		                				 AttrMappingFieldSetStore.filter('fieldType','A');
		                			 }

		                			 if(records[0].data.attrCatg=='Core')
		                			 {
		                				 AttrMappingFieldSetStore.clearFilter();
		                				 AttrMappingFieldSetStore.filter('fieldType','C');
		                			 }
		                			 this.up('form').getForm().loadRecord(records[0]);
		                			 this.up('form').getForm().findField('attrConfAddButton').disable();
		                			 this.up('form').getForm().findField('attrCatg').readOnly = true;
		                			 this.up('form').getForm().findField('srcTblField').readOnly = true;//attrConfAddButton
		                			// this.up('form').getForm().findField('srcTblField').editable = false;
		                			 //this.up('form').getForm().findField('attrType').readOnly = true;
		                			 this.up('form').getForm().findField('freeTxtType').readOnly = true;
		                			 
		                		 }
		                	 }
		                 }
	}, {
		columnWidth: 0.4,
		margin: '0 0 0 10',
		xtype: 'fieldset',
		title:'Attribute Mapping details',
		defaults: {
			width: 240,
			labelWidth: 90
		},
		defaultType: 'textfield',
		items: [
		        {
		        	fieldLabel: 'Id',
		        	disabled: true,
		        	name: 'id',
		        	readOnly : true
		        },

		        {
		        	xtype: 'combo',
		        	store: AttrCatgStore(),
		        	fieldLabel: 'Attr Type',
		        	editable: false,
		        	displayField:'displayName',
		        	valueField:'displayName',
		        	name: 'attrCatg',

		        	listeners: {
		        		'select': function(combo, value){
		        			this.up('form').getForm().findField('srcTblField').reset();
		        			if(combo.getValue()=='Additional')
		        			{
		        				AttrMappingFieldSetStore.clearFilter();
		        				AttrMappingFieldSetStore.filter('fieldType','A');
		        			}

		        			if(combo.getValue()=='Core')
		        			{
		        				AttrMappingFieldSetStore.clearFilter();
		        				AttrMappingFieldSetStore.filter('fieldType','C');
		        			}
		        		}
		        	}
		        },

		        {
		        	xtype: 'combo',
		        	store:payToStore,
		        	fieldLabel: 'Entity Type',
		        	displayField:'displayValue',
		        	valueField:'displayValue',
		        	editable: false,
		        	name: 'attrType',
		        	listeners: {
		        		'select': function(combo, value){
		        		//	alert(combo.getValue());
		        			AttrMappingFieldSetStore.load({params:
		        			{
		        				"attrTypeName" : combo.getValue(),
		        			}});
		        		}
		        	}
		        },

		        {
		        	xtype: 'combo',
		        	store: AttrMappingFieldSetStore,
		        	fieldLabel: 'Table Field',
		        	displayField:'fieldName',
		        	editable: false,
		        	valueField:'fieldName',
		        	name: 'srcTblField'
		        },

		        ,{
		        	fieldLabel: 'displayName',
		        	name: 'displayName',
		        	maxLength : 30,
		        	enforceMaxLength:"true"
		        },
		        {
		        	xtype: 'combo',
		        	store: EntAttrDataTypeStore(),
		        	editable: false,
		        	fieldLabel: 'Data Type',
		        	displayField:'displayName',
		        	valueField:'displayName',
		        	name: 'freeTxtType'
		        },


		        {
		        	xtype: 'checkboxgroup',
		        	fieldLabel: 'Applicable',
		        	columns: 4,

		        	items: [{
		        		inputValue: 'Y',
		        		boxLabel: 'Coverage',
		        		name: 'covFlag',
		        		checked: false
		        	}, {
		        		inputValue: 'Y',
		        		boxLabel: 'Transaction',
		        		checked: false,
		        		name: 'tqFlag'
		        	}, {
		        		inputValue: 'Y',
		        		boxLabel: 'Aggregation',
		        		checked: false,
		        		name: 'entAggFlag'
		        	},

		        	{
		        		inputValue: 'Y',
		        		boxLabel: 'Payout',
		        		checked: false,
		        		name: 'payCondFlag'
		        	}
		        	]
		        },

		        {
		        	xtype: 'fieldset',
		        	columns: 4,
		        	defaults: {
		        		style:'margin-right:5px;',
		        		border : false,
		        		frame : false
		        		//Each radio has the same name so the browser will make sure only one is checked at once
		        	},
		        	items: [
		        	        {
		        	        	xtype: 'button',
		        	        	text : 'Add',
		        	        	name : 'attrConfAddButton',
		        	        	handler : function () { 
		        	        		this.up('form').getForm().submit({
		        	        			waitMsg : 'Saving',
		        	        			url : 'admin/saveAttrConfigStore.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		        	        			method : 'POST',
		        	        			success: function(form, action) {
		        	        				Ext.Msg.alert(action.result.errorMessage);
		        	        				gridForm.child('gridpanel').store.load();
		        	        				form.reset(); 
		        	        				form.findField('id').disable();
		        	        			},

		        	        			failure: function(form, action) {
		        	        				Ext.Msg.alert(action.result.errorMessage);
		        	        			}
		        	        		}); 
		        	        	}
		        	        },

		        	        {
		        	        	xtype: 'button',
		        	        	text : 'Update',
		        	        	handler : function () { 
		        	        		this.up('form').getForm().submit({
		        	        			waitMsg : 'updating',
		        	        			url : 'admin/updateAttrConfigStore.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		        	        			method : 'POST',
		        	        			success: function(form, action) {
		        	        				Ext.Msg.alert(action.result.errorMessage);
		        	        				gridForm.child('gridpanel').store.load();
		        	        				form.reset(); 
		        	        				form.findField('id').disable();
		        	        			},

		        	        			failure: function(form, action) {
		        	        				Ext.Msg.alert(action.result.errorMessage);
		        	        			}
		        	        		}); 
		        	        	}
		        	        },
		        	        /*{
		        	        	xtype: 'button',
		        	        	text : 'Remove',
		        	        	hidden: true,
		        	        	handler : function () { 
		        	        		this.up('form').getForm().submit({
		        	        			waitMsg : 'Deleting',
		        	        			url : 'admin/deleteAttrConfigStore.action',
		        	        			method : 'POST',
		        	        			success: function(form, action) {
		        	        				Ext.Msg.alert(action.result.errorMessage);
		        	        				gridForm.child('gridpanel').store.load();
		        	        				form.reset();
		        	        				form.findField('id').disable();
		        	        			},

		        	        			failure: function(form, action) {
		        	        				Ext.Msg.alert(action.result.errorMessage);
		        	        			}
		        	        		}); 
		        	        	}
		        	        },*/
		        	        {
		        	        	xtype: 'button',
		        	        	text : 'Reset',
		        	        	handler : function () { 
		        	        		this.up('form').getForm().findField('id').disable();
		        	        		this.up('form').getForm().reset(); 
		        	        		this.up('form').getForm().findField('attrConfAddButton').disable();;
		        	        		 this.up('form').getForm().findField('attrCatg').readOnly = false;
		                			 this.up('form').getForm().findField('srcTblField').readOnly = false;
		                			 //this.up('form').getForm().findField('srcTblField').editable = true;
		                			 this.up('form').getForm().findField('attrType').readOnly = false;
		                			 this.up('form').getForm().findField('freeTxtType').readOnly = false;
		        	        	}
		        	        }
		        	        ]
		        }
		        ]
	}],
	//renderTo: bd
});
    gridForm.child('gridpanel').getSelectionModel().select(0);
//});

function saveCircleSchedular(circleSchedularForm)
{
	if(circleSchedularForm.getForm().isValid())
	{
		var result = validateCircleSche(circleSchedularForm,"SaveCircleSchedular");
		if(result=="")
		{
			circleSchedularForm.getForm().submit({
				waitMsg : 'Loading...',
				url : 'admin/updateCircleSchedular.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
				method : 'POST',

				success: function(form, action) {
					if(action.result != null)
						Ext.Msg.alert('Warning', action.result.errorMessage);
					form.reset();
				},

				failure: function(form, action) {
					if(action.result != null)
						Ext.Msg.alert('Warning', action.result.errorMessage);
					else
					{	
						Ext.Msg.alert('Warning', "Attribite Mapping Error");
					}
				}
			});
		}else{
			Ext.Msg.alert('Warning', "<font color='red'>Please Fill All Mandatory Fields.<br>"+result+"</font>");			
		}
	}
	else
	{
		Ext.Msg.alert('Warning', "Please Fill All Mandatory Fields");
	}
}

function saveFrcDeno(circleSchedularForm)
{
	if(circleSchedularForm.getForm().isValid())
	{
		var result = validateCircleSche(circleSchedularForm,"GetDenoSet");
		if(result=="")
		{
			circleSchedularForm.getForm().submit({
				waitMsg : 'Loading...',
				url : 'admin/updateFrcDenoCircleSchedular.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
				method : 'POST',

				success: function(form, action) {
					if(action.result != null)
						Ext.Msg.alert('Warning', action.result.errorMessage);
					form.reset();
				},
				failure: function(form, action) {
					if(action.result != null)
						Ext.Msg.alert('Warning', action.result.errorMessage);
					else
					{	
						Ext.Msg.alert('Warning', "Attribite Mapping Error");
					}
				}
			});
		}else{
			Ext.Msg.alert('Warning', "<font color='red'>Please Fill All Mandatory Fields.<br>"+result+"</font>");			
		}
	}
	else
	{
		Ext.Msg.alert('Warning', "Please Fill All Mandatory Fields");
	}
}


function downloadScmExePayout(circleSchedularForm)
{
	if(circleSchedularForm.getForm().isValid())
	{
		var result = validateCircleSche(circleSchedularForm,"DownloadSchemeExePayout");
		if(result=="")
		{
			var cisDatasd = Ext.Date.format(circleSchedularForm.getForm().findField("fromDate").getValue(),'d-M-y');
			var cisDataed = Ext.Date.format(circleSchedularForm.getForm().findField("toDate").getValue(),'d-M-y');
			var cisid = circleSchedularForm.getForm().findField("circleId").getValue();
			Ext.Msg.confirm('Payout Status', 
					'Download Payout Status CSV', 
					function (button) {
				if (button == 'yes') {

					/*	circleSchedularForm.getForm().submit({
			waitMsg : 'Loading...',
			url : 'csv/payoutStatusCSV.action',
			method : 'GET',
		});*/
					waitMsg : 'Loading...',
					urlParam = './csv/payoutStatusCSV.action?circleId='+cisid +'&toDate='+cisDataed+'&fromDate='+cisDatasd;
				window.open(urlParam,'_BLANK');

				}
			});
		}else{
			Ext.Msg.alert('Warning', "<font color='red'>Please Fill All Mandatory Fields.<br>"+result+"</font>");			
		}
	}
	else
	{
		Ext.Msg.alert('Warning', "Please Fill All Mandatory Fields");
	}
}



function validateCircleSche(circleSchedularForm, type)
{
	if(type=='GetDenoSet'){
		var denoSet = circleSchedularForm.getForm().findField("denoSet").getValue();
		var month = circleSchedularForm.getForm().findField("month").getValue();
		var year = circleSchedularForm.getForm().findField("year").getValue();
		var exeTillDate = circleSchedularForm.getForm().findField("exeTillDate").getValue();
		var negativeDays = circleSchedularForm.getForm().findField("negativeDays").getValue();
		var result="";
		if(month==null || month==undefined || month==""){
			result="Month Field is Mandatory.\n <br>";
		}
		if(year==null || year==undefined || year==""){
			result=result+"Year Field is Mandatory.\n <br>";
		}
		if(negativeDays==null || negativeDays==undefined || negativeDays=="" || negativeDays==0){
			result=result+"Negative Days Field is Mandatory.\n <br>";
		}
		if(exeTillDate==null || exeTillDate==undefined || exeTillDate==""){
			result=result+"Exe Till Date Field is Mandatory.\n <br>";
		}
		if(denoSet==null || denoSet==undefined || denoSet==""){
			result=result+"Deno Set Field is Mandatory.\n <br>";
		}else{
			var num = /^[0-9,]+$/;
			if(denoSet.match(num)){
				//result=result+"success";
			}else{
				result=result+'Please input Numeric Characters and , Only';
			}
		}
		
		return result;
	}
	
	if(type=='SaveCircleSchedular'){
		var delayTime = circleSchedularForm.getForm().findField("delayTime").getValue();
		var tax = circleSchedularForm.getForm().findField("tax").getValue();
		var startDay = circleSchedularForm.getForm().findField("startDay").getValue();
		var endDay = circleSchedularForm.getForm().findField("endDay").getValue();
		var statementDay = circleSchedularForm.getForm().findField("statementDay").getValue();
		var schemeSchedular = circleSchedularForm.getForm().findField("schemeSchedular").getValue();
		var distMagin = circleSchedularForm.getForm().findField("distMagin").getValue();
		
		var result="";
		if(delayTime==null || delayTime==undefined || delayTime=="" ){
			result="Delay Time Field is Mandatory.\n <br>";
		}
		if(tax==null || tax==undefined || tax==""){
			result=result+"Tax Field is Mandatory.\n <br>";
		}
		if(startDay==null || startDay==undefined || startDay=="" || startDay==0){
			result=result+"Start Day Field is Mandatory.\n <br>";
		}
		if(endDay==null || endDay==undefined || endDay==""){
			result=result+"End Day Field is Mandatory.\n <br>";
		}
		if(statementDay==null || statementDay==undefined || statementDay==""){
			result=result+"Statement Day Field is Mandatory.\n <br>";
		}
		if(schemeSchedular==null || schemeSchedular==undefined || schemeSchedular==""){
			result=result+"Scheme Scheduler Field is Mandatory.\n <br>";
		}
		if(distMagin==null || distMagin==undefined || distMagin==""){
			result=result+"Distributor Margin Field is Mandatory.\n <br>";
		}
		return result;
	}
	
	if(type=='DownloadSchemeExePayout'){
		var fromDate = circleSchedularForm.getForm().findField("fromDate").getValue();
		var toDate = circleSchedularForm.getForm().findField("toDate").getValue();
		
		var result="";
		if(fromDate==null || fromDate==undefined || fromDate=="" ){
			result="From Date Field is Mandatory.\n <br>";
		}
		if(toDate==null || toDate==undefined || toDate==""){
			result=result+"To Date Field is Mandatory.\n <br>";
		}
		return result;
	}
	
	
}





var circleSchedular = Ext.create('Ext.form.Panel', {
	//url: addSchemeUrl,
	border: false,
	//layout:'column',
	bodyStyle:'padding:3px 5px',
	width: 1100,
	defaults: {
		bodyStyle:'padding:3px 5px'
	},
	items:[
{
	xtype:'fieldset',
	layout:'column',
	title: 'Circle ',
	height : 50,
	bodyStyle:'padding:3px 0px',
	collapsible: true,	
	items :[
{
	xtype :'combo',
	fieldLabel: 'Circle',
	name:'circleId',
	disabled: false,
	allowBlank:false,
	editable: false,
	displayField:'circleName',
	valueField:'circleId',
	store: circleStore,
	triggerAction:'all'
},]
},
{
	xtype:'fieldset',
	title: 'Circle Scheduler',
	layout: 'column',
	bodyStyle:'padding:3px 0px',
	height : 200,
	collapsible: true,
	items :[
{
	xtype: 'container',
	columnWidth:.3,
	layout: 'anchor',
	items:[
	       {
	    	   xtype :'numberfield',
	    	   fieldLabel: 'Delay Time ',
	    	   allowBlank:true,
	    	   allowNegative: false,
	    	   minValue: 0,
	    	   disabled: false,
	    	   name:'delayTime'
	       },
	       {
	    	   xtype :'numberfield',
	    	   fieldLabel: 'Tax ',
	    	   allowBlank:true,
	    	   allowNegative: false,
	    	   minValue: 0,
	    	   disabled: false,
	    	   name:'tax'
	       },
	       {
	    	   xtype :'numberfield',
	    	   fieldLabel: 'Scheme-Execute Start Day',
	    	   allowBlank:true,
	    	   allowNegative: false,
	    	   minValue: 0,
	    	   disabled: false,
	    	   name:'startDay'
	       },
	       {
	    	   xtype :'numberfield',
	    	   fieldLabel: 'Scheme-Execute End Day',
	    	   allowNegative: false,
	    	   minValue: 0,
	    	   allowBlank:true,
	    	   disabled: false,
	    	   name:'endDay'
	       },]
},{
	xtype: 'container',
	columnWidth:.3,
	layout: 'anchor',
	items:[
	       {
	    	   xtype :'numberfield',
	    	   fieldLabel: 'Statement Day',
	    	   allowBlank:true,
	    	   allowNegative: false,
	    	   minValue: 0,
	    	   disabled: false,
	    	   name:'statementDay'
	       },
	       {
	    	   xtype :'numberfield',
	    	   fieldLabel: 'Scheme Scheduler (Auto mode)',
	    	   allowBlank:true,
	    	   allowNegative: false,
	    	   minValue: 0,
	    	   disabled: false,
	    	   name:'schemeSchedular'
	       },
	       {
	    	   xtype :'numberfield',
	    	   fieldLabel: 'Distributor Margin',
	    	   allowNegative: false,
	    	   minValue: 0,
	    	   allowBlank:true,
	    	   disabled: false,
	    	   name:'distMagin'
	       },
	       {
	    	   xtype:'button',
	    	   text: 'Save',
	    	   handler: function() {
	    		   saveCircleSchedular(circleSchedular);
	    	   }
	       },
	       {
	    	   xtype:'button',
	    	   text: 'Reset',
	    	   handler: function() {
	    		   circleSchedular.reset();
	    	   }
	       }
	       ]}]
},
{
	xtype:'fieldset',
	title: 'FRC Deno Set',
	layout: 'column',
	bodyStyle:'padding:3px 0px',
	height : 150,
	collapsible: true,
	items :[
{
	xtype: 'container',
	columnWidth:.3,
	layout: 'anchor',
	items:[
	       {
	xtype :'combo',
	fieldLabel: 'Month',
	name:'month',
	disabled: false,
	allowBlank:true,
	editable: false,
	displayField:'name',
	valueField:'type',
	store: circleSchedularMonthStore(),
	triggerAction:'all'
},
{
	xtype :'combo',
	fieldLabel: 'Year',
	name:'year',
	disabled: false,
	allowBlank:true,
	editable: false,
	displayField:'type',
	valueField:'type',
	store: circleSchedularYearStore(),
	listeners: {
		'select': function(combo, value){
			var cisid1 = circleSchedular.getForm().findField("circleId").getValue();
			var cisDatasd1 = circleSchedular.getForm().findField("month").getValue();
			
			if(cisid1 != undefined && cisDatasd1 != undefined){
				
				circleSchedular.getForm().submit({
					waitMsg : 'Loading...',
					url : 'admin/getFrcDenoCircleSchedular.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
					method : 'POST',

					success: function(form, action) {
						//form.reset();
						circleSchedular.getForm().findField('denoSet').setValue(action.result.denoSet);
						circleSchedular.getForm().findField('exeTillDate').setValue(action.result.exeTillDate);
						circleSchedular.getForm().findField('negativeDays').setValue(action.result.negativeDays);
					},
					failure: function(form, action) {
						if(action.result != null)
							Ext.Msg.alert('Warning', action.result.errorMessage);
						else
						{	
							Ext.Msg.alert('Warning', "Attribite Mapping Error");
						}
					}
				});
			}
			else{
				var result="";
				if(cisid1==undefined || cisid1==null){
					result = "Circle Field is Mandatory.<br>";
				}
				if(cisDatasd1==undefined || cisDatasd1==null){
					result = result + "Month Field is Mandatory.<br>";
				}
				Ext.Msg.alert('Warning', "Please fill the Mandatory Fields.<br>"+result);
			}
		}
	},
	triggerAction:'all'
},

{
	xtype :'numberfield',
	fieldLabel: 'Negative Days',
	name:'negativeDays',
	emptyText   : 'Negative Days',
	allowNegative: false,
	minValue: 0,
	allowBlank:true,
	editable: true,
	
},{
	xtype       : 'datefield',
	fieldLabel  : 'Exe Till Date',
	allowBlank  : true,
	emptyText   : 'Exe Till Date',
	name        : 'exeTillDate',
	//editable    : true,
},
]
},{
	xtype: 'container',
	columnWidth:.3,
	layout: 'anchor',
	items:[

{
	xtype       : 'textareafield',
	fieldLabel  : 'Deno Set',
	allowBlank  : true,
	emptyText   : 'Deno Set',
	name        : 'denoSet',
	editable    : false,
	width       : 400,
	//padding     : 5,
},{
	   xtype:'button',
	   text: 'Save',
	   float : 'left',
	   handler: function() {
    		   saveFrcDeno(circleSchedular);
	   }
   },]}]
},
{
	xtype:'fieldset',
	layout:'column',
	title: 'Scheme Execute Payout',
	height : 85,
	bodyStyle:'padding:3px 0px',
	collapsible: true,	
	items :[
	        {
	        	xtype       : 'datefield',
	        	fieldLabel  : 'From Date',
	        	allowBlank  : true,
	        	emptyText   : 'Start Date',
	        	name        : 'fromDate',
	        	editable    : false,
	        },
	        {
	        	xtype       : 'datefield',
	        	fieldLabel  : 'To Date',
	        	allowBlank  : true,
	        	emptyText   : 'End Date',
	        	name        : 'toDate',
	        	editable    : false,
	        },
	        {
	        	xtype:'button',
	        	text: 'Download',
	        	handler: function() {
	        		downloadScmExePayout(circleSchedular);
	        	}
	        }]
}]
});

var circleSchedularList = Ext.create('Ext.form.Panel', {
	border: false,
	items:[{
		xtype:'fieldset',
		layout: 'anchor',
		border:false,
		height:600,
		autoscroll:true,
		defaults: {
			anchor: '100%'
		},
		items :[
		        {
		        	html: "<div id='circleSched'></div>",
		        	xtype: "fieldset",
		        	border:false,
		        	autoscroll:true
		        }
		        ]}
	]});
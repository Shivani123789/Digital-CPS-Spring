var poFilterGridStatus = 0;
var spoFilterGridStatus = 0;







function savePoFilter(coverageForm)
{

	coverageForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/addPoFilter.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
        
		 success: function(form, action) {
            Ext.Msg.alert('Payout Filter Created Sucessfully');
            coverageForm.close();
            poFilterStore.load();
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        }
    });
	
}

function updatePoFilter(coverageForm)
{

	coverageForm.down('form').getForm().submit({
		
		 waitMsg : 'Loading...',
		 url : 'payoutcondition/updatePoFilter.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
		 params: {
			  "compId" : poCompId,
			  "condId":poCondId
		    },
       
        
		 success: function(form, action) {
            Ext.Msg.alert('Payout Filter updated successfully');
            coverageForm.close();
            poFilterStore.load();
        },
        failure: function(form, action) {
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        	{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        	}
        }
    });
	
}



var poFilterList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	//height:600,
 	
   items:[{
	   
     		xtype:'fieldset',
     		//title: 'Edit Scheme',
     		//collapsible: true,
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%',
     //			width:230
     		
     		},
     		items :[
     			{
             		html: "<div id='pofilterlist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});

var spoFilterList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
 	border: false,
 	//height:600,
 	
   items:[{
	   
     		xtype:'fieldset',
     		//title: 'Edit Scheme',
     		//collapsible: true,
     		layout: 'anchor',
     		border:false,
     		height:500,
     		autoscroll:true,
     		defaults: {
     		anchor: '100%',
     //			width:230
     		
     		},
     		items :[
     			{
             		html: "<div id='spofilterlist'></div>",
             		xtype: "fieldset",
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
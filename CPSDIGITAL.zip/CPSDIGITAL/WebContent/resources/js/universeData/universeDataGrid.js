Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	             ]);
	
var udValType=null;	
	function downloadUniverse(qualify)
	{
		var grid = Ext.ComponentQuery.query('TransUniverseDataList')[0];
		var sm = grid.getSelectionModel();
		var rs = sm.getSelection();
		var urlParam;
		var test1="";
		if(rs[0].data.inputTypeId==1){
			udValType = document.querySelector('input[name = "inputtype"]:checked').value;
			test1= 'This will download universe data for Type: '+udValType;
		}else{
			udValType='UD';
			test1='Download Universe Data ?';
		}
			
		Ext.Msg.confirm('Trans Data', 
				test1, 
				function (button) {
			if (button == 'yes') {
				if(qualify==='UD'){
					urlParam = './transData/getTransDataCSVDownload.action?schemeId=0' +'&compId=0'+
					'&conditionId=0'+'&qualifyType=1'+'&transSubDataType='+udValType+'&paymentId=0'+'&universeId='+rs[0].data.inputTypeId;
					window.open(urlParam,'_BLANK');
				}
			}
		});
	}
	
		
	var transUnivDataSearch = new Ext.Panel({     
		stripeRows  : true,
		frame       : false,
		border	   : false,
		style       : 'padding-bottom: 5px',
		layout	   :'column',
		anchor	   : '100%',
		items       : [	
		{
			xtype       : 'datefield',
			id          : 'startDateuSD',
			allowBlank  : false,
			emptyText   : 'StartDate',
			name        : 'startDateTrans',
			//width       : 140,
			editable    : false,
		},{
			xtype       : 'datefield',
			id          : 'endDateuSD',
			allowBlank  : false,
			emptyText   : 'EndDate',
			name        : 'endDateTrans',
			editable    : false,
		},

		{
				   xtype :'textfield',
				   fieldLabel: 'CsrfName',
				   hidden:true,
				   disabled : true,
				   name: 'csrfPayoutUn',
				   maxLength : 100,
				   allowBlank:false,
				   id:'testCsrfPayoutUn'
			}

		/*{
			xtype       : 'button',
			text        : 'Go',
			handler     : function () {
				
				var transDatasd = Ext.Date.format(Ext.getCmp("startDateuSD").getValue(),'d-M-y');
				var transDataed = Ext.Date.format(Ext.getCmp("endDateuSD").getValue(),'d-M-y');
				var grid = Ext.ComponentQuery.query('TransUniverseDataList')[0];
					grid.store.load({params:
				{
					"startDate"  :	transDatasd ,
					"endDate"    : 	transDataed,
					//condParam  : 	1,
				}});
			},
		}*/]
	});
	
	
	
	
	
	
	
	
	Ext.define('Scheme.view.TransUniverseDataList', {
		extend: 'Ext.grid.Panel',
		id:'transUniverseDataGrid',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:300,
		bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TransUniverseDataList',
		//title: 'Transaction Payment Data',
		store: transUniverseDataGrid,
		//height:500,
		autoScroll: true,
		listeners: {
		    select: function(selModel, record, index, options){/*
		    	transUniverseSubDataGrid.load({params:
				{
		    		inputTypeId  :	record.data.inputTypeId ,
		    	}});
		    */}
		},

		initComponent: function () {
			var me = this;
			this.tbar = [
			             		transUnivDataSearch
			             ];
			this.columns = [
			                { header: 'Universe Id', dataIndex: 'inputTypeId', flex: 1 },
			                { header: 'Universe Name', dataIndex: 'displayValue', flex: 1 },
			                { header: 'Type', dataIndex: 'inputTypeDesc', flex: 1 },
			                { header: 'Extract', width: 80,
	    	                	renderer: function (v, m, r) {
									var id = Ext.id();
	    	                		Ext.defer(function () {
	    	                			Ext.widget('image', {
	    	                				renderTo: id,
	    	                				name: 'testRun',
	    	                				src : 'resources/images/book_add.png',
	    	                				listeners : {
	    	                					afterrender: function (me) {
	    	                						me.getEl().on('click', function() {
	    	                							Ext.getCmp("testCsrfPayoutUn").setValue(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
	    	                							var grid = Ext.ComponentQuery.query('TransUniverseDataList')[0];
	    	                							var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateuSD").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateuSD").getValue(),'Y/m/d'));
	    	                							if (grid && flag) {
	    	                								var sm = grid.getSelectionModel();
	    	                								var rs = sm.getSelection();
	    	                								var startDt = Ext.Date.format(Ext.getCmp("startDateuSD").getValue(),'d-M-y');
	    	                								var endDt = Ext.Date.format(Ext.getCmp("endDateuSD").getValue(),'d-M-y');
	    	                								if(startDt == '' || endDt == '')
	    	                							    {
	    	                								  Ext.Msg.alert("Warning","<font color='blue'>'Start Date' and 'End Date' can not be left blank.</font>");
	    	                								  return false;
	    	                							    }
	    	                									if(rs[0].data.inputTypeId==1)
	    	                										udValType = document.querySelector('input[name = "inputtype"]:checked').value;
	   	    	                								else
	   	    	                									udValType='UD';
	    	                								if (!rs.length) {
	    	                									Ext.Msg.alert('Info', 'No Scheme Selected');
	    	                									return;
	    	                								}
	    	                								Ext.Msg.confirm('Extract Data', 
	    	                										'Do You want to Extract Data?', 
	    	                										function (button) {
	    	                									
	    	                									if (button == 'yes') {
	    	                										 Ext.ux.mask.show(); 
	    	                									Ext.Ajax.request({
	    	                				                     		  url : 'transData/getTransExecUniverseDataSearch.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
	    	                				                     		  method: 'POST',
	    	                				                     		// timeout:140000,
	    	                				                     		 waitMsg : 'Loading...',
	    	                				                     		 params: {
	    	                				                     			 "inputTypeId"   : rs[0].data.inputTypeId,
	    	                				                     			 "condiParam" : udValType,
	    	                				                     			 "startDt"     : startDt,
	    	                				                     			 "endDt"     : endDt,
	    	                				                 				  "success"   : true
	    	                				                 			    },
	    	                				                 			    
	    	                				                     		    success: function (response) {
	    	                				                     		    	 Ext.ux.mask.hide();
	    	                				                     		    	var jsonResp = Ext.JSON.decode(response.responseText);
	    	                				                    						if(jsonResp.success==false)	
	    	                				                    						{
	    	                				                    						Ext.Msg.alert(jsonResp.errorMessage);
	    	                				                    						}
	    	                				                    						else
	    	                				                    						Ext.Msg.alert("Info",jsonResp.errorMessage);
	    	                				                    				 
																		  grid.store.load({params:
																				{
																					startDate : startDt,
																					endDate : endDt,
																					isMaster : true,
																					isStage : false,
																					condiParam : 'UD'
																					}});
			                												},
	    	                				                     		  failure: function (response) {
	    	                				                     			 Ext.ux.mask.hide();
	    	                				                     			var jsonResp = Ext.JSON.decode(response.responseText);
	    	                				                						if(jsonResp.success==false)	
	    	                				                						{
	    	                				                						Ext.Msg.alert(jsonResp.errorMessage);
	    	                				                						}
	    	                				                						else
	    	                				                						Ext.Msg.alert("Info",jsonResp.errorMessage);
	    	                											  }
	    	                				                     		 })	;
	    	                									}
	    	                								});
	    	                							}
	    	                						});
	    	                					}
	    	                				}
	    	                			});
	    	                		}, 700);
									return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                },
	    	                {
	    	                	header: 'Download',dataIndex: 'download', width: 80,
	    	                	renderer: function (v, m, r) {
	    	                		var id = Ext.id();
	    	                		Ext.defer(function() {
	    	                			Ext.widget('button', {
	    	                				renderTo: id,
	    	                				//		disabled : true,
	    	                				text: 'Download',
	    	                				scale: 'small',
	    	                				handler: function() {
	    	                					downloadUniverse('UD');;
	    	                				}
	    	                			});
	    	                		}, 700);
	    	                		return Ext.String.format('<div id="{0}"></div>', id);
	    	                	}
	    	                },
			                ];
			this.dockedItems = [ {
				xtype : 'pagingtoolbar',
				store : transUniverseDataGrid,
				dock : 'bottom',
				displayInfo : true
			}];
			this.callParent(arguments);
		},
	});

   Ext.define('Scheme.view.TransUniverseSubDataList', {
		extend: 'Ext.grid.Panel',
		id:'transUniverseSubDataGrid',
		stripeRows: true,
		flex: 2,
		width:'100%',
		height:190,
		bodyStyle:'padding:3px 0px',
		hidden: false,
		loadMask: true,
		plugins: 'bufferedrenderer',
		remoteSort:true, remoteFilter :true, remoteGroup :true, 
		alias: 'widget.TransUniverseSubDataList',
		title: 'Transaction Universe Sub Data',
		store: transUniverseSubDataGrid,
		//height:500,
		autoScroll: true,

		initComponent: function () {
			var me = this;
			this.tbar = [
			             //transSubDataSearch
			             ];
			this.columns = [
			                { header: 'Start Date', dataIndex: 'minDt', flex: 1 },
			                { header: 'End Date', dataIndex: 'maxDt', flex: 1 },
			                { header: 'Total Count', dataIndex: 'headCount', flex: 1 },
			                ];
			this.dockedItems = [];
			this.callParent(arguments);
		},
	});
	
   Ext.define('Scheme.controller.TransUniverseDataCon', {
	   extend  : 'Ext.app.Controller',
	   stores  : ['Books'],
	   views   : ['TransUniverseDataList','TransUniverseSubDataList'],
	   init: function () {
		   this.control({
			   'TransUniverseDataList': {
				   itemdblclick: this.onRowdblclick
			   }
		   });
	   },

	   onRowdblclick: function(me, record, item, index) {
		   
		   var startDt = Ext.Date.format(Ext.getCmp("startDateuSD").getValue(),'d-M-y');
			var endDt = Ext.Date.format(Ext.getCmp("endDateuSD").getValue(),'d-M-y');
			var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateuSD").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateuSD").getValue(),'Y/m/d'));
			 if(startDt == '' || endDt == '')
			    {
				  Ext.Msg.alert("Warning","<font color='blue'>'Start Date' and 'End Date' can not be left blank.</font>");
				  //Ext.Msg.alert("Warning","<font color='red'>Please ensure that start date and end date should not be empty or blank.</font>");
				  return false;
			    }
			 if(record.data.inputTypeId==1)
					udValType = document.querySelector('input[name = "inputtype"]:checked').value;
				else
					udValType='UD';
			if(flag)
			transUniverseSubDataGrid.load({params:
		   {
			   inputTypeId  :	record.data.inputTypeId ,
			   "condiParam" : udValType,
			   "startDt"     : startDt,
   			   "endDt"     : endDt,
		   }});
	   }
   });
  
   
});
Ext.onReady(function () {

	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	         ]);
	
 
   
   
   
   var approveloadsd = null;
   var approveloaded = null;
   var apprPayToId = null;
   
   function changeReq(rejectForm)
   {
   	rejectForm.submit({
   		waitMsg : 'Loading...',
   		url : 'searchscheme/submitSchemeChange.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
   		method : 'POST',
   		success: function(form, action) {
   			Ext.Msg.alert("Info",action.result.errorMessage);
   			rejectForm.close();
			var grid = Ext.ComponentQuery.query('PayoutAppSchemeList')[0];
									grid.store.load({params:
   			                		 {
   			                			 startDate: approveloadsd,
   			                			 endDate: approveloaded,
   			                			 schemeComp : Ext.getCmp("schemeNameAppr").getValue()!='' ? Ext.getCmp("schemeNameAppr").getValue() : 'ABCDEF',
										 schemeId : Ext.getCmp("schemeNameIdAppr").getValue()!=null ? Ext.getCmp("schemeNameIdAppr").getValue() : '-1',
										 componentName : Ext.getCmp("compNameAppr").getValue()!='' ? Ext.getCmp("compNameAppr").getValue() : 'ABCDEF',
										 payTo :  apprPayToId != null ? apprPayToId : '-1',
										 // filterBy:reportloadfilter,
   			                			 isMaster:true,
   			                			 isStage:false,
   			                			 condParam:'A'
   			                		 }});

   		},
   		failure: function(form, action) {
   			if(action.result != null)
   				Ext.Msg.alert('Warning', action.result.errorMessage);
   			else
   				if(action.response.status=403)
   					Ext.Msg.alert('Warning','Access Denied' );
   				else
   				{
   					Ext.Msg.alert('Warning', "Attribite Mapping Error");
   				}


   		}
   	});

   } 
   function changeForm()
   {
   	var grid = Ext.ComponentQuery.query('PayoutAppSchemeList')[0];
   	if (grid) {
   		var sm = grid.getSelectionModel();
   		var rs = sm.getSelection();
   		var myForm = new Ext.form.Panel({
   			width: 300,
   			height: 200,
   			//layout: 'anchor',
   			title: 'Change Request',
   			floating: true,
   			border: true,
   			frame : true,
   			closable : true,
   			bodyStyle: {
   				//  background: 'none',
   				padding: '10px',
   				border: '0'
   			},
   			items:[
   			       {
   			    	   xtype : 'hidden',  //should use the more standard hiddenfield
   			    	   name  : 'schemeId',
   			    	   value: rs[0].data.schemeINputId
   			       },
   			       {
   			    	   xtype : 'hidden',  //should use the more standard hiddenfield
   			    	   name  : 'compId',
   			    	   value: rs[0].data.compId
   			       },
   			       {
   			    	   xtype : 'hidden',  //should use the more standard hiddenfield
   			    	   name  : 'componentName',
   			    	   value: rs[0].data.compName
   			       },
   			       {
   			    	   xtype :'textfield',
   			    	   fieldLabel: 'Change Desc',
   			    	   name: 'changeDesc',
   			    	   allowBlank:false
   			       }
   			       ],

   			       buttons: [	
   			                 {
   			                	 text: 'Ok',
   			                	 //action: 'add'
   			                	 handler: function () { 
   			                		changeReq(myForm);
   			                		
   			                		 //myForm.close();
   			                	 }
   			                 },
   			                 {
   			                	 text   : 'Cancel',
   			                	 handler: function () { 
   			                		 myForm.close();
   			                	 }
   			                 }]

   		});
   		myForm.show();

   	}
   }

   
   
   
   function downloadApproved()
   {

//	   alert("hiiii");
	   var grid = Ext.ComponentQuery.query('PayoutAppSchemeList')[0];
	   var sm = grid.getSelectionModel();
	   var rs = sm.getSelection();

//	   alert(rs[0].data.schemeINputId);

Ext.Msg.confirm('Validate Payout', 
		'Download Payout  CSV', 
		function (button) {
	if (button == 'yes') {
		var urlParam = './csv/downloadValidPayoutCSV.action?schemeId='+rs[0].data.schemeINputId +'&compId='+rs[0].data.compId+
		'&toDate='+rs[0].data.endDate+'&fromDate='+rs[0].data.startDate+'&csvType=Payout'+'&compStatus='+rs[0].data.schemeStatus;
		window.open(urlParam,'_SELF');
		//window.open(urlParam,'_self');toDate,fromDate,csvType
	}
});
}
   var approveschemeSearch = new Ext.Panel({     
       stripeRows  : true,
       frame       : false,
       border: false,
       style       : 'padding-bottom: 5px',
       layout:'column',
       anchor: '100%',
       items       : [{
                       xtype       : 'datefield',
                       id          : 'startDateApprove',
                       allowBlank  : true,
                       emptyText   : 'StartDate',
                       name        : 'startDateApprove',
                       //width       : 140,
                       editable    : false,
					   value : new Date(date.getFullYear(), date.getMonth(), 1)
                     },{
                       xtype       : 'datefield',
                       id          : 'endDateApprove',
                       allowBlank  : true,
                       emptyText   : 'EndDate',
                       name        : 'endDateApprove',
                       editable    : false,
					   value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
                     },
                     {
                 		xtype       : 'textfield',
                 		id          : 'schemeNameAppr',
                 		allowBlank  : true,
                 		emptyText   : 'Scheme Name',
                 		name        : 'schemeComp',
                 		//width       : 140,
                 		editable    : true,
                 		// maskRe:/[A-Za-z0-9_- ]/,
                 		maxLength : 100,
    		        	enforceMaxLength:"true"
                 		// format      : 'dd-MMM-yyyy'
                 	},
                 	{
                 		xtype       : 'numberfield',
                 		id          : 'schemeNameIdAppr',
                 		allowBlank  : true,
                 		emptyText   : 'Scheme ID',
                 		name        : 'schemeId',
                 		allowNegative: false,
                 		//width       : 140,
                 		editable    : true,
                 		maxLength : 38,
    		        	enforceMaxLength:"true"
                 		// format      : 'dd-MMM-yyyy'
                 	},
                 	 {
                 		xtype       : 'textfield',
                 		id          : 'compNameAppr',
                 		allowBlank  : true,
                 		emptyText   : 'Component Name',
                 		name        : 'componentName',
                 		// maskRe:/[A-Za-z0-9_- ]/,
                 		//width       : 140,
                 		editable    : true,
                 		maxLength : 100,
    		        	enforceMaxLength:"true"
                 		// format      : 'dd-MMM-yyyy'
                 	},
                 	{
                  		xtype: 'combo',
                  		store:payToStore,
                  		emptyText   : 'Pay To',
                  		//fieldLabel: 'Table Field',
                  		displayField:'displayValue',
                  		editable: false,
                  		valueField:'entityTypeId',
                  		name: 'payTo',
                  		listeners: {
                  			'select': function(combo, value){
                  				apprPayToId = combo.getValue();
                  				//alert("payto ::: "+combo.getValue());
                  			}
                  		}
                  	},
                  	{
        		    	   xtype :'textfield',
        		    	   fieldLabel: 'CsrfName',
						   hidden:true,
        		    	   disabled : true,
        		    	   name: 'csrfPayment',
						   maxLength : 100,
        		    	   allowBlank:false,
        		    	   id:'testCsrfPayout'
        		    },
					
                     {
                           xtype       : 'button',
                           text        : 'Go',
                           //width       : 40,
                           handler     : function () {
                           //	payoutAppSchemeGrid.clearFilter(true);
						   approveloadsd = Ext.Date.format(Ext.getCmp("startDateApprove").getValue(),'d-M-Y');
						   approveloaded = Ext.Date.format(Ext.getCmp("endDateApprove").getValue(),'d-M-Y');
						   var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("startDateApprove").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("endDateApprove").getValue(),'Y/m/d'));
						   if(flag){
							   var apprScmName = Ext.getCmp("schemeNameAppr").getValue()!='' ? Ext.getCmp("schemeNameAppr").getValue() : 'ABCDEF';
							   var apprScmId = Ext.getCmp("schemeNameIdAppr").getValue()!=null ? Ext.getCmp("schemeNameIdAppr").getValue() : '-1';
							   var apprCompName = Ext.getCmp("compNameAppr").getValue()!='' ? Ext.getCmp("compNameAppr").getValue() : 'ABCDEF';	
							   apprPayToId = apprPayToId != null ? apprPayToId : '-1';
								
							   payoutAppSchemeGrid.load({params:
							   {
								   startDate:	approveloadsd ,
								   endDate: approveloaded,
								   schemeComp : apprScmName,
								   schemeId : apprScmId,
								   componentName : apprCompName,
								   payTo : apprPayToId,//	filterBy:combo.getValue(),
								   isMaster:false,
								   isStage:true,
								   condParam:'A',
								   page:1,
								   start :	0
							   }});
						   }
                     },
                     
                   }
                   
                   
                     
               ]
   });
	
  
   Ext.define('Scheme.view.PayoutAppSchemeList', {
    extend: 'Ext.grid.Panel',
    id:'payoutappschemeGrid',
    stripeRows: true,
   // selModel : Ext.create('Ext.selection.CheckboxModel'),    
    flex: 2,
//    width:1120,
    height: '100%',
	layout: 'fit',
	bodyStyle:'padding:3px 0px',
    //bodyStyle:'padding:0px',
    hidden: false,
    loadMask: true,
    columnLines: true, 
    plugins: 'bufferedrenderer',
    remoteSort:true, remoteFilter :true, remoteGroup :true, 
    alias: 'widget.PayoutAppSchemeList',
    title: 'Payout Approval',
    store: payoutAppSchemeGrid,
    //height:500,
    autoScroll: true,
    
    initComponent: function () {
    	 var me = this;
      this.tbar = [
                   	approveschemeSearch
                ];
      this.columns = [
        { header: 'Scheme Id', dataIndex: 'schemeINputId', flex: 1 },
        { header: 'Scheme Name', dataIndex: 'schemeName', width: 150  },
        { header: 'Comp Id', dataIndex: 'compId', flex: 1 },
        { header: 'Comp Name', dataIndex: 'compName', width: 150 },
		{ header: 'Create Date', dataIndex: 'insertTime', flex: 1 },
		{ header: 'PayTo', dataIndex: 'payTo', flex: 1 },
		{ header: 'Start Date', dataIndex: 'startDate', flex: 1 },
		{ header: 'End Date', dataIndex: 'endDate', flex: 1 },
		{ header: 'Status', dataIndex: 'schemeStatus', flex: 1 },
		//{ header: 'Region', dataIndex: 'region', flex: 1 },
		//{ header: 'Zone', dataIndex: 'zone', flex: 1 },
		{ header: 'Net_Payout Amt', dataIndex: 'payAmtStr', flex: 1 },
		{ header: 'Max Pay', dataIndex: 'maxPayStr', flex: 1 },
		{ header: 'Min Pay', dataIndex: 'minPayStr', flex: 1 },
		{ header: 'Execute', flex: 1,
			renderer: function (v, m, r) {
				var id = Ext.id();
				Ext.defer(function () {
					Ext.widget('image', {
						renderTo: id,
						name: 'retestRun',
						src : 'resources/images/book_add.png',
						listeners : {
							afterrender: function (me) {

								me.getEl().on('click', function() {
									var grid = Ext.ComponentQuery.query('PayoutAppSchemeList')[0];
									if (grid) {
										var sm = grid.getSelectionModel();
										var rs = sm.getSelection();
										if (!rs.length) {
											Ext.Msg.alert('Info', 'No Scheme Selected');
											return;
										}
										Ext.Msg.confirm('Execute Payout', 
												'Do You want to execute Payout?', 
												function (button) {

											if (button == 'yes') {
												Ext.ux.mask.show(); 
												Ext.Ajax.request({
													url : 'postexec/testValidateApproveScheme.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
													method: 'POST',
													timeout:120000,
													waitMsg : 'Loading...',
													params: {
														"output":rs[0].data.schemeINputId,
														"compId":rs[0].data.compId,
														"condiType":'P',
														"success" : true
													},

													success: function (response) {
														Ext.ux.mask.hide();
														var jsonResp = Ext.JSON.decode(response.responseText);
														//	console.log(jsonResp); 
														if(jsonResp.success==false)	
														{
															Ext.Msg.alert(jsonResp.errorMessage);
														}
														else
															Ext.Msg.alert("Info",jsonResp.errorMessage);
														//console.log(response);
														grid.store.load({params:
														{
															startDate:	approveloadsd ,
															endDate: approveloaded,
															schemeComp : Ext.getCmp("schemeNameAppr").getValue()!='' ? Ext.getCmp("schemeNameAppr").getValue() : 'ABCDEF',
															schemeId : Ext.getCmp("schemeNameIdAppr").getValue()!=null ? Ext.getCmp("schemeNameIdAppr").getValue() : '-1',
															componentName : Ext.getCmp("compNameAppr").getValue()!='' ? Ext.getCmp("compNameAppr").getValue() : 'ABCDEF',
															payTo :  apprPayToId != null ? apprPayToId : '-1',
															//	filterBy:combo.getValue(),
															isMaster:false,
															isStage:true,
															condParam:'A'
														}});

													},

													failure: function (response) {
														var jsonResp = Ext.JSON.decode(response.responseText);
														//	console.log(jsonResp); 
														if(jsonResp.success==false)	
														{
															Ext.Msg.alert(jsonResp.errorMessage);
														}
														else
															Ext.Msg.alert("Info",jsonResp.errorMessage);
														grid.store.load({params:
														{
															startDate:	approveloadsd ,
															endDate: approveloaded,
															schemeComp : Ext.getCmp("schemeNameAppr").getValue()!='' ? Ext.getCmp("schemeNameAppr").getValue() : 'ABCDEF',
															schemeId : Ext.getCmp("schemeNameIdAppr").getValue()!=null ? Ext.getCmp("schemeNameIdAppr").getValue() : '-1',
															componentName : Ext.getCmp("compNameAppr").getValue()!='' ? Ext.getCmp("compNameAppr").getValue() : 'ABCDEF',
															payTo :  apprPayToId != null ? apprPayToId : '-1',
															//	filterBy:combo.getValue(),
															isMaster:false,
															isStage:true,
															condParam:'A'
														}});

														console.log(response);

													}
												})	;
											}
										}


										);
									}
								});
							}
						}
					});
				}, 70);
				return Ext.String.format('<div id="{0}"></div>', id);
			}

		},
		
		//Excecution Date
		
		
        {
        	header: 'Last Execution',dataIndex: 'execDate', width: 100,
        	renderer: function (v, m, r) {
        		var id = Ext.id();
        		if(v!=null)
        		{
        			Ext.defer(function() {
        				Ext.widget('button', {
        					renderTo: id,
        					text: v,
        					scale: 'small',
        					handler: function() {
        						downloadApproved();
        					}
        				});
        			}, 50);
        		}
        		else
        		{
        			Ext.defer(function() {
        				Ext.widget('button', {
        					renderTo: id,
        					disabled : true,
        					text: 'Not Executed',
        					scale: 'small',
        					handler: function() {
        					}
        				});
        			}, 50);
        		}
        		return Ext.String.format('<div id="{0}"></div>', id);
        	}
        },
		{ header: 'Approve', flex: 1,
            renderer: function (v, m, r) {
              var id = Ext.id();
              var max = 15;
              Ext.defer(function () {
                Ext.widget('image', {
                  renderTo: id,
                  name: 'approve',
                  src : 'resources/images/submit.png',
                  listeners : {
                    afterrender: function (me) { 
                      me.getEl().on('click', function() {
                        var grid = Ext.ComponentQuery.query('PayoutAppSchemeList')[0];
                        if (grid) {
                          var sm = grid.getSelectionModel();
                          var rs = sm.getSelection();
                          if (!rs.length) {
                            Ext.Msg.alert('Info', 'No Scheme Selected');
                            return;
                          }
                          
                            
                          Ext.Msg.confirm('Approve Payout', 
                            'Do you want to Approve payout?', 
                            function (button) {
                              if (button == 'yes') {
                              	
                              		Ext.Ajax.request({
                              			  url : "postexec/updateScheme.action?csrf="+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
                              			  method: 'POST',
                              			  params: {
                              				  "schemeId" : rs[0].data.schemeINputId,
                              				  "compId": rs[0].data.compId,
                              				  "success" : true
                              			    },
                              			    success: function (response) {
                              			    	var jsonResp = Ext.JSON.decode(response.responseText);
                              					//	console.log(jsonResp); 
                              							if(jsonResp.success==false)	
                              							{
                              							Ext.Msg.alert("Error",jsonResp.errorMessage);
                              							}
                              							else
                              							Ext.Msg.alert("Info",jsonResp.errorMessage);
                              					 grid.store.load({params:
																	{
																	startDate:	approveloadsd ,
																	endDate: approveloaded,
																	schemeComp : Ext.getCmp("schemeNameAppr").getValue()!='' ? Ext.getCmp("schemeNameAppr").getValue() : 'ABCDEF',
																	schemeId : Ext.getCmp("schemeNameIdAppr").getValue()!=null ? Ext.getCmp("schemeNameIdAppr").getValue() : '-1',
																	componentName : Ext.getCmp("compNameAppr").getValue()!='' ? Ext.getCmp("compNameAppr").getValue() : 'ABCDEF',
																	payTo :  apprPayToId != null ? apprPayToId : '-1',
																	//	filterBy:combo.getValue(),
																	isMaster:false,
																	isStage:true,
																	condParam:'A'
																	}});

                               			     // payoutAppSchemeGrid.load();
                              			    },
                               			 
                              			  failure: function (response) {
                              			       }
                              			 });
                              //  grid.store.remove(rs[0]);
                              }
                          });
                        }
                      });
                    }
                  }
                });
              }, 50);
              return Ext.String.format('<div id="{0}"></div>', id);
            }
          },
          {
          	header: 'Change Request', flex: 1,
          	renderer: function (v, m, r) {
          		var id = Ext.id();
          		
          		Ext.defer(function() {
          			Ext.widget('button', {
          				renderTo: id,
          				
          				text: 'CR',
          				scale: 'small',
          				handler: function() {
          					changeForm();
          				}
          			});
          		}, 70);
          		
					
          		return Ext.String.format('<div id="{0}"></div>', id);
          	}
          }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : payoutAppSchemeGrid,
			dock : 'bottom',
			displayInfo : true
		}
      ];
      
      this.callParent(arguments);
    },
    
  });
 

  Ext.define('Scheme.controller.ApproveSchemeCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    
    views   : ['PayoutAppSchemeList'],
    

  });
 
   
  
});
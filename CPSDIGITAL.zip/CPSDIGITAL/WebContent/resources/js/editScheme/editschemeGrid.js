Ext.onReady(function () {

	
	//Search Grid
	
	
	 Ext.ux.mask = new Ext.LoadMask(Ext.getBody(), {msg: "Loading..."});
	 Ext.ux.mask.show(); 
	    
	    
	  
	var gridSearch = new Ext.Panel({     
        stripeRows  : true,
        frame       : false,
        border: false,
        style       : 'padding-bottom: 5px',
        layout:'column',
        anchor: '100%',
        items       : [{
                        xtype       : 'datefield',
                       id          : 'startDate',
                        allowBlank  : true,
                        
                        name        : 'startDate',
                        //width       : 140,
                        editable    : false,
						value : new Date(date.getFullYear(), date.getMonth(), 1)
                       // format      : 'dd-MMM-yyyy'
                      },{
                        xtype       : 'datefield',
                        id          : 'endDate',
                        allowBlank  : true,
                        name        : 'endDate',
                        //width       : 140,
                        editable    : false,
						value : new Date(date.getFullYear(), date.getMonth() + 1, 0)
                       // format      : 'dd-MMM-yyyy'
                      },
						
						{
                         xtype       : 'combo',
                        // id          : 'filterBy',
                         displayField:'name',
 							valueField:'id',
                         allowBlank  : true,
                         
                         name        : 'filterBy',
                         //width       : 140,
                         editable    : false,
                         store: editSchemeFilterStore(),
                         listeners: {
     						'select': function(combo, value){
     					//	circleid = combo.getValue();
     						schemeStoreGrid.clearFilter(true);

							if(combo.getValue()==1)
     						{
							schemeStoreGrid.load({params:
							{
                           	startDate:Ext.Date.format(Ext.getCmp("startDate").getValue(),'d-M-y') ,
                           	endDate: Ext.Date.format(Ext.getCmp("endDate").getValue(),'d-M-y'),
                           	filterBy:combo.getValue(),
                           	isMaster:true,
                           	isStage:false,
                           	condParam:'I'
                           	}});
							
							
     						}
							
							if(combo.getValue()==2)
     						{
							schemeStoreGrid.load({params:
							{
                           	startDate:Ext.Date.format(Ext.getCmp("startDate").getValue(),'d-M-y') ,
                           	endDate: Ext.Date.format(Ext.getCmp("endDate").getValue(),'d-M-y'),
                           	filterBy:combo.getValue(),
                           	isMaster:true,
                           	isStage:false,
                           	condParam:'W'
                           	}});
							
							
     						}
							
							if(combo.getValue()==3)
							{
     						schemeStoreGrid.load({params:
							{
                           	startDate:Ext.Date.format(Ext.getCmp("startDate").getValue(),'d-M-y') ,
                           	endDate: Ext.Date.format(Ext.getCmp("endDate").getValue(),'d-M-y'),
                           	filterBy:combo.getValue(),
                           	isMaster:true,
                           	isStage:false,
                           	condParam:'D'
                           	}});
							
							
     						}
							
							if(combo.getValue()==4)
     						{
							schemeStoreGrid.load({params:
							{
                           	startDate:Ext.Date.format(Ext.getCmp("startDate").getValue(),'d-M-y') ,
                           	endDate: Ext.Date.format(Ext.getCmp("endDate").getValue(),'d-M-y'),
                           	filterBy:combo.getValue(),
                           	isMaster:true,
                           	isStage:false,
                           	condParam:'A'
                           	}});
							
							
     						}

							}
     						},
     						triggerAction:'all'
                        
                       }
                       
                
                ]
    });
	var gridSearch = new Ext.Panel({     
        stripeRows  : true,
        frame       : false,
		
        border: false,
        style       : 'padding-bottom: 5px',
        layout:'column',
        anchor: '100%',
        items       : [{
                        xtype       : 'datefield',
                       id          : 'startDate',
                        allowBlank  : true,
                        emptyText   : 'StartDate',
                        name        : 'startDate',
                        //width       : 140,
                        editable    : false,
                       // format      : 'dd-MMM-yyyy'
                      },{
                        xtype       : 'datefield',
                        id          : 'endDate',
                        allowBlank  : true,
                        emptyText   : 'EndDate',
                        name        : 'endDate',
                        //width       : 140,
                        editable    : false,
                       // format      : 'dd-MMM-yyyy'
                      },
						
						{
                         xtype       : 'combo',
                        // id          : 'filterBy',
                         displayField:'name',
 							valueField:'id',
                         allowBlank  : true,
                         
                         name        : 'filterBy',
                         //width       : 140,
                         editable    : false,
                         store: editSchemeFilterStore(),
                         listeners: {
     						'select': function(combo, value){
     					//	circleid = combo.getValue();
     						schemeStoreGrid.clearFilter(true);

							if(combo.getValue()==1)
     						{
							schemeStoreGrid.load({params:
							{
                           	startDate:Ext.Date.format(Ext.getCmp("startDate").getValue(),'d-M-y') ,
                           	endDate: Ext.Date.format(Ext.getCmp("endDate").getValue(),'d-M-y'),
                           	filterBy:combo.getValue(),
                           	isMaster:true,
                           	isStage:false,
                           	condParam:'I'
                           	}});
							
							
     						}
							
							if(combo.getValue()==2)
     						{
							schemeStoreGrid.load({params:
							{
                           	startDate:Ext.Date.format(Ext.getCmp("startDate").getValue(),'d-M-y') ,
                           	endDate: Ext.Date.format(Ext.getCmp("endDate").getValue(),'d-M-y'),
                           	filterBy:combo.getValue(),
                           	isMaster:true,
                           	isStage:false,
                           	condParam:'W'
                           	}});
							
							
     						}
							
							if(combo.getValue()==3)
							{
     						schemeStoreGrid.load({params:
							{
                           	startDate:Ext.Date.format(Ext.getCmp("startDate").getValue(),'d-M-y') ,
                           	endDate: Ext.Date.format(Ext.getCmp("endDate").getValue(),'d-M-y'),
                           	filterBy:combo.getValue(),
                           	isMaster:true,
                           	isStage:false,
                           	condParam:'D'
                           	}});
							
							
     						}
							
							if(combo.getValue()==4)
     						{
							schemeStoreGrid.load({params:
							{
                           	startDate:Ext.Date.format(Ext.getCmp("startDate").getValue(),'d-M-y') ,
                           	endDate: Ext.Date.format(Ext.getCmp("endDate").getValue(),'d-M-y'),
                           	filterBy:combo.getValue(),
                           	isMaster:true,
                           	isStage:false,
                           	condParam:'A'
                           	}});
							
							
     						}

							}
     						},
     						triggerAction:'all'
                        
                       }
                       
                
                ]
    });
	
	
	
	
	
	
	
	
	Ext.require([
	             'Ext.grid.plugin.BufferedRenderer'
	         ]);
	
   Ext.define('Scheme.model.Book', {
    extend: 'Ext.data.Model',
    fields: [
      {name: 'schemeName', type: 'string'},
      {name: 'circleName',  type: 'string'}
   
    ]
  });
 
   Ext.define('schemeModel', {
	    extend: 'Ext.data.Model',
	    fields: [
	      {name: 'schemeINputId', type: 'int'},
	      {name: 'schemeName', type: 'string'},
	      {name: 'circleId',  type: 'int'}
	   
	    ]
	  });
   
   
   
  Ext.define('Scheme.store.Books', {
    extend  : 'Ext.data.Store',
    model   : 'Scheme.model.Book',
    fields  : ['title', 'author','price', 'qty'],
    data    : [
      { title: 'JDBC, Servlet and JSP', 
        author: 'Santosh Kumar', price: 300, qty : 12000 },
      { title: 'Head First Java', 
        author: 'Kathy Sierra', price: 550, qty : 2500 },
      { title: 'Java SCJP Certification', 
        author: 'Khalid Mughal', price: 650, qty : 5500 },
      { title: 'Spring and Hinernate', 
        author: 'Santosh Kumar', price: 350, qty : 2500 },
      { title: 'Mastering C++', 
        author: 'K. R. Venugopal', price: 400, qty : 1200 }
    ]
  });
 
   Ext.define('Scheme.view.SchemeList', {
    extend: 'Ext.grid.Panel',
    id:'schemeGrid',
    stripeRows: true,
	layout : 'fit',
    //flex: 2,
  //  border:false,
//  bodyStyle:'padding:3px 0px',
    hidden: false,
    loadMask: true,
    //loadMask: true,
    plugins: 'bufferedrenderer',
    remoteSort:true, remoteFilter :true, remoteGroup :true, 
    //pageSize : 5,
    alias: 'widget.SchemeList',
    title: 'Edit Scheme',
    store: schemeStoreGrid,
    //width:1120,
    height: '100%',
    //bodyStyle:'padding:0px',
    //width:1000,
    autoScroll: true,
    
    initComponent: function () {
    	 var me = this;
      this.tbar = [
					gridSearch
                ];
      this.columns = [
        { header: 'Scheme Id', dataIndex: 'schemeINputId', flex: 1 },
        { header: 'Scheme Name', dataIndex: 'schemeName', flex: 1 },
        
		{ header: 'Comp Name', dataIndex: 'compName', flex: 1 },
		{ header: 'Create Date', dataIndex: 'insertTime', flex: 1 },
		{ header: 'PayTo', dataIndex: 'payTo', flex: 1 },
		{ header: 'Start Date', dataIndex: 'startDate', flex: 1 },
		{ header: 'End Date', dataIndex: 'endDate', flex: 1 },
		{ header: 'Status', dataIndex: 'schemeStatus', flex: 1 },
        { header: 'Remarks', dataIndex: 'remarks', flex: 1 },
        
       // { header: 'Validity Flag', dataIndex: 'valFlag', width: 80 },
       // { header: 'Create Date', dataIndex: 'cDate', width: 80 },
        { header: 'Select', flex: 1,
          renderer: function (v, m, r) {
            var id = Ext.id();
            var max = 15;
            Ext.defer(function () {
              Ext.widget('image', {
                renderTo: id,
                name: 'delete',
                src : 'resources/images/book_delete.png',
                listeners : {
                  afterrender: function (me) { 
                    me.getEl().on('click', function() {
                      var grid = Ext.ComponentQuery.query('SchemeList')[0];
                      if (grid) {
                        var sm = grid.getSelectionModel();
                        var rs = sm.getSelection();
                        if (!rs.length) {
                          Ext.Msg.alert('Info', 'No Scheme Selected');
                          return;
                        }
                        
                          
                        Ext.Msg.confirm('Remove Scheme', 
                          'Are you sure you want to delete Scheme?', 
                          function (button) {
                            if (button == 'yes') {
                            	
                            		Ext.Ajax.request({
                            			  url : removeSchemeUrl,
                            			  method: 'POST',
                            			  params: {
                            				  "schemeINputId" : rs[0].data.schemeINputId,
                            				  "schemeName" :rs[0].data.schemeName
                            			    },
                            			    success: function (response) {
                             			         Ext.Msg.alert("Info",response.responseText+" Scheme deleted Sucessfully");
                             			        schemeStore.load();
                            			    },
                             			 
                            			  failure: function (response) {
                            			       }
                            			 });
                              grid.store.remove(rs[0]);
                            }
                        });
                      }
                    });
                  }
                }
              });
            }, 50);
            return Ext.String.format('<div id="{0}"></div>', id);
          }
        }
      ];
      this.dockedItems = [ {
			xtype : 'pagingtoolbar',
			store : schemeStoreGrid,
			dock : 'bottom',
			displayInfo : true
		}
		
      ];
      
      this.callParent(arguments);
    },
    
    afterRender: function() {
        var me = this;
        me.callParent(arguments);
        me.textField = me.down('textfield[name=searchField]');
        me.statusBar = me.down('statusbar[name=searchStatusBar]');
    },
    
    
    onTextFieldChange: function(field, newValue, oldValue, options){
        if(newValue==''){
        	schemeStoreGrid.clearFilter();
        }
        
        
        else {
        	schemeStoreGrid.clearFilter(true);
        	if(newValue.length>=4){
        		schemeStoreGrid.filter("schemeName",newValue);
        	}
       	
        //	this.view.refresh();
        //	schemeStoreGrid.load();
        //	schemeStoreGrid.load().filter(filters);            
        }
    }
    
    
//
//        // no results found
//        if (me.currentIndex === null) {
//            me.getSelectionModel().deselectAll();
//        }
//
//        // force textfield focus
//        me.textField.focus();
//    }
  });
 
    Ext.define('Scheme.view.SchemeForm', {
      extend  : 'Ext.window.Window',
      alias   : 'widget.SchemeForm',
      title   : 'Edit Scheme',
      width   : 800,
      height:   500,
      autoscroll:true,
      layout  : 'fit',
      resizable: false,
      closeAction: 'hide',
      modal   : true,
      config  : {
        recordIndex : 0,
        action : ''
      },
      items   : [{
        xtype : 'form',
        layout: 'anchor',
        bodyStyle: {
          background: 'none',
          padding: '10px',
          border: '0'
        },
        defaults: {
          //xtype : 'textfield',
          anchor: '100%'
        },
        items : [	          
                 //	formPanel2
                 	{
                 xtype:'tabpanel',
                 id: 'searchtablist',
                 defaults:{
                 	bodyStyle:'padding:10px',
                 	preventBodyReset: true
                 	},
                 	items:[
								{
								    title:'Component',
								    id : '21',
								    items: [
								            	searchCompList
								           ]
									
								},
								
								{
								    title:'Region',
								    id : '22',
								    items: [
								            	sregList
								           ]
									
								},
								
								{
								    title:'Coverage',
								    id : '23',
								    items: [
								            	scovList
								           ]
									
								},
								
								{
								    title:'TQ',
								    id : '24',
								    items: [
								            	stqList
								           ]
									
								},
								
								{
								    title:'EA',
								    id : '25',
								    items: [
								            		seaList
								           ]
									
								},
								
								{
								    title:'EA_FILTER',
								    id : '26',
								    items: [
								            	seaFilterList
								           ]
									
								},
								{
								    title:'PO',
								    id : '27',
								    items: [
								            	spoList
								           ]
									
								}
                 	       
                 	       ],
                 	       
                 	      listeners: {
                 	    	  
                 	    	 'tabchange': function (tabPanel, tab) {
                 	    		 
                 	    		 
                 	    		if(tab.title=='Component')
                               	{
                 	    			searchcomponentStoreGrid.load();
                 	    			if(searchCompGridStatus==0)
                 	           		{
                 			    	Ext.application({
                 	               	    name  : 'Scheme',
                 	               	    controllers: ['SearchCompCon'],
                 	              	      launch: function () {
                 	               	    	  Ext.widget('SearchCompList', {
                 	               	          renderTo: 'searchcomplist'
                 	               	        });
                 	               	      }
                 	               	    }
                 	               	  );
                 			    	searchCompGridStatus = 1;
                 	           		}
                 	    			
                               	}
                 	    		 
                 	    		 
                 	    		if(tab.title=='Region')
                               	{
                 	    			sregZoneStore.load();
                 	               	if(sregGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SregCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SregList', {
                 	           	          renderTo: 'sreglist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              sregGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		
                 	    		if(tab.title=='Coverage')
                               	{
                 	    			scoverageStore.load();
                 	               	if(scovGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['ScovCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('ScovList', {
                 	           	          renderTo: 'scovlist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              scovGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		
                 	    		if(tab.title=='TQ')
                               	{
                 	    			stqStore.load();
                 	               	if(stqGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['StqCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('StqList', {
                 	           	          renderTo: 'stqlist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              stqGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		
                 	    		if(tab.title=='EA')
                               	{
                 	    			seaStore.load();
                 	               	if(seaGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SeaCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SeaList', {
                 	           	          renderTo: 'sealist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              seaGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		if(tab.title=='EA_FILTER')
                               	{
                 	    			seaFilterStore.load();
                 	               	if(seaFilterGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SeaFilterCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SeaFilterList', {
                 	           	          renderTo: 'seafilterlist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              seaFilterGridStatus=1;
                 	               }
                 	    			
                               	}
                 	    		
                 	    		if(tab.title=='PO')
                               	{
                 	    			spoStore.load();
                 	               	if(spoGridStatus==0)
                 	               		{
                 	               	console.log(tabPanel+ ' ' + tab.title);
                 	               Ext.application({
                 	           	    name  : 'Scheme',
                 	           	    controllers: ['SpoCon'],
                 	          	      launch: function () {
                 	           	    	  Ext.widget('SpoList', {
                 	           	          renderTo: 'spolist'
                 	           	        });
                 	           	      }
                 	           	    }
                 	           	  );
                 	              spoGridStatus=1;
                 	               }
                 	    			
                               	}
                               	
                 	    		
                 	    		 
                 	    	 }
                 	      }
                 			
					}
        ]
      }],
      buttons: [	
                	
                	{
                		text   : 'Cancel',
                		handler: function () { 
                		this.up('window').close();
                	}
      }]
    });
 
  Ext.define('Scheme.controller.SchemeCon', {
    extend  : 'Ext.app.Controller',
    stores  : ['Books'],
    
    views   : ['SchemeList', 'SchemeForm'],
    refs    : [{
      ref   : 'formWindow',
      xtype : 'SchemeForm',
      selector: 'SchemeForm',
      autoCreate: true
    }],
    init: function () {
      this.control({
        'SchemeList > toolbar > button[action=add]': {
          click: this.showAddForm
        },
          
        'SchemeList': {
          itemdblclick: this.onRowdblclick
        },
        'SchemeForm button[action=add]': {
          click: this.doAddBook
        }
      });
    },
    onRowdblclick: function(me, record, item, index) {
    	
    	SchemeName = record.data.schemeName;
		compName = "yes";
	
      var win = this.getFormWindow();
      win.setTitle('Edit Scheme');
      win.setAction('edit');
      win.setRecordIndex(record.data.schemeINputId);
      win.down('form').getForm().setValues(record.getData());
     
      Ext.Ajax.request({
		  url : 'payoutcondition/resetScheme.action',
		  method: 'POST',
		  params: {
			  "schemeINputId" : record.data.schemeINputId,
			  "schemeName" :record.data.schemeName//record.data.schemeINputId
		    },
		    success: function (response) {
		    	searchcomponentStoreGrid.load();
		    	
		    	win.show();
		    	if(searchCompGridStatus==0)
           		{
		    	Ext.application({
               	    name  : 'Scheme',
               	    controllers: ['SearchCompCon'],
              	      launch: function () {
               	    	  Ext.widget('SearchCompList', {
               	          renderTo: 'searchcomplist'
               	        });
               	      }
               	    }
               	  );
		    	searchCompGridStatus = 1;
           		}		    	
		    	
		        //schemeStore.load();
		    },
		 
		  failure: function (response) {
		       }
		 });
	
     
      
      
    },
    showAddForm: function () {
      var win = this.getFormWindow();
      win.setTitle('Add Scheme');
      win.setAction('add');
      win.down('form').getForm().reset();
      win.show();
    },
    doAddBook: function () {
      var win = this.getFormWindow();
      var store = this.getBooksStore();
      var values = win.down('form').getValues();
      
      var action = win.getAction();
      var book = Ext.create('schemeModel', values);
      if(action == 'edit') {
    	  console.log(book);
    	//  alert(book.data.schemeINputId);
    	//  alert(win.getRecordIndex());
    	  
        store.removeAt(win.getRecordIndex());
        store.insert(win.getRecordIndex(), book);  
      }
      else {
    	  saveScheme(win.down('form'));
    	  win.close();
    	  schemeStore.load();
    	  schemeStore.add(book);
      }
      win.close();
    }
  });
 
   
  
});
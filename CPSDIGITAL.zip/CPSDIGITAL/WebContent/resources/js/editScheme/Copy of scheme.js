

var circleid = null;

var formPanel = null;

var schemeNameEdit = null;

var  schemeIdEdit = null;

var isCreateEdit=null;

var autoSuggestTextBox = new Ext.form.ComboBox({
	name:'schemeNameOld',
	fieldLabel:'Scheme Name(Load Existing)*',
	displayField:'schemeName',
	valueField:'schemeName',
	editable: false,
	mode: 'local',
	store: schemeStoreCreate,
	triggerAction:'all',
	width: 500,
	listeners:{
		'select': function(combo, value){
			schemeForm.getForm().findField('schemeName').setValue(combo.getValue());

			Ext.Ajax.request({
				url : 'payoutcondition/getCircle.action',
				method: 'POST',
				params: {
					"schemeName" : combo.getValue()
				},

				success: function (response) {
					Ext.Ajax.request({
						url : 'payoutcondition/resetScheme.action',
						method: 'POST',
						params: {
							// "schemeINputId" : rs[0].data.schemeINputId,
							"schemeName" :combo.getValue()//record.data.schemeINputId
						}/*,
						success: function (response) {
							//schemeStore.load();
						},

						failure: function (response) {
						}
*/					});

				},

				failure: function (response) {
					
				}
			});


		}
	}
} );

var editScheme = new Ext.form.ComboBox({
	name:'schemeEdit',
	id:'schemeEdit',
	fieldLabel:'Select Scheme*',
	displayField:'schemeName',
	valueField:'schemeName',
	editable: false,
	store: schemeStoreEdit,
   triggerAction:'all',
	//width: 300,
	width: 500,
	listeners:{
		'select': function(combo, value){ 	
			schemeNameEdit = combo.getValue();
			schemeIdEdit = schemeStoreEdit.findRecord('schemeName',combo.getValue(),0, false, true, true);
			schemeIdEdit = schemeIdEdit.data.schemeINputId;
			//alert(schemeIdEdit);
			componentEditStoreGrid.clearFilter();
			//alert(schemeIdEdit);
			componentEditStoreGrid.filter('schemeId',schemeIdEdit);
			Ext.getCmp("schemeCompEdit").enable();
			Ext.getCmp("schemeCompEdit").reset();
		
		}
		}
} );



var editSchemeComp = new Ext.form.ComboBox({
	name:'schemeCompEdit',
	id:'schemeCompEdit',
	//disabled : true,
	fieldLabel:'Component',
	displayField:'compName',
	valueField:'compName',
	//allowBlank: false,
	editable: false,
	//typeAhead: true,
	mode: 'local',
	store: componentEditStoreGrid,
	triggerAction:'all',
//	selectOnFocus:true,
//	hideTrigger: true,
	width: 500,
	listeners:{
		select:{
			fn:function(combo,record,index) {

				Ext.Ajax.request({
					url : 'payoutcondition/resetScheme.action',
					method: 'POST',
					params: {
						"schemeName" :schemeNameEdit,
						"compName": combo.getValue()
					},
					success: function (response) {
						//Ext.getCmp("schemeCompEdit").reset();
						//Ext.getCmp("schemeEdit").reset();							
						compName = combo.getValue();



						formPanel.items.each(function(c){


							c.setActiveTab(c.items.items[1]);

							//componentStoreGrid.load();

						})


					},

					failure: function (response) {
					}
				});


			}
		}
	}
} );






function saveScheme(schemeForm)
{

	if(schemeForm.getForm().isValid())
	{
	schemeForm.getForm().submit({
		 waitMsg : 'Loading...',
		 url : addSchemeUrl,
		 method : 'POST',
        
		 success: function(form, action) {
			 if(action.result != null)
		            Ext.Msg.alert(action.result.schemeName+' '+action.result.createMode, action.result.errorMessage);
           // Ext.Msg.alert(action.result.schemeName+' Scheme Created Sucessfully');
            SchemeName = action.result.schemeName;
            form.reset();
			condBody = '';
			condBodyTq = '';
			
			
			if(action.result.createMode!='Copied')
				{
			
			formPanel.items.each(function(c){
		    	
				
				c.items.items[1].setDisabled(true);
						c.items.items[2].setDisabled(true);
						c.items.items[3].setDisabled(true);
						c.items.items[4].setDisabled(true);
						c.items.items[5].setDisabled(true);
						c.items.items[6].setDisabled(true);
						c.items.items[7].setDisabled(true);
						//c.items.items[8].setDisabled(true);
						
						c.items.items[1].setDisabled(false);
						c.setActiveTab(c.items.items[1]);
						})
						
				}
				
				else
				{
				
				formPanel.items.each(function(c){
		    	
				
						c.items.items[1].setDisabled(false);
						c.items.items[2].setDisabled(false);
						c.items.items[3].setDisabled(false);
						c.items.items[4].setDisabled(false);
						c.items.items[5].setDisabled(false);
						c.items.items[6].setDisabled(false);
						c.items.items[7].setDisabled(false);
					//	c.items.items[1].setDisabled(false);
						c.setActiveTab(c.items.items[1]);

				})
				
				
				
				
				}

           // componentStoreGrid.load();
           // regZoneStore.load();
        },
        failure: function(form, action) {
        	//console.log(action.response.status);
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        		}
        }
    });
	
	}
	
	else
		{
		Ext.Msg.alert('Warning', "Please Fill All Mandatory Fields");
		}
}

	

    var schemeForm = Ext.create('Ext.form.Panel', {
    	border: false,
    	//layout:'column',
    	bodyStyle:'padding:3px 5px',
    	width: 1100,
    	defaults: {
    		bodyStyle:'padding:3px 5px'
    	},
    	items:[
{
	xtype:'fieldset',
	//layout:'column',
	title: 'Search Data Filter',
	//height : ,
	bodyStyle:'padding:3px 0px',
	collapsible: true,	
	items :[
	      
	        {
	        	xtype       : 'datefield',
	        	fieldLabel  : 'Start Date',
	        	allowBlank  : true,
	        	emptyText   : 'Start Date',
	        	name        : 'fromDateSearchScm',
	        	id: 'fromDateSearchScm',
	        	editable    : false,
	        	padding: '0px 300px',
	        },
	        {
	        	xtype       : 'datefield',
	        	fieldLabel  : 'End Date',
	        	allowBlank  : true,
	        	emptyText   : 'End Date',
	        	name        : 'toDateSearchScm',
	        	id: 'toDateSearchScm',
	        	editable    : false,
	        	padding: '0px 300px',
	        },
	        { 

					xtype :'combo',
					fieldLabel: 'Pay To*',
					name:'payTo',
				    id:'payToValFilter',
					displayField:'displayValue',
					valueField:'entityTypeId',
					editable: false,
					store: payToStoreCreate,
					triggerAction:'all',
					padding: '0px 300px',
					
					listeners:{
					'select' :function(combo,value) {
						
						
						
						
					//	alert(Ext.getCmp("fromDateSearchScm").getValue());
						
						
						if(Ext.getCmp("fromDateSearchScm").getValue()!=null && Ext.getCmp("toDateSearchScm").getValue()!=null)
							{
							Ext.getCmp("schemeRadioGroupID").enable();
						schemeStoreCreate.load(
						{
							params: 
								{  
								
								    "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-y'),
								    "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-y'),
								    "payTo": Ext.getCmp("payToValFilter").getValue()
							
								}
						}		
						);
						
						schemeStoreEdit.load(
						{
								params:
									{
									
									  "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-y'),
									  "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-y'),
									  "payTo": Ext.getCmp("payToValFilter").getValue()

									}

						}
					
						
						);
						
							}	
						
						else
							{
							Ext.getCmp("schemeRadioGroupID").disable();

							Ext.Msg.alert(" Please provide start date / end date values");
							
							Ext.getCmp("payToValFilter").reset();
							}
						
						
						}
					}
						
	        	
	        },
	        {

        		xtype: 'radiogroup',
        		width:'190%',
        		id: 'schemeRadioGroupID',
        		padding: '10px 200px ',
        		disabled:true,
        		//  fieldLabel: 'Auto Layout',
        		// cls: 'x-check-group-alt',
        		items: [
        		        {boxLabel: 'Create/Copy Scheme', name: 'crRelRadio', inputValue: 1},
        		        {boxLabel: 'Edit Scheme', name: 'crRelRadio', inputValue: 2}
        		        ],
        		        listeners:
        		        {
        		        	change: function(obj,value)
        		        	{
        		        		isCreateEdit=value.crRelRadio;
        		        		
        		        		if(isCreateEdit==1)
        		        			{
        		        			
        		        			Ext.getCmp("editSchemeField").disable();
        		        			Ext.getCmp("schemeNameNew").enable();

        		        			}
        		        		else
        		        			{
        		        			
        		        			
        		        			Ext.getCmp("editSchemeField").enable();
        		        			Ext.getCmp("schemeNameNew").disable();
        		        			}
        		        		
        		        		
        		        		
        		        	}
        		        	
        		        	
        		        	
        		        	
        		        }
        	
        	
        	
        	
        
	        	
	        	
	        
	        	
	        	
	        }
	        ]
},
{
 	url: addSchemeUrl,
 	border: false,
	layout:'column',
	bodyStyle:'padding:3px 5px',
	width: 1100,
	
	defaults: {
			bodyStyle:'padding:3px 5px'
		},
 	
 	      items:[
		  
	
          	{
          		xtype:'fieldset',
          		title: 'Create Scheme / Copy Scheme',
				columnWidth:.5,
				bodyStyle:'padding:3px 0px',
				height : 200,
          		collapsible: true,
          		id: 'schemeNameNew',
          		disabled:true,
          		items :[
				autoSuggestTextBox,
          		    {
					xtype :'textfield',
					fieldLabel: 'Scheme Name(New)*',
					
					nowrap : true,
					name: 'schemeName',
					maxLength : 50,
					width : 500,
					enforceMaxLength:"true",
					allowBlank:false
					},
				{
				xtype:'button',
      			text: 'Save',
      			id: 'saveButton',
      			handler: function() {
      			saveScheme(schemeForm);
      			}
				}
								
					
					]
          	},
			{
          		xtype:'fieldset',
				 columnWidth:.5,
          		title: 'Edit Scheme',
				height : 200,
				bodyStyle:'padding:3px 0px',
          		collapsible: true,	
          		id:'editSchemeField',
          		disabled:true,
          		items :[
				editScheme,editSchemeComp
				
					]
          	}
			
			
			
			]}
]
    });
    
    
var schemeList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
	id:'Edit',
	layout: 'fit',
 	border: false,
 	
   items:[{
	   
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
     	//	width:1200,
     	 	height:600,
			layout: 'fit',
     	 	bodyStyle:'padding:0px',
     		autoscroll:true,
     		items :[
     			{
             		html: "<div id='scheme'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
     			}
             	
     		]}
     	
   ]});


var viewschemeList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
	id: 'View',
	layout: 'fit',
 	border: false,
 	
   items:[{
	   
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
			layout: 'fit',
     		//width:1200,
     	 	height:600,
     		autoscroll:true,
     		
     		items :[
     			{
             		html: "<div id='viewscheme'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});


var SubmitschemeList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
	id:'Submission',
	layout: 'fit',
 	border: false,
 	
   items:[{
	   
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
			layout: 'fit',
     	//	width:1200,
     	 	height:600,
     		autoscroll:true,
     		
     		items :[
     			{
             		html: "<div id='submitscheme'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});

var reportList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
	layout: 'fit',
	 id:'Scheme-Approval',
 	border: false,
 	
   items:[{
	   
     		xtype:'panel',
     		//layout: 'anchor',
     		border:false,
			layout: 'fit',
     	//	width:1200,
     	 	height:600,
     		autoscroll:true,
     		
     		items :[
     			{
             		html: "<div id='report'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});

var payoutAppList = Ext.create('Ext.form.Panel', {
 	//url: addSchemeUrl,
	
 	border: false,
	layout: 'fit',
 	id:'Payout-Approval',
   items:[{
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
     	//	width:1200,
     	 	height:600,
			layout: 'fit',
     	 	//bodyStyle:'padding:0px 0px',
     		autoscroll:true,
     		
     		items :[
     		        
     			
     			{
             		html: "<div id='payoutApp'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});

var execCalList = Ext.create('Ext.form.Panel', {
 	//url: addSchemeUrl,
 	border: false,
	layout: 'fit',
	id:'Execution-Calendar',
 	
   items:[{
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
			layout: 'fit',
     	//	width:1200,
     	 	height:600,
     	 	//bodyStyle:'padding:0px 0px',
     		autoscroll:true,
     		
     		items :[
     		        
     			
     			{
             		html: "<div id='execList'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
   
   var sentToVtopList = Ext.create('Ext.form.Panel', {
 	//url: addSchemeUrl,
 	border: false,
	layout: 'fit',
	id:'Payment',
 	
   items:[{
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
     	//	width:1200,
     	 	height:600,
			layout: 'fit',
     	 	//bodyStyle:'padding:0px 0px',
     		autoscroll:true,
     		
     		items :[
     		        
     			
     			{
             		html: "<div id='sentToVtop'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
   
   
  
   



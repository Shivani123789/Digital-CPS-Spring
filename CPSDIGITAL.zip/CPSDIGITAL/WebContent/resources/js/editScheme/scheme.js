

var circleid = null;

var formPanel = null;

var schemeNameEdit = null;
var monthFlag = true;
var  schemeIdEdit = null;

var isCreateEdit=null;
function monthStore() {
    var store = new Ext.data.SimpleStore({
		mode: 'local',
    	remoteFilter: true,
        fields: ['id', 'monthId','monthName'],
        data: [['0', '0','January'], ['1', '1', 'February'],['2', '2','March'], ['3', '3', 'April'],['4', '4','May'], ['5', '5', 'June'],['6', '6','July'], ['7', '7', 'August'],['8', '8','September'], ['9', '9', 'October'],['10', '10','November'], ['11', '11', 'December']]
    });
    return store;
}

var autoSuggestTextBox = new Ext.form.ComboBox({
	name:'schemeNameOld',
	fieldLabel:'Scheme Name(Existing)*',
	displayField:'schemeName',
	valueField:'schemeName',
	editable: true,
	mode: 'local',
	store: schemeStoreCreate,
	triggerAction:'all',
	queryMode: 'local',
	emptyText:'Select a scheme...',
	forceSelection: true,
	triggerAction: 'all',
	enableKeyEvents: true,
	selectOnFocus:true,
	typeAhead: true,
	disableKeyFilter: true,
	width: 500,
	id:'copyScheme',
	disabled:true,
	listeners:{
		'select': function(combo, value){
			schemeForm.getForm().findField('schemeName').setValue(combo.getValue());

			var schemeIdEditer = schemeStoreCreate.findRecord('schemeName',combo.getValue(),0, false, true, true);
			var autoCp=schemeIdEditer.data.autoCopyFlag;
			var autoAppr=schemeIdEditer.data.autoApprovalFlag;
			var aggrEndDate=schemeIdEditer.data.aggrementEndDate;
			Ext.getCmp("autoCopyFlag").setValue({autoCopyFlag:autoCp});
			Ext.getCmp("autoApprovalFlag").setValue({autoApprovalFlag:autoAppr});
			Ext.getCmp("aggrementEndDate").setValue(aggrEndDate);
			if(combo.getValue()=="&nbsp;")
			{
				Ext.getCmp("copyScheme").setValue("");
			}
			else
			{
				Ext.Ajax.request({
					/*url : 'payoutcondition/getCircle.action',
					method: 'POST',
					params: {
						"schemeName" : combo.getValue()
					},*/

					success: function (response) {
						Ext.Ajax.request({
							url : 'payoutcondition/resetScheme.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
							method: 'POST',
							params: {
								"schemeName" :combo.getValue()//record.data.schemeINputId
							}/*,
						success: function (response) {
							//schemeStore.load();
						},

						failure: function (response) {
						}
							 */					});
					},
					failure: function (response) {
					}
				});

			}
		}
	}
} );

var editScheme = new Ext.form.ComboBox({
	name:'schemeEdit',
	id:'schemeEdit',
	fieldLabel:'Scheme*',
	displayField:'schemeName',
	valueField:'schemeINputId',
	editable: true,
	store: schemeStoreEdit,
   triggerAction:'all',
   queryMode: 'local',
	emptyText:'Select a scheme...',
	forceSelection: true,
	triggerAction: 'all',
	enableKeyEvents: true,
	selectOnFocus:true,
	typeAhead: true,
	disableKeyFilter: true, 
	//width: 300,
	width: 500,
	listeners:{
		'select': function(combo, value){ 	
			schemeNameEdit = combo.getValue();
			if(combo.getValue()=="&nbsp;")
			{
				Ext.getCmp("schemeEdit").setValue("");
				Ext.getCmp("schemeCompEdit").disable();
			}else{
				schemeIdEdit = schemeStoreEdit.findRecord('schemeINputId',combo.getValue(),0, false, true, true);
				schemeNameEdit = schemeIdEdit.data.schemeName;
				//alert(schemeNameEdit);
				/*schemeIdEdit = schemeStoreEdit.findRecord('schemeName',combo.getValue(),0, false, true, true);
				schemeIdEdit = schemeIdEdit.data.schemeINputId;
				alert(combo.getValue());
				componentEditStoreGrid.clearFilter();
				componentEditStoreGrid.filter('schemeId',schemeIdEdit);
				Ext.getCmp("schemeCompEdit").enable();*/
				schemeIdEdit = combo.getValue();
				Ext.getCmp("schemeCompEdit").reset();
				componentEditStoreGrid.load({
							params: 
								{  
								   // "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-Y'),
								   // "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-Y'),
								   // "payTo": Ext.getCmp("payToValFilter").getValue()
								 "schemeId" : combo.getValue(),
								}
						});
			}
			//Ext.getCmp("schemeCompEdit").reset();
		}
	}
});



var editSchemeComp = new Ext.form.ComboBox({
	name:'schemeCompEdit',
	id:'schemeCompEdit',
	//disabled : true,
	fieldLabel:'Component',
	displayField:'compName',
	valueField:'compName',
	//allowBlank: false,
	editable: false,
	//typeAhead: true,
	mode: 'local',
	store: componentEditStoreGrid,
	triggerAction:'all',
	queryMode: 'local',
	width: 500,
	enableKeyEvents: true,
	selectOnFocus:true,
	typeAhead: true,
	disableKeyFilter: true,
	listeners:{
		select:{
			fn:function(combo,record,index) {

				Ext.Ajax.request({
					url : 'payoutcondition/resetScheme.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
					method: 'POST',
					params: {
						"schemeName" :schemeNameEdit,
						"compName": combo.getValue()
					},
					success: function (response) {
						//Ext.getCmp("schemeCompEdit").reset();
						//Ext.getCmp("schemeEdit").reset();							
						compName = combo.getValue();



						formPanel.items.each(function(c){


							c.setActiveTab(c.items.items[1]);

							//componentStoreGrid.load();

						});


					},

					failure: function (response) {
					}
				});


			}
		}
	}
} );





function saveScheme(schemeForm)
{
	 
	/*//var temp="csrf=-6615455815771037141; TJE=; TE3=N0:C N1:C N2:C N3:E N4:E N5:C N6:C N7:C N8:C N9:C N10:C N11:C N12:C N13:C N14:C N15:C N16:C N17:C N18:C N19:C N20:C N21:C N22:C N23:C N24:C N25:C N26:C N27:C N28:C N29:C N30:C N31:C; LtpaToken2=7jZPtCiYBWEgyXLCzoTdxWHzvmmT0sWI/QGhOVC9VCrez+QkCAjCeCM0uObMOwSNI2R0HwwRwcu9pSb3bvwRCLvawO4hstsL/ttWzZ76z+ekHHK51kca0tOODZ1EsJZvodke3c69TT/gT3p1R81aT07htIaX246XPJeleN4vBB//qrrjW51sQiEaDAi32D40JoRFwYl6CB2vXucnGAlM6YmmtkBSZvWE51010ovjBulwpCuw8iu5xdhxawpe3/WzB2Jl7+pqukkLUsUt5Kpwav014uPYtMB2c/jiUr4Fp21Q/qdxZQHvLXxpAo7Hl17sF317yitvwbOFmYCXJEf6voh7qo3VeeWpwC3kJOy86qA2cd3XTg5S+o/yuScbXNC7UDZ7q7lRVDCr6gF9YTc9LQCyIBJuyzE/guF6460YMeW23XlfvpyEXYdehhOJRtttlLgLLzgQAPuZUjSWcHm1U79SN899G+4QY7GNOlU8a6yTQBnjRFMIp+k5SK1r2SHj/H8fTJvoVDCuWA8QAsVtGGnl74GD6o24RaP5RdfV34RFJKpJ2isOIAICBc/0fqmoqeqjv5YgSgvQS4iFgNHHYNTD66Vs+fQQAU5uu5SsL29tM0Rkt42vASzrMcIdrxz2XeQArbx4368A69Wv7BYMKw==; sessionCode=514564614; csrf=7892054190907715618; JSESSIONID=0000GyicL2U3RAnL6fjyqTYRiRW:-1";
	var temp1=temp.split("csrf");
	alert(temp1.length);
	if(temp1.length>2)
		{
		temp="csrf"+temp1[2].split(";")[0];
		}*/
	//alert(document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"));
	if(schemeForm.getForm().isValid())
	{
	schemeForm.getForm().submit({
		 waitMsg : 'Loading...',
		 //url:addSchemeUrl,
		 url : 'payoutcondition/addScheme.action?csrf='+document.cookie.replace(/(?:(?:^|.*;\s*)csrf\s*\=\s*([^;]*).*$)|^.*$/, "$1"),
		 method : 'POST',
        
		 success: function(form, action) {
			 
			 if(action.result != null)
		            Ext.Msg.alert(action.result.schemeName+'  '+action.result.createMode, action.result.errorMessage);
           // Ext.Msg.alert(action.result.schemeName+' Scheme Created Sucessfully');
            SchemeName = action.result.schemeName;
            form.reset();
			condBody = '';
			condBodyTq = '';
			
			if(action.result.createMode!='Copied')
				{
			formPanel.items.each(function(c){				
				c.items.items[1].setDisabled(true);
						c.items.items[2].setDisabled(true);
						c.items.items[3].setDisabled(true);
						c.items.items[4].setDisabled(true);
						c.items.items[5].setDisabled(true);
						c.items.items[6].setDisabled(true);
						c.items.items[7].setDisabled(true);
						//c.items.items[8].setDisabled(true);
						c.items.items[1].setDisabled(false);
						c.setActiveTab(c.items.items[1]);
						})
						
				}
				
				else
				{
				
				formPanel.items.each(function(c){
		    	
				
						c.items.items[1].setDisabled(false);
						c.items.items[2].setDisabled(false);
						c.items.items[3].setDisabled(false);
						c.items.items[4].setDisabled(false);
						c.items.items[5].setDisabled(false);
						c.items.items[6].setDisabled(false);
						c.items.items[7].setDisabled(false);
					//	c.items.items[1].setDisabled(false);
						c.setActiveTab(c.items.items[1]);

				})
				
				
				
				
				}

           // componentStoreGrid.load();
           // regZoneStore.load();
        },
        failure: function(form, action) {
        	//console.log(action.response.status);
        	if(action.result != null)
            Ext.Msg.alert('Warning', action.result.errorMessage);
        	else
        		{
        		if(action.response.status=403)
        			Ext.Msg.alert('Warning','Access Denied' );
        		else
        		Ext.Msg.alert('Warning', "Attribite Mapping Error");
        		}
        }
    });
	
	}
	
	else
		{
		Ext.Msg.alert('Warning', "Please Fill All Mandatory Fields");
		}
}

	

    var schemeForm = Ext.create('Ext.form.Panel', {
    	border: false,
    	//layout:'column',
    	bodyStyle:'padding:3px 5px',
    	width: 900,
    	defaults: {
    		bodyStyle:'padding:3px 5px'
    	},
    	items:[
{
	xtype:'fieldset',
	layout:'column',
	title: 'Filter Scheme List',
	//height : ,
	//bodyStyle:'padding:3px 0px',
	collapsible: true,	
	
	items :[
	      
	        {
	        	xtype       : 'datefield',
	        	fieldLabel  : 'Search Criteria',
	        	allowBlank  : true,
	        	emptyText   : 'Start Date',
	        	name        : 'fromDateSearchScm',
	        	id: 'fromDateSearchScm',
	        	editable    : false,
	        	padding: '0px 30px',
	        	listeners:
        		{
        		'select':
        			function()
        			{
        			if(Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'Y/m/d')!=null && Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'Y/m/d')!="")
        			var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'Y/m/d'));
        			if(flag && Ext.getCmp("payToValFilter").getValue()!=null)
        				{
        				schemeStoreCreate.load(
        						{
        							params: 
        								{  
        								    "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-Y'),
        								    "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-Y'),
        								    "payTo": Ext.getCmp("payToValFilter").getValue()
        							
        								}
        						}		
        						);
        						
        						schemeStoreEdit.load(
        						{
        								params:
        									{
        									
        									  "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-Y'),
        									  "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-Y'),
        									  "payTo": Ext.getCmp("payToValFilter").getValue()

        									}

        						}
        					
        						
        						);
        				
        				
        				}
        			
        			
        			}
        		
        		
        		}
	        },
	        {
	        	xtype       : 'datefield',
	        	//fieldLabel  : 'End Date',
	        	allowBlank  : true,
	        	emptyText   : 'End Date',
	        	name        : 'toDateSearchScm',
	        	id: 'toDateSearchScm',
	        	editable    : false,
	        	padding: '0px 10px',
	        	listeners:
        		{
        		
        		'select':
        			function()
        			{
        			
        			if(Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'Y/m/d')!=null && Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'Y/m/d')!="")
        			var flag = checkDateValidation(Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'Y/m/d'),Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'Y/m/d'));
        			if(flag && Ext.getCmp("payToValFilter").getValue()!=null)
        				{
        				Ext.getCmp("schemeCompEdit").reset();
        				schemeStoreCreate.load(
        						{
        							params: 
        								{  
        								
        								    "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-Y'),
        								    "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-Y'),
        								    "payTo": Ext.getCmp("payToValFilter").getValue()
        							
        								}
        						}		
        						);
        						
        						schemeStoreEdit.load(
        						{
        								params:
        									{
        									
        									  "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-Y'),
        									  "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-Y'),
        									  "payTo": Ext.getCmp("payToValFilter").getValue()

        									}

        						}
        					
        						
        						);
        				
        				
        				}
        			
        			
        			}
        		
        		
        		}
	        },
	        { 

					xtype :'combo',
					//fieldLabel: 'Pay To*',
					name:'payTo',
				    id:'payToValFilter',
					displayField:'displayValue',
					valueField:'entityTypeId',
					editable: false,
					store: payToStoreCreate,
					triggerAction:'all',
					padding: '0px 10px',
					emptyText   : 'PayTo',
					listeners:{
					'select' :function(combo,value) {
						
					//	alert(Ext.getCmp("fromDateSearchScm").getValue());
						Ext.getCmp("schemeCompEdit").reset();
						
						if(Ext.getCmp("fromDateSearchScm").getValue()!=null && Ext.getCmp("toDateSearchScm").getValue()!=null)
							{
							Ext.getCmp("schemeRadioGroupID").enable();
						schemeStoreCreate.load(
						{
							params: 
								{  
								    "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-Y'),
								    "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-Y'),
								    "payTo": Ext.getCmp("payToValFilter").getValue()
								}
						}		
						);
						
						schemeStoreEdit.load(
						{
								params:
									{
									
									  "startDate": Ext.Date.format(Ext.getCmp("fromDateSearchScm").getValue(),'d-M-Y'),
									  "endDate": Ext.Date.format(Ext.getCmp("toDateSearchScm").getValue(),'d-M-Y'),
									  "payTo": Ext.getCmp("payToValFilter").getValue()

									}

						}
					
						
						);
						
							}	
						
						else
							{
							Ext.getCmp("schemeRadioGroupID").disable();

							Ext.Msg.alert(" Please provide start date / end date values");
							
							Ext.getCmp("payToValFilter").reset();
							}
						
						
						}
					}
						
	        	
	        },
	        {

        		xtype: 'radiogroup',
        		width:'300%',
        		id: 'schemeRadioGroupID',
        		fieldLabel  : 'Copy/Edit Scheme',
        		padding: '10px 31px ',
        		disabled:true,
        		nowrap:false,
        		labelStyle: 'white-space: nowrap;',
        		//  fieldLabel: 'Auto Layout',
        		// cls: 'x-check-group-alt',
        		items: [
        		        {boxLabel: 'Copy', name: 'crRelRadio', inputValue: 1,padding: '0px 40px '},
        		        {boxLabel: 'Edit', name: 'crRelRadio', inputValue: 2,padding: '0px 40px '}
        		        ],
        		        listeners:
        		        {
        		        	change: function(obj,value)
        		        	{
        		        		isCreateEdit=value.crRelRadio;

        		        		if(isCreateEdit==1)
        		        			{
        		        			Ext.getCmp("editSchemeField").disable();
        		        			Ext.getCmp("copyScheme").enable();
        		        			Ext.getCmp("monthName").enable();
        		        			Ext.getCmp("autoCopyFlag").enable();
        		        			}
        		        		else
        		        			{
        		        			Ext.getCmp("editSchemeField").enable();
        		        			Ext.getCmp("copyScheme").disable();
        		        			Ext.getCmp("monthName").disable();
        		        			Ext.getCmp("autoCopyFlag").disable();
        		        			}
        		        	}
        		        }
	        }
	        ]
},
{
 	url: addSchemeUrl,
 	border: false,
	layout:'column',
	bodyStyle:'padding:3px 5px',
	width: 1100,
	
	defaults: {
			bodyStyle:'padding:3px 5px'
		},
 	
 	      items:[
		  
	
          	{
          		xtype:'fieldset',
          		title: 'Create/Copy Scheme',
				columnWidth:.5,
				bodyStyle:'padding:3px 0px',
				height : 400,
          		collapsible: true,
          		id: 'schemeNameNew',
          		//disabled:true,
          		items :[
				autoSuggestTextBox,
				{
					xtype :'combo',
					fieldLabel: 'Month*',
					name:'month',
					id:'monthName',
					editable: false,
					displayField:'monthName',
					allowBlank:false,
					valueField:'monthId',
					disabled:true,
					store: monthStore(),
					listeners: {
						'select': function(combo, value){
							var d = new Date();
							var n = combo.getValue();
							var d2 = new Date(d).setDate(1);
							var prevmonth1 = new Date(new Date(d2).setMonth(d.getMonth() - 1));
							var prevmonth2 = new Date(new Date(prevmonth1).setMonth(prevmonth1.getMonth() - 1));
							var prevmonth3 = new Date(new Date(prevmonth2).setMonth(prevmonth2.getMonth() - 1));

							var testnextmonth = new Date(new Date(d2).setMonth(d.getMonth()+1));
							if(n==testnextmonth.getMonth()){
								monthFlag=true;
							}else if(n==prevmonth1.getMonth()){
								monthFlag=true;
							}else if(n==prevmonth2.getMonth()){
								monthFlag=true;
							}else if(n==prevmonth3.getMonth()){
								monthFlag=true;
							}else if(n==d.getMonth()){
								monthFlag=true;
							}else{
								monthFlag=false;
								Ext.Msg.alert("Warning","<font color='red'>You can not create a scheme for 'less than 3 months' or 'more than 1 month' from current month.</font>");
								//Ext.Msg.alert("Warning","<font color='red'>You can not copy a scheme which is more than 3 months older, and <br> You can also not create a scheme for a month which is beyond 1 month..</font>");
								//alert("Not curr cur month ::: "+month[d.getMonth()]+"\n next month :::: "+month[(testnextmonth.getMonth())]+"\n  prev month1 ::::  "+month[(prevmonth1.getMonth())] +"\n  prev month2 ::::  "+month[(prevmonth2.getMonth())] +"\n  prev month3 ::::  "+month[(prevmonth3.getMonth())]+"  n:::: "+n );
							}
						}
					},
					triggerAction:'all'
				},
          		    {
					xtype :'textfield',
					fieldLabel: 'Scheme Name(New)*',
					id:'newSchemeCreate',
					nowrap : true,
					name: 'schemeName',
					maxLength : 50,
					width : 500,
					enforceMaxLength:"true",
					//maskRe:/[A-Za-z0-9_- ]/,
					allowBlank:false
					},
					{
						xtype:'radiogroup',
						fieldLabel:'Auto Copy Flag:',
						displayField:'autoCopyFlag',
						valueField:'autoCopyFlag',
						editable: true,
						mode: 'local',
						store: schemeStoreCreate,
						id:'autoCopyFlag',
						items:
                           [
                            {boxLabel:'Yes', name:'autoCopyFlag',inputValue:'Y'},
                            {boxLabel:'No', name:'autoCopyFlag',inputValue:'N',checked:true},
                            ],
                            listeners:
                        	{
                        	change:function(obj,val)
                        	{
                        		if(val.autoCopyFlag=='Y')
                        			   {
                        			autoCopyFlag=1;
                        			   Ext.getCmp('aggrementEndDate').enable();
                            	       Ext.getCmp('autoApprovalFlag').enable();
                            	     //  Ext.getCmp('tbarSchemeCompAddBut').disable();
                        			   }
                        		   if(val.autoCopyFlag=='N')
                        			   {
                        			   autoCopyFlag=0;
                          		      Ext.getCmp('aggrementEndDate').disable();
                           	          Ext.getCmp('autoApprovalFlag').disable();
                           	          Ext.getCmp('aggrementEndDate').setValue("");
                           	          var emptyText="N";
                           	          Ext.getCmp("autoApprovalFlag").setValue({autoApprovalFlag:emptyText});
                           	          //Ext.getCmp('tbarSchemeCompAddBut').enable();
                        			   }
                        	}
                        	}
					},
					{
						xtype:'datefield',
						fieldLabel:'Agreement End Date',
						disabled:true,
						id:'aggrementEndDate',
						name:'aggrementEndDate',
						displayField:'aggrementEndDate',
						valueField:'aggrementEndDate',
						editable: false,
						mode: 'local',
						store: schemeStoreCreate,
						allowBlank:false
					},
					{
						xtype:'radiogroup',
 						fieldLabel:'Auto Approval Flag',
 						id:'autoApprovalFlag',
 						name:'autoApprovalFlag',
 						displayField:'autoApprovalFlag',
 						valueField:'autoApprovalFlag',
 						editable: true,
 						mode: 'local',
 						store: schemeStoreCreate,
                        items: 	
                        	[
                        	 {boxLabel:'Yes', name:'autoApprovalFlag',inputValue:'Y'},
                        	 {boxLabel:'No', name:'autoApprovalFlag',inputValue:'N',checked:true}
                        	 ],
                       disabled:true
                       },

			        		{
			        		    	   xtype :'textfield',
			        		    	   fieldLabel: 'CsrfName',
								   hidden:true,
			        		    	   disabled : true,
			        		    	   name: 'csrfAppr',
								   maxLength : 100,
			        		    	   allowBlank:false,
			        		    	   id:'testCsrfAppr'
			        		    },
				{
				xtype:'button',
      			text: 'Save',
      			id: 'saveButton',
      			handler: function() {
      			//	alert('hai');
      				if(monthFlag){
      					saveScheme(schemeForm);
      				}
      			}
				}
					
					]
          	},
			{
          		xtype:'fieldset',
				 columnWidth:.5,
          		title: 'Edit Scheme',
				height : 200,
				bodyStyle:'padding:3px 0px',
          		collapsible: true,	
          		id:'editSchemeField',
          		disabled:true,
          		items :[
				editScheme,editSchemeComp
					]
          	}
			
			
			
			]}
]
    });
    
    
var schemeList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
	id:'Edit',
	layout: 'fit',
 	border: false,
 	
   items:[{
	   
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
     	//	width:1200,
     	 	height:600,
			layout: 'fit',
     	 	bodyStyle:'padding:0px',
     		autoscroll:true,
     		items :[
     			{
             		html: "<div id='scheme'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
     			}
             	
     		]}
     	
   ]});


var viewschemeList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
	id: 'View',
	layout: 'fit',
 	border: false,
 	
   items:[{
	   
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
			layout: 'fit',
     		//width:1200,
     	 	height:600,
     		autoscroll:true,
     		
     		items :[
     			{
             		html: "<div id='viewscheme'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});


var SubmitschemeList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
	id:'Submission',
	layout: 'fit',
 	border: false,
 	
   items:[{
	   
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
			layout: 'fit',
     	//	width:1200,
     	 	height:600,
     		autoscroll:true,
     		
     		items :[
     			{
             		html: "<div id='submitscheme'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});

var reportList = Ext.create('Ext.form.Panel', {
 	url: addSchemeUrl,
	layout: 'fit',
	 id:'Scheme-Approval',
 	border: false,
 	
   items:[{
	   
     		xtype:'panel',
     		//layout: 'anchor',
     		border:false,
			layout: 'fit',
     	//	width:1200,
     	 	height:600,
     		autoscroll:true,
     		
     		items :[
     			{
             		html: "<div id='report'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});

var payoutAppList = Ext.create('Ext.form.Panel', {
 	//url: addSchemeUrl,
	
 	border: false,
	layout: 'fit',
 	id:'Payout-Approval',
   items:[{
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
     	//	width:1200,
     	 	height:600,
			layout: 'fit',
     	 	//bodyStyle:'padding:0px 0px',
     		autoscroll:true,
     		
     		items :[
     		        
     			
     			{
             		html: "<div id='payoutApp'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});

var execCalList = Ext.create('Ext.form.Panel', {
 	//url: addSchemeUrl,
 	border: false,
	layout: 'fit',
	id:'Execution-Calendar',
 	
   items:[{
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
			layout: 'fit',
     	//	width:1200,
     	 	height:600,
     	 	//bodyStyle:'padding:0px 0px',
     		autoscroll:true,
     		
     		items :[
     		        
     			
     			{
             		html: "<div id='execList'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});
   
   var sentToVtopList = Ext.create('Ext.form.Panel', {
 	//url: addSchemeUrl,
 	border: false,
	layout: 'fit',
	id:'Payment',
 	
   items:[{
     		xtype:'panel',
     	//	layout: 'anchor',
     		border:false,
     	//	width:1200,
     	 	height:600,
			layout: 'fit',
     	 	//bodyStyle:'padding:0px 0px',
     		autoscroll:true,
     		items :[
     			{
             		html: "<div id='sentToVtop'></div>",
             		xtype: "panel",
					layout: 'fit',
             		border:false,
             		autoscroll:true
             		
     			}
             	
     		]}
     	
   ]});